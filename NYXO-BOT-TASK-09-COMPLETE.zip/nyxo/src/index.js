require('./legacy/compat');

const mongoose = require('mongoose');
const { config, validateConfig } = require('./config/config');
const BotManager = require('./handlers/botManager');
const connectDatabase = require('./database/connect');
const loadCommands = require('./handlers/commandHandler');
const loadEvents = require('./handlers/eventHandler');
const loadLegacyHandlers = require('./legacy/loadLegacyHandlers');
const autoDeployCommands = require('./handlers/deployCommands');
const { stopScheduler } = require('./services/scheduleService');
const { stopAnnouncementScheduler } = require('./services/announcementService');
const { stopAllAfkSessions } = require('./services/afkRewardsService');
const { stopVoiceXpScheduler } = require('./services/voiceXpService');
const { initializeComponents } = require('./components/componentInitializers');
const logger = require('./utils/logger');

let dashboardServer = null;
let shuttingDown = false;
let botManager = null;

validateConfig();
botManager = new BotManager();

async function main() {
  try {
    logger.info('🟦 NYXO BOT - Unified Single-Bot Version');
    logger.info('═══════════════════════════════════════════════════════');

    // Phase 1: Database
    await connectDatabase();
    logger.success('✓ Database connected');

    // Phase 2: Create client
    const client = await botManager.initializeBot(config);
    logger.success('✓ Unified bot client initialized');

    // Phase 3: Load handlers (must happen before login so events are
    // registered before Discord sends the READY payload)
    logger.info('📦 Loading commands and events...');
    loadCommands(client);
    loadEvents(client);
    loadLegacyHandlers(client);
    logger.success('✓ All handlers loaded once on the unified client');

    // Phase 4: Load components
    logger.info('📋 Loading components...');
    const componentManager = await initializeComponents();
    logger.success('✓ All components loaded');
    client.componentManager = componentManager;

    // Phase 5: Connect to Discord gateway
    await botManager.login(config);

    // Phase 6: Wait for Discord to confirm the bot is fully ready.
    // login() resolves as soon as the WebSocket connects; the clientReady
    // event fires later, once Discord sends the READY payload and
    // client.user is set. Deploying commands and starting the dashboard
    // before that point risks using a null client.user or stale guild cache.
    logger.info('⏳ Waiting for Discord ready event...');
    await new Promise((resolve) => client.once('clientReady', resolve));

    // Phase 7: Deploy slash commands (REST — does not need the gateway,
    // but does need client.user.id which is only set after clientReady)
    logger.info('📡 Deploying slash commands...');
    await autoDeployCommands(client);
    logger.success('✓ Slash commands deployed for the unified bot');

    // Phase 8: Start dashboard (client is fully ready at this point)
    logger.info('🌐 Starting dashboard...');
    const startDashboard = require('../dashboard/server');
    dashboardServer = startDashboard(client);
    logger.success('✓ Dashboard started');

    logger.success('═══════════════════════════════════════════════════════');
    logger.success('✓ Unified Discord bot is running successfully with one Client and one token');
  } catch (error) {
    logger.error(`Fatal startup error: ${error?.stack || error}`);
    process.exit(1);
  }
}

async function shutdown(signal) {
  if (shuttingDown) return;
  shuttingDown = true;
  logger.warn(`Received ${signal}, shutting down gracefully...`);

  const timeout = setTimeout(() => {
    logger.error('Graceful shutdown timed out after 10s, forcing exit.');
    process.exit(1);
  }, 10_000);
  timeout.unref();

  // Stop schedulers that were started by the ready event.
  // These are safe to call even if the scheduler never started (they
  // check for a null timer internally before clearing).
  try {
    stopScheduler();
    stopAnnouncementScheduler();
    stopAllAfkSessions();
    stopVoiceXpScheduler();
  } catch (err) {
    logger.error(`Error stopping schedulers: ${err?.stack || err}`);
  }

  try {
    if (dashboardServer) {
      await new Promise((resolve) => dashboardServer.close(resolve));
    }
  } catch (err) {
    logger.error(`Error closing dashboard server: ${err?.stack || err}`);
  }

  try {
    if (botManager) botManager.destroy();
  } catch (err) {
    logger.error(`Error destroying unified Discord bot: ${err?.stack || err}`);
  }

  try {
    if (mongoose.connection.readyState !== 0) {
      await mongoose.connection.close();
    }
  } catch (err) {
    logger.error(`Error closing MongoDB connection: ${err?.stack || err}`);
  }

  logger.success('Shutdown complete.');
  clearTimeout(timeout);
  process.exit(0);
}

process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));

// Known benign rejection codes from the Discord API that do not indicate a
// bug: 10062 = Unknown Interaction (timed out before reply), 10008 = Unknown
// Message (deleted before the bot could edit/delete it), 10003 = Unknown
// Channel, 50013 = Missing Permissions. Logging these as ERROR is misleading;
// they are demoted to WARN. Everything else stays as ERROR.
const BENIGN_DISCORD_CODES = new Set([10062, 10008, 10003, 50013]);

function isBenignDiscordError(err) {
  if (!err) return false;
  if (typeof err.code === 'number' && BENIGN_DISCORD_CODES.has(err.code)) return true;
  if (err.status === 429) return true; // rate-limit
  return false;
}

process.on('unhandledRejection', (err) => {
  if (isBenignDiscordError(err)) {
    logger.warn(`Unhandled rejection (benign Discord API): ${err?.message || err}`);
  } else {
    logger.error(`Unhandled promise rejection: ${err?.stack || err}`);
  }
});

process.on('uncaughtException', (err) => {
  logger.error(`Uncaught exception: ${err?.stack || err}`);
});

main().catch((err) => {
  logger.error(`Fatal startup error: ${err?.stack || err}`);
  process.exit(1);
});

module.exports = { botManager, config };
