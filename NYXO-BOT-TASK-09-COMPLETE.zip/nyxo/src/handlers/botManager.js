/**
 * Unified Discord client manager.
 *
 * The former implementation created three independent Clients and logged
 * each one in with a different token. Keeping that split at runtime caused
 * duplicate gateway events and made features depend on which bot owned them.
 * This manager now creates exactly one Client. The old method names remain as
 * compatibility aliases for scripts that import BotManager directly; every
 * alias returns or operates on the same single client.
 */

const { Client, GatewayIntentBits, Partials } = require('discord.js');
const logger = require('../utils/logger');

class BotManager {
  constructor() {
    this.client = null;
  }

  /**
   * Create a new Discord client with standard intents
   */
  createClient() {
    const client = new Client({
      intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildMessageReactions,
        GatewayIntentBits.GuildModeration,
        GatewayIntentBits.GuildWebhooks,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildVoiceStates,
      ],
      partials: [
        Partials.Message,
        Partials.Channel,
        Partials.Reaction,
        Partials.GuildMember
      ],
    });

    // TASK 27 — Performance: the unified client registers listeners from
    // botManager (5), eventHandler (~23 event files), and legacy handlers
    // on the same EventEmitter. The previous cap of 20 was conservative
    // and triggered spurious "MaxListenersExceededWarning" leakage notices
    // in some deployments. 50 gives headroom for all current listeners
    // plus future additions without ever hitting the warning threshold.
    client.setMaxListeners(50);

    // Error handlers
    client.on('error', (err) => 
      logger.error(`Discord client error: ${err?.stack || err}`)
    );
    client.on('shardError', (err, shardId) => 
      logger.error(`Discord shard ${shardId} error: ${err?.stack || err}`)
    );
    client.on('shardDisconnect', (event, shardId) => 
      logger.warn(`Discord shard ${shardId} disconnected (code ${event?.code}). Reconnecting automatically...`)
    );
    client.on('shardReconnecting', (shardId) => 
      logger.warn(`Discord shard ${shardId} reconnecting...`)
    );
    client.on('shardResume', (shardId, replayedEvents) => 
      logger.success(`Discord shard ${shardId} resumed (${replayedEvents} events replayed).`)
    );

    return client;
  }

  /**
   * Initialize the one unified bot client.
   */
  async initializeBot() {
    try {
      if (!this.client) {
        this.client = this.createClient();
        // Intentionally leave client.botKey unset (not a separate botType
        // field - every consumer across the codebase, e.g.
        // handlers/commandHandler.js, handlers/eventHandler.js,
        // legacy/loadLegacyHandlers.js, reads client.botKey, never
        // client.botType). Falsy botKey is what those loaders treat as
        // "single-client mode: select all features".
        logger.info('✓ Created one unified Discord client');
      }
      return this.client;
    } catch (error) {
      logger.error(`Error initializing unified bot: ${error?.stack || error}`);
      throw error;
    }
  }

  // Backward-compatible entry point: it still creates one client, never 3.
  async initializeBots() {
    return this.initializeBot();
  }

  /**
   * Get the unified client. Takes no botKey argument - any extra argument a
   * legacy caller passes is simply ignored by JavaScript, and this never
   * creates or selects another Client.
   */
  getBot() {
    return this.client;
  }

  /**
   * Compatibility view for older callers. Every legacy key points to the
   * same object, making the single-client invariant explicit.
   */
  getAllBots() {
    return {
      bot1: this.client,
      bot2: this.client,
      bot3: this.client,
      unified: this.client,
    };
  }

  /**
   * Login the one client with the one configured token.
   */
  async login(config) {
    try {
      if (!this.client) await this.initializeBot();
      await this.client.login(config.token);
      logger.success('✓ Unified Discord bot logged in successfully');
    } catch (error) {
      logger.error(`Error logging in unified bot: ${error?.stack || error}`);
      throw error;
    }
  }

  // Backward-compatible alias. It still performs exactly one login.
  async loginAllBots(config) {
    return this.login(config);
  }

  /**
   * Destroy the one Discord connection.
   */
  destroy() {
    try {
      logger.info('Destroying unified bot connection...');
      if (this.client) {
        this.client.destroy();
        logger.info('✓ Unified Discord connection destroyed');
      }
      logger.success('Unified bot connection destroyed');
    } catch (error) {
      logger.error(`Error destroying unified bot: ${error?.stack || error}`);
    }
  }

  // Backward-compatible alias. It cannot destroy more than one client.
  destroyAllBots() {
    return this.destroy();
  }
}

module.exports = BotManager;
