const path = require('node:path');
const logger = require('../utils/logger');
const { walk } = require('../utils/fileWalker');
const { resolveEventOwner, EVENT_FILE_MAP } = require('../config/botEventMap');

/**
 * Loads events and attaches them to `client`.
 *
 * TASK 4 (multi-bot event isolation): registering every file under
 * src/events/** on all 3 bot clients used to mean a single Discord
 * event (e.g. a member join) fired the SAME feature logic 3 times, once
 * per bot's independent gateway connection - a triple welcome message,
 * a triple auto-mod punishment, XP granted 3 times, etc. Being separate
 * Client instances was never enough on its own; the event *logic* has
 * to know which bot it's running as.
 *
 * If `client.botKey` is set (bot1/bot2/bot3 - assigned in
 * handlers/botManager.js), each event file is only registered on the
 * bot(s) config/botEventMap.js assigns it to. Files that mix logic from
 * two bot domains are registered on both of those bots but gate every
 * internal block themselves with `client.botKey` (see the file, and the
 * comments in botEventMap.js), so nothing still runs twice. No event
 * file is deleted, moved, or has a feature removed - this is a
 * load-time filter only, exactly like commandHandler.js's Task 2 split.
 *
 * If `client.botKey` is not set (e.g. a script spinning up a single
 * generic client), every event loads as before, unaffected.
 */
function loadEvents(client) {
  const eventsPath = path.join(__dirname, '..', 'events');
  const files = walk(eventsPath);

  let loaded = 0;
  let skipped = 0;
  let filteredOut = 0;
  for (const file of files) {
    let event;
    try {
      delete require.cache[require.resolve(file)];
      event = require(file);
    } catch (error) {
      logger.warn(`Skipping event that could not be loaded (${path.relative(eventsPath, file)}): ${error.message}`);
      skipped += 1;
      continue;
    }

    if (!event?.name || !event?.execute) {
      logger.warn(`Skipping invalid event file: ${file}`);
      skipped += 1;
      continue;
    }

    if (client.botKey && client.botKey !== 'unified') {
      const relPath = path.relative(eventsPath, file).split(path.sep).join('/');
      const owner = resolveEventOwner(relPath);

       if (!(relPath in EVENT_FILE_MAP)) {
        logger.warn(`Event file "${relPath}" is not in config/botEventMap.js - loading on every bot by default. Add it to the map to isolate it properly.`);
      }

      const ownsThisBot = owner === 'all' || (Array.isArray(owner) ? owner.includes(client.botKey) : owner === client.botKey);
      if (!ownsThisBot) {
        filteredOut += 1;
        continue;
      }
    }

    if (event.once) {
      client.once(event.name, (...args) => runEvent(event, args, client));
    } else {
      client.on(event.name, (...args) => runEvent(event, args, client));
    }
    loaded += 1;
  }

  const botLabel = client.botKey && client.botKey !== 'unified' ? ` for ${client.botKey}` : ' for unified client';
  logger.success(`Loaded ${loaded} events${botLabel}${skipped ? ` (${skipped} skipped safely)` : ''}${filteredOut ? ` (${filteredOut} belong to other bots)` : ''}`);
}

/**
 * Reliability net around every event listener: most event files (see
 * src/events/**) are async and have no top-level try/catch of their own,
 * so a rejection anywhere inside one (a DB hiccup, a missing cache entry,
 * etc.) used to surface only as a generic, context-free line from index.js's
 * global unhandledRejection handler - with no indication of which event
 * fired it. This catches it right at the source, logs the event name so
 * it's actually actionable, and - since discord.js keeps dispatching future
 * emissions of the same event regardless - preserves the exact behavior
 * that already existed: one bad emission is logged and dropped, the bot
 * keeps running.
 */
async function runEvent(event, args, client) {
  try {
    await event.execute(...args, client);
  } catch (err) {
    logger.error(`Event "${event.name}" handler crashed: ${err?.stack || err}`);
  }
}

module.exports = loadEvents;
