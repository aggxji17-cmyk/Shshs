const path = require('node:path');
const { Collection } = require('discord.js');
const logger = require('../utils/logger');
const { walk } = require('../utils/fileWalker');
const { resolveOwnerBot } = require('../config/botCommandMap');

/**
 * Loads commands into `client.commands`.
 *
 * The unified client intentionally has no botKey, so every command from all
 * former feature domains is loaded into one collection. Ownership metadata is
 * still recorded for diagnostics and backwards-compatible tooling, but it is
 * never used to discard a command in the single-bot runtime.
 */
function loadCommands(client) {
  client.commands = new Collection();
  const commandsPath = path.join(__dirname, '..', 'commands');
  const files = walk(commandsPath).sort((a, b) => {
    const aLegacy = a.includes(`${path.sep}legacy${path.sep}`);
    const bLegacy = b.includes(`${path.sep}legacy${path.sep}`);
    return Number(aLegacy) - Number(bLegacy) || a.localeCompare(b);
  });

  let loaded = 0;
  let skipped = 0;
  let filteredOut = 0;
  for (const file of files) {
    let command;
    try {
      delete require.cache[require.resolve(file)];
      command = require(file);
    } catch (error) {
      logger.warn(`Skipping command that could not be loaded (${path.relative(commandsPath, file)}): ${error.message}`);
      skipped += 1;
      continue;
    }

    if (!command?.data || !command?.execute) {
      logger.warn(`Skipping invalid command file: ${file}`);
      skipped += 1;
      continue;
    }

    const commandName = command.data.name;
    if (typeof commandName !== 'string' || commandName.length === 0) {
      logger.warn(`Skipping command file with no valid command name (missing .setName()): ${path.relative(commandsPath, file)}`);
      skipped += 1;
      continue;
    }

    if (client.commands.has(commandName)) {
      logger.warn(`Skipping duplicate command "${commandName}" (${path.relative(commandsPath, file)}); keeping the first implementation.`);
      skipped += 1;
      continue;
    }

    // Category = the command's immediate parent folder under src/commands/
    // (e.g. "moderation" for src/commands/moderation/warn.js). Stashed on
    // the command object itself so anything holding client.commands can
    // group/filter by category with no extra filesystem walk - used by
    // /rolepermissions' allow-category / deny-category / clear-category
    // subcommands (utils/commandCategories.js).
    command.category = path.relative(commandsPath, path.dirname(file)).split(path.sep)[0];

    const ownerBot = resolveOwnerBot(file, commandsPath);
    command.ownerBot = ownerBot;

    // A legacy caller may still pass a botKey. Preserve that old isolated
    // mode for compatibility, while the real unified client leaves it unset.
    if (client.botKey && client.botKey !== 'unified' && ownerBot !== client.botKey) {
      filteredOut += 1;
      continue;
    }

    client.commands.set(commandName, command);
    loaded += 1;
  }

  const botLabel = client.botKey ? ` for ${client.botKey}` : '';
  logger.success(`Loaded ${loaded} application commands${botLabel}${skipped ? ` (${skipped} skipped safely)` : ''}${filteredOut ? ` (${filteredOut} belong to other bots)` : ''}`);
}

module.exports = loadCommands;
