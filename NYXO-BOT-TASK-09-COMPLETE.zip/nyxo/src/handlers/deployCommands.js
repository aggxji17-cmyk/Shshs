const { REST, Routes } = require('discord.js');
const { config } = require('../config/config');
const logger = require('../utils/logger');

/**
 * Registers every loaded slash/context-menu command with Discord.
 *
 * This is the same registration the standalone `npm run deploy-commands`
 * script performs, but running it automatically on every startup means
 * hosts whose control panel "console" only pipes text into the bot's
 * stdin (not a real shell) - so a separate npm script can never actually
 * be run there - still get their commands registered, just by starting
 * the bot normally.
 *
 * Registering is a full overwrite (idempotent) and safe to repeat on
 * every boot: unchanged commands are left as-is Discord-side, and it
 * only costs one extra REST call at startup.
 *
 * SINGLE-BOT VERSION: this always deploys the complete command collection
 * using the unified token. After login, client.user.id is the authoritative
 * application ID, so DISCORD_CLIENT_ID is only needed by dashboard OAuth or
 * standalone tooling.
 */
async function autoDeployCommands(client) {
  // Resolve credentials via config.bots[client.botKey] when a botKey is
  // present (multi-bot or legacy mode), otherwise fall back to the unified
  // token and clientId that cover the single Discord application.
  const botConfig = config.bots && client.botKey ? config.bots[client.botKey] : null;
  const token = botConfig?.token || config.token;
  const clientId = client.user?.id || botConfig?.clientId || config.clientId;
  const label = client.botKey ? `[DEPLOY:${client.botKey}]` : '[DEPLOY:unified]';

  if (!clientId) {
    logger.warn(`${label} CLIENT_ID is missing in .env - skipping automatic slash command registration.`);
    return;
  }
  if (!token) {
    logger.warn(`${label} TOKEN is missing in .env - skipping automatic slash command registration.`);
    return;
  }

  try {
    const commands = [...client.commands.values()].map((command) => command.data.toJSON());

    if (!commands.length) {
      logger.warn(`${label} No commands loaded — skipping registration to avoid wiping existing commands.`);
      return;
    }

    const rest = new REST().setToken(token);

    await rest.put(Routes.applicationCommands(clientId), { body: commands });
    logger.success(`${label} Registered ${commands.length} application commands with Discord (global - may take up to an hour to appear the first time).`);
  } catch (error) {
    logger.error(`${label} Failed to auto-register slash commands: ${error?.stack || error}`);
  }
}

module.exports = autoDeployCommands;
