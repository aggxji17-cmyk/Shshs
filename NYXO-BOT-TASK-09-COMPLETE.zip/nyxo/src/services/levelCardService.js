'use strict';

/**
 * TASK16 (Leveling / XP system) - image rendering for /rank and
 * /leaderboard. Reworked in TASK19 to a more "professional" look
 * (diagonal accent panel + full-width progress bar on the rank card,
 * cleaner per-row layout on the leaderboard) and to support the new
 * per-guild card settings (guildConfig.leveling.card - theme /
 * accentColor / progressColor / enabled, see GuildConfig.js).
 *
 * Reuses the @napi-rs/canvas dependency that's already in package.json
 * for services/inventoryRenderService.js instead of adding a new image
 * library, per the task's instructions.
 *
 * The two reference screenshots the task attached (a leaderboard list
 * with a teal progress underline per row, and a single rank card with a
 * diagonal teal panel on the right) were used only to inform the general
 * *idea* - a dark card, one accent color, a clear progress bar, avatar +
 * name + level/xp/rank on one line. Colors, exact proportions, the
 * diagonal-panel construction and the theme system below are original
 * to this project, per the task's explicit "don't copy the reference
 * literally" instruction.
 *
 * Both renderers are defensive on purpose: avatar fetches, font
 * rendering and text measurement are all wrapped so a slow/broken
 * avatar URL, an unusual (long/RTL/emoji-heavy) name, or a missing
 * system font degrades the card instead of throwing, and the calling
 * commands (/rank, /leaderboard) additionally fall back to a plain text
 * embed if image generation fails outright (see commands/leveling/*.js).
 * Nothing in this file touches XP/level/database state - it only reads
 * the numbers it's given and draws pixels.
 */

const axios = require('axios');

const ACCENT_FALLBACK = '#5865F2';
const TEXT_PRIMARY = '#ffffff';
const TEXT_MUTED = '#9aa0aa';

// TASK19: named background presets selectable via
// /levelingconfig card theme (or the dashboard, once wired to this
// system). 'classic' intentionally keeps the exact flat panel this
// service originally shipped with in TASK16, so guilds that don't touch
// the new setting see zero visual change.
const THEMES = {
  classic: { bg: ['#1e1f22', '#1e1f22'], panel: '#2b2d31', track: '#3a3c41' },
  aurora: { bg: ['#151a23', '#1c2733'], panel: '#202a37', track: '#33404f' },
  ember: { bg: ['#20161a', '#2a1a17'], panel: '#302120', track: '#4a332f' },
  forest: { bg: ['#141d19', '#182821'], panel: '#20302a', track: '#33473f' },
};

function resolveTheme(themeName) {
  return THEMES[themeName] || THEMES.aurora;
}

// TASK20: strict 6-digit hex validator for any color that can come from
// a guild's saved settings (guildConfig.leveling.card.accentColor /
// progressColor). commands/settings/leveling.js already rejects bad
// input at save time, but that only covers the slash-command path - a
// value written some other way (dashboard, direct DB edit, an older doc
// from before validation existed) must not be able to crash rendering
// or produce a broken-looking card. Anything that isn't a clean
// `#rrggbb` string is replaced with `fallback` instead of being handed
// to Canvas as-is.
const HEX_COLOR_RE = /^#[0-9a-fA-F]{6}$/;
function safeColor(color, fallback) {
  return typeof color === 'string' && HEX_COLOR_RE.test(color) ? color : fallback;
}

const AVATAR_FETCH_TIMEOUT_MS = 4000;

async function fetchAvatarBuffer(url) {
  if (!url) return null;
  try {
    const res = await axios.get(url, { responseType: 'arraybuffer', timeout: AVATAR_FETCH_TIMEOUT_MS });
    return Buffer.from(res.data);
  } catch {
    return null;
  }
}

function roundRect(ctx, x, y, width, height, radius) {
  const r = Math.min(radius, width / 2, height / 2);
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + width, y, x + width, y + height, r);
  ctx.arcTo(x + width, y + height, x, y + height, r);
  ctx.arcTo(x, y + height, x, y, r);
  ctx.arcTo(x, y, x + width, y, r);
  ctx.closePath();
}

/** Vertical gradient fill for a rect, used for the theme backgrounds. */
function fillVerticalGradient(ctx, x, y, width, height, colorTop, colorBottom) {
  const gradient = ctx.createLinearGradient(x, y, x, y + height);
  gradient.addColorStop(0, colorTop);
  gradient.addColorStop(1, colorBottom);
  ctx.fillStyle = gradient;
  ctx.fillRect(x, y, width, height);
}

async function drawAvatarCircle(ctx, loadImage, avatarBuffer, cx, cy, radius, ringColor, fallbackFill) {
  ctx.save();
  ctx.beginPath();
  ctx.arc(cx, cy, radius + 4, 0, Math.PI * 2);
  ctx.fillStyle = ringColor;
  ctx.fill();
  ctx.restore();

  ctx.save();
  ctx.beginPath();
  ctx.arc(cx, cy, radius, 0, Math.PI * 2);
  ctx.closePath();
  ctx.clip();

  // Defensive: a broken/missing avatar (deleted account, bad URL, fetch
  // timeout - see fetchAvatarBuffer) or a decode failure inside
  // loadImage() must never throw out of card rendering. Both paths fall
  // back to a flat filled circle instead.
  if (avatarBuffer) {
    try {
      const img = await loadImage(avatarBuffer);
      ctx.drawImage(img, cx - radius, cy - radius, radius * 2, radius * 2);
    } catch {
      ctx.fillStyle = fallbackFill;
      ctx.fillRect(cx - radius, cy - radius, radius * 2, radius * 2);
    }
  } else {
    ctx.fillStyle = fallbackFill;
    ctx.fillRect(cx - radius, cy - radius, radius * 2, radius * 2);
  }
  ctx.restore();
}

/**
 * Shrinks `text` (adding an ellipsis) until it fits maxWidth, using the
 * canvas's own text measurement so this is correct regardless of script
 * (Latin, Arabic, CJK, emoji, ...) or font metrics - it never assumes a
 * fixed character width. Handles the empty/whitespace-only case so a
 * blank display name can't produce an endless loop.
 */
function truncateToWidth(ctx, text, maxWidth) {
  const safe = (text ?? '').toString();
  if (!safe.trim()) return 'Unknown';
  if (ctx.measureText(safe).width <= maxWidth) return safe;

  let truncated = safe;
  while (truncated.length > 1 && ctx.measureText(`${truncated}…`).width > maxWidth) {
    truncated = truncated.slice(0, -1);
  }
  return `${truncated}…`;
}

/** Formats a number defensively - never throws on NaN/undefined/null. */
function fmtNum(n) {
  const value = Number(n);
  return Number.isFinite(value) ? value.toLocaleString('en-US') : '0';
}

/**
 * Renders a single member's rank card: avatar + name on the left, a
 * diagonal accent panel with the level on the right, and a full-width
 * progress bar along the bottom (current XP / XP needed for next level).
 *
 * @param {{ username: string, displayName?: string, avatarURL: string, level: number, rank: number,
 *   currentXp: number, xpNeeded: number, totalXp: number, progressPercent: number,
 *   accentColor?: string, progressColor?: string, theme?: string }} data
 * @returns {Promise<Buffer>} PNG buffer
 */
async function renderRankCard(data) {
  const { createCanvas, loadImage } = require('@napi-rs/canvas');
  const accent = safeColor(data.accentColor, ACCENT_FALLBACK);
  const progressFill = safeColor(data.progressColor, accent);
  const theme = resolveTheme(data.theme);

  const width = 940;
  const height = 300;
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');
  const fontFamily = 'sans-serif';

  // Card background + rounded outer clip so every layer below (gradient,
  // diagonal panel, progress bar) respects the same rounded corners.
  roundRect(ctx, 0, 0, width, height, 26);
  ctx.save();
  ctx.clip();
  fillVerticalGradient(ctx, 0, 0, width, height, theme.bg[0], theme.bg[1]);

  // Diagonal accent panel, top-right. This is the one deliberate visual
  // nod to the reference screenshot (a slanted colored block on the
  // right) - everything else about the layout (avatar left, full-width
  // bottom progress bar, single info line) is this project's own.
  const wedgeTopX = width * 0.62;
  ctx.beginPath();
  ctx.moveTo(wedgeTopX, 0);
  ctx.lineTo(width, 0);
  ctx.lineTo(width, height - 70);
  ctx.lineTo(wedgeTopX - 90, height - 70);
  ctx.closePath();
  ctx.fillStyle = accent;
  ctx.fill();

  // Large level number inside the wedge.
  ctx.fillStyle = 'rgba(255,255,255,0.92)';
  ctx.font = `bold 22px ${fontFamily}`;
  ctx.textAlign = 'center';
  ctx.fillText('LEVEL', width * 0.83, 95);
  ctx.font = `bold 74px ${fontFamily}`;
  ctx.fillStyle = TEXT_PRIMARY;
  ctx.fillText(`${Number.isFinite(data.level) ? data.level : 0}`, width * 0.83, 170);
  ctx.textAlign = 'left';

  // Avatar.
  const avatarBuffer = await fetchAvatarBuffer(data.avatarURL);
  const avatarCx = 140;
  const avatarCy = 140;
  const avatarRadius = 78;
  await drawAvatarCircle(ctx, loadImage, avatarBuffer, avatarCx, avatarCy, avatarRadius, accent, theme.panel);

  // Display name (or username if no nickname is set) as the primary,
  // bold line - truncated against the space actually available before
  // the diagonal panel starts, so long names never run under it. When a
  // display name differs from the account's @username (TASK20: "Display
  // Name إذا كان متوفرًا"), the handle is shown as a second, smaller
  // muted line instead of being dropped - only when it actually adds
  // information, so it never wastes a line duplicating the same text.
  const nameX = 250;
  const nameMaxWidth = Math.max(60, wedgeTopX - 120 - nameX);
  const primaryName = data.displayName || data.username || 'Unknown';
  const showHandle = Boolean(data.username) && data.username !== primaryName;

  ctx.fillStyle = TEXT_PRIMARY;
  ctx.font = `bold 38px ${fontFamily}`;
  ctx.textBaseline = 'alphabetic';
  ctx.fillText(truncateToWidth(ctx, primaryName, nameMaxWidth), nameX, 100);

  let infoY = 140;
  if (showHandle) {
    ctx.fillStyle = TEXT_MUTED;
    ctx.font = `20px ${fontFamily}`;
    ctx.fillText(truncateToWidth(ctx, `@${data.username}`, nameMaxWidth), nameX, 126);
    infoY = 158;
  }

  // Info line: Level / XP / Rank - explicit unstyled numbers so it stays
  // legible however extreme the values get (rank #10,000+, eight-digit
  // XP totals, etc).
  ctx.fillStyle = TEXT_MUTED;
  ctx.font = `24px ${fontFamily}`;
  const infoText = `Level ${Number.isFinite(data.level) ? data.level : 0}   •   XP ${fmtNum(data.currentXp)} / ${fmtNum(
    data.xpNeeded
  )}   •   Rank #${data.rank ?? '-'}`;
  ctx.fillText(truncateToWidth(ctx, infoText, nameMaxWidth), nameX, infoY);

  // Full-width progress bar along the bottom.
  const barX = 40;
  const barY = height - 46;
  const barWidth = width - 80;
  const barHeight = 26;

  roundRect(ctx, barX, barY, barWidth, barHeight, barHeight / 2);
  ctx.fillStyle = theme.track;
  ctx.fill();

  const percent = Math.min(100, Math.max(0, Number(data.progressPercent) || 0));
  const fillWidth = Math.max(barHeight, (barWidth * percent) / 100);
  roundRect(ctx, barX, barY, fillWidth, barHeight, barHeight / 2);
  ctx.fillStyle = progressFill;
  ctx.fill();

  ctx.restore(); // release the outer rounded-corner clip

  // Total-XP caption, above the bar.
  ctx.fillStyle = TEXT_MUTED;
  ctx.font = `18px ${fontFamily}`;
  ctx.textAlign = 'right';
  ctx.fillText(`Total XP: ${fmtNum(data.totalXp)}`, width - 40, barY - 10);
  ctx.textAlign = 'left';

  // toBuffer('image/png') is @napi-rs/canvas's proven, synchronous PNG
  // export (matches services/inventoryRenderService.js's existing usage
  // elsewhere in this codebase) rather than any async encode() API.
  return canvas.toBuffer('image/png');
}

/**
 * Renders a top-N leaderboard image: one row per entry with rank badge,
 * avatar, username, level, a thin per-row progress bar, and total XP.
 *
 * @param {{ guildName: string, entries: Array<{
 *   rank: number, username: string, avatarURL: string, level: number,
 *   totalXp: number, progressPercent: number, progressColor?: string }>,
 *   accentColor?: string, theme?: string, page?: number, totalPages?: number }} data
 * @returns {Promise<Buffer>} PNG buffer
 */
async function renderLeaderboardCard(data) {
  const { createCanvas, loadImage } = require('@napi-rs/canvas');
  const accent = safeColor(data.accentColor, ACCENT_FALLBACK);
  const theme = resolveTheme(data.theme);
  // Defensive: entries is expected to be a non-empty array by callers
  // (they check top.length before calling), but a stray null/undefined
  // must not throw here.
  const entries = Array.isArray(data.entries) ? data.entries : [];

  const width = 940;
  const headerHeight = 106;
  const rowHeight = 78;
  const padding = 28;
  const height = headerHeight + Math.max(1, entries.length) * rowHeight + padding;

  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');
  const fontFamily = 'sans-serif';

  roundRect(ctx, 0, 0, width, height, 26);
  ctx.save();
  ctx.clip();
  fillVerticalGradient(ctx, 0, 0, width, height, theme.bg[0], theme.bg[1]);

  // Header.
  ctx.fillStyle = TEXT_PRIMARY;
  ctx.font = `bold 32px ${fontFamily}`;
  const titleMaxWidth = width - padding * 2 - 220;
  ctx.fillText(`🏆  ${truncateToWidth(ctx, data.guildName || 'Leaderboard', titleMaxWidth)}`, padding, 56);
  ctx.fillStyle = TEXT_MUTED;
  ctx.font = `18px ${fontFamily}`;
  const pageLabel =
    data.totalPages && data.totalPages > 1 ? `XP Leaderboard  •  Page ${data.page || 1} / ${data.totalPages}` : 'XP Leaderboard';
  ctx.fillText(pageLabel, padding, 84);

  const medalColors = { 1: '#f1c40f', 2: '#c9ccd1', 3: '#cd7f32' };

  for (let i = 0; i < entries.length; i += 1) {
    const entry = entries[i] || {};
    const rowY = headerHeight + i * rowHeight;
    const rowInnerHeight = rowHeight - 10;

    roundRect(ctx, padding, rowY, width - padding * 2, rowInnerHeight, 16);
    ctx.fillStyle = i % 2 === 0 ? theme.panel : 'rgba(255,255,255,0.02)';
    ctx.fill();

    // Rank badge.
    ctx.fillStyle = medalColors[entry.rank] || TEXT_MUTED;
    ctx.font = `bold 26px ${fontFamily}`;
    ctx.textAlign = 'right';
    ctx.fillText(`#${entry.rank ?? '-'}`, padding + 66, rowY + rowInnerHeight / 2 + 9);
    ctx.textAlign = 'left';

    // Avatar.
    // eslint-disable-next-line no-await-in-loop
    const avatarBuffer = await fetchAvatarBuffer(entry.avatarURL);
    const avatarCx = padding + 118;
    const avatarCy = rowY + rowInnerHeight / 2;
    // eslint-disable-next-line no-await-in-loop
    await drawAvatarCircle(ctx, loadImage, avatarBuffer, avatarCx, avatarCy, 27, accent, theme.panel);

    // Username + level, and a thin progress bar directly under the name
    // (this is the one detail carried over from the leaderboard
    // reference image: a slim underline-style bar per row).
    const textX = padding + 165;
    const barMaxX = width - padding - 150;
    ctx.fillStyle = TEXT_PRIMARY;
    ctx.font = `bold 23px ${fontFamily}`;
    ctx.fillText(truncateToWidth(ctx, entry.username, barMaxX - textX), textX, rowY + 32);

    const miniBarY = rowY + 46;
    const miniBarW = Math.min(260, barMaxX - textX);
    const miniBarH = 8;
    roundRect(ctx, textX, miniBarY, miniBarW, miniBarH, miniBarH / 2);
    ctx.fillStyle = theme.track;
    ctx.fill();
    const percent = Math.min(100, Math.max(0, Number(entry.progressPercent) || 0));
    const fillW = Math.max(miniBarH, (miniBarW * percent) / 100);
    roundRect(ctx, textX, miniBarY, fillW, miniBarH, miniBarH / 2);
    ctx.fillStyle = entry.progressColor && HEX_COLOR_RE.test(entry.progressColor) ? entry.progressColor : accent;
    ctx.fill();

    // Level + total XP, right-aligned.
    ctx.fillStyle = TEXT_MUTED;
    ctx.font = `bold 20px ${fontFamily}`;
    ctx.textAlign = 'right';
    ctx.fillText(`Lvl ${Number.isFinite(entry.level) ? entry.level : 0}`, width - padding, rowY + 32);
    ctx.font = `18px ${fontFamily}`;
    ctx.fillText(`${fmtNum(entry.totalXp)} XP`, width - padding, rowY + 56);
    ctx.textAlign = 'left';
  }

  ctx.restore(); // release the outer rounded-corner clip

  return canvas.toBuffer('image/png');
}

module.exports = { renderRankCard, renderLeaderboardCard, THEMES };
