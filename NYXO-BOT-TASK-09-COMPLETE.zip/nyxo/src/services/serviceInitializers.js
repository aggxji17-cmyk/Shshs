/**
 * Centralized service initializer functions for ready event.
 * Each function returns a Promise that resolves when the service is ready.
 * This decouples service initialization logic from event handlers.
 */

const { startGiveawayScheduler } = require('./giveawayService');
const { startReminderScheduler } = require('./reminderService');
const { startPollScheduler } = require('./pollService');
const { startStreamNotificationPoller } = require('./streamNotificationService');
const { startMemberCountUpdater } = require('./memberCountService');
const { startMinecraftStatusPanelUpdater } = require('./minecraftStatusPanelService');
const { startPendingDeliveryScheduler } = require('./minecraftPendingDeliveryService');
const { cacheGuildInvites } = require('./inviteService');
const { startCaseExpiryScheduler } = require('./caseService');
const { startTicketAutoDeleteScheduler } = require('./ticketCloseService');
const { startScheduler: startModerationScheduler } = require('./scheduleService');
const { restoreTwentyFourSevenSessions } = require('./musicService');
const { initKazagumo } = require('./lavalinkManager');
const { startLinkCodeWatcher } = require('./linkCodeService');
const { startAnnouncementScheduler } = require('./announcementService');
const { startMemberGrowthScheduler } = require('./memberGrowthService');
const { startSmartAlertsScheduler } = require('./smartAlertsService');
const { startVoiceXpScheduler } = require('./voiceXpService');
const logger = require('../utils/logger');

/**
 * Initializes Music bot services.
 * Should only run if the client is the Music bot (botKey unset or 'bot1').
 */
async function initializeMusic(client) {
  try {
    initKazagumo(client);
    await restoreTwentyFourSevenSessions(client);
    logger.success('Music services initialized');
  } catch (err) {
    logger.error(`Failed to initialize music services: ${err?.stack || err}`);
    throw err;
  }
}

/**
 * Initializes Management bot services.
 * Should only run if the client is the Management bot (botKey unset or 'bot2').
 */
async function initializeManagement(client) {
  try {
    startModerationScheduler(client);
    startCaseExpiryScheduler();
    startTicketAutoDeleteScheduler(client);
    logger.success('Management services initialized');
  } catch (err) {
    logger.error(`Failed to initialize management services: ${err?.stack || err}`);
    throw err;
  }
}

/**
 * Initializes Systems bot services.
 * Should only run if the client is the Systems bot (botKey unset or 'bot3').
 */
async function initializeSystems(client) {
  try {
    startGiveawayScheduler(client);
    startReminderScheduler(client);
    startPollScheduler(client);
    startStreamNotificationPoller(client);
    startMemberCountUpdater(client);
    startMinecraftStatusPanelUpdater(client);
    startPendingDeliveryScheduler(client);
    startLinkCodeWatcher(client);
    startAnnouncementScheduler(client);
    startMemberGrowthScheduler(client);
    startSmartAlertsScheduler(client);
    startVoiceXpScheduler(client);

    // Cache guild invites for anti-raid checks
    for (const guild of client.guilds.cache.values()) {
      await cacheGuildInvites(guild).catch((err) =>
        logger.warn(`Initial invite cache failed for ${guild.id}: ${err.message}`)
      );
    }

    logger.success('Systems services initialized');
  } catch (err) {
    logger.error(`Failed to initialize systems services: ${err?.stack || err}`);
    throw err;
  }
}

/**
 * Determines which service initializers should run based on botKey.
 * Returns an object { music, management, systems } with boolean flags.
 */
function getServiceTargets(botKey) {
  // If botKey is unset (unified single client), all services should initialize
  const isBot1Music = !botKey || botKey === 'bot1';
  const isBot2Management = !botKey || botKey === 'bot2';
  const isBot3Systems = !botKey || botKey === 'bot3';

  return { isBot1Music, isBot2Management, isBot3Systems };
}

/**
 * Initializes all applicable services for the given client.
 * Wraps individual service initializers with logging and error handling.
 */
async function initializeServicesForClient(client) {
  const botKey = client.botKey;
  const targets = getServiceTargets(botKey);

  const results = {
    success: [],
    failed: [],
  };

  if (targets.isBot1Music) {
    try {
      await initializeMusic(client);
      results.success.push('Music');
    } catch (err) {
      results.failed.push({ service: 'Music', error: err?.message || err });
    }
  }

  if (targets.isBot2Management) {
    try {
      await initializeManagement(client);
      results.success.push('Management');
    } catch (err) {
      results.failed.push({ service: 'Management', error: err?.message || err });
    }
  }

  if (targets.isBot3Systems) {
    try {
      await initializeSystems(client);
      results.success.push('Systems');
    } catch (err) {
      results.failed.push({ service: 'Systems', error: err?.message || err });
    }
  }

  // Log results
  if (results.success.length > 0) {
    logger.success(`Initialized service groups: ${results.success.join(', ')}`);
  }
  if (results.failed.length > 0) {
    for (const { service, error } of results.failed) {
      logger.error(`${service} services failed: ${error}`);
    }
  }

  return results;
}

module.exports = {
  initializeMusic,
  initializeManagement,
  initializeSystems,
  getServiceTargets,
  initializeServicesForClient,
};
