const UserLevel = require('../database/models/UserLevel');

/**
 * TASK16 (Leveling / XP system)
 * ---------------------------------------------------------------------
 * This is the ONE place the XP <-> Level curve lives (per spec: "صمم
 * معادلة Leveling قابلة للتعديل من مكان واحد. لا تضع أرقام ومعادلات
 * موزعة في عدة ملفات."). Every command/event that needs level math
 * (messageCreate's handleLeveling, /rank, /leaderboard, the rank-card
 * renderer) calls into the helpers below instead of recomputing XP
 * thresholds itself.
 */

/**
 * XP required to go from `level` to `level + 1`. Quadratic curve so
 * early levels come quickly and later levels take progressively longer -
 * same shape as before, kept unchanged so nobody's existing progress
 * shifts levels when this task ships.
 */
function xpForLevel(level) {
  return 5 * level ** 2 + 50 * level + 100;
}

/** Total cumulative XP needed to reach `level` from 0. */
function totalXpForLevel(level) {
  let total = 0;
  for (let l = 0; l < level; l += 1) total += xpForLevel(l);
  return total;
}

function levelFromXp(xp) {
  let level = 0;
  let remaining = xp;
  while (remaining >= xpForLevel(level)) {
    remaining -= xpForLevel(level);
    level += 1;
  }
  return level;
}

/**
 * Full breakdown for a given total XP value - level, XP within the
 * current level, XP needed for the next level, and progress percentage.
 * Used by /rank, /leaderboard and the rank-card image so none of them
 * duplicate this math themselves.
 */
function getLevelProgress(totalXp) {
  const xp = Math.max(0, totalXp || 0);
  const level = levelFromXp(xp);
  const xpAtLevelStart = totalXpForLevel(level);
  const xpNeeded = xpForLevel(level);
  const currentXp = xp - xpAtLevelStart;
  const progressPercent = xpNeeded > 0 ? Math.min(100, Math.max(0, (currentXp / xpNeeded) * 100)) : 0;
  return { level, currentXp, xpNeeded, totalXp: xp, progressPercent };
}

function randomInt(min, max) {
  const lo = Math.min(min, max);
  const hi = Math.max(min, max);
  return Math.floor(Math.random() * (hi - lo + 1)) + lo;
}

/**
 * Resolves the XP-per-message range a guild should use, falling back to
 * a +/-20% band around the legacy single `xpPerMessage` value for guild
 * docs saved before xpMin/xpMax existed (see GuildConfig.js leveling
 * schema comment).
 */
function resolveXpRange(levelingConfig) {
  if (Number.isFinite(levelingConfig?.xpMin) && Number.isFinite(levelingConfig?.xpMax) && levelingConfig.xpMax > 0) {
    return { min: Math.max(1, levelingConfig.xpMin), max: Math.max(1, levelingConfig.xpMax) };
  }
  const base = levelingConfig?.xpPerMessage > 0 ? levelingConfig.xpPerMessage : 15;
  const min = Math.max(1, Math.round(base * 0.8));
  const max = Math.max(min, Math.round(base * 1.2));
  return { min, max };
}

/**
 * TASK25: resolves the XP multiplier a member should get for their next
 * XP grant, from `leveling.xpMultipliers` (see GuildConfig.js). When a
 * member qualifies for more than one configured role, the *highest*
 * multiplier applies (not stacked/multiplied together) - the same
 * "best one wins" rule already used for level rewards spanning a range
 * is intentionally NOT used here since multipliers compound very
 * differently than one-time role grants; a flat "best wins" keeps the
 * result predictable for admins configuring more than one tier (e.g.
 * Booster = 1.5x, VIP = 2x -> a Boosting VIP gets 2x, not 3x).
 *
 * Defensive by design: a missing/malformed multiplier list, a
 * non-finite or non-positive `multiplier` value, or a member with no
 * roles all safely resolve to 1 (no change in XP) instead of throwing
 * or silently zeroing someone's XP out.
 *
 * @param {import('discord.js').GuildMember|null|undefined} member
 * @param {object} levelingConfig guildConfig.leveling
 * @returns {number}
 */
function getXpMultiplier(member, levelingConfig) {
  const multipliers = levelingConfig?.xpMultipliers;
  if (!member?.roles?.cache || !Array.isArray(multipliers) || !multipliers.length) return 1;

  let best = 1;
  for (const entry of multipliers) {
    const value = Number(entry?.multiplier);
    if (!entry?.roleId || !Number.isFinite(value) || value <= 0) continue;
    if (member.roles.cache.has(entry.roleId) && value > best) best = value;
  }
  return best;
}

/**
 * Applies a multiplier to an { min, max } XP range, rounding each bound
 * and always keeping min >= 1 so a fractional/very small multiplier can
 * never produce a 0-XP grant (which would look like a bug rather than a
 * deliberately small reward).
 *
 * @param {{min:number,max:number}} range
 * @param {number} multiplier
 * @returns {{min:number,max:number}}
 */
function applyXpMultiplier(range, multiplier) {
  if (!Number.isFinite(multiplier) || multiplier === 1) return range;
  const min = Math.max(1, Math.round(range.min * multiplier));
  const max = Math.max(min, Math.round(range.max * multiplier));
  return { min, max };
}

/**
 * In-memory per-user cooldown cache, keyed by `guildId:userId`, holding
 * the timestamp (ms) each user is next eligible for XP. This is a *fast
 * local skip layer* only - it lets the overwhelming majority of messages
 * sent by someone already on cooldown (i.e. normal chatting/spam) never
 * touch MongoDB at all, per spec ("عدم عمل MongoDB write لكل رسالة بشكل
 * غير ضروري ... باستخدام cache"). It intentionally is NOT the source of
 * truth: grantMessageXp()'s atomic Mongo update below is what actually
 * decides whether XP is granted, so a cold cache (process restart,
 * multiple bot processes/shards) never causes double XP - it can only
 * ever cause one extra (harmless) DB round trip that Mongo itself then
 * correctly rejects. This is why a plain Map is safe here instead of
 * needing a distributed cache.
 *
 * Cleared with a single periodic sweep instead of a per-user/per-message
 * timer, per spec ("لا تستخدم setTimeout لكل مستخدم", "لا تنشئ Timer
 * لكل رسالة").
 */
const cooldownCache = new Map();
const CACHE_SWEEP_INTERVAL_MS = 5 * 60 * 1000;

setInterval(() => {
  const now = Date.now();
  for (const [key, expiresAt] of cooldownCache) {
    if (expiresAt <= now) cooldownCache.delete(key);
  }
}, CACHE_SWEEP_INTERVAL_MS).unref?.();

/**
 * TASK26 (Voice XP): shared level-up commit step, factored out of
 * grantMessageXp's body (behavior is byte-for-byte identical to what
 * grantMessageXp already did inline) so grantVoiceXp() below can reuse
 * the exact same optimistic-concurrency guarantee instead of a second,
 * slightly-different copy of it.
 *
 * Given the pre-grant xp/level a caller already has (from its own atomic
 * $inc's `new: false` pre-image) and the amount just added, decides
 * whether that crossed a level boundary and, if so, commits the new
 * level with a `level: previousLevel` guard in the query - this is what
 * makes a level-up land exactly once even when TWO DIFFERENT XP sources
 * for the same member race each other, e.g. a chat message and a
 * completed voice-XP interval resolving in the same instant. Whichever
 * caller's findOneAndUpdate matches first "wins" the announcement/reward
 * grant for that level; the other's `claimed` comes back null (its
 * previousLevel no longer matches - the first caller already moved it)
 * and it silently backs off - so a member can never receive the same
 * level-up (or its rewards) twice no matter which XP source pushed them
 * over, and this is true whether both grants are message+message,
 * voice+voice, or message+voice.
 */
async function commitLevelUpIfNeeded(guildId, userId, previousXp, previousLevel, xpAmount) {
  const newXp = previousXp + xpAmount;
  const newLevel = levelFromXp(newXp);

  if (newLevel === previousLevel) {
    return { leveledUp: false, xpGained: xpAmount, totalXp: newXp };
  }

  const claimed = await UserLevel.findOneAndUpdate(
    { guildId, userId, level: previousLevel },
    { $set: { level: newLevel } },
    { new: true }
  );
  if (claimed) {
    // previousLevel is included (TASK18) so callers can grant every
    // level-reward the member passed through, not only one matching
    // newLevel exactly - see services/levelRewardService.js.
    return { leveledUp: true, newLevel, previousLevel, xpGained: xpAmount, totalXp: newXp };
  }

  return { leveledUp: false, xpGained: xpAmount, totalXp: newXp };
}

/**
 * Awards XP to a user for sending a message, respecting a per-user
 * cooldown, with no read-modify-write race window:
 *
 *  1. Fast path: if the in-memory cache says this user is still on
 *     cooldown, bail out immediately - zero DB calls.
 *  2. Otherwise issue ONE atomic findOneAndUpdate whose *query* embeds
 *     the cooldown check itself (lastMessageAt missing or older than the
 *     cutoff) alongside the $inc for xp/messages. MongoDB only matches
 *     and updates a document that satisfies that condition, so two
 *     messages from the same user racing each other can never both
 *     succeed - the second one's query simply won't match the document
 *     the first one already updated (single-document ops are atomic in
 *     MongoDB, so there is no read-then-write gap for either request).
 *  3. If no existing document matches (user's first message ever, or
 *     currently on cooldown) upsert:true tries to insert a new one.
 *     When the user is actually on cooldown this collides with the
 *     unique (guildId, userId) index and throws E11000 - caught below
 *     and treated as "no XP this time", with no data ever written.
 *  4. Level-up detection: previousLevel is read from the *pre-update*
 *     document (new:false), which needs no second query, and the actual
 *     level bump is committed via the shared commitLevelUpIfNeeded()
 *     helper above - an optimistic-concurrency guard that makes the
 *     transition succeed for exactly one caller even under concurrent
 *     messages (or a concurrent voice-XP grant - see that helper's own
 *     doc comment), so a level-up is never announced twice and the
 *     stored `level` field only gets a write when it truly changes.
 *
 * @param {string} guildId
 * @param {string} userId
 * @param {{min:number,max:number}|number} xpRangeOrAmount
 * @param {number} cooldownSeconds
 * @returns {Promise<{leveledUp: boolean, newLevel?: number, xpGained?: number, totalXp?: number}>}
 */
async function grantMessageXp(guildId, userId, xpRangeOrAmount, cooldownSeconds) {
  const cacheKey = `${guildId}:${userId}`;
  const now = Date.now();

  const cachedExpiry = cooldownCache.get(cacheKey);
  if (cachedExpiry && cachedExpiry > now) {
    return { leveledUp: false };
  }

  const { min, max } =
    typeof xpRangeOrAmount === 'object' && xpRangeOrAmount !== null
      ? xpRangeOrAmount
      : { min: xpRangeOrAmount, max: xpRangeOrAmount };
  const xpAmount = randomInt(min, max);
  const nowDate = new Date(now);
  const cutoff = new Date(now - cooldownSeconds * 1000);

  let previous;
  try {
    previous = await UserLevel.findOneAndUpdate(
      { guildId, userId, $or: [{ lastMessageAt: null }, { lastMessageAt: { $lt: cutoff } }] },
      { $inc: { xp: xpAmount, messages: 1 }, $set: { lastMessageAt: nowDate }, $setOnInsert: { level: 0 } },
      { upsert: true, new: false }
    );
  } catch (err) {
    // E11000 here means the doc exists but didn't match the cooldown
    // condition above - i.e. the user really is still on cooldown.
    if (err?.code === 11000) {
      cooldownCache.set(cacheKey, now + cooldownSeconds * 1000);
      return { leveledUp: false };
    }
    throw err;
  }

  cooldownCache.set(cacheKey, now + cooldownSeconds * 1000);

  const previousXp = previous?.xp || 0;
  const previousLevel = previous?.level ?? 0;
  return commitLevelUpIfNeeded(guildId, userId, previousXp, previousLevel, xpAmount);
}

/**
 * TASK26 (Voice XP): grants XP for one completed voice-XP interval,
 * into the exact same UserLevel document message XP uses - there is no
 * separate voice collection/model, so "Total XP" is always message XP +
 * voice XP by construction (both just $inc the same `xp` field).
 *
 * Deliberately simpler than grantMessageXp above:
 *  - No cooldown query/cache here. All eligibility (feature enabled,
 *    excluded channel/role, alone-or-bots-only, AFK channel, join/leave
 *    farming) is decided by the caller (services/voiceXpService.js)
 *    BEFORE this is ever called - by the time this runs, "grant this
 *    member one interval's worth of XP right now" has already been
 *    decided, so there is nothing left for this function to gate.
 *  - Still a single atomic findOneAndUpdate (upsert so a member's first
 *    ever XP can come from voice, not just messages) - no
 *    find()-then-modify()-then-save() read-modify-write gap, matching
 *    the same race-safety grantMessageXp already guarantees.
 *  - Reuses commitLevelUpIfNeeded() above for the level-up compare/claim
 *    step, so a voice-XP interval and a chat message landing at the same
 *    moment can never double-announce or double-grant a level's rewards
 *    (see that function's doc comment).
 *
 * @param {string} guildId
 * @param {string} userId
 * @param {number} xpAmount Already-resolved amount for this interval (base voiceXpPerMinute * multiplier) - must be a positive integer.
 * @returns {Promise<{leveledUp: boolean, newLevel?: number, previousLevel?: number, xpGained?: number, totalXp?: number}>}
 */
async function grantVoiceXp(guildId, userId, xpAmount) {
  const amount = Math.max(0, Math.floor(Number(xpAmount) || 0));
  if (amount <= 0) return { leveledUp: false, xpGained: 0 };

  const previous = await UserLevel.findOneAndUpdate(
    { guildId, userId },
    { $inc: { xp: amount, voiceMinutes: 1 }, $setOnInsert: { level: 0, messages: 0, lastMessageAt: null } },
    { upsert: true, new: false }
  );

  const previousXp = previous?.xp || 0;
  const previousLevel = previous?.level ?? 0;
  return commitLevelUpIfNeeded(guildId, userId, previousXp, previousLevel, amount);
}

/**
 * Top-N leaderboard entries, sorted and paginated entirely in MongoDB
 * (uses the { guildId: 1, xp: -1 } index) - never pulls the full guild
 * member list into Node just to sort/slice it there.
 */
async function getLeaderboard(guildId, limit = 10, skip = 0) {
  return UserLevel.find({ guildId }).sort({ xp: -1 }).skip(skip).limit(limit).lean();
}

async function getGuildUserCount(guildId) {
  return UserLevel.countDocuments({ guildId });
}

/**
 * A user's rank is `1 + (how many users in this guild have more XP)` -
 * computed with a single indexed countDocuments() rather than loading
 * and sorting every member.
 */
async function getRank(guildId, userId) {
  const doc = await UserLevel.findOne({ guildId, userId }).lean();
  if (!doc) return null;
  const higherCount = await UserLevel.countDocuments({ guildId, xp: { $gt: doc.xp } });
  return { doc, rank: higherCount + 1 };
}

// TASK29: upper bound for any single XP value written directly (i.e. not
// accumulated one small grant at a time by grantMessageXp/grantVoiceXp -
// see below). levelFromXp()/totalXpForLevel() are both O(level) loops;
// normal XP growth is naturally self-limiting (a handful of XP per
// message/minute, gated by cooldown/session), but /levelingconfig
// member set-xp|add-xp accepts an admin-typed integer with no such
// natural ceiling. An arbitrarily large value (e.g. a typo with extra
// zeros) would make levelFromXp()/totalXpForLevel() loop millions of
// times synchronously on every single /rank or /leaderboard call from
// then on - not a crash, but a real, easily-triggered performance cliff
// on the bot's single event loop. 1 billion XP is already far beyond any
// value a real member could ever accumulate (at 15 XP/message with zero
// cooldown that's still ~185 years of nonstop messages) while keeping
// levelFromXp()'s loop in the tens-of-thousands range - i.e. sub-millisecond.
const MAX_ADMIN_XP = 1_000_000_000;

/**
 * TASK25: manual XP administration for /levelingconfig member
 * set-xp|add-xp|reset (commands/settings/leveling.js). Distinct from
 * grantMessageXp() above on purpose:
 *
 *  - It is an infrequent admin action (fixing an exploit, correcting a
 *    mistake, seeding a migrated member's XP), not a hot per-message
 *    path, so it doesn't need the cooldown cache or the upsert/E11000
 *    dance grantMessageXp() uses to survive thousands of concurrent
 *    messages/sec.
 *  - It deliberately does NOT call into levelRewardService or fire a
 *    level-up announcement. Message-based leveling stays the single
 *    place those side effects happen, so an admin correcting someone's
 *    XP can never trigger a duplicate role grant or an announcement
 *    that reads like the member just leveled up from chatting. If an
 *    admin wants the reward role too, /levelreward + manually adding
 *    the role (or just letting the member's next qualifying message
 *    trigger it normally, since grantLevelRewards grants every reward
 *    in (previousLevel, newLevel]) still works.
 *
 * Every write still goes through a single findOneAndUpdate (upsert for
 * set/add so a member with no prior XP doc can be seeded directly) and
 * recomputes `level` from the resulting `xp` via levelFromXp(), so the
 * cached level field can never drift out of sync with xp the way it
 * would if a caller set them independently.
 */
async function setUserXp(guildId, userId, xp) {
  // TASK29: clamp to [0, MAX_ADMIN_XP] - see that constant's comment.
  // Defensive here (not just at the slash-command option level) so any
  // future/other caller of this function can't bypass the ceiling either.
  const safeXp = Math.min(MAX_ADMIN_XP, Math.max(0, Math.floor(Number(xp) || 0)));
  const level = levelFromXp(safeXp);
  const doc = await UserLevel.findOneAndUpdate(
    { guildId, userId },
    { $set: { xp: safeXp, level }, $setOnInsert: { messages: 0, lastMessageAt: null } },
    { upsert: true, new: true }
  );
  return { doc, level };
}

async function addUserXp(guildId, userId, delta) {
  const change = Math.floor(Number(delta) || 0);
  const existing = await UserLevel.findOne({ guildId, userId }).lean();
  const newXp = Math.max(0, (existing?.xp || 0) + change);
  return setUserXp(guildId, userId, newXp);
}

async function resetUserXp(guildId, userId) {
  return setUserXp(guildId, userId, 0);
}

module.exports = {
  xpForLevel,
  totalXpForLevel,
  levelFromXp,
  getLevelProgress,
  resolveXpRange,
  getXpMultiplier,
  applyXpMultiplier,
  grantMessageXp,
  grantVoiceXp,
  getLeaderboard,
  getGuildUserCount,
  getRank,
  setUserXp,
  addUserXp,
  resetUserXp,
  MAX_ADMIN_XP,
};
