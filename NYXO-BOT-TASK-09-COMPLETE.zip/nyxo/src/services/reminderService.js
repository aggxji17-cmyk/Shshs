const Reminder = require('../database/models/Reminder');
const { baseEmbed } = require('../utils/embeds');
const { resolved } = require('../utils/resolveGuildSettings');
const logger = require('../utils/logger');

const POLL_INTERVAL_MS = 15_000;

async function deliverReminder(client, reminder) {
  const channel = await client.channels.fetch(reminder.channelId).catch(() => null);
  const settings = resolved({});
  const embed = baseEmbed(settings)
    .setTitle('⏰ Reminder')
    .setDescription(reminder.message)
    .addFields({ name: 'Set', value: `<t:${Math.floor(reminder.createdAt.getTime() / 1000)}:R>` });

  if (channel) {
    await channel.send({ content: `<@${reminder.userId}>`, embeds: [embed] }).catch(async (err) => {
      logger.warn(`Reminder: channel send failed (channel ${reminder.channelId}): ${err?.message || err} — falling back to DM`);
      const user = await client.users.fetch(reminder.userId).catch(() => null);
      await user?.send({ embeds: [embed] }).catch((dmErr) => {
        logger.warn(`Reminder: DM fallback also failed for user ${reminder.userId}: ${dmErr?.message || dmErr}`);
      });
    });
  } else {
    logger.warn(`Reminder: channel ${reminder.channelId} not found — attempting DM fallback for user ${reminder.userId}`);
    const user = await client.users.fetch(reminder.userId).catch(() => null);
    await user?.send({ embeds: [embed] }).catch((dmErr) => {
      logger.warn(`Reminder: DM fallback failed for user ${reminder.userId}: ${dmErr?.message || dmErr}`);
    });
  }
}

function startReminderScheduler(client) {
  // TASK 19 — overlap guard. A plain setInterval let a slow tick (many
  // reminders, each needing a Discord API round trip) still be running
  // when the next tick fired; that next tick's find({ sent: false, ... })
  // could re-fetch reminders the in-progress tick hadn't reached/saved yet,
  // delivering the same reminder twice. Same fix shape as scheduleService's
  // self-guarding loop.
  let running = false;
  setInterval(async () => {
    if (running) return;
    running = true;
    try {
      const due = await Reminder.find({ sent: false, remindAt: { $lte: new Date() } }).limit(50);
      for (const reminder of due) {
        reminder.sent = true;
        await reminder.save();
        await deliverReminder(client, reminder);
      }
    } catch (err) {
      logger.error(`Reminder scheduler error: ${err.stack || err}`);
    } finally {
      running = false;
    }
  }, POLL_INTERVAL_MS);
}

module.exports = { startReminderScheduler };
