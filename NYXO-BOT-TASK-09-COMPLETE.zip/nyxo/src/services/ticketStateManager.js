/**
 * TASK 08 — Ticket State Manager
 * =================================================================
 * طبقة مركزية لتعريف وتغيير حالات التذكرة. لا تُغيّر أي سلوك تجاري -
 * كل دالة هنا تطبّق بالضبط نفس التعيينات التي كانت موجودة سابقاً في
 * ticketCloseService.js وbuttons.js، لكن من مكان واحد بدل تكرارها.
 *
 * هذه المهمة لا تحفظ في قاعدة البيانات ولا تتصل بـDiscord: كل دالة هنا
 * "نقية" (pure) - تستقبل مستند تذكرة (Mongoose document أو أي كائن) وتُعدّل
 * حقوله في الذاكرة فقط، ثم تُرجعه. الحفظ (`ticket.save()`) والتزامن مع
 * Discord (rename/lock) يبقيان مسؤولية المتصل، تماماً كما كانا قبل هذه
 * المهمة - فقط منطق "أي حقول تتغيّر ولماذا" أصبح موحّداً هنا. توحيد
 * الاستخدام الفعلي عبر كل الملفات (claim, status toggle, إلخ) هو مهمة 09.
 *
 * =================================================================
 * تعريف الحالات (يطابق database/models/Ticket.js تماماً)
 * =================================================================
 *
 * TICKET_STATUS  — دورة حياة التذكرة الأساسية:
 *   'open'     - مفتوحة، لم يستلمها أحد بعد.
 *   'claimed'  - مفتوحة واستلمها موظف (claimedBy).
 *   'closed'   - مغلقة؛ القناة ما زالت موجودة ومقفلة بانتظار حذف/إعادة فتح.
 *
 * CLOSE_STATUS  — حالة العد التنازلي للحذف التلقائي (فقط أثناء status=closed):
 *   'pending_delete' (🔵) - أُغلقت للتو، الحذف التلقائي لم يقترب بعد.
 *   'near_delete'    (🔴) - اقترب موعد الحذف التلقائي (warningMinutes).
 *   null                  - لا يوجد عدّ تنازلي نشط (مفتوحة/معاد فتحها/محذوفة نهائياً).
 *
 * REPLY_STATUS  — من عليه الرد (مستقل عن status، يظهر في اسم القناة):
 *   'needs_reply' (🟡) - صاحب التذكرة أرسل آخر رسالة وينتظره الموظفون.
 *   'no_action'   (🟢) - الموظفون (أو لا أحد) لديهم الدور الآن.
 *
 * LAST_MESSAGE_BY — من أرسل آخر رسالة مؤهلة لتتبع النشاط (TASK33):
 *   'user' | 'staff' | null
 *
 * =================================================================
 */

const TICKET_STATUS = Object.freeze({
  OPEN: 'open',
  CLAIMED: 'claimed',
  CLOSED: 'closed',
});

const CLOSE_STATUS = Object.freeze({
  PENDING_DELETE: 'pending_delete',
  NEAR_DELETE: 'near_delete',
  NONE: null,
});

const REPLY_STATUS = Object.freeze({
  NEEDS_REPLY: 'needs_reply',
  NO_ACTION: 'no_action',
});

const LAST_MESSAGE_BY = Object.freeze({
  USER: 'user',
  STAFF: 'staff',
  NONE: null,
});

/**
 * ينقل تذكرة إلى closed. يطابق تماماً ما كان closeTicket() في
 * ticketCloseService.js يفعله يدوياً قبل هذه المهمة (سطراً بسطر).
 * لا يرسل أي رسالة Discord ولا يحفظ - فقط يُعدّل الحقول.
 *
 * @param {object} ticket مستند التذكرة (سيُعدَّل في الذاكرة).
 * @param {object} opts
 * @param {string} opts.closedById - آيدي من أغلق التذكرة.
 * @param {Date|null} opts.autoDeleteAt - موعد الحذف التلقائي، أو null لتعطيله.
 * @param {string|null} [opts.closeStatus] - يُحسب تلقائياً من autoDeleteAt إن لم يُمرَّر.
 * @param {string|null} [opts.baseChannelName] - اسم القناة بدون بادئة الحالة.
 * @returns {object} نفس التذكرة بعد التعديل.
 */
function applyClosed(ticket, { closedById, autoDeleteAt, closeStatus, baseChannelName } = {}) {
  ticket.status = TICKET_STATUS.CLOSED;
  ticket.closedBy = closedById ?? null;
  ticket.closedAt = new Date();
  // Task 5: يبقى isOpen متزامناً مع status حتى يتحرر مكان العضو في
  // الفهرس الفريد (تذكرة نشطة واحدة لكل عضو).
  ticket.isOpen = false;
  ticket.autoDeleteAt = autoDeleteAt ?? null;
  ticket.closeStatus = closeStatus !== undefined ? closeStatus : (autoDeleteAt ? CLOSE_STATUS.PENDING_DELETE : CLOSE_STATUS.NONE);
  if (baseChannelName) ticket.baseChannelName = baseChannelName;
  return ticket;
}

/**
 * يعيد فتح تذكرة مغلقة. يطابق reopenTicket() الحالي في
 * ticketCloseService.js بالضبط - بما في ذلك تصفير كامل مسار
 * النشاط/التذكير (TASK32/TASK33) حتى لا تُطلق تذكيرات خاطئة بعد إعادة الفتح.
 *
 * @param {object} ticket
 * @param {string} reopenedById
 * @returns {object} نفس التذكرة بعد التعديل.
 */
function applyReopened(ticket, reopenedById) {
  ticket.status = ticket.claimedBy ? TICKET_STATUS.CLAIMED : TICKET_STATUS.OPEN;
  ticket.closedBy = null;
  ticket.closedAt = null;
  ticket.autoDeleteAt = null;
  ticket.closeStatus = CLOSE_STATUS.NONE;
  ticket.reopenedBy = reopenedById;
  ticket.reopenedAt = new Date();
  // Task 5: يستعيد isOpen حجز مكان العضو في الفهرس الفريد.
  ticket.isOpen = true;

  // TASK33: تصفير كامل أثر النشاط/التذكير - نفس منطق تذكرة جديدة تماماً،
  // لمنع تذكير "الموظف ينتظر" خاطئ فور إعادة الفتح.
  ticket.lastStaffMessageAt = null;
  ticket.lastUserMessageAt = null;
  ticket.lastActivityAt = null;
  ticket.lastMessageBy = LAST_MESSAGE_BY.NONE;
  ticket.reminderSentAt = null;

  return ticket;
}

/**
 * يستدعيه المُتصل بعد فشل إعادة الفتح بسبب تعارض الفهرس الفريد (كود
 * MongoDB 11000) - يعيد التذكرة في الذاكرة إلى حالتها المغلقة الحقيقية
 * كي لا يرى المستدعي حالة "open/claimed" وهمية لم تُحفظ فعلياً.
 */
function rollbackReopenConflict(ticket) {
  ticket.status = TICKET_STATUS.CLOSED;
  ticket.isOpen = false;
  return ticket;
}

/**
 * يُعلّم التذكرة كمحذوفة نهائياً - يطابق ما يفعله finalizeTicketDeletion()
 * على المستند في الذاكرة بعد نجاح findOneAndUpdate الذرّي.
 */
function applyPermanentlyDeleted(ticket, permanentlyDeletedAt) {
  ticket.autoDeleteAt = null;
  ticket.closeStatus = CLOSE_STATUS.NONE;
  ticket.permanentlyDeletedAt = permanentlyDeletedAt;
  return ticket;
}

/** يُحدّث فقط مؤشر حالة الحذف المرحلي (🔵 pending_delete → 🔴 near_delete) دون لمس status. */
function applyCloseStatus(ticket, closeStatus) {
  ticket.closeStatus = closeStatus;
  return ticket;
}

/** يُبدّل بين needs_reply/no_action - نفس ما يفعله زر تبديل الحالة ورسائل messageCreate.js حالياً. */
function applyReplyStatus(ticket, replyStatus) {
  ticket.replyStatus = replyStatus;
  return ticket;
}

/**
 * يُسجّل استلام تذكرة (claim). لا يغيّر شيئاً غير claimedBy/status - يُبقي
 * على نفس السلوك الحالي في buttons.js دون تعديل الـAtomic Update نفسه
 * (findOneAndUpdate) الذي يبقى مسؤولية المتصل لمنع استلام تذكرة من موظفَين
 * في آنٍ واحد (سيُغطّى بمهمة 16).
 */
function applyClaimed(ticket, claimedById) {
  ticket.status = TICKET_STATUS.CLAIMED;
  ticket.claimedBy = claimedById;
  return ticket;
}

/**
 * يُسجّل أثر رسالة مؤهلة (من صاحب التذكرة أو من موظف) على حقول النشاط/
 * التذكير - يطابق تماماً منطق handleTicketStatusUpdate في
 * events/message/messageCreate.js (TASK32/TASK33) دون أي تغيير سلوكي:
 * كل رسالة تُحدّث lastActivityAt/lastMessageBy، ورسالة الموظف تُصفّر نافذة
 * التذكير بينما رسالة صاحب التذكرة تصفّرها فقط إن كانت هناك نافذة انتظار
 * سابقة.
 *
 * @param {object} ticket
 * @param {'user'|'staff'} speaker
 * @param {Date} messageCreatedAt
 */
function applyActivity(ticket, speaker, messageCreatedAt) {
  ticket.lastActivityAt = messageCreatedAt;
  ticket.lastMessageBy = speaker;

  if (speaker === LAST_MESSAGE_BY.STAFF) {
    ticket.lastStaffMessageAt = messageCreatedAt;
    ticket.reminderSentAt = null;
  } else {
    ticket.lastUserMessageAt = messageCreatedAt;
    if (ticket.lastStaffMessageAt || ticket.reminderSentAt) {
      ticket.lastStaffMessageAt = null;
      ticket.reminderSentAt = null;
    }
  }
  return ticket;
}

module.exports = {
  TICKET_STATUS,
  CLOSE_STATUS,
  REPLY_STATUS,
  LAST_MESSAGE_BY,
  applyClosed,
  applyReopened,
  rollbackReopenConflict,
  applyPermanentlyDeleted,
  applyCloseStatus,
  applyReplyStatus,
  applyClaimed,
  applyActivity,
};
