const { ChannelType } = require('discord.js');
const { sendModLog } = require('../utils/modLog');

// guildId -> array of join timestamps (ms) within the tracking window
const joinTimestamps = new Map();
// guildId -> array of GuildMember objects within the tracking window (for kick/ban on raid detection)
const joinMembers = new Map();
// guildId -> true while a raid lockdown triggered by this service is active
const activeLockdowns = new Set();

/**
 * Records a join and checks whether it pushed the guild over its configured
 * burst threshold. Returns true if a raid was just detected (and handled)
 * on this call, so the caller can avoid double-processing later joins that
 * arrive while a lockdown is already active.
 */
async function recordJoinAndCheckRaid(member, guildConfig, settings) {
  if (!guildConfig.antiRaid?.enabled) return false;
  if (activeLockdowns.has(member.guild.id)) return true; // already mid-raid-response

  const now = Date.now();
  const windowMs = guildConfig.antiRaid.windowMs;
  const list = (joinTimestamps.get(member.guild.id) || []).filter((t) => now - t < windowMs);
  list.push(now);
  joinTimestamps.set(member.guild.id, list);

  // Track member objects for kick/ban action (parallel to timestamps)
  const mList = (joinMembers.get(member.guild.id) || []).filter((_, i) => i < list.length - 1);
  mList.push(member);
  joinMembers.set(member.guild.id, mList);

  if (list.length < guildConfig.antiRaid.joinThreshold) return false;

  await triggerRaidResponse(member.guild, guildConfig, settings, list.length, joinMembers.get(member.guild.id) || []);
  return true;
}

const LOCKDOWN_AUTO_CLEAR_MS = 10 * 60 * 1000;

async function triggerRaidResponse(guild, guildConfig, settings, joinCount, raidMembers = []) {
  activeLockdowns.add(guild.id);
  setTimeout(() => clearLockdown(guild.id), LOCKDOWN_AUTO_CLEAR_MS).unref?.();

  if (guildConfig.antiRaid.action === 'lockdown') {
    const textChannels = guild.channels.cache.filter((c) => c.type === ChannelType.GuildText);
    for (const channel of textChannels.values()) {
      await channel.permissionOverwrites.edit(guild.roles.everyone, { SendMessages: false }).catch(() => null);
    }
  } else if (guildConfig.antiRaid.action === 'kick') {
    for (const raidMember of raidMembers) {
      if (raidMember.kickable) {
        await raidMember.kick('Anti-raid: suspicious burst of joins detected').catch(() => null);
      }
    }
  } else if (guildConfig.antiRaid.action === 'ban') {
    for (const raidMember of raidMembers) {
      if (raidMember.bannable) {
        await guild.members.ban(raidMember.id, { reason: 'Anti-raid: suspicious burst of joins detected' }).catch(() => null);
      }
    }
  }

  await sendModLog(guild, guildConfig, settings, {
    title: '🚨 Raid Detected',
    description: `${joinCount} members joined within the configured window. Action taken: **${guildConfig.antiRaid.action}**.`,
    color: '#ED4245',
  });
}

function isLockdownActive(guildId) {
  return activeLockdowns.has(guildId);
}

function clearLockdown(guildId) {
  activeLockdowns.delete(guildId);
  joinTimestamps.delete(guildId);
  joinMembers.delete(guildId);
}

/** True if the account is younger than the configured new-account threshold. */
function isNewAccount(user, guildConfig) {
  const ageDays = (Date.now() - user.createdTimestamp) / (1000 * 60 * 60 * 24);
  return ageDays < (guildConfig.antiRaid?.newAccountAgeDays ?? 7);
}

// Periodic sweep so joinTimestamps doesn't silently grow without bound on
// guilds that receive normal joins but never trigger a full raid response
// (clearLockdown only deletes an entry when a raid IS detected; quiet guilds
// accumulate stale entries for the lifetime of the process).
//
// 60 s is a safe upper bound: the default windowMs is 10 s and even the
// most permissive raid config is unlikely to exceed 60 s, so any timestamps
// older than 60 s are definitively stale. Mirrors the sweep pattern used by
// cooldown.js, automodChecks.js, snipeService.js, and levelingService.js.
// unref() so this timer never keeps the process alive on its own.
const JOIN_TIMESTAMPS_MAX_AGE_MS = 60_000;
const JOIN_TIMESTAMPS_SWEEP_MS = 5 * 60_000;

const joinTimestampsSweepTimer = setInterval(() => {
  const now = Date.now();
  for (const [guildId, timestamps] of joinTimestamps) {
    const fresh = timestamps.filter((t) => now - t < JOIN_TIMESTAMPS_MAX_AGE_MS);
    if (fresh.length === 0) {
      joinTimestamps.delete(guildId);
      joinMembers.delete(guildId);
    } else if (fresh.length !== timestamps.length) {
      joinTimestamps.set(guildId, fresh);
      // Trim joinMembers to match the surviving timestamps (newest N members)
      const members = joinMembers.get(guildId);
      if (members) joinMembers.set(guildId, members.slice(members.length - fresh.length));
    }
  }
}, JOIN_TIMESTAMPS_SWEEP_MS);
joinTimestampsSweepTimer.unref();

module.exports = { recordJoinAndCheckRaid, isLockdownActive, clearLockdown, isNewAccount };
