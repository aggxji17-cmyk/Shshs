const { ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits } = require('discord.js');
const { baseEmbed } = require('../utils/embeds');
const { buildTicketArchive, formatBytes } = require('./archiveService');
const { sendRatingPrompt } = require('./ratingService');
const { getGuildConfig, resolved } = require('../utils/resolveGuildSettings');
const { buildStatusChannelName, buildCloseStatusChannelName, deriveBaseChannelName } = require('../utils/ticketPanel');
const { queueRename } = require('./ticketRenameQueue');
const Ticket = require('../database/models/Ticket');
const logger = require('../utils/logger');
const ticketState = require('./ticketStateManager');

const DEFAULT_CLOSE_MESSAGE =
  'تم إغلاق هذه التذكرة. يمكنك إعادة فتحها خلال المدة التالية قبل حذفها نهائياً، أو حذفها الآن.';
const DEFAULT_DELETE_LABEL = '🗑️ حذف نهائي';
const DEFAULT_REOPEN_LABEL = '🔓 إعادة فتح';

/** Replaces {number}/{type}/{minutes} placeholders in a configurable close-prompt template. */
function applyClosePlaceholders(template, { number, type, minutes }) {
  return String(template)
    .replaceAll('{number}', String(number))
    .replaceAll('{type}', type || 'غير محدد')
    .replaceAll('{minutes}', String(minutes ?? 0));
}

/** Builds the 🗑️/🔓 action row for a closed-but-not-yet-deleted ticket. customId carries the ticket's Mongo _id through to the button handlers. */
function buildClosePromptComponents(closePrompt, ticket) {
  const deleteLabel = (closePrompt?.deleteButtonLabel || DEFAULT_DELETE_LABEL).slice(0, 80);
  const reopenLabel = (closePrompt?.reopenButtonLabel || DEFAULT_REOPEN_LABEL).slice(0, 80);

  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`ticket_delete_confirm:${ticket._id}`).setLabel(deleteLabel).setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId(`ticket_reopen:${ticket._id}`).setLabel(reopenLabel).setStyle(ButtonStyle.Success)
  );
}

/** Builds the embed shown alongside the 🗑️/🔓 buttons right after a ticket is closed. */
function buildClosePromptEmbed(settings, closePrompt, ticket, autoDeleteMinutes) {
  const text = applyClosePlaceholders(
    closePrompt?.message ? closePrompt.message.replace(/\\n/g, '\n') : DEFAULT_CLOSE_MESSAGE,
    { number: ticket.ticketNumber, type: ticket.typeLabel, minutes: autoDeleteMinutes }
  );

  const embed = baseEmbed(settings).setTitle('🔒・التذكرة مغلقة').setDescription(text);
  if (autoDeleteMinutes > 0) {
    embed.addFields(
      { name: '🎫 الحالة', value: 'مغلقة وتنتظر قرارك', inline: true },
      { name: '⏳ الحذف التلقائي', value: `<t:${Math.floor((Date.now() + autoDeleteMinutes * 60_000) / 1000)}:R>`, inline: true }
    );
  } else {
    embed.addFields({ name: '🎫 الحالة', value: 'مغلقة — الحذف التلقائي معطّل', inline: true });
  }
  return embed;
}

/**
 * Locks a ticket channel down for its opener - keeps ViewChannel so they
 * can still see the close prompt and its buttons, but revokes SendMessages
 * so the "closed" state actually means something. Mirrors the exact
 * overwrite shape ticket_create_modal grants on open, so restoreTicketAccess
 * below can put it back to precisely how it was.
 */
async function lockTicketChannel(channel, ticket) {
  await channel.permissionOverwrites
    .edit(ticket.userId, {
      ViewChannel: true,
      SendMessages: false,
      ReadMessageHistory: true,
    })
    .catch((err) => {
      // Task 2: log Discord API failures instead of swallowing them -
      // this is cosmetic (the ticket is already correctly closed in the
      // DB either way) but staff should be able to see in the logs why
      // a ticket opener could still technically type in a "closed" channel.
      logger.warn(`تعذر تقييد صلاحيات صاحب التذكرة #${ticket.ticketNumber} بعد الإغلاق: ${err.message}`);
    });
}

/** Restores the ticket opener's original ViewChannel/SendMessages/ReadMessageHistory access on reopen - "تعود جميع الصلاحيات كما كانت". */
async function restoreTicketAccess(channel, ticket) {
  await channel.permissionOverwrites
    .edit(ticket.userId, {
      ViewChannel: true,
      SendMessages: true,
      ReadMessageHistory: true,
    })
    .catch((err) => {
      logger.warn(`تعذر استعادة صلاحيات صاحب التذكرة #${ticket.ticketNumber} بعد إعادة الفتح: ${err.message}`);
    });
}

/**
 * TASK 01 (إصلاح حالة التذكرة أثناء الإغلاق):
 *
 * This used to be two pieces: the caller (ticket_close button /
 * legacy /close command) set `ticket.status = 'closed'` and saved it,
 * THEN called this function, which saved more fields (closeStatus,
 * autoDeleteAt) and only at the very end tried to send the close-prompt
 * message with a silent catch.
 *
 * The bug: the "closed" status was already committed to MongoDB before
 * Discord ever got a chance to fail. If that final `channel.send` failed
 * for any reason (missing permission, rate limit, transient network
 * error) - which was silently swallowed - the ticket was left permanently
 * `status: 'closed'` in the database with no Close Prompt ever posted:
 * no 🗑️/🔓 buttons, nothing for the opener or staff to act on. The
 * database said "closed", Discord showed nothing new at all.
 *
 * Fixed order, so a Discord failure can never leave the database in a
 * misleading state:
 *   1. Send the close-prompt message FIRST, while the ticket is still
 *      fully "open" everywhere else (no DB write has happened yet).
 *   2. If that send fails, stop here and report failure - nothing has
 *      been written, so the ticket stays open and consistent, and the
 *      caller can tell staff to retry instead of the DB silently
 *      disagreeing with what the channel actually shows.
 *   3. Only once the prompt has actually been posted do we persist
 *      status/closedBy/closedAt/isOpen/closeStatus/autoDeleteAt, all in
 *      one save(). If that save fails (e.g. a transient DB error), we
 *      retry once - the message is already live in the channel, so it's
 *      worth a second attempt before giving up - and if it still fails
 *      we log it as a critical inconsistency (message posted, DB not
 *      updated) instead of letting it pass silently, and still report
 *      failure to the caller.
 *   4. Only cosmetic follow-ups (locking the channel, renaming it) run
 *      after that; failures there are logged but don't undo the close -
 *      the ticket is already correctly closed and prompted at that
 *      point, so a missed rename/lock doesn't need recovery. (Task 2:
 *      these now run detached from this function's return - see
 *      runCloseFollowUps below - so a slow/rate-limited rename can never
 *      delay the close-prompt message or the caller's response.)
 *
 * Returns { success: true, ticket } once the ticket is actually closed
 * and its prompt is live, or { success: false, reason } otherwise.
 */
async function closeTicket(channel, guildConfig, settings, ticket, closedById) {
  const closePrompt = guildConfig.tickets.closePrompt || {};
  const autoDeleteMinutes = closePrompt.autoDeleteMinutes ?? 240;
  const baseChannelName = ticket.baseChannelName || deriveBaseChannelName(channel.name);
  // Task 9: as soon as a ticket closes it goes 🔵 "pending deletion" - the
  // channel name itself tells staff its state without opening it.
  const closeStatus = autoDeleteMinutes > 0 ? 'pending_delete' : null;

  try {
    await channel.send({
      embeds: [buildClosePromptEmbed(settings, closePrompt, ticket, autoDeleteMinutes)],
      components: [buildClosePromptComponents(closePrompt, ticket)],
    });
  } catch (err) {
    logger.error(`فشل إرسال رسالة إغلاق التذكرة #${ticket.ticketNumber} (${ticket._id}): ${err.stack || err}`);
    return { success: false, reason: 'send_failed' };
  }

  // Task 8: التعيينات نفسها بالضبط، منقولة إلى الطبقة المركزية
  // (ticketStateManager.applyClosed) بدل تكرارها هنا.
  ticketState.applyClosed(ticket, {
    closedById,
    autoDeleteAt: autoDeleteMinutes > 0 ? new Date(Date.now() + autoDeleteMinutes * 60_000) : null,
    closeStatus,
    baseChannelName,
  });

  try {
    await ticket.save();
  } catch (err) {
    // Recovery: one retry before giving up - most failures here are
    // transient (a DB connection blip), and the close-prompt message is
    // already live in the channel, so it's worth trying again rather
    // than leaving the opener/staff looking at buttons for a ticket
    // that's still "open" in the database.
    try {
      await ticket.save();
    } catch (retryErr) {
      logger.error(
        `حالة غير متسقة: تم إرسال رسالة إغلاق التذكرة #${ticket.ticketNumber} (${ticket._id}) لكن فشل حفظ حالة closed في قاعدة البيانات: ${retryErr.stack || retryErr}`
      );
      return { success: false, reason: 'save_failed' };
    }
  }

  // Task 2 (فصل العمليات البطيئة عن الواجهة المهمة): locking the channel
  // and renaming it are cosmetic, non-critical follow-ups - and setName
  // in particular can be slow or rate-limited by Discord (~2 renames per
  // 10 minutes per channel). The close-prompt message above has already
  // been sent and the ticket already saved as closed, so these run
  // detached instead of making the caller (and the interaction reply)
  // wait on them. Any failure is logged, never silently dropped.
  runCloseFollowUps(channel, ticket, baseChannelName).catch((err) => {
    logger.error(`فشل غير متوقع أثناء عمليات ما بعد إغلاق التذكرة #${ticket.ticketNumber} (${ticket._id}): ${err.stack || err}`);
  });

  return { success: true, ticket };
}

/**
 * TASK 02: the non-critical tail of closeTicket() - locking the channel
 * down for the opener and renaming it to reflect closeStatus. Split out
 * so it can run detached from the critical path (message sent + DB
 * saved) instead of delaying it. Never throws outward: every step here
 * catches and logs its own Discord API failures instead of using
 * silent catch, per the "no hiding critical errors" rule - a
 * missed lock/rename is cosmetic and doesn't need recovery, but it does
 * need to be visible in the logs.
 */
async function runCloseFollowUps(channel, ticket, baseChannelName) {
  await lockTicketChannel(channel, ticket);

  // Task 13: بدل استدعاء channel.setName() مباشرة هنا (حتى مع تشغيلها
  // منفصلة أصلاً عن رسالة الإغلاق منذ مهمة 2)، تُمرَّر التسمية إلى
  // الطابور المركزي (services/ticketRenameQueue.js، مهمة 10) - نفس مبدأ
  // مهمة 11/12. هذا يضمن أن أي طلب rename آخر على نفس القناة (مثلاً
  // Status Toggle حدث بنفس اللحظة) لا يتصادم مع هذا الطلب، ويجعل التعامل
  // مع Rate Limit ديسكورد موحّداً عبر كل مسارات التذاكر بدل تكراره هنا
  // بشكل منفصل.
  if (ticket.closeStatus) {
    queueRename(channel, buildCloseStatusChannelName(baseChannelName, ticket.closeStatus), {
      context: `ticket_close #${ticket.ticketNumber}`,
    });
  }
}

/**
 * Reopens a previously-closed ticket in place: restores channel access,
 * clears the pending-deletion timer, and puts the ticket back into
 * whichever non-closed status it had before (claimed stays claimed).
 *
 * Returns { success: true } normally, or { success: false, reason:
 * 'active_ticket_exists' } in the one edge case the Task 5 partial
 * unique index (guildId+userId, isOpen:true - see database/models/Ticket.js)
 * can now surface: the member opened a *different* new ticket while this
 * one sat closed-and-pending-deletion, so reopening this one would give
 * them two active tickets at once, which the index (correctly) refuses.
 * This was always logically undesirable; it just had no way to be
 * detected/prevented before the index existed. The ticket itself is left
 * exactly as it was (still closed) so nothing is lost and it can still
 * be permanently deleted normally.
 */
async function reopenTicket(channel, ticket, reopenedById) {
  // Task 8: التعيينات نفسها بالضبط (بما فيها تصفير أثر TASK32/TASK33)،
  // منقولة إلى ticketStateManager.applyReopened.
  ticketState.applyReopened(ticket, reopenedById);

  try {
    await ticket.save();
  } catch (err) {
    if (err?.code === 11000) {
      // Roll the in-memory document back to its closed state so callers
      // that inspect `ticket` afterwards (e.g. for logging) see the truth.
      ticketState.rollbackReopenConflict(ticket);
      return { success: false, reason: 'active_ticket_exists' };
    }
    throw err;
  }

  await restoreTicketAccess(channel, ticket);

  // Task 9: "عند إعادة فتح التكت، يعود اسم الروم تلقائياً إلى حالته
  // السابقة" - drop the 🔵/🔴 close-state prefix and go back to whichever
  // 🟡/🟢 reply-status the ticket had before it was closed.
  //
  // Task 12: كانت هذه العملية await مباشر على channel.setName()، أي أن
  // reopenTicket() (وبالتالي رد الـInteraction في buttons.js الذي ينتظرها)
  // كان يتعطّل بانتظار Discord API. الآن تُمرَّر إلى الطابور المركزي
  // (services/ticketRenameQueue.js، مهمة 10) بدون انتظار - نفس مبدأ
  // مهمة 11 - فلا يعود بإمكان setName بطيء أن يعطّل الـInteraction، وتبقى
  // وظيفة إعادة الفتح كما هي تماماً.
  if (channel) {
    const baseName = ticket.baseChannelName || deriveBaseChannelName(channel.name);
    queueRename(channel, buildStatusChannelName(baseName, ticket.replyStatus), {
      context: `ticket_reopen #${ticket.ticketNumber}`,
    });
  }

  return { success: true };
}

/**
 * The one and only path to a ticket channel actually disappearing -
 * used by both the 🗑️ button and the auto-delete scheduler. Builds the
 * HTML/zip transcript archive, drops it (plus a summary embed) into the
 * configured log channel, then deletes the channel. Never throws: a
 * failed archive must never block the deletion itself.
 *
 * Task 6 (double-delete guard): the scheduler and the 🗑️ button (or a
 * fast double-click on it) can both reach this function for the same
 * ticket at nearly the same moment - e.g. the auto-delete pass picks the
 * ticket up right as staff also clicks 🗑️. The very first thing this
 * function does is atomically "claim" the ticket via a single
 * find-and-update on permanentlyDeletedAt (Mongo serializes concurrent
 * writes to the same document, so only one caller can ever win this).
 * Whoever loses the race returns immediately - no archive, no log entry,
 * no second channel.delete() attempt.
 */
async function finalizeTicketDeletion(client, guild, guildConfig, settings, ticket, channel, deletedById) {
  let claimed;
  try {
    claimed = await Ticket.findOneAndUpdate(
      { _id: ticket._id, permanentlyDeletedAt: null },
      { $set: { permanentlyDeletedAt: new Date(), autoDeleteAt: null, closeStatus: null } },
      { new: true }
    );
  } catch (err) {
    logger.error(`فشل حجز حذف التذكرة #${ticket.ticketNumber} (${ticket._id}): ${err.stack || err}`);
    return { success: false, reason: 'claim_failed' };
  }
  if (!claimed) return { success: false, reason: 'already_deleted' }; // another call already finalized (or is finalizing) this ticket

  // Keep the in-memory document consistent with the atomic claim above so
  // anything below that reads these fields sees the true post-claim state.
  // Task 8: نفس التعيينات عبر ticketStateManager.applyPermanentlyDeleted.
  ticketState.applyPermanentlyDeleted(ticket, claimed.permanentlyDeletedAt);

  const openedAt = ticket.createdAt;

  const archive = channel
    ? await buildTicketArchive(channel, ticket, openedAt).catch((err) => {
        logger.error(`فشل إنشاء أرشيف التذكرة #${ticket.ticketNumber}: ${err.message}`);
        return null;
      })
    : null;

  if (guildConfig.tickets.logChannelId) {
    const logChannel = guild.channels.cache.get(guildConfig.tickets.logChannelId);
    if (logChannel) {
      const files = archive ? [archive.htmlAttachment, archive.zipAttachment] : [];
      const openedAtValue = ticket.createdAt ? `<t:${Math.floor(new Date(ticket.createdAt).getTime() / 1000)}:F>` : 'غير معروف';
      const closedAtValue = ticket.closedAt ? `<t:${Math.floor(new Date(ticket.closedAt).getTime() / 1000)}:F>` : 'غير معروف';
      const embed = baseEmbed(settings)
        .setTitle(`📁・التذكرة #${ticket.ticketNumber} حُذفت نهائياً`)
        .addFields(
          { name: '📂 القسم', value: ticket.typeLabel || 'غير محدد', inline: true },
          { name: '👤 صاحب التذكرة', value: `<@${ticket.userId}>`, inline: true },
          // Task 7: surface data that already exists on the ticket
          // document (claimedBy/createdAt/closedAt) but wasn't being
          // shown in this log yet - nothing invented, just fields the
          // system already tracks.
          { name: '🛡️ الموظف المستلم', value: ticket.claimedBy ? `<@${ticket.claimedBy}>` : 'لم يتم الاستلام', inline: true },
          { name: '🗑️ حُذفت بواسطة', value: deletedById ? `<@${deletedById}>` : 'النظام تلقائياً ⏳', inline: true },
          { name: '🕒 وقت الإنشاء', value: openedAtValue, inline: true },
          { name: '🔒 وقت الإغلاق', value: closedAtValue, inline: true }
        );

      if (archive) {
        embed.addFields(
          { name: '💬 عدد الرسائل', value: `${archive.stats.messageCount}`, inline: true },
          { name: '📎 المرفقات المحفوظة', value: `${archive.stats.savedAttachmentCount}/${archive.stats.attachmentCount}`, inline: true },
          { name: '📦 حجم الأرشيف', value: formatBytes(archive.stats.zipSizeBytes), inline: true }
        );
      } else {
        embed.addFields({ name: 'ملاحظة', value: '⚠️ تعذر إنشاء أرشيف كامل لهذه التذكرة.' });
      }

       await logChannel.send({ embeds: [embed], files }).catch((err) => {
         logger.warn(`تعذر إرسال سجل حذف التذكرة #${ticket.ticketNumber} إلى قناة السجل: ${err.message}`);
       });
    }
  }

  // permanentlyDeletedAt/autoDeleteAt/closeStatus were already committed
  // atomically by the claim at the top of this function (Task 6) - no
  // second write needed here.

  // Fire the rating DM last, and only now that the ticket is truly gone
  // for good - asking before this point would be premature, since the
  // opener could still have reopened it via the 🔓 button. A user with
  // DMs closed or ratings disabled for the guild should never block the
  // deletion itself.
  await sendRatingPrompt(client, guild, guildConfig, settings, ticket).catch((err) => {
    logger.warn(`تعذر إرسال طلب تقييم التذكرة #${ticket.ticketNumber}: ${err.message}`);
  });

  if (channel) {
    await channel.delete().catch((err) => {
      logger.error(`فشل حذف قناة التذكرة #${ticket.ticketNumber} (${ticket.channelId}): ${err.stack || err}`);
    });
  }

  return { success: true };
}

/**
 * Task 9: flips every 🔵 "pending deletion" ticket whose remaining time has
 * dropped under tickets.closePrompt.warningMinutes over to 🔴 "about to be
 * deleted" - both the channel name and ticket.closeStatus - so staff can
 * see from the channel list alone that the clock is almost out. Tickets
 * already 🔴 (or with warnings disabled for their guild) are skipped so a
 * server doesn't get a rename attempt every minute for nothing.
 */
async function runCloseWarningPass(client) {
  const candidates = await Ticket.find({
    status: 'closed',
    closeStatus: 'pending_delete',
    autoDeleteAt: { $ne: null },
  }).limit(100);

  for (const ticket of candidates) {
    const guild = client.guilds.cache.get(ticket.guildId);
    if (!guild) continue;

    const guildConfig = await getGuildConfig(ticket.guildId);
    const warningMinutes = guildConfig.tickets.closePrompt?.warningMinutes ?? 30;
    if (warningMinutes <= 0) continue; // 🔴 stage disabled for this guild - stays 🔵 until deleted.

    const msRemaining = ticket.autoDeleteAt.getTime() - Date.now();
    if (msRemaining > warningMinutes * 60_000) continue; // not close enough yet

    ticketState.applyCloseStatus(ticket, ticketState.CLOSE_STATUS.NEAR_DELETE);
    try {
      await ticket.save();
    } catch (err) {
      logger.error(`فشل حفظ حالة اقتراب حذف التذكرة #${ticket.ticketNumber} (${ticket._id}): ${err.stack || err}`);
      continue;
    }

    const channel = guild.channels.cache.get(ticket.channelId) || (await fetchTicketChannel(guild, ticket));
    if (!channel) continue;

    // Task 14: كانت هذه await مباشر على channel.setName() داخل حلقة تمر
    // على حتى 100 تذكرة - فتذكرة واحدة بطيئة أو محكومة بـ Rate Limit
    // كانت تُعطّل استمرار الحلقة على بقية التذاكر (لكل تذكرة، الحلقة
    // تنتظر انتهاء setName قبل الانتقال للتالية). الآن تُمرَّر إلى الطابور
    // المركزي (services/ticketRenameQueue.js، مهمة 10) بدون انتظار - نفس
    // مبدأ مهمة 11/12/13 - فمعالجة بقية التذاكر تستمر فوراً بغض النظر عن
    // حالة Rate Limit لأي قناة، والطابور نفسه يتكفّل بجدولة كل قناة على
    // حدة عند الحاجة.
    const baseName = ticket.baseChannelName || deriveBaseChannelName(channel.name);
    queueRename(channel, buildCloseStatusChannelName(baseName, 'near_delete'), {
      context: `ticket_close_warning #${ticket.ticketNumber}`,
    });
  }
}

// TASK32: how long staff's last message can sit unanswered before the
// opener gets a reminder ping - matches the spec's "دقيقة كاملة".
const REPLY_REMINDER_WAIT_MS = 60_000;

/**
 * TASK32 (reply reminder ping): for every open/claimed ticket where staff
 * spoke last (replyStatus === 'no_action' - see messageCreate.js's
 * handleTicketStatusUpdate, which maintains lastStaffMessageAt/
 * reminderSentAt) and the opener still hasn't replied a full minute
 * later, sends one @mention ping into the ticket - just enough for
 * Discord to fire its normal mention notification - then immediately
 * deletes that message so it doesn't clutter the channel. The
 * notification itself has already been dispatched server-side by the
 * time the message is sent, so deleting it right after doesn't take the
 * notification back.
 *
 * Never more than one ping per wait window: the findOneAndUpdate below
 * atomically claims `reminderSentAt` against the exact `lastStaffMessageAt`
 * this pass observed, so if that timestamp changed in between (staff
 * sent another message, or the opener already replied and cleared it -
 * both happen in handleTicketStatusUpdate) the claim simply fails and
 * this ticket is safely skipped for this tick, exactly like
 * finalizeTicketDeletion's claim-then-act pattern above. No per-ticket
 * timer of any kind - this is one query per scheduler tick, same as the
 * auto-delete/close-warning passes already in this file, and the
 * "tracking" itself lives entirely in the Ticket document (lastStaffMessageAt/
 * reminderSentAt), not in memory - so there's nothing to clean up when a
 * ticket closes or its channel is deleted; it just stops matching the
 * `status: {open, claimed}` filter below and is never picked up again.
 */
async function runReplyReminderPass(client) {
  const due = await Ticket.find({
    status: { $in: ['open', 'claimed'] },
    replyStatus: 'no_action',
    reminderSentAt: null,
    lastStaffMessageAt: { $ne: null, $lte: new Date(Date.now() - REPLY_REMINDER_WAIT_MS) },
  }).limit(100);

  for (const ticket of due) {
    // eslint-disable-next-line no-await-in-loop
    const claimed = await Ticket.findOneAndUpdate(
      {
        _id: ticket._id,
        status: { $in: ['open', 'claimed'] },
        reminderSentAt: null,
        lastStaffMessageAt: ticket.lastStaffMessageAt,
      },
      { $set: { reminderSentAt: new Date() } },
      { new: true }
    );
    if (!claimed) continue; // staff sent another message, or the opener already replied, since the query above ran

    const guild = client.guilds.cache.get(ticket.guildId);
    if (!guild) continue;

    // eslint-disable-next-line no-await-in-loop
    const channel = guild.channels.cache.get(ticket.channelId) || (await fetchTicketChannel(guild, ticket));
    if (!channel) continue;

    const perms = channel.permissionsFor(guild.members.me);
    if (!perms?.has(PermissionFlagsBits.SendMessages)) continue; // can't ping at all - nothing else to do, no crash

    try {
      // eslint-disable-next-line no-await-in-loop
      const sent = await channel.send({ content: `<@${ticket.userId}> ⏳ فريق الدعم بانتظار ردك على هذه التذكرة.` });
      if (perms.has(PermissionFlagsBits.ManageMessages)) {
        // eslint-disable-next-line no-await-in-loop
        await sent.delete().catch((err) => {
          logger.warn(`تعذر حذف رسالة تذكير التذكرة #${ticket.ticketNumber}: ${err.message}`);
        });
      }
      // Missing Manage Messages: leave the ping visible rather than
      // failing the whole reminder - the notification already did its
      // job either way, per spec ("لا يحصل Crash... تعامل مع Missing
      // Permissions بأمان").
    } catch (err) {
      // TASK 21 (إصلاح H5): channel.send() فشل بعد أن سجّلنا reminderSentAt
      // في قاعدة البيانات. لو أبقيناه مُسجَّلاً ستبقى التذكرة بلا تذكير
      // إلى الأبد - ننسئه حتى يُعاد المحاولة في الـtick القادم.
      // هذا آمن لأن findOneAndUpdate أعلاه يمنع التكرار المتزامن.
      await Ticket.updateOne(
        { _id: claimed._id, reminderSentAt: claimed.reminderSentAt },
        { $set: { reminderSentAt: null } }
      ).catch((resetErr) => {
        logger.warn(`تعذر إلغاء حجز reminderSentAt للتذكرة #${ticket.ticketNumber}: ${resetErr.message}`);
      });
      logger.error(`Ticket reply-reminder scheduler error for ticket ${ticket._id}: ${err.stack || err}`);
    }
  }
}

/** Runs finalizeTicketDeletion for every ticket whose auto-delete timer has come due, and separately flips 🔵→🔴 tickets nearing that deadline. Call on an interval from the ready event. */
function startTicketAutoDeleteScheduler(client) {
  setInterval(async () => {
    try {
      await runCloseWarningPass(client);
    } catch (err) {
      logger.error(`Ticket close-warning scheduler error: ${err.stack || err}`);
    }

    // TASK32: same single central interval as the two passes above and
    // below - no separate setInterval/setTimeout added for this feature,
    // per spec ("استخدم Scheduler/Timer مركزي واحد... ولا تنشئ setInterval
    // مستقل لكل تكت").
    try {
      await runReplyReminderPass(client);
    } catch (err) {
      logger.error(`Ticket reply-reminder scheduler error: ${err.stack || err}`);
    }

    try {
      const due = await Ticket.find({ status: 'closed', autoDeleteAt: { $ne: null, $lte: new Date() } }).limit(25);

      for (const staleTicket of due) {
        // Task 6 (reopen-during-delete race): the snapshot above can go
        // stale between this query and this ticket's turn in the loop -
        // e.g. the ticket owner clicks 🔓 reopen in that window, which
        // sets status back to open/claimed and clears autoDeleteAt.
        // Re-claim atomically against the SAME condition the query used
        // (still closed, still due) instead of trusting the in-memory
        // copy - if it was reopened (or another process already claimed
        // it) in the meantime this returns null and the ticket is safely
        // skipped, never deleted out from under its reopen.
        const ticket = await Ticket.findOneAndUpdate(
          { _id: staleTicket._id, status: 'closed', autoDeleteAt: { $ne: null, $lte: new Date() } },
          { $set: { autoDeleteAt: null } },
          { new: true }
        );
        if (!ticket) continue;

        const guild = client.guilds.cache.get(ticket.guildId);
        if (!guild) continue;

        const guildConfig = await getGuildConfig(ticket.guildId);
        const settings = resolved(guildConfig);
        const channel = guild.channels.cache.get(ticket.channelId) || (await fetchTicketChannel(guild, ticket));

        await finalizeTicketDeletion(client, guild, guildConfig, settings, ticket, channel, null);
      }
    } catch (err) {
      logger.error(`Ticket auto-delete scheduler error: ${err.stack || err}`);
    }
  }, 60_000);
}

/**
 * A missing channel is an expected outcome after a manual deletion or a
 * Discord-side cleanup. Other fetch failures still need to be visible so
 * the scheduler does not silently skip a ticket because of a permission,
 * rate-limit, or transport problem.
 */
async function fetchTicketChannel(guild, ticket) {
  try {
    return await guild.channels.fetch(ticket.channelId);
  } catch (err) {
    if (err?.code === 10003) return null;
    logger.warn(`تعذر جلب قناة التذكرة #${ticket.ticketNumber} (${ticket.channelId}): ${err.message}`);
    return null;
  }
}

module.exports = {
  DEFAULT_CLOSE_MESSAGE,
  DEFAULT_DELETE_LABEL,
  DEFAULT_REOPEN_LABEL,
  applyClosePlaceholders,
  buildClosePromptComponents,
  buildClosePromptEmbed,
  closeTicket,
  reopenTicket,
  restoreTicketAccess,
  finalizeTicketDeletion,
  runReplyReminderPass,
  startTicketAutoDeleteScheduler,
  fetchTicketChannel,
};
