const mongoose = require('mongoose');
const EconomyBalance = require('../database/models/EconomyBalance');

/** يُستخدم داخليًا فقط لإيقاف المعاملة (transaction) عند عدم كفاية الرصيد. */
class InsufficientBalanceError extends Error {}

/** يكتشف حالة عدم دعم قاعدة البيانات للمعاملات (mongod بدون replica set). */
function isTransactionsUnsupportedError(err) {
  if (!err) return false;
  const msg = err.message || '';
  return (
    err.code === 20 || // IllegalOperation
    err.codeName === 'IllegalOperation' ||
    /Transaction numbers/i.test(msg) ||
    /requires (a )?replica set/i.test(msg)
  );
}

/**
 * يجلب حساب المستخدم أو ينشئه إن لم يوجد.
 * تم تحويلها إلى findOneAndUpdate + upsert بدل find ثم create المنفصلين،
 * لتفادي إنشاء وثيقتين مكررتين إذا استُدعيت الدالة مرتين بالتوازي لنفس المستخدم
 * قبل اكتمال أول عملية create (سباق كان يمكن أن يصطدم بفهرس unique).
 */
async function getAccount(guildId, userId) {
  const acct = await EconomyBalance.findOneAndUpdate(
    { guildId, userId },
    { $setOnInsert: { guildId, userId } },
    { new: true, upsert: true }
  );
  return acct;
}

async function getBalance(guildId, userId) {
  const acct = await getAccount(guildId, userId);
  return acct.balance;
}

/**
 * إضافة رصيد بشكل ذرّي عبر $inc بدل قراءة->تعديل->حفظ.
 * $inc على مستوى قاعدة البيانات يضمن عدم فقدان أي زيادة حتى لو
 * نُفّذت عدة إضافات لنفس الحساب في نفس اللحظة (لا مزيد من lost updates).
 */
async function addBalance(guildId, userId, amount) {
  if (typeof amount !== 'number' || !Number.isFinite(amount)) {
    throw new Error('Amount must be a finite number.');
  }
  const acct = await EconomyBalance.findOneAndUpdate(
    { guildId, userId },
    { $inc: { balance: amount }, $setOnInsert: { guildId, userId } },
    { new: true, upsert: true }
  );
  return acct.balance;
}

/**
 * خصم رصيد بشكل ذرّي وآمن: الشرط balance >= amount يُفحص ضمن نفس
 * عملية التحديث في قاعدة البيانات (وليس في الذاكرة)، لذا لا يمكن لعمليتين
 * متزامنتين أن تخصمان معًا مبلغًا يتجاوز الرصيد الفعلي.
 * تُرجع الوثيقة المحدَّثة أو null إذا فشل الشرط (رصيد غير كافٍ).
 */
async function subtractBalanceIfSufficient(guildId, userId, amount) {
  return EconomyBalance.findOneAndUpdate(
    { guildId, userId, balance: { $gte: amount } },
    { $inc: { balance: -amount } },
    { new: true }
  );
}

/** Returns { success, amount, balance } or { success: false, remainingMs }. */
async function claimDaily(guildId, userId, dailyAmount) {
  const cooldownMs = 24 * 60 * 60 * 1000;
  const cutoff = new Date(Date.now() - cooldownMs);

  // الخطوة 1: التأكد من وجود الحساب فقط (عملية idempotent لا تمنح أي
  // مكافأة ولا تلمس lastDaily بحد ذاتها). آمنة عند التزامن: لو استُدعيت
  // من عدة نداءات claimDaily في نفس اللحظة لنفس المستخدم، تنتهي جميعها
  // لنفس الوثيقة الواحدة في قاعدة البيانات (upsert ذرّي على مستوى الوثيقة).
  await getAccount(guildId, userId);

  // الخطوة 2: منح المكافأة يتم بعملية ذرّية واحدة فقط لا غير. الشرط
  // (لم يسبق الاستلام اليوم، أو انتهت مدة الانتظار) والتحديث (زيادة
  // الرصيد + تسجيل وقت الاستلام) يُنفَّذان معًا داخل نفس استدعاء
  // findOneAndUpdate على مستوى قاعدة البيانات. MongoDB تُسلسل
  // (serializes) كل الكتابات على نفس الوثيقة، لذا مهما أرسل المستخدم
  // الأمر عدة مرات في نفس الثانية (سبام)، لا يمكن لأكثر من نداء واحد أن
  // يجتاز هذا الشرط لنفس المستخدم ضمن نافذة الـ 24 ساعة نفسها — لا حاجة
  // لأي قفل إضافي ولا لإعادة محاولة (retry/recursion).
  const acct = await EconomyBalance.findOneAndUpdate(
    {
      guildId,
      userId,
      $or: [{ lastDaily: null }, { lastDaily: { $lte: cutoff } }],
    },
    { $inc: { balance: dailyAmount }, $set: { lastDaily: new Date() } },
    { new: true, upsert: false }
  );

  if (acct) {
    return { success: true, amount: dailyAmount, balance: acct.balance };
  }

  // فشل الشرط الذرّي = المستخدم ما زال ضمن فترة الانتظار (بما أن الحساب
  // مضمون الوجود من الخطوة 1، فإن lastDaily هنا ليست null بالتأكيد).
  // هذه قراءة فقط، بدون أي تعديل، لحساب الوقت المتبقي المعروض في الرسالة.
  const existing = await getAccount(guildId, userId);
  const remainingMs = cooldownMs - (Date.now() - existing.lastDaily.getTime());
  return { success: false, remainingMs: Math.max(remainingMs, 0) };
}

/** Returns { success, amount, balance } or { success: false, remainingMs }. */
async function claimWork(guildId, userId, min, max, cooldownMinutes) {
  const cooldownMs = cooldownMinutes * 60 * 1000;
  const cutoff = new Date(Date.now() - cooldownMs);
  const amount = Math.floor(Math.random() * (max - min + 1)) + min;

  // نفس نمط claimDaily: فحص وتحديث lastWork ذرّيًا في عملية واحدة.
  const acct = await EconomyBalance.findOneAndUpdate(
    {
      guildId,
      userId,
      $or: [{ lastWork: null }, { lastWork: { $lte: cutoff } }],
    },
    { $inc: { balance: amount }, $set: { lastWork: new Date() } },
    { new: true, upsert: false }
  );

  if (acct) {
    return { success: true, amount, balance: acct.balance };
  }

  const existing = await getAccount(guildId, userId);
  if (!existing.lastWork) {
    return claimWork(guildId, userId, min, max, cooldownMinutes);
  }
  const remainingMs = cooldownMs - (Date.now() - existing.lastWork.getTime());
  return { success: false, remainingMs: Math.max(remainingMs, 0) };
}

/**
 * تنفيذ التحويل داخل معاملة MongoDB حقيقية (session transaction).
 * الخطوتان (خصم المرسل + إضافة المستلم) تُطبَّقان معًا أو لا تُطبَّق أي
 * منهما إطلاقًا (all-or-nothing)، وقاعدة البيانات نفسها تمنع أي وثيقة
 * أخرى من قراءة حالة وسيطة أثناء تنفيذ المعاملة.
 */
async function transferInSession(session, guildId, fromUserId, toUserId, amount) {
  await EconomyBalance.findOneAndUpdate(
    { guildId, userId: fromUserId },
    { $setOnInsert: { guildId, userId: fromUserId } },
    { upsert: true, session }
  );

  const sender = await EconomyBalance.findOneAndUpdate(
    { guildId, userId: fromUserId, balance: { $gte: amount } },
    { $inc: { balance: -amount } },
    { new: true, session }
  );
  if (!sender) throw new InsufficientBalanceError();

  await EconomyBalance.findOneAndUpdate(
    { guildId, userId: toUserId },
    { $inc: { balance: amount }, $setOnInsert: { guildId, userId: toUserId } },
    { upsert: true, session }
  );
}

/**
 * تنفيذ بديل (fallback) عندما لا تدعم قاعدة البيانات المعاملات
 * (mongod مستقل بدون replica set). يبقى ذرّيًا لكل خطوة على حدة عبر
 * findOneAndUpdate الشرطية، مع تعويض تلقائي إن فشلت خطوة الإضافة
 * للمستلم بعد نجاح خصم المرسل، حتى لا يختفي المبلغ.
 */
async function transferAtomicFallback(guildId, fromUserId, toUserId, amount) {
  await getAccount(guildId, fromUserId);

  const debited = await subtractBalanceIfSufficient(guildId, fromUserId, amount);
  if (!debited) {
    return { success: false, reason: 'Insufficient balance.' };
  }

  try {
    await addBalance(guildId, toUserId, amount);
  } catch (err) {
    await addBalance(guildId, fromUserId, amount);
    throw err;
  }

  return { success: true };
}

/**
 * Returns { success: true } or { success: false, reason }.
 *
 * ذرّية العملية بالكامل: يُستخدم أولًا session transaction حقيقي في
 * MongoDB (خصم المرسل وإضافة المستلم كوحدة واحدة غير قابلة للانقسام،
 * مع rollback تلقائي عند أي فشل أو تعارض). إذا كانت قاعدة البيانات لا
 * تدعم المعاملات (standalone بدون replica set)، تُستخدم طريقة بديلة
 * ذرّية على مستوى كل خطوة مع تعويض تلقائي عند الفشل الجزئي.
 * في الحالتين، الشرط "الرصيد كافٍ؟" يُفحَص من قبل قاعدة البيانات نفسها
 * ضمن عملية الكتابة، وليس من قيمة مقروءة مسبقًا في الذاكرة، لذا لا يمكن
 * لأي عدد من التحويلات المتزامنة (سبام) أن تسحب أكثر من الرصيد الفعلي
 * أو أن تسبب فقدان/تضاعف أي عملة.
 */
async function transfer(guildId, fromUserId, toUserId, amount) {
  // TASK 23 (Economy Safety): `amount <= 0` alone lets NaN through (any
  // comparison with NaN is false), which would then reach $inc as NaN -
  // an invalid/uncontrolled write to a real balance. /pay's own Discord
  // option already guarantees a positive integer, but this is a shared
  // service function - validating the amount here too (same finite-number
  // guard addBalance already uses) means no future caller can corrupt a
  // balance with a non-numeric or non-finite amount, regardless of what
  // validation it did or didn't do on its side.
  if (typeof amount !== 'number' || !Number.isFinite(amount) || amount <= 0) {
    return { success: false, reason: 'Amount must be a positive number.' };
  }

  let session;
  try {
    session = await mongoose.startSession();
  } catch (err) {
    return transferAtomicFallback(guildId, fromUserId, toUserId, amount);
  }

  try {
    await session.withTransaction(() =>
      transferInSession(session, guildId, fromUserId, toUserId, amount)
    );
    return { success: true };
  } catch (err) {
    if (err instanceof InsufficientBalanceError) {
      return { success: false, reason: 'Insufficient balance.' };
    }
    if (isTransactionsUnsupportedError(err)) {
      return transferAtomicFallback(guildId, fromUserId, toUserId, amount);
    }
    throw err;
  } finally {
    session.endSession();
  }
}

/**
 * Returns { success: true } or { success: false, reason }.
 *
 * تم تحويلها لعملية ذرّية واحدة: الشرط (رصيد كافٍ + عدم امتلاك العنصر)
 * يُفحص ضمن نفس استعلام التحديث في قاعدة البيانات، بدل قراءته من نسخة
 * محلية قديمة قد تكون تغيّرت بحلول لحظة الحفظ.
 */
async function purchaseItem(guildId, userId, item) {
  // TASK 23 (Economy Safety): item.price is guaranteed >= 1 by /shop
  // additem's Discord option today, but this function has no way to
  // know that its caller enforced it - and the query below has no
  // safety net of its own. A negative price would make `balance: {
  // $gte: item.price }` match virtually any account (any balance is
  // >= a negative number) and `$inc: { balance: -item.price }` ADD
  // currency instead of charging for it - an unlimited duplication
  // bug for any future caller (dashboard, admin tool, migration) that
  // constructs an item object without going through the slash command's
  // validation. Guarding it here, the same way addBalance guards its
  // own amount, closes that off regardless of the caller.
  if (typeof item?.price !== 'number' || !Number.isFinite(item.price) || item.price <= 0) {
    return { success: false, reason: 'Invalid item price.' };
  }

  const acct = await EconomyBalance.findOneAndUpdate(
    {
      guildId,
      userId,
      balance: { $gte: item.price },
      inventory: { $ne: item.name },
    },
    { $inc: { balance: -item.price }, $push: { inventory: item.name } },
    { new: true }
  );

  if (acct) {
    return { success: true };
  }

  // حدّد سبب الفشل الدقيق بعد فشل الشرط الذرّي.
  const existing = await getAccount(guildId, userId);
  if (existing.inventory.includes(item.name)) {
    return { success: false, reason: 'أنت تمتلك هذا العنصر بالفعل.' };
  }
  return { success: false, reason: 'Insufficient balance.' };
}

module.exports = {
  getAccount,
  getBalance,
  addBalance,
  subtractBalanceIfSufficient,
  claimDaily,
  claimWork,
  transfer,
  purchaseItem,
};
