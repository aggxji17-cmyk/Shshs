/**
 * TASK 10 — Ticket Rename Queue
 * =================================================================
 * نظام مركزي وحيد لتنفيذ channel.setName() على قنوات التذاكر. الهدف:
 *
 *   1. منع الطلبات المتكررة: إذا وصل أكثر من طلب تسمية لنفس القناة قبل
 *      تنفيذ الأول، يُحتفظ فقط بآخر اسم مطلوب - لا تُنفَّذ الأسماء
 *      الوسيطة إطلاقاً (تلغي بعضها).
 *   2. Debounce: كل طلب جديد لقناة معينة يُعيد ضبط مؤقّت قصير (300ms
 *      افتراضياً) قبل التنفيذ الفعلي، حتى تتجمّع الطلبات المتلاحقة
 *      (رسالة تلو رسالة، Claim ثم Status Toggle...) في تنفيذ واحد.
 *   3. التعامل مع Rate Limit: ديسكورد يسمح بحد أقصى تقريبي لإعادة تسمية
 *      نفس القناة مرتين كل 10 دقائق. هذه الطبقة تتتبّع آخر مرّتين نُفّذ
 *      فيهما rename فعلي لكل قناة، وإن كانت القناة "ممتلئة"، تجدول
 *      التنفيذ تلقائياً لأقرب وقت متاح بدل الفشل أو التكرار العشوائي.
 *   4. الاحتفاظ بآخر اسم/حالة مطلوبة: أثناء الانتظار (debounce أو
 *      rate-limit)، أي طلب جديد لنفس القناة يستبدل الاسم المعلّق فقط -
 *      لا تتراكم طلبات متعددة، ولا تُنفَّذ إلا أحدث تسمية طُلبت.
 *
 * هذه الطبقة لا تعرف شيئاً عن حالات التذكرة (status/closeStatus/
 * replyStatus) ولا تبني الأسماء - فقط تستقبل (channel, name) وتُنفّذ
 * setName بأمان ومركزية. بناء الاسم النهائي يبقى مسؤولية
 * utils/ticketPanel.js كما هو تماماً؛ هذه المهمة لا تغيّر ذلك.
 *
 * الاستخدام (بدل استدعاء channel.setName() مباشرة):
 *   const { queueRename } = require('./ticketRenameQueue');
 *   queueRename(channel, newName, { context: 'ticket_close', ticketNumber });
 *
 * queueRename لا تُرجع Promise يُنتظر - فالغرض بالضبط هو ألا تُعطّل أي
 * Interaction/رد بانتظار عملية rename قد تكون بطيئة أو محكومة بـ Rate
 * Limit (نفس مبدأ مهمة 02/11/12/13/15). أي فشل نهائي يُسجَّل عبر Logger
 * فقط، تماماً كما كانت كل نداءات setName().catch(err => logger.warn(...))
 * المتفرقة تفعل من قبل.
 */

const logger = require('../utils/logger');

/** فترة تجميع الطلبات المتلاحقة لنفس القناة قبل التنفيذ الفعلي. */
const DEBOUNCE_MS = 300;

/** حد ديسكورد التقريبي: عمليتا إعادة تسمية كحد أقصى لكل قناة كل 10 دقائق. */
const RATE_LIMIT_WINDOW_MS = 10 * 60 * 1000;
const RATE_LIMIT_MAX_RENAMES = 2;

/**
 * حالة كل قناة قيد الإدارة، مفتاحها channel.id:
 *   pendingName   - آخر اسم طُلب ولم يُنفَّذ بعد (أو null).
 *   debounceTimer - مؤقّت الـdebounce الحالي (أو null).
 *   history       - طوابع زمنية لآخر عمليات rename فعلية (لأجل rate limit).
 *   context       - آخر سياق طُلب به (لأجل رسائل السجل فقط).
 */
const channelQueues = new Map();

function getOrCreateQueueState(channelId) {
  let state = channelQueues.get(channelId);
  if (!state) {
    state = { pendingName: null, debounceTimer: null, history: [], context: null };
    channelQueues.set(channelId, state);
  }
  return state;
}

/** يزيل من history أي طوابع زمنية أقدم من نافذة الـrate limit. */
function pruneHistory(state) {
  const cutoff = Date.now() - RATE_LIMIT_WINDOW_MS;
  state.history = state.history.filter((ts) => ts > cutoff);
}

/** يحسب متى يصبح مسموحاً بعملية rename جديدة لهذه القناة (0 = الآن). */
function msUntilRenameAllowed(state) {
  pruneHistory(state);
  if (state.history.length < RATE_LIMIT_MAX_RENAMES) return 0;
  const oldest = Math.min(...state.history);
  return Math.max(0, oldest + RATE_LIMIT_WINDOW_MS - Date.now());
}

/**
 * ينفّذ فعلياً setName بآخر اسم معلّق للقناة، أو يعيد الجدولة إن كانت
 * القناة ما زالت داخل نافذة الـrate limit. لا يُلقي استثناءً أبداً.
 */
async function flushChannel(channel, channelId) {
  const state = channelQueues.get(channelId);
  if (!state || state.pendingName == null) return;

  const wait = msUntilRenameAllowed(state);
  if (wait > 0) {
    // القناة وصلت الحد المسموح من عمليات إعادة التسمية خلال آخر 10
    // دقائق - إعادة الجدولة لأقرب وقت متاح بدل الفشل أو التكرار.
    state.debounceTimer = setTimeout(() => {
      flushChannel(channel, channelId).catch(() => {});
    }, wait + 50);
    return;
  }

  const nameToApply = state.pendingName;
  const context = state.context;
  // نُصفّر الاسم المعلّق فوراً (قبل انتظار الشبكة) حتى لا يُنفَّذ نفس
  // الاسم مرتين لو وصل طلب جديد بنفس اللحظة بالضبط.
  state.pendingName = null;
  state.debounceTimer = null;

  try {
    if (channel.name !== nameToApply) {
      await channel.setName(nameToApply);
      state.history.push(Date.now());
    }
  } catch (err) {
    logger.warn(
      `فشل تنفيذ إعادة تسمية قناة التذكرة (${channelId})${context ? ` [${context}]` : ''} إلى "${nameToApply}": ${err.message}`
    );
  }

  // إن وصل طلب جديد أثناء تنفيذ setName أعلاه (كان سيُخزَّن في
  // pendingName عبر queueRename)، نفّذه أيضاً الآن دون انتظار debounce
  // إضافي - لضمان أن آخر اسم مطلوب هو ما ينتهي عليه الأمر فعلياً.
  if (state.pendingName != null) {
    flushChannel(channel, channelId).catch(() => {});
    return;
  }

  // TASK 23 (إصلاح H7 - Memory Leak): بعد انتهاء كل عمل للقناة
  // (pendingName = null، لا debounceTimer، history منتهية الصلاحية)
  // نحذف مدخلها من الـMap. بدون هذا كل قناة تذكرة تُضاف مدخلاً
  // يبقى في الذاكرة إلى الأبد حتى بعد حذف القناة.
  pruneHistory(state);
  if (!state.pendingName && !state.debounceTimer && state.history.length === 0) {
    channelQueues.delete(channelId);
  }
}

/**
 * يطلب إعادة تسمية قناة تذكرة بشكل آمن ومركزي. لا تُنتظر (fire-and-forget)
 * عمداً - أي Interaction/رد يستدعيها يجب ألا ينتظرها.
 *
 * @param {import('discord.js').GuildChannel} channel
 * @param {string} name - الاسم النهائي المطلوب (بعد بناء البادئة/الإيموجي).
 * @param {object} [opts]
 * @param {string} [opts.context] - وصف مختصر للسبب (لرسائل الـLogger فقط).
 */
function queueRename(channel, name, opts = {}) {
  if (!channel || !name) return;
  const channelId = channel.id;
  const state = getOrCreateQueueState(channelId);

  state.pendingName = name;
  if (opts.context) state.context = opts.context;

  if (state.debounceTimer) clearTimeout(state.debounceTimer);
  state.debounceTimer = setTimeout(() => {
    flushChannel(channel, channelId).catch((err) => {
      logger.error(`خطأ غير متوقع في طابور إعادة تسمية التذاكر لقناة (${channelId}): ${err.stack || err}`);
    });
  }, DEBOUNCE_MS);
}

/** لأغراض الاختبار فقط: يمسح كل الحالة الداخلية للطابور. */
function _resetForTests() {
  for (const state of channelQueues.values()) {
    if (state.debounceTimer) clearTimeout(state.debounceTimer);
  }
  channelQueues.clear();
}

/**
 * TASK 23: يُنظّف مدخل القناة من الـMap فوراً - يُستدعى من channelDelete
 * event عند حذف قناة التذكرة حتى لا تبقى مدخلات ميتة في الذاكرة.
 * يُلغي أي debounceTimer معلّق (إذ لا فائدة من rename قناة محذوفة).
 */
function evictChannel(channelId) {
  const state = channelQueues.get(channelId);
  if (!state) return;
  if (state.debounceTimer) clearTimeout(state.debounceTimer);
  channelQueues.delete(channelId);
}

module.exports = {
  queueRename,
  evictChannel,
  DEBOUNCE_MS,
  RATE_LIMIT_WINDOW_MS,
  RATE_LIMIT_MAX_RENAMES,
  _resetForTests,
};
