const logger = require('../utils/logger');

/**
 * TASK18 (Leveling / Level Rewards)
 * ---------------------------------------------------------------------
 * Grants the Discord role(s) configured in `GuildConfig.leveling.rewards`
 * (managed via /levelreward - see commands/leveling/levelreward.js) when a
 * member levels up. Kept in its own module, separate from
 * services/levelingService.js, because that file's job is exclusively the
 * XP<->Level curve (see its own header comment) - this one's job is
 * Discord role side-effects, a different concern with a very different
 * failure mode (network/permission errors instead of pure math).
 *
 * Called from events/message/messageCreate.js's handleLeveling AFTER
 * grantMessageXp() has already committed the XP/level atomically, so
 * every failure mode below only ever affects whether a role gets handed
 * out - it can never lose XP, duplicate a level up, or block the level-up
 * announcement (the caller is expected to keep announcing even if this
 * throws or returns an empty list).
 */

/**
 * Grants every reward role configured for a level in (previousLevel,
 * newLevel] that the member doesn't already have.
 *
 * The range (not just `=== newLevel`) exists so a member who jumps more
 * than one level from a single message (possible if an admin configures
 * a very large xpMin/xpMax range) still receives every reward they
 * passed, instead of silently skipping the ones in between - the same
 * "reaching level 10 gives the level 10 role" guarantee applies to every
 * level the member's XP now qualifies for, not only the final one.
 *
 * Every failure case below is caught, logged, and skipped individually -
 * one bad reward (missing role, hierarchy issue, missing permission,
 * Discord API error) never stops the rest of the batch or throws back to
 * the caller, per spec: XP/level-up must never be blocked by a role
 * grant failure.
 *
 * @param {import('discord.js').Guild} guild
 * @param {import('discord.js').GuildMember} member
 * @param {object} guildConfig Mongoose GuildConfig document (or plain object with the same shape)
 * @param {number} previousLevel Level the member was at before this XP grant
 * @param {number} newLevel Level the member is at after this XP grant
 * @returns {Promise<import('discord.js').Role[]>} Roles actually granted (for the level-up announcement)
 */
async function grantLevelRewards(guild, member, guildConfig, previousLevel, newLevel) {
  const rewards = guildConfig?.leveling?.rewards;
  if (!Array.isArray(rewards) || !rewards.length) return [];
  if (!guild || !member) return [];

  const due = rewards.filter((r) => r?.roleId && r.level > previousLevel && r.level <= newLevel);
  if (!due.length) return [];

  const granted = [];

  for (const reward of due) {
    try {
      // Case 5: member already has this role - don't repeat the API call.
      if (member.roles.cache.has(reward.roleId)) continue;

      // Case 2: role no longer exists in the guild.
      const role = guild.roles.cache.get(reward.roleId) || (await guild.roles.fetch(reward.roleId).catch(() => null));
      if (!role) {
        logger.warn(
          `Level reward: role ${reward.roleId} (level ${reward.level}) no longer exists in guild ${guild.id} - skipping.`
        );
        continue;
      }

      // Case 3: bot lacks Manage Roles entirely.
      if (!guild.members.me?.permissions.has('ManageRoles')) {
        logger.warn(`Level reward: bot lacks Manage Roles in guild ${guild.id} - cannot grant role ${role.id}.`);
        continue;
      }

      // Case 4: role sits above (or equal to) the bot's highest role.
      // `role.editable` already accounts for both the permission check
      // above and hierarchy, same accessor used by services/tempRoleService.js.
      if (!role.editable) {
        logger.warn(
          `Level reward: role ${role.id} is above the bot's highest role in guild ${guild.id} - skipping.`
        );
        continue;
      }

      // Case 6: member left the server between the XP grant and here.
      if (!guild.members.cache.has(member.id)) {
        logger.warn(`Level reward: member ${member.id} is no longer in guild ${guild.id} - skipping.`);
        continue;
      }

      // Case 8: Discord API failure on the add itself.
      await member.roles.add(role, `Level ${reward.level} reward`);
      granted.push(role);
    } catch (err) {
      logger.error(
        `Level reward: failed to grant role ${reward.roleId} (level ${reward.level}) to ${member.id} in guild ${guild.id}: ${err?.stack || err}`
      );
    }
  }

  return granted;
}

module.exports = { grantLevelRewards };
