const GuildConfig = require('../database/models/GuildConfig');
const logger = require('../utils/logger');

const UPDATE_INTERVAL_MS = 10 * 60 * 1000; // Discord rate-limits channel renames; every 10 min is safe.

async function updateAllMemberCountChannels(client) {
  const configs = await GuildConfig.find({ 'memberCountChannel.enabled': true }).catch(() => []);

  // TASK 22 (Service Error Handling): everything below channel.setName()
  // was already caught and logged, but a malformed/legacy guildConfig
  // record (e.g. missing memberCountChannel.channelId) throwing earlier
  // in an iteration used to propagate straight out of this loop - the
  // whole pass then hit the outer `.catch(() => null)` in
  // startMemberCountUpdater below and every other guild silently missed
  // its update for that cycle with nothing logged anywhere. Isolated
  // per-guild so one bad record can't block the rest, and logged instead
  // of vanishing.
  for (const guildConfig of configs) {
    try {
      const guild = client.guilds.cache.get(guildConfig.guildId);
      const channel = guild?.channels.cache.get(guildConfig.memberCountChannel.channelId);
      if (!channel) continue;

      const name = guildConfig.memberCountChannel.format.replace('{count}', guild.memberCount.toString());
      if (channel.name === name) continue;

      await channel.setName(name).catch((err) => logger.warn(`Member count channel rename failed for ${guild.id}: ${err.message}`));
    } catch (err) {
      logger.error(`Member count update failed for guild ${guildConfig.guildId}: ${err.stack || err}`);
    }
  }
}

function startMemberCountUpdater(client) {
  updateAllMemberCountChannels(client).catch(() => null);
  setInterval(() => updateAllMemberCountChannels(client).catch(() => null), UPDATE_INTERVAL_MS).unref?.();
}

module.exports = { startMemberCountUpdater, updateAllMemberCountChannels };
