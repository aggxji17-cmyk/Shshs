const logger = require('../utils/logger');

/**
 * Centralized service manager for consistent service initialization,
 * startup sequencing, and graceful shutdown. Reduces boilerplate and
 * ensures all services follow the same error-handling and recovery patterns.
 *
 * Usage:
 *   const manager = new ServiceManager();
 *   manager.register('music', () => initMusicPlayer(client));
 *   manager.register('moderation', () => startScheduler(client));
 *   await manager.initializeAll();
 *   // ... on shutdown:
 *   await manager.shutdownAll();
 */
class ServiceManager {
  constructor() {
    // Map of service name -> { initializer, instance, status }
    this.services = new Map();
    // Map of service name -> stop function (called on shutdown)
    this.stoppers = new Map();
  }

  /**
   * Registers a service by its initializer function.
   * @param {string} name - Service name (e.g., 'music', 'moderation')
   * @param {Function} initializer - Async function that returns the service instance
   * @param {Function} stopper - Optional async function called on shutdown
   */
  register(name, initializer, stopper = null) {
    if (this.services.has(name)) {
      throw new Error(`Service "${name}" is already registered.`);
    }
    this.services.set(name, {
      initializer,
      instance: null,
      status: 'uninitialized',
      error: null,
    });
    if (stopper) {
      this.stoppers.set(name, stopper);
    }
  }

  /**
   * Initializes all registered services sequentially.
   * A single service failure does not stop others from starting.
   * Returns an object { success: [...], failed: [...] }.
   */
  async initializeAll() {
    const results = { success: [], failed: [] };

    for (const [name, service] of this.services) {
      if (service.status === 'initialized') {
        logger.warn(`Service "${name}" already initialized, skipping.`);
        results.success.push(name);
        continue;
      }

      try {
        logger.info(`Initializing service: ${name}...`);
        const instance = await service.initializer();
        service.instance = instance;
        service.status = 'initialized';
        results.success.push(name);
        logger.success(`✓ Service "${name}" initialized`);
      } catch (error) {
        service.status = 'failed';
        service.error = error?.stack || String(error);
        results.failed.push({ name, error: service.error });
        logger.error(`✗ Service "${name}" initialization failed: ${service.error}`);
      }
    }

    return results;
  }

  /**
   * Initializes a single service by name.
   * Throws if the service is not registered.
   */
  async initialize(name) {
    const service = this.services.get(name);
    if (!service) {
      throw new Error(`Service "${name}" is not registered.`);
    }
    if (service.status === 'initialized') {
      logger.warn(`Service "${name}" already initialized.`);
      return service.instance;
    }

    try {
      logger.info(`Initializing service: ${name}...`);
      const instance = await service.initializer();
      service.instance = instance;
      service.status = 'initialized';
      logger.success(`✓ Service "${name}" initialized`);
      return instance;
    } catch (error) {
      service.status = 'failed';
      service.error = error?.stack || String(error);
      logger.error(`✗ Service "${name}" initialization failed: ${service.error}`);
      throw error;
    }
  }

  /**
   * Gets the instance of an initialized service.
   */
  get(name) {
    const service = this.services.get(name);
    if (!service) {
      throw new Error(`Service "${name}" is not registered.`);
    }
    if (service.status !== 'initialized') {
      throw new Error(`Service "${name}" is not initialized.`);
    }
    return service.instance;
  }

  /**
   * Checks if a service is initialized.
   */
  isInitialized(name) {
    const service = this.services.get(name);
    return service && service.status === 'initialized';
  }

  /**
   * Gets the status of a service.
   */
  getStatus(name) {
    const service = this.services.get(name);
    if (!service) return null;
    return {
      status: service.status,
      error: service.error,
    };
  }

  /**
   * Stops all services that have registered stoppers.
   * Runs stoppers sequentially; a single stopper failure does not stop others.
   */
  async shutdownAll() {
    const results = { success: [], failed: [] };

    for (const [name, service] of this.services) {
      if (service.status !== 'initialized') {
        continue; // only stop services that were initialized
      }

      const stopper = this.stoppers.get(name);
      if (!stopper) {
        logger.warn(`No stopper registered for service "${name}"; skipping shutdown.`);
        continue;
      }

      try {
        logger.info(`Stopping service: ${name}...`);
        await stopper();
        service.status = 'stopped';
        results.success.push(name);
        logger.success(`✓ Service "${name}" stopped`);
      } catch (error) {
        service.status = 'stop_failed';
        const errMsg = error?.stack || String(error);
        results.failed.push({ name, error: errMsg });
        logger.error(`✗ Service "${name}" shutdown failed: ${errMsg}`);
      }
    }

    return results;
  }

  /**
   * Stops a single service by name.
   */
  async shutdown(name) {
    const service = this.services.get(name);
    if (!service) {
      throw new Error(`Service "${name}" is not registered.`);
    }
    if (service.status !== 'initialized') {
      logger.warn(`Service "${name}" is not initialized; skipping shutdown.`);
      return;
    }

    const stopper = this.stoppers.get(name);
    if (!stopper) {
      logger.warn(`No stopper registered for service "${name}"; skipping shutdown.`);
      return;
    }

    try {
      logger.info(`Stopping service: ${name}...`);
      await stopper();
      service.status = 'stopped';
      logger.success(`✓ Service "${name}" stopped`);
    } catch (error) {
      service.status = 'stop_failed';
      const errMsg = error?.stack || String(error);
      logger.error(`✗ Service "${name}" shutdown failed: ${errMsg}`);
      throw error;
    }
  }

  /**
   * Returns a summary of all registered services and their statuses.
   */
  getStatusReport() {
    const report = {};
    for (const [name, service] of this.services) {
      report[name] = {
        status: service.status,
        error: service.error,
      };
    }
    return report;
  }

  /**
   * Clears all services (for testing or complete restart).
   */
  clear() {
    this.services.clear();
    this.stoppers.clear();
  }
}

module.exports = ServiceManager;
