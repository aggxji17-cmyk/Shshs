const { AttachmentBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { baseEmbed, errorEmbed } = require('../utils/embeds');
const { buildProgressBar } = require('../utils/progressBar');
const { getServerStatus, getBedrockServerStatus } = require('./minecraftService');

/**
 * Queries the configured Java and (optionally) Bedrock servers live and
 * builds the full status embed + any file attachments + the button row.
 * Used by both the `/ip` slash command and the plain-text "ip" auto-responder.
 *
 * @param {ReturnType<typeof import('../utils/resolveGuildSettings').resolved>} settings
 */
async function buildMinecraftStatusResponse(settings) {
  const { name, ip, port, bedrockPort } = settings.minecraft;
  // Java and Bedrock are the same physical server/IP (Geyser just exposes
  // an extra port), so there's a single IP shared between both editions.

  const [javaStatus, bedrockStatus] = await Promise.all([
    getServerStatus(ip, port),
    bedrockPort ? getBedrockServerStatus(ip, bedrockPort) : Promise.resolve(null),
  ]);

  const isOnline = javaStatus.online || Boolean(bedrockStatus?.online);

  if (!isOnline) {
    return {
      embeds: [errorEmbed(settings, `**${name}** appears to be offline right now. (\`${ip}\`)`)],
      files: [],
      components: [],
    };
  }

  // Prefer Java's player count/version/MOTD when available since it tends to
  // be the authoritative source for cross-play (Geyser) setups.
  const primary = javaStatus.online ? javaStatus : bedrockStatus;

  const embed = baseEmbed(settings)
    .setTitle(`🎮 ${name}`)
    .addFields(
      { name: 'Status', value: '🟢 Online', inline: true },
      { name: 'Players', value: `${primary.players.online} / ${primary.players.max}`, inline: true },
      { name: 'Capacity', value: buildProgressBar(primary.players.online, primary.players.max), inline: true },
      {
        name: 'Java IP',
        value: `\`${ip}\`${javaStatus.online ? '' : ' (offline)'}`,
        inline: true,
      }
    );

  if (bedrockPort) {
    embed.addFields({
      name: 'Bedrock Port',
      value: `\`${bedrockPort}\`${bedrockStatus?.online ? '' : ' (offline)'}`,
      inline: true,
    });
  }

  if (primary.version) {
    embed.addFields({ name: 'Version', value: primary.version, inline: true });
  }

  if (javaStatus.online && javaStatus.players.sample.length) {
    embed.addFields({ name: 'Online Now', value: javaStatus.players.sample.slice(0, 15).join(', ') });
  }

  const motd = javaStatus.motd || bedrockStatus?.motd;
  if (motd) {
    embed.setDescription(`*${motd}*`);
  }

  const files = [];
  if (javaStatus.online && javaStatus.favicon) {
    const base64 = javaStatus.favicon.replace(/^data:image\/png;base64,/, '');
    const attachment = new AttachmentBuilder(Buffer.from(base64, 'base64'), { name: 'server-icon.png' });
    files.push(attachment);
    embed.setThumbnail('attachment://server-icon.png');
  }

  const row = new ActionRowBuilder();
  if (javaStatus.online) {
    row.addComponents(
      new ButtonBuilder().setCustomId('mc_copyip').setLabel('Copy Java IP').setEmoji('📋').setStyle(ButtonStyle.Primary)
    );
  }
  if (bedrockPort) {
    row.addComponents(
      new ButtonBuilder()
        .setCustomId('mc_copybedrockip')
        .setLabel('Copy Bedrock IP')
        .setEmoji('📋')
        .setStyle(ButtonStyle.Secondary)
    );
  }

  return { embeds: [embed], files, components: row.components.length ? [row] : [] };
}

module.exports = { buildMinecraftStatusResponse };
