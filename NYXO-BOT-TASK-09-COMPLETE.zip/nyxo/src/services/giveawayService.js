const { EmbedBuilder } = require('discord.js');
const Giveaway = require('../database/models/Giveaway');
const { getGuildConfig, resolved } = require('../utils/resolveGuildSettings');
const { baseEmbed } = require('../utils/embeds');
const logger = require('../utils/logger');

function pickWinners(participantIds, winnerCount) {
  const pool = [...participantIds];
  const winners = [];
  while (pool.length && winners.length < winnerCount) {
    const index = Math.floor(Math.random() * pool.length);
    winners.push(pool.splice(index, 1)[0]);
  }
  return winners;
}

function mentionList(userIds) {
  return userIds.map((id) => `<@${id}>`).join(', ');
}

async function endGiveaway(client, messageId) {
  // TASK 19 — atomic claim on `ended` instead of read-then-save. The
  // scheduler tick (every 15s) and a manual /giveaway end can otherwise
  // both read ended:false before either write lands, ending the same
  // giveaway twice (duplicate winner picks, duplicate announcements).
  const giveaway = await Giveaway.findOneAndUpdate(
    { messageId, ended: false },
    { $set: { ended: true } },
    { new: true }
  );
  if (!giveaway) return;

  const channel = await client.channels.fetch(giveaway.channelId).catch(() => null);
  if (!channel) return;

  const message = await channel.messages.fetch(giveaway.messageId).catch(() => null);
  const guildConfig = await getGuildConfig(giveaway.guildId);
  const settings = resolved(guildConfig);

  const winners = pickWinners(giveaway.participantIds, giveaway.winnerCount);

  const resultEmbed = baseEmbed(settings)
    .setTitle('🎉 انتهى السحب')
    .setDescription(
      winners.length
        ? `**Prize:** ${giveaway.prize}\n**Winner(s):** ${mentionList(winners)}`
        : `**Prize:** ${giveaway.prize}\nNo valid entries - no winner could be chosen.`
    );

  if (message) {
    await message.edit({ embeds: [resultEmbed], components: [] }).catch(() => null);
  }

  if (winners.length) {
    channel
      .send({ content: `مبروك ${mentionList(winners)}! لقد فزتم بـ **${giveaway.prize}**!` })
      .catch(() => null);
  }
}

async function rerollGiveaway(client, messageId) {
  const giveaway = await Giveaway.findOne({ messageId });
  if (!giveaway) return null;

  const winners = pickWinners(giveaway.participantIds, giveaway.winnerCount);
  const channel = await client.channels.fetch(giveaway.channelId).catch(() => null);
  if (channel && winners.length) {
    channel
      .send({ content: `🎉 فائز(ون) جديد(ون) لـ **${giveaway.prize}**: ${mentionList(winners)}!` })
      .catch(() => null);
  }
  return winners;
}

/**
 * Called once on startup and then periodically; catches giveaways that
 * expired while the bot was offline and ends any that are now due.
 */
function startGiveawayScheduler(client) {
  const check = async () => {
    try {
      const due = await Giveaway.find({ ended: false, endsAt: { $lte: new Date() } });
      // TASK 22 (Service Error Handling): endGiveaway atomically flips
      // `ended` to true before doing any of the announcement work, so a
      // failure partway through (a bad guildConfig, a Discord API hiccup)
      // used to propagate straight out of this loop uncaught - aborting
      // every other due giveaway in the same tick (they'd only be retried
      // next tick) while leaving THIS giveaway stuck `ended: true` forever
      // with no winner ever announced and nothing logged beyond a single
      // generic line. Isolating each giveaway keeps one failure from
      // blocking its siblings and logs which giveaway actually failed.
      for (const g of due) {
        await endGiveaway(client, g.messageId).catch((err) => {
          logger.error(`Failed to end giveaway ${g.messageId}: ${err.stack || err}`);
        });
      }
    } catch (err) {
      logger.error(`Giveaway scheduler error: ${err.message}`);
    }
  };

  check();
  setInterval(check, 15_000);
}

module.exports = { endGiveaway, rerollGiveaway, startGiveawayScheduler };
