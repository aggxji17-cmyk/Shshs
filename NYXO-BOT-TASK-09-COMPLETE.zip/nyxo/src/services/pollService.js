const Poll = require('../database/models/Poll');
const { baseEmbed } = require('../utils/embeds');
const { getGuildConfig, resolved } = require('../utils/resolveGuildSettings');
const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const logger = require('../utils/logger');

const POLL_INTERVAL_MS = 15_000;

function buildResultsEmbed(settings, poll) {
  const totalVotes = poll.options.reduce((sum, o) => sum + o.voterIds.length, 0);
  const lines = poll.options.map((o) => {
    const pct = totalVotes ? Math.round((o.voterIds.length / totalVotes) * 100) : 0;
    const barLength = Math.round(pct / 5);
    return `**${o.text}** - ${o.voterIds.length} vote(s) (${pct}%)\n${'█'.repeat(barLength)}${'░'.repeat(20 - barLength)}`;
  });
  return baseEmbed(settings)
    .setTitle(`📊 Poll Ended: ${poll.question}`)
    .setDescription(lines.join('\n\n') || 'No options.')
    .setFooter({ text: `${totalVotes} total vote(s)` });
}

async function closePoll(client, poll) {
  poll.ended = true;
  await poll.save();

  const channel = await client.channels.fetch(poll.channelId).catch(() => null);
  if (!channel) return;
  const message = await channel.messages.fetch(poll.messageId).catch(() => null);
  if (!message) return;

  const guildConfig = await getGuildConfig(poll.guildId);
  const settings = resolved(guildConfig);

  const disabledRow = new ActionRowBuilder().addComponents(
    poll.options.map((o, i) =>
      new ButtonBuilder().setCustomId(`poll_vote:${poll._id}:${i}`).setLabel(o.text.slice(0, 80)).setStyle(ButtonStyle.Secondary).setDisabled(true)
    )
  );

  await message.edit({ embeds: [buildResultsEmbed(settings, poll)], components: [disabledRow] }).catch(() => null);
}

function startPollScheduler(client) {
  setInterval(async () => {
    try {
      const due = await Poll.find({ ended: false, endsAt: { $ne: null, $lte: new Date() } }).limit(25);
      // TASK 22 (Service Error Handling): an unguarded error partway
      // through closePoll (e.g. getGuildConfig) used to abort this loop
      // entirely, silently deferring every other due poll to the next
      // tick with no indication of which poll or why. Isolated per-poll,
      // matching the pattern already used by streamNotificationService.js.
      for (const poll of due) {
        await closePoll(client, poll).catch((err) => {
          logger.error(`Failed to close poll ${poll._id}: ${err.stack || err}`);
        });
      }
    } catch (err) {
      logger.error(`Poll scheduler error: ${err.stack || err}`);
    }
  }, POLL_INTERVAL_MS);
}

module.exports = { startPollScheduler, buildResultsEmbed, closePoll };
