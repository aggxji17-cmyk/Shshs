const { getGuildConfig, resolved } = require('../utils/resolveGuildSettings');
const { grantVoiceXp, getXpMultiplier, getLevelProgress } = require('./levelingService');
const { grantLevelRewards } = require('./levelRewardService');
const { baseEmbed } = require('../utils/embeds');
const logger = require('../utils/logger');

/**
 * TASK26 (Voice XP)
 * ---------------------------------------------------------------------
 * Grants XP for time spent connected to a voice channel, into the exact
 * same UserLevel document/level-curve/rewards/rank/leaderboard message
 * XP already uses (see services/levelingService.js's grantVoiceXp and
 * services/levelRewardService.js) - there is no second Leveling system
 * here, only a second way to earn XP into the one that already exists.
 *
 * Anti-farm / anti-abuse design (per task spec):
 *   - One XP grant per full VOICE_XP_INTERVAL_MS (default 60s) a member
 *     is CONTINUOUSLY connected to an eligible channel. Any channel
 *     change (join/leave/move) immediately drops the in-memory session
 *     and any partial progress toward the next grant - the same
 *     "no banked partial progress" rule already used by
 *     services/afkRewardsService.js for the same reason: joining and
 *     leaving quickly (or hopping channels) can never accumulate credit.
 *   - Eligibility (feature enabled, excluded channel/role, Discord's
 *     native AFK channel, "alone or with only bots") is re-checked from
 *     LIVE Discord cache on every sweep tick, not cached at join time -
 *     so a channel that becomes ineligible (everyone else leaves, an
 *     admin excludes it) stops granting XP on the very next tick without
 *     needing the member to leave and rejoin.
 *   - Reconnect spam / rapid voiceStateUpdate churn (mute/deaf/stream
 *     toggles) never restarts or duplicates a session -
 *     handleVoiceStateChange() below only acts when the member's actual
 *     channelId changes, exactly like afkRewardsService's own
 *     `wasInAfk !== isInAfk` guard.
 *   - Only ONE place in the whole codebase grants voice XP: the
 *     sweep() tick below, driven by ONE central setInterval (see
 *     startVoiceXpScheduler) - never a per-user setInterval/setTimeout,
 *     and never a DB query per user per second. This file also never
 *     writes to any of the legacy voice-leveling collections
 *     (VoiceLevel/voiceBlacklistSchema) - see the TASK26 report for why
 *     those are a separate, currently-unused legacy feature and were
 *     deliberately left untouched.
 *   - Duplicate-XP / duplicate-level-up / duplicate-reward safety is
 *     inherited entirely from services/levelingService.js's
 *     grantVoiceXp() (atomic $inc, no find-then-save race window) and
 *     its shared commitLevelUpIfNeeded() optimistic-concurrency guard -
 *     the exact same mechanism that already protects message XP, and
 *     the same one that stops a message and a voice interval from
 *     double-granting the same level-up if they land at the same time.
 */

// `${guildId}:${userId}` -> { guildId, userId, channelId, nextGrantAt }.
// In-memory by design (this bot is a single process per client - see
// src/index.js/no sharding), exactly like afkRewardsService's
// `activeSessions` Map. This is ONLY "who is currently connected to
// which channel and when are they next due a check" - it is never the
// source of truth for XP itself (that's the UserLevel document, written
// atomically by grantVoiceXp), so losing this map on a restart can only
// ever cost some members a few seconds/minutes of un-tracked time until
// primeActiveSessions() rebuilds it below - it can never cause duplicate
// or incorrect XP.
const sessions = new Map();

// One XP grant per full minute of continuous, eligible connection.
const VOICE_XP_INTERVAL_MS = 60_000;
// How often the ONE central timer re-checks every active session. Lower
// than the grant interval so grants land close to on-time, but still a
// single shared timer - never one per user/session (per spec: "لا
// تستخدم Timer منفصل لكل مستخدم").
const SWEEP_INTERVAL_MS = 20_000;

let sweepTimer = null;
let schedulerClient = null;

function sessionKey(guildId, userId) {
  return `${guildId}:${userId}`;
}

/**
 * Starts (or restarts) tracking for a member who just joined/moved into
 * `channel`. Resets the clock to a fresh interval - see file header for
 * why banking partial progress across a channel change is intentionally
 * not allowed.
 */
function trackSession(guild, member, channel) {
  sessions.set(sessionKey(guild.id, member.id), {
    guildId: guild.id,
    userId: member.id,
    channelId: channel.id,
    nextGrantAt: Date.now() + VOICE_XP_INTERVAL_MS,
  });
}

function untrackSession(guildId, userId) {
  sessions.delete(sessionKey(guildId, userId));
}

/**
 * Event-facing entry point - call on every `voiceStateUpdate`
 * (src/events/voice/voiceXpTracking.js). Only acts on an actual channel
 * change (join, leave, or move between channels); mute/deaf/streaming
 * toggles fire this same Discord event but leave channelId unchanged, so
 * they're ignored here exactly like afkRewardsService.js ignores them -
 * otherwise every such toggle would reset a member's progress and could
 * even be spammed to prevent them from ever completing an interval.
 */
function handleVoiceStateChange(oldState, newState) {
  const guild = newState.guild || oldState.guild;
  const userId = newState.id || oldState.id;
  if (!guild || !userId) return;

  if (oldState.channelId === newState.channelId) return; // no real move - ignore

  const member = newState.member;
  if (newState.channelId && newState.channel && member && !member.user.bot) {
    trackSession(guild, member, newState.channel);
  } else {
    // Left voice entirely, or the "member" we'd track isn't a usable
    // GuildMember (e.g. partial/uncached) - stop tracking rather than
    // risk a stale/incorrect session.
    untrackSession(guild.id, userId);
  }
}

/**
 * Full eligibility check, always re-derived from LIVE Discord state at
 * grant time (never cached from join time) - see file header. Returns
 * false for: feature disabled, excluded channel, excluded role,
 * Discord's native AFK channel, or fewer than `voiceMinMembers` human
 * members present (covers both "alone" and "alone with only bots" when
 * left at its default of 2).
 */
function isEligible(guild, member, channel, leveling) {
  if (!leveling?.enabled || !leveling?.voiceXpEnabled) return false;
  if (!channel) return false;
  if (member.user.bot) return false;
  if (guild.afkChannelId && channel.id === guild.afkChannelId) return false;

  const excludedChannelIds = leveling.excludedChannelIds || [];
  if (excludedChannelIds.includes(channel.id)) return false;

  const excludedRoleIds = leveling.excludedRoleIds || [];
  if (excludedRoleIds.length && excludedRoleIds.some((roleId) => member.roles?.cache?.has(roleId))) return false;

  // TASK27: configurable minimum human headcount (default 2, matching
  // TASK26's previous hardcoded rule) - see GuildConfig.js's
  // voiceMinMembers comment. Floored at 1 so a malformed/legacy value
  // (0, negative, missing) can never make an empty channel "eligible".
  const minMembers = Math.max(1, Math.floor(Number(leveling.voiceMinMembers) || 2));
  const humanCount = channel.members.filter((m) => !m.user.bot).size;
  if (humanCount < minMembers) return false;

  return true;
}

/**
 * Sends the same style of "🎉 Level Up!" embed messageCreate.js's
 * handleLeveling sends for a message-XP level-up, so a voice-XP level-up
 * looks and feels identical to the member - just triggered by voice
 * activity instead of a message. Falls back from the configured
 * announcement channel to the guild's system channel (voice XP has no
 * "channel the message was sent in" to fall back to the way message XP
 * does), and simply skips sending (never throws) if neither is usable.
 */
async function announceLevelUp(guild, member, guildConfig, newLevel, totalXp, grantedRoles) {
  const leveling = guildConfig.leveling;
  const settings = resolved(guildConfig);
  const channelId = leveling.announceChannelId || guild.systemChannelId;
  const channel = channelId ? guild.channels.cache.get(channelId) : null;
  if (!channel) return;

  const progress = getLevelProgress(totalXp);
  const cardAccent = leveling.card?.accentColor;
  const accentColor = typeof cardAccent === 'string' && /^#[0-9a-fA-F]{6}$/.test(cardAccent) ? cardAccent : settings.embedColor;

  const embed = baseEmbed(settings)
    .setColor(accentColor)
    .setTitle('🎉 Level Up!')
    .setDescription(`${member} just reached **level ${newLevel}** from voice activity!`)
    .setThumbnail(member.user.displayAvatarURL())
    .addFields(
      { name: 'New Level', value: `${newLevel}`, inline: true },
      { name: 'Total XP', value: `${progress.totalXp.toLocaleString()}`, inline: true },
      { name: 'Next Level', value: `${progress.currentXp.toLocaleString()} / ${progress.xpNeeded.toLocaleString()} XP`, inline: true }
    );

  if (grantedRoles.length) {
    embed.addFields({
      name: grantedRoles.length > 1 ? '🎁 Rewards' : '🎁 Reward',
      value: grantedRoles.map((role) => `<@&${role.id}>`).join(', '),
    });
  }

  channel.send({ embeds: [embed] }).catch(() => null);
}

/**
 * Grants XP for exactly one completed interval for a single session, if
 * (and only if) it's still eligible right now. Never throws - every
 * error is caught/logged by sweep() below so one bad session can never
 * stop the rest of the tick from running.
 */
async function processSession(client, session) {
  const guild = client.guilds.cache.get(session.guildId);
  if (!guild) {
    untrackSession(session.guildId, session.userId);
    return;
  }

  const member = guild.members.cache.get(session.userId);
  const channel = member?.voice?.channelId ? guild.channels.cache.get(member.voice.channelId) : null;

  // Member is no longer actually connected to the channel we're tracking
  // (e.g. a missed/out-of-order voiceStateUpdate during a brief gateway
  // hiccup) - drop the stale session instead of ticking on it forever.
  if (!member || !channel || channel.id !== session.channelId) {
    untrackSession(session.guildId, session.userId);
    return;
  }

  const guildConfig = await getGuildConfig(session.guildId);
  const leveling = guildConfig?.leveling;

  // Always schedule the next check up front, whether or not this tick
  // actually grants XP - a disabled feature or a temporarily-ineligible
  // channel must not make the session "fall behind" and then pay out a
  // burst of grants once it becomes eligible again.
  session.nextGrantAt = Date.now() + VOICE_XP_INTERVAL_MS;

  if (!isEligible(guild, member, channel, leveling)) return;

  const baseAmount = Math.max(0, Math.floor(Number(leveling.voiceXpPerMinute) || 0));
  if (baseAmount <= 0) return;

  // TASK25/TASK26: same role-based multiplier message XP uses - see
  // levelingService.js's getXpMultiplier(). No separate multiplier
  // system for voice.
  const multiplier = getXpMultiplier(member, leveling);
  const finalAmount = Math.max(1, Math.round(baseAmount * multiplier));

  const { leveledUp, newLevel, previousLevel, totalXp } = await grantVoiceXp(session.guildId, session.userId, finalAmount);
  if (!leveledUp) return;

  let grantedRoles = [];
  try {
    grantedRoles = await grantLevelRewards(guild, member, guildConfig, previousLevel, newLevel);
  } catch (err) {
    // grantLevelRewards already catches/logs per-reward errors - this is
    // a last-resort net so an unexpected throw here still can't stop the
    // announcement below (matches handleLeveling's own safety net).
    logger.error(`[Voice XP] Level reward grant failed for ${member.id} in guild ${guild.id}: ${err?.stack || err}`);
  }

  if (leveling.announceLevelUp !== false) {
    await announceLevelUp(guild, member, guildConfig, newLevel, totalXp, grantedRoles);
  }
}

/** The ONE central tick - iterates every tracked session and processes the ones due for a check. Never a timer per user/session. */
async function sweep(client) {
  for (const session of sessions.values()) {
    if (session.nextGrantAt > Date.now()) continue;
    try {
      // eslint-disable-next-line no-await-in-loop
      await processSession(client, session);
    } catch (err) {
      logger.error(`[Voice XP] Failed to process session for ${session.userId} in guild ${session.guildId}: ${err?.stack || err}`);
      // Push the next check out a full interval so a persistently
      // failing session (e.g. a transient Mongo error) can't spin the
      // sweep tight in a retry loop.
      session.nextGrantAt = Date.now() + VOICE_XP_INTERVAL_MS;
    }
  }
}

/**
 * Rebuilds `sessions` from the members ALREADY connected to voice
 * channels at startup (bot restart/redeploy), so an ongoing voice
 * session isn't silently un-tracked until someone happens to
 * leave/rejoin. Mirrors the existing `cacheGuildInvites` startup loop in
 * events/client/ready.js. Never grants XP itself - just seeds sessions
 * with a fresh interval, same as a normal join.
 */
function primeActiveSessions(client) {
  for (const guild of client.guilds.cache.values()) {
    for (const channel of guild.channels.cache.values()) {
      if (!channel.isVoiceBased?.() || !channel.members) continue;
      for (const member of channel.members.values()) {
        if (member.user.bot) continue;
        trackSession(guild, member, channel);
      }
    }
  }
}

/**
 * Starts the single shared sweep timer (bot3/Systems only - see
 * events/client/ready.js and config/botEventMap.js). Safe to call more
 * than once - clears any existing timer first so a hot-reload/dev
 * restart can never end up with two ticks racing each other.
 */
function startVoiceXpScheduler(client) {
  stopVoiceXpScheduler();
  schedulerClient = client;
  primeActiveSessions(client);
  sweepTimer = setInterval(() => sweep(client), SWEEP_INTERVAL_MS);
  sweepTimer.unref?.();
}

/** Stops the sweep timer and forgets every tracked session. Called on bot shutdown (src/index.js) so a graceful exit doesn't leave a dangling interval. */
function stopVoiceXpScheduler() {
  if (sweepTimer) {
    clearInterval(sweepTimer);
    sweepTimer = null;
  }
  sessions.clear();
  schedulerClient = null;
}

module.exports = {
  handleVoiceStateChange,
  startVoiceXpScheduler,
  stopVoiceXpScheduler,
};
