const { PermissionFlagsBits } = require('discord.js');
const { baseEmbed } = require('../utils/embeds');
const logger = require('../utils/logger');

/**
 * Smart-ticket-ping: brings `target` into a ticket on a staff member's
 * behalf.
 *
 * - Grants ViewChannel/SendMessages/ReadMessageHistory on the ticket
 *   channel if `target` doesn't already have them - that's what "شخص خارج
 *   التكت" (someone outside the ticket) means in practice: they can't see
 *   the channel yet, so a raw @mention would ping them into a room they
 *   can't open.
 * - Sends the actual highlighted ping itself, as a clean bot message,
 *   instead of leaving the moderator's raw mention as the visible record.
 * - Optionally logs the action to guildConfig.tickets.logChannelId - a
 *   no-op if that's not configured, same convention as the closed-ticket
 *   transcript log.
 *
 * @param {object} params
 * @param {import('discord.js').TextChannel} params.channel - the ticket channel
 * @param {*} params.guildConfig - raw GuildConfig mongoose doc
 * @param {*} params.settings - resolved() settings, for embed color/footer
 * @param {*} params.ticket - the Ticket mongoose doc for this channel
 * @param {import('discord.js').User} params.requestedBy - the staff member who asked for `target`
 * @param {import('discord.js').User} params.target - the member being summoned
 * @param {string|null} [params.reason]
 * @returns {Promise<{ grantedAccess: boolean, notifyMessage: import('discord.js').Message }>}
 */
async function notifyMember({ channel, guildConfig, settings, ticket, requestedBy, target, reason }) {
  const targetMember = await channel.guild.members.fetch(target.id).catch((err) => {
    logger.warn(`تعذر جلب العضو ${target.id} قبل استدعائه إلى التذكرة #${ticket.ticketNumber}: ${err.message}`);
    return null;
  });
  const currentPerms = targetMember ? channel.permissionsFor(targetMember) : null;
  const grantedAccess = !currentPerms?.has(PermissionFlagsBits.ViewChannel);

  if (grantedAccess) {
    await channel.permissionOverwrites.edit(target.id, {
      ViewChannel: true,
      SendMessages: true,
      ReadMessageHistory: true,
    });
  }

  const embed = baseEmbed(settings)
    .setTitle('🔔・استدعاء داخل التذكرة')
    .setDescription(
      grantedAccess
        ? `تمت إضافة ${target} إلى هذه التذكرة بواسطة ${requestedBy}.`
        : `تم استدعاء ${target} إلى هذه التذكرة بواسطة ${requestedBy}.`
    );
  if (reason) embed.addFields({ name: '📝 سبب الاستدعاء', value: reason });

  const notifyMessage = await channel.send({ content: `${target}`, embeds: [embed] });

  await logTicketNotify(channel.guild, guildConfig, settings, { ticket, requestedBy, target, reason, grantedAccess });

  return { grantedAccess, notifyMessage };
}

/** Posts an optional audit entry for a smart-ping to tickets.logChannelId. Silently no-ops if unset/unreachable. */
async function logTicketNotify(guild, guildConfig, settings, { ticket, requestedBy, target, reason, grantedAccess }) {
  const channelId = guildConfig.tickets.logChannelId;
  if (!channelId) return;

  const logChannel = guild.channels.cache.get(channelId);
  if (!logChannel) return;

  const embed = baseEmbed(settings)
    .setTitle(`🔔・استدعاء عضو — تذكرة #${ticket.ticketNumber}`)
    .addFields(
      { name: '🎫 التذكرة', value: `<#${ticket.channelId}>`, inline: true },
      { name: '👤 بواسطة', value: `${requestedBy}`, inline: true },
      { name: '🔔 العضو المُستدعى', value: `${target}`, inline: true },
      { name: '🔐 صلاحية الوصول', value: grantedAccess ? 'تمت إضافته للتذكرة ✅' : 'كانت لديه بالفعل', inline: true }
    );
  if (reason) embed.addFields({ name: '📝 السبب', value: reason });

  await logChannel.send({ embeds: [embed] }).catch((err) => {
    logger.warn(`تعذر إرسال سجل استدعاء العضو للتذكرة #${ticket.ticketNumber}: ${err.message}`);
  });
}

module.exports = { notifyMember };
