const fs = require('node:fs');
const path = require('node:path');
const logger = require('../utils/logger');

// ═══════════════════════════════════════════════════════════════════════════
// TASK 24 — Legacy Handler Ownership Table
// ═══════════════════════════════════════════════════════════════════════════
//
// جدول ملكية Legacy Handlers — يحدد أي بوت يمتلك كل Handler.
//
// القاعدة: كل Handler يُسجَّل فقط على البوت الذي يخصه.
// لا يتم حذف أي Handler — الملكية تُطبَّق عبر فلترة وقت التحميل فقط.
//
// Bot 1 — Music    : bot1
// Bot 2 — Management (Tickets / Moderation / Broadcast) : bot2
// Bot 3 — Systems  (Giveaway / Apply / Suggestions / AutoRole / etc.) : bot3
//
// ┌─────────────────────────┬──────────────────────────────────────────────┬──────┐
// │ الملف                   │ الوظيفة                                      │ Bot  │
// ├─────────────────────────┼──────────────────────────────────────────────┼──────┤
// │ create.js               │ فتح تذكرة جديدة (ticketDB / st.db)          │ bot2 │
// │ close.js                │ إغلاق التذكرة (Yes11 / No11 buttons)        │ bot2 │
// │ claim.js                │ استلام التذكرة (claim_ button)               │ bot2 │
// │ support-panel.js        │ لوحة التحكم (supportPanel select menu)       │ bot2 │
// │ reset.js                │ ticket_select reset — no-op                  │ bot2 │
// │ sendBroadcast.js        │ إرسال البرودكاست (run_broadcast_button)      │ bot2 │
// │ setBroadcastMessage.js  │ تحديد رسالة البرودكاست (Modal)              │ bot2 │
// ├─────────────────────────┼──────────────────────────────────────────────┼──────┤
// │ joinGiveaway.js         │ الانضمام للسحب (join_giveaway button)        │ bot3 │
// │ suggest.js              │ التصويت على الاقتراح (ok_button / no_button) │ bot3 │
// │ applySubmit.js          │ إرسال نموذج التقديم (modal_apply)            │ bot3 │
// │ applyResult.js          │ قبول/رفض التقديم (apply_accept/reject)       │ bot3 │
// │ applyCreate.js          │ فتح نموذج التقديم (apply_button)             │ bot3 │
// │ autorole.js             │ منح/سحب رتبة (getrole_ button)               │ bot3 │
// │ info.js                 │ عرض رسالة مخزنة (info_ button)               │ bot3 │
// │ tax4bot.js              │ عرض قيمة ضريبة (tax_ / mediator_ button)    │ bot3 │
// └─────────────────────────┴──────────────────────────────────────────────┴──────┘
//
// ملاحظة: events.js مُستثنى دائمًا من التحميل (يُعالَج بشكل منفصل).
//
// التغييرات في هذه المهمة (Task 24):
//   - تحديد الملكية لكل Handler بشكل رسمي وموثق في هذا الملف.
//   - إضافة BOT3_ONLY_HANDLERS كمقابل لـ BOT2_ONLY_TICKET_HANDLERS.
//   - تطبيق الفلترة على Bot 1 (Music): لا يُحمّل أي Legacy Handler
//     لأن جميع الـ Handlers هي إما Ticket (bot2) أو Systems (bot3)
//     وليس هناك أي Handler يخص الموسيقى.
//   - Bot 2 يحمّل: Ticket Handlers + Broadcast Handlers.
//   - Bot 3 يحمّل: Giveaway + Apply + Suggestions + AutoRole + Info + Tax.
// ═══════════════════════════════════════════════════════════════════════════

// Legacy Handlers التي تخص Bot 2 — Management فقط
// (Tickets + Broadcast)
const BOT2_ONLY_HANDLERS = new Set([
  'create.js',           // فتح تذكرة — ticketDB
  'close.js',            // إغلاق تذكرة — Yes11/No11
  'claim.js',            // استلام تذكرة — claim_ button
  'support-panel.js',    // لوحة تحكم Support — supportPanel select
  'reset.js',            // ticket_select reset — no-op
  'sendBroadcast.js',    // إرسال البرودكاست — run_broadcast_button
  'setBroadcastMessage.js', // تحديد رسالة البرودكاست — Modal
]);

// Legacy Handlers التي تخص Bot 3 — Systems فقط
const BOT3_ONLY_HANDLERS = new Set([
  'joinGiveaway.js',     // الانضمام للسحب — join_giveaway
  'suggest.js',          // التصويت — ok_button / no_button
  'applySubmit.js',      // إرسال نموذج التقديم — modal_apply
  'applyResult.js',      // قبول/رفض التقديم — apply_accept / apply_reject
  'applyCreate.js',      // فتح نموذج التقديم — apply_button
  'autorole.js',         // منح/سحب رتبة — getrole_ button
  'info.js',             // عرض رسالة مخزنة — info_ button
  'tax4bot.js',          // عرض قيمة ضريبة — tax_ / mediator_ button
]);

/**
 * هل يُحمَّل هذا الملف على البوت المحدد؟
 *
 * TASK 06 — تمييز صريح بين 3 حالات بدلاً من fallback واحد يُحمّل كل شيء
 * لأي قيمة غير bot1/bot2/bot3 (بما فيها قيم غير صحيحة بالخطأ):
 *
 *   1) Unified Bot   — botKey غير معرّف (undefined/null) أو === 'unified'.
 *      هذا هو نفس المعيار المستخدم فعليًا في بقية المشروع
 *      (commandHandler.js، eventHandler.js، وكل ملفات events/ التي تفحص
 *      `!botKey || botKey === 'unified'`) — لذلك البوت الموحد في مسار
 *      الإنتاج (src/index.js -> botManager.initializeBot يترك botKey غير
 *      معرّف عمدًا) يستمر بتحميل جميع الـLegacy Handlers كما كان، بدون
 *      أي تغيير في السلوك الحالي.
 *   2) Bot محدد (bot1/bot2/bot3) — يحمّل حسب جدول الملكية كما هو.
 *   3) قيمة غير معروفة/غير صالحة — لا تُعامَل كـUnified ولا يتم تحميل كل
 *      شيء عشوائيًا؛ السلوك الآمن هو عدم التحميل مع تسجيل تحذير واضح
 *      لتتبّع الحالة، بدل افتراض ضمني قد يخفي خطأ في تمرير botKey.
 *
 * @param {string} file اسم الملف
 * @param {string|undefined|null} botKey مفتاح البوت
 * @returns {boolean}
 */
function shouldLoadHandler(file, botKey) {
  // Unified Bot: نفس معيار "!botKey || botKey === 'unified'" المستخدم في
  // بقية المشروع. البوت الموحد يستمر بتحميل جميع الـLegacy Handlers.
  if (!botKey || botKey === 'unified') return true;

  // bot1 (Music): لا يمتلك أي Legacy Handler
  if (botKey === 'bot1') return false;

  // bot2 (Management): يحمّل BOT2_ONLY_HANDLERS فقط
  if (botKey === 'bot2') return BOT2_ONLY_HANDLERS.has(file);

  // bot3 (Systems): يحمّل BOT3_ONLY_HANDLERS فقط
  if (botKey === 'bot3') return BOT3_ONLY_HANDLERS.has(file);

  // botKey غير معروف/غير صالح: لا نفترض أنه Unified، ولا نحمّل كل شيء
  // بشكل عشوائي. سلوك آمن: تخطي التحميل + تحذير صريح في الـlogs.
  logger.warn(`loadLegacyHandlers: unrecognized botKey "${botKey}" — skipping legacy handler "${file}" (not treated as unified; verify how botKey is being set)`);
  return false;
}

function loadLegacyHandlers(client) {
  const handlersPath = path.join(__dirname, '..', 'legacy-handlers');
  const botKey = client.botKey;

  // Mirrors the same resilience fixed in utils/fileWalker.js (commands/events
  // loaders): this directory read used to be unguarded, so a missing or
  // unreadable legacy-handlers folder would throw straight out of this
  // function and abort startup before any command/event/legacy handler had
  // a chance to load. It now degrades to "0 legacy handlers loaded" with a
  // clear warning instead.
  let entries;
  try {
    entries = fs.readdirSync(handlersPath);
  } catch (error) {
    logger.warn(`loadLegacyHandlers: could not read legacy-handlers directory (${handlersPath}): ${error.message}`);
    entries = [];
  }

  const files = entries
    .filter((file) => file.endsWith('.js') && file !== 'events.js')
    .filter((file) => shouldLoadHandler(file, botKey))
    .sort();

  let loaded = 0;
  let skipped = 0;
  for (const file of files) {
    const fullPath = path.join(handlersPath, file);
    try {
      delete require.cache[require.resolve(fullPath)];
      const register = require(fullPath);
      if (typeof register !== 'function') {
        skipped += 1;
        logger.warn(`Skipping legacy handler without a registrar: ${file}`);
        continue;
      }
      register(client);
      loaded += 1;
    } catch (error) {
      skipped += 1;
      logger.warn(`Skipping legacy handler ${file}: ${error.message}`);
    }
  }

  logger.success(`[${botKey || 'unknown'}] Loaded ${loaded} legacy compatibility handlers${skipped ? ` (${skipped} skipped safely)` : ''}`);
}

module.exports = loadLegacyHandlers;
