'use strict';

/**
 * Task 46 — Command Router (موجّه الأوامر المركزي).
 *
 * هذا الملف يوحّد نقطة الدخول لجميع الأوامر التي تفتح الأنظمة
 * والواجهات التفاعلية، بدلاً من وجود كود مكرر لفحص الصلاحيات
 * وتسجيل العملية في كل أمر على حدة.
 *
 * المسؤوليات:
 *  1. التحقق من الصلاحيات (isGuildManager / isModerator / isOwner)
 *     بناءً على مستوى الأمر المطلوب.
 *  2. فتح الواجهة المناسبة (admin / settings / tickets / …)
 *     عن طريق استدعاء builder الصحيح من ملفات dashboard.
 *  3. تسجيل العملية عبر Logger (بدون أي Tokens أو Secrets).
 *  4. معالجة الأخطاء مركزياً بدلاً من تكرارها في كل أمر.
 *
 * الاستخدام:
 *   const { routeCommand } = require('../../utils/commandRouter');
 *
 *   // في execute() لأي أمر:
 *   return routeCommand(interaction, 'admin');
 *   return routeCommand(interaction, 'settings');
 *   return routeCommand(interaction, 'tickets');
 *   // …إلخ
 *
 * كيف يُحدَّد مستوى الصلاحية لكل نظام:
 *   'admin'    → isGuildManager (Administrator / ManageGuild / adminRoleId)
 *   'settings' → isGuildManager
 *   'tickets'  → isGuildManager
 *   'moderation' → isModerator (يشمل isGuildManager + modRoleId)
 *   'owner'    → isOwner فقط (مالك البوت)
 *
 * ملاحظة: لا يتم هنا حذف أي أمر قائم أو تعديل سلوكه؛
 * الـ Router يُضاف كطبقة مركزية بجانب الأوامر الموجودة.
 */

const { EmbedBuilder } = require('discord.js');
const { COLORS, ICONS } = require('./designSystem');
const { isGuildManager, isModerator, isOwner } = require('./permissions');
const { getGuildConfig, resolved } = require('./resolveGuildSettings');
const { errorEmbed } = require('./embeds');
const logger = require('./logger');

// ─── خريطة الأنظمة ──────────────────────────────────────────────────────────
// كل مدخل يربط اسم النظام بـ:
//   requiredLevel : مستوى الصلاحية المطلوب
//   getBuilder    : دالة lazy تُرجع builder الـ dashboard (lazy لتجنب
//                   حلقات require عند تحميل الملف أول مرة)
//   labelAr       : اسم عربي للتسجيل
// ─────────────────────────────────────────────────────────────────────────────
const SYSTEM_MAP = {
  admin: {
    requiredLevel: 'manager',
    labelAr: 'لوحة الإدارة المركزية',
    getBuilder: () => require('./adminDashboard').buildHomeView,
  },
  settings: {
    requiredLevel: 'manager',
    labelAr: 'لوحة الإعدادات العامة',
    getBuilder: () => require('./settingsDashboard').buildHomeView,
  },
  tickets: {
    requiredLevel: 'manager',
    labelAr: 'لوحة التذاكر',
    getBuilder: () => require('./ticketDashboard').buildHomeView,
  },
  moderation: {
    requiredLevel: 'moderator',
    labelAr: 'لوحة الإشراف',
    getBuilder: () => require('./moderationSettingsDashboard').buildModerationSettingsView,
  },
  logging: {
    requiredLevel: 'manager',
    labelAr: 'لوحة السجلات',
    getBuilder: () => require('./loggingDashboard').buildLoggingView,
  },
  welcome: {
    requiredLevel: 'manager',
    labelAr: 'لوحة الترحيب',
    getBuilder: () => require('./welcomeDashboard').buildWelcomeView,
  },
  protection: {
    requiredLevel: 'manager',
    labelAr: 'لوحة الحماية',
    getBuilder: () => require('./protectionDashboard').buildProtectionView,
  },
  leveling: {
    requiredLevel: 'manager',
    labelAr: 'لوحة المستويات',
    getBuilder: () => require('./levelingDashboard').buildLevelingView,
  },
  economy: {
    requiredLevel: 'manager',
    labelAr: 'لوحة الاقتصاد',
    getBuilder: () => require('./economyDashboard').buildEconomyView,
  },
  music: {
    requiredLevel: 'manager',
    labelAr: 'لوحة الموسيقى',
    getBuilder: () => require('./musicDashboard').buildMusicView,
  },
  giveaways: {
    requiredLevel: 'manager',
    labelAr: 'لوحة السحوبات',
    getBuilder: () => require('./giveawaysDashboard').buildGiveawaysView,
  },
  broadcast: {
    requiredLevel: 'manager',
    labelAr: 'لوحة البث',
    getBuilder: () => require('./broadcastDashboard').buildBroadcastView,
  },
  system: {
    requiredLevel: 'manager',
    labelAr: 'لوحة النظام',
    getBuilder: () => require('./systemDashboard').buildSystemView,
  },
};

// ─── فحص الصلاحيات ──────────────────────────────────────────────────────────
/**
 * يُرجع true إذا كان العضو يملك المستوى المطلوب.
 * @param {string} requiredLevel - 'manager' | 'moderator' | 'owner'
 * @param {import('discord.js').GuildMember} member
 * @param {*} guildConfig
 * @returns {boolean}
 */
function hasRequiredLevel(requiredLevel, member, guildConfig) {
  switch (requiredLevel) {
    case 'owner':
      return isOwner(member.id);
    case 'moderator':
      return isModerator(member, guildConfig);
    case 'manager':
    default:
      return isGuildManager(member, guildConfig);
  }
}

/**
 * يُرجع نص رسالة الخطأ العربية/الإنجليزية المناسبة للمستوى المطلوب.
 */
function permissionDeniedMessage(requiredLevel) {
  switch (requiredLevel) {
    case 'owner':
      return 'هذه العملية متاحة لمالك البوت فقط. / This action is restricted to the bot owner only.';
    case 'moderator':
      return 'تحتاج صلاحية مشرف أو أعلى لفتح هذا النظام. / You need Moderator or higher permission to open this system.';
    case 'manager':
    default:
      return 'تحتاج صلاحية إدارة السيرفر لفتح هذا النظام. / You need Manage Server or higher permission to open this system.';
  }
}

// ─── الدالة الرئيسية ─────────────────────────────────────────────────────────
/**
 * يوجّه تفاعل `/command` إلى الواجهة المناسبة بعد فحص الصلاحيات.
 *
 * @param {import('discord.js').ChatInputCommandInteraction} interaction
 * @param {string} systemKey - مفتاح النظام من SYSTEM_MAP أعلاه
 * @param {object} [options]
 * @param {*}      [options.guildConfig]   - إذا كان الأمر محمّله بالفعل تجنب استدعاء إضافي
 * @param {boolean} [options.ephemeral]    - هل الرد سري (افتراضي: true)
 * @returns {Promise<void>}
 */
async function routeCommand(interaction, systemKey, options = {}) {
  const { ephemeral = true } = options;

  // ── التحقق من وجود النظام ──────────────────────────────────────────────
  const systemDef = SYSTEM_MAP[systemKey];
  if (!systemDef) {
    logger.warn(`[CommandRouter] Unknown system key requested: "${systemKey}" by user ${interaction.user.id}`);
    const embed = new EmbedBuilder()
      .setColor(COLORS.error)
      .setDescription(`${ICONS.error} هذا النظام غير متاح حالياً. / This system is not currently available.`);
    return interaction.reply({ embeds: [embed], ephemeral: true });
  }

  // ── تحميل إعدادات السيرفر ──────────────────────────────────────────────
  let guildConfig = options.guildConfig ?? null;
  if (!guildConfig && interaction.guildId) {
    guildConfig = await getGuildConfig(interaction.guildId);
  }
  const settings = resolved(guildConfig || {});

  // ── فحص الصلاحيات ─────────────────────────────────────────────────────
  if (!hasRequiredLevel(systemDef.requiredLevel, interaction.member, guildConfig)) {
    logger.warn(
      `[CommandRouter] Permission denied: user ${interaction.user.username} (${interaction.user.id}) ` +
      `tried to open "${systemKey}" in guild ${interaction.guildId} ` +
      `— required level: ${systemDef.requiredLevel}`
    );
    return interaction.reply({
      embeds: [errorEmbed(settings, permissionDeniedMessage(systemDef.requiredLevel))],
      ephemeral: true,
    });
  }

  // ── تسجيل العملية ─────────────────────────────────────────────────────
  logger.info(
    `[CommandRouter] ${interaction.user.username} (${interaction.user.id}) ` +
    `opened "${systemKey}" (${systemDef.labelAr}) ` +
    `in guild ${interaction.guildId ?? 'DM'} via /${interaction.commandName}`
  );

  // ── بناء الواجهة وإرسالها ─────────────────────────────────────────────
  try {
    const builder = systemDef.getBuilder();

    // بعض الـ builders تأخذ (settings, guildName) وبعضها (settings, guildConfig, …)
    // نمرر الاثنين ونترك البيلدر يأخذ ما يحتاج
    const guildName = interaction.guild?.name ?? 'Server';
    const result = await Promise.resolve(builder(settings, guildName, guildConfig, interaction));

    if (!result || (!result.embeds && !result.components)) {
      // بعض الـ builders ترجع payload مباشرة بدل { embeds, components }
      // مثل systemDashboard الذي يُرجع { embeds, components, ephemeral }
      const payload = result ?? {};
      return interaction.reply({ ...payload, ephemeral: payload.ephemeral ?? ephemeral });
    }

    return interaction.reply({ embeds: result.embeds, components: result.components, ephemeral });
  } catch (err) {
    logger.error(
      `[CommandRouter] Failed to build view for "${systemKey}": ${err.stack || err}`
    );
    return interaction.reply({
      embeds: [errorEmbed(settings, 'حدث خطأ أثناء تحميل هذا النظام. / An error occurred while loading this system.')],
      ephemeral: true,
    });
  }
}

// ─── دوال مساعدة للأوامر ─────────────────────────────────────────────────────

/**
 * يُرجع قائمة الأنظمة المتاحة للمستخدم بناءً على صلاحياته.
 * مفيد لأوامر تعرض قائمة بالأنظمة التي يملك المستخدم صلاحية الوصول إليها.
 *
 * @param {import('discord.js').GuildMember} member
 * @param {*} guildConfig
 * @returns {string[]} - مفاتيح الأنظمة المسموح بها
 */
function getAccessibleSystems(member, guildConfig) {
  return Object.entries(SYSTEM_MAP)
    .filter(([, def]) => hasRequiredLevel(def.requiredLevel, member, guildConfig))
    .map(([key]) => key);
}

/**
 * يُرجع تعريف نظام معين من SYSTEM_MAP. مفيد لعرض معلومات عنه.
 *
 * @param {string} systemKey
 * @returns {{ requiredLevel: string, labelAr: string } | null}
 */
function getSystemInfo(systemKey) {
  const def = SYSTEM_MAP[systemKey];
  if (!def) return null;
  return { requiredLevel: def.requiredLevel, labelAr: def.labelAr };
}

module.exports = { routeCommand, getAccessibleSystems, getSystemInfo, SYSTEM_MAP };
