/**
 * Tasks 38–45 — Settings Dashboard (`/settings`).
 *
 * Shared view builder for the public settings entry point and its component
 * handlers. Each section is now routed to its own dedicated builder so the
 * admin sees live, interactive controls instead of a placeholder.
 *
 * Sections with real UIs (Task → section):
 *   39  → logging         (loggingDashboard)
 *   40  → welcome         (welcomeDashboard)
 *   41  → protection      (protectionDashboard)
 *   45  → leveling        (levelingDashboard)
 *   45  → economy         (economyDashboard)
 *   45  → moderation      (moderationSettingsDashboard)
 *   45  → music           (musicDashboard)
 *   45  → giveaways       (giveawaysDashboard)   [async]
 *   45  → broadcast       (broadcastDashboard)   [async]
 *   45  → system          (systemDashboard)
 *
 * Sections that still use the placeholder (managed via commands):
 *   tickets  → /tickets command / ticketDashboard
 *   automod  → /automod command / protectionDashboard sub-page
 */
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder } = require('discord.js');
const { COLORS, ICONS } = require('./designSystem');
const { buildLoggingView }              = require('./loggingDashboard');
const { buildWelcomeView }              = require('./welcomeDashboard');
const { buildProtectionView }           = require('./protectionDashboard');
const { buildLevelingView }             = require('./levelingDashboard');
const { buildEconomyView }              = require('./economyDashboard');
const { buildModerationSettingsView }   = require('./moderationSettingsDashboard');
const { buildMusicView }                = require('./musicDashboard');
const { buildSystemView }               = require('./systemDashboard');
// Async builders (need await at call site)
const { buildGiveawaysView }            = require('./giveawaysDashboard');
const { buildBroadcastView }            = require('./broadcastDashboard');
// Task-09 community sections
const {
  buildSuggestionsView, buildBoosterView, buildMemberCountView,
  buildStarboardView, buildCountingView,
} = require('./communityDashboard');

const SETTINGS_SECTIONS = [
  { id: 'tickets',    icon: ICONS.tickets,    nameAr: 'التذاكر',          nameEn: 'Tickets',    descAr: 'إعدادات نظام الدعم والتذاكر ولوحات فتح التذاكر' },
  { id: 'moderation', icon: ICONS.moderation, nameAr: 'الإشراف',          nameEn: 'Moderation', descAr: 'أدوار وصلاحيات وأدوات الإشراف على الأعضاء' },
  { id: 'protection', icon: ICONS.security,   nameAr: 'الحماية',          nameEn: 'Protection', descAr: 'الحماية من Anti-Raid وAnti-Nuke والاعتداءات' },
  { id: 'giveaways',  icon: ICONS.giveaway,   nameAr: 'السحوبات',         nameEn: 'Giveaways',  descAr: 'إعدادات سحوبات الجوائز وإدارتها' },
  { id: 'economy',    icon: ICONS.economy,    nameAr: 'الاقتصاد',         nameEn: 'Economy',    descAr: 'إعدادات العملات والمتجر والمكافآت' },
  { id: 'leveling',   icon: ICONS.leveling,   nameAr: 'المستويات',        nameEn: 'Leveling',   descAr: 'إعدادات الخبرة والمستويات ورتب المكافآت' },
  { id: 'welcome',    icon: ICONS.welcome,    nameAr: 'الترحيب',          nameEn: 'Welcome',    descAr: 'رسائل الترحيب والمغادرة وإعدادات الأعضاء الجدد' },
  { id: 'logging',    icon: ICONS.logging,    nameAr: 'السجلات',          nameEn: 'Logging',    descAr: 'قنوات وأنواع الأحداث التي يتم تسجيلها' },
  { id: 'automod',    icon: ICONS.automod,    nameAr: 'الحماية التلقائية', nameEn: 'AutoMod',    descAr: 'فلترة الروابط والسبام والكلمات والمحتوى المخالف' },
  { id: 'broadcast',  icon: ICONS.broadcast,  nameAr: 'البث',             nameEn: 'Broadcast',  descAr: 'إعدادات الإعلانات والبث إلى أعضاء السيرفر' },
  { id: 'music',      icon: ICONS.music,      nameAr: 'الموسيقى',         nameEn: 'Music',      descAr: 'إعدادات مشغل الموسيقى وقنوات الصوت' },
  { id: 'system',     icon: ICONS.system,     nameAr: 'النظام',           nameEn: 'System',     descAr: 'حالة البوت وإعدادات السيرفر العامة' },
  { id: 'suggestions', icon: '💡', nameAr: 'الاقتراحات',    nameEn: 'Suggestions',  descAr: 'إعداد قناة الاقتراحات وتفعيلها' },
  { id: 'booster',     icon: '🚀', nameAr: 'إعلانات Boost', nameEn: 'Booster',      descAr: 'رسائل إعلانات تعزيز السيرفر' },
  { id: 'membercount', icon: '👥', nameAr: 'عداد الأعضاء',  nameEn: 'Member Count', descAr: 'قناة تعرض عدد الأعضاء بشكل تلقائي' },
  { id: 'starboard',   icon: '⭐', nameAr: 'لوحة النجوم',   nameEn: 'Starboard',    descAr: 'تمييز الرسائل الشعبية بنجوم' },
  { id: 'counting',    icon: '🔢', nameAr: 'لعبة العد',     nameEn: 'Counting',     descAr: 'لعبة العد التصاعدي في قناة مخصصة' },
];

const NAV_SELECT_ID  = 'settings_nav';
const HOME_BUTTON_ID = 'settings_home';
const BACK_BUTTON_ID = 'settings_back';
const CLOSE_BUTTON_ID = 'settings_close';

function findSection(id) {
  return SETTINGS_SECTIONS.find((s) => s.id === id) || null;
}

function closeButton() {
  return new ButtonBuilder()
    .setCustomId(CLOSE_BUTTON_ID)
    .setLabel('إغلاق / Close')
    .setEmoji(ICONS.close)
    .setStyle(ButtonStyle.Danger);
}

function navigationRow() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(BACK_BUTTON_ID).setLabel('رجوع / Back').setEmoji(ICONS.back).setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(HOME_BUTTON_ID).setLabel('الرئيسية / Home').setEmoji(ICONS.home).setStyle(ButtonStyle.Secondary),
    closeButton(),
  );
}

function buildHomeView(settings, guildName) {
  const embed = new EmbedBuilder()
    .setColor(COLORS.primary)
    .setTitle(`${ICONS.settings}・لوحة الإعدادات العامة`)
    .setDescription(
      `مرحبًا **${guildName}**، هذه لوحة الإعدادات العامة للبوت.\n` +
      'اختر النظام الذي تريد إدارته من القائمة أدناه.\n\n' +
      '**الأقسام المتاحة:**'
    )
    .addFields(
      SETTINGS_SECTIONS.map((s) => ({
        name: `${s.icon} ${s.nameAr} (${s.nameEn})`,
        value: s.descAr,
        inline: true,
      }))
    )
    .setFooter({ text: settings.footer })
    .setTimestamp();

  const select = new StringSelectMenuBuilder()
    .setCustomId(NAV_SELECT_ID)
    .setPlaceholder('اختر قسم الإعدادات... / Choose a settings section')
    .addOptions(
      SETTINGS_SECTIONS.map((s) => ({
        label: `${s.nameAr} (${s.nameEn})`,
        description: s.descAr.slice(0, 100),
        value: s.id,
        emoji: s.icon,
      }))
    );

  return {
    embeds: [embed],
    components: [new ActionRowBuilder().addComponents(select), new ActionRowBuilder().addComponents(closeButton())],
  };
}

/**
 * Build the view for a specific settings section.
 *
 * For sections backed by async builders (giveaways, broadcast) this
 * function returns a Promise — callers must await it.
 * For all other sections it returns the view object synchronously.
 *
 * @param {object}  settings    - resolved guild settings
 * @param {string}  sectionId   - section identifier
 * @param {object}  guildConfig - raw GuildConfig document (may be null)
 * @param {object}  [client]    - Discord.js Client (needed for 'system')
 */
function buildSectionView(settings, sectionId, guildConfig = null, client = null) {
  const section = findSection(sectionId);
  if (!section) return null;

  // ── Sections with real interactive UIs ────────────────────────────────
  if (sectionId === 'logging' && guildConfig)    return buildLoggingView(settings, guildConfig);
  if (sectionId === 'welcome' && guildConfig)    return buildWelcomeView(settings, guildConfig);
  if (sectionId === 'protection' && guildConfig) return buildProtectionView(settings, guildConfig);
  if (sectionId === 'leveling' && guildConfig)   return buildLevelingView(settings, guildConfig);
  if (sectionId === 'economy' && guildConfig)    return buildEconomyView(settings, guildConfig);
  if (sectionId === 'moderation' && guildConfig) return buildModerationSettingsView(settings, guildConfig);
  if (sectionId === 'music' && guildConfig)      return buildMusicView(settings, guildConfig);
  if (sectionId === 'system')                    return buildSystemView(settings, client);
  // Task-09 community sections
  if (sectionId === 'suggestions' && guildConfig) return buildSuggestionsView(settings, guildConfig);
  if (sectionId === 'booster' && guildConfig)     return buildBoosterView(settings, guildConfig);
  if (sectionId === 'membercount' && guildConfig) return buildMemberCountView(settings, guildConfig);
  if (sectionId === 'starboard' && guildConfig)   return buildStarboardView(settings, guildConfig);
  if (sectionId === 'counting' && guildConfig)    return buildCountingView(settings, guildConfig);

  // ── Async builders ─────────────────────────────────────────────────────
  // Returns a Promise<view> — the caller (selectMenus.js settings_nav handler)
  // must await this and then call interaction.update().
  if (sectionId === 'giveaways') {
    return buildGiveawaysView(settings, guildConfig?.guildId ?? null);
  }
  if (sectionId === 'broadcast') {
    return buildBroadcastView(settings, guildConfig?.guildId ?? null);
  }

  // ── Placeholder for sections still managed via commands ────────────────
  // tickets  → use /tickets for the full dashboard
  // automod  → use /automod command or the Protection section
  const embed = new EmbedBuilder()
    .setColor(COLORS.primary)
    .setTitle(`${section.icon}・${section.nameAr} (${section.nameEn})`)
    .setDescription(
      `${section.descAr}\n\n` +
      `${ICONS.info} يُدار هذا النظام عبر أوامره المخصصة. يمكنك استخدام رجوع للعودة إلى قائمة الأقسام أو الرئيسية لفتح لوحة الإعدادات من جديد.`
    )
    .setFooter({ text: settings.footer })
    .setTimestamp();

  return { embeds: [embed], components: [navigationRow()] };
}

function buildClosedView(settings) {
  const embed = new EmbedBuilder()
    .setColor(COLORS.neutral)
    .setDescription(`${ICONS.close} تم إغلاق لوحة الإعدادات. استخدم \`/settings\` لفتحها من جديد.`)
    .setFooter({ text: settings.footer })
    .setTimestamp();
  return { embeds: [embed], components: [] };
}

module.exports = {
  SETTINGS_SECTIONS,
  findSection,
  buildHomeView,
  buildSectionView,
  buildClosedView,
  NAV_SELECT_ID,
  HOME_BUTTON_ID,
  BACK_BUTTON_ID,
  CLOSE_BUTTON_ID,
};
