const { ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const { baseEmbed } = require('./embeds');
const ticketState = require('../services/ticketStateManager');

const BUTTON_STYLES = {
  Primary: ButtonStyle.Primary,
  Secondary: ButtonStyle.Secondary,
  Success: ButtonStyle.Success,
  Danger: ButtonStyle.Danger,
};

const DEFAULT_TITLE = '🎫・مركز الدعم';
const DEFAULT_DESCRIPTION =
  'مرحباً بك في مركز الدعم.\n\nاختر القسم الذي يطابق طلبك لفتح تذكرة خاصة مع فريقنا. اكتب التفاصيل بوضوح لنساعدك بشكل أسرع.';
const DEFAULT_WELCOME =
  'مرحباً {user}، شكراً لتواصلك مع فريق الدعم.\n\nتم فتح تذكرتك بنجاح. اشرح طلبك بالتفصيل وسيرد عليك أحد أعضاء الفريق قريباً.';
const DEFAULT_PANEL_BUTTON_LABEL = 'فتح تذكرة';
const DEFAULT_PANEL_EMOJI = '🎫';

// Used when the guild has not configured any custom types yet - keeps the
// legacy single-button behaviour working with zero setup required.
const FALLBACK_TYPE = {
  typeId: 'default',
  label: DEFAULT_PANEL_BUTTON_LABEL,
  emoji: DEFAULT_PANEL_EMOJI,
  style: 'Primary',
  description: null,
  categoryId: null,
  mentionRoleId: null,
  viewRoleIds: [],
  welcomeMessage: null,
  channelName: null,
};

// Discord hard caps: 5 components per action row, 5 rows per message.
// Buttons stay in one row-set (max 25) for the compact look Task 1 asked
// for; once a server configures more types than that, the panel switches
// to string select menus instead (25 options each), which lets a single
// panel scale up to 125 ticket types across the 5 available rows.
const MAX_BUTTON_TYPES = 25;
const MAX_SELECT_OPTIONS = 25;
const MAX_ROWS = 5;
const MAX_TOTAL_TYPES = MAX_SELECT_OPTIONS * MAX_ROWS;

/** Splits an array into chunks of `size`. */
function chunk(items, size) {
  const rows = [];
  for (let i = 0; i < items.length; i += size) rows.push(items.slice(i, i + size));
  return rows;
}

/** Replaces {user}/{type}/{number} placeholders in an admin-authored template string. */
function applyPlaceholders(template, { user, type, number }) {
  return template
    .replace(/\{user\}/g, user ? `<@${user.id}>` : '')
    .replace(/\{type\}/g, type?.label || '')
    .replace(/\{number\}/g, number != null ? String(number) : '');
}

/** Turns a user-facing template into a Discord-legal channel name (lowercase, alphanumeric/hyphen, <=100 chars). */
function slugifyChannelName(raw) {
  return raw
    .toLowerCase()
    .replace(/<@!?(\d+)>/g, '$1')
    .normalize('NFKD')
    .replace(/[^a-z0-9\u0600-\u06FF-]+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '')
    .slice(0, 100) || 'ticket';
}

// 🟡 = the ticket opener sent the last message and is waiting on staff.
// 🟢 = staff has replied / no action is currently needed.
const STATUS_EMOJI = { needs_reply: '🟡', no_action: '🟢' };
// 🔵 = the ticket is closed and waiting (unattended) for its auto-delete
// timer. 🔴 = same, but less than the configured warning window
// (tickets.closePrompt.warningMinutes) remains before it's deleted for
// good. See services/ticketCloseService.js.
const CLOSE_STATUS_EMOJI = { pending_delete: '🔵', near_delete: '🔴' };
// Every emoji this feature can ever prefix a channel name with, used to
// strip a stale prefix back off before applying a new one.
const ALL_STATUS_EMOJI = { ...STATUS_EMOJI, ...CLOSE_STATUS_EMOJI };
const STATUS_SEPARATOR = '・';

/** Prefixes a (already-slugified) base channel name with the open-ticket status emoji, e.g. "🟡・ticket-001". */
function buildStatusChannelName(baseName, status) {
  const emoji = STATUS_EMOJI[status] || STATUS_EMOJI.needs_reply;
  return `${emoji}${STATUS_SEPARATOR}${baseName}`.slice(0, 100);
}

/** Prefixes a (already-slugified) base channel name with the closed-ticket status emoji, e.g. "🔵・ticket-001". */
function buildCloseStatusChannelName(baseName, closeStatus) {
  const emoji = CLOSE_STATUS_EMOJI[closeStatus] || CLOSE_STATUS_EMOJI.pending_delete;
  return `${emoji}${STATUS_SEPARATOR}${baseName}`.slice(0, 100);
}

/** Strips a previously-applied status-emoji prefix back off, so renames never stack prefixes. Falls back to the raw name for legacy tickets that predate this feature. */
function deriveBaseChannelName(currentName) {
  if (!currentName) return currentName;
  const prefix = Object.values(ALL_STATUS_EMOJI).find((emoji) => currentName.startsWith(`${emoji}${STATUS_SEPARATOR}`));
  return prefix ? currentName.slice(prefix.length + STATUS_SEPARATOR.length) : currentName;
}

// TASK33: the four-state workflow view layered on top of TASK32's
// tracking fields (see database/models/Ticket.js's lastActivityAt/
// lastMessageBy) - purely a *read* helper, no new field/system of its
// own beyond what messageCreate.js's handleTicketStatusUpdate already
// writes. 'closed' always wins regardless of activity. 'active' is a
// ticket that's open/claimed but has no tracked activity yet (freshly
// opened, or freshly reopened - see ticketCloseService.js#reopenTicket,
// which clears the activity fields on reopen). Otherwise the state
// mirrors whoever spoke last.
const WORKFLOW_STATE = {
  active: { emoji: '💬', label: 'نشطة' },
  waiting_staff: { emoji: '🟡', label: 'بانتظار رد الإدارة' },
  waiting_user: { emoji: '🟢', label: 'بانتظار رد العضو' },
  closed: { emoji: '🔒', label: 'مغلقة' },
};

/** TASK33: derives the ticket's logical workflow state (Active / Waiting for Staff / Waiting for User / Closed) from its tracked activity fields. Read-only - never itself writes to the ticket. */
function getTicketWorkflowState(ticket) {
  if (ticket.status === ticketState.TICKET_STATUS.CLOSED) return ticketState.TICKET_STATUS.CLOSED;
  if (!ticket.lastActivityAt || !ticket.lastMessageBy) return 'active';
  return ticket.lastMessageBy === 'staff' ? 'waiting_user' : 'waiting_staff';
}

/** TASK33: builds the embed field(s) summarizing a ticket's activity - reused by buttons.js's ticket_status_toggle reply, the closest thing this project already had to a dedicated "ticket status message". Additive only: never removes/replaces fields the caller already has. */
function buildTicketActivityField(ticket) {
  const stateKey = getTicketWorkflowState(ticket);
  const state = WORKFLOW_STATE[stateKey];
  const toTimestamp = (date) => (date ? `<t:${Math.floor(new Date(date).getTime() / 1000)}:R>` : '—');

  const lines = [
    `**الحالة:** ${state.emoji} ${state.label}`,
    `**آخر متحدث:** ${ticket.lastMessageBy === 'staff' ? 'فريق الدعم' : ticket.lastMessageBy === 'user' ? 'صاحب التذكرة' : '—'}`,
    `**آخر رسالة من صاحب التذكرة:** ${toTimestamp(ticket.lastUserMessageAt)}`,
    `**آخر رسالة من الإدارة:** ${toTimestamp(ticket.lastStaffMessageAt)}`,
    `**آخر نشاط:** ${toTimestamp(ticket.lastActivityAt)}`,
  ];

  return { name: '📊 نشاط التذكرة', value: lines.join('\n') };
}

/** Returns the guild's configured ticket types, or the single legacy default if none exist. */
function getPanelBuilder(guildConfig) {
  const builder = guildConfig?.tickets?.panelBuilder || {};
  return {
    channelId: builder.channelId || null,
    categoryId: builder.categoryId || null,
    buttonLabel: builder.buttonLabel || DEFAULT_PANEL_BUTTON_LABEL,
    emoji: builder.emoji || DEFAULT_PANEL_EMOJI,
  };
}

function getTicketTypes(guildConfig) {
  const types = guildConfig?.tickets?.types || [];
  if (types.length) return types;

  const builder = getPanelBuilder(guildConfig);
  return [
    {
      ...FALLBACK_TYPE,
      label: builder.buttonLabel,
      emoji: builder.emoji,
      categoryId: builder.categoryId || guildConfig?.tickets?.categoryId || null,
    },
  ];
}

function findTicketType(guildConfig, typeId) {
  const types = getTicketTypes(guildConfig);
  return types.find((t) => t.typeId === typeId) || types[0];
}

/** A ticket type's effective category/mention-role/view-roles: its own overrides, falling back to the guild-wide defaults. */
function resolveTypeTargets(guildConfig, type) {
  const categoryId = type?.categoryId || guildConfig.tickets.categoryId || null;
  const mentionRoleId = type?.mentionRoleId || guildConfig.tickets.supportRoleId || null;
  const viewRoleIds = type?.viewRoleIds?.length
    ? type.viewRoleIds
    : guildConfig.tickets.supportRoleId
    ? [guildConfig.tickets.supportRoleId]
    : [];
  return { categoryId, mentionRoleId, viewRoleIds };
}

/** Resolves the channel name for a brand-new ticket of this type. */
function resolveChannelName(type, { user, number }) {
  const template = type.channelName || (type.typeId !== 'default' ? `ticket-${type.typeId}-{number}` : 'ticket-{number}');
  return slugifyChannelName(applyPlaceholders(template, { user, type, number }));
}

/** Resolves the welcome-message text shown as the ticket embed description. */
function resolveWelcomeMessage(type, { user, number }) {
  const template = type.welcomeMessage || DEFAULT_WELCOME;
  return applyPlaceholders(template, { user, type, number });
}

/** Builds the professional panel embed - title, intro, per-type breakdown, and optional rules. */
function buildPanelEmbed(settings, guildConfig) {
  const { tickets } = guildConfig;
  const types = getTicketTypes(guildConfig);

  const embed = baseEmbed(settings)
    .setTitle(tickets.panelTitle || DEFAULT_TITLE)
    .setDescription(tickets.panelDescription || DEFAULT_DESCRIPTION);

  if (types.length > 1 || types[0].description) {
    const lines = types.map((t) => `${t.emoji || '•'} **${t.label}**${t.description ? ` — ${t.description}` : ''}`);
    // Keep the embed within field-value limits even with a large number of types.
    for (const group of chunk(lines, 15)) {
      embed.addFields({ name: embed.data.fields?.length ? '\u200b' : '🎫 أقسام الدعم المتاحة', value: group.join('\n') });
    }
  }

  embed.addFields({
    name: '📌 قبل فتح التذكرة',
    value:
      tickets.panelRules ||
      '• افتح تذكرة واحدة فقط في كل مرة.\n• اكتب التفاصيل والملفات المطلوبة بوضوح.\n• انتظر رد فريق الدعم وتجنب تكرار الرسائل.\n• استخدم النظام للطلبات المتعلقة بالسيرفر فقط.',
  });

  return embed;
}

/**
 * Builds the panel's interactive components. Up to MAX_BUTTON_TYPES types
 * render as button rows (Task 1's original look); beyond that the panel
 * automatically switches to one or more string select menus so a server
 * can configure well past Discord's 25-button ceiling (up to MAX_TOTAL_TYPES).
 */
function buildPanelComponents(guildConfig) {
  const types = getTicketTypes(guildConfig).slice(0, MAX_TOTAL_TYPES);

  if (types.length <= MAX_BUTTON_TYPES) {
    const buttons = types.map((t) => {
      const button = new ButtonBuilder()
        .setCustomId(`ticket_create:${t.typeId}`)
        .setLabel(t.label)
        .setStyle(BUTTON_STYLES[t.style] || ButtonStyle.Primary);
      if (t.emoji) button.setEmoji(t.emoji);
      return button;
    });
    return chunk(buttons, 5).map((row) => new ActionRowBuilder().addComponents(row));
  }

  return chunk(types, MAX_SELECT_OPTIONS).map((group, i) => {
    const menu = new StringSelectMenuBuilder()
      .setCustomId(`ticket_create_select:${i}`)
      .setPlaceholder(`🎫 اختر قسم الدعم... (${i * MAX_SELECT_OPTIONS + 1}-${i * MAX_SELECT_OPTIONS + group.length})`)
      .addOptions(
        group.map((t) => ({
          label: t.label,
          value: t.typeId,
          description: t.description ? t.description.slice(0, 100) : undefined,
          emoji: t.emoji || undefined,
        }))
      );
    return new ActionRowBuilder().addComponents(menu);
  });
}

/** Builds the "why are you opening this ticket?" modal for a given type. customId carries the typeId through to the submit handler. */
function buildTicketModal(type) {
  const modal = new ModalBuilder()
    .setCustomId(`ticket_create_modal:${type.typeId}`)
    .setTitle(`🎫 ${type.label}`.slice(0, 45));
  const reasonInput = new TextInputBuilder()
    .setCustomId('reason')
    .setLabel('اشرح كيف يمكننا مساعدتك')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true)
    .setMaxLength(500);
  modal.addComponents(new ActionRowBuilder().addComponents(reasonInput));
  return modal;
}

module.exports = {
  BUTTON_STYLES,
  FALLBACK_TYPE,
  DEFAULT_PANEL_BUTTON_LABEL,
  DEFAULT_PANEL_EMOJI,
  MAX_TOTAL_TYPES,
  STATUS_EMOJI,
  CLOSE_STATUS_EMOJI,
  WORKFLOW_STATE,
  getTicketWorkflowState,
  buildTicketActivityField,
  getTicketTypes,
  getPanelBuilder,
  findTicketType,
  resolveTypeTargets,
  resolveChannelName,
  resolveWelcomeMessage,
  applyPlaceholders,
  buildPanelEmbed,
  buildPanelComponents,
  buildTicketModal,
  buildStatusChannelName,
  buildCloseStatusChannelName,
  deriveBaseChannelName,
};
