const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { baseEmbed } = require('./embeds');

const TRACKS_PER_PAGE = 10;
const REPEAT_MODE_LABELS = { 0: 'إيقاف', 1: 'مقطع', 2: 'قائمة', 3: 'تشغيل تلقائي' };

/** Formats a millisecond duration as `h:mm:ss` (or `m:ss` under an hour). Returns null for 0/unknown. */
function formatDuration(ms) {
  if (!ms || ms <= 0) return null;
  const totalSeconds = Math.floor(ms / 1000);
  const h = Math.floor(totalSeconds / 3600);
  const m = Math.floor((totalSeconds % 3600) / 60);
  const s = totalSeconds % 60;
  const pad = (n) => String(n).padStart(2, '0');
  return h > 0 ? `${h}:${pad(m)}:${pad(s)}` : `${m}:${pad(s)}`;
}

/**
 * Builds a single page of the queue: the embed (now playing + upcoming
 * tracks + stats) and its Previous/Next/Clear button row. Shared between
 * the /queue command and the music_queue_page / music_queue_clear button
 * handlers so both always render identically.
 *
 * @param {import('discord-player').GuildQueue} queue
 * @param {ReturnType<typeof import('./resolveGuildSettings').resolved>} settings
 * @param {number} requestedPage 1-indexed page to render; clamped into range.
 */
function buildQueuePage(queue, settings, requestedPage = 1) {
  if (!queue.currentTrack) {
    // Queue ended between button click and handler - return a safe "nothing playing" state
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('music_queue_page:0').setEmoji('◀️').setStyle(ButtonStyle.Secondary).setDisabled(true),
      new ButtonBuilder().setCustomId('music_queue_page:2').setEmoji('▶️').setStyle(ButtonStyle.Secondary).setDisabled(true),
      new ButtonBuilder().setCustomId('music_queue_clear').setLabel('Clear Queue').setEmoji('🗑️').setStyle(ButtonStyle.Danger).setDisabled(true)
    );
    const embed = baseEmbed(settings).setTitle('🎶 قائمة الانتظار').setDescription('_لا يوجد شيء يعمل حالياً._');
    return { embed, components: [row], page: 1, totalPages: 1 };
  }
  const tracks = queue.tracks.toArray();
  const totalPages = Math.max(1, Math.ceil(tracks.length / TRACKS_PER_PAGE));
  const page = Math.min(Math.max(requestedPage, 1), totalPages);
  const start = (page - 1) * TRACKS_PER_PAGE;
  const pageTracks = tracks.slice(start, start + TRACKS_PER_PAGE);

  const upcoming = pageTracks.length
    ? pageTracks
        .map((t, i) => `**${start + i + 1}.** [${t.title}](${t.url}) \`${t.duration || 'Live'}\` — ${t.requestedBy ?? 'غير معروف'}`)
        .join('\n')
    : '_Queue is empty — this is the last track._';

  const upcomingMs = tracks.reduce((sum, t) => sum + (t.durationMS || 0), 0);
  const currentMs = queue.currentTrack?.durationMS || 0;
  const totalDuration = formatDuration(upcomingMs + currentMs) || 'غير معروف';

  const embed = baseEmbed(settings)
    .setTitle('🎶 قائمة الانتظار')
    .setDescription(
      `**يعمل الآن:**\n[${queue.currentTrack.title}](${queue.currentTrack.url}) \`${queue.currentTrack.duration || 'Live'}\` — ${queue.currentTrack.requestedBy ?? 'غير معروف'}\n\n**القادم:**\n${upcoming}`
    )
    .addFields(
      { name: 'المقاطع في الانتظار', value: `${tracks.length}`, inline: true },
      { name: 'المدة الإجمالية', value: totalDuration, inline: true },
      { name: 'وضع التكرار', value: REPEAT_MODE_LABELS[queue.repeatMode] ?? 'إيقاف', inline: true },
      { name: 'الصوت', value: `${queue.node.volume}%`, inline: true }
    )
    .setFooter({ text: `الصفحة ${page}/${totalPages} • ${settings.footer}` });

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`music_queue_page:${page - 1}`)
      .setEmoji('◀️')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(page <= 1),
    new ButtonBuilder()
      .setCustomId(`music_queue_page:${page + 1}`)
      .setEmoji('▶️')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(page >= totalPages),
    new ButtonBuilder()
      .setCustomId('music_queue_clear')
      .setLabel('Clear Queue')
      .setEmoji('🗑️')
      .setStyle(ButtonStyle.Danger)
      .setDisabled(tracks.length === 0)
  );

  return { embed, components: [row], page, totalPages };
}



const LOOP_TO_REPEAT_MODE = { none: 0, track: 1, queue: 2 };

/** Mirrors the private formatDuration() in this file so Kazagumo tracks render identically to discord-player ones. */
function formatKazagumoTrackDuration(ms) {
  if (!ms || ms <= 0) return null;
  const totalSeconds = Math.floor(ms / 1000);
  const h = Math.floor(totalSeconds / 3600);
  const m = Math.floor((totalSeconds % 3600) / 60);
  const s = totalSeconds % 60;
  const pad = (n) => String(n).padStart(2, '0');
  return h > 0 ? `${h}:${pad(m)}:${pad(s)}` : `${m}:${pad(s)}`;
}

/** Reshapes a KazagumoTrack into the plain shape buildQueuePage() expects. */
function toKazagumoDisplayTrack(kazagumoTrack) {
  return {
    title: kazagumoTrack.title,
    url: kazagumoTrack.uri,
    duration: kazagumoTrack.isStream ? 'Live' : formatKazagumoTrackDuration(kazagumoTrack.length),
    durationMS: kazagumoTrack.length || 0,
    requestedBy: kazagumoTrack.requester,
  };
}

/**
 * Builds a discord-player-shaped "queue" view backed by Kazagumo data so
 * buildQueuePage() doesn't need to know which engine is behind it.
 * Moved from commands/music/queue.js so it can be used without registering that command.
 */
function buildKazagumoQueueView(kazagumoPlayer) {
  const upcoming = [...kazagumoPlayer.queue].map(toKazagumoDisplayTrack);
  return {
    currentTrack: kazagumoPlayer.queue.current ? toKazagumoDisplayTrack(kazagumoPlayer.queue.current) : null,
    tracks: { toArray: () => upcoming },
    repeatMode: LOOP_TO_REPEAT_MODE[kazagumoPlayer.loop] ?? 0,
    node: { volume: kazagumoPlayer.volume ?? 100 },
  };
}

module.exports = { buildQueuePage, buildKazagumoQueueView };
