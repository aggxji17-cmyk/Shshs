/**
 * Task 31 — التنقل داخل Admin Dashboard (Admin Dashboard Navigation).
 *
 * Single source of truth for every view `/admin` can render: the section
 * list and the Home/Section/Closed embeds+components. Moved here from
 * `commands/settings/admin.js` (where Task 30 first defined ADMIN_SECTIONS
 * and built the one static Home embed inline) because from this task
 * onward THREE places need to build the exact same views - the `/admin`
 * command itself, the section select menu, and the Back/Home/Close
 * buttons. Centralizing view-building here means all of them render
 * identical output from one place instead of duplicating markup, in
 * line with the project's own rule against duplicate systems (see
 * NYXO-BOT-TASKS-70.txt, rule 3). `docs/TASK31-ADMIN-DASHBOARD-NAV.md`
 * documents this refactor and why `tests/task30-admin-dashboard.test.js`
 * was updated to check this file instead of `admin.js` for the pieces
 * that moved - nothing it originally verified was weakened, only
 * re-pointed at their new home.
 *
 * Navigation depth today is exactly two levels: Home -> one Section.
 * Back and Home therefore land on the same view for now; they are kept
 * as two separate buttons (not merged into one) because the task spec
 * requires both, and because later Phase 6 tasks (44/45/46, which move
 * real settings into these section screens) will add real depth under
 * each section - at that point Back will start meaning "previous view"
 * instead of always "home".
 *
 * What a section shows right now is a placeholder, NOT that system's
 * actual settings controls. Moving real functionality into the
 * dashboard is explicitly scheduled for later, per-system tasks (44
 * Ticket Setup, 45 Settings, ...), and the Phase 6 rule at the top of
 * that phase says an old command is never removed before its dashboard
 * replacement is complete. This task only builds the reusable
 * navigation shell everything else will plug into.
 */
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder } = require('discord.js');
const { COLORS, ICONS } = require('./designSystem');

// Section list for the dashboard. Order/content matches the task
// specification verbatim (NYXO-BOT-TASKS-70.txt, Task 30). `id` is the
// internal navigation key (select menu value / section lookup) and is
// never shown to the user.
const ADMIN_SECTIONS = [
  { id: 'tickets', icon: ICONS.tickets, nameAr: 'التذاكر', nameEn: 'Tickets', descAr: 'إعدادات نظام الدعم والتذاكر' },
  { id: 'moderation', icon: ICONS.moderation, nameAr: 'الإشراف', nameEn: 'Moderation', descAr: 'أوامر وإعدادات الإشراف على الأعضاء' },
  { id: 'protection', icon: ICONS.security, nameAr: 'الحماية', nameEn: 'Protection', descAr: 'الحماية من الأعطال والدخول الجماعي (Anti-Nuke/Raid)' },
  { id: 'giveaways', icon: ICONS.giveaway, nameAr: 'السحوبات', nameEn: 'Giveaways', descAr: 'إدارة سحوبات الجوائز الجارية والقادمة' },
  { id: 'economy', icon: ICONS.economy, nameAr: 'الاقتصاد', nameEn: 'Economy', descAr: 'إعدادات نظام العملات والمتجر' },
  { id: 'leveling', icon: ICONS.leveling, nameAr: 'نظام المستويات', nameEn: 'Leveling', descAr: 'إعدادات الخبرة والمستويات ورتب المستويات' },
  { id: 'logging', icon: ICONS.logging, nameAr: 'السجلات', nameEn: 'Logging', descAr: 'قنوات ونوع الأحداث التي يتم تسجيلها' },
  { id: 'broadcast', icon: ICONS.broadcast, nameAr: 'البث', nameEn: 'Broadcast', descAr: 'إرسال إعلانات جماعية للأعضاء' },
  { id: 'welcome', icon: ICONS.welcome, nameAr: 'الترحيب', nameEn: 'Welcome', descAr: 'رسائل الترحيب والمغادرة' },
  { id: 'automod', icon: ICONS.automod, nameAr: 'الحماية التلقائية', nameEn: 'AutoMod', descAr: 'فلترة الروابط والسبام والكلمات الممنوعة' },
  { id: 'system', icon: ICONS.system, nameAr: 'النظام', nameEn: 'System', descAr: 'حالة البوتات الثلاثة والمعلومات التقنية' },
];

// customId constants - kept here so admin.js and both component handler
// files (buttons.js, selectMenus.js) never hardcode the raw string in
// more than one place each.
const NAV_SELECT_ID = 'admin_nav';
const HOME_BUTTON_ID = 'admin_home';
const BACK_BUTTON_ID = 'admin_back';
const CLOSE_BUTTON_ID = 'admin_close';

function findSection(id) {
  return ADMIN_SECTIONS.find((section) => section.id === id) || null;
}

function closeButton() {
  return new ButtonBuilder().setCustomId(CLOSE_BUTTON_ID).setLabel('إغلاق / Close').setEmoji(ICONS.close).setStyle(ButtonStyle.Danger);
}

/** The dashboard's top-level view: section list + a select menu to enter one + Close. No Back/Home here - there is nothing before it. */
function buildHomeView(settings, guildName) {
  const embed = new EmbedBuilder()
    .setColor(COLORS.primary)
    .setTitle(`${ICONS.admin}・لوحة الإدارة المركزية`)
    .setDescription(
      `مرحبًا **${guildName}**، هذه هي لوحة الإدارة المركزية للبوت.\n` +
        'تجمع هذه اللوحة الأقسام الإدارية الرئيسية في مكان واحد بدل الاعتماد على أوامر متفرقة.\n' +
        'اختر قسمًا من القائمة أدناه لعرضه.\n\n' +
        '**الأقسام المتاحة حاليًا:**'
    )
    .addFields(
      ADMIN_SECTIONS.map((section) => ({
        name: `${section.icon} ${section.nameAr} (${section.nameEn})`,
        value: section.descAr,
        inline: true,
      }))
    )
    .setFooter({ text: settings.footer })
    .setTimestamp();

  const select = new StringSelectMenuBuilder()
    .setCustomId(NAV_SELECT_ID)
    .setPlaceholder('اختر قسمًا لعرضه... / Choose a section')
    .addOptions(
      ADMIN_SECTIONS.map((section) => ({
        label: `${section.nameAr} (${section.nameEn})`,
        description: section.descAr.slice(0, 100),
        value: section.id,
        emoji: section.icon,
      }))
    );

  return {
    embeds: [embed],
    components: [new ActionRowBuilder().addComponents(select), new ActionRowBuilder().addComponents(closeButton())],
  };
}

/** One section's placeholder view, reached from Home. Always has Back + Home + Close (rule 15: every new UI needs Back where relevant and Close always). Returns null for an unknown/stale section id so the caller can show a proper error instead of a broken embed. */
function buildSectionView(settings, sectionId) {
  const section = findSection(sectionId);
  if (!section) return null;

  const embed = new EmbedBuilder()
    .setColor(COLORS.primary)
    .setTitle(`${section.icon}・${section.nameAr} (${section.nameEn})`)
    .setDescription(
      `${section.descAr}\n\n` +
        `${ICONS.info} أدوات التحكم الكاملة لهذا القسم سيتم نقلها إلى هذه الواجهة في مهام لاحقة من نفس المرحلة (المرحلة 6). ` +
        'الأوامر الحالية الخاصة بهذا القسم ما زالت تعمل بشكل طبيعي حتى اكتمال النقل.'
    )
    .setFooter({ text: settings.footer })
    .setTimestamp();

  const navRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(BACK_BUTTON_ID).setLabel('رجوع / Back').setEmoji(ICONS.back).setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(HOME_BUTTON_ID).setLabel('الرئيسية / Home').setEmoji(ICONS.home).setStyle(ButtonStyle.Secondary),
    closeButton()
  );

  return { embeds: [embed], components: [navRow] };
}

/** Replaces the panel with a plain "closed" notice and no components, so a stale click on an already-closed panel can't do anything (handled separately by the unknown-interaction safety net, Task 50). */
function buildClosedView(settings) {
  const embed = new EmbedBuilder()
    .setColor(COLORS.neutral)
    .setDescription(`${ICONS.close} تم إغلاق لوحة الإدارة. استخدم \`/admin\` لفتحها من جديد.`)
    .setFooter({ text: settings.footer })
    .setTimestamp();
  return { embeds: [embed], components: [] };
}

module.exports = {
  ADMIN_SECTIONS,
  findSection,
  buildHomeView,
  buildSectionView,
  buildClosedView,
  NAV_SELECT_ID,
  HOME_BUTTON_ID,
  BACK_BUTTON_ID,
  CLOSE_BUTTON_ID,
};
