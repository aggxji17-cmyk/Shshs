const fs = require('fs');
const path = require('path');

/**
 * Task 51: نظام الترجمة المركزي (Localization System) لـ NYXO BOT.
 *
 * العربية هي اللغة الافتراضية للمشروع. أي نص يظهر للمستخدم (أزرار،
 * Embeds، رسائل، أخطاء، إعدادات) يجب أن يمر عبر `t(lang, key, vars)`
 * بدلاً من كتابته مباشرة داخل ملفات الأوامر/الأحداث/الخدمات، لتفادي
 * تكرار نفس النص في أكثر من مكان وليسهل تعديله من مصدر واحد.
 *
 * الترجمات تعيش في `src/lang/<code>.json` - ملف JSON واحد متداخل بالنقاط
 * (dot-nested) لكل لغة، بنفس بنية المفاتيح في كل ملف.
 *
 * إضافة لغة جديدة لاحقاً خطوتان فقط، بدون أي تعديل آخر في الكود:
 *   1. إضافة `src/lang/<code>.json` بنفس مفاتيح `ar.json`.
 *   2. إضافة `<code>` إلى `SUPPORTED_LANGUAGES` بالأسفل.
 * أي استدعاء `t(lang, key)` موجود يستمر بالعمل فوراً - المفاتيح
 * الناقصة في ملف جديد/غير مكتمل ترجع تلقائياً إلى `DEFAULT_LANGUAGE`
 * (انظر `t()`) بدلاً من رمي خطأ أو طباعة `undefined`.
 */

const SUPPORTED_LANGUAGES = ['ar', 'en'];
const DEFAULT_LANGUAGE = 'ar';

const LANG_DIR = path.join(__dirname, '..', 'lang');

const dictionaries = {};
for (const lang of SUPPORTED_LANGUAGES) {
  const file = path.join(LANG_DIR, `${lang}.json`);
  dictionaries[lang] = JSON.parse(fs.readFileSync(file, 'utf8'));
}

function getByPath(obj, key) {
  return key.split('.').reduce((acc, part) => (acc && typeof acc === 'object' ? acc[part] : undefined), obj);
}

function interpolate(str, vars) {
  if (!vars) return str;
  return str.replace(/\{(\w+)\}/g, (match, name) => (name in vars ? String(vars[name]) : match));
}

/**
 * Translates `key` (dot path, e.g. "shop.purchased") into `lang`.
 * Falls back to English if `lang` is unsupported or the key is missing
 * from that language's file, and as a last resort returns the raw key
 * (never `undefined`, so a missing translation is visible/debuggable in
 * the actual Discord message instead of silently breaking the reply).
 *
 * @param {string} lang - one of SUPPORTED_LANGUAGES
 * @param {string} key - dot-path into the language JSON, e.g. "shop.empty"
 * @param {Record<string, string|number>} [vars] - `{name}` placeholders to fill in
 */
function t(lang, key, vars) {
  const normalized = SUPPORTED_LANGUAGES.includes(lang) ? lang : DEFAULT_LANGUAGE;

  let str = getByPath(dictionaries[normalized], key);
  if (str === undefined && normalized !== DEFAULT_LANGUAGE) {
    str = getByPath(dictionaries[DEFAULT_LANGUAGE], key);
  }
  if (str === undefined) return key;

  return interpolate(str, vars);
}

// Discord locale codes (interaction.locale) -> our language codes. Only
// the ones we actually have a dictionary for need an entry; anything
// else falls through to DEFAULT_LANGUAGE in resolveLanguage().
const DISCORD_LOCALE_MAP = { ar: 'ar' };

/**
 * Picks which language to reply in, in priority order:
 *   1. An explicit per-guild override (`GuildConfig.language`, set via
 *      `/language set`) - a guild manager's choice always wins.
 *   2. The invoking member's own Discord client language
 *      (`interaction.locale`), when it's a language we support.
 *   3. DEFAULT_LANGUAGE (Arabic).
 *
 * @param {object} [params]
 * @param {{language?: string|null}} [params.guildConfigDoc]
 * @param {import('discord.js').Interaction} [params.interaction]
 */
function resolveLanguage({ guildConfigDoc, interaction } = {}) {
  if (guildConfigDoc?.language && SUPPORTED_LANGUAGES.includes(guildConfigDoc.language)) {
    return guildConfigDoc.language;
  }

  const discordLocale = interaction?.locale;
  const base = discordLocale?.split('-')[0];
  if (base && DISCORD_LOCALE_MAP[base]) {
    return DISCORD_LOCALE_MAP[base];
  }

  return DEFAULT_LANGUAGE;
}

module.exports = { t, resolveLanguage, SUPPORTED_LANGUAGES, DEFAULT_LANGUAGE };
