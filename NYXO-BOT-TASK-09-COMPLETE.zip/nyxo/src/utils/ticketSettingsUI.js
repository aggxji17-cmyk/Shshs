/**
 * Tasks 33–37 — Ticket Settings, Categories, Roles, Messages & Panels UIs.
 *
 * This module builds all five "live" section views that replace the
 * Task-32 placeholder views for the Settings, Categories, Roles, Messages,
 * and Panels sections of the Tickets Dashboard (`/tickets`).
 *
 * Architecture:
 *   • Each section has a dedicated `build*View()` function that reads the
 *     live guildConfig document and renders the current state into an Embed
 *     + ActionRow set. The views are ephemeral (sent via interaction.update)
 *     so there's no risk of them becoming stale in a public channel.
 *   • Every view always has Back + Home + Close (rule 15).
 *   • Every setting has an Arabic name and clear description (rule 16).
 *   • Modal submissions save changes and re-render the section in-place
 *     (same customId prefix pattern used everywhere else in this project).
 *   • Nothing in this file touches the existing /ticketsetup command; the
 *     old command keeps working as-is until Phase 8 finalises the transition.
 *
 * CustomId convention (prefix_action:extra):
 *   tds_settings_*    — Task 33: Settings section buttons/modals
 *   tds_categories_*  — Task 34: Categories section buttons/modals
 *   tds_roles_*       — Task 35: Roles & Permissions section buttons/modals
 *   tds_messages_*    — Task 36: Messages section buttons/modals
 *
 * All four prefix families are registered in:
 *   - src/components/buttons.js  (buttons/confirmation flows)
 *   - src/components/modals.js   (Modal submissions)
 *   - src/components/selectMenus.js is NOT needed here (ticketdash_nav
 *     already delegates navigation; per-section selects are under their
 *     own prefixes in buttons.js where necessary).
 */

const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ChannelSelectMenuBuilder,
  ChannelType,
} = require('discord.js');
const { COLORS, ICONS } = require('./designSystem');
const { DEFAULT_PANEL_BUTTON_LABEL, DEFAULT_PANEL_EMOJI } = require('./ticketPanel');

// ─── Shared nav helpers ────────────────────────────────────────────────────

function navRow() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('ticketdash_back').setLabel('رجوع / Back').setEmoji(ICONS.back).setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('ticketdash_home').setLabel('الرئيسية / Home').setEmoji(ICONS.home).setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('ticketdash_close').setLabel('إغلاق / Close').setEmoji(ICONS.close).setStyle(ButtonStyle.Danger)
  );
}

function fmt(val, fallback = '`غير محدد`') {
  if (!val) return fallback;
  return val;
}

function fmtChannel(id) {
  return id ? `<#${id}>` : '`غير محدد`';
}

function fmtRole(id) {
  return id ? `<@&${id}>` : '`غير محدد`';
}

function fmtBool(val) {
  return val ? '✅ مفعّل' : '❌ معطّل';
}

function fmtMinutes(minutes) {
  if (!minutes && minutes !== 0) return '`غير محدد`';
  if (minutes === 0) return '`معطّل`';
  if (minutes < 60) return `\`${minutes} دقيقة\``;
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return m ? `\`${h} ساعة و${m} دقيقة\`` : `\`${h} ساعة\``;
}

// ─── Task 33 — Settings Section View ──────────────────────────────────────

/**
 * Builds the live Settings section view for the Tickets Dashboard.
 * Shows every setting from GuildConfig.tickets that maps to a
 * single-field value (category, supportRole, logChannel, transcriptChannel
 * [note: stored as `logChannelId`, the dashboard also shows it], deleteTime,
 * autoClaim, autoClose, reminder, smartMention).
 *
 * The GuildConfig schema as of Task 32 doesn't have autoClaim/autoClose/
 * smartMention/transcriptChannel as top-level tickets fields (the legacy
 * system stored them in LegacyTicketSetup). This view reads them from
 * guildConfig.tickets where they exist and shows a clear "not configured"
 * message where they don't, so the UI is honest about the current state.
 * Adding the fields to GuildConfig is deferred to a later task that
 * migrates the legacy data (rule 8: don't assume a problem before checking).
 */
function buildSettingsView(settings, guildConfig) {
  const t = guildConfig.tickets || {};
  const cp = t.closePrompt || {};

  const embed = new EmbedBuilder()
    .setColor(COLORS.primary)
    .setTitle(`${ICONS.settings}・إعدادات نظام التذاكر`)
    .setDescription('الإعدادات الحالية لنظام التذاكر. اضغط على أي زر أدناه لتعديل الإعداد المقابل.')
    .addFields(
      {
        name: '⚡ حالة النظام',
        value: fmtBool(t.enabled),
        inline: true,
      },
      {
        name: '🗂️ الفئة الافتراضية (Category)',
        value: t.categoryId ? `<#${t.categoryId}>` : '`غير محدد`',
        inline: true,
      },
      {
        name: '🎭 رتبة الدعم الافتراضية',
        value: fmtRole(t.supportRoleId),
        inline: true,
      },
      {
        name: '📋 قناة السجلات (Log Channel)',
        value: fmtChannel(t.logChannelId),
        inline: true,
      },
      {
        name: '📄 قناة النسخ (Transcript Channel)',
        value: fmtChannel(t.transcriptChannelId || null),
        inline: true,
      },
      {
        name: '🗑️ وقت الحذف التلقائي',
        value: fmtMinutes(cp.autoDeleteMinutes),
        inline: true,
      },
      {
        name: '⚠️ وقت تحذير الحذف',
        value: fmtMinutes(cp.warningMinutes),
        inline: true,
      },
      {
        name: '🤖 الاستلام التلقائي (Auto Claim)',
        value: fmtBool(t.autoClaim),
        inline: true,
      },
      {
        name: '🔒 الإغلاق التلقائي (Auto Close)',
        value: t.autoCloseMinutes ? fmtMinutes(t.autoCloseMinutes) : '❌ معطّل',
        inline: true,
      },
      {
        name: '⏰ تذكير الردّ (Reminder)',
        value: t.reminderMinutes ? fmtMinutes(t.reminderMinutes) : '❌ معطّل',
        inline: true,
      },
      {
        name: '🧠 الإشارة الذكية (Smart Mention)',
        value: fmtBool(t.smartMention),
        inline: true,
      },
      {
        name: '⭐ تقييم التذاكر (Ratings)',
        value: fmtBool(t.ratings?.enabled),
        inline: true,
      }
    )
    .setFooter({ text: settings.footer })
    .setTimestamp();

  // Row 1: toggle + basic channel/role buttons
  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('tds_settings_toggle')
      .setLabel(t.enabled ? 'تعطيل النظام' : 'تفعيل النظام')
      .setEmoji(t.enabled ? '❌' : '✅')
      .setStyle(t.enabled ? ButtonStyle.Danger : ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId('tds_settings_logchannel')
      .setLabel('قناة السجلات')
      .setEmoji('📋')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId('tds_settings_transcript')
      .setLabel('قناة النسخ')
      .setEmoji('📄')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId('tds_settings_deletetime')
      .setLabel('وقت الحذف التلقائي')
      .setEmoji('🗑️')
      .setStyle(ButtonStyle.Secondary)
  );

  // Row 2: auto-features
  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('tds_settings_autoclaim')
      .setLabel(t.autoClaim ? 'تعطيل الاستلام التلقائي' : 'تفعيل الاستلام التلقائي')
      .setEmoji('🤖')
      .setStyle(t.autoClaim ? ButtonStyle.Danger : ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId('tds_settings_autoclose')
      .setLabel('وقت الإغلاق التلقائي')
      .setEmoji('🔒')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('tds_settings_reminder')
      .setLabel('وقت التذكير')
      .setEmoji('⏰')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('tds_settings_smartmention')
      .setLabel(t.smartMention ? 'تعطيل الإشارة الذكية' : 'تفعيل الإشارة الذكية')
      .setEmoji('🧠')
      .setStyle(t.smartMention ? ButtonStyle.Danger : ButtonStyle.Success)
  );

  // Row 3 (TASK44): the three /ticketsetup settings that still had no
  // dashboard control - default category (config.category), the
  // close-prompt 🔴 warning timer (closeprompt setwarning), and resetting
  // the close-prompt message/labels/timers back to defaults
  // (closeprompt reset). Everything else /ticketsetup config/toggle/panel
  // and /ticketsetup closeprompt already had a control above/in other
  // sections.
  const row3 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('tds_settings_category')
      .setLabel('الفئة الافتراضية')
      .setEmoji('🗂️')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('tds_settings_warningtime')
      .setLabel('وقت تحذير الحذف')
      .setEmoji('⚠️')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('tds_settings_closepromptreset')
      .setLabel('إعادة ضبط رسائل الإغلاق')
      .setEmoji('♻️')
      .setStyle(ButtonStyle.Danger)
  );

  return {
    embeds: [embed],
    components: [row1, row2, row3, navRow()],
  };
}

// ─── Task 34 — Categories Section View ────────────────────────────────────

/**
 * Builds the live Categories section view.
 * Lists all configured ticket types (categories) with their settings,
 * and provides Add/Edit/Delete controls.
 */
function buildCategoriesView(settings, guildConfig) {
  const t = guildConfig.tickets || {};
  const types = t.types || [];

  const embed = new EmbedBuilder()
    .setColor(COLORS.primary)
    .setTitle(`${ICONS.categories}・أنواع (فئات) التذاكر`)
    .setDescription(
      types.length === 0
        ? `${ICONS.info} لا توجد أنواع تذاكر محددة بعد. اضغط **إضافة نوع** لإنشاء أول نوع.`
        : `إجمالي الأنواع: **${types.length}** / 25\nاضغط **إضافة نوع** لإضافة نوع جديد، أو اختر نوعاً موجوداً لتعديله أو حذفه.`
    )
    .setFooter({ text: settings.footer })
    .setTimestamp();

  // Show up to 10 types as fields (keeps embed under limit)
  const display = types.slice(0, 10);
  if (display.length > 0) {
    embed.addFields(
      display.map((tp) => ({
        name: `${tp.emoji ? tp.emoji + ' ' : ''}${tp.label} (\`${tp.typeId}\`)`,
        value: [
          tp.categoryId ? `🗂️ الفئة: <#${tp.categoryId}>` : '🗂️ الفئة: *(افتراضية)*',
          tp.mentionRoleId ? `🎭 الرتبة: <@&${tp.mentionRoleId}>` : '🎭 الرتبة: *(افتراضية)*',
          tp.description ? `📝 الوصف: ${tp.description.slice(0, 60)}` : '',
        ]
          .filter(Boolean)
          .join('\n') || '*(لا توجد تفاصيل إضافية)*',
        inline: true,
      }))
    );

    if (types.length > 10) {
      embed.addFields({
        name: `${ICONS.info} ملاحظة`,
        value: `يوجد ${types.length - 10} أنواع إضافية. استخدم \`/ticketsetup type list\` لرؤيتها جميعاً.`,
        inline: false,
      });
    }
  }

  const canAdd = types.length < 25;

  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('tds_categories_add')
      .setLabel('إضافة نوع')
      .setEmoji('➕')
      .setStyle(ButtonStyle.Success)
      .setDisabled(!canAdd),
    new ButtonBuilder()
      .setCustomId('tds_categories_edit')
      .setLabel('تعديل نوع')
      .setEmoji('✏️')
      .setStyle(ButtonStyle.Primary)
      .setDisabled(types.length === 0),
    new ButtonBuilder()
      .setCustomId('tds_categories_delete')
      .setLabel('حذف نوع')
      .setEmoji('🗑️')
      .setStyle(ButtonStyle.Danger)
      .setDisabled(types.length === 0)
  );

  return {
    embeds: [embed],
    components: [row1, navRow()],
  };
}

// ─── Task 35 — Roles & Permissions Section View ────────────────────────────

/**
 * Builds the live Roles & Permissions section view.
 * Shows the support, moderator, and admin roles configured for
 * the ticket system, and provides controls to update them.
 */
function buildRolesView(settings, guildConfig) {
  const t = guildConfig.tickets || {};
  const gc = guildConfig;

  embed_fields = [
    {
      name: '🎭 رتبة الدعم (Support Role)',
      value: [
        fmtRole(t.supportRoleId),
        '> صلاحيات: رؤية التذاكر، الرد عليها، استلامها',
      ].join('\n'),
      inline: false,
    },
    {
      name: '🛡️ رتبة الإشراف (Moderator Role)',
      value: [
        fmtRole(gc.modRoleId),
        '> صلاحيات: كل صلاحيات الدعم + إغلاق وحذف التذاكر',
      ].join('\n'),
      inline: false,
    },
    {
      name: '👑 رتبة الإدارة (Admin Role)',
      value: [
        fmtRole(gc.adminRoleId),
        '> صلاحيات: كل الصلاحيات + إعداد النظام',
      ].join('\n'),
      inline: false,
    },
    {
      name: `${ICONS.info} رتب مخصصة لأنواع التذاكر`,
      value:
        (t.types || []).length > 0
          ? (t.types || [])
              .filter((tp) => tp.mentionRoleId || (tp.viewRoleIds || []).length > 0)
              .slice(0, 5)
              .map(
                (tp) =>
                  `**${tp.label}**: ${tp.mentionRoleId ? fmtRole(tp.mentionRoleId) : '*(افتراضية)*'}` +
                  ((tp.viewRoleIds || []).length > 0
                    ? ` | رؤية: ${tp.viewRoleIds.map((r) => `<@&${r}>`).join(', ')}`
                    : '')
              )
              .join('\n') || '*(جميع الأنواع تستخدم الرتبة الافتراضية)*'
          : '*(لا توجد أنواع محددة بعد)*',
      inline: false,
    },
  ];

  const embed = new EmbedBuilder()
    .setColor(COLORS.primary)
    .setTitle(`${ICONS.roles}・الرتب والصلاحيات`)
    .setDescription('إعدادات رتب نظام التذاكر وصلاحيات كل مستوى.')
    .addFields(embed_fields)
    .setFooter({ text: settings.footer })
    .setTimestamp();

  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('tds_roles_support')
      .setLabel('تغيير رتبة الدعم')
      .setEmoji('🎭')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId('tds_roles_moderator')
      .setLabel('تغيير رتبة الإشراف')
      .setEmoji('🛡️')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId('tds_roles_admin')
      .setLabel('تغيير رتبة الإدارة')
      .setEmoji('👑')
      .setStyle(ButtonStyle.Primary)
  );

  return {
    embeds: [embed],
    components: [row1, navRow()],
  };
}

// ─── Task 36 — Messages Section View ──────────────────────────────────────

/**
 * Builds the live Messages section view.
 * Shows the customizable text messages for the ticket system and
 * provides Modal-based editors for each one.
 */
function buildMessagesView(settings, guildConfig) {
  const t = guildConfig.tickets || {};
  const cp = t.closePrompt || {};

  const truncate = (str, max = 80) => {
    if (!str) return '*`(يستخدم النص الافتراضي)`*';
    return str.length > max ? str.slice(0, max) + '…' : str;
  };

  const embed = new EmbedBuilder()
    .setColor(COLORS.primary)
    .setTitle(`${ICONS.messages}・رسائل نظام التذاكر`)
    .setDescription(
      'النصوص المخصصة لنظام التذاكر. اضغط على أي زر لتعديل الرسالة المقابلة.\n' +
        'المتغيرات المتاحة: `{user}` `{type}` `{number}` `{minutes}`'
    )
    .addFields(
      {
        name: '🖼️ عنوان لوحة التذاكر (Panel Title)',
        value: truncate(t.panelTitle),
        inline: false,
      },
      {
        name: '📝 وصف لوحة التذاكر (Panel Description)',
        value: truncate(t.panelDescription),
        inline: false,
      },
      {
        name: '📋 قوانين اللوحة (Panel Rules)',
        value: truncate(t.panelRules),
        inline: false,
      },
      {
        name: '👋 رسالة الترحيب (Welcome Message)',
        value: '*تُعدّل لكل نوع تذكرة على حدة عبر قسم الفئات*',
        inline: false,
      },
      {
        name: '🔒 رسالة الإغلاق (Close Prompt Message)',
        value: truncate(cp.message),
        inline: false,
      },
      {
        name: '🗑️ نص زر الحذف (Delete Button Label)',
        value: truncate(cp.deleteButtonLabel, 40) || '*`(افتراضي)`*',
        inline: true,
      },
      {
        name: '🔓 نص زر إعادة الفتح (Reopen Button Label)',
        value: truncate(cp.reopenButtonLabel, 40) || '*`(افتراضي)`*',
        inline: true,
      },
      {
        name: '⭐ رسالة طلب التقييم (Rating Prompt)',
        value: truncate(t.ratings?.promptMessage),
        inline: false,
      },
      {
        name: '🙏 رسالة شكر التقييم (Rating Thank You)',
        value: truncate(t.ratings?.thankYouMessage),
        inline: false,
      }
    )
    .setFooter({ text: settings.footer })
    .setTimestamp();

  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('tds_messages_paneltitle')
      .setLabel('عنوان اللوحة')
      .setEmoji('🖼️')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId('tds_messages_paneldesc')
      .setLabel('وصف اللوحة')
      .setEmoji('📝')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId('tds_messages_panelrules')
      .setLabel('قوانين اللوحة')
      .setEmoji('📋')
      .setStyle(ButtonStyle.Primary)
  );

  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('tds_messages_closemsg')
      .setLabel('رسالة الإغلاق')
      .setEmoji('🔒')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('tds_messages_deletebtn')
      .setLabel('نص زر الحذف')
      .setEmoji('🗑️')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('tds_messages_reopenbtn')
      .setLabel('نص زر إعادة الفتح')
      .setEmoji('🔓')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('tds_messages_ratingprompt')
      .setLabel('رسالة التقييم')
      .setEmoji('⭐')
      .setStyle(ButtonStyle.Secondary)
  );

  return {
    embeds: [embed],
    components: [row1, row2, navRow()],
  };
}

// ─── Task 37 — Ticket Panel Builder View ───────────────────────────────────

/**
 * Builds the live Panel Builder for the Tickets Dashboard.
 *
 * Discord does not provide a way to persist state inside an ephemeral
 * interaction message, so every selection is saved immediately into
 * tickets.panelBuilder. The final save action then publishes the panel and
 * records its message/channel IDs in the existing ticket fields.
 */
function buildPanelsView(settings, guildConfig) {
  const t = guildConfig.tickets || {};
  const builder = t.panelBuilder || {};
  const buttonLabel = builder.buttonLabel || DEFAULT_PANEL_BUTTON_LABEL;
  const emoji = builder.emoji || DEFAULT_PANEL_EMOJI;

  const embed = new EmbedBuilder()
    .setColor(COLORS.primary)
    .setTitle(`${ICONS.panels}・منشئ لوحة التذاكر`)
    .setDescription(
      'أنشئ لوحة فتح تذاكر من الواجهة مباشرة. اختر مكان النشر، وحدد الفئة التي ستُنشأ فيها التذاكر، ثم خصص اسم الزر والإيموجي واحفظ لإرسال اللوحة.\n\n' +
        'كل اختيار يُحفظ تلقائياً، ويمكنك العودة لاحقاً لإعادة نشر اللوحة أو تحديثها.'
    )
    .addFields(
      { name: '📣 قناة نشر اللوحة', value: fmtChannel(builder.channelId), inline: true },
      { name: '🗂️ فئة قنوات التذاكر', value: fmtChannel(builder.categoryId), inline: true },
      { name: '🔘 اسم الزر', value: `\`${buttonLabel.slice(0, 80)}\``, inline: true },
      { name: '✨ إيموجي الزر', value: emoji, inline: true },
      {
        name: '📌 آخر لوحة منشورة',
        value: t.panelMessageId && t.panelChannelId ? `<#${t.panelChannelId}> — الرسالة محفوظة ✅` : '`لم تُنشر لوحة بعد`',
        inline: false,
      }
    )
    .setFooter({ text: settings.footer })
    .setTimestamp();

  const channelSelect = new ChannelSelectMenuBuilder()
    .setCustomId('tds_panels_channel')
    .setPlaceholder('اختر قناة إرسال اللوحة')
    .setMinValues(1)
    .setMaxValues(1)
    .setChannelTypes(ChannelType.GuildText);

  const categorySelect = new ChannelSelectMenuBuilder()
    .setCustomId('tds_panels_category')
    .setPlaceholder('اختر Category لقنوات التذاكر')
    .setMinValues(1)
    .setMaxValues(1)
    .setChannelTypes(ChannelType.GuildCategory);

  const textRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('tds_panels_label').setLabel('تغيير اسم الزر').setEmoji('🔘').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('tds_panels_emoji').setLabel('تغيير الإيموجي').setEmoji('✨').setStyle(ButtonStyle.Secondary)
  );
  const saveRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('tds_panels_save').setLabel('حفظ وإرسال اللوحة').setEmoji('📨').setStyle(ButtonStyle.Success)
  );

  return {
    embeds: [embed],
    components: [
      new ActionRowBuilder().addComponents(channelSelect),
      new ActionRowBuilder().addComponents(categorySelect),
      textRow,
      saveRow,
      navRow(),
    ],
  };
}

// ─── Modal builders (Task 48 — تفويض لـ modalSystem الموحّد) ────────────────
// الدوال أدناه تُغلّف modalSystem لتحافظ على التوافق مع الكود الحالي
// (buttons.js يستدعيها بنفس الـ API القديم) بينما تنقل المنطق الفعلي
// إلى الملف الموحَّد.

const {
  buildTextModal    : _msText,
  buildChannelModal : _msChannel,
  buildRoleModal    : _msRole,
  buildNumberModal  : _msNumber,
  buildMultiModal   : _msMulti,
} = require('./modalSystem');

/** Opens a single-field text Modal for a ticket message edit. */
function buildMessageModal({ customId, title, label, placeholder, currentValue, maxLength = 1000, required = false, style }) {
  const { TextInputStyle: TIS } = require('discord.js');
  return _msText({
    customId,
    title,
    label,
    placeholder,
    value    : currentValue,
    long     : (style ?? TIS.Paragraph) === TIS.Paragraph,
    required : required ?? false,
    maxLength,
  });
}

/** Opens a number-input Modal (minutes). */
function buildMinutesModal({ customId, title, label, placeholder, currentValue }) {
  return _msNumber({
    customId,
    title,
    label,
    placeholder : placeholder ?? 'أدخل عدداً (0 للتعطيل)',
    current     : currentValue,
    min         : 0,
    max         : 99999,
  });
}

/** Opens a channel-ID Modal (user pastes a channel ID or mention). */
function buildChannelModal({ customId, title, label, currentValue }) {
  return _msChannel({ customId, title, label, current: currentValue });
}

/** Opens a role-ID Modal. */
function buildRoleModal({ customId, title, label, currentValue }) {
  return _msRole({ customId, title, label, current: currentValue });
}

/** Categories: Add/Edit modal (typeId + label + emoji + description fields). */
function buildCategoryModal({ customId, title, existing }) {
  const modal = new ModalBuilder().setCustomId(customId).setTitle(title);

  const idInput = new TextInputBuilder()
    .setCustomId('typeId')
    .setLabel('معرّف النوع (ID) - أحرف صغيرة/أرقام/-/_')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('مثال: general')
    .setRequired(true)
    .setMaxLength(20);

  const labelInput = new TextInputBuilder()
    .setCustomId('label')
    .setLabel('اسم النوع (يظهر على الزر)')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('مثال: دعم عام')
    .setRequired(true)
    .setMaxLength(80);

  const emojiInput = new TextInputBuilder()
    .setCustomId('emoji')
    .setLabel('الإيموجي (اختياري)')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('مثال: 🎫')
    .setRequired(false)
    .setMaxLength(32);

  const descInput = new TextInputBuilder()
    .setCustomId('description')
    .setLabel('الوصف (اختياري، يظهر بجانب الزر)')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('مثال: لأسئلة الدعم العام')
    .setRequired(false)
    .setMaxLength(150);

  if (existing) {
    idInput.setValue(existing.typeId || '');
    labelInput.setValue(existing.label || '');
    if (existing.emoji) emojiInput.setValue(existing.emoji);
    if (existing.description) descInput.setValue(existing.description);
  }

  modal.addComponents(
    new ActionRowBuilder().addComponents(idInput),
    new ActionRowBuilder().addComponents(labelInput),
    new ActionRowBuilder().addComponents(emojiInput),
    new ActionRowBuilder().addComponents(descInput)
  );

  return modal;
}

/** Categories: Delete confirmation — asks for the typeId to confirm deletion. */
function buildCategoryDeleteModal() {
  const modal = new ModalBuilder().setCustomId('tds_categories_delete_confirm').setTitle('حذف نوع تذكرة');
  const input = new TextInputBuilder()
    .setCustomId('typeId')
    .setLabel('معرّف النوع المراد حذفه')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('اكتب معرّف النوع بدقة للتأكيد')
    .setRequired(true)
    .setMaxLength(20);
  modal.addComponents(new ActionRowBuilder().addComponents(input));
  return modal;
}

/**
 * TASK44: confirmation for `tds_settings_closepromptreset` - resets are a
 * risky/destructive operation (rule 14), so this asks the admin to type a
 * fixed confirmation word, same "type-to-confirm" pattern already used by
 * buildCategoryDeleteModal above instead of introducing a new UX pattern.
 */
function buildClosePromptResetModal() {
  const modal = new ModalBuilder().setCustomId('tds_settings_closepromptreset_confirm').setTitle('إعادة ضبط رسائل الإغلاق');
  const input = new TextInputBuilder()
    .setCustomId('confirm')
    .setLabel('اكتب "reset" للتأكيد')
    .setStyle(TextInputStyle.Short)
    .setPlaceholder('reset')
    .setRequired(true)
    .setMaxLength(10);
  modal.addComponents(new ActionRowBuilder().addComponents(input));
  return modal;
}

module.exports = {
  // View builders
  buildSettingsView,
  buildCategoriesView,
  buildRolesView,
  buildMessagesView,
  buildPanelsView,
  // Modal builders
  buildMessageModal,
  buildMinutesModal,
  buildChannelModal,
  buildRoleModal,
  buildCategoryModal,
  buildCategoryDeleteModal,
  buildClosePromptResetModal,
};
