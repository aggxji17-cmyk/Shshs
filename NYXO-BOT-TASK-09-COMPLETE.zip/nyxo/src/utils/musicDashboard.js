/**
 * Task 45 — Music Settings UI (إعدادات الموسيقى).
 *
 * Renders the interactive music configuration section that opens when
 * the admin picks "الموسيقى" from the /settings dashboard.
 *
 * Controls exposed:
 *   • تشغيل/إيقاف وضع 24/7              (smu_247_toggle)
 *   • قناة الصوت لـ 24/7                 (smu_247_voice)   → Modal
 *   • قناة النص لـ 24/7                  (smu_247_text)    → Modal
 *   Navigation: settings_back / settings_home / settings_close
 *
 * All modals:
 *   smu_modal_247_voice  — voice channel ID for 24/7
 *   smu_modal_247_text   — text channel ID for 24/7 Now Playing messages
 */

const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
} = require('discord.js');
const { COLORS, ICONS, DIVIDER } = require('./designSystem');
const { getGuildConfig, resolved, invalidateGuildConfig } = require('./resolveGuildSettings');
const { errorEmbed } = require('./embeds');
const { isGuildManager } = require('./permissions');
const logger = require('./logger');

// ─── CustomId constants ───────────────────────────────────────────────────────
const SMU_247_TOGGLE_ID   = 'smu_247_toggle';
const SMU_247_VOICE_ID    = 'smu_247_voice';
const SMU_247_TEXT_ID     = 'smu_247_text';

const SMU_MODAL_247_VOICE = 'smu_modal_247_voice';
const SMU_MODAL_247_TEXT  = 'smu_modal_247_text';

// ─── Helpers ──────────────────────────────────────────────────────────────────
function onOff(bool) {
  return bool ? `${ICONS.success} مُفعَّل` : `${ICONS.error} مُعطَّل`;
}

function navRow() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('settings_back').setLabel('رجوع / Back').setEmoji(ICONS.back).setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('settings_home').setLabel('الرئيسية / Home').setEmoji(ICONS.home).setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('settings_close').setLabel('إغلاق / Close').setEmoji(ICONS.close).setStyle(ButtonStyle.Danger),
  );
}

// ─── View builder ─────────────────────────────────────────────────────────────
function buildMusicView(settings, guildConfig) {
  const mus = guildConfig?.music ?? {};
  const tfs = mus.twentyFourSeven ?? {};

  const voiceCh = tfs.voiceChannelId ? `<#${tfs.voiceChannelId}>` : '—';
  const textCh  = tfs.textChannelId  ? `<#${tfs.textChannelId}>`  : '—';

  const embed = new EmbedBuilder()
    .setColor(COLORS.primary)
    .setTitle(`${ICONS.music}・إعدادات الموسيقى (Music)`)
    .setDescription(
      `إعداد مشغل الموسيقى ووضع التشغيل المستمر 24/7.\n${DIVIDER}`
    )
    .addFields(
      { name: `🔁 وضع 24/7`, value: onOff(tfs.enabled ?? false), inline: true },
      { name: `🔊 قناة الصوت (24/7)`, value: voiceCh, inline: true },
      { name: `💬 قناة النص (24/7)`, value: textCh, inline: true },
    )
    .addFields({
      name: `${ICONS.info} ملاحظة`,
      value:
        'وضع 24/7 يبقي البوت متصلاً بالقناة الصوتية حتى بدون تشغيل موسيقى. ' +
        'استخدم الأوامر `/247 enable` و `/247 disable` للتحكم المباشر.',
      inline: false,
    })
    .setFooter({ text: `${settings.footer} • استخدم الأزرار أدناه لتعديل الإعدادات` })
    .setTimestamp();

  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(SMU_247_TOGGLE_ID)
      .setLabel(tfs.enabled ? 'تعطيل وضع 24/7' : 'تفعيل وضع 24/7')
      .setEmoji(tfs.enabled ? ICONS.error : ICONS.success)
      .setStyle(tfs.enabled ? ButtonStyle.Danger : ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(SMU_247_VOICE_ID)
      .setLabel('قناة الصوت (24/7)')
      .setEmoji('🔊')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId(SMU_247_TEXT_ID)
      .setLabel('قناة النص (24/7)')
      .setEmoji('💬')
      .setStyle(ButtonStyle.Primary),
  );

  return { embeds: [embed], components: [row1, navRow()] };
}

// ─── Interaction handlers ─────────────────────────────────────────────────────

async function handleMusicButton(interaction) {
  const id = interaction.customId;
  const guildConfig = await getGuildConfig(interaction.guildId);
  const settings    = resolved(guildConfig);

  if (!isGuildManager(interaction.member, guildConfig)) {
    return interaction.reply({
      embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر (Manage Server) لاستخدام هذه الواجهة.')],
      ephemeral: true,
    });
  }

  if (id === SMU_247_TOGGLE_ID) {
    const current = guildConfig.music?.twentyFourSeven?.enabled ?? false;
    guildConfig.music.twentyFourSeven.enabled = !current;
    await guildConfig.save();
    invalidateGuildConfig(interaction.guildId);
    const updated = await getGuildConfig(interaction.guildId);
    const view = buildMusicView(resolved(updated), updated);
    return interaction.update({ embeds: view.embeds, components: view.components });
  }

  if (id === SMU_247_VOICE_ID) {
    const modal = new ModalBuilder().setCustomId(SMU_MODAL_247_VOICE).setTitle('قناة الصوت لوضع 24/7');
    modal.addComponents(new ActionRowBuilder().addComponents(
      new TextInputBuilder().setCustomId('channel_id').setLabel('معرف قناة الصوت (Channel ID)')
        .setStyle(TextInputStyle.Short).setPlaceholder('أدخل معرف القناة أو اتركه فارغاً للإلغاء').setRequired(false)
        .setValue(guildConfig.music?.twentyFourSeven?.voiceChannelId ?? ''),
    ));
    return interaction.showModal(modal);
  }

  if (id === SMU_247_TEXT_ID) {
    const modal = new ModalBuilder().setCustomId(SMU_MODAL_247_TEXT).setTitle('قناة النص لوضع 24/7');
    modal.addComponents(new ActionRowBuilder().addComponents(
      new TextInputBuilder().setCustomId('channel_id').setLabel('معرف قناة النص (Channel ID)')
        .setStyle(TextInputStyle.Short).setPlaceholder('أدخل معرف القناة أو اتركه فارغاً للإلغاء').setRequired(false)
        .setValue(guildConfig.music?.twentyFourSeven?.textChannelId ?? ''),
    ));
    return interaction.showModal(modal);
  }
}

async function handleMusicModal(interaction) {
  const id = interaction.customId;
  const guildConfig = await getGuildConfig(interaction.guildId);
  const settings    = resolved(guildConfig);

  if (!isGuildManager(interaction.member, guildConfig)) {
    return interaction.reply({
      embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر (Manage Server) لاستخدام هذه الواجهة.')],
      ephemeral: true,
    });
  }

  try {
    const val = interaction.fields.getTextInputValue('channel_id').trim();

    if (id === SMU_MODAL_247_VOICE) {
      guildConfig.music.twentyFourSeven.voiceChannelId = val || null;
    }
    if (id === SMU_MODAL_247_TEXT) {
      guildConfig.music.twentyFourSeven.textChannelId = val || null;
    }

    await interaction.deferUpdate();
    await guildConfig.save();
    invalidateGuildConfig(interaction.guildId);
    const updated = await getGuildConfig(interaction.guildId);
    const view = buildMusicView(resolved(updated), updated);
    return interaction.editReply({ embeds: view.embeds, components: view.components });

  } catch (err) {
    logger.error('[musicDashboard] Modal save error:', err);
    return (interaction.deferred || interaction.replied ? interaction.followUp : interaction.reply).call(interaction, { embeds: [errorEmbed(settings, 'حدث خطأ أثناء حفظ الإعداد.')], ephemeral: true });
  }
}

module.exports = {
  buildMusicView,
  handleMusicButton,
  handleMusicModal,
  SMU_247_TOGGLE_ID,
  SMU_247_VOICE_ID,
  SMU_247_TEXT_ID,
  SMU_MODAL_247_VOICE,
  SMU_MODAL_247_TEXT,
};
