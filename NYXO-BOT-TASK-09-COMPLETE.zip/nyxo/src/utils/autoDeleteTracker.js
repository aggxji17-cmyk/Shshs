/**
 * Small in-memory registry for messages that are about to be removed by an
 * auto-delete-channel timer (see events/message/messageCreate.js). The
 * messageDelete handler checks this before running ghost-ping / snipe
 * logic, so a scheduled cleanup doesn't get logged as a "ghost ping".
 *
 * TASK 27 — Performance:
 * The previous implementation scheduled a separate setTimeout() per
 * message. Under high message volume this created one timer object per
 * message, adding GC pressure. Replaced with a Map<messageId, expiresAt>
 * and a single shared sweep interval — same cleanup semantics, far fewer
 * timer allocations.
 */

const ENTRY_TTL_MS = 5 * 60 * 1000;
// Map<messageId, expiresAtMs>
const pending = new Map();

function markAutoDeleted(messageId) {
  pending.set(messageId, Date.now() + ENTRY_TTL_MS);
}

function wasAutoDeleted(messageId) {
  const exp = pending.get(messageId);
  if (exp === undefined) return false;
  if (Date.now() > exp) {
    pending.delete(messageId);
    return false;
  }
  return true;
}

// Single shared sweep — evicts expired entries once per TTL period.
// unref() so this never keeps the process alive on its own.
const sweepTimer = setInterval(() => {
  const now = Date.now();
  for (const [id, exp] of pending) {
    if (now > exp) pending.delete(id);
  }
}, ENTRY_TTL_MS);
sweepTimer.unref();

module.exports = { markAutoDeleted, wasAutoDeleted };
