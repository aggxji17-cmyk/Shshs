/**
 * Task 45 — Moderation Settings UI (إعدادات الإشراف).
 *
 * Renders the interactive moderation configuration section that opens when
 * the admin picks "الإشراف" from the /settings dashboard.
 *
 * Controls exposed:
 *   • تشغيل/إيقاف نظام الموافقة          (smd_approvals_toggle)
 *   • قناة مراجعة الطلبات               (smd_review_channel)   → Modal
 *   • تشغيل/إيقاف Ghost Ping            (smd_ghostping_toggle)
 *   • تشغيل/إيقاف حدود Ban              (smd_ban_limits_toggle)
 *   • تشغيل/إيقاف حدود Kick             (smd_kick_limits_toggle)
 *   Navigation: settings_back / settings_home / settings_close
 *
 * All modals:
 *   smd_modal_review_channel — review channel ID for approvals
 */

const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
} = require('discord.js');
const { COLORS, ICONS, DIVIDER } = require('./designSystem');
const { getGuildConfig, resolved, invalidateGuildConfig } = require('./resolveGuildSettings');
const { errorEmbed } = require('./embeds');
const { isGuildManager } = require('./permissions');
const logger = require('./logger');

// ─── CustomId constants ───────────────────────────────────────────────────────
const SMD_APPROVALS_TOGGLE_ID   = 'smd_approvals_toggle';
const SMD_REVIEW_CHANNEL_ID     = 'smd_review_channel';
const SMD_GHOSTPING_TOGGLE_ID   = 'smd_ghostping_toggle';
const SMD_BAN_LIMITS_TOGGLE_ID  = 'smd_ban_limits_toggle';
const SMD_KICK_LIMITS_TOGGLE_ID = 'smd_kick_limits_toggle';

const SMD_MODAL_REVIEW_CHANNEL  = 'smd_modal_review_channel';

// ─── Helpers ──────────────────────────────────────────────────────────────────
function onOff(bool) {
  return bool ? `${ICONS.success} مُفعَّل` : `${ICONS.error} مُعطَّل`;
}

function navRow() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('settings_back').setLabel('رجوع / Back').setEmoji(ICONS.back).setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('settings_home').setLabel('الرئيسية / Home').setEmoji(ICONS.home).setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('settings_close').setLabel('إغلاق / Close').setEmoji(ICONS.close).setStyle(ButtonStyle.Danger),
  );
}

// ─── View builder ─────────────────────────────────────────────────────────────
function buildModerationSettingsView(settings, guildConfig) {
  const mod  = guildConfig?.moderation ?? {};
  const appr = guildConfig?.approvals ?? {};

  const reviewCh = appr.reviewChannelId ? `<#${appr.reviewChannelId}>` : '—';

  const embed = new EmbedBuilder()
    .setColor(COLORS.primary)
    .setTitle(`${ICONS.moderation}・إعدادات الإشراف (Moderation)`)
    .setDescription(`إدارة نظام الموافقة وصلاحيات الإشراف وقيود الأوامر.\n${DIVIDER}`)
    .addFields(
      { name: `🛡️ نظام الموافقة (Approvals)`, value: onOff(appr.enabled ?? false), inline: true },
      { name: `📋 قناة المراجعة`, value: reviewCh, inline: true },
      { name: `👻 مكافحة Ghost Ping`, value: onOff(mod.antiGhostPing ?? false), inline: true },
      { name: `🔨 حدود /ban أسبوعية`, value: onOff(mod.banLimits?.enabled ?? false), inline: true },
      { name: `👟 حدود /kick أسبوعية`, value: onOff(mod.kickLimits?.enabled ?? false), inline: true },
    )
    .addFields({
      name: `${ICONS.info} ملاحظة`,
      value:
        'للتحكم الكامل في حدود Bans/Kicks/Timeouts وإعدادات العقوبات، استخدم الأوامر ' +
        '`/warnconfig` و `/moderation` و `/blacklist` المتخصصة. هذه الواجهة تتحكم في الإعدادات العامة فقط.',
      inline: false,
    })
    .setFooter({ text: `${settings.footer} • استخدم الأزرار أدناه لتعديل الإعدادات` })
    .setTimestamp();

  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(SMD_APPROVALS_TOGGLE_ID)
      .setLabel(appr.enabled ? 'تعطيل الموافقة' : 'تفعيل الموافقة')
      .setEmoji(appr.enabled ? ICONS.error : ICONS.success)
      .setStyle(appr.enabled ? ButtonStyle.Danger : ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(SMD_REVIEW_CHANNEL_ID)
      .setLabel('قناة المراجعة')
      .setEmoji(ICONS.logging)
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId(SMD_GHOSTPING_TOGGLE_ID)
      .setLabel(mod.antiGhostPing ? 'تعطيل Ghost Ping' : 'تفعيل Ghost Ping')
      .setEmoji('👻')
      .setStyle(mod.antiGhostPing ? ButtonStyle.Danger : ButtonStyle.Success),
  );

  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(SMD_BAN_LIMITS_TOGGLE_ID)
      .setLabel(mod.banLimits?.enabled ? 'تعطيل حدود Ban' : 'تفعيل حدود Ban')
      .setEmoji('🔨')
      .setStyle(mod.banLimits?.enabled ? ButtonStyle.Danger : ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(SMD_KICK_LIMITS_TOGGLE_ID)
      .setLabel(mod.kickLimits?.enabled ? 'تعطيل حدود Kick' : 'تفعيل حدود Kick')
      .setEmoji('👟')
      .setStyle(mod.kickLimits?.enabled ? ButtonStyle.Danger : ButtonStyle.Success),
  );

  return { embeds: [embed], components: [row1, row2, navRow()] };
}

// ─── Interaction handlers ─────────────────────────────────────────────────────

async function handleModerationSettingsButton(interaction) {
  const id = interaction.customId;
  const guildConfig = await getGuildConfig(interaction.guildId);
  const settings    = resolved(guildConfig);

  if (!isGuildManager(interaction.member, guildConfig)) {
    return interaction.reply({
      embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر (Manage Server) لاستخدام هذه الواجهة.')],
      ephemeral: true,
    });
  }

  if (id === SMD_APPROVALS_TOGGLE_ID) {
    const current = guildConfig.approvals?.enabled ?? false;
    guildConfig.approvals.enabled = !current;
    await guildConfig.save();
    invalidateGuildConfig(interaction.guildId);
    const updated = await getGuildConfig(interaction.guildId);
    const view = buildModerationSettingsView(resolved(updated), updated);
    return interaction.update({ embeds: view.embeds, components: view.components });
  }

  if (id === SMD_GHOSTPING_TOGGLE_ID) {
    const current = guildConfig.moderation?.antiGhostPing ?? false;
    guildConfig.moderation.antiGhostPing = !current;
    await guildConfig.save();
    invalidateGuildConfig(interaction.guildId);
    const updated = await getGuildConfig(interaction.guildId);
    const view = buildModerationSettingsView(resolved(updated), updated);
    return interaction.update({ embeds: view.embeds, components: view.components });
  }

  if (id === SMD_BAN_LIMITS_TOGGLE_ID) {
    const current = guildConfig.moderation?.banLimits?.enabled ?? false;
    guildConfig.moderation.banLimits.enabled = !current;
    await guildConfig.save();
    invalidateGuildConfig(interaction.guildId);
    const updated = await getGuildConfig(interaction.guildId);
    const view = buildModerationSettingsView(resolved(updated), updated);
    return interaction.update({ embeds: view.embeds, components: view.components });
  }

  if (id === SMD_KICK_LIMITS_TOGGLE_ID) {
    const current = guildConfig.moderation?.kickLimits?.enabled ?? false;
    guildConfig.moderation.kickLimits.enabled = !current;
    await guildConfig.save();
    invalidateGuildConfig(interaction.guildId);
    const updated = await getGuildConfig(interaction.guildId);
    const view = buildModerationSettingsView(resolved(updated), updated);
    return interaction.update({ embeds: view.embeds, components: view.components });
  }

  if (id === SMD_REVIEW_CHANNEL_ID) {
    const modal = new ModalBuilder().setCustomId(SMD_MODAL_REVIEW_CHANNEL).setTitle('قناة مراجعة الموافقة');
    modal.addComponents(new ActionRowBuilder().addComponents(
      new TextInputBuilder().setCustomId('channel_id').setLabel('معرف قناة المراجعة')
        .setStyle(TextInputStyle.Short).setPlaceholder('أدخل معرف القناة أو اتركه فارغاً للإلغاء').setRequired(false)
        .setValue(guildConfig.approvals?.reviewChannelId ?? ''),
    ));
    return interaction.showModal(modal);
  }
}

async function handleModerationSettingsModal(interaction) {
  const id = interaction.customId;
  const guildConfig = await getGuildConfig(interaction.guildId);
  const settings    = resolved(guildConfig);

  if (!isGuildManager(interaction.member, guildConfig)) {
    return interaction.reply({
      embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر (Manage Server) لاستخدام هذه الواجهة.')],
      ephemeral: true,
    });
  }

  try {
    await interaction.deferUpdate();
    if (id === SMD_MODAL_REVIEW_CHANNEL) {
      const val = interaction.fields.getTextInputValue('channel_id').trim();
      guildConfig.approvals.reviewChannelId = val || null;
      await guildConfig.save();
      invalidateGuildConfig(interaction.guildId);
    }

    const updated = await getGuildConfig(interaction.guildId);
    const view = buildModerationSettingsView(resolved(updated), updated);
    return interaction.editReply({ embeds: view.embeds, components: view.components });

  } catch (err) {
    logger.error('[moderationSettingsDashboard] Modal save error:', err);
    return (interaction.deferred || interaction.replied ? interaction.followUp : interaction.reply).call(interaction, { embeds: [errorEmbed(settings, 'حدث خطأ أثناء حفظ الإعداد.')], ephemeral: true });
  }
}

module.exports = {
  buildModerationSettingsView,
  handleModerationSettingsButton,
  handleModerationSettingsModal,
  SMD_APPROVALS_TOGGLE_ID,
  SMD_REVIEW_CHANNEL_ID,
  SMD_GHOSTPING_TOGGLE_ID,
  SMD_BAN_LIMITS_TOGGLE_ID,
  SMD_KICK_LIMITS_TOGGLE_ID,
  SMD_MODAL_REVIEW_CHANNEL,
};
