/**
 * Task 40 — Welcome/Leave Settings UI (إعدادات الترحيب والمغادرة).
 *
 * Renders the interactive welcome/goodbye configuration section that opens
 * when the admin picks "الترحيب" from the /settings dashboard.
 *
 * Controls exposed:
 *   Welcome system:
 *     • تشغيل/إيقاف الترحيب (swl_welcome_toggle)
 *     • تحديد قناة الترحيب  (swl_welcome_channel)
 *     • تعديل رسالة الترحيب (swl_welcome_message)
 *     • تشغيل/إيقاف الرسالة الخاصة (DM) (swl_welcome_dm_toggle)
 *     • معاينة رسالة الترحيب (swl_welcome_preview)
 *   Goodbye system:
 *     • تشغيل/إيقاف الوداع  (swl_goodbye_toggle)
 *     • تحديد قناة الوداع   (swl_goodbye_channel)
 *     • تعديل رسالة الوداع  (swl_goodbye_message)
 *     • معاينة رسالة الوداع (swl_goodbye_preview)
 *   Navigation: settings_back / settings_home / settings_close
 *
 * All modals:
 *   swl_modal_welcome_channel  — channel ID for welcome
 *   swl_modal_welcome_message  — welcome message text
 *   swl_modal_goodbye_channel  — channel ID for goodbye
 *   swl_modal_goodbye_message  — goodbye message text
 */

const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require('discord.js');
const { COLORS, ICONS } = require('./designSystem');

// ─────────────────────────────────────────────────────────────────────────────
// CustomId constants
// ─────────────────────────────────────────────────────────────────────────────
const SWL_WELCOME_TOGGLE_ID   = 'swl_welcome_toggle';
const SWL_WELCOME_CHANNEL_ID  = 'swl_welcome_channel';
const SWL_WELCOME_MESSAGE_ID  = 'swl_welcome_message';
const SWL_WELCOME_DM_TOGGLE_ID= 'swl_welcome_dm_toggle';
const SWL_WELCOME_PREVIEW_ID  = 'swl_welcome_preview';
const SWL_GOODBYE_TOGGLE_ID   = 'swl_goodbye_toggle';
const SWL_GOODBYE_CHANNEL_ID  = 'swl_goodbye_channel';
const SWL_GOODBYE_MESSAGE_ID  = 'swl_goodbye_message';
const SWL_GOODBYE_PREVIEW_ID  = 'swl_goodbye_preview';

// ─────────────────────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────────────────────

function statusEmoji(enabled) {
  return enabled ? '🟢' : '🔴';
}

function channelDisplay(channelId) {
  return channelId ? `<#${channelId}>` : '❌ لم يتم التحديد';
}

function messagePreview(text, defaultText) {
  const t = text || defaultText;
  if (!t) return '_(افتراضي)_';
  return t.length > 80 ? t.slice(0, 80) + '…' : t;
}

/** Shared navigation row (back / home / close). */
function navigationRow() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('settings_back')
      .setLabel('رجوع / Back')
      .setEmoji(ICONS.back)
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('settings_home')
      .setLabel('الرئيسية / Home')
      .setEmoji(ICONS.home)
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('settings_close')
      .setLabel('إغلاق / Close')
      .setEmoji(ICONS.close)
      .setStyle(ButtonStyle.Danger),
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Main view builder
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Builds the full Welcome/Leave section view.
 *
 * @param {object} settings    - resolved guild settings
 * @param {object} guildConfig - raw Mongoose document
 * @returns {{ embeds: EmbedBuilder[], components: ActionRowBuilder[] }}
 */
function buildWelcomeView(settings, guildConfig) {
  const welcome = guildConfig.welcome || {};
  const goodbye = guildConfig.goodbye || {};

  const welcomeEnabled = !!welcome.enabled;
  const goodbyeEnabled = !!goodbye.enabled;
  const dmEnabled      = !!welcome.dm?.enabled;

  const DEFAULT_WELCOME = 'Welcome {user} to **{server}**! You are member #{memberCount}.';
  const DEFAULT_GOODBYE = '{user} has left **{server}**. Goodbye!';

  // ── Embed ──────────────────────────────────────────────────────────────────
  const embed = new EmbedBuilder()
    .setColor(welcomeEnabled || goodbyeEnabled ? COLORS.success : COLORS.neutral)
    .setTitle(`${ICONS.welcome}・إعدادات الترحيب والمغادرة (Welcome / Leave)`)
    .setDescription(
      'أدِر رسائل الترحيب بالأعضاء الجدد ورسائل الوداع عند المغادرة من هنا.\n' +
      'استخدم `{user}` `{username}` `{server}` `{memberCount}` كمتغيرات داخل الرسائل.'
    )
    .addFields(
      {
        name: `${ICONS.welcome} الترحيب (Welcome)`,
        value:
          `الحالة: ${statusEmoji(welcomeEnabled)} ${welcomeEnabled ? 'مُفعَّل' : 'معطَّل'}\n` +
          `القناة: ${channelDisplay(welcome.channelId)}\n` +
          `الرسالة: ${messagePreview(welcome.message, DEFAULT_WELCOME)}\n` +
          `DM للأعضاء الجدد: ${statusEmoji(dmEnabled)} ${dmEnabled ? 'مُفعَّل' : 'معطَّل'}`,
        inline: false,
      },
      {
        name: `➖ الوداع (Leave)`,
        value:
          `الحالة: ${statusEmoji(goodbyeEnabled)} ${goodbyeEnabled ? 'مُفعَّل' : 'معطَّل'}\n` +
          `القناة: ${channelDisplay(goodbye.channelId)}\n` +
          `الرسالة: ${messagePreview(goodbye.message, DEFAULT_GOODBYE)}`,
        inline: false,
      }
    )
    .setFooter({ text: settings.footer })
    .setTimestamp();

  // ── Row 1: Welcome controls ────────────────────────────────────────────────
  const welcomeRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(SWL_WELCOME_TOGGLE_ID)
      .setLabel(welcomeEnabled ? 'إيقاف الترحيب' : 'تشغيل الترحيب')
      .setEmoji(welcomeEnabled ? '🔴' : '🟢')
      .setStyle(welcomeEnabled ? ButtonStyle.Danger : ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(SWL_WELCOME_CHANNEL_ID)
      .setLabel('قناة الترحيب')
      .setEmoji('📌')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId(SWL_WELCOME_MESSAGE_ID)
      .setLabel('رسالة الترحيب')
      .setEmoji('✏️')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId(SWL_WELCOME_DM_TOGGLE_ID)
      .setLabel(dmEnabled ? 'إيقاف DM' : 'تشغيل DM')
      .setEmoji('📩')
      .setStyle(dmEnabled ? ButtonStyle.Danger : ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId(SWL_WELCOME_PREVIEW_ID)
      .setLabel('معاينة')
      .setEmoji('👁️')
      .setStyle(ButtonStyle.Secondary),
  );

  // ── Row 2: Goodbye controls ────────────────────────────────────────────────
  const goodbyeRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(SWL_GOODBYE_TOGGLE_ID)
      .setLabel(goodbyeEnabled ? 'إيقاف الوداع' : 'تشغيل الوداع')
      .setEmoji(goodbyeEnabled ? '🔴' : '🟢')
      .setStyle(goodbyeEnabled ? ButtonStyle.Danger : ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(SWL_GOODBYE_CHANNEL_ID)
      .setLabel('قناة الوداع')
      .setEmoji('📌')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId(SWL_GOODBYE_MESSAGE_ID)
      .setLabel('رسالة الوداع')
      .setEmoji('✏️')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId(SWL_GOODBYE_PREVIEW_ID)
      .setLabel('معاينة')
      .setEmoji('👁️')
      .setStyle(ButtonStyle.Secondary),
  );

  return {
    embeds:     [embed],
    components: [welcomeRow, goodbyeRow, navigationRow()],
  };
}

/**
 * Builds a preview embed shown ephemerally when admin clicks "معاينة".
 * Replaces placeholders with mock values so the admin sees the final look.
 */
function buildPreviewEmbed(settings, guildConfig, type) {
  const isWelcome = type === 'welcome';
  const cfg       = isWelcome ? guildConfig.welcome : guildConfig.goodbye;
  const DEFAULT   = isWelcome
    ? 'Welcome {user} to **{server}**! You are member #{memberCount}.'
    : '{user} has left **{server}**. Goodbye!';

  const rawMsg = cfg?.message || DEFAULT;

  // Mock placeholder values for preview
  const previewMsg = rawMsg
    .replaceAll('{user}', '**@عضو_جديد**')
    .replaceAll('{username}', 'عضو_جديد')
    .replaceAll('{tag}', 'عضو_جديد#0000')
    .replaceAll('{server}', '**اسم السيرفر**')
    .replaceAll('{memberCount}', '1234')
    .replaceAll('{ordinal}', '1,234th');

  const title  = isWelcome ? '👋 معاينة رسالة الترحيب' : '➖ معاينة رسالة الوداع';
  const color  = isWelcome
    ? (guildConfig.welcome?.color || settings.embedColor || COLORS.success)
    : COLORS.neutral;

  const embed = new EmbedBuilder()
    .setColor(color)
    .setTitle(title)
    .setDescription(previewMsg)
    .setFooter({ text: 'هذه معاينة — القيم الحقيقية تأتي عند انضمام/مغادرة أعضاء فعليين.' });

  if (isWelcome && guildConfig.welcome?.imageUrl) {
    embed.setImage(guildConfig.welcome.imageUrl);
  }

  return embed;
}

module.exports = {
  SWL_WELCOME_TOGGLE_ID,
  SWL_WELCOME_CHANNEL_ID,
  SWL_WELCOME_MESSAGE_ID,
  SWL_WELCOME_DM_TOGGLE_ID,
  SWL_WELCOME_PREVIEW_ID,
  SWL_GOODBYE_TOGGLE_ID,
  SWL_GOODBYE_CHANNEL_ID,
  SWL_GOODBYE_MESSAGE_ID,
  SWL_GOODBYE_PREVIEW_ID,
  buildWelcomeView,
  buildPreviewEmbed,
};
