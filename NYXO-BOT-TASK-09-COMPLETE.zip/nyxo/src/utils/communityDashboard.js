/**
 * TASK-09 — Community Settings Dashboard
 *
 * Handles /settings panel sections for:
 *   - suggestions   (suggestionsetup → /settings → suggestions)
 *   - booster       (boosterannounce → /settings → booster)
 *   - membercount   (membercount → /settings → membercount)
 *   - starboard     (starboard → /settings → starboard)
 *   - counting      (counting → /settings → counting)
 *
 * All modals use prefix: scd_ (Settings Community Dashboard)
 */

const {
  EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle,
  ModalBuilder, TextInputBuilder, TextInputStyle,
} = require('discord.js');
const { COLORS, ICONS, DIVIDER } = require('./designSystem');
const { getGuildConfig, resolved, invalidateGuildConfig } = require('./resolveGuildSettings');
const { successEmbed, errorEmbed } = require('./embeds');
const { isGuildManager } = require('./permissions');
const logger = require('./logger');

// ─── CustomId constants ────────────────────────────────────────────────────
// Suggestions
const SCD_SUGGEST_TOGGLE   = 'scd_suggest_toggle';
const SCD_SUGGEST_CHANNEL  = 'scd_suggest_channel';
const SCD_MODAL_SUGGEST_CH = 'scd_modal_suggest_ch';

// Booster
const SCD_BOOST_TOGGLE     = 'scd_boost_toggle';
const SCD_BOOST_CHANNEL    = 'scd_boost_channel';
const SCD_BOOST_MESSAGE    = 'scd_boost_message';
const SCD_MODAL_BOOST_CH   = 'scd_modal_boost_ch';
const SCD_MODAL_BOOST_MSG  = 'scd_modal_boost_msg';

// Member count
const SCD_MC_TOGGLE        = 'scd_mc_toggle';
const SCD_MC_CHANNEL       = 'scd_mc_channel';
const SCD_MC_FORMAT        = 'scd_mc_format';
const SCD_MODAL_MC_CH      = 'scd_modal_mc_ch';
const SCD_MODAL_MC_FMT     = 'scd_modal_mc_fmt';

// Starboard
const SCD_SB_TOGGLE        = 'scd_sb_toggle';
const SCD_SB_CONFIG        = 'scd_sb_config';
const SCD_MODAL_SB_CONFIG  = 'scd_modal_sb_config';

// Counting
const SCD_CNT_ENABLE       = 'scd_cnt_enable';
const SCD_CNT_DISABLE      = 'scd_cnt_disable';
const SCD_CNT_RESET        = 'scd_cnt_reset';
const SCD_MODAL_CNT_CH     = 'scd_modal_cnt_ch';

// ─── Navigation helpers ────────────────────────────────────────────────────
function navRow() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('settings_back').setLabel('رجوع / Back').setEmoji(ICONS.back).setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('settings_home').setLabel('الرئيسية / Home').setEmoji(ICONS.home).setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('settings_close').setLabel('إغلاق / Close').setEmoji(ICONS.close).setStyle(ButtonStyle.Danger),
  );
}

function onOff(bool) { return bool ? `${ICONS.success} مُفعَّل` : `${ICONS.error} مُعطَّل`; }
function ch(id) { return id ? `<#${id}>` : '—'; }

// ─── SUGGESTIONS ──────────────────────────────────────────────────────────
function buildSuggestionsView(settings, guildConfig) {
  const sug = guildConfig?.suggestions ?? {};
  const embed = new EmbedBuilder()
    .setColor(COLORS.primary)
    .setTitle(`💡・إعدادات الاقتراحات (Suggestions)`)
    .setDescription(`إعداد قناة الاقتراحات وتفعيلها.\n${DIVIDER}`)
    .addFields(
      { name: '⚙️ الحالة', value: onOff(sug.enabled), inline: true },
      { name: '📢 القناة', value: ch(sug.channelId), inline: true },
    )
    .setFooter({ text: settings.footer }).setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(SCD_SUGGEST_TOGGLE)
      .setLabel(sug.enabled ? 'تعطيل الاقتراحات' : 'تفعيل الاقتراحات')
      .setEmoji(sug.enabled ? ICONS.error : ICONS.success)
      .setStyle(sug.enabled ? ButtonStyle.Danger : ButtonStyle.Success),
    new ButtonBuilder().setCustomId(SCD_SUGGEST_CHANNEL)
      .setLabel('تعيين القناة').setEmoji('📢').setStyle(ButtonStyle.Primary),
  );

  return { embeds: [embed], components: [row, navRow()] };
}

// ─── BOOSTER ANNOUNCE ─────────────────────────────────────────────────────
function buildBoosterView(settings, guildConfig) {
  const ba = guildConfig?.boosterAnnounce ?? {};
  const embed = new EmbedBuilder()
    .setColor(COLORS.primary)
    .setTitle(`🚀・إعلانات التعزيز (Booster Announce)`)
    .setDescription(`إعداد رسائل تعزيز السيرفر.\n${DIVIDER}`)
    .addFields(
      { name: '⚙️ الحالة', value: onOff(ba.enabled), inline: true },
      { name: '📢 القناة', value: ch(ba.channelId), inline: true },
      { name: '💬 الرسالة', value: ba.message ? ba.message.slice(0, 100) + (ba.message.length > 100 ? '…' : '') : '_(افتراضية)_', inline: false },
    )
    .setFooter({ text: `${settings.footer} • {user} و {server} متاحان` }).setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(SCD_BOOST_TOGGLE)
      .setLabel(ba.enabled ? 'تعطيل الإعلانات' : 'تفعيل الإعلانات')
      .setEmoji(ba.enabled ? ICONS.error : ICONS.success)
      .setStyle(ba.enabled ? ButtonStyle.Danger : ButtonStyle.Success),
    new ButtonBuilder().setCustomId(SCD_BOOST_CHANNEL).setLabel('تعيين القناة').setEmoji('📢').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId(SCD_BOOST_MESSAGE).setLabel('تعيين الرسالة').setEmoji('💬').setStyle(ButtonStyle.Primary),
  );

  return { embeds: [embed], components: [row, navRow()] };
}

// ─── MEMBER COUNT ─────────────────────────────────────────────────────────
function buildMemberCountView(settings, guildConfig) {
  const mc = guildConfig?.memberCountChannel ?? {};
  const embed = new EmbedBuilder()
    .setColor(COLORS.primary)
    .setTitle(`👥・عداد الأعضاء (Member Count)`)
    .setDescription(`إعداد قناة عرض عدد الأعضاء.\n${DIVIDER}`)
    .addFields(
      { name: '⚙️ الحالة', value: onOff(mc.enabled), inline: true },
      { name: '🔊 القناة الصوتية', value: ch(mc.channelId), inline: true },
      { name: '📝 التنسيق', value: mc.format || '_(افتراضي: Members: {count})_', inline: false },
    )
    .setFooter({ text: `${settings.footer} • {count} يُستبدل بعدد الأعضاء` }).setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(SCD_MC_TOGGLE)
      .setLabel(mc.enabled ? 'تعطيل عداد الأعضاء' : 'تفعيل عداد الأعضاء')
      .setEmoji(mc.enabled ? ICONS.error : ICONS.success)
      .setStyle(mc.enabled ? ButtonStyle.Danger : ButtonStyle.Success),
    new ButtonBuilder().setCustomId(SCD_MC_CHANNEL).setLabel('تعيين القناة').setEmoji('🔊').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId(SCD_MC_FORMAT).setLabel('تعيين التنسيق').setEmoji('📝').setStyle(ButtonStyle.Primary),
  );

  return { embeds: [embed], components: [row, navRow()] };
}

// ─── STARBOARD ────────────────────────────────────────────────────────────
function buildStarboardView(settings, guildConfig) {
  const sb = guildConfig?.starboard ?? {};
  const embed = new EmbedBuilder()
    .setColor(COLORS.primary)
    .setTitle(`⭐・لوحة النجوم (Starboard)`)
    .setDescription(`إعداد نظام تمييز الرسائل بنجوم.\n${DIVIDER}`)
    .addFields(
      { name: '⚙️ الحالة', value: onOff(sb.enabled), inline: true },
      { name: '📢 القناة', value: ch(sb.channelId), inline: true },
      { name: '⭐ عدد النجوم', value: sb.threshold ? String(sb.threshold) : '3', inline: true },
      { name: '🎭 الإيموجي', value: sb.emoji || '⭐', inline: true },
    )
    .setFooter({ text: settings.footer }).setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(SCD_SB_TOGGLE)
      .setLabel(sb.enabled ? 'تعطيل Starboard' : 'تفعيل Starboard')
      .setEmoji(sb.enabled ? ICONS.error : ICONS.success)
      .setStyle(sb.enabled ? ButtonStyle.Danger : ButtonStyle.Success),
    new ButtonBuilder().setCustomId(SCD_SB_CONFIG).setLabel('إعداد القناة والنجوم').setEmoji('⚙️').setStyle(ButtonStyle.Primary),
  );

  return { embeds: [embed], components: [row, navRow()] };
}

// ─── COUNTING ─────────────────────────────────────────────────────────────
function buildCountingView(settings, guildConfig) {
  const cnt = guildConfig?.counting ?? {};
  const embed = new EmbedBuilder()
    .setColor(COLORS.primary)
    .setTitle(`🔢・لعبة العد (Counting)`)
    .setDescription(`إعداد لعبة العد التصاعدي في قناة مخصصة.\n${DIVIDER}`)
    .addFields(
      { name: '⚙️ الحالة', value: onOff(cnt.enabled), inline: true },
      { name: '📢 القناة', value: ch(cnt.channelId), inline: true },
      { name: '🔢 العدد الحالي', value: cnt.currentCount !== undefined ? String(cnt.currentCount) : '0', inline: true },
    )
    .setFooter({ text: settings.footer }).setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(SCD_CNT_ENABLE).setLabel('تفعيل / تغيير القناة').setEmoji('🔢').setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId(SCD_CNT_DISABLE).setLabel('تعطيل').setEmoji(ICONS.error).setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId(SCD_CNT_RESET).setLabel('إعادة العد').setEmoji('🔄').setStyle(ButtonStyle.Secondary),
  );

  return { embeds: [embed], components: [row, navRow()] };
}

// ─── Modal builders ────────────────────────────────────────────────────────
function modalChannelId(customId, title, label) {
  const modal = new ModalBuilder().setCustomId(customId).setTitle(title);
  const input = new TextInputBuilder().setCustomId('channel_id').setLabel(label)
    .setStyle(TextInputStyle.Short).setPlaceholder('مثال: 123456789012345678').setRequired(true);
  return modal.addComponents(new ActionRowBuilder().addComponents(input));
}

// ─── Button handlers (called from components/buttons.js) ──────────────────
async function handleCommunityButton(interaction) {
  const id = interaction.customId;
  const guildConfig = await getGuildConfig(interaction.guildId);
  const settings = resolved(guildConfig);

  if (!isGuildManager(interaction.member, guildConfig)) {
    return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
  }

  // ── Suggestions ────────────────────────────────────────────────────────
  if (id === SCD_SUGGEST_TOGGLE) {
    guildConfig.suggestions.enabled = !guildConfig.suggestions.enabled;
    await guildConfig.save(); invalidateGuildConfig(interaction.guildId);
    const view = buildSuggestionsView(resolved(guildConfig), guildConfig);
    return interaction.update(view);
  }
  if (id === SCD_SUGGEST_CHANNEL) {
    return interaction.showModal(modalChannelId(SCD_MODAL_SUGGEST_CH, '📢 قناة الاقتراحات', 'معرّف القناة (Channel ID)'));
  }

  // ── Booster ────────────────────────────────────────────────────────────
  if (id === SCD_BOOST_TOGGLE) {
    if (!guildConfig.boosterAnnounce) guildConfig.boosterAnnounce = {};
    guildConfig.boosterAnnounce.enabled = !guildConfig.boosterAnnounce.enabled;
    guildConfig.markModified('boosterAnnounce');
    await guildConfig.save(); invalidateGuildConfig(interaction.guildId);
    return interaction.update(buildBoosterView(resolved(guildConfig), guildConfig));
  }
  if (id === SCD_BOOST_CHANNEL) {
    return interaction.showModal(modalChannelId(SCD_MODAL_BOOST_CH, '📢 قناة إعلانات Boost', 'معرّف القناة (Channel ID)'));
  }
  if (id === SCD_BOOST_MESSAGE) {
    const modal = new ModalBuilder().setCustomId(SCD_MODAL_BOOST_MSG).setTitle('💬 رسالة إعلان Boost');
    const inp = new TextInputBuilder().setCustomId('message')
      .setLabel('نص الرسالة ({user} و {server} متاحان)').setStyle(TextInputStyle.Paragraph)
      .setPlaceholder('{user} قام بتعزيز {server}! 🚀').setMaxLength(500).setRequired(true);
    return interaction.showModal(modal.addComponents(new ActionRowBuilder().addComponents(inp)));
  }

  // ── Member Count ───────────────────────────────────────────────────────
  if (id === SCD_MC_TOGGLE) {
    if (!guildConfig.memberCountChannel) guildConfig.memberCountChannel = {};
    guildConfig.memberCountChannel.enabled = !guildConfig.memberCountChannel.enabled;
    guildConfig.markModified('memberCountChannel');
    await guildConfig.save(); invalidateGuildConfig(interaction.guildId);
    return interaction.update(buildMemberCountView(resolved(guildConfig), guildConfig));
  }
  if (id === SCD_MC_CHANNEL) {
    return interaction.showModal(modalChannelId(SCD_MODAL_MC_CH, '🔊 قناة عداد الأعضاء (صوتية)', 'معرّف القناة الصوتية (Channel ID)'));
  }
  if (id === SCD_MC_FORMAT) {
    const modal = new ModalBuilder().setCustomId(SCD_MODAL_MC_FMT).setTitle('📝 تنسيق عداد الأعضاء');
    const inp = new TextInputBuilder().setCustomId('format')
      .setLabel('التنسيق ({count} يُستبدل بعدد الأعضاء)').setStyle(TextInputStyle.Short)
      .setPlaceholder('👥 Members: {count}').setMaxLength(90).setRequired(true);
    return interaction.showModal(modal.addComponents(new ActionRowBuilder().addComponents(inp)));
  }

  // ── Starboard ──────────────────────────────────────────────────────────
  if (id === SCD_SB_TOGGLE) {
    if (!guildConfig.starboard) guildConfig.starboard = {};
    guildConfig.starboard.enabled = !guildConfig.starboard.enabled;
    guildConfig.markModified('starboard');
    await guildConfig.save(); invalidateGuildConfig(interaction.guildId);
    return interaction.update(buildStarboardView(resolved(guildConfig), guildConfig));
  }
  if (id === SCD_SB_CONFIG) {
    const modal = new ModalBuilder().setCustomId(SCD_MODAL_SB_CONFIG).setTitle('⭐ إعداد Starboard');
    const chInput = new TextInputBuilder().setCustomId('channel_id').setLabel('معرّف القناة (Channel ID)').setStyle(TextInputStyle.Short).setPlaceholder('123456789012345678').setRequired(true);
    const tInput  = new TextInputBuilder().setCustomId('threshold').setLabel('عدد النجوم المطلوب').setStyle(TextInputStyle.Short).setPlaceholder('3').setRequired(false);
    const eInput  = new TextInputBuilder().setCustomId('emoji').setLabel('الإيموجي (اختياري، افتراضي ⭐)').setStyle(TextInputStyle.Short).setPlaceholder('⭐').setRequired(false);
    return interaction.showModal(modal.addComponents(
      new ActionRowBuilder().addComponents(chInput),
      new ActionRowBuilder().addComponents(tInput),
      new ActionRowBuilder().addComponents(eInput),
    ));
  }

  // ── Counting ───────────────────────────────────────────────────────────
  if (id === SCD_CNT_ENABLE) {
    return interaction.showModal(modalChannelId(SCD_MODAL_CNT_CH, '🔢 قناة لعبة العد', 'معرّف القناة (Channel ID)'));
  }
  if (id === SCD_CNT_DISABLE) {
    if (!guildConfig.counting) guildConfig.counting = {};
    guildConfig.counting.enabled = false;
    guildConfig.markModified('counting');
    await guildConfig.save(); invalidateGuildConfig(interaction.guildId);
    return interaction.update(buildCountingView(resolved(guildConfig), guildConfig));
  }
  if (id === SCD_CNT_RESET) {
    if (!guildConfig.counting) guildConfig.counting = {};
    guildConfig.counting.currentCount = 0;
    guildConfig.markModified('counting');
    await guildConfig.save(); invalidateGuildConfig(interaction.guildId);
    return interaction.update(buildCountingView(resolved(guildConfig), guildConfig));
  }
}

// ─── Modal handlers (called from components/modals.js) ────────────────────
async function handleCommunityModal(interaction) {
  const id = interaction.customId;
  const guildConfig = await getGuildConfig(interaction.guildId);
  const settings = resolved(guildConfig);

  const resolveChannel = async (channelId) => {
    try { return await interaction.guild.channels.fetch(channelId); } catch { return null; }
  };

  // Suggestions channel
  if (id === SCD_MODAL_SUGGEST_CH) {
    const channelId = interaction.fields.getTextInputValue('channel_id').trim();
    const ch = await resolveChannel(channelId);
    if (!ch) return interaction.reply({ embeds: [errorEmbed(settings, 'لم يتم العثور على القناة. تأكد من الـ ID.')], ephemeral: true });
    guildConfig.suggestions.channelId = channelId;
    guildConfig.suggestions.enabled = true;
    await guildConfig.save(); invalidateGuildConfig(interaction.guildId);
    await interaction.reply({ embeds: [successEmbed(settings, `✅ قناة الاقتراحات: <#${channelId}>`)], ephemeral: true });
    return;
  }

  // Booster channel
  if (id === SCD_MODAL_BOOST_CH) {
    const channelId = interaction.fields.getTextInputValue('channel_id').trim();
    const ch = await resolveChannel(channelId);
    if (!ch) return interaction.reply({ embeds: [errorEmbed(settings, 'لم يتم العثور على القناة.')], ephemeral: true });
    if (!guildConfig.boosterAnnounce) guildConfig.boosterAnnounce = {};
    guildConfig.boosterAnnounce.channelId = channelId;
    guildConfig.markModified('boosterAnnounce');
    await guildConfig.save(); invalidateGuildConfig(interaction.guildId);
    await interaction.reply({ embeds: [successEmbed(settings, `✅ قناة إعلانات Boost: <#${channelId}>`)], ephemeral: true });
    return;
  }

  // Booster message
  if (id === SCD_MODAL_BOOST_MSG) {
    const message = interaction.fields.getTextInputValue('message').trim();
    if (!guildConfig.boosterAnnounce) guildConfig.boosterAnnounce = {};
    guildConfig.boosterAnnounce.message = message;
    guildConfig.markModified('boosterAnnounce');
    await guildConfig.save(); invalidateGuildConfig(interaction.guildId);
    await interaction.reply({ embeds: [successEmbed(settings, '✅ تم تحديث رسالة Boost.')], ephemeral: true });
    return;
  }

  // Member count channel
  if (id === SCD_MODAL_MC_CH) {
    const channelId = interaction.fields.getTextInputValue('channel_id').trim();
    const ch = await resolveChannel(channelId);
    if (!ch) return interaction.reply({ embeds: [errorEmbed(settings, 'لم يتم العثور على القناة.')], ephemeral: true });
    if (!guildConfig.memberCountChannel) guildConfig.memberCountChannel = {};
    guildConfig.memberCountChannel.channelId = channelId;
    guildConfig.memberCountChannel.enabled = true;
    guildConfig.markModified('memberCountChannel');
    await guildConfig.save(); invalidateGuildConfig(interaction.guildId);
    await interaction.reply({ embeds: [successEmbed(settings, `✅ قناة عداد الأعضاء: <#${channelId}>`)], ephemeral: true });
    return;
  }

  // Member count format
  if (id === SCD_MODAL_MC_FMT) {
    const format = interaction.fields.getTextInputValue('format').trim();
    if (!guildConfig.memberCountChannel) guildConfig.memberCountChannel = {};
    guildConfig.memberCountChannel.format = format;
    guildConfig.markModified('memberCountChannel');
    await guildConfig.save(); invalidateGuildConfig(interaction.guildId);
    await interaction.reply({ embeds: [successEmbed(settings, `✅ تنسيق العداد: \`${format}\``)], ephemeral: true });
    return;
  }

  // Starboard config
  if (id === SCD_MODAL_SB_CONFIG) {
    const channelId = interaction.fields.getTextInputValue('channel_id').trim();
    const thresholdStr = interaction.fields.getTextInputValue('threshold').trim();
    const emoji = interaction.fields.getTextInputValue('emoji').trim();
    const ch = await resolveChannel(channelId);
    if (!ch) return interaction.reply({ embeds: [errorEmbed(settings, 'لم يتم العثور على القناة.')], ephemeral: true });
    if (!guildConfig.starboard) guildConfig.starboard = {};
    guildConfig.starboard.channelId = channelId;
    guildConfig.starboard.enabled = true;
    if (thresholdStr) {
      const t = parseInt(thresholdStr, 10);
      if (!isNaN(t) && t >= 1) guildConfig.starboard.threshold = t;
    }
    if (emoji) guildConfig.starboard.emoji = emoji;
    guildConfig.markModified('starboard');
    await guildConfig.save(); invalidateGuildConfig(interaction.guildId);
    await interaction.reply({ embeds: [successEmbed(settings, `✅ تم إعداد Starboard في <#${channelId}>`)], ephemeral: true });
    return;
  }

  // Counting channel
  if (id === SCD_MODAL_CNT_CH) {
    const channelId = interaction.fields.getTextInputValue('channel_id').trim();
    const ch = await resolveChannel(channelId);
    if (!ch) return interaction.reply({ embeds: [errorEmbed(settings, 'لم يتم العثور على القناة.')], ephemeral: true });
    if (!guildConfig.counting) guildConfig.counting = {};
    guildConfig.counting.channelId = channelId;
    guildConfig.counting.enabled = true;
    guildConfig.counting.currentCount = 0;
    guildConfig.markModified('counting');
    await guildConfig.save(); invalidateGuildConfig(interaction.guildId);
    await interaction.reply({ embeds: [successEmbed(settings, `✅ تم تفعيل لعبة العد في <#${channelId}>`)], ephemeral: true });
    return;
  }
}

module.exports = {
  buildSuggestionsView, buildBoosterView, buildMemberCountView,
  buildStarboardView, buildCountingView,
  handleCommunityButton, handleCommunityModal,
  // CustomId sets exported so buttons.js / modals.js can register them
  SCD_BUTTON_IDS: [
    SCD_SUGGEST_TOGGLE, SCD_SUGGEST_CHANNEL,
    SCD_BOOST_TOGGLE, SCD_BOOST_CHANNEL, SCD_BOOST_MESSAGE,
    SCD_MC_TOGGLE, SCD_MC_CHANNEL, SCD_MC_FORMAT,
    SCD_SB_TOGGLE, SCD_SB_CONFIG,
    SCD_CNT_ENABLE, SCD_CNT_DISABLE, SCD_CNT_RESET,
  ],
  SCD_MODAL_IDS: [
    SCD_MODAL_SUGGEST_CH, SCD_MODAL_BOOST_CH, SCD_MODAL_BOOST_MSG,
    SCD_MODAL_MC_CH, SCD_MODAL_MC_FMT, SCD_MODAL_SB_CONFIG, SCD_MODAL_CNT_CH,
  ],
};
