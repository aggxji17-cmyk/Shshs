/**
 * Task 41 — Protection Settings UI (إعدادات الحماية).
 *
 * Renders the interactive protection configuration section that opens when
 * the admin picks "الحماية" from the /settings dashboard. Controls:
 *
 *   Anti-Raid:
 *     • تشغيل/إيقاف Anti-Raid          (spt_antiraid_toggle)
 *     • إعداد حد الانضمامات             (spt_antiraid_threshold) → Modal
 *     • إجراء الرد على الغارة            (spt_antiraid_action)   → Modal
 *     • الحسابات الجديدة               (spt_antiraid_newaccounts) → Modal
 *
 *   Anti-Nuke:
 *     • تشغيل/إيقاف Anti-Nuke           (spt_antinuke_toggle)
 *     • عقوبة المهاجم                   (spt_antinuke_punishment) → Modal
 *     • القائمة الموثوقة (Whitelist)     (spt_antinuke_whitelist) → Modal
 *     • حدود الأحداث                   (spt_antinuke_thresholds) → Modal
 *
 *   Anti-Spam (AutoMod):
 *     • تشغيل/إيقاف AutoMod             (spt_automod_toggle)
 *     • إعداد انواع الحماية التلقائية   (spt_automod_checks)    → Sub-page
 *
 *   AutoMod checks sub-page (spt_automod_check:<key>):
 *     • Toggle each individual check     (spt_automod_check_toggle:<key>)
 *     • Set punishment for check         (spt_automod_check_punishment:<key>) → Modal
 *
 *   Navigation: settings_back / settings_home / settings_close
 *
 * All modals:
 *   spt_modal_antiraid_threshold   — join threshold + window seconds
 *   spt_modal_antiraid_action      — action choice
 *   spt_modal_antiraid_newaccounts — min age + action
 *   spt_modal_antinuke_punishment  — punishment type
 *   spt_modal_antinuke_whitelist   — whitelist user ID
 *   spt_modal_antinuke_thresholds  — per-event thresholds
 *   spt_modal_automod_punishment   — punishment + optional timeout for a check
 */

const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require('discord.js');
const { COLORS, ICONS } = require('./designSystem');
const { CHECKS } = require('../services/automodChecks');
const { AUTOMOD_PUNISHMENT_LABELS } = require('./automodConstants');

// ─────────────────────────────────────────────────────────────────────────────
// CustomId constants
// ─────────────────────────────────────────────────────────────────────────────
const SPT_ANTIRAID_TOGGLE_ID       = 'spt_antiraid_toggle';
const SPT_ANTIRAID_THRESHOLD_ID    = 'spt_antiraid_threshold';
const SPT_ANTIRAID_ACTION_ID       = 'spt_antiraid_action';
const SPT_ANTIRAID_NEWACCOUNTS_ID  = 'spt_antiraid_newaccounts';

const SPT_ANTINUKE_TOGGLE_ID       = 'spt_antinuke_toggle';
const SPT_ANTINUKE_PUNISHMENT_ID   = 'spt_antinuke_punishment';
const SPT_ANTINUKE_WHITELIST_ID    = 'spt_antinuke_whitelist';
const SPT_ANTINUKE_THRESHOLDS_ID   = 'spt_antinuke_thresholds';

const SPT_AUTOMOD_TOGGLE_ID        = 'spt_automod_toggle';
const SPT_AUTOMOD_CHECKS_ID        = 'spt_automod_checks';

// Dynamic prefix IDs (resolved via startsWith in buttons.js router)
const SPT_AUTOMOD_CHECK_TOGGLE_PREFIX     = 'spt_automod_check_toggle';
const SPT_AUTOMOD_CHECK_PUNISHMENT_PREFIX = 'spt_automod_check_punishment';

// ─────────────────────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────────────────────

function statusEmoji(enabled) {
  return enabled ? '🟢' : '🔴';
}

function statusLabel(enabled) {
  return enabled ? 'مُفعَّل' : 'معطَّل';
}

function _navRow() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('settings_back')
      .setLabel('رجوع / Back')
      .setEmoji(ICONS.back)
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('settings_home')
      .setLabel('الرئيسية / Home')
      .setEmoji(ICONS.home)
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('settings_close')
      .setLabel('إغلاق / Close')
      .setEmoji(ICONS.close)
      .setStyle(ButtonStyle.Danger),
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Main Protection View
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Builds the main Protection dashboard view.
 * Shows Anti-Raid, Anti-Nuke, and AutoMod status with controls.
 *
 * @param {object} settings  — resolved guild settings (footer, embedColor, etc.)
 * @param {object} guildConfig — raw GuildConfig document from MongoDB
 * @returns {{ embeds: EmbedBuilder[], components: ActionRowBuilder[] }}
 */
function buildProtectionView(settings, guildConfig) {
  const antiRaid  = guildConfig.antiRaid  || {};
  const antiNuke  = guildConfig.antinuke  || {};
  const automod   = guildConfig.automod   || {};

  const raidEnabled  = !!antiRaid.enabled;
  const nukeEnabled  = !!antiNuke.enabled;
  const automodEnabled = !!automod.enabled;

  // ── Embed ──────────────────────────────────────────────────────────────────
  const embed = new EmbedBuilder()
    .setColor(raidEnabled || nukeEnabled || automodEnabled ? COLORS.success : COLORS.neutral)
    .setTitle(`${ICONS.security}・إعدادات الحماية (Protection)`)
    .setDescription(
      'أدِر أنظمة الحماية المتعددة للسيرفر من هنا.\n' +
      'استخدم الأزرار لتشغيل/إيقاف كل نظام أو تعديل إعداداته.'
    )
    .addFields(
      {
        name: `🛡️ Anti-Raid`,
        value:
          `الحالة: ${statusEmoji(raidEnabled)} ${statusLabel(raidEnabled)}\n` +
          `حد الانضمامات: **${antiRaid.joinThreshold ?? 8}** خلال **${Math.round((antiRaid.windowMs ?? 10000) / 1000)}** ثانية\n` +
          `الإجراء: **${_raidActionLabel(antiRaid.action ?? 'lockdown')}**\n` +
          `الحسابات الجديدة: حد أدنى **${antiRaid.newAccountAgeDays ?? 7}** يوم — ${_newAccActionLabel(antiRaid.newAccountAction ?? 'flag')}`,
        inline: false,
      },
      {
        name: `💣 Anti-Nuke`,
        value:
          `الحالة: ${statusEmoji(nukeEnabled)} ${statusLabel(nukeEnabled)}\n` +
          `العقوبة: **${_nukeActionLabel(antiNuke.punishment ?? 'stripRoles')}**\n` +
          `المستثنون: **${(antiNuke.whitelistedUserIds ?? []).length}** مستخدم\n` +
          `حد الأحداث: حذف قنوات **${antiNuke.thresholds?.channelDelete ?? 3}** | حذف رتب **${antiNuke.thresholds?.roleDelete ?? 3}** | حظر **${antiNuke.thresholds?.memberBan ?? 3}** | Webhooks **${antiNuke.thresholds?.webhookCreate ?? 3}**`,
        inline: false,
      },
      {
        name: `🤖 AutoMod (الحماية التلقائية)`,
        value:
          `الحالة: ${statusEmoji(automodEnabled)} ${statusLabel(automodEnabled)}\n` +
          `الفحوصات المُفعَّلة: **${_countEnabledChecks(automod)}** / ${CHECKS.length}`,
        inline: false,
      }
    )
    .setFooter({ text: settings.footer })
    .setTimestamp();

  // ── Row 1: Anti-Raid controls ──────────────────────────────────────────────
  const antiRaidRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(SPT_ANTIRAID_TOGGLE_ID)
      .setLabel(raidEnabled ? 'إيقاف Anti-Raid' : 'تشغيل Anti-Raid')
      .setEmoji(raidEnabled ? '🔴' : '🟢')
      .setStyle(raidEnabled ? ButtonStyle.Danger : ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(SPT_ANTIRAID_THRESHOLD_ID)
      .setLabel('حد الانضمامات')
      .setEmoji('⚙️')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId(SPT_ANTIRAID_ACTION_ID)
      .setLabel('إجراء الرد')
      .setEmoji('🔨')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId(SPT_ANTIRAID_NEWACCOUNTS_ID)
      .setLabel('الحسابات الجديدة')
      .setEmoji('🔍')
      .setStyle(ButtonStyle.Secondary),
  );

  // ── Row 2: Anti-Nuke controls ──────────────────────────────────────────────
  const antiNukeRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(SPT_ANTINUKE_TOGGLE_ID)
      .setLabel(nukeEnabled ? 'إيقاف Anti-Nuke' : 'تشغيل Anti-Nuke')
      .setEmoji(nukeEnabled ? '🔴' : '🟢')
      .setStyle(nukeEnabled ? ButtonStyle.Danger : ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(SPT_ANTINUKE_PUNISHMENT_ID)
      .setLabel('العقوبة')
      .setEmoji('⚖️')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId(SPT_ANTINUKE_WHITELIST_ID)
      .setLabel('القائمة الموثوقة')
      .setEmoji('✅')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId(SPT_ANTINUKE_THRESHOLDS_ID)
      .setLabel('حدود الأحداث')
      .setEmoji('📊')
      .setStyle(ButtonStyle.Secondary),
  );

  // ── Row 3: AutoMod controls ────────────────────────────────────────────────
  const automodRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(SPT_AUTOMOD_TOGGLE_ID)
      .setLabel(automodEnabled ? 'إيقاف AutoMod' : 'تشغيل AutoMod')
      .setEmoji(automodEnabled ? '🔴' : '🟢')
      .setStyle(automodEnabled ? ButtonStyle.Danger : ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(SPT_AUTOMOD_CHECKS_ID)
      .setLabel('إعداد الفحوصات')
      .setEmoji('🔧')
      .setStyle(ButtonStyle.Primary),
  );

  return {
    embeds:     [embed],
    components: [antiRaidRow, antiNukeRow, automodRow, _navRow()],
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// AutoMod Checks Sub-page
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Builds the AutoMod checks detail view.
 * Shows each individual check with its status and punishment.
 *
 * @param {object} settings
 * @param {object} guildConfig
 * @returns {{ embeds: EmbedBuilder[], components: ActionRowBuilder[] }}
 */
function buildAutomodChecksView(settings, guildConfig) {
  const automod = guildConfig.automod || {};
  const checks  = automod.checks || {};
  const enabled = !!automod.enabled;

  const checkRows = [];
  // Discord limits 5 action rows total; we use row 1 for embed info, last for nav.
  // Each button row: toggle + punishment (2 buttons per check, grouped in rows of 2 checks = 4 buttons/row)
  // With 7 checks we need 4 rows: 3 of 2 checks + 1 of 1 check → we'll do one button per check in 2 rows of 4 + 1 of 3 = 2+2+2+1 buttons
  // Actually simpler: one row = all toggles (up to 5), next row = all punishment buttons (up to 5)

  const toggleRow1 = new ActionRowBuilder();
  const toggleRow2 = new ActionRowBuilder();
  const punishRow  = new ActionRowBuilder();

  CHECKS.forEach((check, i) => {
    const cfg    = checks[check.key] || {};
    const isOn   = !!cfg.enabled;
    const pLabel = AUTOMOD_PUNISHMENT_LABELS[cfg.punishment] || 'Delete';

    const toggleBtn = new ButtonBuilder()
      .setCustomId(`${SPT_AUTOMOD_CHECK_TOGGLE_PREFIX}:${check.key}`)
      .setLabel(check.label)
      .setEmoji(isOn ? '🟢' : '🔴')
      .setStyle(isOn ? ButtonStyle.Success : ButtonStyle.Secondary);

    if (i < 5) toggleRow1.addComponents(toggleBtn);
    else        toggleRow2.addComponents(toggleBtn);

    // Only add punishment buttons for the first 5 to stay within row limit
    if (i < 5) {
      punishRow.addComponents(
        new ButtonBuilder()
          .setCustomId(`${SPT_AUTOMOD_CHECK_PUNISHMENT_PREFIX}:${check.key}`)
          .setLabel(`عقوبة ${check.label}`)
          .setEmoji('⚖️')
          .setStyle(ButtonStyle.Secondary)
      );
    }
  });

  const embed = new EmbedBuilder()
    .setColor(enabled ? COLORS.success : COLORS.neutral)
    .setTitle(`🤖・إعداد فحوصات AutoMod`)
    .setDescription(
      `المفتاح الرئيسي: ${statusEmoji(enabled)} ${statusLabel(enabled)}\n\n` +
      'اضغط على اسم الفحص لتشغيله/إيقافه.\n' +
      'اضغط على "عقوبة" لتغيير العقوبة الخاصة به.'
    )
    .addFields(
      CHECKS.map((check) => {
        const cfg  = checks[check.key] || {};
        const isOn = !!cfg.enabled;
        const pKey = cfg.punishment || 'delete';
        return {
          name:   `${isOn ? '🟢' : '🔴'} ${check.label}`,
          value:  `العقوبة: **${AUTOMOD_PUNISHMENT_LABELS[pKey] || pKey}**${check.hasThreshold ? ` | الحد: **${cfg.threshold ?? '—'}**` : ''}`,
          inline: true,
        };
      })
    )
    .setFooter({ text: settings.footer })
    .setTimestamp();

  const navRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(SPT_AUTOMOD_CHECKS_ID + '_back') // goes back to main protection view
      .setLabel('رجوع للحماية')
      .setEmoji(ICONS.back)
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('settings_home')
      .setLabel('الرئيسية / Home')
      .setEmoji(ICONS.home)
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('settings_close')
      .setLabel('إغلاق / Close')
      .setEmoji(ICONS.close)
      .setStyle(ButtonStyle.Danger),
  );

  const components = [toggleRow1];
  if (toggleRow2.components.length > 0) components.push(toggleRow2);
  // punishRow may have too many buttons if all 7 checks; trim to 5
  if (punishRow.components.length > 0) {
    punishRow.components = punishRow.components.slice(0, 5);
    components.push(punishRow);
  }
  components.push(navRow);

  return { embeds: [embed], components };
}

// ─────────────────────────────────────────────────────────────────────────────
// Label helpers
// ─────────────────────────────────────────────────────────────────────────────

function _raidActionLabel(action) {
  return { lockdown: 'قفل القنوات', kick: 'طرد الجدد', ban: 'حظر الجدد' }[action] ?? action;
}

function _newAccActionLabel(action) {
  return { none: 'لا شيء', flag: 'تسجيل في السجل', kick: 'طرد تلقائي' }[action] ?? action;
}

function _nukeActionLabel(punishment) {
  return { stripRoles: 'سحب الرتب', kick: 'طرد', ban: 'حظر' }[punishment] ?? punishment;
}

function _countEnabledChecks(automod) {
  const checks = automod.checks || {};
  return CHECKS.filter((c) => !!checks[c.key]?.enabled).length;
}

// ─────────────────────────────────────────────────────────────────────────────
// Exports
// ─────────────────────────────────────────────────────────────────────────────

module.exports = {
  // CustomId constants (used by buttons.js)
  SPT_ANTIRAID_TOGGLE_ID,
  SPT_ANTIRAID_THRESHOLD_ID,
  SPT_ANTIRAID_ACTION_ID,
  SPT_ANTIRAID_NEWACCOUNTS_ID,
  SPT_ANTINUKE_TOGGLE_ID,
  SPT_ANTINUKE_PUNISHMENT_ID,
  SPT_ANTINUKE_WHITELIST_ID,
  SPT_ANTINUKE_THRESHOLDS_ID,
  SPT_AUTOMOD_TOGGLE_ID,
  SPT_AUTOMOD_CHECKS_ID,
  SPT_AUTOMOD_CHECK_TOGGLE_PREFIX,
  SPT_AUTOMOD_CHECK_PUNISHMENT_PREFIX,

  // View builders
  buildProtectionView,
  buildAutomodChecksView,
};
