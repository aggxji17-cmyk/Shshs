/**
 * Task 39 — Logging Settings UI (إعدادات السجلات).
 *
 * Renders the interactive logging configuration section that opens when
 * the admin picks "السجلات" from the /settings dashboard. Controls:
 *
 *   • قناة السجلات     — the channel all event logs are sent to
 *   • تشغيل / إيقاف   — master enable/disable toggle
 *   • أنواع الأحداث   — per-event type toggles (messageDelete, memberJoin, …)
 *
 * All customIds exposed here:
 *   slg_channel          → open modal to set channelId
 *   slg_toggle           → toggle logging.enabled
 *   slg_event:<eventKey> → toggle a single event type on/off
 *   (navigation: settings_back / settings_home / settings_close from settingsDashboard.js)
 *
 * Shared constraint: every button opens back/home/close so the admin is
 * never stuck. The view is always rebuilt after a save so the admin sees
 * the current state immediately.
 */

const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require('discord.js');
const { COLORS, ICONS } = require('./designSystem');

// ─────────────────────────────────────────────────────────────────────────────
// Event registry — human-readable Arabic labels for every event type stored
// in GuildConfig.logging.events. Order here controls display order in the UI.
// ─────────────────────────────────────────────────────────────────────────────
const LOG_EVENTS = [
  { key: 'messageDelete',  labelAr: 'حذف الرسائل',        icon: '🗑️' },
  { key: 'messageEdit',    labelAr: 'تعديل الرسائل',       icon: '✏️' },
  { key: 'memberJoin',     labelAr: 'انضمام الأعضاء',      icon: '➕' },
  { key: 'memberLeave',    labelAr: 'مغادرة الأعضاء',      icon: '➖' },
  { key: 'memberBan',      labelAr: 'حظر الأعضاء',         icon: '🔨' },
  { key: 'memberUnban',    labelAr: 'رفع الحظر',           icon: '🔓' },
  { key: 'channelUpdates', labelAr: 'تعديلات القنوات',     icon: '📁' },
  { key: 'roleUpdates',    labelAr: 'تعديلات الرتب',       icon: '🎖️' },
];

// ─────────────────────────────────────────────────────────────────────────────
// CustomId constants
// ─────────────────────────────────────────────────────────────────────────────
const SLG_CHANNEL_BUTTON_ID   = 'slg_channel';
const SLG_TOGGLE_BUTTON_ID    = 'slg_toggle';
const SLG_EVENT_PREFIX        = 'slg_event:';

// ─────────────────────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────────────────────

/** Returns emoji indicator for enabled / disabled state. */
function statusEmoji(enabled) {
  return enabled ? '🟢' : '🔴';
}

/**
 * Builds the full Logging section view.
 *
 * @param {object} settings  - resolved guild settings (from resolveGuildSettings)
 * @param {object} guildConfig - raw Mongoose document (to read logging sub-doc)
 * @returns {{ embeds: EmbedBuilder[], components: ActionRowBuilder[] }}
 */
function buildLoggingView(settings, guildConfig) {
  const logging    = guildConfig.logging || {};
  const enabled    = !!logging.enabled;
  const channelId  = logging.channelId || null;
  const events     = logging.events   || {};

  // ── Embed ──────────────────────────────────────────────────────────────────
  const embed = new EmbedBuilder()
    .setColor(enabled ? COLORS.success : COLORS.neutral)
    .setTitle(`${ICONS.logging}・إعدادات السجلات (Logging)`)
    .setDescription(
      `**حالة النظام:** ${statusEmoji(enabled)} ${enabled ? 'مُفعَّل' : 'معطَّل'}\n` +
      `**قناة السجلات:** ${channelId ? `<#${channelId}>` : '❌ لم يتم تحديدها'}\n\n` +
      'استخدم الأزرار أدناه لضبط قناة السجلات وتشغيل/إيقاف النظام واختيار أنواع الأحداث التي تريد تسجيلها.'
    )
    .addFields(
      LOG_EVENTS.map((ev) => {
        const isOn = events[ev.key] !== false; // default true per schema
        return {
          name: `${ev.icon} ${ev.labelAr}`,
          value: `${statusEmoji(isOn)} ${isOn ? 'مُفعَّل' : 'معطَّل'}`,
          inline: true,
        };
      })
    )
    .setFooter({ text: settings.footer })
    .setTimestamp();

  // ── Components ─────────────────────────────────────────────────────────────
  // Row 1: main controls (channel + master toggle)
  const mainRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(SLG_CHANNEL_BUTTON_ID)
      .setLabel('تحديد قناة السجلات')
      .setEmoji('📌')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId(SLG_TOGGLE_BUTTON_ID)
      .setLabel(enabled ? 'إيقاف تشغيل السجلات' : 'تشغيل السجلات')
      .setEmoji(enabled ? '🔴' : '🟢')
      .setStyle(enabled ? ButtonStyle.Danger : ButtonStyle.Success),
  );

  // Rows 2-3: event toggles (up to 5 per row, Discord limit)
  const eventRows = [];
  for (let i = 0; i < LOG_EVENTS.length; i += 5) {
    const chunk = LOG_EVENTS.slice(i, i + 5);
    const row   = new ActionRowBuilder().addComponents(
      chunk.map((ev) => {
        const isOn = events[ev.key] !== false;
        return new ButtonBuilder()
          .setCustomId(`${SLG_EVENT_PREFIX}${ev.key}`)
          .setLabel(ev.labelAr)
          .setEmoji(ev.icon)
          .setStyle(isOn ? ButtonStyle.Success : ButtonStyle.Secondary);
      })
    );
    eventRows.push(row);
  }

  // Row last: navigation (Back / Home / Close)
  const { navigationRow } = _navRow();

  return {
    embeds:     [embed],
    components: [mainRow, ...eventRows, navigationRow],
  };
}

/** Returns the shared navigation row (back / home / close). */
function _navRow() {
  const navigationRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('settings_back')
      .setLabel('رجوع / Back')
      .setEmoji(ICONS.back)
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('settings_home')
      .setLabel('الرئيسية / Home')
      .setEmoji(ICONS.home)
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('settings_close')
      .setLabel('إغلاق / Close')
      .setEmoji(ICONS.close)
      .setStyle(ButtonStyle.Danger),
  );
  return { navigationRow };
}

module.exports = {
  LOG_EVENTS,
  SLG_CHANNEL_BUTTON_ID,
  SLG_TOGGLE_BUTTON_ID,
  SLG_EVENT_PREFIX,
  buildLoggingView,
};
