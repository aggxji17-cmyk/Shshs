/**
 * Task 50 — معالج التفاعلات غير المعروفة
 * يتعامل مع الحالات التالية:
 * - customId غير معروف
 * - رسائل قديمة من قبل التحديث
 * - أزرار منتهية الصلاحية
 * - مكونات محذوفة من الكود
 */

const { EmbedBuilder } = require('discord.js');
const logger = require('./logger');
const { getGuildConfig, resolved } = require('./resolveGuildSettings');
const { COLORS, ICONS } = require('./designSystem');
const { config } = require('../config/config');

/**
 * معالج آمن للتفاعلات غير المعروفة
 * - لا يتجاهل التفاعل بصمت
 * - يرسل رد آمن للمستخدم
 * - يسجل تحذير مع السياق
 * - لا يسبب توقف التطبيق
 * - يميز بين الأخطاء المختلفة
 */
async function handleUnknownInteraction(interaction) {
  const customId = interaction.customId || 'unknown';
  const interactionType = getInteractionType(interaction);
  const guildId = interaction.guildId || 'DM';
  const userId = interaction.user?.id || 'unknown';

  // تسجيل التحذير مع السياق الكامل
  logger.warn(
    `Unknown interaction detected: ` +
    `type="${interactionType}", ` +
    `customId="${customId}", ` +
    `guild="${guildId}", ` +
    `user="${userId}", ` +
    `messageId="${interaction.message?.id || 'none'}"`
  );

  // في الحالات النادرة جداً، قد يحدث خطأ في الوصول لخصائص التفاعل
  if (!interaction.isButton() && 
      !interaction.isStringSelectMenu() && 
      !interaction.isModalSubmit()) {
    return; // تفاعل غير معروف من نوع مختلف تماماً
  }

  try {
    // محاولة الرد على المستخدم برسالة آمنة
    await sendUnknownInteractionResponse(interaction);
  } catch (err) {
    // قد يحدث خطأ إذا:
    // - انتهت صلاحية التفاعل (3+ ثوانٍ)
    // - حُذفت الرسالة الأصلية
    // - انقطع الاتصال
    logger.error(
      `Failed to respond to unknown interaction: ${err.message} ` +
      `(customId="${customId}", type="${interactionType}")`
    );
  }
}

/**
 * تحديد نوع التفاعل
 */
function getInteractionType(interaction) {
  if (interaction.isButton()) return 'Button';
  if (interaction.isStringSelectMenu()) return 'SelectMenu';
  if (interaction.isModalSubmit()) return 'Modal';
  return 'Unknown';
}

/**
 * إرسال رد آمن عند التفاعل غير المعروف
 * - الرسالة آمنة (ephemeral) حتى لا يراها أحد آخر
 * - نص واضح بالعربية والإنجليزية
 * - تصميم متسق مع النظام
 */
async function sendUnknownInteractionResponse(interaction) {
  // جاري محاولة الحصول على إعدادات النقابة للتصميم المتسق
  let guildConfig = null;
  if (interaction.guildId) {
    try {
      guildConfig = await getGuildConfig(interaction.guildId);
    } catch {
      // إذا فشل الحصول على الإعدادات، نستخدم القيم الافتراضية
      guildConfig = null;
    }
  }

  const settings = resolved(guildConfig || {});

  // بناء الرسالة
  const embed = new EmbedBuilder()
    .setColor(COLORS.warning)
    .setFooter({ text: config.embedFooter })
    .setTimestamp()
    .setDescription(
      `${ICONS.info} This button or component is no longer available. ` +
      `It may be from an older message or a previous bot version.\n\n` +
      `هذا الزر أو المكون لم يعد متاحاً. قد يكون من رسالة قديمة أو إصدار سابق من البوت.`
    )
    .addFields({
      name: '💡 Suggestion / الاقتراح',
      value: 'Try using the command again or accessing the main menu. / حاول استخدام الأمر مجدداً أو الوصول إلى القائمة الرئيسية.',
      inline: false,
    });

  // محاولة الرد
  if (interaction.replied || interaction.deferred) {
    // إذا تم الرد أو الانتظار مسبقاً، استخدم followUp
    await interaction.followUp({
      embeds: [embed],
      ephemeral: true,
    });
  } else {
    // وإلا، استخدم reply المباشر
    await interaction.reply({
      embeds: [embed],
      ephemeral: true,
    });
  }
}

/**
 * تحليل السياق - هل هذا تفاعل من رسالة قديمة؟
 * يُستخدم في السجلات للتمييز بين الحالات المختلفة
 */
function analyzeUnknownInteractionContext(interaction) {
  const analysis = {
    hasMessage: !!interaction.message,
    messageId: interaction.message?.id,
    isReply: !!interaction.message?.reference,
    customIdLength: (interaction.customId || '').length,
    customIdParts: (interaction.customId || '').split(':').length,
    hasGuild: !!interaction.guildId,
    hasUser: !!interaction.user,
  };

  return analysis;
}

/**
 * معالج محسّن للتحقق من صحة customId
 * يُستخدم قبل معالجة التفاعل
 */
function isValidCustomId(customId) {
  if (!customId) return false;
  if (typeof customId !== 'string') return false;
  if (customId.length === 0) return false;
  // customId يجب أن يكون إما:
  // - اسم مباشر (مثل "nyxo_page")
  // - مع أجزاء مفصولة بـ ":" (مثل "ticket_claim:12345")
  return /^[a-zA-Z0-9_]+(?::[a-zA-Z0-9_.\-]+)*$/.test(customId);
}

module.exports = {
  handleUnknownInteraction,
  getInteractionType,
  analyzeUnknownInteractionContext,
  isValidCustomId,
};
