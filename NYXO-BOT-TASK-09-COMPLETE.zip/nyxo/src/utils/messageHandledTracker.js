/**
 * TASK 4 (Event Isolation): messageCreate.js's pipeline used to run once,
 * top-to-bottom, on a single bot - so an early step deleting the message
 * (mentionProtection, automod) could simply `return` to stop every later
 * step from touching it. Now that the pipeline is split so each feature
 * runs on its owning bot's client (see events/message/messageCreate.js and
 * config/botEventMap.js), the moderation steps (Bot 2) and the
 * engagement/utility steps (Bot 3) fire as two independent listener calls
 * for the *same* Discord message. This small in-memory registry lets Bot
 * 2 mark a message it just deleted so Bot 3's pipeline can skip the rest
 * of its steps for that message - mirroring the existing
 * autoDeleteTracker.js pattern used between messageCreate and
 * messageDelete.
 *
 * Best-effort only: since the two pipelines now run as separate listener
 * invocations (not sequential steps in one function), there's a small
 * window where Bot 3 could already be mid-pipeline before Bot 2's mark
 * lands. Every downstream action Bot 3 takes already no-ops safely via
 * .catch(() => null) on a deleted message, so this is a safety/consistency
 * improvement, not a correctness requirement.
 *
 * TASK 27 — Performance:
 * The previous implementation scheduled a separate setTimeout() per
 * message. Under high message volume this created one timer object per
 * message, adding GC pressure. Replaced with a Map<messageId, expiresAt>
 * and a single shared sweep interval — same cleanup semantics, far fewer
 * timer allocations.
 */

const ENTRY_TTL_MS = 60 * 1000;
// Map<messageId, expiresAtMs>
const pending = new Map();

function markMessageHandled(messageId) {
  pending.set(messageId, Date.now() + ENTRY_TTL_MS);
}

function wasMessageHandled(messageId) {
  const exp = pending.get(messageId);
  if (exp === undefined) return false;
  if (Date.now() > exp) {
    pending.delete(messageId);
    return false;
  }
  return true;
}

// Single shared sweep — evicts expired entries once per minute.
// unref() so this never keeps the process alive on its own.
const sweepTimer = setInterval(() => {
  const now = Date.now();
  for (const [id, exp] of pending) {
    if (now > exp) pending.delete(id);
  }
}, ENTRY_TTL_MS);
sweepTimer.unref();

module.exports = { markMessageHandled, wasMessageHandled };
