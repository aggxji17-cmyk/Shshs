/**
 * Task 45 — Giveaways Settings UI (إعدادات السحوبات).
 *
 * Renders the giveaways info/status section that opens when the admin
 * picks "السحوبات" from the /settings dashboard.
 *
 * Giveaways are event-driven and per-message; there are no persistent
 * guild-level settings stored in GuildConfig for them. This view acts
 * as an informational hub pointing admins to the right commands, and
 * showing how many active giveaways exist in the guild.
 *
 * Navigation: settings_back / settings_home / settings_close
 */

const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require('discord.js');
const { COLORS, ICONS, DIVIDER } = require('./designSystem');
const Giveaway = require('../database/models/Giveaway');
const logger   = require('./logger');

function navRow() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('settings_back').setLabel('رجوع / Back').setEmoji(ICONS.back).setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('settings_home').setLabel('الرئيسية / Home').setEmoji(ICONS.home).setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('settings_close').setLabel('إغلاق / Close').setEmoji(ICONS.close).setStyle(ButtonStyle.Danger),
  );
}

async function buildGiveawaysView(settings, guildId) {
  let activeCount = 0;
  let endedCount  = 0;

  try {
    const now = new Date();
    activeCount = await Giveaway.countDocuments({ guildId, endsAt: { $gt: now } });
    endedCount  = await Giveaway.countDocuments({ guildId, endsAt: { $lte: now } });
  } catch (err) {
    logger.error('[giveawaysDashboard] Count error:', err);
  }

  const embed = new EmbedBuilder()
    .setColor(COLORS.primary)
    .setTitle(`${ICONS.giveaway}・إعدادات السحوبات (Giveaways)`)
    .setDescription(
      `إدارة سحوبات الجوائز وعرض الإحصائيات.\n${DIVIDER}`
    )
    .addFields(
      { name: `🟢 سحوبات نشطة`, value: String(activeCount), inline: true },
      { name: `🔴 سحوبات منتهية`, value: String(endedCount), inline: true },
    )
    .addFields({
      name: `${ICONS.info} الأوامر المتاحة`,
      value:
        '`/gstart` — بدء سحب جديد\n' +
        '`/gend` — إنهاء سحب مبكراً\n' +
        '`/greroll` — إعادة اختيار الفائز\n' +
        '`/glist` — عرض السحوبات النشطة\n' +
        '`/gdelete` — حذف سحب',
      inline: false,
    })
    .setFooter({ text: `${settings.footer} • السحوبات تُدار بالكامل عبر الأوامر` })
    .setTimestamp();

  return { embeds: [embed], components: [navRow()] };
}

module.exports = { buildGiveawaysView };
