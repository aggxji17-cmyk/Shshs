/**
 * Task 45 — Economy Settings UI (إعدادات الاقتصاد).
 *
 * Renders the interactive economy configuration section that opens when
 * the admin picks "الاقتصاد" from the /settings dashboard.
 *
 * Controls exposed:
 *   • تشغيل/إيقاف الاقتصاد             (sec_toggle)
 *   • اسم العملة                        (sec_currency_name)  → Modal
 *   • رمز العملة                        (sec_currency_symbol)→ Modal
 *   • مكافأة /daily                     (sec_daily)          → Modal
 *   • نطاق /work                        (sec_work)           → Modal
 *   • فترة تهدئة /work                  (sec_work_cooldown)  → Modal
 *   Navigation: settings_back / settings_home / settings_close
 *
 * All modals:
 *   sec_modal_currency_name    — currency name
 *   sec_modal_currency_symbol  — currency symbol (emoji)
 *   sec_modal_daily            — daily amount
 *   sec_modal_work             — work min/max amounts
 *   sec_modal_work_cooldown    — work cooldown in minutes
 */

const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
} = require('discord.js');
const { COLORS, ICONS, DIVIDER } = require('./designSystem');
const { getGuildConfig, resolved, invalidateGuildConfig } = require('./resolveGuildSettings');
const { errorEmbed } = require('./embeds');
const { isGuildManager } = require('./permissions');
const logger = require('./logger');

// ─── CustomId constants ───────────────────────────────────────────────────────
const SEC_TOGGLE_ID           = 'sec_toggle';
const SEC_CURRENCY_NAME_ID    = 'sec_currency_name';
const SEC_CURRENCY_SYMBOL_ID  = 'sec_currency_symbol';
const SEC_DAILY_ID            = 'sec_daily';
const SEC_WORK_ID             = 'sec_work';
const SEC_WORK_COOLDOWN_ID    = 'sec_work_cooldown';

const SEC_MODAL_CURRENCY_NAME   = 'sec_modal_currency_name';
const SEC_MODAL_CURRENCY_SYMBOL = 'sec_modal_currency_symbol';
const SEC_MODAL_DAILY           = 'sec_modal_daily';
const SEC_MODAL_WORK            = 'sec_modal_work';
const SEC_MODAL_WORK_COOLDOWN   = 'sec_modal_work_cooldown';

// ─── Helpers ──────────────────────────────────────────────────────────────────
function onOff(bool) {
  return bool ? `${ICONS.success} مُفعَّل` : `${ICONS.error} مُعطَّل`;
}

function navRow() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('settings_back').setLabel('رجوع / Back').setEmoji(ICONS.back).setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('settings_home').setLabel('الرئيسية / Home').setEmoji(ICONS.home).setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('settings_close').setLabel('إغلاق / Close').setEmoji(ICONS.close).setStyle(ButtonStyle.Danger),
  );
}

// ─── View builder ─────────────────────────────────────────────────────────────
function buildEconomyView(settings, guildConfig) {
  const eco = guildConfig?.economy ?? {};

  const embed = new EmbedBuilder()
    .setColor(COLORS.primary)
    .setTitle(`${ICONS.economy}・إعدادات الاقتصاد (Economy)`)
    .setDescription(`إدارة العملات والمتجر والمكافآت اليومية.\n${DIVIDER}`)
    .addFields(
      { name: `${ICONS.settings} الحالة`, value: onOff(eco.enabled ?? false), inline: true },
      { name: `💎 اسم العملة`, value: eco.currencyName ?? 'coins', inline: true },
      { name: `🪙 رمز العملة`, value: eco.currencySymbol ?? '🪙', inline: true },
      { name: `🎁 مكافأة /daily`, value: `${eco.dailyAmount ?? 100}`, inline: true },
      { name: `💼 نطاق /work`, value: `${eco.workMin ?? 20} – ${eco.workMax ?? 150}`, inline: true },
      { name: `⏱️ فترة تهدئة /work`, value: `${eco.workCooldownMinutes ?? 60} دقيقة`, inline: true },
    )
    .setFooter({ text: `${settings.footer} • استخدم الأزرار أدناه لتعديل الإعدادات` })
    .setTimestamp();

  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(SEC_TOGGLE_ID)
      .setLabel(eco.enabled ? 'تعطيل الاقتصاد' : 'تفعيل الاقتصاد')
      .setEmoji(eco.enabled ? ICONS.error : ICONS.success)
      .setStyle(eco.enabled ? ButtonStyle.Danger : ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(SEC_CURRENCY_NAME_ID)
      .setLabel('اسم العملة')
      .setEmoji('💎')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId(SEC_CURRENCY_SYMBOL_ID)
      .setLabel('رمز العملة')
      .setEmoji('🪙')
      .setStyle(ButtonStyle.Primary),
  );

  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(SEC_DAILY_ID)
      .setLabel('مكافأة /daily')
      .setEmoji('🎁')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId(SEC_WORK_ID)
      .setLabel('نطاق /work')
      .setEmoji('💼')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId(SEC_WORK_COOLDOWN_ID)
      .setLabel('فترة تهدئة /work')
      .setEmoji('⏱️')
      .setStyle(ButtonStyle.Secondary),
  );

  return { embeds: [embed], components: [row1, row2, navRow()] };
}

// ─── Interaction handlers ─────────────────────────────────────────────────────

async function handleEconomyButton(interaction) {
  const id = interaction.customId;
  const guildConfig = await getGuildConfig(interaction.guildId);
  const settings    = resolved(guildConfig);

  if (!isGuildManager(interaction.member, guildConfig)) {
    return interaction.reply({
      embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر (Manage Server) لاستخدام هذه الواجهة.')],
      ephemeral: true,
    });
  }

  if (id === SEC_TOGGLE_ID) {
    const current = guildConfig.economy?.enabled ?? false;
    guildConfig.economy.enabled = !current;
    await guildConfig.save();
    invalidateGuildConfig(interaction.guildId);
    const updated = await getGuildConfig(interaction.guildId);
    const view = buildEconomyView(resolved(updated), updated);
    return interaction.update({ embeds: view.embeds, components: view.components });
  }

  const eco = guildConfig.economy ?? {};

  if (id === SEC_CURRENCY_NAME_ID) {
    const modal = new ModalBuilder().setCustomId(SEC_MODAL_CURRENCY_NAME).setTitle('اسم العملة');
    modal.addComponents(new ActionRowBuilder().addComponents(
      new TextInputBuilder().setCustomId('name').setLabel('اسم العملة').setStyle(TextInputStyle.Short)
        .setPlaceholder('مثال: نقطة، دولار، ذهب').setRequired(true).setValue(eco.currencyName ?? 'coins'),
    ));
    return interaction.showModal(modal);
  }

  if (id === SEC_CURRENCY_SYMBOL_ID) {
    const modal = new ModalBuilder().setCustomId(SEC_MODAL_CURRENCY_SYMBOL).setTitle('رمز العملة');
    modal.addComponents(new ActionRowBuilder().addComponents(
      new TextInputBuilder().setCustomId('symbol').setLabel('رمز أو إيموجي العملة').setStyle(TextInputStyle.Short)
        .setPlaceholder('مثال: 🪙 أو 💵').setRequired(true).setValue(eco.currencySymbol ?? '🪙'),
    ));
    return interaction.showModal(modal);
  }

  if (id === SEC_DAILY_ID) {
    const modal = new ModalBuilder().setCustomId(SEC_MODAL_DAILY).setTitle('مكافأة /daily');
    modal.addComponents(new ActionRowBuilder().addComponents(
      new TextInputBuilder().setCustomId('amount').setLabel('القيمة اليومية').setStyle(TextInputStyle.Short)
        .setPlaceholder('مثال: 100').setRequired(true).setValue(String(eco.dailyAmount ?? 100)),
    ));
    return interaction.showModal(modal);
  }

  if (id === SEC_WORK_ID) {
    const modal = new ModalBuilder().setCustomId(SEC_MODAL_WORK).setTitle('نطاق /work');
    modal.addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('min').setLabel('الحد الأدنى').setStyle(TextInputStyle.Short)
          .setPlaceholder('مثال: 20').setRequired(true).setValue(String(eco.workMin ?? 20)),
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder().setCustomId('max').setLabel('الحد الأقصى').setStyle(TextInputStyle.Short)
          .setPlaceholder('مثال: 150').setRequired(true).setValue(String(eco.workMax ?? 150)),
      ),
    );
    return interaction.showModal(modal);
  }

  if (id === SEC_WORK_COOLDOWN_ID) {
    const modal = new ModalBuilder().setCustomId(SEC_MODAL_WORK_COOLDOWN).setTitle('فترة تهدئة /work');
    modal.addComponents(new ActionRowBuilder().addComponents(
      new TextInputBuilder().setCustomId('minutes').setLabel('المدة بالدقائق').setStyle(TextInputStyle.Short)
        .setPlaceholder('مثال: 60').setRequired(true).setValue(String(eco.workCooldownMinutes ?? 60)),
    ));
    return interaction.showModal(modal);
  }
}

async function handleEconomyModal(interaction) {
  const id = interaction.customId;
  const guildConfig = await getGuildConfig(interaction.guildId);
  const settings    = resolved(guildConfig);

  if (!isGuildManager(interaction.member, guildConfig)) {
    return interaction.reply({
      embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر (Manage Server) لاستخدام هذه الواجهة.')],
      ephemeral: true,
    });
  }

  try {
    if (id === SEC_MODAL_CURRENCY_NAME) {
      const val = interaction.fields.getTextInputValue('name').trim();
      if (!val) return interaction.reply({ embeds: [errorEmbed(settings, 'الاسم لا يمكن أن يكون فارغاً.')], ephemeral: true });
      guildConfig.economy.currencyName = val;
    }

    if (id === SEC_MODAL_CURRENCY_SYMBOL) {
      const val = interaction.fields.getTextInputValue('symbol').trim();
      if (!val) return interaction.reply({ embeds: [errorEmbed(settings, 'الرمز لا يمكن أن يكون فارغاً.')], ephemeral: true });
      guildConfig.economy.currencySymbol = val;
    }

    if (id === SEC_MODAL_DAILY) {
      const amount = parseInt(interaction.fields.getTextInputValue('amount'), 10);
      if (isNaN(amount) || amount < 0) return interaction.reply({ embeds: [errorEmbed(settings, 'قيمة غير صحيحة.')], ephemeral: true });
      guildConfig.economy.dailyAmount = amount;
    }

    if (id === SEC_MODAL_WORK) {
      const min = parseInt(interaction.fields.getTextInputValue('min'), 10);
      const max = parseInt(interaction.fields.getTextInputValue('max'), 10);
      if (isNaN(min) || isNaN(max) || min < 0 || max < min) {
        return interaction.reply({ embeds: [errorEmbed(settings, 'القيم غير صحيحة. تأكد أن الحد الأدنى أقل من الأقصى.')], ephemeral: true });
      }
      guildConfig.economy.workMin = min;
      guildConfig.economy.workMax = max;
    }

    if (id === SEC_MODAL_WORK_COOLDOWN) {
      const mins = parseInt(interaction.fields.getTextInputValue('minutes'), 10);
      if (isNaN(mins) || mins < 1) return interaction.reply({ embeds: [errorEmbed(settings, 'قيمة غير صحيحة. أدخل عدداً موجباً للدقائق.')], ephemeral: true });
      guildConfig.economy.workCooldownMinutes = mins;
    }

    await interaction.deferUpdate();
    await guildConfig.save();
    invalidateGuildConfig(interaction.guildId);
    const updated = await getGuildConfig(interaction.guildId);
    const view = buildEconomyView(resolved(updated), updated);
    return interaction.editReply({ embeds: view.embeds, components: view.components });

  } catch (err) {
    logger.error('[economyDashboard] Modal save error:', err);
    return (interaction.deferred || interaction.replied ? interaction.followUp : interaction.reply).call(interaction, { embeds: [errorEmbed(settings, 'حدث خطأ أثناء حفظ الإعداد. حاول مجدداً.')], ephemeral: true });
  }
}

module.exports = {
  buildEconomyView,
  handleEconomyButton,
  handleEconomyModal,
  SEC_TOGGLE_ID,
  SEC_CURRENCY_NAME_ID,
  SEC_CURRENCY_SYMBOL_ID,
  SEC_DAILY_ID,
  SEC_WORK_ID,
  SEC_WORK_COOLDOWN_ID,
  SEC_MODAL_CURRENCY_NAME,
  SEC_MODAL_CURRENCY_SYMBOL,
  SEC_MODAL_DAILY,
  SEC_MODAL_WORK,
  SEC_MODAL_WORK_COOLDOWN,
};
