/**
 * Small dependency-free logger with timestamps and log levels.
 * Keeping this in-house avoids pulling in a heavy logging framework
 * for what is otherwise a simple console-based need.
 *
 * TASK 27 — Performance:
 * timestamp() previously called new Date().toISOString() on every single
 * log line. Under high event-load (thousands of messageCreate / interactionCreate
 * fires per minute) this produced thousands of short-lived Date objects and
 * their ISO strings — needless GC pressure. The new implementation caches
 * the formatted second-precision string for the current second and rebuilds
 * it only once per second, reducing object allocation to at most 1 per 1 000 ms
 * regardless of log volume.
 */
const COLORS = {
  reset: '\x1b[0m',
  gray: '\x1b[90m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  red: '\x1b[31m',
  cyan: '\x1b[36m',
  magenta: '\x1b[35m',
};

// Cache the formatted timestamp string for the current second.
// Rebuilt at most once every 1 000 ms.
let _cachedTs = '';
let _cachedSec = -1;

function timestamp() {
  const now = Date.now();
  const sec = Math.floor(now / 1000);
  if (sec !== _cachedSec) {
    _cachedSec = sec;
    _cachedTs = new Date(now).toISOString().replace('T', ' ').substring(0, 19);
  }
  return _cachedTs;
}

function line(color, tag, msg) {
  console.log(`${COLORS.gray}[${timestamp()}]${COLORS.reset} ${color}${tag}${COLORS.reset} ${msg}`);
}

module.exports = {
  info:    (msg) => line(COLORS.cyan,    '[INFO]',  msg),
  success: (msg) => line(COLORS.green,   '[OK]',    msg),
  warn:    (msg) => line(COLORS.yellow,  '[WARN]',  msg),
  error:   (msg) => line(COLORS.red,     '[ERROR]', msg),
  event:   (msg) => line(COLORS.magenta, '[EVENT]', msg),
};
