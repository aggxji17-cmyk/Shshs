/**
 * Task 45 — Broadcast Settings UI (إعدادات البث).
 *
 * Renders the broadcast/announcement info section that opens when the
 * admin picks "البث" from the /settings dashboard.
 *
 * Broadcast (scheduled announcements) are per-record in the Announcement
 * collection; there are no guild-level on/off toggles. This view shows
 * how many active scheduled announcements exist and points to the command.
 *
 * Navigation: settings_back / settings_home / settings_close
 */

const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require('discord.js');
const { COLORS, ICONS, DIVIDER } = require('./designSystem');
const Announcement = require('../database/models/Announcement');
const logger = require('./logger');

function navRow() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('settings_back').setLabel('رجوع / Back').setEmoji(ICONS.back).setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('settings_home').setLabel('الرئيسية / Home').setEmoji(ICONS.home).setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('settings_close').setLabel('إغلاق / Close').setEmoji(ICONS.close).setStyle(ButtonStyle.Danger),
  );
}

async function buildBroadcastView(settings, guildId) {
  let activeCount = 0;

  try {
    activeCount = await Announcement.countDocuments({ guildId });
  } catch (err) {
    logger.error('[broadcastDashboard] Count error:', err);
  }

  const embed = new EmbedBuilder()
    .setColor(COLORS.primary)
    .setTitle(`${ICONS.broadcast}・إعدادات البث (Broadcast)`)
    .setDescription(
      `إدارة الإعلانات المجدولة والبث الدوري لأعضاء السيرفر.\n${DIVIDER}`
    )
    .addFields(
      { name: `📢 إعلانات مجدولة`, value: String(activeCount), inline: true },
    )
    .addFields({
      name: `${ICONS.info} الأوامر المتاحة`,
      value:
        '`/announcement create` — إنشاء إعلان مجدول\n' +
        '`/announcement list` — عرض الإعلانات الحالية\n' +
        '`/announcement delete` — حذف إعلان\n' +
        '`/broadcast` — إرسال رسالة جماعية لأعضاء السيرفر',
      inline: false,
    })
    .setFooter({ text: `${settings.footer} • الإعلانات تُدار عبر الأوامر` })
    .setTimestamp();

  return { embeds: [embed], components: [navRow()] };
}

module.exports = { buildBroadcastView };
