const fs = require('node:fs');
const path = require('node:path');
const logger = require('./logger');

/**
 * Recursively collects every .js file under `dir`.
 *
 * A single unreadable directory (permission error, a broken symlink, an
 * entry removed mid-scan, etc.) used to throw straight out of this
 * function, which in turn crashed the caller (e.g. commandHandler.js /
 * eventHandler.js) and took down the whole bot at startup even though
 * every other command/event file was perfectly loadable. Each directory
 * read is now isolated: an unreadable one is logged and skipped, and
 * everything else keeps loading normally.
 *
 * TASK 27 — Performance:
 * Results are memoised per directory so repeated calls (e.g. hot-path
 * tooling that calls loadCommands more than once) do not re-walk the
 * filesystem. The cache is keyed by absolute path and lives for the
 * lifetime of the process. Use walkFresh() to bypass it if you need
 * an up-to-date listing (e.g. in tests or dynamic-reload scenarios).
 */

// Map<absDir, string[]>
const _cache = new Map();

function _walkDir(dir) {
  let entries;
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch (error) {
    logger.warn(`Skipping unreadable directory during file scan (${dir}): ${error.message}`);
    return [];
  }

  let files = [];
  for (const entry of entries) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) files = files.concat(_walkDir(full));
    else if (entry.name.endsWith('.js')) files.push(full);
  }
  return files;
}

/**
 * Returns cached file list for `dir`. Populates the cache on first call.
 */
function walk(dir) {
  const abs = path.resolve(dir);
  if (_cache.has(abs)) return _cache.get(abs);
  const result = _walkDir(abs);
  _cache.set(abs, result);
  return result;
}

/**
 * Bypasses the cache — always performs a fresh filesystem walk.
 * Use this in tests or when you need to detect newly-added files.
 */
function walkFresh(dir) {
  const abs = path.resolve(dir);
  const result = _walkDir(abs);
  _cache.set(abs, result);
  return result;
}

/** Clears the walk cache (useful between test runs). */
function clearWalkCache() {
  _cache.clear();
}

module.exports = { walk, walkFresh, clearWalkCache };
