const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { QueueRepeatMode } = require('discord-player');

/**
 * Builds the interactive playback-control button rows shown under
 * "Now Playing" messages (both the automatic one sent on PlayerStart
 * and the one sent by /nowplaying). Button state (pause icon, loop/
 * autoplay highlight) reflects the current queue so the rows always
 * match reality right after they're rendered.
 *
 * Returns an array of two ActionRowBuilders (Discord caps rows at 5
 * buttons each) - pass it straight as `components` to reply/send/update.
 *
 * customIds are handled in components/buttons.js, prefixed `music_`.
 */
function buildMusicControlsRow(queue) {
  const isPaused = queue?.node?.isPaused?.() ?? false;
  const repeatMode = queue?.repeatMode ?? QueueRepeatMode.OFF;
  const isAutoplay = repeatMode === QueueRepeatMode.AUTOPLAY;

  const primaryRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('music_pauseresume')
      .setEmoji(isPaused ? '▶️' : '⏸️')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('music_skip')
      .setEmoji('⏭️')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('music_stop')
      .setEmoji('⏹️')
      .setStyle(ButtonStyle.Danger),
    new ButtonBuilder()
      .setCustomId('music_shuffle')
      .setEmoji('🔀')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('music_loop')
      .setEmoji('🔁')
      .setStyle(!isAutoplay && repeatMode !== QueueRepeatMode.OFF ? ButtonStyle.Success : ButtonStyle.Secondary)
  );

  const secondaryRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('music_autoplay')
      .setLabel('تلقائي')
      .setEmoji('🔄')
      .setStyle(isAutoplay ? ButtonStyle.Success : ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('music_favorite')
      .setLabel('مفضلة')
      .setEmoji('❤️')
      .setStyle(ButtonStyle.Secondary)
  );

  return [primaryRow, secondaryRow];
}

module.exports = { buildMusicControlsRow };
