'use strict';

/**
 * Task 49 — نظام التأكيد الموحّد (Unified Confirmation System).
 *
 * يوحّد جميع نوافذ التأكيد الخطيرة في البوت في مكان واحد بدلاً من
 * تكرار نفس كود Embed/Buttons في كل ملف.
 *
 * حالات الاستخدام المطلوبة (من مواصفة المهمة 49):
 *   ✅ Delete          — حذف عنصر نهائياً
 *   ✅ Reset           — إعادة ضبط الإعدادات
 *   ✅ Close           — إغلاق نظام/جلسة
 *   ✅ Remove          — إزالة عضو/دور/عنصر
 *   ✅ Clear Data      — مسح البيانات
 *   ✅ حذف Panel       — حذف لوحة تذكرة
 *   ✅ Reset Settings  — إعادة ضبط إعدادات كاملة
 *
 * آلية العمل:
 *   1. يتم بناء Embed تأكيد + زرَّي ✅ نعم / ✖️ لا عبر buildConfirmView().
 *   2. يتم تمرير نوع العملية وبياناتها في customId بصيغة:
 *      nyxo_confirm:<action>:<token>
 *      - action : نوع العملية (delete, reset, close, remove, clear, …)
 *      - token  : بيانات مُشفَّرة بـ "~" بدل ":" (مثل معرّف عنصر)
 *   3. عند نقر ✅ يُرسَل customId: nyxo_confirm_yes:<action>:<token>
 *      عند نقر ✖️ يُرسَل customId: nyxo_confirm_no:<action>:<token>
 *   4. كل معالج Button في buttons.js يستدعي
 *      handleConfirmYes() أو handleConfirmNo() من هنا.
 *
 * الاستخدام من buttons.js:
 *   const { buildConfirmView } = require('../utils/confirmationSystem');
 *
 *   // عرض نافذة التأكيد:
 *   const { embed, components } = buildConfirmView({
 *     action      : 'delete_panel',
 *     token       : panelId,
 *     title       : '🗑️ حذف اللوحة',
 *     description : `هل أنت متأكد من حذف اللوحة **${panelName}**؟\nلا يمكن التراجع عن هذا الإجراء.`,
 *     settings,
 *   });
 *   await interaction.update({ embeds: [embed], components });
 *
 *   // في معالج nyxo_confirm_yes:
 *   case 'delete_panel': {
 *     const panelId = token;
 *     // نفّذ الحذف
 *     break;
 *   }
 *
 * الوظائف المُصدَّرة:
 *   buildConfirmView(opts)        → { embed, components }
 *   buildConfirmId(action, token) → string (customId لزر نعم)
 *   parseConfirmId(customId)      → { action, token }
 *   CONFIRM_YES_PREFIX            → 'nyxo_confirm_yes'
 *   CONFIRM_NO_PREFIX             → 'nyxo_confirm_no'
 */

const { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');
const { COLORS, ICONS } = require('./designSystem');

// ─── ثوابت ──────────────────────────────────────────────────────────────────

/** بادئة customId زر التأكيد (نعم). */
const CONFIRM_YES_PREFIX = 'nyxo_confirm_yes';

/** بادئة customId زر الإلغاء (لا). */
const CONFIRM_NO_PREFIX = 'nyxo_confirm_no';

/** أقصى طول للـ token (customId Discord حد 100 حرف). */
const MAX_TOKEN_LEN = 60;

// ─── بناء customId ───────────────────────────────────────────────────────────

/**
 * يبني customId موحد لزر التأكيد أو الإلغاء.
 * @param {'yes'|'no'}  side   - 'yes' أو 'no'
 * @param {string}      action - نوع العملية (e.g. 'delete_panel')
 * @param {string}      token  - بيانات إضافية (يُستبدل ":" بـ "~" تلقائيًا)
 * @returns {string}
 */
function buildConfirmId(side, action, token = '') {
  const prefix = side === 'yes' ? CONFIRM_YES_PREFIX : CONFIRM_NO_PREFIX;
  const safeToken = String(token).replace(/:/g, '~').slice(0, MAX_TOKEN_LEN);
  return `${prefix}:${action}:${safeToken}`;
}

/**
 * يفكّك customId زر التأكيد.
 * @param {string} customId
 * @returns {{ valid: boolean, side: 'yes'|'no'|'', action: string, token: string }}
 */
function parseConfirmId(customId) {
  const isYes = customId.startsWith(CONFIRM_YES_PREFIX + ':');
  const isNo  = customId.startsWith(CONFIRM_NO_PREFIX + ':');
  if (!isYes && !isNo) return { valid: false, side: '', action: '', token: '' };

  const prefix = isYes ? CONFIRM_YES_PREFIX : CONFIRM_NO_PREFIX;
  const rest   = customId.slice(prefix.length + 1); // بعد "prefix:"
  const colonIdx = rest.indexOf(':');
  const action = colonIdx >= 0 ? rest.slice(0, colonIdx) : rest;
  const token  = colonIdx >= 0 ? rest.slice(colonIdx + 1).replace(/~/g, ':') : '';
  return { valid: true, side: isYes ? 'yes' : 'no', action, token };
}

// ─── بناء الواجهة ────────────────────────────────────────────────────────────

/**
 * @typedef {object} ConfirmViewOpts
 * @property {string}  action       - نوع العملية (e.g. 'delete_panel', 'reset_settings')
 * @property {string}  [token]      - بيانات إضافية تُمرَّر في customId
 * @property {string}  title        - عنوان Embed التأكيد
 * @property {string}  description  - نص التحذير/الوصف المعروض للمستخدم
 * @property {object}  [settings]   - إعدادات السيرفر (لون Embed وما إلى ذلك)
 * @property {string}  [yesLabel]   - تسمية زر التأكيد (افتراضي: 'نعم، تأكيد')
 * @property {string}  [noLabel]    - تسمية زر الإلغاء (افتراضي: 'إلغاء')
 * @property {boolean} [dangerous]  - إذا true يظهر زر التأكيد بلون أحمر (Danger)
 */

/**
 * يبني Embed التأكيد وصفَّي الأزرار.
 *
 * @param {ConfirmViewOpts} opts
 * @returns {{ embed: EmbedBuilder, components: ActionRowBuilder[] }}
 */
function buildConfirmView(opts) {
  const {
    action,
    token      = '',
    title,
    description,
    settings   = {},
    yesLabel   = 'نعم، تأكيد',
    noLabel    = 'إلغاء',
    dangerous  = true,
  } = opts;

  // ── Embed ──
  const color = settings?.embedColor ?? COLORS.warning;
  const embed = new EmbedBuilder()
    .setColor(color)
    .setTitle(title)
    .setDescription(description)
    .setFooter({ text: 'هذا الإجراء قد لا يمكن التراجع عنه — فكّر جيداً قبل التأكيد.' });

  // ── أزرار ──
  const yesBtn = new ButtonBuilder()
    .setCustomId(buildConfirmId('yes', action, token))
    .setLabel(yesLabel)
    .setEmoji(ICONS.success)
    .setStyle(dangerous ? ButtonStyle.Danger : ButtonStyle.Success);

  const noBtn = new ButtonBuilder()
    .setCustomId(buildConfirmId('no', action, token))
    .setLabel(noLabel)
    .setEmoji(ICONS.close)
    .setStyle(ButtonStyle.Secondary);

  const row = new ActionRowBuilder().addComponents(yesBtn, noBtn);

  return { embed, components: [row] };
}

// ─── أنواع العمليات القياسية ─────────────────────────────────────────────────

/**
 * أنواع العمليات المدعومة في النظام الموحّد.
 * كل نوع له عنوان ووصف افتراضي يمكن override من المُستدعي.
 *
 * الاستخدام:
 *   const preset = CONFIRM_PRESETS.delete;
 *   const { embed, components } = buildConfirmView({
 *     ...preset,
 *     action: 'delete_panel',
 *     token:  panelId,
 *     description: `هل تريد حذف اللوحة **${name}**؟`,
 *     settings,
 *   });
 */
const CONFIRM_PRESETS = {
  /** حذف عنصر نهائياً */
  delete: {
    title    : `${ICONS.error} تأكيد الحذف`,
    dangerous: true,
    yesLabel : 'نعم، احذف',
    noLabel  : 'إلغاء',
  },

  /** إعادة ضبط إعداد أو نظام */
  reset: {
    title    : `${ICONS.warning} تأكيد إعادة الضبط`,
    dangerous: true,
    yesLabel : 'نعم، أعد الضبط',
    noLabel  : 'إلغاء',
  },

  /** إغلاق نظام أو جلسة */
  close: {
    title    : `${ICONS.warning} تأكيد الإغلاق`,
    dangerous: false,
    yesLabel : 'نعم، أغلق',
    noLabel  : 'إلغاء',
  },

  /** إزالة عضو أو دور أو عنصر */
  remove: {
    title    : `${ICONS.warning} تأكيد الإزالة`,
    dangerous: true,
    yesLabel : 'نعم، أزِل',
    noLabel  : 'إلغاء',
  },

  /** مسح بيانات كاملة */
  clear: {
    title    : `${ICONS.error} تأكيد مسح البيانات`,
    dangerous: true,
    yesLabel : 'نعم، امسح',
    noLabel  : 'إلغاء',
  },
};

// ─── مساعدات إضافية ──────────────────────────────────────────────────────────

/**
 * يبني سريعاً نافذة تأكيد حذف Panel تذكرة.
 * استخدام مختصر بدون ملء جميع الحقول يدوياً.
 *
 * @param {{ panelId: string, panelChannel: string, settings: object }} opts
 * @returns {{ embed: EmbedBuilder, components: ActionRowBuilder[] }}
 */
function buildDeletePanelConfirm({ panelId, panelChannel, settings }) {
  return buildConfirmView({
    ...CONFIRM_PRESETS.delete,
    action     : 'delete_panel',
    token      : panelId,
    description: `هل أنت متأكد من حذف لوحة التذاكر في <#${panelChannel}>؟\n\n⚠️ سيتم حذف اللوحة من قاعدة البيانات نهائياً وقد لا يمكن استعادتها.`,
    settings,
  });
}

/**
 * يبني نافذة تأكيد إعادة ضبط إعداد.
 *
 * @param {{ action: string, settingName: string, token?: string, settings: object }} opts
 * @returns {{ embed: EmbedBuilder, components: ActionRowBuilder[] }}
 */
function buildResetSettingConfirm({ action, settingName, token = '', settings }) {
  return buildConfirmView({
    ...CONFIRM_PRESETS.reset,
    action,
    token,
    description: `هل أنت متأكد من إعادة ضبط **${settingName}** إلى القيم الافتراضية؟\n\n⚠️ سيتم حذف جميع الإعدادات الحالية المرتبطة بها.`,
    settings,
  });
}

/**
 * يبني نافذة تأكيد إزالة عضو من تذكرة.
 *
 * @param {{ userId: string, ticketId: string, settings: object }} opts
 * @returns {{ embed: EmbedBuilder, components: ActionRowBuilder[] }}
 */
function buildRemoveMemberConfirm({ userId, ticketId, settings }) {
  return buildConfirmView({
    ...CONFIRM_PRESETS.remove,
    action     : 'remove_member',
    token      : `${ticketId}~${userId}`,
    description: `هل أنت متأكد من إزالة <@${userId}> من هذه التذكرة؟\n\nسيفقد العضو صلاحية الوصول للقناة فوراً.`,
    settings,
  });
}

/**
 * يبني نافذة تأكيد مسح بيانات (عامة).
 *
 * @param {{ action: string, dataName: string, token?: string, settings: object }} opts
 * @returns {{ embed: EmbedBuilder, components: ActionRowBuilder[] }}
 */
function buildClearDataConfirm({ action, dataName, token = '', settings }) {
  return buildConfirmView({
    ...CONFIRM_PRESETS.clear,
    action,
    token,
    description: `هل أنت متأكد من مسح **${dataName}**؟\n\n❌ هذا الإجراء لا يمكن التراجع عنه.`,
    settings,
  });
}

// ─── Exports ─────────────────────────────────────────────────────────────────

module.exports = {
  // الثوابت
  CONFIRM_YES_PREFIX,
  CONFIRM_NO_PREFIX,
  CONFIRM_PRESETS,

  // بناء customId
  buildConfirmId,
  parseConfirmId,

  // بناء الواجهة العامة
  buildConfirmView,

  // مساعدات جاهزة لحالات شائعة
  buildDeletePanelConfirm,
  buildResetSettingConfirm,
  buildRemoveMemberConfirm,
  buildClearDataConfirm,
};
