/**
 * Task 45 — Leveling Settings UI (إعدادات المستويات).
 *
 * Renders the interactive leveling configuration section that opens when
 * the admin picks "المستويات" from the /settings dashboard.
 *
 * Controls exposed:
 *   • تشغيل/إيقاف المستويات            (slv_toggle)
 *   • قناة الإعلانات                    (slv_announce_channel) → Modal
 *   • تشغيل/إيقاف إعلانات الترقية      (slv_announce_toggle)
 *   • نطاق XP (الحد الأدنى والأقصى)    (slv_xp_range)        → Modal
 *   • فترة التهدئة (cooldown)           (slv_cooldown)         → Modal
 *   • تشغيل/إيقاف XP الصوت             (slv_voice_toggle)
 *   • XP الصوت في الدقيقة              (slv_voice_xp)         → Modal
 *   • الحد الأدنى للأعضاء في الصوت     (slv_voice_min)        → Modal
 *   Navigation: settings_back / settings_home / settings_close
 *
 * All modals:
 *   slv_modal_announce_channel  — channel ID for level-up announcements
 *   slv_modal_xp_range          — xpMin and xpMax values
 *   slv_modal_cooldown          — cooldown in seconds
 *   slv_modal_voice_xp          — voiceXpPerMinute value
 *   slv_modal_voice_min         — voiceMinMembers value
 */

const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
} = require('discord.js');
const { COLORS, ICONS, DIVIDER } = require('./designSystem');
const { getGuildConfig, resolved, invalidateGuildConfig } = require('./resolveGuildSettings');
const { errorEmbed } = require('./embeds');
const { isGuildManager } = require('./permissions');
const logger = require('./logger');

// ─── CustomId constants ───────────────────────────────────────────────────────
const SLV_TOGGLE_ID             = 'slv_toggle';
const SLV_ANNOUNCE_TOGGLE_ID    = 'slv_announce_toggle';
const SLV_ANNOUNCE_CHANNEL_ID   = 'slv_announce_channel';
const SLV_XP_RANGE_ID           = 'slv_xp_range';
const SLV_COOLDOWN_ID           = 'slv_cooldown';
const SLV_VOICE_TOGGLE_ID       = 'slv_voice_toggle';
const SLV_VOICE_XP_ID           = 'slv_voice_xp';
const SLV_VOICE_MIN_ID          = 'slv_voice_min';

const SLV_MODAL_ANNOUNCE_CHANNEL = 'slv_modal_announce_channel';
const SLV_MODAL_XP_RANGE         = 'slv_modal_xp_range';
const SLV_MODAL_COOLDOWN         = 'slv_modal_cooldown';
const SLV_MODAL_VOICE_XP         = 'slv_modal_voice_xp';
const SLV_MODAL_VOICE_MIN        = 'slv_modal_voice_min';

// ─── Helpers ──────────────────────────────────────────────────────────────────
function onOff(bool) {
  return bool ? `${ICONS.success} مُفعَّل` : `${ICONS.error} مُعطَّل`;
}

function resolveXpDisplay(cfg) {
  const lvl = cfg.leveling || {};
  if (lvl.xpMin != null && lvl.xpMax != null) {
    return `${lvl.xpMin} – ${lvl.xpMax} XP`;
  }
  return `${lvl.xpPerMessage ?? 15} XP (ثابت)`;
}

function navRow() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('settings_back').setLabel('رجوع / Back').setEmoji(ICONS.back).setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('settings_home').setLabel('الرئيسية / Home').setEmoji(ICONS.home).setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('settings_close').setLabel('إغلاق / Close').setEmoji(ICONS.close).setStyle(ButtonStyle.Danger),
  );
}

// ─── View builder ─────────────────────────────────────────────────────────────
function buildLevelingView(settings, guildConfig) {
  const cfg = guildConfig ?? {};
  const lvl = cfg.leveling ?? {};

  const xpDisplay  = resolveXpDisplay(cfg);
  const channel    = lvl.announceChannelId ? `<#${lvl.announceChannelId}>` : '—';
  const cooldown   = lvl.cooldownSeconds ?? 60;
  const vxpPerMin  = lvl.voiceXpPerMinute ?? 10;
  const vMinMembers = lvl.voiceMinMembers ?? 2;

  const embed = new EmbedBuilder()
    .setColor(COLORS.primary)
    .setTitle(`${ICONS.leveling}・إعدادات المستويات (Leveling)`)
    .setDescription(
      `إدارة نظام الخبرة والمستويات ورتب المكافآت.\n${DIVIDER}`
    )
    .addFields(
      {
        name: `${ICONS.settings} الحالة العامة`,
        value: onOff(lvl.enabled ?? false),
        inline: true,
      },
      {
        name: `${ICONS.notifications} إعلانات الترقية`,
        value: onOff(lvl.announceLevelUp ?? true),
        inline: true,
      },
      {
        name: `${ICONS.logging} قناة الإعلانات`,
        value: channel,
        inline: true,
      },
      {
        name: `${ICONS.stats} نطاق XP`,
        value: xpDisplay,
        inline: true,
      },
      {
        name: `⏱️ فترة التهدئة`,
        value: `${cooldown} ثانية`,
        inline: true,
      },
      {
        name: `🎙️ XP الصوت`,
        value: onOff(lvl.voiceXpEnabled ?? false),
        inline: true,
      },
      {
        name: `🎙️ XP الصوت / دقيقة`,
        value: `${vxpPerMin} XP`,
        inline: true,
      },
      {
        name: `👥 حد الأعضاء في الصوت`,
        value: `${vMinMembers} عضو`,
        inline: true,
      },
    )
    .setFooter({ text: `${settings.footer} • استخدم الأزرار أدناه لتعديل الإعدادات` })
    .setTimestamp();

  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(SLV_TOGGLE_ID)
      .setLabel(lvl.enabled ? 'تعطيل المستويات' : 'تفعيل المستويات')
      .setEmoji(lvl.enabled ? ICONS.error : ICONS.success)
      .setStyle(lvl.enabled ? ButtonStyle.Danger : ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(SLV_ANNOUNCE_TOGGLE_ID)
      .setLabel(lvl.announceLevelUp ? 'إيقاف إعلانات الترقية' : 'تفعيل إعلانات الترقية')
      .setEmoji(ICONS.notifications)
      .setStyle(lvl.announceLevelUp ? ButtonStyle.Secondary : ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId(SLV_ANNOUNCE_CHANNEL_ID)
      .setLabel('قناة الإعلانات')
      .setEmoji(ICONS.logging)
      .setStyle(ButtonStyle.Primary),
  );

  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(SLV_XP_RANGE_ID)
      .setLabel('نطاق XP')
      .setEmoji(ICONS.stats)
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId(SLV_COOLDOWN_ID)
      .setLabel('فترة التهدئة')
      .setEmoji('⏱️')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId(SLV_VOICE_TOGGLE_ID)
      .setLabel(lvl.voiceXpEnabled ? 'تعطيل XP الصوت' : 'تفعيل XP الصوت')
      .setEmoji('🎙️')
      .setStyle(lvl.voiceXpEnabled ? ButtonStyle.Danger : ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(SLV_VOICE_XP_ID)
      .setLabel('XP الصوت/دقيقة')
      .setEmoji(ICONS.music)
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId(SLV_VOICE_MIN_ID)
      .setLabel('حد الأعضاء')
      .setEmoji('👥')
      .setStyle(ButtonStyle.Secondary),
  );

  return { embeds: [embed], components: [row1, row2, navRow()] };
}

// ─── Interaction handlers ─────────────────────────────────────────────────────

async function handleLevelingButton(interaction) {
  const id = interaction.customId;

  const guildConfig = await getGuildConfig(interaction.guildId);
  const settings    = resolved(guildConfig);

  if (!isGuildManager(interaction.member, guildConfig)) {
    return interaction.reply({
      embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر (Manage Server) لاستخدام هذه الواجهة.')],
      ephemeral: true,
    });
  }

  // ── Toggle master enable ──────────────────────────────────────────────
  if (id === SLV_TOGGLE_ID) {
    const current = guildConfig.leveling?.enabled ?? false;
    guildConfig.leveling.enabled = !current;
    await guildConfig.save();
    invalidateGuildConfig(interaction.guildId);
    const updated = await getGuildConfig(interaction.guildId);
    const view = buildLevelingView(resolved(updated), updated);
    return interaction.update({ embeds: view.embeds, components: view.components });
  }

  // ── Toggle announce ───────────────────────────────────────────────────
  if (id === SLV_ANNOUNCE_TOGGLE_ID) {
    const current = guildConfig.leveling?.announceLevelUp ?? true;
    guildConfig.leveling.announceLevelUp = !current;
    await guildConfig.save();
    invalidateGuildConfig(interaction.guildId);
    const updated = await getGuildConfig(interaction.guildId);
    const view = buildLevelingView(resolved(updated), updated);
    return interaction.update({ embeds: view.embeds, components: view.components });
  }

  // ── Toggle voice XP ───────────────────────────────────────────────────
  if (id === SLV_VOICE_TOGGLE_ID) {
    const current = guildConfig.leveling?.voiceXpEnabled ?? false;
    guildConfig.leveling.voiceXpEnabled = !current;
    await guildConfig.save();
    invalidateGuildConfig(interaction.guildId);
    const updated = await getGuildConfig(interaction.guildId);
    const view = buildLevelingView(resolved(updated), updated);
    return interaction.update({ embeds: view.embeds, components: view.components });
  }

  // ── Modal: announce channel ───────────────────────────────────────────
  if (id === SLV_ANNOUNCE_CHANNEL_ID) {
    const modal = new ModalBuilder()
      .setCustomId(SLV_MODAL_ANNOUNCE_CHANNEL)
      .setTitle('قناة إعلانات الترقية');
    modal.addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('channel_id')
          .setLabel('معرف القناة (Channel ID)')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('أدخل معرف القناة أو اتركه فارغاً للإلغاء')
          .setRequired(false)
          .setValue(guildConfig.leveling?.announceChannelId ?? ''),
      ),
    );
    return interaction.showModal(modal);
  }

  // ── Modal: XP range ───────────────────────────────────────────────────
  if (id === SLV_XP_RANGE_ID) {
    const lvl = guildConfig.leveling ?? {};
    const modal = new ModalBuilder()
      .setCustomId(SLV_MODAL_XP_RANGE)
      .setTitle('نطاق XP لكل رسالة');
    modal.addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('xp_min')
          .setLabel('الحد الأدنى للـ XP')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('مثال: 10')
          .setRequired(true)
          .setValue(String(lvl.xpMin ?? lvl.xpPerMessage ?? 15)),
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('xp_max')
          .setLabel('الحد الأقصى للـ XP')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('مثال: 25')
          .setRequired(true)
          .setValue(String(lvl.xpMax ?? lvl.xpPerMessage ?? 15)),
      ),
    );
    return interaction.showModal(modal);
  }

  // ── Modal: cooldown ───────────────────────────────────────────────────
  if (id === SLV_COOLDOWN_ID) {
    const modal = new ModalBuilder()
      .setCustomId(SLV_MODAL_COOLDOWN)
      .setTitle('فترة التهدئة بين رسائل XP');
    modal.addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('cooldown_seconds')
          .setLabel('المدة بالثواني')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('مثال: 60')
          .setRequired(true)
          .setValue(String(guildConfig.leveling?.cooldownSeconds ?? 60)),
      ),
    );
    return interaction.showModal(modal);
  }

  // ── Modal: voice XP per minute ────────────────────────────────────────
  if (id === SLV_VOICE_XP_ID) {
    const modal = new ModalBuilder()
      .setCustomId(SLV_MODAL_VOICE_XP)
      .setTitle('XP الصوت في الدقيقة');
    modal.addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('voice_xp')
          .setLabel('XP في الدقيقة الواحدة')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('مثال: 10')
          .setRequired(true)
          .setValue(String(guildConfig.leveling?.voiceXpPerMinute ?? 10)),
      ),
    );
    return interaction.showModal(modal);
  }

  // ── Modal: voice min members ──────────────────────────────────────────
  if (id === SLV_VOICE_MIN_ID) {
    const modal = new ModalBuilder()
      .setCustomId(SLV_MODAL_VOICE_MIN)
      .setTitle('الحد الأدنى للأعضاء في الصوت');
    modal.addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('min_members')
          .setLabel('عدد الأعضاء الأدنى (لا يقل عن 1)')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('مثال: 2')
          .setRequired(true)
          .setValue(String(guildConfig.leveling?.voiceMinMembers ?? 2)),
      ),
    );
    return interaction.showModal(modal);
  }
}

async function handleLevelingModal(interaction) {
  const id = interaction.customId;

  const guildConfig = await getGuildConfig(interaction.guildId);
  const settings    = resolved(guildConfig);

  if (!isGuildManager(interaction.member, guildConfig)) {
    return interaction.reply({
      embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر (Manage Server) لاستخدام هذه الواجهة.')],
      ephemeral: true,
    });
  }

  try {
    if (id === SLV_MODAL_ANNOUNCE_CHANNEL) {
      const val = interaction.fields.getTextInputValue('channel_id').trim();
      guildConfig.leveling.announceChannelId = val || null;
    }

    if (id === SLV_MODAL_XP_RANGE) {
      const min = parseInt(interaction.fields.getTextInputValue('xp_min'), 10);
      const max = parseInt(interaction.fields.getTextInputValue('xp_max'), 10);
      if (isNaN(min) || isNaN(max) || min < 1 || max < min) {
        return interaction.reply({
          embeds: [errorEmbed(settings, 'القيم غير صحيحة. تأكد أن الحد الأدنى أقل من الأقصى وأن كليهما موجب.')],
          ephemeral: true,
        });
      }
      guildConfig.leveling.xpMin = min;
      guildConfig.leveling.xpMax = max;
    }

    if (id === SLV_MODAL_COOLDOWN) {
      const secs = parseInt(interaction.fields.getTextInputValue('cooldown_seconds'), 10);
      if (isNaN(secs) || secs < 0) {
        return interaction.reply({
          embeds: [errorEmbed(settings, 'قيمة غير صحيحة. أدخل عدداً صحيحاً موجباً للثواني.')],
          ephemeral: true,
        });
      }
      guildConfig.leveling.cooldownSeconds = secs;
    }

    if (id === SLV_MODAL_VOICE_XP) {
      const xp = parseInt(interaction.fields.getTextInputValue('voice_xp'), 10);
      if (isNaN(xp) || xp < 1) {
        return interaction.reply({
          embeds: [errorEmbed(settings, 'قيمة غير صحيحة. أدخل عدداً موجباً لـ XP في الدقيقة.')],
          ephemeral: true,
        });
      }
      guildConfig.leveling.voiceXpPerMinute = xp;
    }

    if (id === SLV_MODAL_VOICE_MIN) {
      const min = parseInt(interaction.fields.getTextInputValue('min_members'), 10);
      if (isNaN(min) || min < 1) {
        return interaction.reply({
          embeds: [errorEmbed(settings, 'القيمة يجب أن تكون 1 على الأقل.')],
          ephemeral: true,
        });
      }
      guildConfig.leveling.voiceMinMembers = min;
    }

    // TASK 18 — defer immediately after (synchronous) validation passes,
    // before the DB write, matching the economy/moderation/music modal
    // handlers. Previously guildConfig.save() ran before deferUpdate() in
    // every branch above, delaying the ack behind a DB round trip.
    await interaction.deferUpdate();
    await guildConfig.save();
    invalidateGuildConfig(interaction.guildId);
    const updated = await getGuildConfig(interaction.guildId);
    const view = buildLevelingView(resolved(updated), updated);
    return interaction.editReply({ embeds: view.embeds, components: view.components });

  } catch (err) {
    logger.error('[levelingDashboard] Modal save error:', err);
    return (interaction.deferred || interaction.replied ? interaction.followUp : interaction.reply).call(interaction, {
      embeds: [errorEmbed(settings, 'حدث خطأ أثناء حفظ الإعداد. حاول مجدداً.')],
      ephemeral: true,
    });
  }
}

module.exports = {
  buildLevelingView,
  handleLevelingButton,
  handleLevelingModal,
  SLV_TOGGLE_ID,
  SLV_ANNOUNCE_TOGGLE_ID,
  SLV_ANNOUNCE_CHANNEL_ID,
  SLV_XP_RANGE_ID,
  SLV_COOLDOWN_ID,
  SLV_VOICE_TOGGLE_ID,
  SLV_VOICE_XP_ID,
  SLV_VOICE_MIN_ID,
  SLV_MODAL_ANNOUNCE_CHANNEL,
  SLV_MODAL_XP_RANGE,
  SLV_MODAL_COOLDOWN,
  SLV_MODAL_VOICE_XP,
  SLV_MODAL_VOICE_MIN,
};
