'use strict';

/**
 * Task 47 — نظام صفحات UI الموحّد (Unified UI Page System).
 *
 * يحل مشكلتين أساسيتين في الواجهات الحالية:
 *
 *  1. تضخّم الرسالة الواحدة بعدد كبير من الأزرار:
 *     عند وجود قوائم طويلة (فئات تذاكر، سجلات، قوائم أوامر، …) تُقسَّم
 *     إلى صفحات بحجم ثابت مع زرَّي ◀️ السابق / ▶️ التالي.
 *
 *  2. التنقل بين الطبقات (Home → Section → Sub-page):
 *     كل طبقة تعرف سابقتها عبر زر رجوع، وHome يعيد دائمًا للجذر.
 *     الحالة (الطبقة الحالية + رقم الصفحة + البيانات الإضافية) تُخزَّن
 *     في customId على شكل: `nyxo_page:<namespace>:<layer>:<page>:<extra>`
 *     بدون قاعدة بيانات، بدون session، بدون أي معلومات خاصة.
 *
 * الاستخدام:
 *
 *   // بناء أزرار التنقل لأي قائمة مُقسَّمة:
 *   const row = buildPageNav('cases', targetId, page, totalPages);
 *
 *   // بناء أزرار Home/Back/Next/Close لطبقة داخل dashboard:
 *   const row = buildLayerNav({
 *     namespace : 'admin',
 *     homeId    : 'admin_home',
 *     backId    : 'admin_back',
 *     closeId   : 'admin_close',
 *     hasNext   : false,
 *   });
 *
 *   // فك customId زر الصفحة وقراءة الأجزاء:
 *   const { namespace, layer, page, extra } = parsePageId(interaction.customId);
 *
 * المتطلبات (من مواصفة المهمة 47):
 *   ✅ Home    — يعيد دائمًا إلى الجذر
 *   ✅ Back    — يعيد إلى الطبقة السابقة
 *   ✅ Next    — عند الحاجة فقط
 *   ✅ Close   — موجود دائمًا
 *   ✅ حفظ حالة الصفحة في customId
 *   ✅ منع تضخم رسالة واحدة بعدد كبير من الأزرار
 */

const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { ICONS, COLORS } = require('./designSystem');
const { EmbedBuilder } = require('discord.js');

// ─── ثوابت ──────────────────────────────────────────────────────────────────
/** أقصى عدد عناصر في صفحة واحدة عند تقسيم القوائم. */
const DEFAULT_PAGE_SIZE = 10;

/** أقصى عدد أزرار في صف واحد (حد Discord). */
const MAX_BUTTONS_PER_ROW = 5;

/**
 * البادئة الثابتة لـ customId أزرار الصفحات العامة.
 * الشكل الكامل: `nyxo_page:<namespace>:<layer>:<page>:<extra>`
 * - namespace : اسم النظام (cases, modhistory, …) — لا يحتوي ":"
 * - layer     : رقم الطبقة الحالية (0 = Home, 1 = Section, …)
 * - page      : رقم الصفحة (1-indexed)
 * - extra     : بيانات إضافية مُشفَّرة بـ "~" بدل ":"
 */
const PAGE_PREFIX = 'nyxo_page';

// ─── بناء customId ───────────────────────────────────────────────────────────
/**
 * يبني customId موحد لزر صفحة.
 * @param {string} namespace - اسم النظام (e.g. 'cases', 'modhistory')
 * @param {number} page      - رقم الصفحة (1-indexed)
 * @param {number} layer     - عمق الطبقة (0 = root/home)
 * @param {string} extra     - بيانات إضافية (يُستبدل ":" بـ "~" تلقائيًا)
 * @returns {string}
 */
function buildPageId(namespace, page, layer = 0, extra = '') {
  const safeExtra = String(extra).replace(/:/g, '~');
  return `${PAGE_PREFIX}:${namespace}:${layer}:${page}:${safeExtra}`;
}

/**
 * يفكّك customId زر صفحة إلى أجزائه.
 * @param {string} customId
 * @returns {{ valid: boolean, namespace: string, layer: number, page: number, extra: string }}
 */
function parsePageId(customId) {
  const parts = customId.split(':');
  if (parts[0] !== PAGE_PREFIX || parts.length < 5) {
    return { valid: false, namespace: '', layer: 0, page: 1, extra: '' };
  }
  const [, namespace, layerStr, pageStr, ...extraParts] = parts;
  return {
    valid: true,
    namespace,
    layer: parseInt(layerStr, 10) || 0,
    page: Math.max(parseInt(pageStr, 10) || 1, 1),
    extra: extraParts.join(':').replace(/~/g, ':'),
  };
}

// ─── تقسيم القوائم ───────────────────────────────────────────────────────────
/**
 * يقسّم مصفوفة إلى صفحات بحجم ثابت.
 * @template T
 * @param {T[]} items
 * @param {number} pageSize
 * @param {number} page - 1-indexed
 * @returns {{ items: T[], page: number, totalPages: number, hasNext: boolean, hasPrev: boolean }}
 */
function paginate(items, page = 1, pageSize = DEFAULT_PAGE_SIZE) {
  const totalPages = Math.max(1, Math.ceil(items.length / pageSize));
  const safePage = Math.min(Math.max(page, 1), totalPages);
  const start = (safePage - 1) * pageSize;
  return {
    items: items.slice(start, start + pageSize),
    page: safePage,
    totalPages,
    hasNext: safePage < totalPages,
    hasPrev: safePage > 1,
  };
}

// ─── أزرار التنقل بين الصفحات ────────────────────────────────────────────────
/**
 * يبني صفًّا واحدًا يحتوي أزرار ◀️ / ▶️ لقائمة مُقسَّمة.
 * يضيف Home وClose تلقائيًا إذا مُرِّرت customId-اتهما.
 *
 * @param {object} opts
 * @param {string}   opts.namespace  - اسم النظام
 * @param {number}   opts.page       - الصفحة الحالية
 * @param {number}   opts.totalPages - إجمالي الصفحات
 * @param {number}   [opts.layer]    - عمق الطبقة
 * @param {string}   [opts.extra]    - بيانات إضافية
 * @param {string}   [opts.homeId]   - customId زر Home (يظهر إن مُرِّر)
 * @param {string}   [opts.closeId]  - customId زر Close (يظهر إن مُرِّر)
 * @returns {ActionRowBuilder}
 */
function buildPageRow(opts) {
  const { namespace, page, totalPages, layer = 0, extra = '', homeId, closeId } = opts;
  const buttons = [];

  // زر السابق
  const prevId = buildPageId(namespace, page - 1, layer, extra);
  buttons.push(
    new ButtonBuilder()
      .setCustomId(prevId)
      .setEmoji(ICONS.back)
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(page <= 1)
  );

  // مؤشر الصفحة (disabled - للعرض فقط)
  buttons.push(
    new ButtonBuilder()
      .setCustomId(`${PAGE_PREFIX}_indicator:${namespace}`)
      .setLabel(`${page} / ${totalPages}`)
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(true)
  );

  // زر التالي
  const nextId = buildPageId(namespace, page + 1, layer, extra);
  buttons.push(
    new ButtonBuilder()
      .setCustomId(nextId)
      .setEmoji('▶️')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(page >= totalPages)
  );

  // Home (اختياري)
  if (homeId) {
    buttons.push(
      new ButtonBuilder()
        .setCustomId(homeId)
        .setLabel('الرئيسية')
        .setEmoji(ICONS.home)
        .setStyle(ButtonStyle.Secondary)
    );
  }

  // Close (اختياري)
  if (closeId) {
    buttons.push(
      new ButtonBuilder()
        .setCustomId(closeId)
        .setLabel('إغلاق')
        .setEmoji(ICONS.close)
        .setStyle(ButtonStyle.Danger)
    );
  }

  // Discord يسمح بـ 5 أزرار كحد أقصى في صف واحد
  return new ActionRowBuilder().addComponents(buttons.slice(0, MAX_BUTTONS_PER_ROW));
}

// ─── أزرار التنقل بين الطبقات ────────────────────────────────────────────────
/**
 * يبني صفّ أزرار Home / Back / [Next] / Close لطبقة داخل dashboard.
 * Close دائمًا موجود. Back يختفي في الطبقة 0 (لا يوجد ما قبلها).
 *
 * @param {object} opts
 * @param {string}  opts.homeId    - customId زر Home
 * @param {string}  opts.closeId   - customId زر Close
 * @param {string}  [opts.backId]  - customId زر Back (يُخفى في الجذر)
 * @param {string}  [opts.nextId]  - customId زر Next (يظهر فقط عند الحاجة)
 * @param {boolean} [opts.isRoot]  - هل هذه الطبقة 0 (Home)؟
 * @param {string}  [opts.nextLabel] - تسمية زر Next
 * @returns {ActionRowBuilder}
 */
function buildLayerNav(opts) {
  const { homeId, closeId, backId, nextId, isRoot = false, nextLabel } = opts;
  const buttons = [];

  // Back — يختفي في الجذر لأنه لا يوجد ما قبله
  if (backId && !isRoot) {
    buttons.push(
      new ButtonBuilder()
        .setCustomId(backId)
        .setLabel('رجوع / Back')
        .setEmoji(ICONS.back)
        .setStyle(ButtonStyle.Secondary)
    );
  }

  // Home — دائمًا موجود (حتى في الجذر، يعيد تحميله)
  if (homeId) {
    buttons.push(
      new ButtonBuilder()
        .setCustomId(homeId)
        .setLabel('الرئيسية / Home')
        .setEmoji(ICONS.home)
        .setStyle(ButtonStyle.Secondary)
    );
  }

  // Next — عند الحاجة فقط
  if (nextId) {
    buttons.push(
      new ButtonBuilder()
        .setCustomId(nextId)
        .setLabel(nextLabel ?? 'التالي / Next')
        .setEmoji('▶️')
        .setStyle(ButtonStyle.Primary)
    );
  }

  // Close — دائمًا موجود ودائمًا آخر زر
  buttons.push(
    new ButtonBuilder()
      .setCustomId(closeId)
      .setLabel('إغلاق / Close')
      .setEmoji(ICONS.close)
      .setStyle(ButtonStyle.Danger)
  );

  return new ActionRowBuilder().addComponents(buttons.slice(0, MAX_BUTTONS_PER_ROW));
}

// ─── embed مؤشر الصفحة ────────────────────────────────────────────────────────
/**
 * يضيف سطر Footer يُظهر رقم الصفحة الحالية على أي EmbedBuilder.
 * مساعد اختياري — يمكن تجاهله واستخدام setFooter مباشرة.
 *
 * @param {EmbedBuilder} embed
 * @param {number} page
 * @param {number} totalPages
 * @param {string} [baseFooter]
 * @returns {EmbedBuilder}
 */
function withPageFooter(embed, page, totalPages, baseFooter = '') {
  const pageStr = totalPages > 1 ? `📄 صفحة ${page} من ${totalPages}` : '';
  const sep = pageStr && baseFooter ? ' • ' : '';
  return embed.setFooter({ text: `${pageStr}${sep}${baseFooter}` }).setTimestamp();
}

// ─── مساعد: رسالة "لا توجد عناصر" ───────────────────────────────────────────
/**
 * يبني embed بسيط يُظهر رسالة "لا توجد عناصر" موحّدة.
 * @param {object} settings
 * @param {string} [messageAr]
 * @returns {EmbedBuilder}
 */
function emptyPageEmbed(settings, messageAr = 'لا توجد عناصر لعرضها.') {
  return new EmbedBuilder()
    .setColor(COLORS.neutral)
    .setDescription(`${ICONS.info} ${messageAr}`)
    .setFooter({ text: settings.footer })
    .setTimestamp();
}

// ─── مساعد: التحقق من رقم الصفحة ────────────────────────────────────────────
/**
 * يُرجع رقم صفحة صالح (1 ≤ page ≤ totalPages).
 * @param {number|string} raw
 * @param {number} totalPages
 * @returns {number}
 */
function clampPage(raw, totalPages) {
  const n = parseInt(raw, 10);
  return Math.min(Math.max(isNaN(n) ? 1 : n, 1), Math.max(totalPages, 1));
}

// ─── Handler مركزي لزر nyxo_page ─────────────────────────────────────────────
/**
 * خريطة الـ handlers المسجَّلة لكل namespace.
 * كل handler يأخذ { interaction, namespace, layer, page, extra }
 * ويُنفِّذ interaction.update(...) بنفسه.
 *
 * @type {Map<string, Function>}
 */
const _pageHandlers = new Map();

/**
 * يسجّل handler لنظام معين بحيث يُستدعى عند ضغط أزرار nyxo_page:<namespace>.
 * @param {string}   namespace
 * @param {Function} handler - async ({ interaction, namespace, layer, page, extra }) => void
 */
function registerPageHandler(namespace, handler) {
  _pageHandlers.set(namespace, handler);
}

/**
 * Entry point مركزي لمعالجة ضغط أزرار nyxo_page.
 * يُستدعى من components/buttons.js تحت مفتاح `nyxo_page`.
 *
 * @param {import('discord.js').ButtonInteraction} interaction
 */
async function handlePageButton(interaction) {
  const parsed = parsePageId(interaction.customId);
  if (!parsed.valid) {
    return interaction.reply({ content: '⚠️ زر صفحة غير صالح.', ephemeral: true });
  }

  const handler = _pageHandlers.get(parsed.namespace);
  if (!handler) {
    // namespace غير مسجَّل — رد آمن بدل crash
    return interaction.reply({
      content: `⚠️ لا يوجد handler مسجَّل لنظام \`${parsed.namespace}\`.`,
      ephemeral: true,
    });
  }

  await handler({
    interaction,
    namespace: parsed.namespace,
    layer: parsed.layer,
    page: parsed.page,
    extra: parsed.extra,
  });
}

// ─── صادرات ─────────────────────────────────────────────────────────────────
module.exports = {
  // ثوابت
  DEFAULT_PAGE_SIZE,
  PAGE_PREFIX,

  // customId
  buildPageId,
  parsePageId,

  // تقسيم القوائم
  paginate,

  // بناء الأزرار
  buildPageRow,
  buildLayerNav,

  // مساعدات embeds
  withPageFooter,
  emptyPageEmbed,
  clampPage,

  // نظام handlers
  registerPageHandler,
  handlePageButton,
};
