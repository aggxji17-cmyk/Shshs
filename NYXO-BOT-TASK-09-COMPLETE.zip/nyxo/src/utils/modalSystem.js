'use strict';

/**
 * Task 48 — نظام Modal الموحّد (Unified Modal System).
 *
 * يوحّد بناء جميع نوافذ الإدخال (Modals) في البوت في مكان واحد
 * بدلاً من تكرار نفس كود ModalBuilder/TextInputBuilder في كل ملف.
 *
 * الأنواع المدعومة:
 *   ✅ Text Input      — نص قصير أو طويل مع حد أحرف قابل للضبط
 *   ✅ Channel Input   — معرّف قناة Discord مع Validation
 *   ✅ Role Input      — معرّف رتبة Discord مع Validation
 *   ✅ Number Input    — رقم صحيح ضمن نطاق min/max مع Validation
 *   ✅ Duration Input  — مدة زمنية (دقائق/ساعات/أيام) مع Validation
 *   ✅ Multi-field     — نافذة تحتوي حقولاً متعددة مخصصة
 *
 * Validation مركزي:
 *   validateChannelId(value, guild)   → { valid, channelId, error }
 *   validateRoleId(value, guild)      → { valid, roleId, error }
 *   validateNumber(value, min, max)   → { valid, number, error }
 *   validateDuration(value)           → { valid, minutes, error }
 *
 * الاستخدام في buttons.js:
 *   const { buildTextModal, buildChannelModal, buildRoleModal,
 *           buildNumberModal, buildDurationModal } = require('../utils/modalSystem');
 *
 *   await interaction.showModal(buildChannelModal({
 *     customId : 'tds_modal_logchannel',
 *     title    : 'قناة السجلات',
 *     label    : 'معرّف القناة',
 *     current  : guildConfig.tickets.logChannelId,
 *   }));
 *
 * الاستخدام في modals.js:
 *   const { validateChannelId, validateNumber } = require('../utils/modalSystem');
 *
 *   const { valid, channelId, error } = validateChannelId(
 *     interaction.fields.getTextInputValue('value'),
 *     interaction.guild
 *   );
 *   if (!valid) return interaction.reply({ embeds: [errorEmbed(settings, error)], ephemeral: true });
 *
 * متطلبات المهمة 48:
 *   ✅ Text Input
 *   ✅ Channel Selection (via ID — Discord لا يدعم Channel picker في Modals)
 *   ✅ Role Selection (via ID — Discord لا يدعم Role picker في Modals)
 *   ✅ Number Input
 *   ✅ Duration Input
 *   ✅ Validation
 *   ✅ رسائل خطأ واضحة بالعربية
 */

const {
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
} = require('discord.js');

// ─── ثوابت ──────────────────────────────────────────────────────────────────

/** أقصى عدد حقول في Modal واحد (حد Discord). */
const MAX_MODAL_FIELDS = 5;

/** أقصى طول لـ customId في Discord. */
const MAX_CUSTOM_ID_LEN = 100;

/** أقصى طول لعنوان Modal في Discord. */
const MAX_TITLE_LEN = 45;

// ─── أنواع الحقول ──────────────────────────────────────────────────────────
/**
 * @typedef {object} FieldDef
 * @property {string}          id          - customId الحقل الداخلي
 * @property {string}          label       - التسمية المعروضة للمستخدم
 * @property {TextInputStyle}  [style]     - Short أو Paragraph (افتراضي: Short)
 * @property {string}          [placeholder]
 * @property {string}          [value]     - القيمة الافتراضية
 * @property {boolean}         [required]  - افتراضي: false
 * @property {number}          [minLength]
 * @property {number}          [maxLength]
 */

// ─── مساعد داخلي: بناء حقل نص ───────────────────────────────────────────────
/**
 * @param {FieldDef} def
 * @returns {TextInputBuilder}
 */
function _makeField(def) {
  const input = new TextInputBuilder()
    .setCustomId(def.id)
    .setLabel(def.label.slice(0, 45))
    .setStyle(def.style ?? TextInputStyle.Short)
    .setRequired(def.required ?? false);

  if (def.placeholder) input.setPlaceholder(def.placeholder.slice(0, 100));
  if (def.minLength != null) input.setMinLength(def.minLength);
  if (def.maxLength != null) input.setMaxLength(def.maxLength);
  if (def.value != null && def.value !== '') {
    // Discord ترفض setValue بقيمة أطول من maxLength
    const cap = def.maxLength ?? 4000;
    input.setValue(String(def.value).slice(0, cap));
  }

  return input;
}

// ─── مساعد داخلي: بناء modal من مصفوفة حقول ─────────────────────────────────
/**
 * @param {string}    customId
 * @param {string}    title
 * @param {FieldDef[]} fields
 * @returns {ModalBuilder}
 */
function _buildModal(customId, title, fields) {
  if (!customId || customId.length > MAX_CUSTOM_ID_LEN) {
    throw new Error(`[modalSystem] customId غير صالح: "${customId}"`);
  }
  const modal = new ModalBuilder()
    .setCustomId(customId)
    .setTitle(title.slice(0, MAX_TITLE_LEN));

  const limited = fields.slice(0, MAX_MODAL_FIELDS);
  for (const def of limited) {
    modal.addComponents(new ActionRowBuilder().addComponents(_makeField(def)));
  }
  return modal;
}

// ════════════════════════════════════════════════════════════════════════════
//  بناة Modals (Builders)
// ════════════════════════════════════════════════════════════════════════════

/**
 * نافذة نص حر (قصير أو طويل).
 *
 * @param {object} opts
 * @param {string}  opts.customId
 * @param {string}  opts.title
 * @param {string}  opts.label
 * @param {string}  [opts.placeholder]
 * @param {string}  [opts.value]        - القيمة الحالية للتعديل
 * @param {boolean} [opts.long]         - Paragraph style إذا true
 * @param {boolean} [opts.required]     - افتراضي: false
 * @param {number}  [opts.maxLength]    - افتراضي: 1000
 * @returns {ModalBuilder}
 */
function buildTextModal(opts) {
  return _buildModal(opts.customId, opts.title, [
    {
      id          : 'value',
      label       : opts.label,
      style       : opts.long ? TextInputStyle.Paragraph : TextInputStyle.Short,
      placeholder : opts.placeholder,
      value       : opts.value,
      required    : opts.required ?? false,
      maxLength   : opts.maxLength ?? (opts.long ? 1000 : 200),
    },
  ]);
}

/**
 * نافذة إدخال معرّف قناة Discord.
 * المستخدم يلصق Channel ID أو يترك الحقل فارغاً للحذف.
 *
 * @param {object} opts
 * @param {string}  opts.customId
 * @param {string}  opts.title
 * @param {string}  [opts.label]
 * @param {string}  [opts.current]  - القيمة الحالية
 * @returns {ModalBuilder}
 */
function buildChannelModal(opts) {
  return _buildModal(opts.customId, opts.title, [
    {
      id          : 'value',
      label       : opts.label ?? 'معرّف القناة (Channel ID)',
      placeholder : 'الصق معرّف القناة أو اتركه فارغاً للحذف',
      value       : opts.current ?? '',
      required    : false,
      maxLength   : 20,
    },
  ]);
}

/**
 * نافذة إدخال معرّف رتبة Discord.
 * المستخدم يلصق Role ID أو يترك الحقل فارغاً للحذف.
 *
 * @param {object} opts
 * @param {string}  opts.customId
 * @param {string}  opts.title
 * @param {string}  [opts.label]
 * @param {string}  [opts.current]
 * @returns {ModalBuilder}
 */
function buildRoleModal(opts) {
  return _buildModal(opts.customId, opts.title, [
    {
      id          : 'value',
      label       : opts.label ?? 'معرّف الرتبة (Role ID)',
      placeholder : 'الصق معرّف الرتبة أو اتركه فارغاً للحذف',
      value       : opts.current ?? '',
      required    : false,
      maxLength   : 20,
    },
  ]);
}

/**
 * نافذة إدخال رقم صحيح ضمن نطاق.
 *
 * @param {object} opts
 * @param {string}  opts.customId
 * @param {string}  opts.title
 * @param {string}  [opts.label]
 * @param {string}  [opts.placeholder]
 * @param {number}  [opts.current]
 * @param {number}  [opts.min]        - افتراضي: 0
 * @param {number}  [opts.max]        - افتراضي: 99999
 * @param {boolean} [opts.required]   - افتراضي: false
 * @returns {ModalBuilder}
 */
function buildNumberModal(opts) {
  const min = opts.min ?? 0;
  const max = opts.max ?? 99999;
  return _buildModal(opts.customId, opts.title, [
    {
      id          : 'value',
      label       : opts.label ?? `رقم (${min}–${max})`,
      placeholder : opts.placeholder ?? `أدخل رقماً بين ${min} و${max}`,
      value       : opts.current != null ? String(opts.current) : undefined,
      required    : opts.required ?? false,
      maxLength   : 6,
    },
  ]);
}

/**
 * نافذة إدخال مدة زمنية.
 * الصيغ المقبولة: "30" (دقيقة)، "2h" (ساعتان)، "1d" (يوم)، "0" (تعطيل).
 *
 * @param {object} opts
 * @param {string}  opts.customId
 * @param {string}  opts.title
 * @param {string}  [opts.label]
 * @param {number}  [opts.currentMinutes]  - القيمة الحالية بالدقائق
 * @param {number}  [opts.maxDays]         - الحد الأقصى بالأيام (افتراضي: 30)
 * @returns {ModalBuilder}
 */
function buildDurationModal(opts) {
  const maxDays = opts.maxDays ?? 30;
  let currentDisplay = '';
  if (opts.currentMinutes != null && opts.currentMinutes > 0) {
    if (opts.currentMinutes % 1440 === 0) {
      currentDisplay = `${opts.currentMinutes / 1440}d`;
    } else if (opts.currentMinutes % 60 === 0) {
      currentDisplay = `${opts.currentMinutes / 60}h`;
    } else {
      currentDisplay = `${opts.currentMinutes}`;
    }
  }

  return _buildModal(opts.customId, opts.title, [
    {
      id          : 'value',
      label       : opts.label ?? 'المدة الزمنية',
      placeholder : `مثال: 30 (دقيقة)  2h (ساعتان)  1d (يوم) — 0 للتعطيل — أقصى ${maxDays}d`,
      value       : currentDisplay || undefined,
      required    : false,
      maxLength   : 8,
    },
  ]);
}

/**
 * نافذة متعددة الحقول (Multi-field).
 * تُستخدم للحالات الخاصة مثل إنشاء فئة تذكرة أو إعداد Embed.
 *
 * @param {object}    opts
 * @param {string}    opts.customId
 * @param {string}    opts.title
 * @param {FieldDef[]} opts.fields  - بحد أقصى 5 حقول
 * @returns {ModalBuilder}
 */
function buildMultiModal(opts) {
  return _buildModal(opts.customId, opts.title, opts.fields);
}

// ════════════════════════════════════════════════════════════════════════════
//  Validation
// ════════════════════════════════════════════════════════════════════════════

/**
 * @typedef {object} ValidationResult
 * @property {boolean} valid
 * @property {string}  [error]   - رسالة الخطأ بالعربية (موجودة إذا valid === false)
 */

// ─── Channel ID ─────────────────────────────────────────────────────────────
/** @type {RegExp} Discord Snowflake: 17-19 digits */
const SNOWFLAKE_RE = /^\d{17,19}$/;

/**
 * يتحقق من Channel ID ويعيد القناة إذا كانت صالحة.
 *
 * @param {string} raw    - القيمة كما أدخلها المستخدم
 * @param {import('discord.js').Guild} guild
 * @param {object} [opts]
 * @param {string[]} [opts.allowedTypes]  - ChannelType المسموح بها (افتراضي: كل النصية)
 * @returns {{ valid: boolean, channelId?: string, channel?: import('discord.js').GuildChannel, error?: string }}
 */
function validateChannelId(raw, guild, opts = {}) {
  const value = String(raw ?? '').trim().replace(/[<#>]/g, '');

  // قيمة فارغة = حذف (مقبول دائماً)
  if (!value) {
    return { valid: true, channelId: null, channel: null };
  }

  if (!SNOWFLAKE_RE.test(value)) {
    return {
      valid: false,
      error: `❌ معرّف القناة غير صالح.\nيجب أن يكون رقماً من 17 إلى 19 خانة.\nمثال: \`1234567890123456789\``,
    };
  }

  const channel = guild.channels.cache.get(value);
  if (!channel) {
    return {
      valid: false,
      error: `❌ لم يتم العثور على القناة \`${value}\` في هذا السيرفر.\nتأكد أن البوت لديه صلاحية رؤيتها.`,
    };
  }

  if (opts.allowedTypes && opts.allowedTypes.length > 0) {
    if (!opts.allowedTypes.includes(channel.type)) {
      return {
        valid: false,
        error: `❌ هذه القناة غير مدعومة هنا.\nالأنواع المسموح بها: ${opts.allowedTypes.join(', ')}`,
      };
    }
  }

  return { valid: true, channelId: channel.id, channel };
}

// ─── Role ID ─────────────────────────────────────────────────────────────────
/**
 * يتحقق من Role ID ويعيد الرتبة إذا كانت صالحة.
 *
 * @param {string} raw
 * @param {import('discord.js').Guild} guild
 * @returns {{ valid: boolean, roleId?: string, role?: import('discord.js').Role, error?: string }}
 */
function validateRoleId(raw, guild) {
  const value = String(raw ?? '').trim().replace(/[<@&>]/g, '');

  // قيمة فارغة = حذف
  if (!value) {
    return { valid: true, roleId: null, role: null };
  }

  if (!SNOWFLAKE_RE.test(value)) {
    return {
      valid: false,
      error: `❌ معرّف الرتبة غير صالح.\nيجب أن يكون رقماً من 17 إلى 19 خانة.\nمثال: \`1234567890123456789\``,
    };
  }

  const role = guild.roles.cache.get(value);
  if (!role) {
    return {
      valid: false,
      error: `❌ لم يتم العثور على الرتبة \`${value}\` في هذا السيرفر.`,
    };
  }

  // الرتبة @everyone لا يمكن اختيارها كإعداد دعم
  if (role.id === guild.id) {
    return {
      valid: false,
      error: `❌ لا يمكن استخدام رتبة \`@everyone\` هنا.`,
    };
  }

  return { valid: true, roleId: role.id, role };
}

// ─── Number ──────────────────────────────────────────────────────────────────
/**
 * يتحقق من إدخال رقمي.
 *
 * @param {string} raw
 * @param {object} [opts]
 * @param {number} [opts.min]      - افتراضي: 0
 * @param {number} [opts.max]      - افتراضي: Infinity
 * @param {boolean}[opts.integer]  - إذا true، يُرفض الكسر (افتراضي: true)
 * @returns {{ valid: boolean, number?: number, error?: string }}
 */
function validateNumber(raw, opts = {}) {
  const { min = 0, max = Infinity, integer = true } = opts;
  const value = String(raw ?? '').trim();

  // قيمة فارغة مقبولة إذا الحقل غير إلزامي
  if (!value) {
    return { valid: true, number: null };
  }

  const n = Number(value);
  if (isNaN(n)) {
    return {
      valid: false,
      error: `❌ القيمة المُدخلة ليست رقماً صالحاً.\nأدخل رقماً مثل: \`10\``,
    };
  }

  if (integer && !Number.isInteger(n)) {
    return {
      valid: false,
      error: `❌ يجب إدخال رقم صحيح بدون كسور.`,
    };
  }

  if (n < min) {
    return {
      valid: false,
      error: `❌ أقل قيمة مسموح بها هي **${min}**.`,
    };
  }

  if (n > max) {
    return {
      valid: false,
      error: `❌ أكبر قيمة مسموح بها هي **${max}**.`,
    };
  }

  return { valid: true, number: n };
}

// ─── Duration ────────────────────────────────────────────────────────────────
/**
 * يُحوّل نص مدة زمنية إلى دقائق.
 *
 * الصيغ المدعومة:
 *   "0"          → 0 (تعطيل)
 *   "30"         → 30 دقيقة
 *   "2h"         → 120 دقيقة
 *   "1d"         → 1440 دقيقة
 *   ""           → null (لم يُدخل شيء)
 *
 * @param {string} raw
 * @param {object} [opts]
 * @param {number} [opts.maxDays]  - الحد الأقصى بالأيام (افتراضي: 30)
 * @param {number} [opts.minMinutes] - الحد الأدنى بالدقائق بخلاف الصفر (افتراضي: 1)
 * @returns {{ valid: boolean, minutes?: number|null, error?: string }}
 */
function validateDuration(raw, opts = {}) {
  const { maxDays = 30, minMinutes = 1 } = opts;
  const value = String(raw ?? '').trim().toLowerCase();

  // فارغ = لا تغيير
  if (!value) {
    return { valid: true, minutes: null };
  }

  // صفر = تعطيل
  if (value === '0') {
    return { valid: true, minutes: 0 };
  }

  // دقائق/ساعات/أيام
  const match = /^(\d+)(m|h|d)?$/.exec(value);
  if (!match) {
    return {
      valid: false,
      error: [
        `❌ صيغة المدة غير صحيحة.`,
        ``,
        `الصيغ المقبولة:`,
        `• \`30\` أو \`30m\` — 30 دقيقة`,
        `• \`2h\` — ساعتان`,
        `• \`1d\` — يوم واحد`,
        `• \`0\` — تعطيل`,
      ].join('\n'),
    };
  }

  const amount = parseInt(match[1], 10);
  const unit = match[2] ?? 'm';
  let minutes;

  switch (unit) {
    case 'm': minutes = amount; break;
    case 'h': minutes = amount * 60; break;
    case 'd': minutes = amount * 1440; break;
    default:  minutes = amount;
  }

  const maxMinutes = maxDays * 1440;

  if (minutes < minMinutes) {
    return {
      valid: false,
      error: `❌ المدة الزمنية أقل من الحد الأدنى المسموح (${minMinutes} دقيقة).`,
    };
  }

  if (minutes > maxMinutes) {
    return {
      valid: false,
      error: `❌ المدة الزمنية تتجاوز الحد الأقصى المسموح به (${maxDays} يوم / ${maxMinutes} دقيقة).`,
    };
  }

  return { valid: true, minutes };
}

// ─── Hex Color ───────────────────────────────────────────────────────────────
const HEX_RE = /^#?([0-9a-fA-F]{6})$/;

/**
 * يتحقق من لون Hex ويُرجعه بصيغة #RRGGBB.
 *
 * @param {string} raw
 * @returns {{ valid: boolean, hex?: string, error?: string }}
 */
function validateHexColor(raw) {
  const value = String(raw ?? '').trim();
  if (!value) return { valid: true, hex: null };

  const m = HEX_RE.exec(value);
  if (!m) {
    return {
      valid: false,
      error: `❌ اللون غير صالح. أدخل كود Hex مثل: \`#5865F2\` أو \`5865F2\``,
    };
  }

  return { valid: true, hex: `#${m[1].toUpperCase()}` };
}

// ─── URL ─────────────────────────────────────────────────────────────────────
/**
 * يتحقق من URL (يقبل http / https فقط).
 *
 * @param {string} raw
 * @param {boolean} [required]
 * @returns {{ valid: boolean, url?: string, error?: string }}
 */
function validateUrl(raw, required = false) {
  const value = String(raw ?? '').trim();

  if (!value) {
    if (required) return { valid: false, error: `❌ يجب إدخال رابط URL.` };
    return { valid: true, url: null };
  }

  try {
    const u = new URL(value);
    if (!['http:', 'https:'].includes(u.protocol)) {
      return { valid: false, error: `❌ الرابط يجب أن يبدأ بـ \`https://\` أو \`http://\`` };
    }
    return { valid: true, url: u.toString() };
  } catch {
    return { valid: false, error: `❌ الرابط المُدخل غير صالح. مثال: \`https://example.com\`` };
  }
}

// ─── مساعد: استخراج قيمة حقل بأمان ─────────────────────────────────────────
/**
 * يستخرج قيمة حقل من ModalSubmitInteraction بأمان.
 * يُرجع سلسلة فارغة إذا الحقل غير موجود بدلاً من throw.
 *
 * @param {import('discord.js').ModalSubmitInteraction} interaction
 * @param {string} fieldId
 * @returns {string}
 */
function getField(interaction, fieldId) {
  try {
    return interaction.fields.getTextInputValue(fieldId) ?? '';
  } catch {
    return '';
  }
}

// ─── مساعد: تحويل دقائق إلى نص قابل للقراءة ─────────────────────────────────
/**
 * يُحوّل عدد دقائق إلى نص بالعربية.
 *
 * @param {number} minutes
 * @returns {string}
 */
function minutesToDisplay(minutes) {
  if (!minutes || minutes === 0) return 'معطّل';
  if (minutes < 60) return `${minutes} دقيقة`;
  if (minutes < 1440) {
    const h = Math.floor(minutes / 60);
    const m = minutes % 60;
    return m > 0 ? `${h} ساعة و${m} دقيقة` : `${h} ساعة`;
  }
  const d = Math.floor(minutes / 1440);
  const rem = minutes % 1440;
  if (rem === 0) return `${d} يوم`;
  const h = Math.floor(rem / 60);
  return `${d} يوم و${h} ساعة`;
}

// ════════════════════════════════════════════════════════════════════════════
//  صادرات
// ════════════════════════════════════════════════════════════════════════════
module.exports = {
  // ─── بناة Modals ─────────────────────────────────────
  /** نص قصير أو طويل */
  buildTextModal,
  /** معرّف قناة Discord */
  buildChannelModal,
  /** معرّف رتبة Discord */
  buildRoleModal,
  /** رقم صحيح ضمن نطاق */
  buildNumberModal,
  /** مدة زمنية (دقائق/ساعات/أيام) */
  buildDurationModal,
  /** نافذة متعددة الحقول المخصصة */
  buildMultiModal,

  // ─── Validation ──────────────────────────────────────
  /** التحقق من Channel ID مع رسالة خطأ واضحة */
  validateChannelId,
  /** التحقق من Role ID مع رسالة خطأ واضحة */
  validateRoleId,
  /** التحقق من رقم ضمن نطاق */
  validateNumber,
  /** تحويل نص مدة زمنية إلى دقائق مع Validation */
  validateDuration,
  /** التحقق من لون Hex */
  validateHexColor,
  /** التحقق من URL */
  validateUrl,

  // ─── مساعدات ─────────────────────────────────────────
  /** استخراج قيمة حقل بأمان بدون throw */
  getField,
  /** تحويل دقائق إلى نص عربي مقروء */
  minutesToDisplay,
};
