const GuildConfig = require('../database/models/GuildConfig');
const { config } = require('../config/config');

/**
 * TASK 27 — Performance improvements to guild config cache:
 *
 * 1. TTL raised 30 s → 60 s. Guild configs change rarely (admin sets a
 *    setting, invalidates manually). 30 s was so short that high-traffic
 *    servers hit MongoDB on almost every command burst. 60 s still keeps
 *    the data fresh enough for interactive settings changes to show up
 *    within one minute while halving the DB read rate.
 *
 * 2. In-flight deduplication (stampede guard): if two commands fire
 *    concurrently for the same guild and both miss the cache, the old
 *    code issued two parallel findOne() calls. Now the first miss stores
 *    a Promise in `inFlight`; every subsequent miss for the same guildId
 *    awaits that same Promise instead of creating a new DB round-trip.
 *
 * 3. LRU eviction: the previous strategy evicted the insertion-order
 *    oldest entry. Map iteration order in JS reflects insertion order,
 *    so re-inserting on every cache hit (delete + re-set) correctly
 *    makes the LRU entry the first key, matching true LRU behaviour.
 *
 * 4. Sweep interval raised to match TTL (60 s, was 30 s). The sweep
 *    only deletes entries older than TTL, so running it more often than
 *    TTL is always wasted work.
 */

const CACHE_TTL_MS = 60_000;
const MAX_CACHE_SIZE = 2_000;

// guildId -> { value: doc, at: timestampMs }
const cache = new Map();
// guildId -> Promise<doc>  — in-flight DB reads (stampede guard)
const inFlight = new Map();

/**
 * Fetches (and lightly caches) a guild's configuration document, creating
 * one with defaults if it does not exist yet. Also merges in bot-wide
 * .env defaults for fields the guild has not overridden.
 */
async function getGuildConfig(guildId) {
  const now = Date.now();
  const cached = cache.get(guildId);
  if (cached && now - cached.at < CACHE_TTL_MS) {
    // Bump to MRU position so LRU eviction stays accurate
    cache.delete(guildId);
    cache.set(guildId, cached);
    return cached.value;
  }

  // Stampede guard — reuse an in-flight read for the same guildId
  if (inFlight.has(guildId)) {
    return inFlight.get(guildId);
  }

  const promise = (async () => {
    let doc = await GuildConfig.findOne({ guildId });
    if (!doc) {
      doc = await GuildConfig.create({ guildId });
    }

    // Evict LRU entry when cap is reached
    if (!cache.has(guildId) && cache.size >= MAX_CACHE_SIZE) {
      const oldestKey = cache.keys().next().value;
      cache.delete(oldestKey);
    }

    cache.set(guildId, { value: doc, at: Date.now() });
    return doc;
  })();

  inFlight.set(guildId, promise);
  try {
    return await promise;
  } finally {
    inFlight.delete(guildId);
  }
}

function invalidateGuildConfig(guildId) {
  cache.delete(guildId);
  inFlight.delete(guildId);
}

function resolved(guildConfigDoc) {
  return {
    prefix: guildConfigDoc.prefix || config.prefix,
    embedColor: guildConfigDoc.embedColor || config.embedColor,
    footer: guildConfigDoc.footer || config.embedFooter,
    language: guildConfigDoc.language || null, // raw override only - resolve the actual reply language via utils/i18n.js#resolveLanguage
    minecraft: {
      name: guildConfigDoc.minecraft?.name || config.minecraft.name,
      ip: guildConfigDoc.minecraft?.ip || config.minecraft.ip,
      port: guildConfigDoc.minecraft?.port || config.minecraft.port,
      // Bedrock always shares the Java IP - same server, Geyser just adds a port.
      bedrockPort: guildConfigDoc.minecraft?.bedrockPort || config.minecraft.bedrockPort,
      statsApiUrl: guildConfigDoc.minecraft?.statsApiUrl || null,
    },
  };
}

// Periodic sweep: remove entries whose TTL has expired. Interval matches
// TTL — running it more often than TTL is always wasted work.
// unref() keeps this from holding the process open.
const sweepTimer = setInterval(() => {
  const now = Date.now();
  for (const [guildId, entry] of cache) {
    if (now - entry.at >= CACHE_TTL_MS) cache.delete(guildId);
  }
}, CACHE_TTL_MS);
sweepTimer.unref();

module.exports = { getGuildConfig, invalidateGuildConfig, resolved };
