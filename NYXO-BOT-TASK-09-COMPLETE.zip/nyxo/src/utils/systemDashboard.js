/**
 * Task 45 — System Settings UI (إعدادات النظام).
 *
 * Renders the system/bot info section that opens when the admin picks
 * "النظام" from the /settings dashboard. Read-only status panel with
 * navigation only — no modifiable settings live here.
 *
 * Shows:
 *   • Bot uptime
 *   • Node.js version
 *   • Memory usage
 *   • Guild count (available from client)
 *   Navigation: settings_back / settings_home / settings_close
 */

const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require('discord.js');
const { COLORS, ICONS, DIVIDER } = require('./designSystem');

// ─── Helpers ──────────────────────────────────────────────────────────────────
function formatUptime(ms) {
  const s = Math.floor(ms / 1000);
  const m = Math.floor(s / 60);
  const h = Math.floor(m / 60);
  const d = Math.floor(h / 24);
  if (d > 0) return `${d}d ${h % 24}h ${m % 60}m`;
  if (h > 0) return `${h}h ${m % 60}m ${s % 60}s`;
  return `${m}m ${s % 60}s`;
}

function formatMem(bytes) {
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}

function navRow() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('settings_back').setLabel('رجوع / Back').setEmoji(ICONS.back).setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('settings_home').setLabel('الرئيسية / Home').setEmoji(ICONS.home).setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('settings_close').setLabel('إغلاق / Close').setEmoji(ICONS.close).setStyle(ButtonStyle.Danger),
  );
}

// ─── View builder ─────────────────────────────────────────────────────────────
function buildSystemView(settings, client) {
  const mem    = process.memoryUsage();
  const uptime = client ? formatUptime(client.uptime ?? process.uptime() * 1000) : formatUptime(process.uptime() * 1000);
  const guilds = client?.guilds?.cache?.size ?? '—';
  const users  = client?.users?.cache?.size  ?? '—';
  const node   = process.version;
  const rss    = formatMem(mem.rss);
  const heap   = formatMem(mem.heapUsed);

  const embed = new EmbedBuilder()
    .setColor(COLORS.primary)
    .setTitle(`${ICONS.system}・حالة النظام (System)`)
    .setDescription(`لوحة معلومات البوت والنظام — للعرض فقط.\n${DIVIDER}`)
    .addFields(
      { name: `⏱️ وقت التشغيل`, value: uptime, inline: true },
      { name: `🖥️ Node.js`, value: node, inline: true },
      { name: `🏠 السيرفرات`, value: String(guilds), inline: true },
      { name: `👥 المستخدمون (مخزن)`, value: String(users), inline: true },
      { name: `🧠 الذاكرة RSS`, value: rss, inline: true },
      { name: `📦 Heap Used`, value: heap, inline: true },
    )
    .setFooter({ text: `${settings.footer} • هذه القراءات من وقت فتح اللوحة` })
    .setTimestamp();

  return { embeds: [embed], components: [navRow()] };
}

module.exports = { buildSystemView };
