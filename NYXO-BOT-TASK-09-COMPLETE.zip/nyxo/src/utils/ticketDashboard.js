/**
 * Task 32 — إنشاء Tickets Dashboard (Tickets Dashboard).
 * Tasks 33-37 — إضافة الواجهات الحقيقية لأقسام Settings/Categories/Roles/Messages/Panels.
 *
 * buildSectionView now delegates five sections to their real UI modules
 * (ticketSettingsUI.js) instead of showing the Task-32 placeholder.
 * The remaining six sections (logs, status, reminders,
 * close_delete, statistics, permissions) still show a placeholder until
 * their own tasks are implemented - per-task isolation rule.
 */
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder } = require('discord.js');
const { COLORS, ICONS } = require('./designSystem');
const {
  buildSettingsView,
  buildCategoriesView,
  buildRolesView,
  buildMessagesView,
  buildPanelsView,
} = require('./ticketSettingsUI');

const TICKET_DASH_SECTIONS = [
  { id: 'settings', icon: ICONS.settings, nameAr: 'الإعدادات', nameEn: 'Settings', descAr: 'الإعدادات العامة لنظام التذاكر' },
  { id: 'panels', icon: ICONS.panels, nameAr: 'اللوحات', nameEn: 'Panels', descAr: 'إدارة لوحات فتح التذاكر' },
  { id: 'categories', icon: ICONS.categories, nameAr: 'الفئات', nameEn: 'Categories', descAr: 'فئات (أنواع) التذاكر المتاحة' },
  { id: 'roles', icon: ICONS.roles, nameAr: 'الرتب', nameEn: 'Roles', descAr: 'رتب الدعم والإشراف المرتبطة بالتذاكر' },
  { id: 'permissions', icon: ICONS.permissions, nameAr: 'الصلاحيات', nameEn: 'Permissions', descAr: 'من يملك صلاحية استلام/إغلاق/إدارة التذاكر' },
  { id: 'messages', icon: ICONS.messages, nameAr: 'الرسائل', nameEn: 'Messages', descAr: 'نصوص الترحيب والإغلاق والرسائل التلقائية' },
  { id: 'logs', icon: ICONS.logs, nameAr: 'السجلات', nameEn: 'Logs', descAr: 'قناة وسجل عمليات التذاكر' },
  { id: 'status', icon: ICONS.status, nameAr: 'الحالة', nameEn: 'Status', descAr: 'حالة نظام التذاكر (مفعّل/معطّل) والتذاكر المفتوحة حاليًا' },
  { id: 'reminders', icon: ICONS.reminders, nameAr: 'التذكيرات', nameEn: 'Reminders', descAr: 'تذكيرات الردّ على التذاكر غير المجاب عليها' },
  { id: 'close_delete', icon: ICONS.closeDelete, nameAr: 'الإغلاق والحذف', nameEn: 'Close/Delete', descAr: 'إعدادات إغلاق وحذف التذاكر تلقائيًا' },
  { id: 'statistics', icon: ICONS.stats, nameAr: 'الإحصائيات', nameEn: 'Statistics', descAr: 'إحصائيات التذاكر المفتوحة والمغلقة وأوقات الرد' },
];

const NAV_SELECT_ID = 'ticketdash_nav';
const HOME_BUTTON_ID = 'ticketdash_home';
const BACK_BUTTON_ID = 'ticketdash_back';
const CLOSE_BUTTON_ID = 'ticketdash_close';

function findSection(id) {
  return TICKET_DASH_SECTIONS.find((section) => section.id === id) || null;
}

function closeButton() {
  return new ButtonBuilder().setCustomId(CLOSE_BUTTON_ID).setLabel('إغلاق / Close').setEmoji(ICONS.close).setStyle(ButtonStyle.Danger);
}

function buildHomeView(settings, guildName) {
  const embed = new EmbedBuilder()
    .setColor(COLORS.primary)
    .setTitle(`${ICONS.tickets}・لوحة إدارة التذاكر`)
    .setDescription(
      `مرحبًا **${guildName}**، هذه هي لوحة إدارة نظام التذاكر.\n` +
        'تجمع هذه اللوحة كل إعدادات وأدوات التذاكر في مكان واحد بدل الاعتماد على أوامر متفرقة.\n' +
        'اختر قسمًا من القائمة أدناه لعرضه.\n\n' +
        '**الأقسام المتاحة حاليًا:**'
    )
    .addFields(
      TICKET_DASH_SECTIONS.map((section) => ({
        name: `${section.icon} ${section.nameAr} (${section.nameEn})`,
        value: section.descAr,
        inline: true,
      }))
    )
    .setFooter({ text: settings.footer })
    .setTimestamp();

  const select = new StringSelectMenuBuilder()
    .setCustomId(NAV_SELECT_ID)
    .setPlaceholder('اختر قسمًا لعرضه... / Choose a section')
    .addOptions(
      TICKET_DASH_SECTIONS.map((section) => ({
        label: `${section.nameAr} (${section.nameEn})`,
        description: section.descAr.slice(0, 100),
        value: section.id,
        emoji: section.icon,
      }))
    );

  return {
    embeds: [embed],
    components: [new ActionRowBuilder().addComponents(select), new ActionRowBuilder().addComponents(closeButton())],
  };
}

/**
 * Tasks 33-37: buildSectionView now delegates the five implemented sections
 * to their real UI view builders. All other sections still show a placeholder.
 * guildConfig is the raw Mongoose document (needed by real view builders).
 */
function buildSectionView(settings, sectionId, guildConfig = null) {
  const section = findSection(sectionId);
  if (!section) return null;

  // ── Real sections (Tasks 33-37) ──────────────────────────────────────────
  if (guildConfig) {
    if (sectionId === 'settings') return buildSettingsView(settings, guildConfig);
    if (sectionId === 'categories') return buildCategoriesView(settings, guildConfig);
    if (sectionId === 'roles') return buildRolesView(settings, guildConfig);
    if (sectionId === 'messages') return buildMessagesView(settings, guildConfig);
    if (sectionId === 'panels') return buildPanelsView(settings, guildConfig);
  }

  // ── Placeholder for not-yet-implemented sections ─────────────────────────
  const embed = new EmbedBuilder()
    .setColor(COLORS.primary)
    .setTitle(`${section.icon}・${section.nameAr} (${section.nameEn})`)
    .setDescription(
      `${section.descAr}\n\n` +
        `${ICONS.info} أدوات التحكم الكاملة لهذا القسم سيتم نقلها إلى هذه الواجهة في مهام لاحقة. ` +
        'الأوامر الحالية الخاصة بالتذاكر (مثل /ticketsetup) ما زالت تعمل بشكل طبيعي حتى اكتمال النقل.'
    )
    .setFooter({ text: settings.footer })
    .setTimestamp();

  const navRowPlaceholder = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(BACK_BUTTON_ID).setLabel('رجوع / Back').setEmoji(ICONS.back).setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(HOME_BUTTON_ID).setLabel('الرئيسية / Home').setEmoji(ICONS.home).setStyle(ButtonStyle.Secondary),
    closeButton()
  );

  return { embeds: [embed], components: [navRowPlaceholder] };
}

function buildClosedView(settings) {
  const embed = new EmbedBuilder()
    .setColor(COLORS.neutral)
    .setDescription(`${ICONS.close} تم إغلاق لوحة التذاكر. استخدم \`/tickets\` لفتحها من جديد.`)
    .setFooter({ text: settings.footer })
    .setTimestamp();
  return { embeds: [embed], components: [] };
}

module.exports = {
  TICKET_DASH_SECTIONS,
  findSection,
  buildHomeView,
  buildSectionView,
  buildClosedView,
  NAV_SELECT_ID,
  HOME_BUTTON_ID,
  BACK_BUTTON_ID,
  CLOSE_BUTTON_ID,
};
