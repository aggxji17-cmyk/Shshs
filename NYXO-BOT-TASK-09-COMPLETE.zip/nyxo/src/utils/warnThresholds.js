const { sendModLog } = require('./modLog');

/**
 * After a warn is recorded, checks the guild's configured warn thresholds
 * and applies the highest-count punishment the member has now reached.
 * Only ever applies ONE punishment per warn (the best match), so stacking
 * several warns at once doesn't fire off multiple actions.
 *
 * @param {import('discord.js').Guild} guild
 * @param {import('mongoose').Document} guildConfig
 * @param {ReturnType<typeof import('./resolveGuildSettings').resolved>} settings
 * @param {string} userId
 * @param {number} warnCount total warns the user now has
 * @returns {Promise<{ action: string, durationMinutes?: number } | null>} the punishment applied, if any
 */
async function applyWarnThresholds(guild, guildConfig, settings, userId, warnCount) {
  const thresholds = guildConfig.moderation?.warnThresholds || [];
  if (!thresholds.length) return null;

  // Pick the highest threshold the member has reached exactly or surpassed,
  // so a bulk warn (e.g. jumping from 1 to 3 warns) still triggers the
  // strongest applicable punishment rather than the first one in the list.
  const match = thresholds
    .filter((t) => warnCount >= t.count)
    .sort((a, b) => b.count - a.count)[0];
  if (!match) return null;

  const member = await guild.members.fetch(userId).catch(() => null);
  if (!member) return null;

  try {
    if (match.action === 'timeout') {
      if (!member.moderatable) return null;
      const ms = (match.durationMinutes || 60) * 60 * 1000;
      await member.timeout(ms, `Automatic: reached ${match.count} warns`);
    } else if (match.action === 'kick') {
      if (!member.kickable) return null;
      await member.kick(`Automatic: reached ${match.count} warns`);
    } else if (match.action === 'ban') {
      if (!member.bannable) return null;
      await guild.members.ban(userId, { reason: `Automatic: reached ${match.count} warns` });
    } else {
      return null;
    }
  } catch {
    return null;
  }

  await sendModLog(guild, guildConfig, settings, {
    title: 'Automatic Warn Punishment',
    description: `${member.user.username} reached **${warnCount}** warn(s) and triggered an automatic **${match.action}**.`,
    color: '#ED4245',
  });

  return { action: match.action, durationMinutes: match.durationMinutes };
}

module.exports = { applyWarnThresholds };
