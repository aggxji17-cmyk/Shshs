const { ChannelType, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle, EmbedBuilder } = require('discord.js');
const { QueueRepeatMode, useQueue } = require('discord-player');
const { getKazagumo } = require('../services/lavalinkManager');
const { buildKazagumoQueueView } = require('../utils/musicQueueEmbed');
const { getGuildConfig, resolved } = require('../utils/resolveGuildSettings');
const { successEmbed, errorEmbed, infoEmbed, loadingEmbed, baseEmbed } = require('../utils/embeds');
const { isModerator, isGuildManager } = require('../utils/permissions');
const { requireActiveQueue } = require('../utils/musicChecks');
const { buildMusicControlsRow } = require('../utils/musicControls');
const { buildQueuePage } = require('../utils/musicQueueEmbed');
const { buildCasesPage } = require('../utils/caseEmbed');
const { buildModHistoryPage, buildUserAuditPage } = require('../utils/auditEmbed');
const { closeTicket, reopenTicket, finalizeTicketDeletion } = require('../services/ticketCloseService');
const ticketState = require('../services/ticketStateManager');
const approvalService = require('../services/approvalService');
const favoritesService = require('../services/favoritesService');
const {
  findTicketType,
  buildTicketModal,
  buildPanelEmbed,
  buildPanelComponents,
  buildStatusChannelName,
  deriveBaseChannelName,
  STATUS_EMOJI,
  buildTicketActivityField,
} = require('../utils/ticketPanel');
const { queueRename } = require('../services/ticketRenameQueue');
const { buildHomeView, buildClosedView } = require('../utils/adminDashboard');
const { buildHomeView: buildTicketDashHomeView, buildClosedView: buildTicketDashClosedView, buildSectionView: buildTicketDashSectionView } = require('../utils/ticketDashboard');
const { buildHomeView: buildSettingsHomeView, buildClosedView: buildSettingsClosedView, buildSectionView: buildSettingsSectionView } = require('../utils/settingsDashboard');
const { buildLoggingView, SLG_EVENT_PREFIX } = require('../utils/loggingDashboard');
const { buildWelcomeView, buildPreviewEmbed } = require('../utils/welcomeDashboard');
// Task 45 — new settings section handlers
const {
  handleLevelingButton,
  SLV_TOGGLE_ID, SLV_ANNOUNCE_TOGGLE_ID, SLV_ANNOUNCE_CHANNEL_ID,
  SLV_XP_RANGE_ID, SLV_COOLDOWN_ID,
  SLV_VOICE_TOGGLE_ID, SLV_VOICE_XP_ID, SLV_VOICE_MIN_ID,
} = require('../utils/levelingDashboard');
const {
  handleEconomyButton,
  SEC_TOGGLE_ID, SEC_CURRENCY_NAME_ID, SEC_CURRENCY_SYMBOL_ID,
  SEC_DAILY_ID, SEC_WORK_ID, SEC_WORK_COOLDOWN_ID,
} = require('../utils/economyDashboard');
const {
  handleModerationSettingsButton,
  SMD_APPROVALS_TOGGLE_ID, SMD_REVIEW_CHANNEL_ID,
  SMD_GHOSTPING_TOGGLE_ID, SMD_BAN_LIMITS_TOGGLE_ID, SMD_KICK_LIMITS_TOGGLE_ID,
} = require('../utils/moderationSettingsDashboard');
const {
  handleMusicButton,
  SMU_247_TOGGLE_ID, SMU_247_VOICE_ID, SMU_247_TEXT_ID,
} = require('../utils/musicDashboard');
const {
  buildProtectionView,
  buildAutomodChecksView,
  SPT_AUTOMOD_CHECK_TOGGLE_PREFIX,
  SPT_AUTOMOD_CHECK_PUNISHMENT_PREFIX,
} = require('../utils/protectionDashboard');
const { CHECKS } = require('../services/automodChecks');
const {
  buildSettingsView,
  buildCategoriesView,
  buildRolesView,
  buildMessagesView,
  buildPanelsView,
  buildMessageModal,
  buildMinutesModal,
  buildChannelModal,
  buildRoleModal,
  buildCategoryModal,
  buildCategoryDeleteModal,
  buildClosePromptResetModal,
} = require('../utils/ticketSettingsUI');
const GuildConfig = require('../database/models/GuildConfig');
const { invalidateGuildConfig } = require('../utils/resolveGuildSettings');
const Ticket = require('../database/models/Ticket');
const Rating = require('../database/models/Rating');
const Suggestion = require('../database/models/Suggestion');
const Giveaway = require('../database/models/Giveaway');
const Poll = require('../database/models/Poll');
const logger = require('../utils/logger');
// Task 47 — نظام صفحات UI الموحّد
const { handlePageButton } = require('../utils/uiPages');
// Task 09 — Community Settings Dashboard
const { handleCommunityButton } = require('../utils/communityDashboard');
// Task 49 — نظام التأكيد الموحّد
const {
  parseConfirmId,
  buildConfirmView,
  CONFIRM_PRESETS,
} = require('../utils/confirmationSystem');

module.exports = {
  /**
   * Task 47 — معالج مركزي لأزرار nyxo_page الخاصة بنظام الصفحات.
   * customId: nyxo_page:<namespace>:<layer>:<page>:<extra>
   */
  nyxo_page: async (interaction) => {
    await handlePageButton(interaction);
  },

  // ── Task 49 — نظام التأكيد الموحّد ─────────────────────────────────────

  /**
   * معالج زر التأكيد (نعم).
   * customId: nyxo_confirm_yes:<action>:<token>
   *
   * الـ action يحدد ماذا يتم تنفيذه عند الضغط على "نعم".
   * كل case يقرأ الـ token (إن وجد) وينفّذ العملية المطلوبة.
   */
  nyxo_confirm_yes: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    const { valid, action, token } = parseConfirmId(interaction.customId);
    if (!valid) {
      return interaction.update({
        embeds: [errorEmbed(settings, 'طلب تأكيد غير صالح.')],
        components: [],
      });
    }

    switch (action) {
      // ── حذف Panel تذكرة ─────────────────────────────────────────────────
      case 'delete_panel': {
        if (!isGuildManager(interaction.member, guildConfig)) {
          return interaction.update({
            embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')],
            components: [],
          });
        }
        const panelId = token;
        if (!panelId) {
          return interaction.update({
            embeds: [errorEmbed(settings, 'معرّف اللوحة مفقود.')],
            components: [],
          });
        }

        // حذف الـ panel من الـ GuildConfig
        const result = await GuildConfig.updateOne(
          { guildId: interaction.guildId },
          { $pull: { 'tickets.panels': { _id: panelId } } }
        ).catch((err) => {
          logger.error(`فشل حذف Panel ${panelId} في السيرفر ${interaction.guildId}: ${err.stack || err}`);
          return null;
        });

        if (!result) {
          return interaction.update({
            embeds: [errorEmbed(settings, 'فشل حذف اللوحة، حاول مرة أخرى.')],
            components: [],
          });
        }

        invalidateGuildConfig(interaction.guildId);
        logger.info(`تم حذف Panel ${panelId} في السيرفر ${interaction.guildId} بواسطة ${interaction.user.id}`);

        return interaction.update({
          embeds: [successEmbed(settings, '✅ تم حذف اللوحة بنجاح.')],
          components: [],
        });
      }

      // ── إعادة ضبط إعدادات نظام التذاكر ─────────────────────────────────
      case 'reset_ticket_settings': {
        if (!isGuildManager(interaction.member, guildConfig)) {
          return interaction.update({
            embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')],
            components: [],
          });
        }

        await GuildConfig.updateOne(
          { guildId: interaction.guildId },
          {
            $unset: {
              'tickets.categoryId'       : '',
              'tickets.supportRoleId'    : '',
              'tickets.logChannelId'     : '',
              'tickets.transcriptChannelId': '',
              'tickets.autoClose'        : '',
              'tickets.autoClaimEnabled' : '',
              'tickets.reminderEnabled'  : '',
              'tickets.reminderInterval' : '',
              'tickets.deleteTime'       : '',
              'tickets.smartMention'     : '',
            },
          }
        ).catch((err) => {
          logger.error(`فشل إعادة ضبط إعدادات التذاكر في ${interaction.guildId}: ${err.stack || err}`);
        });

        invalidateGuildConfig(interaction.guildId);
        logger.info(`إعادة ضبط إعدادات التذاكر في ${interaction.guildId} بواسطة ${interaction.user.id}`);

        return interaction.update({
          embeds: [successEmbed(settings, '✅ تمت إعادة ضبط إعدادات التذاكر إلى القيم الافتراضية.')],
          components: [],
        });
      }

      // ── مسح بيانات الاقتصاد ─────────────────────────────────────────────
      case 'clear_economy': {
        if (!isGuildManager(interaction.member, guildConfig)) {
          return interaction.update({
            embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')],
            components: [],
          });
        }

        await GuildConfig.updateOne(
          { guildId: interaction.guildId },
          { $unset: { economy: '' } }
        ).catch((err) => {
          logger.error(`فشل مسح بيانات الاقتصاد في ${interaction.guildId}: ${err.stack || err}`);
        });

        invalidateGuildConfig(interaction.guildId);
        logger.info(`مسح بيانات الاقتصاد في ${interaction.guildId} بواسطة ${interaction.user.id}`);

        return interaction.update({
          embeds: [successEmbed(settings, '✅ تم مسح بيانات نظام الاقتصاد بنجاح.')],
          components: [],
        });
      }

      // ── مسح بيانات نظام المستويات ───────────────────────────────────────
      case 'clear_leveling': {
        if (!isGuildManager(interaction.member, guildConfig)) {
          return interaction.update({
            embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')],
            components: [],
          });
        }

        await GuildConfig.updateOne(
          { guildId: interaction.guildId },
          { $unset: { leveling: '' } }
        ).catch((err) => {
          logger.error(`فشل مسح إعدادات المستويات في ${interaction.guildId}: ${err.stack || err}`);
        });

        invalidateGuildConfig(interaction.guildId);
        logger.info(`مسح إعدادات المستويات في ${interaction.guildId} بواسطة ${interaction.user.id}`);

        return interaction.update({
          embeds: [successEmbed(settings, '✅ تم مسح إعدادات نظام المستويات بنجاح.')],
          components: [],
        });
      }

      // ── إعادة ضبط إعدادات عامة (generic) ──────────────────────────────
      case 'reset_settings': {
        if (!isGuildManager(interaction.member, guildConfig)) {
          return interaction.update({
            embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')],
            components: [],
          });
        }
        // token = اسم الحقل في GuildConfig المراد إعادة ضبطه
        if (!token) {
          return interaction.update({
            embeds: [errorEmbed(settings, 'لم يُحدَّد الإعداد المراد إعادة ضبطه.')],
            components: [],
          });
        }

        await GuildConfig.updateOne(
          { guildId: interaction.guildId },
          { $unset: { [token]: '' } }
        ).catch((err) => {
          logger.error(`فشل إعادة ضبط ${token} في ${interaction.guildId}: ${err.stack || err}`);
        });

        invalidateGuildConfig(interaction.guildId);
        logger.info(`إعادة ضبط إعداد "${token}" في ${interaction.guildId} بواسطة ${interaction.user.id}`);

        return interaction.update({
          embeds: [successEmbed(settings, `✅ تمت إعادة ضبط الإعداد بنجاح.`)],
          components: [],
        });
      }

      // ── إزالة عضو من تذكرة ─────────────────────────────────────────────
      case 'remove_member': {
        // token = "<ticketId>~<userId>"
        const [ticketId, targetUserId] = token.split('~');
        if (!ticketId || !targetUserId) {
          return interaction.update({
            embeds: [errorEmbed(settings, 'بيانات غير صالحة لإزالة العضو.')],
            components: [],
          });
        }

        const ticket = await Ticket.findById(ticketId).catch(() => null);
        if (!ticket || ticket.channelId !== interaction.channelId) {
          return interaction.update({
            embeds: [errorEmbed(settings, 'لم يتم العثور على التذكرة.')],
            components: [],
          });
        }

        if (!isModerator(interaction.member, guildConfig)) {
          return interaction.update({
            embeds: [errorEmbed(settings, 'الموظفون فقط يمكنهم إزالة الأعضاء.')],
            components: [],
          });
        }

        // إزالة من addedMembers
        ticket.addedMembers = (ticket.addedMembers || []).filter((id) => id !== targetUserId);
        await ticket.save().catch((err) => {
          logger.error(`فشل حفظ التذكرة بعد إزالة العضو ${targetUserId}: ${err.stack || err}`);
        });

        // إزالة الصلاحية من القناة
        await interaction.channel.permissionOverwrites.delete(targetUserId).catch((err) => {
          logger.warn(`تعذر حذف Permission Overwrite للعضو ${targetUserId}: ${err.message}`);
        });

        logger.info(`تم إزالة العضو ${targetUserId} من التذكرة ${ticketId} بواسطة ${interaction.user.id}`);

        return interaction.update({
          embeds: [successEmbed(settings, `✅ تم إزالة <@${targetUserId}> من التذكرة.`)],
          components: [],
        });
      }

      // ── حذف نوع تذكرة (Category) ────────────────────────────────────────
      case 'delete_ticket_type': {
        if (!isGuildManager(interaction.member, guildConfig)) {
          return interaction.update({
            embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')],
            components: [],
          });
        }
        const typeId = token;
        if (!typeId) {
          return interaction.update({
            embeds: [errorEmbed(settings, 'معرّف النوع مفقود.')],
            components: [],
          });
        }

        const before = (guildConfig.tickets?.types || []).length;
        await GuildConfig.updateOne(
          { guildId: interaction.guildId },
          { $pull: { 'tickets.types': { id: typeId } } }
        ).catch((err) => {
          logger.error(`فشل حذف نوع التذكرة ${typeId} في ${interaction.guildId}: ${err.stack || err}`);
        });

        invalidateGuildConfig(interaction.guildId);

        const after = (
          (await GuildConfig.findOne({ guildId: interaction.guildId }).lean().catch(() => null))
            ?.tickets?.types || []
        ).length;

        if (after >= before) {
          return interaction.update({
            embeds: [errorEmbed(settings, 'لم يتم العثور على هذا النوع أو فشل الحذف.')],
            components: [],
          });
        }

        logger.info(`تم حذف نوع التذكرة "${typeId}" في ${interaction.guildId} بواسطة ${interaction.user.id}`);

        return interaction.update({
          embeds: [successEmbed(settings, `✅ تم حذف نوع التذكرة بنجاح.`)],
          components: [],
        });
      }

      // ── عملية غير معروفة ─────────────────────────────────────────────────
      default: {
        logger.warn(`nyxo_confirm_yes: عملية غير معروفة "${action}" من المستخدم ${interaction.user.id} في ${interaction.guildId}`);
        return interaction.update({
          embeds: [errorEmbed(settings, `عملية التأكيد "${action}" غير مدعومة حالياً.`)],
          components: [],
        });
      }
    }
  },

  /**
   * معالج زر الإلغاء (لا).
   * customId: nyxo_confirm_no:<action>:<token>
   *
   * في جميع الحالات: إغلاق نافذة التأكيد برسالة هادئة.
   */
  nyxo_confirm_no: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    return interaction.update({
      embeds: [infoEmbed(settings, '🚫 تم إلغاء العملية.')],
      components: [],
    });
  },

  /** Reveals the Java Minecraft server IP as easily copyable inline code. */
  mc_copyip: async (interaction) => {
    const ip = interaction.message.embeds[0]?.fields?.find((f) => f.name === 'Java IP')?.value;
    await interaction.reply({
      content: `\`${ip?.replace(/`|\s*\(offline\)/g, '') || 'IP unavailable'}\``,
      ephemeral: true,
    });
  },

  /** Reveals the Bedrock Minecraft server IP as easily copyable inline code. Bedrock shares the same host as Java - only the port differs - so this combines the Java IP field's host with the Bedrock Port field's port. */
  mc_copybedrockip: async (interaction) => {
    const fields = interaction.message.embeds[0]?.fields || [];
    const javaIpRaw = fields.find((f) => f.name === 'Java IP')?.value;
    const bedrockPortRaw = fields.find((f) => f.name === 'Bedrock Port')?.value;

    const host = javaIpRaw
      ?.replace(/`|\s*\(offline\)/g, '')
      .split(':')[0];
    const bedrockPort = bedrockPortRaw?.replace(/`|\s*\(offline\)/g, '');

    const address = host && bedrockPort ? `${host}:${bedrockPort}` : null;

    await interaction.reply({
      content: `\`${address || 'IP unavailable'}\``,
      ephemeral: true,
    });
  },

  /** Opens a modal asking the user why they want to open a ticket. customId: ticket_create:<typeId>, one per panel button. */
  ticket_create: async (interaction) => {
    const [, typeId] = interaction.customId.split(':');
    const guildConfig = await getGuildConfig(interaction.guildId);
    const type = findTicketType(guildConfig, typeId);
    await interaction.showModal(buildTicketModal(type));
  },

  ticket_claim: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isModerator(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'الموظفون فقط يمكنهم استلام التذاكر.')], ephemeral: true });
    }

    // TASK 16 (إصلاح Ticket Claim الأساسي - تم فحصه وتأكيده):
    // الـfindOne -> mutate -> save() القديم كان يتصادم تحت نظام
    // optimistic-concurrency الافتراضي لـMongoose (__v، غير مُعطَّل في
    // هذا الـSchema - انظر database/models/Ticket.js): موظفان يضغطان
    // Claim في نفس اللحظة يحمّلان نفس نسخة المستند، وsave() الخاسر يرمي
    // VersionError (يظهر كرد عام "حدث خطأ ما"، مع بقاء claimedBy بدون
    // تغيير) بدل نجاح واضح أو إخبار الموظف أن التذكرة مُستلَمة بالفعل.
    // نداء واحد ذري (findOneAndUpdate) - نفس النمط المستخدم أصلاً في
    // هذا الملف (giveaway_join أعلاه) وفي ticketCloseService.js لنفس
    // السبب - يزيل التصادم تماماً: طلب واحد يفوز دائماً بدون أي تعارض
    // نسخة ممكن، ولا يفشل تحديث قاعدة البيانات لموظفين ينقران بنفس
    // اللحظة. إعادة استلام تذكرة مفتوحة تم استلامها مسبقاً تبقى مسموحة
    // كما كانت دائماً (سلوك تجاري مقصود، لا علاقة له بمشكلة الـRace).
    // TASK 18 (مزامنة Claim مع الصلاحيات - تم الفحص، لا تغيير مطلوب):
    // السلوك الرسمي الحالي لهذا النظام (Ticket model الجديد) هو أن
    // الاستلام (Claim) مؤشّر تنظيمي فقط (status/claimedBy)، ولا يغيّر
    // Permission Overwrites إطلاقاً - كل الأدوار المُدرجة في viewRoleIds
    // (انظر modals.js#ticket_create_modal، resolveTypeTargets) تحتفظ
    // بنفس صلاحيات View/Send/ReadHistory بغض النظر عمّن استلم التذكرة،
    // بعكس نظام claim.js القديم (legacy-handlers) الذي كان يقفل صلاحية
    // الإرسال عن دور الدعم بالكامل ويمنحها فقط للمستلم. بما أن قفل
    // الصلاحيات لم يكن جزءاً موثّقاً من سلوك هذا النظام الجديد أصلاً
    // (Rule 8: لا نفترض Bug غير مؤكد)، لا يوجد "فرق بين قاعدة البيانات
    // وDiscord" يلزم تصحيحه هنا - قاعدة البيانات (claimedBy) والصلاحيات
    // في Discord متّسقتان بالتصميم لأن لا علاقة بينهما في هذا المسار.
    const ticket = await Ticket.findOneAndUpdate(
      { channelId: interaction.channelId, status: { $ne: ticketState.TICKET_STATUS.CLOSED } },
      { $set: { status: ticketState.TICKET_STATUS.CLAIMED, claimedBy: interaction.user.id } },
      { new: true }
    );
    if (!ticket) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'هذه التذكرة غير مفتوحة.')], ephemeral: true });
    }

    await interaction.reply({
      embeds: [successEmbed(settings, `تم استلام التذكرة بواسطة <@${interaction.user.id}>.`)],
    });

    // TASK 17: مزامنة اللوحة (Embed + Buttons) بعد نجاح الاستلام - انظر
    // syncClaimedTicketPanel أسفل الملف. يعمل بعد الرد أعلاه (الذي أقرّ
    // الـInteraction) فلا يؤخّره؛ فشل هذه الخطوة cosmetic فقط.
    await syncClaimedTicketPanel(interaction.message, ticket, interaction.user);
  },

  /** 🔄 Lets staff manually flip a ticket between 🟡 "needs reply" and 🟢 "no action needed", independent of who spoke last. */
  ticket_status_toggle: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isModerator(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'الموظفون فقط يمكنهم تغيير حالة التذكرة.')], ephemeral: true });
    }

    const ticket = await Ticket.findOne({ channelId: interaction.channelId });
    if (!ticket || ticket.status === ticketState.TICKET_STATUS.CLOSED) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'هذه التذكرة غير مفتوحة.')], ephemeral: true });
    }

    const nextStatus =
      ticket.replyStatus === ticketState.REPLY_STATUS.NEEDS_REPLY
        ? ticketState.REPLY_STATUS.NO_ACTION
        : ticketState.REPLY_STATUS.NEEDS_REPLY;
    const baseName = ticket.baseChannelName || deriveBaseChannelName(interaction.channel.name);

    ticketState.applyReplyStatus(ticket, nextStatus);
    ticket.baseChannelName = baseName;
    await ticket.save();

    // TASK 11: بدل استدعاء channel.setName() مباشرة (كان يعلّق أحياناً
    // بسبب Rate Limit ديسكورد على القناة)، تُمرَّر عملية التسمية إلى
    // طابور إعادة التسمية المركزي (services/ticketRenameQueue.js) من
    // مهمة 10. queueRename لا تُنتظر عمداً (fire-and-forget) فالرد على
    // الـInteraction أدناه لا ينتظر أي عملية rename بطيئة - حالة قاعدة
    // البيانات (المستخدمة من هذا الزر ومن messageCreate.js) تبقى صحيحة
    // فوراً بغض النظر عن توقيت نجاح إعادة التسمية الفعلية.
    queueRename(interaction.channel, buildStatusChannelName(baseName, nextStatus), {
      context: `ticket_status_toggle #${ticket.ticketNumber}`,
    });

    // TASK33: surface the activity-tracking fields (last speaker/last
    // message per side/last activity) on this reply - it's already the
    // closest thing this project has to a dedicated "ticket status
    // message", so this is additive only: the existing success line
    // above is untouched, this just appends a field to the same embed.
    const embed = successEmbed(
      settings,
      `تم تغيير حالة التذكرة إلى ${STATUS_EMOJI[nextStatus]} ${nextStatus === 'needs_reply' ? 'تحتاج رد من الإدارة' : 'لا تحتاج أي إجراء'}.`
    ).addFields(buildTicketActivityField(ticket));

    await interaction.reply({
      embeds: [embed],
      ephemeral: true,
    });
  },

  /**
   * "الإغلاق الذكي" - smart close. Closing a ticket no longer deletes it
   * right away: the channel is locked and a 🗑️ delete / 🔓 reopen prompt
   * is posted (see services/ticketCloseService.js), giving the opener a
   * window to change their mind. Actual deletion (archive + logs) only
   * happens via ticket_delete_confirm below, or the auto-delete scheduler.
   */
  ticket_close: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    // TASK 19 (فحص صلاحيات إغلاق التذاكر H3 - تم الفحص، السلوك الرسمي مؤكَّد):
    // فحص isModerator (utils/permissions.js) وكل مسارات الإغلاق أكّد أن
    // إغلاق تذكرة اليوم مبني على تحقّق واحد فقط (staff-tier)، بلا أي
    // تمييز إضافي حسب مين استلمها:
    //   • Moderator (modRoleId)      → مسموح (isModerator=true).
    //   • Administrator              → مسموح ضمنياً - isModerator يستدعي
    //     isGuildManager الذي يتحقق من صلاحية Administrator مباشرة.
    //   • Claimer (استلم التذكرة)    → مسموح فقط إن كان أصلاً staff (وهذا
    //     مضمون دائماً لأن ticket_claim نفسه يشترط isModerator ليستلم -
    //     لا يوجد "امتياز إغلاق إضافي" خاص بكونه المستلم تحديداً؛ أي
    //     staff آخر غير المستلم يقدر يغلق بنفس الصلاحية بالضبط).
    //   • Ticket Owner (صاحب التذكرة) → غير مسموح؛ لا يوجد أي مسار في
    //     الكود يمنح صاحب التذكرة صلاحية الإغلاق (بعكس ticket_reopen الذي
    //     يسمح صراحة لصاحب التذكرة - سلوك مختلف ومقصود لكل زر).
    //   • حالة عدم وجود Claimer      → لا تأثير على صلاحية الإغلاق أصلاً،
    //     لأن التحقق لا يقرأ claimedBy إطلاقاً - أي staff يقدر يغلق سواء
    //     استُلمت التذكرة أو لا.
    // نفس القاعدة (isModerator فقط) مطبّقة أيضاً في ticket_delete_confirm
    // أدناه - اتساق كامل بين الإغلاق والحذف النهائي. لا يوجد فرق موثّق أو
    // مقصود يستدعي تمييز الـClaimer عن بقية الـStaff هنا، فلا تعديل على
    // السلوك (rule 2/8) - هذا التعليق فقط لتوثيق نتيجة الفحص.
    if (!isModerator(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'الموظفون فقط يمكنهم إغلاق التذاكر.')], ephemeral: true });
    }

    const ticket = await Ticket.findOne({ channelId: interaction.channelId });
    if (!ticket || ticket.status === 'closed') {
      return interaction.reply({ embeds: [errorEmbed(settings, 'هذه التذكرة مغلقة بالفعل أو ليست تذكرة.')], ephemeral: true });
    }

    // Task 1: ack immediately (rule 13, no Interaction Failed) - the
    // actual close (send the close prompt, then persist it) now happens
    // in that order inside closeTicket and can take longer than
    // Discord's interaction window.
    await interaction.deferReply();

    const result = await closeTicket(interaction.channel, guildConfig, settings, ticket, interaction.user.id);

    if (!result.success) {
      return interaction.editReply({
        embeds: [errorEmbed(settings, 'تعذر إغلاق التذكرة بسبب خطأ في إرسال أو حفظ حالة الإغلاق. حاول مرة أخرى.')],
      });
    }

    await interaction.editReply({ embeds: [successEmbed(settings, `تم إغلاق التذكرة بواسطة <@${interaction.user.id}>.`)] });
  },

  /** 🗑️ button on the close prompt. customId: ticket_delete_confirm:<ticketId>. Staff-only - builds the transcript archive, logs it, then deletes the channel for good. */
  ticket_delete_confirm: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    // Task 19: نفس تحقّق isModerator المفحوص والموثَّق في ticket_close
    // أعلاه (staff-tier فقط، لا تمييز حسب Claimer، لا صلاحية لصاحب
    // التذكرة) - راجع التعليق هناك للتفاصيل الكاملة.
    if (!isModerator(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'الموظفون فقط يمكنهم حذف التذاكر نهائياً.')], ephemeral: true });
    }

    const [, ticketId] = interaction.customId.split(':');
    const ticket = await Ticket.findById(ticketId).catch((err) => {
      logger.error(`فشل تحميل التذكرة ${ticketId} من أجل الحذف: ${err.stack || err}`);
      return null;
    });
    if (!ticket || ticket.status !== 'closed' || ticket.channelId !== interaction.channelId) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'هذه التذكرة لم تعد بانتظار الحذف.')], ephemeral: true });
    }

     await interaction.reply({ embeds: [loadingEmbed(settings, 'جارٍ إنشاء أرشيف التذكرة وحذفها نهائياً...')] });
    await interaction.message.edit({ components: [] }).catch((err) => {
      logger.warn(`تعذر تعطيل أزرار حذف التذكرة #${ticket.ticketNumber}: ${err.message}`);
    });

    await finalizeTicketDeletion(interaction.client, interaction.guild, guildConfig, settings, ticket, interaction.channel, interaction.user.id);
  },

  /** 🔓 button on the close prompt. customId: ticket_reopen:<ticketId>. Owner or staff only - cancels the auto-delete timer and restores the ticket exactly as it was. */
  ticket_reopen: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    const [, ticketId] = interaction.customId.split(':');
    const ticket = await Ticket.findById(ticketId).catch((err) => {
      logger.error(`فشل تحميل التذكرة ${ticketId} من أجل إعادة الفتح: ${err.stack || err}`);
      return null;
    });
    if (!ticket || ticket.status !== 'closed' || ticket.channelId !== interaction.channelId) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'هذه التذكرة لم تعد بانتظار الحذف.')], ephemeral: true });
    }

    const isOwner = interaction.user.id === ticket.userId;
    if (!isOwner && !isModerator(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'إعادة فتح التذكرة متاحة فقط لصاحبها أو الإدارة.')], ephemeral: true });
    }

    // Task 15: reopenTicket() below does a DB save ثم permissionOverwrites.edit
    // (Discord API)، وبعدها message.edit أدناه يعمل نداء Discord آخر - قبل
    // أي رد على هذا الـInteraction. تسلسل عمليتي Discord API قبل الرد قد
    // يتجاوز مهلة ديسكورد القصيرة، فنُقر (ack) فوراً هنا (rule 13: منع
    // Interaction Failed)، ثم نستخدم editReply لكل الردود التالية.
    //
    // ملاحظة سلوك موثّقة (rule 2): الرد النهائي بعد defer لا يمكن أن يكون
    // ephemeral لتذكرة نجاح غير-ephemeral ثم ephemeral لحالة الفشل النادرة
    // (لديك تذكرة أخرى مفتوحة) في نفس الوقت - ديسكورد يثبّت هذا عند أول
    // رد. اخترنا غير-ephemeral (تطابق المسار الأساسي/الناجح)؛ رسالة الفشل
    // النادرة تصبح مرئية للجميع بدل ephemeral فقط - تنازل بسيط مقابل ضمان
    // عدم فشل الـInteraction، وهي حالة نادرة أصلاً (طلب إعادة فتح تذكرة
    // بينما لدى المستخدم تذكرة أخرى مفتوحة).
    await interaction.deferReply();

    const result = await reopenTicket(interaction.channel, ticket, interaction.user.id);

    // Task 5: the member already has a different active ticket (opened
    // while this one was closed/pending deletion) - the unique index
    // correctly refused to give them two at once. Leave the 🗑️/🔓 prompt
    // in place so they can still delete this one, or reopen it later
    // once their other ticket is closed.
    if (!result.success) {
      return interaction.editReply({
        embeds: [errorEmbed(settings, 'لا يمكن إعادة فتح هذه التذكرة لأن لديك تذكرة أخرى مفتوحة حالياً.')],
      });
    }

    await interaction.message.edit({ components: [] }).catch((err) => {
      logger.warn(`تعذر تعطيل أزرار إعادة فتح التذكرة #${ticket.ticketNumber}: ${err.message}`);
    });

    await interaction.editReply({ embeds: [successEmbed(settings, `تم إلغاء الحذف وإعادة فتح التذكرة بواسطة <@${interaction.user.id}>. عادت جميع الصلاحيات كما كانت.`)] });
  },

  /** ⭐ button in the post-close rating DM. customId: ticket_rate:<ticketId>:<stars 1-5>. Opens a modal for an optional comment; the rating itself is only recorded on that modal's submission (see modals.js), so a dismissed modal leaves nothing behind and the buttons stay usable. */
  ticket_rate: async (interaction) => {
    const [, ticketId, starsRaw] = interaction.customId.split(':');
    const stars = Number(starsRaw);

    const ticket = await Ticket.findById(ticketId).catch((err) => {
      logger.error(`فشل تحميل التذكرة ${ticketId} من أجل التقييم: ${err.stack || err}`);
      return null;
    });

    // Task 7 (real bug): this button is only ever clicked from the rating
    // DM (see services/ratingService.js), so interaction.guildId is always
    // null here - a DM interaction has no guild. getGuildConfig(null) hit
    // GuildConfig's unique `guildId` index on the very first call and
    // threw for every rating attempt after it, since a second
    // GuildConfig.create({guildId: null}) is a duplicate key. Resolve the
    // guild from the ticket itself instead, exactly like the comment-modal
    // handler below already does correctly.
    const guildConfig = ticket ? await getGuildConfig(ticket.guildId) : null;
    const settings = resolved(guildConfig || {});

    if (!ticket) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تعذر العثور على هذه التذكرة.')], ephemeral: true });
    }

    if (interaction.user.id !== ticket.userId) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'هذا التقييم مخصص لصاحب التذكرة فقط.')], ephemeral: true });
    }

    const existing = await Rating.findOne({ ticketId: ticket._id });
    if (existing) {
      return interaction.reply({ embeds: [successEmbed(settings, 'لقد قمت بتقييم هذه التذكرة مسبقاً، شكراً لك!')], ephemeral: true });
    }

    const modal = new ModalBuilder()
      .setCustomId(`ticket_rate_comment_modal:${ticket._id}:${stars}`)
      .setTitle(`تقييمك: ${'⭐'.repeat(stars)}`)
      .addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('comment')
            .setLabel('تعليق (اختياري)')
            .setPlaceholder('شاركنا رأيك في تجربتك مع الدعم الفني...')
            .setStyle(TextInputStyle.Paragraph)
            .setRequired(false)
            .setMaxLength(500)
        )
      );

    await interaction.showModal(modal);
  },

  suggestion_upvote: async (interaction) => await handleSuggestionVote(interaction, 'up'),
  suggestion_downvote: async (interaction) => await handleSuggestionVote(interaction, 'down'),

  /** Grants the configured verification role when a new member clicks Verify. */
  verification_verify: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!guildConfig.verification?.enabled || !guildConfig.verification.roleId) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'Verification is not currently configured.')], ephemeral: true });
    }

    if (interaction.member.roles.cache.has(guildConfig.verification.roleId)) {
      return interaction.reply({ embeds: [infoEmbed(settings, 'You are already verified.')], ephemeral: true });
    }

    await interaction.member.roles.add(guildConfig.verification.roleId).catch(() => null);
    return interaction.reply({ embeds: [successEmbed(settings, 'You have been verified! Welcome to the server.')], ephemeral: true });
  },

  /**
   * Task 4 (Race Condition fix): the old findOne -> mutate participantIds
   * in JS -> save() pattern let two clicks arriving at nearly the same
   * moment (even from different members) both read the same array,
   * mutate their own in-memory copy, then overwrite each other on save -
   * a lost update that could silently drop another member's entry, or
   * throw a VersionError from Mongoose's optimistic concurrency check on
   * the array. This is now two single atomic MongoDB operations (modeled
   * on services/economyService.js's findOneAndUpdate pattern), so the
   * "already joined?" check and the mutation happen together as one
   * database-level step with no room for another request to interleave.
   */
  giveaway_join: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    const messageId = interaction.message.id;
    const userId = interaction.user.id;

    // محاولة أولى ذرّية: أزل العضو إن كان مسجلاً بالفعل (leave). الشرط
    // (العضو ضمن participantIds) والتعديل ($pull) يُنفَّذان معاً داخل
    // نفس عملية findOneAndUpdate في قاعدة البيانات - لا يمكن لأي عملية
    // متزامنة أخرى أن ترى حالة وسيطة أو تسبب lost update هنا.
    const left = await Giveaway.findOneAndUpdate(
      { messageId, ended: false, participantIds: userId },
      { $pull: { participantIds: userId } },
      { new: true }
    );

    if (left) {
      return interaction.reply({ embeds: [infoEmbed(settings, 'You left the giveaway.')], ephemeral: true });
    }

    // لم يكن العضو مسجلاً (أو لا يوجد giveaway نشط بهذا الشكل أصلاً).
    // $addToSet ذرّي وآمن من التكرار بطبيعته: حتى لو نُفِّذ نداءان
    // متزامنان لنفس العضو في نفس اللحظة، لن يُضاف أكثر من إدخال واحد له
    // مهما تداخل التوقيت (لا حاجة لفحص includes() يدوي في الذاكرة).
    const joined = await Giveaway.findOneAndUpdate(
      { messageId, ended: false },
      { $addToSet: { participantIds: userId } },
      { new: true }
    );

    if (!joined) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'This giveaway has ended.')], ephemeral: true });
    }

    return interaction.reply({
      embeds: [successEmbed(settings, `You entered the giveaway! (${joined.participantIds.length} entries so far)`)],
      ephemeral: true,
    });
  },

  poll_vote: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    const [, pollId, optionIndexStr] = interaction.customId.split(':');
    const optionIndex = Number(optionIndexStr);

    const poll = await Poll.findById(pollId);
    if (!poll || poll.ended) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'This poll is no longer active.')], ephemeral: true });
    }

    const userId = interaction.user.id;
    const alreadyVotedThis = poll.options[optionIndex].voterIds.includes(userId);

    if (!poll.allowMultiple) {
      poll.options.forEach((o) => { o.voterIds = o.voterIds.filter((id) => id !== userId); });
    }

    if (alreadyVotedThis) {
      poll.options[optionIndex].voterIds = poll.options[optionIndex].voterIds.filter((id) => id !== userId);
    } else {
      poll.options[optionIndex].voterIds.push(userId);
    }

    await poll.save();

    const totalVotes = poll.options.reduce((sum, o) => sum + o.voterIds.length, 0);
    const embed = baseEmbed(settings)
      .setTitle(`📊 ${poll.question}`)
      .setDescription(poll.options.map((o, i) => `**${i + 1}.** ${o.text} — ${o.voterIds.length} vote(s)`).join('\n'))
      .setFooter({ text: `${totalVotes} total vote(s)` });

    await interaction.update({ embeds: [embed] });
  },

  /** ✅ Approve button on an approval-request embed. customId: approval_approve:<requestId>. */
  approval_approve: async (interaction) => {
    const [, requestId] = interaction.customId.split(':');
    await approvalService.approveRequest(interaction, requestId);
  },

  /** ❌ Reject button on an approval-request embed - opens a modal for the rejection reason. customId: approval_reject:<requestId>. */
  approval_reject: async (interaction) => {
    const [, requestId] = interaction.customId.split(':');
    await interaction.showModal(approvalService.buildRejectModal(requestId));
  },

  /** Previous/Next paging for /cases. customId: cases_page:<targetId>:<page>. */
  cases_page: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isModerator(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'ليس لديك صلاحية استخدام هذا الأمر.')], ephemeral: true });
    }

    const [, targetId, pageStr] = interaction.customId.split(':');
    const page = Math.max(parseInt(pageStr, 10) || 1, 1);

    const target = await interaction.client.users.fetch(targetId).catch(() => null);
    if (!target) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تعذر العثور على هذا المستخدم.')], ephemeral: true });
    }

    const { embed, components } = await buildCasesPage(settings, interaction.guildId, target, page);
    await interaction.update({ embeds: [embed], components });
  },

  /** Previous/Next paging for /modhistory. customId: modhistory_page:<moderatorId>:<range>:<sort>:<page>. */
  modhistory_page: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'ليس لديك صلاحية استخدام هذا الأمر.')], ephemeral: true });
    }

    const [, moderatorId, range, sort, pageStr] = interaction.customId.split(':');
    const page = Math.max(parseInt(pageStr, 10) || 1, 1);

    const moderator = await interaction.client.users.fetch(moderatorId).catch(() => null);
    if (!moderator) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تعذر العثور على هذا المستخدم.')], ephemeral: true });
    }

    const { embed, components } = await buildModHistoryPage(settings, interaction.guildId, moderator, { range, sort, page });
    await interaction.update({ embeds: [embed], components });
  },

  /** Opens, then pages through, a member's full punishment record from /userinfo. customId: userinfo_audit_page:<targetId>:<range>:<sort>:<page>. */
  userinfo_audit_page: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isModerator(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'ليس لديك صلاحية استخدام هذا الأمر.')], ephemeral: true });
    }

    const [, targetId, range, sort, pageStr] = interaction.customId.split(':');
    const page = Math.max(parseInt(pageStr, 10) || 1, 1);

    const target = await interaction.client.users.fetch(targetId).catch(() => null);
    if (!target) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تعذر العثور على هذا المستخدم.')], ephemeral: true });
    }

    const { embed, components } = await buildUserAuditPage(settings, interaction.guildId, target, { range, sort, page });
    await interaction.update({ embeds: [embed], components });
  },

  /** ⏸️/▶️ toggle on a Now Playing message. Updates the row in place so the icon always reflects current state. */
  music_pauseresume: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    const queue = await requireActiveQueue(interaction, settings);
    if (!queue) return;

    const nowPaused = !queue.node.isPaused();
    queue.node.setPaused(nowPaused);
    if (!nowPaused && queue.metadata) queue.metadata.autoPausedForEmpty = false;
    await interaction.update({ components: buildMusicControlsRow(queue) });
  },

  /** ⏭️ Skip the current track from the Now Playing message. */
  music_skip: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    const queue = await requireActiveQueue(interaction, settings);
    if (!queue) return;

    const skipped = queue.currentTrack;
    queue.node.skip();
    await interaction.reply({
      embeds: [successEmbed(settings, `⏭️ Skipped **${skipped.title}** — <@${interaction.user.id}>`)],
      ephemeral: true,
    });
  },

  /** ⏹️ Stop playback, clear the queue, and disable the buttons on the message they were clicked from. */
  music_stop: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    const queue = await requireActiveQueue(interaction, settings);
    if (!queue) return;

    queue.delete();
    await interaction.update({
      embeds: [successEmbed(settings, `⏹️ Playback stopped and queue cleared — <@${interaction.user.id}>`)],
      components: [],
    });
  },

  /** 🔀 Shuffle the upcoming tracks from the Now Playing message. */
  music_shuffle: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    const queue = await requireActiveQueue(interaction, settings);
    if (!queue) return;

    if (queue.tracks.toArray().length < 2) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'Not enough tracks in the queue to shuffle.')], ephemeral: true });
    }

    queue.tracks.shuffle();
    await interaction.reply({ embeds: [successEmbed(settings, `🔀 Queue shuffled — <@${interaction.user.id}>`)], ephemeral: true });
  },

  /** 🔁 Cycle Off → Track → Queue → Off from the Now Playing message, and re-highlight the button to match. */
  music_loop: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    const queue = await requireActiveQueue(interaction, settings);
    if (!queue) return;

    const CYCLE = [QueueRepeatMode.OFF, QueueRepeatMode.TRACK, QueueRepeatMode.QUEUE];
    const nextMode = CYCLE[(CYCLE.indexOf(queue.repeatMode) + 1) % CYCLE.length];
    const LABELS = { [QueueRepeatMode.OFF]: 'disabled', [QueueRepeatMode.TRACK]: 'looping the track', [QueueRepeatMode.QUEUE]: 'looping the queue' };

    queue.setRepeatMode(nextMode);
    await interaction.reply({ embeds: [successEmbed(settings, `🔁 Loop mode is now **${LABELS[nextMode]}**.`)], ephemeral: true });

    await interaction.message.edit({ components: buildMusicControlsRow(queue) }).catch(() => null);
  },

  /** ◀️/▶️ Previous/Next page on a /queue message. customId: music_queue_page:<page>. View-only, so no voice-channel check. */
  music_queue_page: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    const [, pageStr] = interaction.customId.split(':');
    const page = Math.max(parseInt(pageStr, 10) || 1, 1);

    // Try Kazagumo first, then fall back to discord-player
    const kazagumo = getKazagumo();
    const kazagumoPlayer = kazagumo?.players.get(interaction.guildId);
    if (kazagumoPlayer && kazagumoPlayer.queue.current) {
      const queueView = buildKazagumoQueueView(kazagumoPlayer);
      const { embed, components } = buildQueuePage(queueView, settings, page);
      return interaction.update({ embeds: [embed], components });
    }

    const queue = useQueue(interaction.guildId);
    if (!queue || !queue.currentTrack) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'Nothing is playing right now.')], ephemeral: true });
    }

    const { embed, components } = buildQueuePage(queue, settings, page);
    await interaction.update({ embeds: [embed], components });
  },

  /** 🗑️ Clear Queue button on a /queue message. Leaves the currently playing track untouched. */
  music_queue_clear: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    // Try Kazagumo first, then fall back to discord-player
    const kazagumo = getKazagumo();
    const kazagumoPlayer = kazagumo?.players.get(interaction.guildId);
    if (kazagumoPlayer && kazagumoPlayer.queue.current) {
      const memberChannel = interaction.member?.voice?.channel;
      if (!memberChannel || memberChannel.id !== kazagumoPlayer.voiceId) {
        return interaction.reply({ embeds: [errorEmbed(settings, 'انضم للقناة الصوتية للتحكم بالموسيقى.')], ephemeral: true });
      }
      kazagumoPlayer.queue.clear();
      const queueView = buildKazagumoQueueView(kazagumoPlayer);
      const { embed, components } = buildQueuePage(queueView, settings, 1);
      return interaction.update({ embeds: [embed], components });
    }

    const queue = await requireActiveQueue(interaction, settings);
    if (!queue) return;

    queue.tracks.clear();
    const { embed, components } = buildQueuePage(queue, settings, 1);
    await interaction.update({ embeds: [embed], components });
  },

  /** 🔄 Toggle autoplay (plays similar tracks once the queue ends) from the Now Playing message. Shares the same repeatMode field as /loop, so it's mutually exclusive with track/queue looping. */
  music_autoplay: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    const queue = await requireActiveQueue(interaction, settings);
    if (!queue) return;

    const enabling = queue.repeatMode !== QueueRepeatMode.AUTOPLAY;
    queue.setRepeatMode(enabling ? QueueRepeatMode.AUTOPLAY : QueueRepeatMode.OFF);

    await interaction.reply({
      embeds: [
        successEmbed(
          settings,
          enabling
            ? '🔄 Autoplay is now **enabled** — similar tracks will play when the queue ends.'
            : '🔄 Autoplay is now **disabled**.'
        ),
      ],
      ephemeral: true,
    });

    await interaction.message.edit({ components: buildMusicControlsRow(queue) }).catch(() => null);
  },

  /** ❤️ Adds the currently playing track to the clicking user's personal favorites from the Now Playing message. View-only like music_queue_page - anyone can favorite a song for themselves without needing to be in the voice channel. */
  music_favorite: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    const queue = useQueue(interaction.guildId);
    if (!queue || !queue.currentTrack) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'Nothing is playing right now.')], ephemeral: true });
    }

    const trackData = favoritesService.toTrackData(queue.currentTrack);
    const { track, error } = await favoritesService.addTrackData(interaction.user.id, trackData);
    if (error) {
      return interaction.reply({ embeds: [errorEmbed(settings, error)], ephemeral: true });
    }

    await interaction.reply({ embeds: [successEmbed(settings, `❤️ Added **${track.title}** to your favorites.`)], ephemeral: true });
  },

  /**
   * Task 31 — Home button on the admin dashboard. Returns to the section
   * list from a section view. customId: admin_home.
   *
   * Re-checks isGuildManager() on every click, not just once at /admin -
   * the panel is ephemeral so only the original invoker can ever see or
   * click it, but a role removed mid-session (e.g. their admin role is
   * taken away while the panel is still open) should still be caught
   * here, same as cases_page/modhistory_page above already do for their
   * own re-checks.
   */
  admin_home: async (interaction) => {
    await renderAdminHome(interaction);
  },

  /**
   * Task 31 — Back button on an admin dashboard section view. At the
   * current single-level depth (Home -> one Section) this lands on the
   * same Home view as admin_home above - see utils/adminDashboard.js's
   * top comment for why it is still a separate button/customId rather
   * than merged into admin_home. customId: admin_back.
   */
  admin_back: async (interaction) => {
    await renderAdminHome(interaction);
  },

  /**
   * Task 31 — Close button on the admin dashboard (present on every
   * view: Home and every Section). Replaces the panel with a plain
   * "closed" notice and removes all components, rather than just
   * deleting the message, so the ephemeral reply doesn't vanish
   * abruptly. customId: admin_close.
   */
  admin_close: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر (Manage Server) لاستخدام لوحة الإدارة.')], ephemeral: true });
    }

    const { embeds, components } = buildClosedView(settings);
    await interaction.update({ embeds, components });
  },



  // ═══════════════════════════════════════════════════════════════════════════
  // Task 40 — Welcome/Leave Settings UI (swl_*)
  // ═══════════════════════════════════════════════════════════════════════════

  /** Toggle welcome system on/off. customId: swl_welcome_toggle */
  swl_welcome_toggle: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const newEnabled = !guildConfig.welcome?.enabled;
    await GuildConfig.updateOne(
      { guildId: interaction.guildId },
      { $set: { 'welcome.enabled': newEnabled } }
    );
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view  = buildWelcomeView(settings, fresh);
    await interaction.update({ embeds: view.embeds, components: view.components });
  },

  /** Open modal to set welcome channel ID. customId: swl_welcome_channel */
  swl_welcome_channel: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const { ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
    const modal = new ModalBuilder()
      .setCustomId('swl_modal_welcome_channel')
      .setTitle('قناة الترحيب (Welcome Channel)');
    const input = new TextInputBuilder()
      .setCustomId('value')
      .setLabel('معرّف القناة (Channel ID)')
      .setPlaceholder('مثال: 123456789012345678')
      .setStyle(TextInputStyle.Short)
      .setRequired(false)
      .setMaxLength(20);
    if (guildConfig.welcome?.channelId) input.setValue(guildConfig.welcome.channelId);
    modal.addComponents(new ActionRowBuilder().addComponents(input));
    await interaction.showModal(modal);
  },

  /** Open modal to edit welcome message. customId: swl_welcome_message */
  swl_welcome_message: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const { ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
    const modal = new ModalBuilder()
      .setCustomId('swl_modal_welcome_message')
      .setTitle('رسالة الترحيب (Welcome Message)');
    const input = new TextInputBuilder()
      .setCustomId('value')
      .setLabel('نص الرسالة')
      .setPlaceholder('{user} {username} {server} {memberCount}')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(false)
      .setMaxLength(1500);
    const current = guildConfig.welcome?.message;
    if (current) input.setValue(current);
    modal.addComponents(new ActionRowBuilder().addComponents(input));
    await interaction.showModal(modal);
  },

  /** Toggle welcome DM on/off. customId: swl_welcome_dm_toggle */
  swl_welcome_dm_toggle: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const newEnabled = !guildConfig.welcome?.dm?.enabled;
    await GuildConfig.updateOne(
      { guildId: interaction.guildId },
      { $set: { 'welcome.dm.enabled': newEnabled } }
    );
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view  = buildWelcomeView(settings, fresh);
    await interaction.update({ embeds: view.embeds, components: view.components });
  },

  /** Show a preview of the welcome message (ephemeral). customId: swl_welcome_preview */
  swl_welcome_preview: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const previewEmbed = buildPreviewEmbed(settings, guildConfig, 'welcome');
    await interaction.reply({ embeds: [previewEmbed], ephemeral: true });
  },

  /** Toggle goodbye system on/off. customId: swl_goodbye_toggle */
  swl_goodbye_toggle: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const newEnabled = !guildConfig.goodbye?.enabled;
    await GuildConfig.updateOne(
      { guildId: interaction.guildId },
      { $set: { 'goodbye.enabled': newEnabled } }
    );
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view  = buildWelcomeView(settings, fresh);
    await interaction.update({ embeds: view.embeds, components: view.components });
  },

  /** Open modal to set goodbye channel ID. customId: swl_goodbye_channel */
  swl_goodbye_channel: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const { ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
    const modal = new ModalBuilder()
      .setCustomId('swl_modal_goodbye_channel')
      .setTitle('قناة الوداع (Leave Channel)');
    const input = new TextInputBuilder()
      .setCustomId('value')
      .setLabel('معرّف القناة (Channel ID)')
      .setPlaceholder('مثال: 123456789012345678')
      .setStyle(TextInputStyle.Short)
      .setRequired(false)
      .setMaxLength(20);
    if (guildConfig.goodbye?.channelId) input.setValue(guildConfig.goodbye.channelId);
    modal.addComponents(new ActionRowBuilder().addComponents(input));
    await interaction.showModal(modal);
  },

  /** Open modal to edit goodbye message. customId: swl_goodbye_message */
  swl_goodbye_message: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const { ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
    const modal = new ModalBuilder()
      .setCustomId('swl_modal_goodbye_message')
      .setTitle('رسالة الوداع (Leave Message)');
    const input = new TextInputBuilder()
      .setCustomId('value')
      .setLabel('نص الرسالة')
      .setPlaceholder('{user} {username} {server} {memberCount}')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(false)
      .setMaxLength(1500);
    const current = guildConfig.goodbye?.message;
    if (current) input.setValue(current);
    modal.addComponents(new ActionRowBuilder().addComponents(input));
    await interaction.showModal(modal);
  },

  /** Show a preview of the goodbye message (ephemeral). customId: swl_goodbye_preview */
  swl_goodbye_preview: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const previewEmbed = buildPreviewEmbed(settings, guildConfig, 'goodbye');
    await interaction.reply({ embeds: [previewEmbed], ephemeral: true });
  },

  // ═══════════════════════════════════════════════════════════════════════════
  // Task 39 — Logging Settings UI (slg_*)
  // ═══════════════════════════════════════════════════════════════════════════

  /**
   * Open a modal so the admin can type in the Channel ID for log events.
   * customId: slg_channel
   */
  slg_channel: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const { ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
    const modal = new ModalBuilder()
      .setCustomId('slg_modal_channel')
      .setTitle('قناة السجلات (Logging Channel)');
    const input = new TextInputBuilder()
      .setCustomId('value')
      .setLabel('معرّف القناة (Channel ID)')
      .setPlaceholder('مثال: 123456789012345678')
      .setStyle(TextInputStyle.Short)
      .setRequired(false)
      .setMaxLength(20);
    const currentId = guildConfig.logging?.channelId;
    if (currentId) input.setValue(currentId);
    modal.addComponents(new ActionRowBuilder().addComponents(input));
    await interaction.showModal(modal);
  },

  /**
   * Toggle the master logging enabled flag.
   * customId: slg_toggle
   */
  slg_toggle: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const newEnabled = !guildConfig.logging?.enabled;
    await GuildConfig.updateOne(
      { guildId: interaction.guildId },
      { $set: { 'logging.enabled': newEnabled } }
    );
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view  = buildLoggingView(settings, fresh);
    await interaction.update({ embeds: view.embeds, components: view.components });
  },


  /**
   * Toggle a specific log event type on/off.
   * customId: slg_event:<eventKey>  (e.g. slg_event:messageDelete)
   * The router matches on prefix "slg_event" via startsWith("slg_event:").
   */
  'slg_event': async (interaction) => {
    const eventKey  = interaction.customId.slice('slg_event:'.length);
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const currentEvents = guildConfig.logging?.events || {};
    const currentValue  = currentEvents[eventKey] !== false; // default true
    const newValue      = !currentValue;
    await GuildConfig.updateOne(
      { guildId: interaction.guildId },
      { $set: { [`logging.events.${eventKey}`]: newValue } }
    );
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view  = buildLoggingView(settings, fresh);
    await interaction.update({ embeds: view.embeds, components: view.components });
  },

  /**
   * Task 38 — Home button on the general `/settings` dashboard.
   * Back and Home intentionally share the same destination until later
   * tasks add nested setting screens.
   */
  settings_home: async (interaction) => {
    await renderSettingsHome(interaction);
  },

  /** Task 38 — Back button from a `/settings` section view. */
  settings_back: async (interaction) => {
    await renderSettingsHome(interaction);
  },

  /** Task 38 — Close the `/settings` dashboard and remove its controls. */
  settings_close: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر (Manage Server) لاستخدام لوحة الإعدادات.')], ephemeral: true });
    }

    const { embeds, components } = buildSettingsClosedView(settings);
    await interaction.update({ embeds, components });
  },

  // ── Task 45 — Leveling section buttons ──────────────────────────────────
  [SLV_TOGGLE_ID]:           async (i) => handleLevelingButton(i),
  [SLV_ANNOUNCE_TOGGLE_ID]:  async (i) => handleLevelingButton(i),
  [SLV_ANNOUNCE_CHANNEL_ID]: async (i) => handleLevelingButton(i),
  [SLV_XP_RANGE_ID]:         async (i) => handleLevelingButton(i),
  [SLV_COOLDOWN_ID]:         async (i) => handleLevelingButton(i),
  [SLV_VOICE_TOGGLE_ID]:     async (i) => handleLevelingButton(i),
  [SLV_VOICE_XP_ID]:         async (i) => handleLevelingButton(i),
  [SLV_VOICE_MIN_ID]:        async (i) => handleLevelingButton(i),

  // ── Task 45 — Economy section buttons ───────────────────────────────────
  [SEC_TOGGLE_ID]:          async (i) => handleEconomyButton(i),
  [SEC_CURRENCY_NAME_ID]:   async (i) => handleEconomyButton(i),
  [SEC_CURRENCY_SYMBOL_ID]: async (i) => handleEconomyButton(i),
  [SEC_DAILY_ID]:           async (i) => handleEconomyButton(i),
  [SEC_WORK_ID]:            async (i) => handleEconomyButton(i),
  [SEC_WORK_COOLDOWN_ID]:   async (i) => handleEconomyButton(i),

  // ── Task 45 — Moderation section buttons ─────────────────────────────────
  [SMD_APPROVALS_TOGGLE_ID]:   async (i) => handleModerationSettingsButton(i),
  [SMD_REVIEW_CHANNEL_ID]:     async (i) => handleModerationSettingsButton(i),
  [SMD_GHOSTPING_TOGGLE_ID]:   async (i) => handleModerationSettingsButton(i),
  [SMD_BAN_LIMITS_TOGGLE_ID]:  async (i) => handleModerationSettingsButton(i),
  [SMD_KICK_LIMITS_TOGGLE_ID]: async (i) => handleModerationSettingsButton(i),

  // ── Task 45 — Music section buttons ──────────────────────────────────────
  [SMU_247_TOGGLE_ID]: async (i) => handleMusicButton(i),
  [SMU_247_VOICE_ID]:  async (i) => handleMusicButton(i),
  [SMU_247_TEXT_ID]:   async (i) => handleMusicButton(i),

  /**
   * Task 32 — Home button on the Tickets Dashboard. Returns to the
   * section list from a section view. customId: ticketdash_home. Mirrors
   * admin_home above exactly (see that handler's doc comment) but points
   * at utils/ticketDashboard.js instead of utils/adminDashboard.js, and
   * uses the ManageGuild-tier isGuildManager() check that `/tickets`
   * itself uses (same tier as `/ticketsetup`, not the Administrator-only
   * gate `/admin` uses).
   */
  ticketdash_home: async (interaction) => {
    await renderTicketDashHome(interaction);
  },

  /**
   * Task 32 — Back button on a Tickets Dashboard section view. At the
   * current single-level depth (Home -> one Section) this lands on the
   * same Home view as ticketdash_home above, same as admin_back does for
   * `/admin` (see utils/ticketDashboard.js's top comment). customId:
   * ticketdash_back.
   */
  ticketdash_back: async (interaction) => {
    await renderTicketDashHome(interaction);
  },

  /**
   * Task 32 — Close button on the Tickets Dashboard (present on every
   * view: Home and every Section). Replaces the panel with a plain
   * "closed" notice and removes all components, rather than just
   * deleting the message, so the ephemeral reply doesn't vanish
   * abruptly. customId: ticketdash_close.
   */
  ticketdash_close: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر (Manage Server) لاستخدام لوحة إدارة التذاكر.')], ephemeral: true });
    }

    const { embeds, components } = buildTicketDashClosedView(settings);
    await interaction.update({ embeds, components });
  },

  // ════════════════════════════════════════════════════════════════════════
  // Tasks 33-37 — Ticket Dashboard: Settings / Categories / Roles / Messages / Panels
  // ════════════════════════════════════════════════════════════════════════

  // ── Task 33: Settings buttons ──────────────────────────────────────────

  /** Toggle ticket system on/off. customId: tds_settings_toggle */
  tds_settings_toggle: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const newVal = !guildConfig.tickets.enabled;
    await GuildConfig.updateOne({ guildId: interaction.guildId }, { $set: { 'tickets.enabled': newVal } });
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view = buildSettingsView(settings, fresh);
    await interaction.update({ embeds: view.embeds, components: view.components });
  },

  /** Open modal to set log channel. customId: tds_settings_logchannel */
  tds_settings_logchannel: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    await interaction.showModal(buildChannelModal({
      customId: 'tds_modal_logchannel',
      title: 'قناة السجلات',
      label: 'معرّف قناة السجلات (Channel ID)',
      currentValue: guildConfig.tickets?.logChannelId || '',
    }));
  },

  /** Open modal to set transcript channel. customId: tds_settings_transcript */
  tds_settings_transcript: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    await interaction.showModal(buildChannelModal({
      customId: 'tds_modal_transcript',
      title: 'قناة النسخ (Transcript)',
      label: 'معرّف قناة النسخ (Channel ID)',
      currentValue: guildConfig.tickets?.transcriptChannelId || '',
    }));
  },

  /** Open modal to set auto-delete time. customId: tds_settings_deletetime */
  tds_settings_deletetime: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    await interaction.showModal(buildMinutesModal({
      customId: 'tds_modal_deletetime',
      title: 'وقت الحذف التلقائي',
      label: 'عدد الدقائق (0 = تعطيل)',
      placeholder: 'مثال: 240 (أي 4 ساعات)',
      currentValue: guildConfig.tickets?.closePrompt?.autoDeleteMinutes ?? 240,
    }));
  },

  /** Toggle autoClaim. customId: tds_settings_autoclaim */
  tds_settings_autoclaim: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const newVal = !guildConfig.tickets?.autoClaim;
    await GuildConfig.updateOne({ guildId: interaction.guildId }, { $set: { 'tickets.autoClaim': newVal } });
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view = buildSettingsView(settings, fresh);
    await interaction.update({ embeds: view.embeds, components: view.components });
  },

  /** Open modal to set auto-close time. customId: tds_settings_autoclose */
  tds_settings_autoclose: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    await interaction.showModal(buildMinutesModal({
      customId: 'tds_modal_autoclose',
      title: 'الإغلاق التلقائي',
      label: 'عدد الدقائق (0 = تعطيل)',
      placeholder: 'مثال: 1440 (أي يوم كامل)',
      currentValue: guildConfig.tickets?.autoCloseMinutes ?? 0,
    }));
  },

  /** Open modal to set reminder time. customId: tds_settings_reminder */
  tds_settings_reminder: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    await interaction.showModal(buildMinutesModal({
      customId: 'tds_modal_reminder',
      title: 'وقت التذكير',
      label: 'عدد الدقائق بعد آخر رد (0 = تعطيل)',
      placeholder: 'مثال: 60 (أي ساعة)',
      currentValue: guildConfig.tickets?.reminderMinutes ?? 0,
    }));
  },

  /** Toggle smartMention. customId: tds_settings_smartmention */
  tds_settings_smartmention: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const newVal = !guildConfig.tickets?.smartMention;
    await GuildConfig.updateOne({ guildId: interaction.guildId }, { $set: { 'tickets.smartMention': newVal } });
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view = buildSettingsView(settings, fresh);
    await interaction.update({ embeds: view.embeds, components: view.components });
  },

  // ── Task 44: remaining Settings buttons (default category, close-prompt
  //    warning timer, close-prompt reset) - closes the last gaps left over
  //    from /ticketsetup config/closeprompt that Task 33 didn't cover. ──

  /** Open modal to set the default ticket category. customId: tds_settings_category */
  tds_settings_category: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    await interaction.showModal(buildChannelModal({
      customId: 'tds_modal_category',
      title: 'الفئة الافتراضية (Category)',
      label: 'معرّف الفئة (Category ID)',
      currentValue: guildConfig.tickets?.categoryId || '',
    }));
  },

  /** Open modal to set the close-prompt 🔴 warning timer. customId: tds_settings_warningtime */
  tds_settings_warningtime: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    await interaction.showModal(buildMinutesModal({
      customId: 'tds_modal_warningtime',
      title: 'وقت تحذير الحذف 🔴',
      label: 'الدقائق المتبقية عند التحذير (0 = تعطيل)',
      placeholder: 'مثال: 30',
      currentValue: guildConfig.tickets?.closePrompt?.warningMinutes ?? 30,
    }));
  },

  /** Ask for typed confirmation before resetting close-prompt text/timers. customId: tds_settings_closepromptreset */
  tds_settings_closepromptreset: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    await interaction.showModal(buildClosePromptResetModal());
  },

  // ── Task 34: Categories buttons ────────────────────────────────────────

  /** Open modal to add a new ticket type. customId: tds_categories_add */
  tds_categories_add: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    if ((guildConfig.tickets?.types || []).length >= 25) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'وصلت للحد الأقصى (25 نوع).')], ephemeral: true });
    }
    await interaction.showModal(buildCategoryModal({ customId: 'tds_modal_category_add', title: 'إضافة نوع تذكرة جديد' }));
  },

  /** Open modal to edit an existing ticket type. customId: tds_categories_edit */
  tds_categories_edit: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    // Editing: modal asks for typeId first then pre-fills from existing
    await interaction.showModal(buildCategoryModal({ customId: 'tds_modal_category_edit', title: 'تعديل نوع تذكرة (أدخل معرّفه أولاً)' }));
  },

  /** Open modal to delete a ticket type (asks for typeId confirmation). customId: tds_categories_delete */
  tds_categories_delete: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    await interaction.showModal(buildCategoryDeleteModal());
  },

  // ── Task 35: Roles buttons ─────────────────────────────────────────────

  /** Open modal to change support role. customId: tds_roles_support */
  tds_roles_support: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    await interaction.showModal(buildRoleModal({
      customId: 'tds_modal_role_support',
      title: 'رتبة الدعم (Support Role)',
      label: 'معرّف الرتبة (Role ID)',
      currentValue: guildConfig.tickets?.supportRoleId || '',
    }));
  },

  /** Open modal to change moderator role. customId: tds_roles_moderator */
  tds_roles_moderator: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    await interaction.showModal(buildRoleModal({
      customId: 'tds_modal_role_moderator',
      title: 'رتبة الإشراف (Moderator Role)',
      label: 'معرّف الرتبة (Role ID)',
      currentValue: guildConfig.modRoleId || '',
    }));
  },

  /** Open modal to change admin role. customId: tds_roles_admin */
  tds_roles_admin: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    await interaction.showModal(buildRoleModal({
      customId: 'tds_modal_role_admin',
      title: 'رتبة الإدارة (Admin Role)',
      label: 'معرّف الرتبة (Role ID)',
      currentValue: guildConfig.adminRoleId || '',
    }));
  },

  // ── Task 37: Panel Builder buttons ──────────────────────────────────────

  /** Open the modal for the single ticket button label used by the builder. */
  tds_panels_label: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }

    await interaction.showModal(buildMessageModal({
      customId: 'tds_modal_panel_label',
      title: 'اسم زر فتح التذكرة',
      label: 'اسم الزر (من 1 إلى 80 حرفاً)',
      placeholder: 'مثال: فتح تذكرة الدعم',
      currentValue: guildConfig.tickets?.panelBuilder?.buttonLabel || 'فتح تذكرة',
      maxLength: 80,
      required: true,
      style: TextInputStyle.Short,
    }));
  },

  /** Open the modal for the emoji used by the builder's ticket button. */
  tds_panels_emoji: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }

    await interaction.showModal(buildMessageModal({
      customId: 'tds_modal_panel_emoji',
      title: 'إيموجي زر التذكرة',
      label: 'الإيموجي (مثال: 🎫 أو :ticket:)',
      placeholder: '🎫',
      currentValue: guildConfig.tickets?.panelBuilder?.emoji || '🎫',
      maxLength: 32,
      required: true,
      style: TextInputStyle.Short,
    }));
  },

  /**
   * Persist the builder and publish the panel. If the previous published
   * message is still available in the selected channel, update it instead
   * of creating duplicates.
   */
  tds_panels_save: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }

    if (!guildConfig.tickets?.enabled) {
      return interaction.reply({
        embeds: [errorEmbed(settings, 'فعّل نظام التذاكر أولاً من قسم الإعدادات، ثم احفظ اللوحة وأرسلها.')],
        ephemeral: true,
      });
    }

    const builder = guildConfig.tickets.panelBuilder || {};
    const buttonLabel = builder.buttonLabel?.trim();
    const emoji = builder.emoji?.trim();
    if (!builder.channelId || !builder.categoryId || !buttonLabel || !emoji) {
      return interaction.reply({
        embeds: [errorEmbed(settings, 'أكمل اختيار قناة النشر وCategory واسم الزر والإيموجي قبل الحفظ والإرسال.')],
        ephemeral: true,
      });
    }

    await interaction.deferUpdate();

    let panelChannel;
    let category;
    try {
      panelChannel = await interaction.guild.channels.fetch(builder.channelId);
      category = await interaction.guild.channels.fetch(builder.categoryId);
    } catch (err) {
      logger.error(`تعذر جلب قناة منشئ لوحة التذاكر: ${err.stack || err}`);
      return interaction.editReply({
        embeds: [errorEmbed(settings, 'تعذر الوصول إلى القناة أو الـCategory المحددين. تأكد من وجودهما وصلاحيات البوت.')],
        components: [],
      });
    }

    if (!panelChannel || panelChannel.type !== ChannelType.GuildText) {
      return interaction.editReply({
        embeds: [errorEmbed(settings, 'قناة نشر اللوحة غير صالحة. اختر قناة نصية من القائمة.')],
        components: [],
      });
    }
    if (!category || category.type !== ChannelType.GuildCategory) {
      return interaction.editReply({
        embeds: [errorEmbed(settings, 'الـCategory المحدد غير صالح أو لم يعد موجوداً.')],
        components: [],
      });
    }

    let message;
    try {
      if (guildConfig.tickets.panelChannelId === panelChannel.id && guildConfig.tickets.panelMessageId) {
        let previousMessage = null;
        try {
          previousMessage = await panelChannel.messages.fetch(guildConfig.tickets.panelMessageId);
        } catch (err) {
          logger.warn(`تعذر العثور على لوحة التذاكر السابقة ${guildConfig.tickets.panelMessageId}: ${err.message}`);
        }

        if (previousMessage?.editable) {
          message = await previousMessage.edit({
            embeds: [buildPanelEmbed(settings, guildConfig)],
            components: buildPanelComponents(guildConfig),
          });
        }
      }

      if (!message) {
        message = await panelChannel.send({
          embeds: [buildPanelEmbed(settings, guildConfig)],
          components: buildPanelComponents(guildConfig),
        });
      }
    } catch (err) {
      logger.error(`فشل نشر لوحة التذاكر من الواجهة: ${err.stack || err}`);
      return interaction.editReply({
        embeds: [errorEmbed(settings, 'تعذر إرسال اللوحة. تأكد من صلاحية البوت لإرسال الرسائل والـEmbeds والأزرار في القناة المحددة.')],
        components: [],
      });
    }

    await GuildConfig.updateOne(
      { guildId: interaction.guildId },
      {
        $set: {
          'tickets.panelBuilder.channelId': panelChannel.id,
          'tickets.panelBuilder.categoryId': category.id,
          'tickets.panelBuilder.buttonLabel': buttonLabel,
          'tickets.panelBuilder.emoji': emoji,
          'tickets.categoryId': category.id,
          'tickets.panelChannelId': panelChannel.id,
          'tickets.panelMessageId': message.id,
        },
      }
    );
    invalidateGuildConfig(interaction.guildId);

    const fresh = await getGuildConfig(interaction.guildId);
    const view = buildPanelsView(settings, fresh);
    await interaction.editReply({ embeds: view.embeds, components: view.components });
    return interaction.followUp({
      embeds: [successEmbed(settings, `تم حفظ وإرسال لوحة التذاكر في ${panelChannel}.`)],
      ephemeral: true,
    });
  },

  // ── Task 36: Messages buttons ──────────────────────────────────────────

  /** Open modal to edit panel title. customId: tds_messages_paneltitle */
  tds_messages_paneltitle: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    await interaction.showModal(buildMessageModal({
      customId: 'tds_modal_paneltitle',
      title: 'عنوان لوحة التذاكر',
      label: 'العنوان (اتركه فارغاً للافتراضي)',
      placeholder: 'مثال: 🎫 مركز الدعم',
      currentValue: guildConfig.tickets?.panelTitle || '',
      maxLength: 256,
      style: TextInputStyle.Short,
    }));
  },

  /** Open modal to edit panel description. customId: tds_messages_paneldesc */
  tds_messages_paneldesc: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    await interaction.showModal(buildMessageModal({
      customId: 'tds_modal_paneldesc',
      title: 'وصف لوحة التذاكر',
      label: 'الوصف (اتركه فارغاً للافتراضي)',
      placeholder: 'اشرح هنا كيفية استخدام نظام التذاكر',
      currentValue: guildConfig.tickets?.panelDescription || '',
      maxLength: 2000,
    }));
  },

  /** Open modal to edit panel rules. customId: tds_messages_panelrules */
  tds_messages_panelrules: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    await interaction.showModal(buildMessageModal({
      customId: 'tds_modal_panelrules',
      title: 'قوانين لوحة التذاكر',
      label: 'القوانين (اتركه فارغاً للحذف، \\n = سطر جديد)',
      placeholder: 'مثال: • لا ترسل أكثر من تذكرة\\n• كن محترماً',
      currentValue: guildConfig.tickets?.panelRules || '',
      maxLength: 1024,
    }));
  },

  /** Open modal to edit close prompt message. customId: tds_messages_closemsg */
  tds_messages_closemsg: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    await interaction.showModal(buildMessageModal({
      customId: 'tds_modal_closemsg',
      title: 'رسالة تأكيد الإغلاق',
      label: 'الرسالة (متغيرات: {number} {type} {minutes})',
      placeholder: 'سيتم حذف التذكرة #{number} خلال {minutes} دقيقة',
      currentValue: guildConfig.tickets?.closePrompt?.message || '',
      maxLength: 1000,
    }));
  },

  /** Open modal to edit delete button label. customId: tds_messages_deletebtn */
  tds_messages_deletebtn: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    await interaction.showModal(buildMessageModal({
      customId: 'tds_modal_deletebtn',
      title: 'نص زر الحذف',
      label: 'نص الزر (اتركه فارغاً للافتراضي)',
      placeholder: 'مثال: 🗑️ حذف نهائي',
      currentValue: guildConfig.tickets?.closePrompt?.deleteButtonLabel || '',
      maxLength: 80,
      style: TextInputStyle.Short,
    }));
  },

  /** Open modal to edit reopen button label. customId: tds_messages_reopenbtn */
  tds_messages_reopenbtn: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    await interaction.showModal(buildMessageModal({
      customId: 'tds_modal_reopenbtn',
      title: 'نص زر إعادة الفتح',
      label: 'نص الزر (اتركه فارغاً للافتراضي)',
      placeholder: 'مثال: 🔓 إعادة فتح',
      currentValue: guildConfig.tickets?.closePrompt?.reopenButtonLabel || '',
      maxLength: 80,
      style: TextInputStyle.Short,
    }));
  },

  /** Open modal to edit rating prompt message. customId: tds_messages_ratingprompt */
  tds_messages_ratingprompt: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    await interaction.showModal(buildMessageModal({
      customId: 'tds_modal_ratingprompt',
      title: 'رسالة طلب التقييم',
      label: 'الرسالة (اتركه فارغاً للافتراضي)',
      placeholder: 'شكراً لتواصلك. كيف تقيّم تجربتك؟',
      currentValue: guildConfig.tickets?.ratings?.promptMessage || '',
      maxLength: 500,
    }));
  },

  // ───────────────────────────────────────────────────────────────────────────
  // Task 41 — Protection Settings UI (spt_*)
  // ───────────────────────────────────────────────────────────────────────────

  /** Toggle Anti-Raid on/off. customId: spt_antiraid_toggle */
  spt_antiraid_toggle: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    guildConfig.antiRaid.enabled = !guildConfig.antiRaid.enabled;
    await guildConfig.save();
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view  = buildProtectionView(resolved(fresh), fresh);
    await interaction.update({ embeds: view.embeds, components: view.components });
  },

  /** Open modal to configure Anti-Raid join threshold + window. customId: spt_antiraid_threshold */
  spt_antiraid_threshold: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const modal = new ModalBuilder()
      .setCustomId('spt_modal_antiraid_threshold')
      .setTitle('إعداد حد الانضمامات — Anti-Raid')
      .addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('join_threshold')
            .setLabel('عدد الانضمامات التي تُفعّل الاستجابة')
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
            .setMinLength(1)
            .setMaxLength(4)
            .setValue(String(guildConfig.antiRaid?.joinThreshold ?? 8))
        ),
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('window_seconds')
            .setLabel('المدة الزمنية بالثواني')
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
            .setMinLength(1)
            .setMaxLength(5)
            .setValue(String(Math.round((guildConfig.antiRaid?.windowMs ?? 10000) / 1000)))
        ),
      );
    await interaction.showModal(modal);
  },

  /** Open modal to configure Anti-Raid action. customId: spt_antiraid_action */
  spt_antiraid_action: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const modal = new ModalBuilder()
      .setCustomId('spt_modal_antiraid_action')
      .setTitle('إجراء الرد على الغارة — Anti-Raid')
      .addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('action')
            .setLabel('الإجراء: lockdown / kick / ban')
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
            .setMinLength(3)
            .setMaxLength(8)
            .setValue(guildConfig.antiRaid?.action ?? 'lockdown')
            .setPlaceholder('lockdown أو kick أو ban')
        ),
      );
    await interaction.showModal(modal);
  },

  /** Open modal to configure new account handling. customId: spt_antiraid_newaccounts */
  spt_antiraid_newaccounts: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const modal = new ModalBuilder()
      .setCustomId('spt_modal_antiraid_newaccounts')
      .setTitle('إعداد الحسابات الجديدة — Anti-Raid')
      .addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('min_age_days')
            .setLabel('الحد الأدنى لعمر الحساب بالأيام')
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
            .setMinLength(1)
            .setMaxLength(4)
            .setValue(String(guildConfig.antiRaid?.newAccountAgeDays ?? 7))
        ),
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('new_account_action')
            .setLabel('الإجراء: none / flag / kick')
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
            .setMinLength(3)
            .setMaxLength(4)
            .setValue(guildConfig.antiRaid?.newAccountAction ?? 'flag')
            .setPlaceholder('none أو flag أو kick')
        ),
      );
    await interaction.showModal(modal);
  },

  /** Toggle Anti-Nuke on/off. customId: spt_antinuke_toggle */
  spt_antinuke_toggle: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    guildConfig.antinuke.enabled = !guildConfig.antinuke.enabled;
    await guildConfig.save();
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view  = buildProtectionView(resolved(fresh), fresh);
    await interaction.update({ embeds: view.embeds, components: view.components });
  },

  /** Open modal to set Anti-Nuke punishment. customId: spt_antinuke_punishment */
  spt_antinuke_punishment: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const modal = new ModalBuilder()
      .setCustomId('spt_modal_antinuke_punishment')
      .setTitle('عقوبة المهاجم — Anti-Nuke')
      .addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('punishment')
            .setLabel('العقوبة: stripRoles / kick / ban')
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
            .setMinLength(3)
            .setMaxLength(10)
            .setValue(guildConfig.antinuke?.punishment ?? 'stripRoles')
            .setPlaceholder('stripRoles أو kick أو ban')
        ),
      );
    await interaction.showModal(modal);
  },

  /** Open modal to manage Anti-Nuke whitelist. customId: spt_antinuke_whitelist */
  spt_antinuke_whitelist: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const currentList = (guildConfig.antinuke?.whitelistedUserIds ?? []).join('\n') || '';
    const modal = new ModalBuilder()
      .setCustomId('spt_modal_antinuke_whitelist')
      .setTitle('القائمة الموثوقة — Anti-Nuke')
      .addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('user_ids')
            .setLabel('معرّفات المستخدمين (كل ID في سطر)')
            .setStyle(TextInputStyle.Paragraph)
            .setRequired(false)
            .setMaxLength(1000)
            .setValue(currentList)
            .setPlaceholder('123456789012345678\n987654321098765432')
        ),
      );
    await interaction.showModal(modal);
  },

  /** Open modal to configure Anti-Nuke thresholds. customId: spt_antinuke_thresholds */
  spt_antinuke_thresholds: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const t = guildConfig.antinuke?.thresholds ?? {};
    const modal = new ModalBuilder()
      .setCustomId('spt_modal_antinuke_thresholds')
      .setTitle('حدود الأحداث — Anti-Nuke')
      .addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('channel_delete')
            .setLabel('حذف قنوات (channelDelete)')
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
            .setMinLength(1)
            .setMaxLength(3)
            .setValue(String(t.channelDelete ?? 3))
        ),
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('role_delete')
            .setLabel('حذف رتب (roleDelete)')
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
            .setMinLength(1)
            .setMaxLength(3)
            .setValue(String(t.roleDelete ?? 3))
        ),
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('member_ban')
            .setLabel('حظر أعضاء (memberBan)')
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
            .setMinLength(1)
            .setMaxLength(3)
            .setValue(String(t.memberBan ?? 3))
        ),
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('webhook_create')
            .setLabel('إنشاء Webhooks (webhookCreate)')
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
            .setMinLength(1)
            .setMaxLength(3)
            .setValue(String(t.webhookCreate ?? 3))
        ),
      );
    await interaction.showModal(modal);
  },

  /** Toggle AutoMod master switch. customId: spt_automod_toggle */
  spt_automod_toggle: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    guildConfig.automod.enabled = !guildConfig.automod.enabled;
    await guildConfig.save();
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view  = buildProtectionView(resolved(fresh), fresh);
    await interaction.update({ embeds: view.embeds, components: view.components });
  },

  /** Open AutoMod checks sub-page. customId: spt_automod_checks */
  spt_automod_checks: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const view = buildAutomodChecksView(settings, guildConfig);
    await interaction.update({ embeds: view.embeds, components: view.components });
  },

  /** Back button from AutoMod checks sub-page → return to main protection view. customId: spt_automod_checks_back */
  spt_automod_checks_back: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const view = buildProtectionView(settings, guildConfig);
    await interaction.update({ embeds: view.embeds, components: view.components });
  },

  /**
   * Toggle individual AutoMod check on/off.
   * customId: spt_automod_check_toggle:<checkKey>  (e.g. spt_automod_check_toggle:antiSpam)
   * Router matches via startsWith('spt_automod_check_toggle:').
   */
  spt_automod_check_toggle: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const checkKey = interaction.customId.slice('spt_automod_check_toggle:'.length);
    const validCheck = CHECKS.find((c) => c.key === checkKey);
    if (!validCheck) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'فحص AutoMod غير معروف.')], ephemeral: true });
    }
    if (!guildConfig.automod.checks[checkKey]) {
      guildConfig.automod.checks[checkKey] = {};
    }
    guildConfig.automod.checks[checkKey].enabled = !guildConfig.automod.checks[checkKey].enabled;
    guildConfig.markModified('automod.checks');
    await guildConfig.save();
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view  = buildAutomodChecksView(resolved(fresh), fresh);
    await interaction.update({ embeds: view.embeds, components: view.components });
  },

  /**
   * Open modal to set punishment for individual AutoMod check.
   * customId: spt_automod_check_punishment:<checkKey>
   * Router matches via startsWith('spt_automod_check_punishment:').
   */
  spt_automod_check_punishment: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const checkKey = interaction.customId.slice('spt_automod_check_punishment:'.length);
    const validCheck = CHECKS.find((c) => c.key === checkKey);
    if (!validCheck) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'فحص AutoMod غير معروف.')], ephemeral: true });
    }
    const currentPunishment = guildConfig.automod.checks[checkKey]?.punishment || 'delete';
    const currentTimeout    = guildConfig.automod.checks[checkKey]?.timeoutMinutes || 10;
    const modal = new ModalBuilder()
      .setCustomId(`spt_modal_automod_punishment:${checkKey}`)
      .setTitle(`عقوبة ${validCheck.label}`)
      .addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('punishment')
            .setLabel('العقوبة: delete / warn / timeout / kick / ban')
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
            .setMinLength(3)
            .setMaxLength(7)
            .setValue(currentPunishment)
            .setPlaceholder('delete أو warn أو timeout أو kick أو ban')
        ),
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('timeout_minutes')
            .setLabel('مدة Timeout بالدقائق (إذا اخترت timeout)')
            .setStyle(TextInputStyle.Short)
            .setRequired(false)
            .setMinLength(1)
            .setMaxLength(5)
            .setValue(String(currentTimeout))
            .setPlaceholder('10')
        ),
      );
    await interaction.showModal(modal);
  },

  // ─── Music Request Panel (mr-*) ────────────────────────────────────────────
  // These IDs are produced by /setup-music-request and point to a persistent
  // panel message in a dedicated music-request channel.  They map 1-to-1 to
  // the equivalent music_* handlers already registered above; volume buttons
  // adjust by ±10% (clamped to 0-100) mirroring /volume command behaviour.

  /** ⏯️ Pause/resume from the music-request panel. customId: mr-playpause */
  'mr-playpause': async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    const queue = await requireActiveQueue(interaction, settings);
    if (!queue) return;
    const nowPaused = !queue.node.isPaused();
    queue.node.setPaused(nowPaused);
    if (!nowPaused && queue.metadata) queue.metadata.autoPausedForEmpty = false;
    await interaction.deferUpdate().catch(() => null);
  },

  /** ⏭️ Skip from the music-request panel. customId: mr-skip */
  'mr-skip': async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    const queue = await requireActiveQueue(interaction, settings);
    if (!queue) return;
    const skipped = queue.currentTrack;
    queue.node.skip();
    await interaction.reply({
      embeds: [successEmbed(settings, `⏭️ Skipped **${skipped?.title ?? 'track'}** — <@${interaction.user.id}>`)],
      ephemeral: true,
    });
  },

  /** ⏹️ Stop from the music-request panel. customId: mr-stop */
  'mr-stop': async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    const queue = await requireActiveQueue(interaction, settings);
    if (!queue) return;
    queue.delete();
    await interaction.reply({
      embeds: [successEmbed(settings, `⏹️ Playback stopped — <@${interaction.user.id}>`)],
      ephemeral: true,
    });
  },

  /** 🔁 Cycle loop mode from the music-request panel. customId: mr-loop */
  'mr-loop': async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    const queue = await requireActiveQueue(interaction, settings);
    if (!queue) return;
    const CYCLE  = [QueueRepeatMode.OFF, QueueRepeatMode.TRACK, QueueRepeatMode.QUEUE];
    const LABELS = {
      [QueueRepeatMode.OFF]:   'disabled',
      [QueueRepeatMode.TRACK]: 'looping the track',
      [QueueRepeatMode.QUEUE]: 'looping the queue',
    };
    const nextMode = CYCLE[(CYCLE.indexOf(queue.repeatMode) + 1) % CYCLE.length];
    queue.setRepeatMode(nextMode);
    await interaction.reply({
      embeds: [successEmbed(settings, `🔁 Loop mode is now **${LABELS[nextMode]}**.`)],
      ephemeral: true,
    });
  },

  /** 🔀 Shuffle queue from the music-request panel. customId: mr-shuffle */
  'mr-shuffle': async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    const queue = await requireActiveQueue(interaction, settings);
    if (!queue) return;
    if (queue.tracks.toArray().length < 2) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'Not enough tracks in the queue to shuffle.')], ephemeral: true });
    }
    queue.tracks.shuffle();
    await interaction.reply({ embeds: [successEmbed(settings, `🔀 Queue shuffled — <@${interaction.user.id}>`)], ephemeral: true });
  },

  /** 🧹 Clear queue from the music-request panel. customId: mr-clear */
  'mr-clear': async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    const queue = await requireActiveQueue(interaction, settings);
    if (!queue) return;
    queue.tracks.clear();
    await interaction.reply({ embeds: [successEmbed(settings, `🧹 Queue cleared — <@${interaction.user.id}>`)], ephemeral: true });
  },

  /** 🔉 Volume -10% from the music-request panel. customId: mr-voldown */
  'mr-voldown': async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    const queue = await requireActiveQueue(interaction, settings);
    if (!queue) return;
    const newVol = Math.max(0, (queue.node.volume ?? 100) - 10);
    queue.node.setVolume(newVol);
    await interaction.reply({ embeds: [successEmbed(settings, `🔉 Volume set to **${newVol}%**.`)], ephemeral: true });
  },

  /** 🔊 Volume +10% from the music-request panel. customId: mr-volup */
  'mr-volup': async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    const queue = await requireActiveQueue(interaction, settings);
    if (!queue) return;
    const newVol = Math.min(100, (queue.node.volume ?? 100) + 10);
    queue.node.setVolume(newVol);
    await interaction.reply({ embeds: [successEmbed(settings, `🔊 Volume set to **${newVol}%**.`)], ephemeral: true });
  },

  /** 🎵 Now Playing — show current track details with controls. customId: mr-nowplaying */
  'mr-nowplaying': async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    const { useQueue } = require('discord-player');
    const { getKazagumo } = require('../services/lavalinkManager');
    const { buildMusicControlsRow } = require('../utils/musicControls');

    const kazagumo = getKazagumo();
    const kazagumoPlayer = kazagumo?.players.get(interaction.guildId);

    if (kazagumoPlayer && kazagumoPlayer.queue.current) {
      const kTrack = kazagumoPlayer.queue.current;
      const embed = baseEmbed(settings)
        .setTitle('🎶 يعمل الآن')
        .setDescription(`[${kTrack.title}](${kTrack.uri})`)
        .setThumbnail(kTrack.thumbnail || null)
        .addFields(
          { name: 'طلب بواسطة', value: `${kTrack.requester ?? 'غير معروف'}`, inline: true },
          { name: 'الصوت', value: `${kazagumoPlayer.volume ?? 100}%`, inline: true },
        );
      const shim = { repeatMode: { none:0,track:1,queue:2 }[kazagumoPlayer.loop] ?? 0, node: { isPaused: () => kazagumoPlayer.paused } };
      return interaction.reply({ embeds: [embed], components: buildMusicControlsRow(shim), ephemeral: true });
    }

    const queue = useQueue(interaction.guildId);
    if (!queue || !queue.currentTrack) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'لا يوجد شيء يعمل حالياً.')], ephemeral: true });
    }
    const track = queue.currentTrack;
    const embed = baseEmbed(settings)
      .setTitle('🎶 يعمل الآن')
      .setDescription(`[${track.title}](${track.url})`)
      .setThumbnail(track.thumbnail || null)
      .addFields(
        { name: 'طلب بواسطة', value: `${track.requestedBy ?? 'غير معروف'}`, inline: true },
        { name: 'الصوت', value: `${queue.node.volume}%`, inline: true },
      );
    return interaction.reply({ embeds: [embed], components: buildMusicControlsRow(queue), ephemeral: true });
  },

  /** 📋 Show queue — display current queue with pagination. customId: mr-queue */
  'mr-queue': async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    const { useQueue } = require('discord-player');
    const { getKazagumo } = require('../services/lavalinkManager');
    const { buildKazagumoQueueView } = require('../utils/musicQueueEmbed');

    const kazagumo = getKazagumo();
    const kazagumoPlayer = kazagumo?.players.get(interaction.guildId);
    if (kazagumoPlayer && kazagumoPlayer.queue.current) {
      const queueView = buildKazagumoQueueView(kazagumoPlayer);
      const { embed, components } = buildQueuePage(queueView, settings, 1);
      return interaction.reply({ embeds: [embed], components, ephemeral: true });
    }
    const queue = useQueue(interaction.guildId);
    if (!queue || !queue.currentTrack) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'لا يوجد شيء في قائمة الانتظار.')], ephemeral: true });
    }
    const { embed, components } = buildQueuePage(queue, settings, 1);
    return interaction.reply({ embeds: [embed], components, ephemeral: true });
  },

  /** ⏩ Seek — open modal to enter timestamp. customId: mr-seek */
  'mr-seek': async (interaction) => {
    const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder: MActionRowBuilder } = require('discord.js');
    const modal = new ModalBuilder()
      .setCustomId('mr_modal_seek')
      .setTitle('⏩ Seek to Timestamp');
    const input = new TextInputBuilder()
      .setCustomId('mr_seek_input')
      .setLabel('Timestamp (e.g. 1:30 or 0:45)')
      .setStyle(TextInputStyle.Short)
      .setPlaceholder('1:30')
      .setRequired(true);
    modal.addComponents(new MActionRowBuilder().addComponents(input));
    await interaction.showModal(modal);
  },

  /** 🎵 Lyrics — show lyrics for current track. customId: mr-lyrics */
  'mr-lyrics': async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    const { useQueue } = require('discord-player');

    const queue = useQueue(interaction.guildId);
    if (!queue?.currentTrack) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'لا يوجد شيء يعمل حالياً.')], ephemeral: true });
    }
    const lyricsHandler = require('../music-handlers/lyrics');
    await lyricsHandler.execute(interaction);
  },

  /** 🎛️ Filters — show audio filter selection. customId: mr-filters */
  'mr-filters': async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    const queue = await requireActiveQueue(interaction, settings);
    if (!queue) return;

    const { ActionRowBuilder: AR, StringSelectMenuBuilder, StringSelectMenuOptionBuilder } = require('discord.js');
    const FILTER_LIST = [
      { label: 'Bass Boost 🎵', value: 'bassboost', description: 'Enhance bass frequencies' },
      { label: 'Nightcore 🌙', value: 'nightcore', description: 'Speed up & pitch up' },
      { label: 'Vaporwave 🌊', value: 'vaporwave', description: 'Slow down & pitch down' },
      { label: '8D Audio 🎧', value: '8D', description: '8D surround sound' },
      { label: 'Karaoke 🎤', value: 'karaoke', description: 'Remove vocals' },
      { label: 'Tremolo 🎸', value: 'tremolo', description: 'Tremolo effect' },
      { label: 'Vibrato 🎹', value: 'vibrato', description: 'Vibrato effect' },
      { label: 'Clear All Filters ❌', value: 'clear', description: 'Remove all filters' },
    ];
    const menu = new StringSelectMenuBuilder()
      .setCustomId('mr_select_filter')
      .setPlaceholder('Choose a filter to toggle...')
      .addOptions(FILTER_LIST.map(f => new StringSelectMenuOptionBuilder().setLabel(f.label).setValue(f.value).setDescription(f.description)));
    const row = new AR().addComponents(menu);
    return interaction.reply({ content: '🎛️ Select a filter to toggle:', components: [row], ephemeral: true });
  },

  /** ❌ Remove track — open modal to enter position. customId: mr-remove */
  'mr-remove': async (interaction) => {
    const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder: MActionRowBuilder } = require('discord.js');
    const modal = new ModalBuilder()
      .setCustomId('mr_modal_remove')
      .setTitle('❌ Remove Track from Queue');
    const input = new TextInputBuilder()
      .setCustomId('mr_remove_input')
      .setLabel('Track position (e.g. 1, 2, 3...)')
      .setStyle(TextInputStyle.Short)
      .setPlaceholder('1')
      .setRequired(true);
    modal.addComponents(new MActionRowBuilder().addComponents(input));
    await interaction.showModal(modal);
  },

  /** 📜 History — show recently played tracks. customId: mr-history */
  'mr-history': async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    const musicHistoryService = require('../services/musicHistoryService');

    const DEFAULT_LIMIT = 10;
    const tracks = await musicHistoryService.getHistory(interaction.guildId, null, DEFAULT_LIMIT);
    if (!tracks?.length) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'لم يتم تشغيل أي أغاني بعد.')], ephemeral: true });
    }
    const list = tracks.map((t, i) => `**${i + 1}.** ${t.title} — ${t.requestedBy || 'Unknown'}`).join('\n');
    const embed = baseEmbed(settings).setTitle('📜 سجل الموسيقى (آخر 10 مقاطع)').setDescription(list);
    return interaction.reply({ embeds: [embed], ephemeral: true });
  },

  /** ❤️ Favorites — show and play favorites. customId: mr-favorites */
  'mr-favorites': async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);

    const favorites = await favoritesService.listFavorites(interaction.user.id);
    if (!favorites?.length) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'ليس لديك أغاني مفضلة.')], ephemeral: true });
    }
    const list = favorites.slice(0, 10).map((f, i) => `**${i + 1}.** ${f.title}`).join('\n');
    const embed = baseEmbed(settings).setTitle('❤️ أغانيك المفضلة').setDescription(list);
    return interaction.reply({ embeds: [embed], ephemeral: true });
  },

  // ── Task-09 Community Settings Dashboard (scd_*) ──────────────────────
  scd_suggest_toggle:  async (i) => handleCommunityButton(i),
  scd_suggest_channel: async (i) => handleCommunityButton(i),
  scd_boost_toggle:    async (i) => handleCommunityButton(i),
  scd_boost_channel:   async (i) => handleCommunityButton(i),
  scd_boost_message:   async (i) => handleCommunityButton(i),
  scd_mc_toggle:       async (i) => handleCommunityButton(i),
  scd_mc_channel:      async (i) => handleCommunityButton(i),
  scd_mc_format:       async (i) => handleCommunityButton(i),
  scd_sb_toggle:       async (i) => handleCommunityButton(i),
  scd_sb_config:       async (i) => handleCommunityButton(i),
  scd_cnt_enable:      async (i) => handleCommunityButton(i),
  scd_cnt_disable:     async (i) => handleCommunityButton(i),
  scd_cnt_reset:       async (i) => handleCommunityButton(i),
};

/** Shared body for admin_home and admin_back (see their doc comments above for why they're two customIds that currently do the same thing). */
async function renderAdminHome(interaction) {
  const guildConfig = await getGuildConfig(interaction.guildId);
  const settings = resolved(guildConfig);

  if (!isGuildManager(interaction.member, guildConfig)) {
    return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر (Manage Server) لاستخدام لوحة الإدارة.')], ephemeral: true });
  }

  const { embeds, components } = buildHomeView(settings, interaction.guild.name);
  await interaction.update({ embeds, components });
}

/** Shared body for ticketdash_home and ticketdash_back (see their doc comments above), mirroring renderAdminHome() but for the Tickets Dashboard's ManageGuild-tier permission check. */
async function renderTicketDashHome(interaction) {
  const guildConfig = await getGuildConfig(interaction.guildId);
  const settings = resolved(guildConfig);

  if (!isGuildManager(interaction.member, guildConfig)) {
    return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر (Manage Server) لاستخدام لوحة إدارة التذاكر.')], ephemeral: true });
  }

  const { embeds, components } = buildTicketDashHomeView(settings, interaction.guild.name);
  await interaction.update({ embeds, components });
}

/** Shared body for settings_home and settings_back. */
async function renderSettingsHome(interaction) {
  const guildConfig = await getGuildConfig(interaction.guildId);
  const settings = resolved(guildConfig);

  if (!isGuildManager(interaction.member, guildConfig)) {
    return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر (Manage Server) لاستخدام لوحة الإعدادات.')], ephemeral: true });
  }

  const { embeds, components } = buildSettingsHomeView(settings, interaction.guild.name);
  await interaction.update({ embeds, components });
}

/**
 * TASK 17 (مزامنة Claim مع واجهة Discord): بعد نجاح استلام تذكرة، يعدّل
 * رسالة اللوحة نفسها (نفس الرسالة التي فيها زر "استلام التذكرة") لتعكس
 * الحالة الجديدة فوراً - بدل بقاء اللوحة كما هي وكأن أحداً لم يستلم شيئاً:
 *   - Embed: يضيف/يحدّث حقل "🛡️ الموظف المستلم" (أو يستبدله إن كانت
 *     التذكرة قد استُلمت واستُلمت مجدداً من موظف آخر).
 *   - Buttons: يحدّث نص زر الاستلام فقط ليظهر اسم المستلم الحالي، دون
 *     تغيير customId أو تعطيله - لأن مهمة 16 أكّدت أن إعادة الاستلام من
 *     موظف آخر سلوك مقصود ويجب أن يبقى ممكناً.
 * لا تُنتظر من المتصل حرجياً (خطأ هنا cosmetic فقط - الاستلام نفسه في
 * قاعدة البيانات نجح بالفعل ورُدّ على الـInteraction) - أي فشل يُسجَّل
 * فقط، مطابقةً لنمط بقية نداءات message.edit في هذا الملف.
 */
async function syncClaimedTicketPanel(message, ticket, claimedByUser) {
  if (!message || !message.editable) return;

  const embeds = message.embeds.map((embed, index) => {
    if (index !== 0) return embed;
    const builder = EmbedBuilder.from(embed);
    const fields = (builder.data.fields || []).slice();
    const claimField = { name: '🛡️ الموظف المستلم', value: `<@${claimedByUser.id}>`, inline: true };
    const existingIndex = fields.findIndex((f) => f.name === claimField.name);
    if (existingIndex >= 0) fields[existingIndex] = claimField;
    else fields.push(claimField);
    return builder.setFields(fields);
  });

  const components = message.components.map((row) => {
    const newRow = new ActionRowBuilder();
    for (const comp of row.components) {
      if (comp.customId === 'ticket_claim') {
        newRow.addComponents(
          ButtonBuilder.from(comp).setLabel(`مُستلمة بواسطة ${claimedByUser.username}`.slice(0, 80))
        );
      } else {
        newRow.addComponents(ButtonBuilder.from(comp));
      }
    }
    return newRow;
  });

  await message.edit({ embeds, components }).catch((err) => {
    logger.warn(`تعذر مزامنة لوحة التذكرة #${ticket.ticketNumber} بعد الاستلام: ${err.message}`);
  });
}

async function handleSuggestionVote(interaction, direction) {
  const guildConfig = await getGuildConfig(interaction.guildId);
  const settings = resolved(guildConfig);

  const suggestion = await Suggestion.findOne({ messageId: interaction.message.id });
  if (!suggestion) {
    return interaction.reply({ embeds: [errorEmbed(settings, 'Suggestion record not found.')], ephemeral: true });
  }

  suggestion.upvotes = suggestion.upvotes.filter((id) => id !== interaction.user.id);
  suggestion.downvotes = suggestion.downvotes.filter((id) => id !== interaction.user.id);

  if (direction === 'up') suggestion.upvotes.push(interaction.user.id);
  else suggestion.downvotes.push(interaction.user.id);

  await suggestion.save();

  const embed = baseEmbed(settings)
    .setAuthor({ name: 'Suggestion' })
    .setDescription(suggestion.content)
    .addFields(
      { name: '👍 Upvotes', value: `${suggestion.upvotes.length}`, inline: true },
      { name: '👎 Downvotes', value: `${suggestion.downvotes.length}`, inline: true }
    );

  await interaction.update({ embeds: [embed] });
}
