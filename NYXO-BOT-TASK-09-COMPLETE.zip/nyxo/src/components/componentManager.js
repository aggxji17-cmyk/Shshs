const logger = require('../utils/logger');

/**
 * Centralized component manager for consistent component registration,
 * lookup, and error handling. Supports buttons, select menus, modals,
 * and any other Discord interaction component.
 *
 * Components are identified by customId prefix matching, allowing flexible
 * routing of component interactions (e.g., "ticket_claim:123" matches the
 * "ticket_claim" handler).
 *
 * Usage:
 *   const manager = new ComponentManager();
 *   manager.register('button_prefix', async (interaction) => { ... });
 *   manager.register('select_prefix', async (interaction) => { ... });
 *
 *   const handler = manager.get('button_prefix:some_id');
 *   if (handler) await handler(interaction);
 */
class ComponentManager {
  constructor() {
    // Map of component prefix -> { handler, type, metadata }
    this.components = new Map();
    // Ordered list of prefixes for longest-match-first lookups
    this.prefixOrder = [];
  }

  /**
   * Registers a component handler by prefix.
   * @param {string} prefix - Component ID prefix (e.g., 'ticket_claim', 'nyxo_page')
   * @param {Function} handler - Async handler function (interaction) => void
   * @param {Object} options - Optional metadata
   *   - type: 'button', 'select', 'modal', or auto-detected
   *   - description: Human-readable description
   *   - requiresGuild: true if component only works in guilds
   */
  register(prefix, handler, options = {}) {
    if (!prefix || typeof prefix !== 'string') {
      throw new Error('Component prefix must be a non-empty string');
    }
    if (typeof handler !== 'function') {
      throw new Error(`Handler for prefix "${prefix}" must be a function`);
    }
    if (this.components.has(prefix)) {
      throw new Error(`Component prefix "${prefix}" is already registered`);
    }

    const component = {
      prefix,
      handler,
      type: options.type || 'unknown',
      description: options.description || '',
      requiresGuild: options.requiresGuild !== false,
      registered: new Date(),
    };

    this.components.set(prefix, component);
    this._updatePrefixOrder();
    logger.info(`Component registered: ${prefix} (${component.type})`);
  }

  /**
   * Updates the prefix order list for longest-match-first lookups.
   * This ensures "ticket_claim:confirm" matches before "ticket".
   */
  _updatePrefixOrder() {
    this.prefixOrder = Array.from(this.components.keys()).sort((a, b) => b.length - a.length);
  }

  /**
   * Looks up a component handler by customId using longest-match-first.
   * Matches both exact prefixes and prefix:suffix patterns.
   * @returns {Function|null} - Handler function or null if not found
   */
  get(customId) {
    if (!customId) return null;

    for (const prefix of this.prefixOrder) {
      if (customId === prefix || customId.startsWith(`${prefix}:`)) {
        const component = this.components.get(prefix);
        return component ? component.handler : null;
      }
    }

    return null;
  }

  /**
   * Checks if a component prefix is registered.
   */
  has(prefix) {
    return this.components.has(prefix);
  }

  /**
   * Looks up the full component entry by customId (internal helper).
   * @returns {Object|null} - Full component entry or null if not found
   */
  _getComponent(customId) {
    if (!customId) return null;

    for (const prefix of this.prefixOrder) {
      if (customId === prefix || customId.startsWith(`${prefix}:`)) {
        return this.components.get(prefix) || null;
      }
    }

    return null;
  }

  /**
   * Executes a component handler by customId with error handling.
   * Checks requiresGuild before running the handler.
   * @returns {Object} - { success: boolean, found: boolean, error: Error|null }
   */
  async execute(customId, interaction) {
    const component = this._getComponent(customId);
    if (!component) {
      // TASK 06 — return found:false so callers can distinguish "no handler"
      // from a genuine runtime error. Previously this returned an Error object
      // which caused handleComponent() to treat a missing handler the same as
      // a crashed handler, logging a false ERROR and skipping the legacy
      // fallback and handleUnknownInteraction() path entirely.
      return { success: false, found: false, error: null };
    }

    // Enforce requiresGuild: components registered with requiresGuild:true
    // (the default) must not run in DM context where interaction.guildId is null.
    if (component.requiresGuild && !interaction.guildId) {
      logger.warn(`Component "${customId}" requires a guild but was invoked outside one (user=${interaction.user?.id})`);
      try {
        if (!interaction.replied && !interaction.deferred) {
          await interaction.reply({ content: 'This action is only available inside a server.', ephemeral: true });
        }
      } catch { /* interaction may have already timed out */ }
      return { success: false, found: true, error: null };
    }

    try {
      await component.handler(interaction);
      return { success: true, found: true, error: null };
    } catch (error) {
      return {
        success: false,
        found: true,
        error,
      };
    }
  }

  /**
   * Finds components by type or metadata.
   * @param {Object} filter - Filter object
   *   - type: 'button', 'select', 'modal'
   *   - prefix: partial prefix match
   * @returns {Array} - Matching components
   */
  find(filter = {}) {
    return Array.from(this.components.values()).filter((comp) => {
      if (filter.type && comp.type !== filter.type) return false;
      if (filter.prefix && !comp.prefix.includes(filter.prefix)) return false;
      return true;
    });
  }

  /**
   * Gets metadata for a registered component.
   */
  getInfo(prefix) {
    const comp = this.components.get(prefix);
    if (!comp) return null;
    return {
      prefix: comp.prefix,
      type: comp.type,
      description: comp.description,
      registered: comp.registered,
    };
  }

  /**
   * Returns a summary of all registered components.
   */
  getStatusReport() {
    const report = {
      total: this.components.size,
      byType: {},
      components: [],
    };

    for (const [prefix, comp] of this.components) {
      if (!report.byType[comp.type]) {
        report.byType[comp.type] = 0;
      }
      report.byType[comp.type]++;

      report.components.push({
        prefix: comp.prefix,
        type: comp.type,
        description: comp.description,
        registered: comp.registered,
      });
    }

    return report;
  }

  /**
   * Unregisters a component (for testing or dynamic reload).
   */
  unregister(prefix) {
    const removed = this.components.delete(prefix);
    if (removed) {
      this._updatePrefixOrder();
      logger.info(`Component unregistered: ${prefix}`);
    }
    return removed;
  }

  /**
   * Clears all components (for testing or complete restart).
   */
  clear() {
    this.components.clear();
    this.prefixOrder = [];
  }

  /**
   * Returns the count of registered components.
   */
  count() {
    return this.components.size;
  }

  /**
   * Bulk registration from an object (legacy compatibility).
   * Useful for migrating from module.exports = { ... }.
   * @param {Object} handlers - Object mapping prefix -> handler function
   * @param {string} type - Component type for all handlers
   */
  registerFromObject(handlers, type = 'unknown') {
    if (typeof handlers !== 'object') {
      throw new Error('Handlers must be an object');
    }

    for (const [prefix, handler] of Object.entries(handlers)) {
      if (typeof handler === 'function') {
        try {
          this.register(prefix, handler, { type });
        } catch (err) {
          logger.warn(`Failed to register component "${prefix}": ${err.message}`);
        }
      }
    }
  }
}

module.exports = ComponentManager;
