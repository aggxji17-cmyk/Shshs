/**
 * Centralized component initializer.
 * Loads all component handlers from their respective modules and
 * registers them with the component manager.
 *
 * This decouples the loading logic from the interaction handler,
 * making it easy to reload components or initialize them at different
 * stages of the bot's lifecycle.
 */

const ComponentManager = require('./componentManager');
const logger = require('../utils/logger');

/**
 * Initializes all components and returns a populated manager.
 * Loads buttons, select menus, and modals from their respective modules.
 *
 * @returns {ComponentManager} - Fully initialized component manager
 */
async function initializeComponents() {
  const manager = new ComponentManager();

  try {
    // Load button handlers
    logger.info('Loading button components...');
    const buttonHandlers = require('./buttons');
    manager.registerFromObject(buttonHandlers, 'button');
    logger.success(`✓ Loaded ${Object.keys(buttonHandlers).length} button handlers`);

    // Load select menu handlers
    logger.info('Loading select menu components...');
    const selectHandlers = require('./selectMenus');
    manager.registerFromObject(selectHandlers, 'select');
    logger.success(`✓ Loaded ${Object.keys(selectHandlers).length} select menu handlers`);

    // Load modal handlers
    logger.info('Loading modal components...');
    const modalHandlers = require('./modals');
    manager.registerFromObject(modalHandlers, 'modal');
    logger.success(`✓ Loaded ${Object.keys(modalHandlers).length} modal handlers`);

    // Log summary
    const report = manager.getStatusReport();
    logger.success(
      `All components loaded: ${report.total} total ` +
        `(${report.byType.button || 0} buttons, ` +
        `${report.byType.select || 0} selects, ` +
        `${report.byType.modal || 0} modals)`
    );

    return manager;
  } catch (error) {
    logger.error(`Failed to initialize components: ${error?.stack || error}`);
    throw error;
  }
}

/**
 * Reloads components from disk and returns a new manager.
 * Useful for development or dynamic component updates.
 * Note: This clears the require cache for component modules.
 *
 * @returns {ComponentManager} - Newly initialized component manager
 */
async function reloadComponents() {
  logger.info('Reloading components...');

  // Clear require cache to pick up file changes
  delete require.cache[require.resolve('./buttons')];
  delete require.cache[require.resolve('./selectMenus')];
  delete require.cache[require.resolve('./modals')];

  return initializeComponents();
}

module.exports = {
  initializeComponents,
  reloadComponents,
};
