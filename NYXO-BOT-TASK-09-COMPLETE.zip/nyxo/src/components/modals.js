const { ChannelType, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');
const { getGuildConfig, resolved, invalidateGuildConfig } = require('../utils/resolveGuildSettings');
const { handleCommunityModal } = require('../utils/communityDashboard');
const { buildLoggingView } = require('../utils/loggingDashboard');
const { buildWelcomeView } = require('../utils/welcomeDashboard');
const { buildProtectionView, buildAutomodChecksView } = require('../utils/protectionDashboard');
// Task 45 — new settings section modal handlers
const { handleLevelingModal, SLV_MODAL_ANNOUNCE_CHANNEL, SLV_MODAL_XP_RANGE, SLV_MODAL_COOLDOWN, SLV_MODAL_VOICE_XP, SLV_MODAL_VOICE_MIN } = require('../utils/levelingDashboard');
const { handleEconomyModal, SEC_MODAL_CURRENCY_NAME, SEC_MODAL_CURRENCY_SYMBOL, SEC_MODAL_DAILY, SEC_MODAL_WORK, SEC_MODAL_WORK_COOLDOWN } = require('../utils/economyDashboard');
const { handleModerationSettingsModal, SMD_MODAL_REVIEW_CHANNEL } = require('../utils/moderationSettingsDashboard');
const { handleMusicModal, SMU_MODAL_247_VOICE, SMU_MODAL_247_TEXT } = require('../utils/musicDashboard');
const { CHECKS } = require('../services/automodChecks');
const { AUTOMOD_PUNISHMENTS } = require('../utils/automodConstants');
// GuildConfig is imported below as GuildConfig
const { successEmbed, errorEmbed, baseEmbed } = require('../utils/embeds');
const { isModerator, isGuildManager } = require('../utils/permissions');
const { buildSettingsView, buildCategoriesView, buildRolesView, buildMessagesView, buildPanelsView } = require('../utils/ticketSettingsUI');
const { applyWarnThresholds } = require('../utils/warnThresholds');
const { sendModerationLog } = require('../utils/moderationLogService');
const { createCase } = require('../services/caseService');
const { findTicketType, resolveTypeTargets, resolveChannelName, resolveWelcomeMessage, buildStatusChannelName } = require('../utils/ticketPanel');
const { postRatingResult, DEFAULT_THANK_YOU_MESSAGE } = require('../services/ratingService');
const { DEFAULT_CLOSE_MESSAGE, DEFAULT_DELETE_LABEL, DEFAULT_REOPEN_LABEL } = require('../services/ticketCloseService');
const Ticket = require('../database/models/Ticket');
const Rating = require('../database/models/Rating');
const Warn = require('../database/models/Warn');
const GuildConfig = require('../database/models/GuildConfig');
const approvalService = require('../services/approvalService');
const logger = require('../utils/logger');

const HEX_COLOR_RE = /^#?[0-9a-fA-F]{6}$/;
const DUPLICATE_KEY_ERROR_CODE = 11000;

/**
 * Task 5 (Race Condition fix): atomically claims the next ticket number
 * for this guild via a direct $inc on GuildConfig.tickets.counter -
 * mirrors nextCaseId in services/caseService.js. This replaces the old
 * `const ticketNumber = tickets.counter + 1; ...; guildConfig.tickets.counter
 * = ticketNumber; await guildConfig.save();` pattern, which read/wrote a
 * guildConfig document that resolveGuildSettings.js caches (and can share
 * across several concurrent interactions for the same guild) for up to
 * 30 seconds - a classic findOne-modify-save race that could hand two
 * different tickets the same number under concurrency. $inc here is a
 * single atomic database operation, so no number can ever be issued
 * twice no matter how many tickets open at once. The cache is
 * invalidated afterwards so any other reader of guildConfig.tickets.counter
 * within that window sees the fresh value instead of a stale one.
 */
async function nextTicketNumber(guildId) {
  const updated = await GuildConfig.findOneAndUpdate(
    { guildId },
    { $inc: { 'tickets.counter': 1 } },
    { new: true, upsert: true, setDefaultsOnInsert: true }
  );
  invalidateGuildConfig(guildId);
  return updated.tickets.counter;
}

module.exports = {
  /** Submission of the reason modal opened by the "Quick Warn" user context menu command. customId: ctxwarn_modal:<targetUserId>. Mirrors /warn's own logic exactly. */
  ctxwarn_modal: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isModerator(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You do not have permission to use this command.')], ephemeral: true });
    }

    const [, targetId] = interaction.customId.split(':');
    const target = await interaction.client.users.fetch(targetId).catch(() => null);
    if (!target) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'That user could no longer be found.')], ephemeral: true });
    }

    const reason = interaction.fields.getTextInputValue('reason');

    await Warn.create({ guildId: interaction.guildId, userId: target.id, moderatorId: interaction.user.id, reason });
    const count = await Warn.countDocuments({ guildId: interaction.guildId, userId: target.id });

    const caseDoc = await createCase({
      guildId: interaction.guildId,
      action: 'warn',
      moderatorId: interaction.user.id,
      targetId: target.id,
      reason,
    });

    await interaction.reply({
      embeds: [successEmbed(settings, `**${target.tag}** has been warned (total: ${count}). Reason: ${reason}\nرقم القضية: #${caseDoc.caseId}`)],
      ephemeral: true,
    });
    await target.send({ embeds: [errorEmbed(settings, `You were warned in **${interaction.guild.name}**: ${reason}`)] }).catch(() => null);

    await applyWarnThresholds(interaction.guild, guildConfig, settings, target.id, count);

    await sendModerationLog(interaction.guild, guildConfig, settings, {
      action: 'warn',
      moderator: interaction.user,
      target,
      reason,
      caseId: caseDoc.caseId,
    });
  },

  embedbuilder_modal: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isModerator(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You do not have permission to send embeds.')], ephemeral: true });
    }

    const [, channelId] = interaction.customId.split(':');
    const channel = interaction.guild.channels.cache.get(channelId);
    if (!channel?.isTextBased()) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'That channel is no longer available.')], ephemeral: true });
    }

    const title = interaction.fields.getTextInputValue('title');
    const description = interaction.fields.getTextInputValue('description');
    const colorInput = interaction.fields.getTextInputValue('color');
    const imageUrl = interaction.fields.getTextInputValue('imageUrl');
    const footer = interaction.fields.getTextInputValue('footer');

    if (colorInput && !HEX_COLOR_RE.test(colorInput)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'Color must be a valid hex code, e.g. `#5865F2`.')], ephemeral: true });
    }

    const embed = new EmbedBuilder().setDescription(description).setColor(colorInput || settings.embedColor);
    if (title) embed.setTitle(title);
    if (footer) embed.setFooter({ text: footer });
    if (imageUrl && /^https?:\/\//.test(imageUrl)) embed.setImage(imageUrl);

    await channel.send({ embeds: [embed] }).catch(() => null);
    await interaction.reply({ embeds: [successEmbed(settings, `Embed sent to ${channel}.`)], ephemeral: true });
  },

  /** Submission of the reject-reason modal opened by the ❌ Reject button. customId: approval_reject_modal:<requestId>. */
  approval_reject_modal: async (interaction) => {
    const [, requestId] = interaction.customId.split(':');
    const rejectReason = interaction.fields.getTextInputValue('reject_reason');
    await approvalService.rejectRequestWithReason(interaction, requestId, rejectReason);
  },

  /** Submission of the reason modal opened by a panel button. customId: ticket_create_modal:<typeId>. */
  ticket_create_modal: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    const { tickets } = guildConfig;

    if (!tickets.enabled) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'نظام التذاكر معطّل حالياً.')], ephemeral: true });
    }

    // فحص سريع غير ذرّي - فقط لتحسين تجربة المستخدم في الحالة الشائعة
    // (رد فوري بدون لمس Discord API إن كانت لديه تذكرة مفتوحة أصلاً).
    // هذا الفحص وحده لا يمنع TOCTOU: الحماية الفعلية من التزامن (ضغط
    // مزدوج أو نداءان متزامنان) تأتي من الفهرس الفريد الجزئي
    // uniq_active_ticket_per_member على Ticket (راجع database/models/Ticket.js)
    // الذي يُفرض فعلياً عند محاولة الحفظ أدناه، بعد إنشاء القناة.
    const existing = await Ticket.findOne({ guildId: interaction.guildId, userId: interaction.user.id, isOpen: true });
    if (existing) {
      return interaction.reply({
        embeds: [errorEmbed(settings, `لديك تذكرة مفتوحة بالفعل: <#${existing.channelId}>`)],
        ephemeral: true,
      });
    }

    await interaction.deferReply({ ephemeral: true });

    const [, typeId] = interaction.customId.split(':');
    const type = findTicketType(guildConfig, typeId);
    const { categoryId, mentionRoleId, viewRoleIds } = resolveTypeTargets(guildConfig, type);

    const reason = interaction.fields.getTextInputValue('reason');
    // رقم التذكرة يُحجز ذرّياً الآن (انظر nextTicketNumber أعلاه) بدل
    // tickets.counter + 1 محلياً - يمنع تصادم رقمين متطابقين لتذكرتين
    // مختلفتين فُتحتا في نفس اللحظة.
    const ticketNumber = await nextTicketNumber(interaction.guildId);

    const permissionOverwrites = [
      { id: interaction.guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
      {
        id: interaction.user.id,
        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
      },
      {
        id: interaction.client.user.id,
        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ManageChannels],
      },
      ...viewRoleIds.map((roleId) => ({
        id: roleId,
        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
      })),
    ];

    const channelName = resolveChannelName(type, { user: interaction.user, number: ticketNumber });
    // A brand-new ticket is, by definition, waiting on staff to respond.
    const initialStatus = 'needs_reply';

    const channel = await interaction.guild.channels.create({
      name: buildStatusChannelName(channelName, initialStatus),
      type: ChannelType.GuildText,
      parent: categoryId || undefined,
      permissionOverwrites,
    });

    // الحماية الذرّية الفعلية من التزامن (TOCTOU): محاولة إنشاء وثيقة
    // Ticket تصطدم بالفهرس الفريد الجزئي uniq_active_ticket_per_member
    // إن كان قد سبق لنداء آخر متزامن (double-click أو ضغطتان قريبتان)
    // من نفس العضو أن أنشأ له تذكرة نشطة بين لحظة الفحص أعلاه ولحظة هذا
    // الإنشاء. عند التصادم (كود الخطأ 11000) نتراجع بحذف القناة التي
    // أُنشئت للتو حتى لا يبقى للعضو قناتان مكررتان لتذكرة واحدة فقط
    // يُفترض أن تُقبل.
    try {
      await Ticket.create({
        guildId: interaction.guildId,
        channelId: channel.id,
        userId: interaction.user.id,
        ticketNumber,
        typeId: type.typeId,
        typeLabel: type.label,
        replyStatus: initialStatus,
        baseChannelName: channelName,
      });
    } catch (err) {
      if (err?.code === DUPLICATE_KEY_ERROR_CODE) {
        await channel.delete().catch((cleanupErr) => {
          logger.error(`فشل تنظيف قناة التذكرة المكررة ${channel.id}: ${cleanupErr.stack || cleanupErr}`);
        });
        const winner = await Ticket.findOne({ guildId: interaction.guildId, userId: interaction.user.id, isOpen: true });
        return interaction.editReply({
          embeds: [
            errorEmbed(
              settings,
              winner ? `لديك تذكرة مفتوحة بالفعل: <#${winner.channelId}>` : 'لديك تذكرة مفتوحة بالفعل.'
            ),
          ],
        });
      }
      throw err;
    }

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('ticket_claim').setLabel('استلام التذكرة').setStyle(ButtonStyle.Primary).setEmoji('🙋'),
      new ButtonBuilder().setCustomId('ticket_status_toggle').setLabel('حالة التذكرة').setStyle(ButtonStyle.Secondary).setEmoji('🔄'),
      new ButtonBuilder().setCustomId('ticket_close').setLabel('إغلاق التذكرة').setStyle(ButtonStyle.Danger).setEmoji('🔒')
    );

    await channel.send({
      content: mentionRoleId ? `<@&${mentionRoleId}> <@${interaction.user.id}>` : `<@${interaction.user.id}>`,
      embeds: [
        baseEmbed(settings)
          .setTitle(`🎫・تذكرة #${ticketNumber}`)
          .setDescription(resolveWelcomeMessage(type, { user: interaction.user, number: ticketNumber }))
          .addFields(
            { name: '📝 تفاصيل الطلب', value: reason },
            { name: '📂 القسم', value: `${type.emoji || ''} ${type.label}`.trim(), inline: true },
            { name: '👤 صاحب التذكرة', value: `<@${interaction.user.id}>`, inline: true }
          ),
      ],
      components: [row],
    });

    await interaction.editReply({ embeds: [successEmbed(settings, `تم إنشاء تذكرتك: ${channel}`)] });
  },

  /** Submission of the optional-comment modal opened by a ⭐ rating button. customId: ticket_rate_comment_modal:<ticketId>:<stars 1-5>. This is the only place a Rating document is actually created - see buttons.js ticket_rate. */
  ticket_rate_comment_modal: async (interaction) => {
    const [, ticketId, starsRaw] = interaction.customId.split(':');
    const stars = Number(starsRaw);

    const ticket = await Ticket.findById(ticketId).catch((err) => {
      logger.error(`فشل تحميل التذكرة ${ticketId} من أجل تسجيل التقييم: ${err.stack || err}`);
      return null;
    });
    if (!ticket) {
      return interaction.reply({ content: '❌ تعذر العثور على هذه التذكرة.', ephemeral: true });
    }

    const guildConfig = await getGuildConfig(ticket.guildId);
    const settings = resolved(guildConfig);

    if (interaction.user.id !== ticket.userId) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'هذا التقييم مخصص لصاحب التذكرة فقط.')], ephemeral: true });
    }

    const rawComment = interaction.fields.getTextInputValue('comment');
    const comment = rawComment && rawComment.trim() ? rawComment.trim() : null;

    let rating;
    try {
      rating = await Rating.create({
        guildId: ticket.guildId,
        ticketId: ticket._id,
        channelId: ticket.channelId,
        ticketNumber: ticket.ticketNumber,
        ticketUserId: ticket.userId,
        staffId: ticket.claimedBy || ticket.closedBy || null,
        stars,
        comment,
        // Duplicate-rating guard: ticketId has a unique index, so a second
        // submission for the same ticket (e.g. two near-simultaneous clicks)
        // fails here instead of creating a second rating.
      });
    } catch (err) {
      if (err?.code === 11000) {
        return interaction.reply({ embeds: [successEmbed(settings, 'لقد قمت بتقييم هذه التذكرة مسبقاً، شكراً لك!')], ephemeral: true });
      }
      logger.error(`فشل حفظ تقييم التذكرة #${ticket.ticketNumber} (${ticket._id}): ${err.stack || err}`);
      return interaction.reply({ embeds: [errorEmbed(settings, 'تعذر حفظ التقييم حالياً. حاول مرة أخرى لاحقاً.')], ephemeral: true });
    }

    if (!rating) {
      return interaction.reply({ embeds: [successEmbed(settings, 'لقد قمت بتقييم هذه التذكرة مسبقاً، شكراً لك!')], ephemeral: true });
    }

    const thankYou = (guildConfig.tickets.ratings?.thankYouMessage || DEFAULT_THANK_YOU_MESSAGE).replace(/\\n/g, '\n');

    await interaction.reply({ embeds: [successEmbed(settings, thankYou)] });

    // Disable the star row on the original DM so this ticket can't be
    // rated twice from the same message (the unique index above already
    // guarantees it at the data level - this is just the UI reflecting it).
    if (interaction.message) {
      const disabledRow = new ActionRowBuilder().addComponents(
        interaction.message.components[0].components.map((c) => ButtonBuilder.from(c).setDisabled(true))
      );
      await interaction.message.edit({ components: [disabledRow] }).catch((err) => {
        logger.warn(`تعذر تعطيل أزرار تقييم التذكرة #${ticket.ticketNumber}: ${err.message}`);
      });
    }

    const guild = interaction.client.guilds.cache.get(ticket.guildId);
    if (guild) await postRatingResult(interaction.client, guild, guildConfig, settings, ticket, rating);
  },

  // ════════════════════════════════════════════════════════════════════════
  // Tasks 33-36 — Ticket Dashboard Modals (tds_modal_*)
  // All share the same guard: isGuildManager. After saving they re-render
  // the relevant section view in-place so the admin sees the updated state
  // immediately without having to re-open the dashboard.
  // ════════════════════════════════════════════════════════════════════════

  /** Set log channel. customId: tds_modal_logchannel */
  tds_modal_logchannel: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const raw = interaction.fields.getTextInputValue('value').trim();
    const channelId = raw || null;
    if (channelId && !/^\d{17,20}$/.test(channelId)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'معرّف القناة غير صحيح. يجب أن يكون رقماً مكوناً من 17-20 رقماً.')], ephemeral: true });
    }
    await interaction.deferUpdate();
    await GuildConfig.updateOne({ guildId: interaction.guildId }, { $set: { 'tickets.logChannelId': channelId } });
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view = buildSettingsView(settings, fresh);
    await interaction.editReply({ embeds: view.embeds, components: view.components });
  },

  /** Set transcript channel. customId: tds_modal_transcript */
  tds_modal_transcript: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const raw = interaction.fields.getTextInputValue('value').trim();
    const channelId = raw || null;
    if (channelId && !/^\d{17,20}$/.test(channelId)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'معرّف القناة غير صحيح.')], ephemeral: true });
    }
    await interaction.deferUpdate();
    await GuildConfig.updateOne({ guildId: interaction.guildId }, { $set: { 'tickets.transcriptChannelId': channelId } });
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view = buildSettingsView(settings, fresh);
    await interaction.editReply({ embeds: view.embeds, components: view.components });
  },

  /** Set auto-delete minutes. customId: tds_modal_deletetime */
  tds_modal_deletetime: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const raw = interaction.fields.getTextInputValue('value').trim();
    const minutes = raw === '' ? 0 : parseInt(raw, 10);
    if (isNaN(minutes) || minutes < 0 || minutes > 43200) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'القيمة يجب أن تكون رقماً بين 0 و 43200.')], ephemeral: true });
    }
    await interaction.deferUpdate();
    await GuildConfig.updateOne({ guildId: interaction.guildId }, { $set: { 'tickets.closePrompt.autoDeleteMinutes': minutes } });
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view = buildSettingsView(settings, fresh);
    await interaction.editReply({ embeds: view.embeds, components: view.components });
  },

  /** Set auto-close minutes. customId: tds_modal_autoclose */
  tds_modal_autoclose: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const raw = interaction.fields.getTextInputValue('value').trim();
    const minutes = raw === '' ? 0 : parseInt(raw, 10);
    if (isNaN(minutes) || minutes < 0 || minutes > 43200) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'القيمة يجب أن تكون رقماً بين 0 و 43200.')], ephemeral: true });
    }
    await interaction.deferUpdate();
    await GuildConfig.updateOne({ guildId: interaction.guildId }, { $set: { 'tickets.autoCloseMinutes': minutes || null } });
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view = buildSettingsView(settings, fresh);
    await interaction.editReply({ embeds: view.embeds, components: view.components });
  },

  /** Set reminder minutes. customId: tds_modal_reminder */
  tds_modal_reminder: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const raw = interaction.fields.getTextInputValue('value').trim();
    const minutes = raw === '' ? 0 : parseInt(raw, 10);
    if (isNaN(minutes) || minutes < 0 || minutes > 10080) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'القيمة يجب أن تكون رقماً بين 0 و 10080 (أسبوع).')], ephemeral: true });
    }
    await interaction.deferUpdate();
    await GuildConfig.updateOne({ guildId: interaction.guildId }, { $set: { 'tickets.reminderMinutes': minutes || null } });
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view = buildSettingsView(settings, fresh);
    await interaction.editReply({ embeds: view.embeds, components: view.components });
  },

  // ── Task 44: remaining Settings modals (default category, close-prompt
  //    warning timer, close-prompt reset confirmation) ─────────────────────

  /** Set the default ticket category. customId: tds_modal_category */
  tds_modal_category: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const raw = interaction.fields.getTextInputValue('value').trim();
    const categoryId = raw || null;
    if (categoryId && !/^\d{17,20}$/.test(categoryId)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'معرّف الفئة غير صحيح. يجب أن يكون رقماً مكوناً من 17-20 رقماً.')], ephemeral: true });
    }
    await interaction.deferUpdate();
    await GuildConfig.updateOne({ guildId: interaction.guildId }, { $set: { 'tickets.categoryId': categoryId } });
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view = buildSettingsView(settings, fresh);
    await interaction.editReply({ embeds: view.embeds, components: view.components });
  },

  /** Set the close-prompt 🔴 warning timer. customId: tds_modal_warningtime */
  tds_modal_warningtime: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const raw = interaction.fields.getTextInputValue('value').trim();
    const minutes = raw === '' ? 0 : parseInt(raw, 10);
    if (isNaN(minutes) || minutes < 0 || minutes > 43200) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'القيمة يجب أن تكون رقماً بين 0 و 43200.')], ephemeral: true });
    }
    await interaction.deferUpdate();
    await GuildConfig.updateOne({ guildId: interaction.guildId }, { $set: { 'tickets.closePrompt.warningMinutes': minutes } });
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view = buildSettingsView(settings, fresh);
    await interaction.editReply({ embeds: view.embeds, components: view.components });
  },

  /** Confirm + reset close-prompt message/labels/timers to defaults. customId: tds_settings_closepromptreset_confirm */
  tds_settings_closepromptreset_confirm: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const confirm = interaction.fields.getTextInputValue('confirm').trim().toLowerCase();
    if (confirm !== 'reset') {
      return interaction.reply({ embeds: [errorEmbed(settings, 'لم يتم التأكيد - اكتب "reset" بالضبط لإعادة الضبط.')], ephemeral: true });
    }
    const defaults = { message: null, deleteButtonLabel: null, reopenButtonLabel: null, autoDeleteMinutes: 240, warningMinutes: 30 };
    await interaction.deferUpdate();
    await GuildConfig.updateOne({ guildId: interaction.guildId }, { $set: { 'tickets.closePrompt': defaults } });
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view = buildSettingsView(settings, fresh);
    view.embeds.push(
      baseEmbed(settings)
        .setTitle('♻️ تمت إعادة الضبط')
        .addFields(
          { name: 'الرسالة الافتراضية', value: DEFAULT_CLOSE_MESSAGE },
          { name: 'زر الحذف', value: DEFAULT_DELETE_LABEL, inline: true },
          { name: 'زر إعادة الفتح', value: DEFAULT_REOPEN_LABEL, inline: true }
        )
    );
    await interaction.editReply({ embeds: view.embeds, components: view.components });
  },

  // ── Task 34: Category modals ────────────────────────────────────────────

  /** Add new ticket type. customId: tds_modal_category_add */
  tds_modal_category_add: async (interaction) => {
    const TYPE_ID_RE = /^[a-z0-9_-]{1,20}$/;
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const typeId = interaction.fields.getTextInputValue('typeId').trim().toLowerCase();
    const label = interaction.fields.getTextInputValue('label').trim();
    const emoji = interaction.fields.getTextInputValue('emoji').trim() || null;
    const description = interaction.fields.getTextInputValue('description').trim() || null;

    if (!TYPE_ID_RE.test(typeId)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'المعرّف يجب أن يحتوي على أحرف إنجليزية صغيرة وأرقام و - و _ فقط (1-20 حرف).')], ephemeral: true });
    }

    const existingTypes = guildConfig.tickets?.types || [];
    if (existingTypes.find((t) => t.typeId === typeId)) {
      return interaction.reply({ embeds: [errorEmbed(settings, `النوع \`${typeId}\` موجود بالفعل. استخدم "تعديل نوع" لتعديله.`)], ephemeral: true });
    }
    if (existingTypes.length >= 25) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'وصلت للحد الأقصى (25 نوع).')], ephemeral: true });
    }

    await interaction.deferUpdate();
    await GuildConfig.updateOne(
      { guildId: interaction.guildId },
      { $push: { 'tickets.types': { typeId, label, emoji, description, style: 'Primary' } } }
    );
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view = buildCategoriesView(settings, fresh);
    await interaction.editReply({ embeds: view.embeds, components: view.components });
  },

  /** Edit existing ticket type. customId: tds_modal_category_edit */
  tds_modal_category_edit: async (interaction) => {
    const TYPE_ID_RE = /^[a-z0-9_-]{1,20}$/;
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const typeId = interaction.fields.getTextInputValue('typeId').trim().toLowerCase();
    const label = interaction.fields.getTextInputValue('label').trim();
    const emoji = interaction.fields.getTextInputValue('emoji').trim() || null;
    const description = interaction.fields.getTextInputValue('description').trim() || null;

    const existingTypes = guildConfig.tickets?.types || [];
    const idx = existingTypes.findIndex((t) => t.typeId === typeId);
    if (idx === -1) {
      return interaction.reply({ embeds: [errorEmbed(settings, `لم يتم العثور على النوع \`${typeId}\`. تحقق من المعرّف وحاول مجدداً.`)], ephemeral: true });
    }

    await interaction.deferUpdate();
    await GuildConfig.updateOne(
      { guildId: interaction.guildId, 'tickets.types.typeId': typeId },
      { $set: { 'tickets.types.$.label': label, 'tickets.types.$.emoji': emoji, 'tickets.types.$.description': description } }
    );
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view = buildCategoriesView(settings, fresh);
    await interaction.editReply({ embeds: view.embeds, components: view.components });
  },

  /** Delete ticket type with typeId confirmation. customId: tds_categories_delete_confirm */
  tds_categories_delete_confirm: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const typeId = interaction.fields.getTextInputValue('typeId').trim().toLowerCase();
    const existingTypes = guildConfig.tickets?.types || [];
    const exists = existingTypes.find((t) => t.typeId === typeId);
    if (!exists) {
      return interaction.reply({ embeds: [errorEmbed(settings, `لم يتم العثور على النوع \`${typeId}\`.`)], ephemeral: true });
    }
    await interaction.deferUpdate();
    await GuildConfig.updateOne({ guildId: interaction.guildId }, { $pull: { 'tickets.types': { typeId } } });
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view = buildCategoriesView(settings, fresh);
    await interaction.editReply({ embeds: view.embeds, components: view.components });
  },

  // ── Task 35: Role modals ─────────────────────────────────────────────────

  /** Set support role. customId: tds_modal_role_support */
  tds_modal_role_support: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const raw = interaction.fields.getTextInputValue('value').trim();
    const roleId = raw || null;
    if (roleId && !/^\d{17,20}$/.test(roleId)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'معرّف الرتبة غير صحيح.')], ephemeral: true });
    }
    await interaction.deferUpdate();
    await GuildConfig.updateOne({ guildId: interaction.guildId }, { $set: { 'tickets.supportRoleId': roleId } });
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view = buildRolesView(settings, fresh);
    await interaction.editReply({ embeds: view.embeds, components: view.components });
  },

  /** Set moderator role. customId: tds_modal_role_moderator */
  tds_modal_role_moderator: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const raw = interaction.fields.getTextInputValue('value').trim();
    const roleId = raw || null;
    if (roleId && !/^\d{17,20}$/.test(roleId)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'معرّف الرتبة غير صحيح.')], ephemeral: true });
    }
    await interaction.deferUpdate();
    await GuildConfig.updateOne({ guildId: interaction.guildId }, { $set: { modRoleId: roleId } });
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view = buildRolesView(settings, fresh);
    await interaction.editReply({ embeds: view.embeds, components: view.components });
  },

  /** Set admin role. customId: tds_modal_role_admin */
  tds_modal_role_admin: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const raw = interaction.fields.getTextInputValue('value').trim();
    const roleId = raw || null;
    if (roleId && !/^\d{17,20}$/.test(roleId)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'معرّف الرتبة غير صحيح.')], ephemeral: true });
    }
    await interaction.deferUpdate();
    await GuildConfig.updateOne({ guildId: interaction.guildId }, { $set: { adminRoleId: roleId } });
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view = buildRolesView(settings, fresh);
    await interaction.editReply({ embeds: view.embeds, components: view.components });
  },

  // ── Task 36: Message modals ───────────────────────────────────────────────

  /** Set panel title. customId: tds_modal_paneltitle */
  tds_modal_paneltitle: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const val = interaction.fields.getTextInputValue('value').trim() || null;
    await interaction.deferUpdate();
    await GuildConfig.updateOne({ guildId: interaction.guildId }, { $set: { 'tickets.panelTitle': val } });
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view = buildMessagesView(settings, fresh);
    await interaction.editReply({ embeds: view.embeds, components: view.components });
  },

  /** Set panel description. customId: tds_modal_paneldesc */
  tds_modal_paneldesc: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const val = interaction.fields.getTextInputValue('value').trim() || null;
    await interaction.deferUpdate();
    await GuildConfig.updateOne({ guildId: interaction.guildId }, { $set: { 'tickets.panelDescription': val } });
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view = buildMessagesView(settings, fresh);
    await interaction.editReply({ embeds: view.embeds, components: view.components });
  },

  /** Set panel rules. customId: tds_modal_panelrules */
  tds_modal_panelrules: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const val = interaction.fields.getTextInputValue('value').replace(/\\n/g, '\n').trim() || null;
    await interaction.deferUpdate();
    await GuildConfig.updateOne({ guildId: interaction.guildId }, { $set: { 'tickets.panelRules': val } });
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view = buildMessagesView(settings, fresh);
    await interaction.editReply({ embeds: view.embeds, components: view.components });
  },

  /** Set close prompt message. customId: tds_modal_closemsg */
  tds_modal_closemsg: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const val = interaction.fields.getTextInputValue('value').replace(/\\n/g, '\n').trim() || null;
    await interaction.deferUpdate();
    await GuildConfig.updateOne({ guildId: interaction.guildId }, { $set: { 'tickets.closePrompt.message': val } });
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view = buildMessagesView(settings, fresh);
    await interaction.editReply({ embeds: view.embeds, components: view.components });
  },

  /** Set delete button label. customId: tds_modal_deletebtn */
  tds_modal_deletebtn: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const val = interaction.fields.getTextInputValue('value').trim() || null;
    await interaction.deferUpdate();
    await GuildConfig.updateOne({ guildId: interaction.guildId }, { $set: { 'tickets.closePrompt.deleteButtonLabel': val } });
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view = buildMessagesView(settings, fresh);
    await interaction.editReply({ embeds: view.embeds, components: view.components });
  },

  /** Set reopen button label. customId: tds_modal_reopenbtn */
  tds_modal_reopenbtn: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const val = interaction.fields.getTextInputValue('value').trim() || null;
    await interaction.deferUpdate();
    await GuildConfig.updateOne({ guildId: interaction.guildId }, { $set: { 'tickets.closePrompt.reopenButtonLabel': val } });
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view = buildMessagesView(settings, fresh);
    await interaction.editReply({ embeds: view.embeds, components: view.components });
  },

  /** Set rating prompt message. customId: tds_modal_ratingprompt */
  tds_modal_ratingprompt: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const val = interaction.fields.getTextInputValue('value').trim() || null;
    await interaction.deferUpdate();
    await GuildConfig.updateOne({ guildId: interaction.guildId }, { $set: { 'tickets.ratings.promptMessage': val } });
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view = buildMessagesView(settings, fresh);
    await interaction.editReply({ embeds: view.embeds, components: view.components });
  },

  /** Task 37 — set the Panel Builder button label. customId: tds_modal_panel_label */
  tds_modal_panel_label: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }

    const value = interaction.fields.getTextInputValue('value').trim();
    if (!value || value.length > 80) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'اسم الزر مطلوب ويجب ألا يتجاوز 80 حرفاً.')], ephemeral: true });
    }

    await interaction.deferUpdate();
    await GuildConfig.updateOne({ guildId: interaction.guildId }, { $set: { 'tickets.panelBuilder.buttonLabel': value } });
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view = buildPanelsView(settings, fresh);
    await interaction.editReply({ embeds: view.embeds, components: view.components });
  },

  /** Task 37 — set the Panel Builder button emoji. customId: tds_modal_panel_emoji */
  tds_modal_panel_emoji: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }

    const value = interaction.fields.getTextInputValue('value').trim();
    if (!value || value.length > 32) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'الإيموجي مطلوب ويجب ألا يتجاوز 32 حرفاً.')], ephemeral: true });
    }

    await interaction.deferUpdate();
    await GuildConfig.updateOne({ guildId: interaction.guildId }, { $set: { 'tickets.panelBuilder.emoji': value } });
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view = buildPanelsView(settings, fresh);
    await interaction.editReply({ embeds: view.embeds, components: view.components });
  },
  // ═══════════════════════════════════════════════════════════════════════════
  // Task 39 — Logging Settings Modal (slg_modal_*)
  // ═══════════════════════════════════════════════════════════════════════════

  /**
   * Submission of the channel modal opened by slg_channel button.
   * Validates the Channel ID, saves it, then re-renders the Logging view.
   * customId: slg_modal_channel
   */
  slg_modal_channel: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const raw = interaction.fields.getTextInputValue('value').trim();
    const channelId = raw || null;
    if (channelId && !/^\d{17,20}$/.test(channelId)) {
      return interaction.reply({
        embeds: [errorEmbed(settings, 'معرّف القناة غير صحيح. يجب أن يكون رقماً مكوناً من 17-20 رقماً.')],
        ephemeral: true,
      });
    }
    const updateFields = { 'logging.channelId': channelId };
    // Auto-enable logging when a channel is set for the first time
    if (channelId && !guildConfig.logging?.enabled) {
      updateFields['logging.enabled'] = true;
    }
    await interaction.deferUpdate();
    await GuildConfig.updateOne({ guildId: interaction.guildId }, { $set: updateFields });
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view  = buildLoggingView(settings, fresh);
    await interaction.editReply({ embeds: view.embeds, components: view.components });
  },


  // ═══════════════════════════════════════════════════════════════════════════
  // Task 40 — Welcome/Leave Settings Modals (swl_modal_*)
  // ═══════════════════════════════════════════════════════════════════════════

  /** Set welcome channel. customId: swl_modal_welcome_channel */
  swl_modal_welcome_channel: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const raw = interaction.fields.getTextInputValue('value').trim();
    const channelId = raw || null;
    if (channelId && !/^\d{17,20}$/.test(channelId)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'معرّف القناة غير صحيح. يجب أن يكون رقماً من 17-20 رقماً.')], ephemeral: true });
    }
    const update = { 'welcome.channelId': channelId };
    if (channelId && !guildConfig.welcome?.enabled) update['welcome.enabled'] = true;
    await interaction.deferUpdate();
    await GuildConfig.updateOne({ guildId: interaction.guildId }, { $set: update });
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view  = buildWelcomeView(settings, fresh);
    await interaction.editReply({ embeds: view.embeds, components: view.components });
  },

  /** Set welcome message. customId: swl_modal_welcome_message */
  swl_modal_welcome_message: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const raw     = interaction.fields.getTextInputValue('value').trim();
    const message = raw || null;
    await interaction.deferUpdate();
    await GuildConfig.updateOne({ guildId: interaction.guildId }, { $set: { 'welcome.message': message } });
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view  = buildWelcomeView(settings, fresh);
    await interaction.editReply({ embeds: view.embeds, components: view.components });
  },

  /** Set goodbye channel. customId: swl_modal_goodbye_channel */
  swl_modal_goodbye_channel: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const raw = interaction.fields.getTextInputValue('value').trim();
    const channelId = raw || null;
    if (channelId && !/^\d{17,20}$/.test(channelId)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'معرّف القناة غير صحيح. يجب أن يكون رقماً من 17-20 رقماً.')], ephemeral: true });
    }
    const update = { 'goodbye.channelId': channelId };
    if (channelId && !guildConfig.goodbye?.enabled) update['goodbye.enabled'] = true;
    await interaction.deferUpdate();
    await GuildConfig.updateOne({ guildId: interaction.guildId }, { $set: update });
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view  = buildWelcomeView(settings, fresh);
    await interaction.editReply({ embeds: view.embeds, components: view.components });
  },

  /** Set goodbye message. customId: swl_modal_goodbye_message */
  swl_modal_goodbye_message: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const raw     = interaction.fields.getTextInputValue('value').trim();
    const message = raw || null;
    await interaction.deferUpdate();
    await GuildConfig.updateOne({ guildId: interaction.guildId }, { $set: { 'goodbye.message': message } });
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view  = buildWelcomeView(settings, fresh);
    await interaction.editReply({ embeds: view.embeds, components: view.components });
  },

  // ───────────────────────────────────────────────────────────────────────────
  // Task 41 — Protection Settings UI modals (spt_modal_*)
  // ───────────────────────────────────────────────────────────────────────────

  /** Set Anti-Raid join threshold + window. customId: spt_modal_antiraid_threshold */
  spt_modal_antiraid_threshold: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const joinThresholdRaw = interaction.fields.getTextInputValue('join_threshold').trim();
    const windowSecsRaw    = interaction.fields.getTextInputValue('window_seconds').trim();

    const joinThreshold = parseInt(joinThresholdRaw, 10);
    const windowSecs    = parseInt(windowSecsRaw, 10);

    if (isNaN(joinThreshold) || joinThreshold < 2) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'حد الانضمامات يجب أن يكون رقماً 2 فأكثر.')], ephemeral: true });
    }
    if (isNaN(windowSecs) || windowSecs < 1) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'المدة الزمنية يجب أن تكون رقماً 1 فأكثر.')], ephemeral: true });
    }

    await interaction.deferUpdate();
    await GuildConfig.updateOne(
      { guildId: interaction.guildId },
      { $set: { 'antiRaid.joinThreshold': joinThreshold, 'antiRaid.windowMs': windowSecs * 1000 } }
    );
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view  = buildProtectionView(resolved(fresh), fresh);
    await interaction.editReply({ embeds: view.embeds, components: view.components });
  },

  /** Set Anti-Raid response action. customId: spt_modal_antiraid_action */
  spt_modal_antiraid_action: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const action = interaction.fields.getTextInputValue('action').trim().toLowerCase();
    const valid  = ['lockdown', 'kick', 'ban'];
    if (!valid.includes(action)) {
      return interaction.reply({ embeds: [errorEmbed(settings, `الإجراء يجب أن يكون أحد: ${valid.join(' / ')}`)], ephemeral: true });
    }
    await interaction.deferUpdate();
    await GuildConfig.updateOne({ guildId: interaction.guildId }, { $set: { 'antiRaid.action': action } });
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view  = buildProtectionView(resolved(fresh), fresh);
    await interaction.editReply({ embeds: view.embeds, components: view.components });
  },

  /** Set Anti-Raid new account handling. customId: spt_modal_antiraid_newaccounts */
  spt_modal_antiraid_newaccounts: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const minAgeDaysRaw = interaction.fields.getTextInputValue('min_age_days').trim();
    const newAccAction  = interaction.fields.getTextInputValue('new_account_action').trim().toLowerCase();

    const minAge = parseInt(minAgeDaysRaw, 10);
    if (isNaN(minAge) || minAge < 0) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'عمر الحساب يجب أن يكون رقماً 0 فأكثر.')], ephemeral: true });
    }
    const validActions = ['none', 'flag', 'kick'];
    if (!validActions.includes(newAccAction)) {
      return interaction.reply({ embeds: [errorEmbed(settings, `الإجراء يجب أن يكون: ${validActions.join(' / ')}`)], ephemeral: true });
    }
    await interaction.deferUpdate();
    await GuildConfig.updateOne(
      { guildId: interaction.guildId },
      { $set: { 'antiRaid.newAccountAgeDays': minAge, 'antiRaid.newAccountAction': newAccAction } }
    );
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view  = buildProtectionView(resolved(fresh), fresh);
    await interaction.editReply({ embeds: view.embeds, components: view.components });
  },

  /** Set Anti-Nuke punishment. customId: spt_modal_antinuke_punishment */
  spt_modal_antinuke_punishment: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const punishment = interaction.fields.getTextInputValue('punishment').trim();
    const valid      = ['stripRoles', 'kick', 'ban'];
    if (!valid.includes(punishment)) {
      return interaction.reply({ embeds: [errorEmbed(settings, `العقوبة يجب أن تكون: ${valid.join(' / ')}`)], ephemeral: true });
    }
    await interaction.deferUpdate();
    await GuildConfig.updateOne({ guildId: interaction.guildId }, { $set: { 'antinuke.punishment': punishment } });
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view  = buildProtectionView(resolved(fresh), fresh);
    await interaction.editReply({ embeds: view.embeds, components: view.components });
  },

  /** Manage Anti-Nuke whitelist. customId: spt_modal_antinuke_whitelist */
  spt_modal_antinuke_whitelist: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const raw  = interaction.fields.getTextInputValue('user_ids').trim();
    const ids  = raw
      .split(/\s+/)
      .map((s) => s.trim())
      .filter((s) => /^\d{17,20}$/.test(s));

    await interaction.deferUpdate();
    await GuildConfig.updateOne({ guildId: interaction.guildId }, { $set: { 'antinuke.whitelistedUserIds': ids } });
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view  = buildProtectionView(resolved(fresh), fresh);
    await interaction.editReply({ embeds: view.embeds, components: view.components });
  },

  /** Set Anti-Nuke event thresholds. customId: spt_modal_antinuke_thresholds */
  spt_modal_antinuke_thresholds: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }

    const parse = (key) => {
      const v = parseInt(interaction.fields.getTextInputValue(key).trim(), 10);
      return isNaN(v) || v < 1 ? null : v;
    };

    const channelDelete = parse('channel_delete');
    const roleDelete    = parse('role_delete');
    const memberBan     = parse('member_ban');
    const webhookCreate = parse('webhook_create');

    if ([channelDelete, roleDelete, memberBan, webhookCreate].some((v) => v === null)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'جميع الحدود يجب أن تكون أرقاماً صحيحة (1 فأكثر).')], ephemeral: true });
    }

    await interaction.deferUpdate();
    await GuildConfig.updateOne(
      { guildId: interaction.guildId },
      {
        $set: {
          'antinuke.thresholds.channelDelete': channelDelete,
          'antinuke.thresholds.roleDelete':    roleDelete,
          'antinuke.thresholds.memberBan':     memberBan,
          'antinuke.thresholds.webhookCreate': webhookCreate,
        },
      }
    );
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view  = buildProtectionView(resolved(fresh), fresh);
    await interaction.editReply({ embeds: view.embeds, components: view.components });
  },

  /**
   * Set AutoMod punishment for a specific check.
   * customId: spt_modal_automod_punishment:<checkKey>
   * Router matches via startsWith('spt_modal_automod_punishment:').
   */
  spt_modal_automod_punishment: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings    = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }
    const checkKey   = interaction.customId.slice('spt_modal_automod_punishment:'.length);
    const validCheck = CHECKS.find((c) => c.key === checkKey);
    if (!validCheck) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'فحص AutoMod غير معروف.')], ephemeral: true });
    }

    const punishment = interaction.fields.getTextInputValue('punishment').trim().toLowerCase();
    if (!AUTOMOD_PUNISHMENTS.includes(punishment)) {
      return interaction.reply({ embeds: [errorEmbed(settings, `العقوبة يجب أن تكون: ${AUTOMOD_PUNISHMENTS.join(' / ')}`)], ephemeral: true });
    }

    const timeoutRaw     = interaction.fields.getTextInputValue('timeout_minutes').trim();
    const timeoutMinutes = parseInt(timeoutRaw, 10);

    const updateDoc = { [`automod.checks.${checkKey}.punishment`]: punishment };
    if (punishment === 'timeout' && !isNaN(timeoutMinutes) && timeoutMinutes >= 1) {
      updateDoc[`automod.checks.${checkKey}.timeoutMinutes`] = Math.min(timeoutMinutes, 40320);
    }

    await interaction.deferUpdate();
    await GuildConfig.updateOne({ guildId: interaction.guildId }, { $set: updateDoc });
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view  = buildAutomodChecksView(resolved(fresh), fresh);
    await interaction.editReply({ embeds: view.embeds, components: view.components });
  },

  // ── Task 45 — Leveling Settings Modals (slv_modal_*) ────────────────────
  [SLV_MODAL_ANNOUNCE_CHANNEL]: async (i) => handleLevelingModal(i),
  [SLV_MODAL_XP_RANGE]:         async (i) => handleLevelingModal(i),
  [SLV_MODAL_COOLDOWN]:         async (i) => handleLevelingModal(i),
  [SLV_MODAL_VOICE_XP]:         async (i) => handleLevelingModal(i),
  [SLV_MODAL_VOICE_MIN]:        async (i) => handleLevelingModal(i),

  // ── Task 45 — Economy Settings Modals (sec_modal_*) ─────────────────────
  [SEC_MODAL_CURRENCY_NAME]:   async (i) => handleEconomyModal(i),
  [SEC_MODAL_CURRENCY_SYMBOL]: async (i) => handleEconomyModal(i),
  [SEC_MODAL_DAILY]:           async (i) => handleEconomyModal(i),
  [SEC_MODAL_WORK]:            async (i) => handleEconomyModal(i),
  [SEC_MODAL_WORK_COOLDOWN]:   async (i) => handleEconomyModal(i),

  // ── Task 45 — Moderation Settings Modals (smd_modal_*) ──────────────────
  [SMD_MODAL_REVIEW_CHANNEL]: async (i) => handleModerationSettingsModal(i),

  // ── Task 45 — Music Settings Modals (smu_modal_*) ───────────────────────
  [SMU_MODAL_247_VOICE]: async (i) => handleMusicModal(i),
  [SMU_MODAL_247_TEXT]:  async (i) => handleMusicModal(i),

  // ── Task-09 Community Settings Dashboard Modals (scd_modal_*) ─────────
  scd_modal_suggest_ch:  async (i) => handleCommunityModal(i),
  scd_modal_boost_ch:    async (i) => handleCommunityModal(i),
  scd_modal_boost_msg:   async (i) => handleCommunityModal(i),
  scd_modal_mc_ch:       async (i) => handleCommunityModal(i),
  scd_modal_mc_fmt:      async (i) => handleCommunityModal(i),
  scd_modal_sb_config:   async (i) => handleCommunityModal(i),
  scd_modal_cnt_ch:      async (i) => handleCommunityModal(i),

  // ── Music Panel Modals (mr_modal_*) ─────────────────────────────────────

  /** ⏩ Seek modal — mr-seek button opens this. customId: mr_modal_seek */
  mr_modal_seek: async (interaction) => {
    const { getGuildConfig, resolved } = require('../utils/resolveGuildSettings');
    const { errorEmbed, successEmbed } = require('../utils/embeds');
    const { requireActiveQueue } = require('../utils/musicChecks');

    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    const queue = await requireActiveQueue(interaction, settings);
    if (!queue) return;

    const timestamp = interaction.fields.getTextInputValue('mr_seek_input').trim();
    const parts = timestamp.split(':').map(Number);
    let ms = 0;
    if (parts.length === 2 && !parts.some(isNaN)) {
      ms = (parts[0] * 60 + parts[1]) * 1000;
    } else if (parts.length === 3 && !parts.some(isNaN)) {
      ms = (parts[0] * 3600 + parts[1] * 60 + parts[2]) * 1000;
    } else {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تنسيق الوقت غير صحيح. استخدم مثل: 1:30 أو 0:45')], ephemeral: true });
    }

    try {
      await queue.node.seek(ms);
      return interaction.reply({ embeds: [successEmbed(settings, `⏩ تم الانتقال إلى **${timestamp}**`)], ephemeral: true });
    } catch (err) {
      return interaction.reply({ embeds: [errorEmbed(settings, `تعذر الانتقال: ${err.message}`)], ephemeral: true });
    }
  },

  /** ❌ Remove track modal — mr-remove button opens this. customId: mr_modal_remove */
  mr_modal_remove: async (interaction) => {
    const { getGuildConfig, resolved } = require('../utils/resolveGuildSettings');
    const { errorEmbed, successEmbed } = require('../utils/embeds');
    const { requireActiveQueue } = require('../utils/musicChecks');

    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    const queue = await requireActiveQueue(interaction, settings);
    if (!queue) return;

    const posStr = interaction.fields.getTextInputValue('mr_remove_input').trim();
    const position = parseInt(posStr, 10);
    if (isNaN(position) || position < 1) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'رقم الموضع غير صحيح. أدخل رقماً موجباً.')], ephemeral: true });
    }

    const tracks = queue.tracks.toArray();
    if (position > tracks.length) {
      return interaction.reply({ embeds: [errorEmbed(settings, `الموضع ${position} خارج النطاق. القائمة تحتوي على ${tracks.length} مقطع.`)], ephemeral: true });
    }

    const removed = tracks[position - 1];
    queue.tracks.remove(position - 1);
    return interaction.reply({ embeds: [successEmbed(settings, `❌ تمت إزالة **${removed.title}** من القائمة.`)], ephemeral: true });
  },

};
