const { ChannelType } = require('discord.js');
const logger = require('../utils/logger');
const { getGuildConfig, resolved, invalidateGuildConfig } = require('../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../utils/embeds');
const { isGuildManager } = require('../utils/permissions');
const { findTicketType, buildTicketModal } = require('../utils/ticketPanel');
const GuildConfig = require('../database/models/GuildConfig');
const { buildSectionView } = require('../utils/adminDashboard');
const { buildSectionView: buildTicketDashSectionView } = require('../utils/ticketDashboard');
const { buildSectionView: buildSettingsSectionView } = require('../utils/settingsDashboard');
const { buildPanelsView } = require('../utils/ticketSettingsUI');

module.exports = {
  /**
   * Panel dropdown used instead of buttons once a server has more ticket
   * types configured than fit as buttons (see utils/ticketPanel.js). Mirrors
   * buttons.js's ticket_create handler exactly - same shared modal builder,
   * just triggered by a select instead of a click. customId:
   * ticket_create_select:<pageIndex> (pageIndex is unused; the chosen type
   * is in interaction.values[0]).
   */
  ticket_create_select: async (interaction) => {
    const typeId = interaction.values[0];
    const guildConfig = await getGuildConfig(interaction.guildId);
    const type = findTicketType(guildConfig, typeId);
    await interaction.showModal(buildTicketModal(type));
  },

  /**
   * Task 37 — saves the selected channel for the interactive Panel Builder.
   * ChannelSelectMenuBuilder restricts the normal UI to text channels, but
   * the type check is repeated here because component payloads are
   * user-controlled and the selected channel must be safe to send to.
   */
  tds_panels_channel: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }

    const channelId = interaction.values[0];
    const channel = await interaction.guild.channels.fetch(channelId);
    if (!channel || channel.type !== ChannelType.GuildText) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'اختر قناة نصية صالحة لإرسال لوحة التذاكر.')], ephemeral: true });
    }

    await GuildConfig.updateOne({ guildId: interaction.guildId }, { $set: { 'tickets.panelBuilder.channelId': channel.id } });
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view = buildPanelsView(settings, fresh);
    await interaction.update({ embeds: view.embeds, components: view.components });
  },

  /** Task 37 — saves the selected Category for new ticket channels. */
  tds_panels_category: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر.')], ephemeral: true });
    }

    const categoryId = interaction.values[0];
    const category = await interaction.guild.channels.fetch(categoryId);
    if (!category || category.type !== ChannelType.GuildCategory) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'اختر Category صالحة لقنوات التذاكر.')], ephemeral: true });
    }

    await GuildConfig.updateOne({ guildId: interaction.guildId }, { $set: { 'tickets.panelBuilder.categoryId': category.id } });
    invalidateGuildConfig(interaction.guildId);
    const fresh = await getGuildConfig(interaction.guildId);
    const view = buildPanelsView(settings, fresh);
    await interaction.update({ embeds: view.embeds, components: view.components });
  },

  /**
   * Self-assignable role menu. Values are role IDs baked in at panel-creation
   * time (see commands/roles/rolemenu.js). Selecting toggles membership:
   * roles present in the new selection are added, previously-selected panel
   * roles that got deselected are removed.
   */
  rolemenu_select: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    const allOptionValues = interaction.component.options.map((o) => o.value);
    const selected = interaction.values;
    const member = interaction.member;

    const toAdd = allOptionValues.filter((id) => selected.includes(id) && !member.roles.cache.has(id));
    const toRemove = allOptionValues.filter((id) => !selected.includes(id) && member.roles.cache.has(id));

    try {
      for (const roleId of toAdd) await member.roles.add(roleId);
      for (const roleId of toRemove) await member.roles.remove(roleId);
    } catch (err) {
      logger.warn(`[selectMenus] Role update failed for member ${member.id} in guild ${interaction.guildId}: ${err.message}`);
      return interaction.reply({
        embeds: [errorEmbed(settings, 'I could not update your roles - check that my role is above the assignable roles.')],
        ephemeral: true,
      });
    }

    await interaction.reply({ embeds: [successEmbed(settings, 'Your roles have been updated.')], ephemeral: true });
  },

  /**
   * Task 31 — Section picker on the admin dashboard Home view. Opens the
   * chosen section's (currently placeholder) view, with Back/Home/Close
   * below it. customId: admin_nav, value = section id (see
   * utils/adminDashboard.js#ADMIN_SECTIONS).
   *
   * Re-checks isGuildManager() the same way every admin_* button handler
   * in components/buttons.js does - see admin_home's doc comment there
   * for why this re-check exists even though the panel is ephemeral.
   */
  admin_nav: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر (Manage Server) لاستخدام لوحة الإدارة.')], ephemeral: true });
    }

    const sectionId = interaction.values[0];
    const view = buildSectionView(settings, sectionId);
    if (!view) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'هذا القسم غير معروف أو أصبح غير متاح.')], ephemeral: true });
    }

    await interaction.update({ embeds: view.embeds, components: view.components });
  },

  /**
   * Task 38 — Section picker on the general `/settings` dashboard.
   * The ManageGuild check is repeated on every interaction so a role change
   * while the ephemeral panel is open cannot bypass the command's gate.
   */
  settings_nav: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر (Manage Server) لاستخدام لوحة الإعدادات.')], ephemeral: true });
    }

    // Tasks 39-45: pass guildConfig + client so all sections with a real UI
    // render live settings. Some builders (giveaways, broadcast) are async —
    // await the result to handle both sync and async builders uniformly.
    const client = interaction.client;
    const viewOrPromise = buildSettingsSectionView(settings, interaction.values[0], guildConfig, client);
    const view = viewOrPromise instanceof Promise ? await viewOrPromise : viewOrPromise;
    if (!view) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'هذا القسم غير معروف أو أصبح غير متاح.')], ephemeral: true });
    }

    await interaction.update({ embeds: view.embeds, components: view.components });
  },

  /**
   * Task 32 — Section picker on the Tickets Dashboard Home view. Opens
   * the chosen section's (currently placeholder) view, with Back/Home/
   * Close below it. customId: ticketdash_nav, value = section id (see
   * utils/ticketDashboard.js#TICKET_DASH_SECTIONS). Mirrors admin_nav
   * above exactly but uses the ManageGuild-tier isGuildManager() check
   * `/tickets` itself uses (see that command's doc comment for why).
   */
  ticketdash_nav: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر (Manage Server) لاستخدام لوحة إدارة التذاكر.')], ephemeral: true });
    }

    const sectionId = interaction.values[0];
    // Tasks 33-36: pass guildConfig so real section views can read live settings.
    const view = buildTicketDashSectionView(settings, sectionId, guildConfig);
    if (!view) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'هذا القسم غير معروف أو أصبح غير متاح.')], ephemeral: true });
    }

    await interaction.update({ embeds: view.embeds, components: view.components });
  },

  /** 🎛️ Filter selection from music panel. customId: mr_select_filter */
  mr_select_filter: async (interaction) => {
    const { getGuildConfig, resolved } = require('../utils/resolveGuildSettings');
    const { errorEmbed, successEmbed } = require('../utils/embeds');
    const { requireActiveQueue } = require('../utils/musicChecks');

    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    const queue = await requireActiveQueue(interaction, settings);
    if (!queue) return;

    const chosen = interaction.values[0];

    try {
      if (chosen === 'clear') {
        queue.filters.ffmpeg.setFilters(false);
        return interaction.update({ content: '✅ تمت إزالة جميع الفلاتر.', components: [] });
      }
      const enabled = queue.filters.ffmpeg.getFiltersEnabled();
      if (enabled.includes(chosen)) {
        // toggle off
        const remaining = enabled.filter(f => f !== chosen);
        queue.filters.ffmpeg.setFilters(remaining.length ? remaining.reduce((a, f) => ({ ...a, [f]: true }), {}) : false);
        return interaction.update({ content: `✅ تم إيقاف فلتر **${chosen}**.`, components: [] });
      } else {
        queue.filters.ffmpeg.toggle([chosen]);
        return interaction.update({ content: `✅ تم تفعيل فلتر **${chosen}**.`, components: [] });
      }
    } catch (err) {
      return interaction.reply({ embeds: [errorEmbed(settings, `تعذر تطبيق الفلتر: ${err.message}`)], ephemeral: true });
    }
  },
};
