const { ChatInputCommandInteraction , Client , SlashCommandBuilder,Events , ActivityType,ModalBuilder,TextInputStyle, EmbedBuilder , PermissionsBitField,ButtonStyle, TextInputBuilder, ActionRowBuilder,ButtonBuilder,MessageComponentCollector, Embed } = require("discord.js");
const { Database } = require("st.db")
const dd = new Database("/Json-db/Bots/ticketDB.json")
const discordTranscripts = require('discord-html-transcripts');
const logger = require('../utils/logger');
const { queueRename } = require('../services/ticketRenameQueue');
    /**
     * @param {ChatInputCommandInteraction} interaction
     * @param {Client} client27
     */
module.exports = (client27 , interaction) => {
  client27.on(Events.InteractionCreate , async(interaction) =>{
    if(interaction.isStringSelectMenu()) {


      if(interaction.customId === "supportPanel"){
          let selected = await dd.get(`${interaction.channel.id}`)
      //    let panelFind = await panels.findOne({guildid:interaction.guild.id , panelId:selected.panelId})
         const Support = dd.get(`TICKET-PANEL_${interaction.channel.id}`).Support;

          if (!interaction.member.roles.cache.has(Support)) return interaction.reply({content:`**لا تمتلك الصلاحية لفعل هذا**` , ephemeral:true})
          
          if(interaction.values[0] === "renameTicket"){
                const modal = new ModalBuilder().setTitle('تغيير اسم التكت').setCustomId('renameTicketSubmitModal');
                const newNameInp = new TextInputBuilder().setCustomId('newNameValue').setLabel('اسم التذكرة الجديد').setStyle(TextInputStyle.Short).setRequired(true);
                const inpRow = new ActionRowBuilder().addComponents(newNameInp);
                modal.addComponents(inpRow);
                await interaction.showModal(modal);
          }else if(interaction.values[0] === "addMemberToTicket"){
              const modal = new ModalBuilder().setTitle('اضافة عضو للتذكرة').setCustomId('addMemberToTicketSubmitModal');
              const memberIdInp = new TextInputBuilder().setCustomId('addMemberToTicketMemberId').setLabel('ايدي العضو').setStyle(TextInputStyle.Short).setRequired(true);
              const inpRow = new ActionRowBuilder().addComponents(memberIdInp);
              modal.addComponents(inpRow);
              await interaction.showModal(modal);
          }else if(interaction.values[0] === "removeMemberFromTicket"){
            const modal = new ModalBuilder().setTitle('حذف عضو من التذكرة').setCustomId('removeMemberFromTicketSubmitModal');
            const memberIdInp = new TextInputBuilder().setCustomId('removeMemberFromTicketMemberId').setLabel('ايدي العضو').setStyle(TextInputStyle.Short).setRequired(true);
            const inpRow = new ActionRowBuilder().addComponents(memberIdInp);
            modal.addComponents(inpRow);
            await interaction.showModal(modal);
          }else if(interaction.values[0] === "refreshSupportPanel"){
              try {
                return await interaction.update().catch(async() => {return;})
              } catch  {
                return;
              }
          }
          
      }
    }
 
    if(interaction.isModalSubmit()){
        //---------------------- RENAME ----------------------//
        if(interaction.customId == "renameTicketSubmitModal"){
            const newName = interaction.fields.getTextInputValue('newNameValue');
            // TASK 03 (إصلاح reply/update في Rename Ticket): this used to
            // call interaction.reply(...) immediately followed by
            // interaction.update() on the SAME interaction. A modal-submit
            // interaction can only be acknowledged once - reply() already
            // does that - so the update() call was guaranteed to throw
            // "InteractionAlreadyReplied" every single time, silently
            // swallowed by .catch(async () => { return; }). It never did
            // anything; removing it changes no user-visible behavior.
            await interaction.reply({embeds : [new EmbedBuilder().setColor('Green').setDescription(`**تم تغيير الاسم التكت ل \`${newName}\`**`).setAuthor({name : interaction.guild.name , iconURL : interaction.guild.iconURL()}).setFooter({text : `تم الطلب من قبل: ${interaction.user.username}` , iconURL : interaction.user.displayAvatarURL()})]})
            // TASK 20: بدل await مباشر على channel.setName() (كان يخضع
            // مباشرةً لـRate Limit ديسكورد بدون أي حماية)، نُمرّر الطلب
            // إلى الطابور المركزي (ticketRenameQueue) الذي يُطبّق Debounce
            // وRate Limit Tracking ويمنع تراكم الطلبات. queueRename لا
            // تُنتظر عمداً - الرد على الـInteraction تمّ قبلها (interaction.reply).
            queueRename(interaction.channel, newName, { context: 'legacy_rename_ticket' });
       //---------------------- ADD MEMBER ----------------------//
        }else if(interaction.customId == "addMemberToTicketSubmitModal"){
          const memberId = interaction.fields.getTextInputValue('addMemberToTicketMemberId');
          // TASK 04 (إصلاح reply/update في Add Member):
          // 1) users.fetch() rejects (throws) for an invalid/unknown id instead
          //    of resolving to a falsy value, so the "not found" branch below
          //    was unreachable and an invalid id crashed the handler. The
          //    sibling Remove Member branch already guards this with
          //    `.catch(() => {return;})`; mirroring that here is what actually
          //    makes the documented "member not found" case work.
          // 2) Same bug as Rename Ticket (TASK 03): interaction.reply(...)
          //    followed by interaction.update() on the same modal-submit
          //    interaction always threw "InteractionAlreadyReplied", silently
          //    swallowed by .catch(). It never did anything; removing it
          //    changes no user-visible behavior.
          const theMember = await client27.users.fetch(memberId).catch(() => {return;})
          if(theMember){
            await interaction.reply({embeds : [new EmbedBuilder().setColor('Green').setDescription(`**تم اضافة \`${theMember.username}\` للتذكرة**`).setAuthor({name : interaction.guild.name , iconURL : interaction.guild.iconURL()}).setFooter({text : `تم الطلب من قبل: ${interaction.user.username}` , iconURL : interaction.user.displayAvatarURL()})]})
            await interaction.channel.permissionOverwrites.edit(theMember.id , {
              ViewChannel: true,
              SendMessages: true
            })
          }else{
            await interaction.reply({embeds : [new EmbedBuilder().setColor('Red').setDescription(`**عذرا لم اجد عضوا بهذا الايدي \`${memberId}\`**`).setAuthor({name : interaction.guild.name , iconURL : interaction.guild.iconURL()}).setFooter({text : `تم الطلب من قبل: ${interaction.user.username}` , iconURL : interaction.user.displayAvatarURL()})] , ephemeral : true})
          }
        //---------------------- REMOVE MEMBER ----------------------//
        }else if(interaction.customId == "removeMemberFromTicketSubmitModal"){
          const memberId = interaction.fields.getTextInputValue('removeMemberFromTicketMemberId');
          // TASK 05 (إصلاح reply/update في Remove Member): same bug as
          // Rename Ticket (TASK 03) and Add Member (TASK 04) -
          // interaction.reply(...) followed by interaction.update() on the
          // same modal-submit interaction always threw
          // "InteractionAlreadyReplied", silently swallowed by .catch().
          // It never did anything; removing it changes no user-visible
          // behavior. The member-not-found handling here (.catch(() => {return;})
          // on users.fetch) was already correct and is unchanged.
            const theMember = await client27.users.fetch(memberId).catch(() => {return;})
          if(theMember){
            await interaction.reply({embeds : [new EmbedBuilder().setColor('Green').setDescription(`**تم حذف \`${theMember.username}\` من التذكرة**`).setAuthor({name : interaction.guild.name , iconURL : interaction.guild.iconURL()}).setFooter({text : `تم الطلب من قبل: ${interaction.user.username}` , iconURL : interaction.user.displayAvatarURL()})]})
            await interaction.channel.permissionOverwrites.edit(theMember.id , {
              ViewChannel: false,
              SendMessages: false
            })
          }else{
            await interaction.reply({embeds : [new EmbedBuilder().setColor('Red').setDescription(`**عذرا لم اجد عضوا بهذا الايدي \`${memberId}\`**`).setAuthor({name : interaction.guild.name , iconURL : interaction.guild.iconURL()}).setFooter({text : `تم الطلب من قبل: ${interaction.user.username}` , iconURL : interaction.user.displayAvatarURL()})] , ephemeral : true})
          }
        }
    }
  }
  )}