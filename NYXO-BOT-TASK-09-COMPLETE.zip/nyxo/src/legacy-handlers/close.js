const { Events, EmbedBuilder, ActionRowBuilder, ButtonStyle, ButtonBuilder } = require("discord.js");
const { Database } = require('st.db');
const db = new Database('/Json-db/Bots/ticketDB');
const confirme = "هل انت متأكد من إغلاقك للتذكرة؟";
const discordTranscripts = require('discord-html-transcripts');

module.exports = (client7) => {
  client7.on(Events.InteractionCreate, async (interaction) => {
    try {
    if (interaction.isButton()) {
      const { customId } = interaction;

      if (customId === 'close') {
        const row = new ActionRowBuilder()
          .addComponents(
            new ButtonBuilder().setCustomId('Yes11').setLabel('إغلاق').setStyle(ButtonStyle.Danger),
            new ButtonBuilder().setCustomId('No11').setLabel('إلغاء').setStyle(ButtonStyle.Secondary),
          );



    await interaction.reply({ content: confirme, components: [row] });


      } else if (customId === 'Yes11') {
        const id = db.get('closed');
        const Ticket = db.get(`TICKET-PANEL_${interaction.channel.id}`);

        await interaction.deferUpdate();
        await interaction.channel.permissionOverwrites.edit(Ticket.author, { ViewChannel: false });
        const embed2 = new EmbedBuilder()
        .setDescription(`تم اغلاق تذكرة بواسطة ${interaction.user}`)
        .setColor("Yellow");
        const embed = new EmbedBuilder()
        .setDescription("```لوحة فريق الدعم.```")
        .setColor("DarkButNotBlack");
        const roww = new ActionRowBuilder()
          .addComponents(
            new ButtonBuilder().setCustomId('delete').setLabel('حذف').setStyle(ButtonStyle.Danger),
            new ButtonBuilder().setCustomId('Open').setLabel('فتح').setStyle(ButtonStyle.Success),
            new ButtonBuilder().setCustomId('Tran').setLabel('نسخة المحادثة').setStyle(ButtonStyle.Secondary),
          );

await interaction.editReply({ 
    content: '', 
    embeds: [embed2, embed], 
    components: [roww]
});


        const Logs = db.get(`LogsRoom_${interaction.guild.id}`);
        const logChannel = interaction.guild.channels.cache.get(Logs);
        const embedLog = new EmbedBuilder()
          .setAuthor({ name: interaction.user.username, iconURL: interaction.user.displayAvatarURL() })
          .setTitle('إغلاق تذكرة')
          .setFields(
            { name: `اسم التذكرة`, value: `${interaction.channel.name}` },
            { name: `صاحب التذكرة`, value: `${Ticket.author}` },
            { name: `أُغلقت بواسطة`, value: `${interaction.user}` },
          )
          .setFooter({ text: interaction.user.username, iconURL: interaction.user.displayAvatarURL() });

        logChannel?.send({ embeds: [embedLog] });

      } else if (customId === 'No11') {
        await interaction.deferUpdate();
        await interaction.deleteReply();

      } else if (customId === 'delete') {
        await interaction.reply({ content: `#${interaction.channel} تم حذفها بنجاح :unlock:`, ephemeral: true });
        setTimeout(async () => {
          await interaction.channel.delete();
        }, 5000);

        const Logs = db.get(`LogsRoom_${interaction.guild.id}`);
        const logChannel = interaction.guild.channels.cache.get(Logs);
        const Ticket = db.get(`TICKET-PANEL_${interaction.channel.id}`);
        const embedLog = new EmbedBuilder()
          .setAuthor({ name: interaction.user.username, iconURL: interaction.user.displayAvatarURL() })
          .setTitle('حذف تذكرة')
          .setFields(
            { name: `اسم التذكرة`, value: `${interaction.channel.name}` },
            { name: `صاحب التذكرة`, value: `${Ticket.author}` },
            { name: `حُذفت بواسطة`, value: `${interaction.user}` },
          )
          .setFooter({ text: interaction.user.username, iconURL: interaction.user.displayAvatarURL() });

        logChannel?.send({ embeds: [embedLog] });
        db.delete(`TICKET-PANEL_${interaction.channel.id}`);

      } else if (customId === 'Open') {
        const Ticket = db.get(`TICKET-PANEL_${interaction.channel.id}`);
        await interaction.deferUpdate();
        await interaction.channel.permissionOverwrites.edit(Ticket?.author, { ViewChannel: true });
        await interaction.deleteReply();

      } else if (customId === 'Tran') {
        await interaction.deferReply({ ephemeral: true });

        const channel = interaction.channel;
        const attachment = await discordTranscripts.createTranscript(channel);

        const Logs = db.get(`LogsRoom_${interaction.guild.id}`);
        const Trans = db.get(`TransRoom_${interaction.guild.id}`);
        const logChannel = interaction.guild.channels.cache.get(Logs);
        const TransChannel = interaction.guild.channels.cache.get(Trans);
        const Ticket = db.get(`TICKET-PANEL_${interaction.channel.id}`);
        if (!TransChannel) {
          await interaction.editReply({ content: "لم يتم تحديد روم لوغ، استخدم /set-log لتحديده." });
          return;
         }
        const embed = new EmbedBuilder()
          .setAuthor({ name: interaction.user.username, iconURL: interaction.user.displayAvatarURL() })
          .setTitle('نسخة محادثة تذكرة')
          .setFields(
            { name: `اسم التذكرة`, value: `${interaction.channel.name}` },
            { name: `صاحب التذكرة`, value: `${Ticket.author}` },
            { name: `نُسخت بواسطة`, value: `${interaction.user}` },
          )
          .setFooter({ text: interaction.user.username, iconURL: interaction.user.displayAvatarURL() });

        logChannel?.send({ embeds: [embed] });
        TransChannel?.send({ files: [attachment] });
        await interaction.editReply({ content: `#${interaction.channel.name} تم نسخ محادثتها بنجاح` });
      }
    }
  } catch (err) {
    const logger = require('../utils/logger');
    logger.error('[legacy/close.js] Runtime error: ' + (err.stack || err));
  }
  });
};
