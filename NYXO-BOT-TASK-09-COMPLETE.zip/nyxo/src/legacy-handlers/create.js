const { Database } = require("st.db");
const db = new Database('/Json-db/Bots/ticketDB');
const { 
    StringSelectMenuOptionBuilder,
    StringSelectMenuBuilder,
    SlashCommandBuilder,
    Events,
    ActivityType,
    ModalBuilder,
    TextInputStyle,
    EmbedBuilder,
    PermissionsBitField,
    ButtonStyle,
    TextInputBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    MessageComponentCollector,
    Embed
} = require("discord.js");

module.exports = (client27) => {
    client27.on(Events.InteractionCreate, async (interaction) => {
        try {
        if ((interaction.isButton() || interaction.isStringSelectMenu()) && interaction.customId.startsWith('ticket')) {
            const customId = interaction.isStringSelectMenu() ? interaction.values[0] : interaction.customId;
        if (customId === 'reset') {
            return; 
        }
            const data = db.get(`Ticket_${interaction.channel.id}_${customId}`);
            // Task 2 (ticket merge): this legacy handler used to reply
            // "Please Setup Again" for ANY button/select whose customId
            // starts with "ticket" and has no matching entry in the old
            // st.db store - including the new ticket system's own
            // ticket_create / ticket_claim / ticket_close / etc.
            // customIds, which are never present in this old store.
            // That caused this handler to try to reply() to interactions
            // the new system (src/components/buttons.js, wired through
            // src/events/interaction/interactionCreate.js) had already
            // acknowledged (e.g. via showModal), throwing an
            // "already replied/acknowledged" error and risking a crash
            // (this listener has no try/catch of its own). Since this
            // legacy handler only owns interactions it has matching data
            // for, silently doing nothing when there is no match is the
            // correct no-op - it leaves genuine old-system panels (where
            // data exists) completely unaffected.
            if (!data) return;

            if (data.Ask === 'on') {
                const modal = new ModalBuilder()
                    .setCustomId(customId + '_modal')
                    .setTitle('سبب فتح التذكرة')
                    .addComponents(
                        new ActionRowBuilder().addComponents(
                            new TextInputBuilder()
                                .setCustomId('ticket_reason')
                                .setLabel('ما هو سبب فتح التكت')
                                .setStyle(TextInputStyle.Short)
                                .setRequired(true)
                        )
                    );
                await interaction.showModal(modal);
            } else {
                createTicketChannel(interaction, data);
            }
        }

        if (interaction.isModalSubmit() && interaction.customId.endsWith('_modal')) {
            const buttonCustomId = interaction.customId.replace('_modal', '');
            const data = db.get(`Ticket_${interaction.channel.id}_${buttonCustomId}`);
            // Same no-op-on-no-match fix as above, for the modal-submit
            // branch (e.g. so it never fires on the new system's own
            // ..._modal submissions such as the rating-comment modal).
            if (!data) return;
            
            const ticketReason = interaction.fields.getTextInputValue('ticket_reason');
            createTicketChannel(interaction, data, ticketReason);
        }

      } catch (err) {
        const logger = require('../utils/logger');
        logger.error('[legacy/create.js] Runtime error: ' + (err.stack || err));
      }
    });
};

async function createTicketChannel(interaction, data, ticketReason = null) {
    const channel = await interaction.guild.channels.create({
        name: `ticket-${interaction.user.username}`,
        type: 0,
        parent: data.Category,
        permissionOverwrites: [
            {
                id: interaction.guild.roles.everyone.id,
                deny: ['ViewChannel'],
            },
            {
                id: data.Support,
                allow: ['ViewChannel', 'SendMessages'],
            },
            {
                id: interaction.user.id,
                allow: ['ViewChannel', 'SendMessages'],
            },
        ],
    });

    db.set(`TICKET-PANEL_${channel.id}`, { author: interaction.user.id, Support: data.Support });
    interaction.reply({ content: `${channel} تم إنشاؤها :white_check_mark:`, ephemeral: true });

    const embed = new EmbedBuilder()
        .setColor('Random')
        .setDescription(`${data.Internal}`)
        .setFooter({ text: interaction.user.username, iconURL: interaction.user.displayAvatarURL() })
        .setAuthor({ name: interaction.guild.name, iconURL: interaction.guild.iconURL() })
        .setTimestamp();

    const select = new StringSelectMenuBuilder()
        .setCustomId('supportPanel')
        .setPlaceholder('لوحة تحكم السبورت')
        .addOptions(
            new StringSelectMenuOptionBuilder()
                .setLabel('تغيير اسم التكت')
                .setValue('renameTicket')
                .setEmoji('✍🏼'),
            new StringSelectMenuOptionBuilder()
                .setLabel('اضافة عضو للتذكرة')
                .setValue('addMemberToTicket')
                .setEmoji('✅'),
            new StringSelectMenuOptionBuilder()
                .setLabel('حذف عضو من التذكرة')
                .setValue('removeMemberFromTicket')
                .setEmoji('⛔'),
            new StringSelectMenuOptionBuilder()
                .setLabel('اعادة تحميل')
                .setValue('refreshSupportPanel')
                .setEmoji('🔄'),
        );

    const row2 = new ActionRowBuilder().addComponents(select);
    const row = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder().setCustomId('close').setLabel('إغلاق').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('claim').setLabel('استلام').setStyle(ButtonStyle.Success)
        );

    if (data.Type === 'embed') {
        await channel.send({ 
            content: `${interaction.user},<@&${data.Support}>`, 
            embeds: [embed], 
            components: [row, row2] 
        });
    } else {
        await channel.send({ 
            content: `${interaction.user},<@&${data.Support}>\n${data.Internal}`, 
            components: [row, row2] 
        });
    }

    if (ticketReason) {
        const reasonEmbed = new EmbedBuilder()
            .setColor('Random')
            .setDescription(`**سبب فتح التكت : \`\`\` ${ticketReason} \`\`\`**`)
            .setTimestamp();
        
        await channel.send({ embeds: [reasonEmbed] });
    }
}
