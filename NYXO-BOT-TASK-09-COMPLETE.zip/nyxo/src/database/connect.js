const mongoose = require('mongoose');
const { config } = require('../config/config');
const logger = require('../utils/logger');

mongoose.set('strictQuery', true);

// Connection options for a resilient MongoDB connection.
// These are passed once and apply to all operations on this connection.
//
// serverSelectionTimeoutMS — how long (ms) Mongoose waits when selecting a
//   server before giving up and throwing. Default is 30 000 (30 s); keeping
//   it at 10 s makes startup failures visible faster without being too tight.
//
// socketTimeoutMS — idle-socket timeout. 0 = no timeout (Mongoose default),
//   which means a stalled query can hang the event loop indefinitely. 45 s
//   is a safe ceiling that covers slow aggregations while still detecting
//   truly dead sockets.
//
// heartbeatFrequencyMS — how often the driver pings replica-set/cluster
//   members to confirm they are still alive. Default 10 000 ms. Keeping the
//   default here; listed explicitly so the intent is clear.
//
// maxPoolSize — maximum number of simultaneous connections the driver
//   maintains. Default 5 is fine for a single-bot process; raise if you see
//   "waiting for connection from pool" under heavy load.
//
// minPoolSize — TASK 27: keep at least 1 connection open at all times.
//   Without this, under light load the driver can shrink the pool to 0 and
//   then pay the full TCP + TLS + MongoDB auth handshake on the next query.
//   A floor of 1 means there is always a warm socket ready, removing that
//   cold-start latency spike for the first query after an idle period.
//
// family: 4 — force IPv4. Avoids a multi-second delay on hosts where DNS
//   returns both AAAA and A records but only A is reachable (common on some
//   VPS providers). Safe to remove if your deployment is IPv6-native.
const CONNECT_OPTIONS = {
  serverSelectionTimeoutMS: 10_000,
  socketTimeoutMS: 45_000,
  heartbeatFrequencyMS: 10_000,
  maxPoolSize: 5,
  minPoolSize: 1,
  family: 4,
};

// Track whether the event listeners have already been registered so they
// are never stacked on repeated calls to connectDatabase().
let listenersRegistered = false;

function registerConnectionListeners() {
  if (listenersRegistered) return;
  listenersRegistered = true;

  mongoose.connection.on('disconnected', () => {
    logger.warn('MongoDB connection lost. Mongoose will attempt to reconnect automatically.');
  });

  mongoose.connection.on('reconnected', () => {
    logger.success('MongoDB reconnected successfully.');
  });

  mongoose.connection.on('error', (err) => {
    logger.error(`MongoDB connection error: ${err.message}`);
  });

  mongoose.connection.on('close', () => {
    logger.info('MongoDB connection closed.');
  });
}

/**
 * Task 3 (shared database): this is the ONE MongoDB/Mongoose connection
 * used by all 3 bots (bot1/bot2/bot3). It is intentionally called only
 * once, from src/index.js, BEFORE any bot client is created — every
 * model in src/database/models/* and every service/command in the
 * project talks to this same `mongoose` default connection regardless
 * of which bot's client is handling the interaction. There is no
 * per-bot database or per-bot connection, matching the requirement
 * that bot1/bot2/bot3 share exactly one database.
 *
 * Guarded against being awaited more than once (e.g. a future code
 * path or a test script) - a second call just resolves immediately
 * instead of throwing or opening a second connection.
 */
async function connectDatabase() {
  // Register listeners once — before connecting so 'connecting' and early
  // errors are not missed, and regardless of whether we end up skipping below.
  registerConnectionListeners();

  if (mongoose.connection.readyState === 1) {
    logger.info('MongoDB already connected - reusing existing shared connection.');
    return;
  }

  try {
    await mongoose.connect(config.mongoUri, CONNECT_OPTIONS);
    logger.success('Connected to MongoDB (single shared connection for bot1/bot2/bot3)');
  } catch (err) {
    logger.error(`Failed to connect to MongoDB: ${err.message}`);
    process.exit(1);
  }
}

module.exports = connectDatabase;
