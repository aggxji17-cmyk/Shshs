const { Schema, model, models } = require('mongoose');

const reminderSchema = new Schema({
  userId: { type: String, required: true, index: true },
  guildId: { type: String, default: null },
  channelId: { type: String, required: true },
  message: { type: String, required: true },
  remindAt: { type: Date, required: true, index: true },
  createdAt: { type: Date, default: Date.now },
  sent: { type: Boolean, default: false },
});

module.exports = models.Reminder || model('Reminder', reminderSchema);
