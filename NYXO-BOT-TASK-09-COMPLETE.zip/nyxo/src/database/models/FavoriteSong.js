const { Schema, model, models } = require('mongoose');

/**
 * A single saved track inside a user's favorites list. Same flat
 * snapshot shape as Playlist's embedded track (see
 * database/models/Playlist.js) - title/duration/thumbnail are cached
 * at add-time so /favorites list never needs a network round trip,
 * while `url` is what actually gets re-resolved on /favorites play.
 */
const favoriteTrackSchema = new Schema(
  {
    title: { type: String, required: true },
    url: { type: String, required: true },
    duration: { type: String, default: null },
    thumbnail: { type: String, default: null },
    author: { type: String, default: null },
    addedAt: { type: Date, default: Date.now },
  },
  { _id: false }
);

/**
 * One document per user - unlike Playlist (many named lists per user),
 * a user has exactly one favorites list, so `userId` alone is the
 * unique key. Not guild-scoped, for the same reason Playlist isn't:
 * favorites follow the user across every server the bot is in.
 */
const favoriteSongSchema = new Schema(
  {
    userId: { type: String, required: true, unique: true, index: true },
    tracks: { type: [favoriteTrackSchema], default: [] },
  },
  { timestamps: true }
);

module.exports = models.FavoriteSong || model('FavoriteSong', favoriteSongSchema);
