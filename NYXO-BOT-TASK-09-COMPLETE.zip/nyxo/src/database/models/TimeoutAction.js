const { Schema, model, models } = require('mongoose');

/**
 * One document per successful timeout. Used to enforce the per-role weekly
 * timeout limit (timeoutLimitService counts these within the current week)
 * and doubles as a lightweight audit trail of who timed out whom, for how
 * long, and when.
 */
const timeoutActionSchema = new Schema(
  {
    guildId: { type: String, required: true, index: true },
    moderatorId: { type: String, required: true, index: true },
    targetId: { type: String, required: true },
    durationMinutes: { type: Number, required: true },
    reason: { type: String, default: 'No reason provided' },
  },
  { timestamps: true }
);

// Most lookups are "timeouts by this moderator, in this guild, since date X".
timeoutActionSchema.index({ guildId: 1, moderatorId: 1, createdAt: 1 });

module.exports = models.TimeoutAction || model('TimeoutAction', timeoutActionSchema);
