const { Schema, model, models } = require('mongoose');

const userLevelSchema = new Schema(
  {
    guildId: { type: String, required: true },
    userId: { type: String, required: true, index: true },
    xp: { type: Number, default: 0 },
    level: { type: Number, default: 0 },
    messages: { type: Number, default: 0 },
    lastMessageAt: { type: Date, default: null },
    // TASK26 (Voice XP): mirrors `messages` above, but counts completed
    // voice-XP intervals (see services/voiceXpService.js) instead of
    // messages sent. Purely a stat for /rank - it plays no part in the
    // XP/level math, which only ever reads/writes `xp` (both message XP
    // and voice XP $inc the same `xp` field - see
    // services/levelingService.js's grantMessageXp/grantVoiceXp), so
    // Total XP is always "message XP + voice XP" with no separate voice
    // UserLevel document anywhere.
    voiceMinutes: { type: Number, default: 0 },
  },
  { timestamps: true }
);

// Serves the guildId+userId upsert/lookup in grantMessageXp()/getRank().
// A separate single-field guildId index was removed - this compound index
// already serves any guildId-only query too (Mongo can use a compound
// index's leftmost prefix), so the old one was pure extra write overhead
// on this collection, which gets an update on nearly every message sent.
userLevelSchema.index({ guildId: 1, userId: 1 }, { unique: true });
// Serves getLeaderboard() (sort by xp within a guild) and getRank()'s
// countDocuments({guildId, xp: {$gt}}) - without this both had to filter
// by guildId then sort/scan in memory.
userLevelSchema.index({ guildId: 1, xp: -1 });

module.exports = models.UserLevel || model('UserLevel', userLevelSchema);
