const { Schema, model, models } = require('mongoose');

/**
 * Tracks a member's AFK state per guild. Cleared automatically the next
 * time they send a message (see events/message/messageCreate.js).
 *
 * TASK31: extended (additive, no fields removed/renamed - existing docs
 * missing these just read back as `null`/`[]` via the defaults below)
 * with:
 *  - `originalNick`: the member's nickname *as it was right before AFK
 *    was activated* (nullable - `null` here legitimately means "had no
 *    custom nickname", not "unknown"), so it can be restored exactly on
 *    return via `member.setNickname(originalNick)` (passing `null`
 *    correctly clears back to no-nickname, it doesn't error).
 *  - `mentions`: a bounded (see messageCreate.js's handleAfkMentions)
 *    log of *who* mentioned this member while away, one entry per
 *    mention event (so the same mentioner can appear more than once -
 *    tallied into "X mentions" on return). `mentionCount` above is kept
 *    exactly as-is (still the running total, still incremented the same
 *    way it always was) so nothing that already read it breaks; `mentions`
 *    is purely additive detail for the new "who mentioned you" summary.
 */
const afkStatusSchema = new Schema({
  guildId: { type: String, required: true, index: true },
  userId: { type: String, required: true },
  reason: { type: String, default: 'AFK' },
  mentionCount: { type: Number, default: 0 },
  since: { type: Date, default: Date.now },
  originalNick: { type: String, default: null },
  mentions: { type: [String], default: [] },
});

afkStatusSchema.index({ guildId: 1, userId: 1 }, { unique: true });

module.exports = models.AfkStatus || model('AfkStatus', afkStatusSchema);
