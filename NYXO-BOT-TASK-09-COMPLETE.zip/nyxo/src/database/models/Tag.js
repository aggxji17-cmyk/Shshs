const { Schema, model, models } = require('mongoose');

/**
 * A reusable canned-response snippet, explicitly invoked with
 * `/tag show <name>` - distinct from AutoResponder (database/models/
 * AutoResponder.js), which fires passively whenever its trigger text
 * appears in a message. Tags are for content staff want on-demand
 * (rules copy-paste, FAQ answers, apply-instructions, etc.) without
 * it firing on every mention of a word.
 */
const tagSchema = new Schema(
  {
    guildId: { type: String, required: true, index: true },
    name: { type: String, required: true },
    content: { type: String, required: true, maxlength: 2000 },
    createdBy: { type: String, required: true },
    uses: { type: Number, default: 0 },
  },
  { timestamps: true }
);

// Tag names are unique per guild (case-insensitive - normalized to
// lowercase by the command before every read/write, so this index only
// needs to guard the literal stored value).
tagSchema.index({ guildId: 1, name: 1 }, { unique: true });

module.exports = models.Tag || model('Tag', tagSchema);
