const { Schema, model, models } = require('mongoose');

/**
 * One document per command invocation, written by
 * utils/commandLogService.js right before a command actually executes
 * (so blocked/blacklisted/on-cooldown attempts are not recorded - only
 * genuine usage is). Powers /commandlogs recent and the optional live
 * usage channel (GuildConfig.commandLogging).
 *
 * guildId is nullable to also support commands used in DMs.
 * Auto-expires after 30 days so this collection doesn't grow forever -
 * plenty for reviewing recent usage without needing indefinite storage.
 *
 * Task 3 (shared database across bot1/bot2/bot3): `botKey` records
 * which of the 3 bots handled the command (e.g. "bot1"). Nullable/
 * optional so older documents written before this field existed still
 * read fine (default null == "unknown/legacy"), and single-bot setups
 * that don't set client.botKey are unaffected. Indexed so /commandlogs
 * (or any future audit tooling) can filter or group usage per bot to
 * confirm no cross-bot duplication is happening in practice.
 */
const commandLogSchema = new Schema(
  {
    guildId: { type: String, default: null, index: true },
    commandName: { type: String, required: true },
    userId: { type: String, required: true },
    channelId: { type: String, default: null },
    botKey: { type: String, default: null, index: true },
    createdAt: { type: Date, default: Date.now, expires: 60 * 60 * 24 * 30 },
  },
  { timestamps: false }
);

module.exports = models.CommandLog || model('CommandLog', commandLogSchema);
