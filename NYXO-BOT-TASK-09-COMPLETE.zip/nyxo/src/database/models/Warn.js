const { Schema, model, models } = require('mongoose');

const warnSchema = new Schema(
  {
    guildId: { type: String, required: true, index: true },
    userId: { type: String, required: true, index: true },
    moderatorId: { type: String, required: true },
    reason: { type: String, default: 'No reason provided' },
  },
  { timestamps: true }
);

module.exports = models.Warn || model('Warn', warnSchema);
