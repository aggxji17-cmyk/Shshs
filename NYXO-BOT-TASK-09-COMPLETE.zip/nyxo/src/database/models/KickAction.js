const { Schema, model, models } = require('mongoose');

/**
 * One document per successful kick. Used to enforce the per-role weekly
 * kick limit (kickLimitService counts these within the current week) and
 * doubles as a lightweight audit trail of who kicked whom and when.
 */
const kickActionSchema = new Schema(
  {
    guildId: { type: String, required: true, index: true },
    moderatorId: { type: String, required: true, index: true },
    targetId: { type: String, required: true },
    reason: { type: String, default: 'No reason provided' },
  },
  { timestamps: true }
);

// Most lookups are "kicks by this moderator, in this guild, since date X".
kickActionSchema.index({ guildId: 1, moderatorId: 1, createdAt: 1 });

module.exports = models.KickAction || model('KickAction', kickActionSchema);
