const { Schema, model, models } = require('mongoose');

/**
 * A guild's subscription to a Twitch channel or YouTube channel for
 * go-live / new-video announcements. `lastSeenId` stores whichever ID the
 * poller last announced (stream ID for Twitch, video ID for YouTube) so it
 * doesn't repost the same event.
 */
const streamSubscriptionSchema = new Schema(
  {
    guildId: { type: String, required: true, index: true },
    platform: { type: String, enum: ['twitch', 'youtube'], required: true },
    channelIdentifier: { type: String, required: true }, // Twitch login name or YouTube channel ID
    discordChannelId: { type: String, required: true },
    message: { type: String, default: '{channel} is now live: {title}' },
    lastSeenId: { type: String, default: null },
    isLive: { type: Boolean, default: false },
  },
  { timestamps: true }
);

streamSubscriptionSchema.index({ guildId: 1, platform: 1, channelIdentifier: 1 }, { unique: true });

module.exports = models.StreamSubscription || model('StreamSubscription', streamSubscriptionSchema);
