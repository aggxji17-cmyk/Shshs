const { Schema, model, models } = require('mongoose');

/**
 * One document per original message that has been (or is being tracked to
 * potentially be) posted to the starboard, so we can find and edit/delete
 * the mirrored post as star reactions change.
 */
const starboardSchema = new Schema({
  guildId: { type: String, required: true, index: true },
  sourceChannelId: { type: String, required: true },
  sourceMessageId: { type: String, required: true, unique: true },
  starboardMessageId: { type: String, default: null },
  starCount: { type: Number, default: 0 },
});

module.exports = models.Starboard || model('Starboard', starboardSchema);
