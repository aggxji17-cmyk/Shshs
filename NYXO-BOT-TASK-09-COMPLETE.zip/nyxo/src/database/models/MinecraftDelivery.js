const { Schema, model, models } = require('mongoose');

/**
 * One document per shop-purchase in-game delivery attempt (Task 4: shop
 * <-> Minecraft bridge). This is the durable side of "تسجيل جميع
 * العمليات في اللوق" - every attempt is recorded here regardless of
 * whether a log channel is configured (see
 * GuildConfig.minecraft.deliveryLogChannelId / services/minecraftDeliveryService.js
 * for the live channel-embed side of logging).
 *
 * Usually written exactly once, already in a terminal state ("done" /
 * "failed") - the delivery service waits for NovaBridge's command queue
 * to settle (see services/commandQueueService.js#runCommand) before
 * persisting anything here, so most rows never pass through any other
 * status.
 *
 * Task 5 exception: an "item"-kind purchase (ShopItem.minecraft.kind)
 * bought while the player is offline starts as "queued" instead (command
 * not sent yet), and services/minecraftPendingDeliveryService.js updates
 * this same row to "done"/"failed" once it's actually delivered on join -
 * see database/models/MinecraftPendingDelivery.js, which holds the
 * queued-state bookkeeping this row's `deliveryId` link points back from.
 */
const minecraftDeliverySchema = new Schema(
  {
    guildId: { type: String, required: true, index: true },
    discordUserId: { type: String, required: true, index: true },
    minecraftUuid: { type: String, required: true },
    minecraftUsername: { type: String, required: true },

    itemName: { type: String, required: true }, // ShopItem.name at time of purchase
    targetServerId: { type: String, required: true }, // MinecraftServer._id the command was sent to
    command: { type: String, required: true }, // fully-substituted console command that was (or will be) sent

    status: { type: String, enum: ['queued', 'done', 'failed'], required: true },
    error: { type: String, default: null }, // set when status === 'failed'
    deliveredAt: { type: Date, default: null }, // set when a "queued" row transitions to "done"/"failed"

    // Links back to the ServerCommand document (database/models/ServerCommand.js)
    // this delivery was carried out through, for cross-referencing/debugging.
    serverCommandId: { type: Schema.Types.ObjectId, default: null },

    requestedBy: { type: String, default: null }, // e.g. "discord:123456789012345678"
  },
  { timestamps: true }
);

minecraftDeliverySchema.index({ guildId: 1, createdAt: -1 });

module.exports = models.MinecraftDelivery || model('MinecraftDelivery', minecraftDeliverySchema);
