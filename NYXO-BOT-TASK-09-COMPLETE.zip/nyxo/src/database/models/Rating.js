const { Schema, model, models } = require('mongoose');

// One rating per ticket - `ticketId` is unique so a duplicate submission
// (e.g. a race between two clicks) fails at the database level even if the
// application-level checks in components/buttons.js are ever bypassed.
const ratingSchema = new Schema(
  {
    guildId: { type: String, required: true, index: true },
    ticketId: { type: Schema.Types.ObjectId, ref: 'Ticket', required: true, unique: true },
    channelId: { type: String, required: true },
    ticketNumber: { type: Number, required: true },
    ticketUserId: { type: String, required: true },
    // Whoever claimed the ticket, falling back to whoever closed it if it
    // was never claimed. Null if neither happened (shouldn't normally occur).
    staffId: { type: String, default: null },
    stars: { type: Number, required: true, min: 1, max: 5 },
    comment: { type: String, default: null },
  },
  { timestamps: true }
);

module.exports = models.Rating || model('Rating', ratingSchema);
