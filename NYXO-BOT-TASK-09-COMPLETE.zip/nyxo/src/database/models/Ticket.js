const { Schema, model, models } = require('mongoose');

const ticketSchema = new Schema(
  {
    guildId: { type: String, required: true, index: true },
    channelId: { type: String, required: true, unique: true },
    userId: { type: String, required: true },
    ticketNumber: { type: Number, required: true },
    // Which configured panel button/type opened this ticket (see
    // GuildConfig.tickets.types). Both null on servers still using the
    // single-button legacy panel, or if the type was deleted afterwards.
    typeId: { type: String, default: null },
    typeLabel: { type: String, default: null },
    status: { type: String, enum: ['open', 'claimed', 'closed'], default: 'open' },
    claimedBy: { type: String, default: null },
    closedBy: { type: String, default: null },
    closedAt: { type: Date, default: null },
    // Smart close (task 8): while status is 'closed' the channel still
    // exists, locked, with a delete/reopen prompt posted in it. This is
    // when that prompt's permanent deletion is scheduled for - null means
    // no auto-delete timer is running (either it was disabled via
    // tickets.closePrompt.autoDeleteMinutes = 0, or the ticket isn't in
    // the pending-deletion window). Cleared whenever the ticket reopens.
    autoDeleteAt: { type: Date, default: null, index: true },
    // Mirrors which close-state emoji (see ticketPanel.js CLOSE_STATUS_EMOJI)
    // is currently applied to the channel name while status is 'closed':
    // 'pending_delete' (🔵) right after closing, then 'near_delete' (🔴)
    // once tickets.closePrompt.warningMinutes remain before auto-delete.
    // null once the ticket isn't in the pending-deletion window (open,
    // reopened, or already permanently deleted). Checked by the scheduler
    // in ticketCloseService.js so it only renames the channel once per
    // transition instead of every time it polls.
    closeStatus: { type: String, enum: ['pending_delete', 'near_delete', null], default: null },
    reopenedBy: { type: String, default: null },
    reopenedAt: { type: Date, default: null },
    // Set once finalizeTicketDeletion actually deletes the channel
    // (manually via 🗑️ or automatically once autoDeleteAt elapses).
    // The Ticket document itself is kept for ratings/history - only the
    // Discord channel is gone.
    permanentlyDeletedAt: { type: Date, default: null },
    // Reply-needed indicator, independent of open/claimed/closed above.
    // 'needs_reply' (🟡) - the ticket opener sent the last message and is
    // waiting on staff. 'no_action' (🟢) - staff (or nobody) has the ball.
    // Flips automatically on every message per whoever sent it (see
    // messageCreate.js), and can be flipped manually by staff via the
    // status button. Mirrored into the channel name so staff can read it
    // straight from the channel list - see ticketPanel.js's STATUS_EMOJI.
    replyStatus: { type: String, enum: ['needs_reply', 'no_action'], default: 'needs_reply' },
    // The channel name without its status-emoji prefix, so renames can
    // reapply the right emoji without accumulating/mismatching prefixes.
    baseChannelName: { type: String, default: null },

    // TASK32 (reply reminder ping): timestamp of the most recent message
    // sent by staff/a moderator in this ticket while the ticket opener
    // still hasn't replied since - i.e. only meaningful while
    // replyStatus === 'no_action' (see messageCreate.js's
    // handleTicketStatusUpdate). Reset to null the moment the opener
    // replies. Deliberately its own field rather than reusing
    // `updatedAt` (timestamps), since `updatedAt` also changes for
    // unrelated ticket updates (claim, rename, etc.) that must NOT count
    // as "staff is waiting on a reply".
    lastStaffMessageAt: { type: Date, default: null },
    // Set the moment the scheduler (services/ticketCloseService.js's
    // runReplyReminderPass) actually sends the "staff is waiting" ping
    // for the CURRENT `lastStaffMessageAt`, so it can never send a
    // second one for the same wait window - cleared back to null
    // whenever `lastStaffMessageAt` itself changes (a new staff message,
    // or the opener replying), which starts a fresh window.
    reminderSentAt: { type: Date, default: null },

    // TASK33 (activity tracking): timestamp of the most recent message
    // sent by the ticket OPENER (mirror of lastStaffMessageAt above, but
    // for the other side of the conversation). Cleared back to null on
    // reopen (ticketCloseService.js#reopenTicket) along with the rest of
    // the activity fields below, so a reopened ticket starts its activity
    // history fresh rather than carrying over a stale pre-close timestamp.
    lastUserMessageAt: { type: Date, default: null },
    // TASK33: max(lastUserMessageAt, lastStaffMessageAt) at the time it
    // was set - i.e. the timestamp of whichever qualifying message (from
    // the opener or from staff) most recently touched this ticket. Kept
    // as its own field rather than computed on read for the same reason
    // lastStaffMessageAt is: cheap to query/sort/display without pulling
    // both timestamps and comparing them every time. Only null-safe to
    // treat as "no activity yet" while the ticket is open/claimed since
    // creation or since its last reopen - a fresh/reopened ticket that
    // nobody has replied in yet has neither field set.
    lastActivityAt: { type: Date, default: null, index: true },
    // TASK33: who sent that most recent qualifying message - 'user' (the
    // ticket opener) or 'staff' (a moderator/admin, per isModerator()).
    // Drives the four-state workflow view (see utils/ticketPanel.js's
    // getTicketWorkflowState): null/no activity yet = Active,
    // 'user' = Waiting for Staff, 'staff' = Waiting for User, independent
    // of the closed check which always wins. Deliberately separate from
    // the pre-existing replyStatus (🟡/🟢 channel-name flag) - that one
    // can also be flipped manually by staff via the status-toggle button,
    // while lastMessageBy always reflects who *actually* spoke last.
    lastMessageBy: { type: String, enum: ['user', 'staff', null], default: null },

    // Task 5 (Race Condition fix): mirrors "status !== 'closed'" as a
    // plain boolean so it can back a partial unique index below. Set to
    // true on creation and on reopen (ticketCloseService.js#reopenTicket),
    // false on close (buttons.js#ticket_close). Kept in sync everywhere
    // `status` transitions to/from 'closed' - it is never read on its own
    // as a source of truth for ticket state, `status` still is.
    isOpen: { type: Boolean, default: true },
  },
  { timestamps: true }
);

// حد أقصى تذكرة نشطة واحدة لكل عضو في كل سيرفر - يفرضه MongoDB نفسه
// وليس كود التطبيق، فلا يمكن لأي تزامن (ضغط مزدوج، أو نداءان متزامنان)
// أن يُنشئ تذكرتين نشطتين لنفس العضو مهما كان التوقيت. partialFilterExpression
// يقصر الفهرس على الوثائق التي isOpen:true فقط، فلا يمنع تراكم عدد
// غير محدود من التذاكر المغلقة لنفس العضو - فقط يمنع تذكرتين نشطتين
// في آنٍ واحد. تُستخدم هنا مساواة بسيطة (isOpen: true) بدل $in/$ne
// لأن partialFilterExpression لا يدعم $ne إطلاقاً، ودعم $in مرتبط
// بإصدار MongoDB (5.0+) وغير مضمون على كل البيئات (مثل بعض توافقات
// DocumentDB) - المساواة البسيطة مدعومة في كل الإصدارات والبيئات.
ticketSchema.index(
  { guildId: 1, userId: 1 },
  { unique: true, partialFilterExpression: { isOpen: true }, name: 'uniq_active_ticket_per_member' }
);

// TASK32: serves runReplyReminderPass's periodic scan (services/
// ticketCloseService.js) - open/claimed tickets whose staff-is-waiting
// window is due and hasn't been reminded yet, without a full collection
// scan every pass.
ticketSchema.index({ status: 1, replyStatus: 1, reminderSentAt: 1 });

module.exports = models.Ticket || model('Ticket', ticketSchema);
