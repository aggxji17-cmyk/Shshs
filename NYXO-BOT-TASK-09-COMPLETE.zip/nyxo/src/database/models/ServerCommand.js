const { Schema, model, models } = require('mongoose');

/**
 * Bot-side mirror of NovaBridge's command queue collection
 * (`collections.commands` in the plugin's config.yml, default
 * "server_commands" - see CommandQueueService.java / PendingCommand.java
 * on the plugin side).
 *
 * This is the ONLY collection NYXO BOT writes to that a Minecraft server
 * also reads from. The flow (already implemented and working on the
 * plugin side, see NovaBridge's queue package):
 *
 *   1. NYXO BOT inserts a document here with `status: "pending"` and
 *      `targetServerId` set to the server that should run it.
 *   2. The matching NovaBridge instance polls, atomically claims it
 *      (pending -> processing), and hands it to whichever CommandHandler
 *      is registered for its `type`.
 *   3. The plugin writes the outcome back onto the SAME document
 *      (`status: "done"|"failed"`, `result`, `processedAt`).
 *   4. NYXO BOT polls this document by `_id` until it leaves "pending"/
 *      "processing", then reads `result`.
 *
 * NYXO BOT must never set `status` to anything other than "pending" on
 * insert, and must never write to `result`/`processedAt` - those are
 * owned by the plugin.
 *
 * `type: "get_inventory"` (this task's payload/result contract) is not
 * handled by the plugin yet - only "ping" and "console_command" are
 * (see BuiltinCommandHandlers.java). Requests of type "get_inventory"
 * will sit as "pending" until a future NovaBridge update registers a
 * handler for it (that update is intentionally out of scope here - see
 * services/inventoryService.js for the exact contract it needs to
 * implement).
 */
const serverCommandSchema = new Schema(
  {
    targetServerId: { type: String, required: true, index: true }, // must match a NovaBridge server.id
    type: { type: String, required: true }, // e.g. "ping", "console_command", "get_inventory"
    payload: { type: Schema.Types.Mixed, default: {} }, // handler-specific input
    status: { type: String, default: 'pending', index: true }, // pending | processing | done | failed
    requestedBy: { type: String, default: null }, // free-form origin marker, e.g. "discord:123456789012345678"
    processedAt: { type: Date, default: null }, // set by the plugin
    result: { type: Schema.Types.Mixed, default: null }, // set by the plugin: success data, or { error } on failure
  },
  { collection: 'server_commands', timestamps: { createdAt: 'createdAt', updatedAt: 'updatedAt' }, strict: false, versionKey: false }
);

module.exports = models.ServerCommand || model('ServerCommand', serverCommandSchema);
