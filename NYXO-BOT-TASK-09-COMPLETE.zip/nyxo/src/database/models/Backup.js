const { Schema, model, models } = require('mongoose');

const backupSchema = new Schema(
  {
    guildId: { type: String, required: true, index: true },
    createdBy: { type: String, required: true },
    name: { type: String, default: 'backup' },
    data: {
      name: String,
      roles: [
        {
          name: String,
          color: Number,
          hoist: Boolean,
          mentionable: Boolean,
          permissions: String,
          position: Number,
        },
      ],
      channels: [
        {
          name: String,
          type: Number,
          topic: String,
          parentName: { type: String, default: null },
          position: Number,
        },
      ],
    },
  },
  { timestamps: true }
);

module.exports = models.Backup || model('Backup', backupSchema);
