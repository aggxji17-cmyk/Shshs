const { Schema, model, models } = require('mongoose');

/**
 * A single saved track inside a playlist. Deliberately just a flat
 * snapshot of what discord-player's Track exposed at add-time (not a
 * live reference) - the source (YouTube/Spotify/SoundCloud) can be
 * re-resolved from `url` on playback, but title/duration/thumbnail are
 * cached here so /playlist view never has to hit the network.
 */
const playlistTrackSchema = new Schema(
  {
    title: { type: String, required: true },
    url: { type: String, required: true },
    duration: { type: String, default: null },
    thumbnail: { type: String, default: null },
    author: { type: String, default: null },
    addedAt: { type: Date, default: Date.now },
  },
  { _id: false }
);

/**
 * Playlists belong to a user, not a guild - the same personal playlist
 * can be queued from /playlist play in any server the bot and the
 * owner are both in, matching how a user's own music library works
 * everywhere else (Spotify, YouTube Music, ...).
 */
const playlistSchema = new Schema(
  {
    userId: { type: String, required: true, index: true },
    name: { type: String, required: true },
    // Lowercased mirror of `name`, used only for the case-insensitive
    // uniqueness check below and for lookups - keeps `name` itself free
    // to display with whatever casing the user originally typed.
    nameKey: { type: String, required: true },
    tracks: { type: [playlistTrackSchema], default: [] },
  },
  { timestamps: true }
);

playlistSchema.index({ userId: 1, nameKey: 1 }, { unique: true });

module.exports = models.Playlist || model('Playlist', playlistSchema);
