const { Schema, model, models } = require('mongoose');

const APPROVAL_STATUSES = ['Pending', 'Approved', 'Rejected', 'Expired', 'Cancelled'];

/**
 * One document per approval-gated moderation request (services/
 * approvalService.js). Deliberately NOT restricted to a fixed `action`
 * enum - unlike Case/ScheduledTask - because the whole point of this
 * system is that any current or future moderation command can be put
 * behind approval just by adding its name to
 * GuildConfig.approvals.requiredActions and registering an executor via
 * scheduleService.registerHandler. This document only ever describes the
 * *request*; once approved, the real action is executed through the exact
 * same executors services/scheduleService.js already uses for scheduled
 * tasks, which is what actually creates the Case (services/caseService.js)
 * and posts the moderation log (utils/moderationLogService.js).
 */
const approvalRequestSchema = new Schema(
  {
    guildId: { type: String, required: true, index: true },
    action: { type: String, required: true },

    moderatorId: { type: String, required: true }, // the requester
    targetId: { type: String, required: true },

    reason: { type: String, default: 'No reason provided' },
    // Only meaningful for 'timeout'.
    durationMinutes: { type: Number, default: null },
    // Only meaningful for 'ban'/'softban'.
    deleteDays: { type: Number, default: 0 },

    status: { type: String, enum: APPROVAL_STATUSES, default: 'Pending' },

    // Where the Approve/Reject embed was posted, so decisions and the
    // auto-expiry can find and edit it in place.
    reviewChannelId: { type: String, default: null },
    reviewMessageId: { type: String, default: null },

    // The ScheduledTask (services/scheduleService.js, action:
    // 'approval_expire') that will flip this to Expired if nobody acts in
    // time. Cancelled the moment a human decision (approve/reject/cancel)
    // is made, so a late-firing expiry can never clobber a real decision.
    scheduledTaskId: { type: String, default: null },
    expiresAt: { type: Date, required: true },

    decidedBy: { type: String, default: null },
    decidedAt: { type: Date, default: null },
    rejectReason: { type: String, default: null },

    // The Case number (Case.caseId) created once an Approved request
    // actually executes - null until then, and stays null for
    // Rejected/Expired/Cancelled requests since those never ran.
    caseId: { type: Number, default: null },
  },
  { timestamps: true }
);

// /approvals list - a guild's requests, soonest-decided-first (i.e. newest
// created first), optionally filtered by status.
approvalRequestSchema.index({ guildId: 1, status: 1, createdAt: -1 });

const ApprovalRequestModel = models.ApprovalRequest || model('ApprovalRequest', approvalRequestSchema);
ApprovalRequestModel.APPROVAL_STATUSES = APPROVAL_STATUSES;

module.exports = ApprovalRequestModel;
