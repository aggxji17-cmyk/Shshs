const { Schema, model, models } = require('mongoose');

/**
 * Tracks the single live-updating Minecraft status panel message for a
 * guild (created via /setupstatus). Only channelId + messageId are needed
 * to find and edit the panel; if either the channel or the message has
 * been deleted, the scheduled refresher simply skips that guild until
 * /setupstatus is run again to recreate it.
 */
const minecraftStatusPanelSchema = new Schema(
  {
    guildId: { type: String, required: true, unique: true, index: true },
    channelId: { type: String, required: true },
    messageId: { type: String, required: true },
  },
  { timestamps: true }
);

module.exports = models.MinecraftStatusPanel || model('MinecraftStatusPanel', minecraftStatusPanelSchema);
