const { Schema, model, models } = require('mongoose');

const CASE_ACTIONS = ['ban', 'kick', 'timeout', 'warn', 'unban', 'softban'];
const CASE_STATUSES = ['Active', 'Expired', 'Reverted'];

/**
 * One document per moderation Case. Unlike the older BanAction/KickAction/
 * TimeoutAction/SoftbanAction/Warn models (which only exist to back the
 * weekly-quota and warn-threshold math), this is the unified, user-facing
 * audit trail behind /case, /cases and /editcase - every moderation
 * command creates exactly one of these (via services/caseService.js) in
 * addition to whatever quota record it already wrote.
 *
 * `caseId` is a simple per-guild sequential integer (see
 * GuildConfig.caseCounter), not the Mongo _id, so staff can reference
 * cases as short human-friendly numbers like "#42".
 */
const caseSchema = new Schema(
  {
    guildId: { type: String, required: true, index: true },
    caseId: { type: Number, required: true },

    action: { type: String, enum: CASE_ACTIONS, required: true },
    moderatorId: { type: String, required: true },
    targetId: { type: String, required: true, index: true },

    reason: { type: String, default: 'No reason provided' },
    // Free-form notes added later via /editcase, on top of (not instead
    // of) the original reason.
    notes: { type: String, default: null },

    // Only meaningful for 'timeout' cases.
    durationMinutes: { type: Number, default: null },
    // createdAt + durationMinutes, precomputed so the expiry sweep
    // (caseService.sweepExpiredTimeouts) can query it directly.
    expiresAt: { type: Date, default: null },

    status: { type: String, enum: CASE_STATUSES, default: 'Active' },

    // Populated when this case is later reverted - either a ban case
    // closed out by /unban, or a timeout case closed out by the
    // automatic expiry sweep (revertedBy: 'system' in that case).
    revertedAt: { type: Date, default: null },
    revertedBy: { type: String, default: null },
    revertReason: { type: String, default: null },
  },
  { timestamps: true }
);

// /case lookups: one specific case number within a guild.
caseSchema.index({ guildId: 1, caseId: 1 }, { unique: true });
// /cases lookups: every case for one member, newest first.
caseSchema.index({ guildId: 1, targetId: 1, caseId: -1 });
// /modhistory + moderator stats (services/auditService.js): every case by
// one moderator, filterable by date range (today/7d/30d) via createdAt.
caseSchema.index({ guildId: 1, moderatorId: 1, createdAt: -1 });
// /userinfo's punishment record, filterable by the same date ranges.
caseSchema.index({ guildId: 1, targetId: 1, createdAt: -1 });

const CaseModel = models.Case || model('Case', caseSchema);
CaseModel.CASE_ACTIONS = CASE_ACTIONS;
CaseModel.CASE_STATUSES = CASE_STATUSES;

module.exports = CaseModel;
