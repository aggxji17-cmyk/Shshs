const { Schema, model, models } = require('mongoose');

/**
 * Task 5: an item-kind purchase (see ShopItem.minecraft.kind) whose buyer
 * was NOT online on the item's `targetServerId` at purchase time.
 *
 * Created by services/minecraftDeliveryService.js#deliverPurchase instead
 * of running the command right away, and consumed by
 * services/minecraftPendingDeliveryService.js's background poller: every
 * few seconds it checks whether the buyer is now online on
 * `targetServerId` (via the read-only MinecraftPlayerCache mirror of
 * NovaBridge's `minecraft_players` collection) and, once they are, sends
 * the same console command that immediate delivery would have sent.
 *
 * One document per queued attempt. `status` starts "pending" and ends in
 * exactly one of "delivered" / "failed" - never deleted, so this table
 * doubles as part of the delivery history (paired 1:1 with the
 * MinecraftDelivery document created for it via `deliveryId`, which is
 * what actually carries the final result/log entry).
 */
const minecraftPendingDeliverySchema = new Schema(
  {
    guildId: { type: String, required: true, index: true },
    discordUserId: { type: String, required: true, index: true },
    minecraftUuid: { type: String, required: true, index: true },
    minecraftUsername: { type: String, required: true },

    itemName: { type: String, required: true },
    targetServerId: { type: String, required: true },
    commandTemplate: { type: String, required: true }, // re-rendered at delivery time in case the username changed meanwhile

    requestedBy: { type: String, default: null },

    // Links to the MinecraftDelivery row created at queue time (status
    // "queued") which this poller updates in place once resolved.
    deliveryId: { type: Schema.Types.ObjectId, required: true },

    status: { type: String, enum: ['pending', 'delivered', 'failed'], default: 'pending', index: true },
    attempts: { type: Number, default: 0 },
    lastError: { type: String, default: null },
  },
  { timestamps: true }
);

minecraftPendingDeliverySchema.index({ status: 1, minecraftUuid: 1, targetServerId: 1 });

module.exports = models.MinecraftPendingDelivery || model('MinecraftPendingDelivery', minecraftPendingDeliverySchema);
