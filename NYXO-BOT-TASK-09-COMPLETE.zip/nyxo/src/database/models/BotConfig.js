const { Schema, model, models } = require('mongoose');

/**
 * Bot-wide configuration, as opposed to GuildConfig which is one document
 * per server. Only ever one document exists (see
 * utils/globalCommandBlacklist.js getBotConfig, which finds-or-creates a
 * single fixed-id doc), so nothing here takes a guildId.
 */
const botConfigSchema = new Schema(
  {
    // Fixed singleton id so getBotConfig() can always find-or-create the
    // exact same one document instead of accidentally creating a second.
    _id: { type: String, default: 'singleton' },

    // Commands the bot owner has disabled everywhere - every server, no
    // exceptions. See utils/globalCommandBlacklist.js for resolution
    // and commands/owner/globaldisable.js for the owner-only command
    // that manages this list.
    globalCommandBlacklist: { type: [String], default: [] },
  },
  { timestamps: true }
);

module.exports = models.BotConfig || model('BotConfig', botConfigSchema);
