const { Schema, model, models } = require('mongoose');

const pollSchema = new Schema({
  guildId: { type: String, required: true, index: true },
  channelId: { type: String, required: true },
  messageId: { type: String, required: true, unique: true },
  question: { type: String, required: true },
  options: {
    type: [{ text: { type: String, required: true }, voterIds: { type: [String], default: [] } }],
    required: true,
  },
  allowMultiple: { type: Boolean, default: false },
  createdBy: { type: String, required: true },
  endsAt: { type: Date, default: null },
  ended: { type: Boolean, default: false },
});

module.exports = models.Poll || model('Poll', pollSchema);
