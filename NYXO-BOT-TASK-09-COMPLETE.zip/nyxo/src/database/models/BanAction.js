const { Schema, model, models } = require('mongoose');

/**
 * One document per successful ban. Used to enforce the per-role weekly ban
 * limit (banLimitService counts these within the current week) and doubles
 * as a lightweight audit trail of who banned whom and when.
 */
const banActionSchema = new Schema(
  {
    guildId: { type: String, required: true, index: true },
    moderatorId: { type: String, required: true, index: true },
    targetId: { type: String, required: true },
    reason: { type: String, default: 'No reason provided' },
  },
  { timestamps: true }
);

// Most lookups are "bans by this moderator, in this guild, since date X".
banActionSchema.index({ guildId: 1, moderatorId: 1, createdAt: 1 });

module.exports = models.BanAction || model('BanAction', banActionSchema);
