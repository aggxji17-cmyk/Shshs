const { Schema, model, models } = require('mongoose');

/**
 * Read-only mirror of NovaBridge's per-player cache collection
 * (`collections.players` in the plugin's config.yml, default
 * "minecraft_players" - see PlayerRepository.java). One document per
 * Minecraft account, keyed by UUID.
 *
 * NYXO BOT never writes to this collection - PlayerRepository.upsertPresence
 * is the only writer. Today (as shipped) it only tracks join/quit presence:
 * `online`, `currentServerId`, `lastSeenServerId`, `lastSeenAt`,
 * `firstSeenAt`. Because it's only ever updated on join/quit (see
 * PlayerPresenceListener), `lastSeenAt` is a reliable proxy for:
 *   - last LOGIN time, when `online` is true (it was set at the join that
 *     made them online)
 *   - last LOGOUT time, when `online` is false (it was set at that quit)
 * There is currently no way to know the *other* one (e.g. when an offline
 * player last logged in) - see minecraftPlayerService.buildPresenceInfo for
 * how that gap is surfaced honestly instead of guessed at.
 *
 * The fields below that point (rank/ranks, playtime, distinct
 * lastLoginAt/lastLogoutAt, skin data) don't exist in the collection yet -
 * they're declared here so the rest of the bot (services/minecraftPlayerService.js,
 * /mcprofile) can already read them by name. Until a future NovaBridge
 * update actually writes them, they simply come back `undefined`, which
 * every consumer already treats as "not available".
 *
 * `strict: false` so any other field the plugin writes is preserved even
 * before this model is updated to declare it.
 */
const minecraftPlayerCacheSchema = new Schema(
  {
    _id: { type: String }, // Minecraft UUID (with dashes)
    username: { type: String, default: null },
    online: { type: Boolean, default: false },
    currentServerId: { type: String, default: null },
    lastSeenServerId: { type: String, default: null },
    lastSeenAt: { type: Date, default: null },
    firstSeenAt: { type: Date, default: null },
    updatedAt: { type: Date, default: null },

    // --- Not written by the plugin yet - reserved for Phase 2 ---
    ranks: { type: [String], default: undefined },
    rank: { type: String, default: null },
    playtimeMinutes: { type: Number, default: null },
    lastLoginAt: { type: Date, default: null },
    lastLogoutAt: { type: Date, default: null },

    // Skin data: how a future in-game hook (reading the player's live
    // GameProfile textures property, or querying SkinsRestorer directly if
    // installed) would let /mcprofile show the ACTUAL current skin even
    // for offline/cracked accounts, which have no real Mojang skin to look
    // up by UUID. `skinUrl` is meant to be a direct texture PNG URL (the
    // same shape Mojang's own session server returns), so it can be
    // rendered the same way regardless of source.
    skinUrl: { type: String, default: null },
    capeUrl: { type: String, default: null },
    skinSource: { type: String, default: null }, // e.g. "mojang" | "skinsrestorer"
  },
  { collection: 'minecraft_players', strict: false, versionKey: false }
);

module.exports = models.MinecraftPlayerCache || model('MinecraftPlayerCache', minecraftPlayerCacheSchema);
