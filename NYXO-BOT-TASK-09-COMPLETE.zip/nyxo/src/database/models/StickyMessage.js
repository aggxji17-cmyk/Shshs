const { Schema, model, models } = require('mongoose');

/**
 * A message that gets reposted to the bottom of a channel every time
 * someone else sends a new message, keeping it "stuck" in view.
 */
const stickyMessageSchema = new Schema({
  guildId: { type: String, required: true, index: true },
  channelId: { type: String, required: true, unique: true },
  content: { type: String, required: true },
  lastMessageId: { type: String, default: null },
  createdBy: { type: String, required: true },
});

module.exports = models.StickyMessage || model('StickyMessage', stickyMessageSchema);
