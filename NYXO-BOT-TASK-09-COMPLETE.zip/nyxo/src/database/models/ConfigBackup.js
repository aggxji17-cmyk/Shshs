const { Schema, model, models } = require('mongoose');

/**
 * Bumped only when the *shape of this document* changes in a way that
 * would break old backups (e.g. we start storing settings compressed, or
 * split `settings` into multiple fields). It is NOT bumped when a new
 * field is simply added to GuildConfig - that case is already handled
 * without any migration, because `settings` below is stored schema-less
 * and restored via a merge (see services/backupService.js). Kept here,
 * next to the schema it describes, so the two never drift apart.
 */
const CURRENT_SCHEMA_VERSION = 1;

/**
 * A single point-in-time snapshot of a guild's bot *settings*
 * (GuildConfig) - moderation, AutoMod, logging, cases, tickets, leveling,
 * economy, music, and every other per-guild config block. This is
 * intentionally separate from the existing `Backup` model (commands/
 * settings/backup.js), which snapshots Discord server structure (roles/
 * channels) instead. The two are unrelated concepts that happen to share
 * the word "backup".
 *
 * Per-user data (economy balances, XP/levels, warns, tickets, cases...)
 * lives in its own collections and is never captured here - a settings
 * backup only ever touches the single GuildConfig document for a guild.
 */
const configBackupSchema = new Schema(
  {
    guildId: { type: String, required: true, index: true },
    // Server name at the moment the backup was taken (servers can be
    // renamed later, so this is captured, not looked up live).
    guildName: { type: String, required: true },
    createdBy: { type: String, required: true },
    // Optional human label, e.g. "before automod rework".
    label: { type: String, default: null },
    schemaVersion: { type: Number, default: CURRENT_SCHEMA_VERSION },
    // Raw snapshot of the guild's settings. Deliberately `Mixed` instead
    // of mirroring GuildConfig's schema field-for-field: that lets old
    // backups keep loading even after new settings blocks are added to
    // GuildConfig down the line. See services/backupService.js for how
    // the merge-based restore makes use of that.
    settings: { type: Schema.Types.Mixed, required: true },
  },
  { timestamps: true }
);

// Powers `/configbackup list`, which always queries newest-first per guild.
configBackupSchema.index({ guildId: 1, createdAt: -1 });

module.exports = models.ConfigBackup || model('ConfigBackup', configBackupSchema);
module.exports.CURRENT_SCHEMA_VERSION = CURRENT_SCHEMA_VERSION;
