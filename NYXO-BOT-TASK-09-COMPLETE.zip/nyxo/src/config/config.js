require('dotenv').config();

const isProduction = process.env.NODE_ENV === 'production';

// A handful of values that are obviously not real secrets - either this
// file's own former default, or the kind of placeholder people paste in
// out of habit ("changeme", "secret", ...). Only used to reject them in
// production; any of these are still accepted in development so `npm
// start` keeps working with zero setup.
const KNOWN_INSECURE_SECRETS = new Set([
  'insecure-dev-secret',
  'secret',
  'changeme',
  'change-me',
  'password',
  'session-secret',
  'your-secret-here',
  '',
]);

/**
 * Central configuration object. Every module reads bot-wide defaults from
 * here. Per-guild overrides (stored in MongoDB) always take priority over
 * these defaults - see utils/resolveGuildSettings.js.
 * 
 * SINGLE-BOT VERSION: all features share one Discord client and one token.
 */
const config = {
  // The only Discord bot credential used by the application.
  token: process.env.DISCORD_TOKEN,
  // The application ID is optional at runtime: after login the client user
  // ID is used for automatic command deployment. It remains configurable for
  // dashboard OAuth and the standalone deploy script.
  clientId: process.env.DISCORD_CLIENT_ID || process.env.CLIENT_ID,
  clientSecret: process.env.CLIENT_SECRET,
  redirectUri: process.env.REDIRECT_URI,
  // DEVELOPER_ID is normally a single Discord user ID, but a
  // comma-separated list still works here for guilds/setups that need
  // more than one full-access owner.
  ownerIds: (process.env.DEVELOPER_ID || '')
    .split(',')
    .map((id) => id.trim())
    .filter(Boolean),

  mongoUri: process.env.MONGODB_URL,

  dashboardPort: parseInt(process.env.DASHBOARD_PORT, 10) || 3000,
  // Falls back to a fixed dev-only value so `npm run dashboard` still
  // works with zero setup locally. validateConfig() below refuses to
  // start in production unless a real SESSION_SECRET is provided -
  // never rely on this fallback outside of local development.
  sessionSecret: process.env.SESSION_SECRET || 'insecure-dev-secret',
  // Reserved for a future simple password-based dashboard login. Not
  // consumed by any route yet (the live dashboard authenticates via
  // Discord OAuth - see dashboard/routes/auth.js) - only wire this in
  // once you actually add a password-based login path, and even then
  // compare it with a constant-time check (e.g. crypto.timingSafeEqual),
  // never with `===`.
  panelPassword: process.env.PANEL_PASSWORD || null,

  embedColor: process.env.EMBED_COLOR || '#5865F2',
  embedFooter: process.env.EMBED_FOOTER || 'NYXO BOT',
  botStatus: process.env.BOT_STATUS || 'online',
  activityType: process.env.BOT_ACTIVITY_TYPE || 'Watching',
  activityText: process.env.BOT_ACTIVITY_TEXT || 'over your server',

  minecraft: {
    name: process.env.MINECRAFT_SERVER_NAME || 'Minecraft Server',
    ip: process.env.MINECRAFT_SERVER_IP || 'localhost',
    port: parseInt(process.env.MINECRAFT_SERVER_PORT, 10) || 25565,
    // Bedrock (Geyser) shares the same server IP as Java - only the port differs.
    bedrockPort: parseInt(process.env.MINECRAFT_BEDROCK_PORT, 10) || 19132,
    // RCON is deliberately global and environment-only. Guild managers can
    // configure which server is displayed, but they must never be able to
    // redirect the bot's privileged console connection to an arbitrary host.
    rcon: {
      enabled: (process.env.RCON_ENABLED || 'false').toLowerCase() === 'true',
      host: process.env.RCON_HOST || '127.0.0.1',
      port: parseInt(process.env.RCON_PORT, 10) || 25575,
      password: process.env.RCON_PASSWORD || null,
    },
  },

  twitch: {
    clientId: process.env.TWITCH_CLIENT_ID || null,
    clientSecret: process.env.TWITCH_CLIENT_SECRET || null,
  },
  youtube: {
    apiKey: process.env.YOUTUBE_API_KEY || null,
    // Cookie string from a logged-in YouTube session, used by the music
    // extractor. Without this, YouTube frequently blocks the bot's
    // streaming requests ("Sign in to confirm you're not a bot" /
    // tracks that show as found but never actually play). See .env.example.
    cookie: process.env.YOUTUBE_COOKIE || null,
  },

  prefix: process.env.PREFIX || '!',

  // Minecraft AFK voice-channel rewards: a member who stays connected to
  // a specific Discord voice channel (`channelId`) earns one in-game
  // reward per full `intervalSeconds` spent there, delivered through the
  // existing NovaBridge command queue (see services/afkRewardsService.js
  // and services/commandQueueService.js) - no new Discord<->Minecraft
  // link or delivery mechanism, this reuses MinecraftLink +
  // ServerCommand exactly like services/minecraftDeliveryService.js
  // does for shop purchases.
  afkRewards: {
    enabled: (process.env.AFK_REWARDS_ENABLED || 'false').toLowerCase() === 'true',
    channelId: process.env.AFK_REWARDS_CHANNEL_ID || null,
    // Which registered NovaBridge server (MinecraftServer._id) receives
    // the console command - same targeting model as ShopItem.minecraft.targetServerId.
    targetServerId: process.env.AFK_REWARDS_TARGET_SERVER_ID || null,
    reward: {
      // 'VAULT' or 'PLAYERPOINTS'. Anything else is treated as
      // misconfigured (see afkRewardsService.js) so a typo here fails
      // safe (feature disabled) instead of silently running a bogus command.
      type: (process.env.AFK_REWARDS_TYPE || 'VAULT').toUpperCase(),
      amount: parseInt(process.env.AFK_REWARDS_AMOUNT, 10) || 1,
    },
    intervalSeconds: parseInt(process.env.AFK_REWARDS_INTERVAL_SECONDS, 10) || 60,
    // Optional override of the console command sent to the server.
    // Placeholders: {player} {uuid} {amount}. Defaults (see
    // afkRewardsService.js) match EssentialsX's Vault-backed `eco give`
    // and the PlayerPoints plugin's `points give` console commands.
    commandTemplate: process.env.AFK_REWARDS_COMMAND_TEMPLATE || null,
  },

  stripe: {
    secretKey: process.env.STRIPE_SECRET_KEY || null,
    webhookSecret: process.env.STRIPE_WEBHOOK_SECRET || null,
  },

  bitly: {
    accessToken: process.env.BITLY_ACCESS_TOKEN || null,
  },

  // Audio playback node (see /lavalink folder for server setup docs).
  // Actively read by services/lavalinkManager.js: when host+password are
  // both set, Kazagumo/Lavalink becomes the active engine for any guild
  // that doesn't already have a live discord-player session (see the
  // engine-selection comment in commands/music/play.js). Leaving either
  // empty keeps every guild on discord-player exactly as before, since
  // initKazagumo() returns null when buildNodes() has nothing to connect to.
  lavalink: {
    host: process.env.LAVALINK_HOST || null,
    port: parseInt(process.env.LAVALINK_PORT, 10) || 2333,
    password: process.env.LAVALINK_PASSWORD || null,
    secure: (process.env.LAVALINK_SECURE || 'false').toLowerCase() === 'true',
  },
};

// The ONLY variables required to start the bots (node src/index.js).
// Everything else in config.js has a safe default and is optional.
// DISCORD_CLIENT_ID is only needed for dashboard OAuth or for the standalone
// deploy script when it cannot log in to discover the application ID.
function validateConfig() {
  const missing = [];
  
  if (!config.token) missing.push('DISCORD_TOKEN');
  
  if (!config.mongoUri) missing.push('MONGODB_URL');
  if (!config.ownerIds.length) missing.push('DEVELOPER_ID');
  // MINECRAFT_SERVER_IP and MINECRAFT_BEDROCK_PORT are intentionally NOT
  // required here: config.minecraft above already falls back to safe
  // defaults ('localhost' and 19132) when they are unset, exactly like
  // every other Minecraft-related variable (name, port, RCON). Forcing
  // them to be present contradicted that documented optional/default
  // behavior and blocked startup for setups that don't use the
  // Minecraft integration at all.

  if (config.minecraft.rcon.enabled && !config.minecraft.rcon.password) {
    console.error('[CONFIG] RCON_ENABLED is true but RCON_PASSWORD is missing.');
    process.exit(1);
  }

  if (missing.length) {
    console.error(
      `[CONFIG] Missing required environment variables: ${missing.join(', ')}\n` +
        'This project runs as one Discord bot.\n' +
        'Copy .env.example to .env and fill in DISCORD_TOKEN before starting.'
    );
    process.exit(1);
  }

  // The dashboard signs session cookies with this value - anyone who knows
  // it (or guesses one of the common placeholders below) can forge a
  // logged-in session and take over any account, including the admin
  // panel. It is fine to leave unset in development (a fixed fallback is
  // used there so local setups don't need to think about it), but running
  // production without a real, unique secret is refused outright rather
  // than silently starting up insecure.
  if (isProduction && KNOWN_INSECURE_SECRETS.has((config.sessionSecret || '').trim().toLowerCase())) {
    console.error(
      '[CONFIG] SESSION_SECRET is missing or set to an insecure default value.\n' +
        'Set SESSION_SECRET to a long, random string in production - for example, run:\n' +
        '  node -e "console.log(require(\'crypto\').randomBytes(48).toString(\'hex\'))"\n' +
        'and put the result in your .env / hosting panel secrets.'
    );
    process.exit(1);
  }
  if (isProduction && config.sessionSecret.length < 32) {
    console.error(
      '[CONFIG] SESSION_SECRET is too short for production use (minimum 32 characters).\n' +
        'Generate a longer random value, e.g.:\n' +
        '  node -e "console.log(require(\'crypto\').randomBytes(48).toString(\'hex\'))"'
    );
    process.exit(1);
  }

  // panelPassword is not consumed anywhere yet (see the comment above),
  // but if someone has set PANEL_PASSWORD anyway, at least warn about an
  // obviously weak value so it isn't forgotten about the day it does get
  // wired up to a login route.
  if (config.panelPassword && config.panelPassword.length < 12) {
    console.warn(
      '[CONFIG] PANEL_PASSWORD is set but shorter than 12 characters - use a longer value.'
    );
  }
}

// Per-bot credential map. In unified mode all three keys share the same
// single Discord application. External tooling (deploy-commands.js,
// verify-multibot.js) iterates over this map so it works correctly
// regardless of whether the project is running in unified or split mode.
config.bots = {
  bot1: { token: config.token, clientId: config.clientId },
  bot2: { token: config.token, clientId: config.clientId },
  bot3: { token: config.token, clientId: config.clientId },
};

// Exported so tooling (e.g. scripts/static-verify.js) can detect whether
// the project runs in unified-bot mode or the legacy multi-bot split.
// Consumers: check `BOT_MODE === 'unified'` before assuming multiple bot keys.
const BOT_MODE = 'unified';

module.exports = { config, validateConfig, BOT_MODE, isProduction };
