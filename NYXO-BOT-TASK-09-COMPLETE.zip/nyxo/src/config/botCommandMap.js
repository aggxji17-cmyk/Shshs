/**
 * Bot Command Map — Task 2 (توزيع الأوامر والميزات على البوتات)
 * ---------------------------------------------------------------
 * Decides which of the 3 bots (bot1 = Music, bot2 = Management,
 * bot3 = Systems) owns each command, WITHOUT physically moving any
 * command file. The command handler (handlers/commandHandler.js)
 * only loads a command into a given client's `client.commands`
 * collection if this map says that client's bot owns it.
 *
 * Why a map instead of moving files on disk:
 *   - Zero risk of breaking `require()` paths across ~230 files.
 *   - Nothing is deleted or duplicated — every command still lives
 *     in exactly one place on disk and is now assigned to exactly
 *     one bot.
 *   - Easy to audit/adjust in one place.
 *
 * Resolution order for a command file at src/commands/<...>:
 *   1. FILE_OVERRIDES   — exact relative path (handles folders that
 *      mix commands belonging to different bots, e.g. legacy/System
 *      which has both `ban.js` (management) and `avatar.js` (systems)).
 *   2. LEGACY_FOLDER_MAP — for src/commands/legacy/<Sub>/*, keyed by
 *      "legacy/<Sub>".
 *   3. CATEGORY_BOT_MAP — top-level folder name under src/commands/.
 *   4. Fallback — bot3 (Systems), so an unmapped/new folder never
 *      silently loses its commands; a warning is logged instead.
 */

const path = require('node:path');

const BOT1_MUSIC = 'bot1';
const BOT2_MANAGEMENT = 'bot2';
const BOT3_SYSTEMS = 'bot3';

// ---------------------------------------------------------------
// 1) Top-level src/commands/<category> folders that are entirely
//    owned by one bot.
// ---------------------------------------------------------------
const CATEGORY_BOT_MAP = {
  // Bot 1 — Music
  music: BOT1_MUSIC,

  // Bot 2 — Management (moderation / protection / tickets / automod)
  moderation: BOT2_MANAGEMENT,
  automod: BOT2_MANAGEMENT,
  antinuke: BOT2_MANAGEMENT,
  verification: BOT2_MANAGEMENT,
  ticket: BOT2_MANAGEMENT,
  owner: BOT2_MANAGEMENT,
  // Task 2 rebalance (2026-08-09): these four folders are entirely
  // ManageGuild/ManageRoles/ManageChannels/ManageMessages-gated server
  // configuration commands (verified against each file's
  // setDefaultMemberPermissions / isGuildManager / isModerator checks),
  // not general-purpose "Systems" features - moved here to relieve
  // Bot 3's command count and because they are management in nature.
  settings: BOT2_MANAGEMENT,
  roles: BOT2_MANAGEMENT,
  invites: BOT2_MANAGEMENT,
  notifications: BOT2_MANAGEMENT,

  // Bot 3 — Systems (everything else: info, fun, games, minecraft, ...)
  community: BOT3_SYSTEMS,
  giveaway: BOT3_SYSTEMS,
  images: BOT3_SYSTEMS,
  fun: BOT3_SYSTEMS,
  voice: BOT3_SYSTEMS,
  leveling: BOT3_SYSTEMS,
  economy: BOT3_SYSTEMS,
  suggestion: BOT3_SYSTEMS,
  premium: BOT3_SYSTEMS,
  minecraft: BOT3_SYSTEMS,
  tools: BOT3_SYSTEMS,
  utility: BOT3_SYSTEMS,
};

// ---------------------------------------------------------------
// 2) src/commands/legacy/<Sub>/* folders that are entirely owned
//    by one bot (keyed as "legacy/<Sub>").
// ---------------------------------------------------------------
const LEGACY_FOLDER_MAP = {
  'legacy/Ticket': BOT2_MANAGEMENT,
  'legacy/Logs': BOT2_MANAGEMENT,
  'legacy/protection': BOT2_MANAGEMENT,
  'legacy/Broadcast': BOT2_MANAGEMENT, // owner/admin broadcast panel

  'legacy/Auto-role': BOT3_SYSTEMS,
  'legacy/Suggestions': BOT3_SYSTEMS,
  'legacy/Autoline': BOT3_SYSTEMS,
  'legacy/Tax': BOT3_SYSTEMS,
  'legacy/Nadeko': BOT3_SYSTEMS,
  'legacy/apply': BOT3_SYSTEMS,
  'legacy/Feedback': BOT3_SYSTEMS,
  'legacy/Auto-reply': BOT3_SYSTEMS,
  'legacy/General': BOT3_SYSTEMS,
  'legacy/Giveaway': BOT3_SYSTEMS,
};

// ---------------------------------------------------------------
// 3) Exact-file overrides for folders that mix commands belonging
//    to more than one bot. Keys are relative paths from
//    src/commands/ using forward slashes.
// ---------------------------------------------------------------
const FILE_OVERRIDES = {
  // -- setups/ (mixed: admin-only config commands -> management,
  //    genuinely general-purpose "Systems" setups stay put)
  'setups/anti-ghost-ping.js': BOT2_MANAGEMENT,
  'setups/modmail.js': BOT2_MANAGEMENT,
  'setups/staff-help.js': BOT2_MANAGEMENT,
  'setups/warnconfig.js': BOT2_MANAGEMENT,
  'setups/setup-music-request.js': BOT1_MUSIC,
  // Task 2 rebalance (2026-08-09): Administrator-gated, config-only
  // commands for the Applications subsystem (identical shape to
  // warnconfig/modmail/staff-help above - an admin configures a panel,
  // no gameplay/content of its own). The applicant-facing commands
  // (legacy/apply/close-apply.js, new-apply.js, dm-mode.js) are NOT
  // moved - those are used by regular members, not admins, so they
  // correctly stay on Bot 3 (Systems).
  'setups/setup-apply.js': BOT2_MANAGEMENT,
  'setups/setup-menuapply.js': BOT2_MANAGEMENT,
  // guessthenumber.js is Administrator-gated too, but it's a game
  // (number-guessing) config, not a server-management feature -
  // deliberately NOT moved; see report for reasoning.
  //
  // Task 2 rebalance #2 (2026-08-09, "bot3-under-99" pass): these two
  // are, like modmail/warnconfig/staff-help/anti-ghost-ping above, a
  // single Administrator-only config panel with NO subcommand any
  // regular member can use (verified by reading each file's execute()
  // - the permission check guards the entire command, not just one
  // subcommand). That makes them server administration, not a
  // general-purpose feature, by the same rule already applied to the
  // rest of setups/ - moved here to give Bot 3 headroom below the
  // Discord CHAT_INPUT cap instead of sitting one command away from it.
  //   - ai-config.js: Administrator-gated AI-feature configuration panel.
  //   - autoDelete.js: setDefaultMemberPermissions(Administrator),
  //     auto-message-deletion channel configuration.
  'setups/ai-config.js': BOT2_MANAGEMENT,
  'setups/autoDelete.js': BOT2_MANAGEMENT,
  // The following are administratively-gated in the exact same way
  // (whole-command Administrator/ManageGuild check, no member-facing
  // subcommand) but were deliberately left on Bot 3 this pass so
  // neither bot ends up sitting right at the cap - see report:
  //   - setup-smart-alerts.js: ManageGuild-gated on all subcommands.
  //   - voiceLevelingcmd.js: Administrator-gated on all subcommands.
  // level-roles.js (levelroles.js) was NOT considered for the move at
  // all: it has a `view` subcommand any regular member can run (only
  // `set` is Administrator-gated), so it's a mixed general-feature
  // command, not pure admin config - same category as
  // guessthenumber.js above.

  // -- starboard/ (single file, ManageGuild-gated server config)
  'starboard/starboard.js': BOT2_MANAGEMENT,

  // -- suggestion/ (mixed: admin config -> management, the user-facing
  //    /suggest command itself has no permission gate and stays on
  //    Bot 3 since regular members use it)
  'suggestion/suggestionsetup.js': BOT2_MANAGEMENT,

  // -- context-menu/ (mixed)
  'context-menu/deleteMessage.js': BOT2_MANAGEMENT,
  'context-menu/reportMessage.js': BOT2_MANAGEMENT,
  'context-menu/warnUser.js': BOT2_MANAGEMENT,
  'context-menu/userInfo.js': BOT3_SYSTEMS,

  // -- legacy/System/ (mixed: real moderation actions -> management)
  'legacy/System/mute.js': BOT2_MANAGEMENT,
  'legacy/System/clear.js': BOT2_MANAGEMENT,
  'legacy/System/lock.js': BOT2_MANAGEMENT,
  'legacy/System/unlock.js': BOT2_MANAGEMENT,
  'legacy/System/hide.js': BOT2_MANAGEMENT,
  'legacy/System/unhide.js': BOT2_MANAGEMENT,
  // Task 28 cleanup (2026-08-12): legacy/System/ban.js, kick.js,
  // timeout.js, role.js, and nickname.js (formerly overridden here as
  // BOT2_MANAGEMENT) were deleted — Task 27 confirmed the modern
  // moderation/{ban,kick,timeout,nickname}.js and roles/role.js already
  // cover every feature they had, and Task 26 had already established
  // those modern files as the sole loaded implementations. See
  // docs/TASK28-DUPLICATE-COMMANDS-CLEANUP.md.
  // remaining legacy/System/* files (avatar, banner, come, embed,
  // roles.js info lookup, say, send, server, setup-welcome, user,
  // add-info-button) fall through to the "legacy" default below (systems).

  // Task 28 cleanup (2026-08-12): legacy/apply/setup-apply.js (the
  // older st.db-based duplicate of setups/setup-apply.js, formerly
  // overridden here as BOT2_MANAGEMENT) was deleted after Task 27
  // confirmed setups/setup-apply.js was made self-sufficient. The
  // applicant-facing legacy/apply/* files (close-apply.js, new-apply.js,
  // dm-mode.js) are untouched and still fall through to legacy/apply's
  // BOT3_SYSTEMS folder mapping above. See
  // docs/TASK28-DUPLICATE-COMMANDS-CLEANUP.md.
};

/**
 * Resolve which bot owns a command file.
 * @param {string} absoluteFilePath Absolute path to the command file.
 * @param {string} commandsRoot Absolute path to src/commands.
 * @returns {'bot1'|'bot2'|'bot3'}
 */
function resolveOwnerBot(absoluteFilePath, commandsRoot) {
  const relPath = path.relative(commandsRoot, absoluteFilePath).split(path.sep).join('/');

  if (FILE_OVERRIDES[relPath]) {
    return FILE_OVERRIDES[relPath];
  }

  const parts = relPath.split('/');

  if (parts[0] === 'legacy' && parts.length >= 2) {
    const folderKey = `legacy/${parts[1]}`;
    if (LEGACY_FOLDER_MAP[folderKey]) {
      return LEGACY_FOLDER_MAP[folderKey];
    }
    // Unmapped legacy subfolder (e.g. legacy/System's non-overridden
    // files): defaults to Systems bot rather than being dropped.
    return BOT3_SYSTEMS;
  }

  if (CATEGORY_BOT_MAP[parts[0]]) {
    return CATEGORY_BOT_MAP[parts[0]];
  }

  // Unknown/new top-level category: never silently lose it — assign
  // to the Systems bot ("باقي الأنظمة") and let the command handler
  // log a warning so it can be classified properly later.
  return BOT3_SYSTEMS;
}

module.exports = {
  resolveOwnerBot,
  CATEGORY_BOT_MAP,
  LEGACY_FOLDER_MAP,
  FILE_OVERRIDES,
  BOT1_MUSIC,
  BOT2_MANAGEMENT,
  BOT3_SYSTEMS,
};
