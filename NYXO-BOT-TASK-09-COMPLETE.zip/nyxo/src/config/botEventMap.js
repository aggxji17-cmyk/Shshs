/**
 * Bot Event Map — TASK 4 (إصلاح عزل الـ Events)
 * ---------------------------------------------------------------
 * Companion to config/botCommandMap.js (Task 2), but for src/events/**.
 *
 * Problem: handlers/eventHandler.js used to call `client.on(...)` for
 * EVERY file under src/events/** on ALL 3 bot clients. The 3 Discord
 * clients are separate, but each of them independently receives the
 * same guild event from Discord's gateway (a member join fires once per
 * bot in that guild), so any event whose *logic* wasn't itself isolated
 * ran 3 times — e.g. a triple welcome message, triple auto-mod
 * punishment, triple XP grant.
 *
 * This map decides, per event file (relative path under src/events/,
 * forward slashes), which bot(s) that file's listener should even be
 * registered on:
 *
 *   'bot1' | 'bot2' | 'bot3'  → register ONLY on that bot's client.
 *   ['bot2', 'bot3']          → register on exactly those bots. Used
 *                               only for files that mix logic from two
 *                               bot domains; those files gate each
 *                               internal block with `client.botKey`
 *                               themselves (see the file for details),
 *                               so nothing runs twice even though the
 *                               listener itself is attached twice.
 *   'all'                     → register on every bot, unconditionally.
 *                               Reserved for events that are genuinely
 *                               per-bot by nature (e.g. clientReady sets
 *                               each bot's own presence and, internally,
 *                               gates every scheduler it starts by
 *                               client.botKey — see events/client/ready.js)
 *                               or that Discord already scopes to the
 *                               right bot on its own (interactionCreate
 *                               only ever fires for interactions on that
 *                               bot's own registered commands).
 *
 * Nothing is deleted or moved on disk — this is a load-time filter only,
 * exactly like botCommandMap.js. An event file not listed here defaults
 * to 'all' (never silently drop a feature) and eventHandler.js logs a
 * warning so it gets classified here instead of quietly staying
 * triple-registered.
 *
 * Bot roles (unchanged from Task 2): bot1 = Music, bot2 = Management
 * (moderation/security/tickets/automod/logs), bot3 = Systems (everything
 * else: welcome, leveling, minecraft, giveaways, utility, roles, ...).
 */

const BOT1_MUSIC = 'bot1';
const BOT2_MANAGEMENT = 'bot2';
const BOT3_SYSTEMS = 'bot3';
const ALL_BOTS = 'all';

const EVENT_FILE_MAP = {
  // -- client/ --------------------------------------------------------
  // Starts a scheduler per feature; each one is gated internally by
  // client.botKey to the bot that owns that feature (music/moderation/
  // systems). Presence + login log lines run for every bot, as they
  // should. See events/client/ready.js.
  'client/ready.js': ALL_BOTS,

  // -- guild/ (security / anti-nuke / mod-logs -> Management) --------
  'guild/channelDelete.js': BOT2_MANAGEMENT,
  'guild/guildBanAdd.js': BOT2_MANAGEMENT,
  'guild/guildBanRemove.js': BOT2_MANAGEMENT,
  'guild/roleDelete.js': BOT2_MANAGEMENT,
  'guild/webhooksUpdate.js': BOT2_MANAGEMENT,

  // Smart Alerts weekly health report is owned by the Systems bot
  // (setup-smart-alerts.js lives under src/commands/setups, which falls
  // through to Systems in botCommandMap.js's CATEGORY_BOT_MAP).
  'guild/guildBanAdd.smartAlerts.js': BOT3_SYSTEMS,
  'message/messageCreate.smartAlerts.js': BOT3_SYSTEMS,

  // Mixed: anti-raid detection + new-account action + join/leave mod-log
  // entries -> Management. Autorole + welcome (channel & DM) + invite-
  // join tracking -> Systems. Both files gate every block internally by
  // client.botKey (see the files), so registering the listener on both
  // bots is safe — each bot only ever runs its own half.
  'guild/guildMemberAdd.js': [BOT2_MANAGEMENT, BOT3_SYSTEMS],
  'guild/guildMemberRemove.js': [BOT2_MANAGEMENT, BOT3_SYSTEMS],

  // Booster announcement (settings, fallback -> Systems) + temprole
  // manual-removal reconciliation (src/commands/roles -> Systems). Both
  // halves are Systems, so the whole file is single-owner, no internal
  // gating needed.
  'guild/guildMemberUpdate.js': BOT3_SYSTEMS,

  'guild/inviteCreate.js': BOT3_SYSTEMS,
  'guild/inviteDelete.js': BOT3_SYSTEMS,

  // -- interaction/ ----------------------------------------------------
  // Always safe on all 3: each bot's client.commands only holds the
  // commands Task 2 assigned to it, so a bot simply won't have a handler
  // for interactions that aren't its own. No isolation work needed here.
  'interaction/interactionCreate.js': ALL_BOTS,

  // -- message/ ---------------------------------------------------------
  // Mixed pipeline (mention-protection/ticket/automod -> Management,
  // ip-trigger/afk/counting/sticky/autoresponder/leveling/legacy-prefix
  // -> Systems). Internally gated by client.botKey; see the file's
  // top-of-file comment and utils/messageHandledTracker.js for how a
  // Management-side deletion signals the Systems-side pipeline to stop.
  'message/messageCreate.js': [BOT2_MANAGEMENT, BOT3_SYSTEMS],

  'message/messageDelete.js': BOT2_MANAGEMENT, // ghost-ping + mod-log
  'message/messageUpdate.js': BOT2_MANAGEMENT, // ghost-ping + mod-log

  // -- reaction/ (starboard + reaction-roles -> Systems) ----------------
  'reaction/messageReactionAdd.js': BOT3_SYSTEMS,
  'reaction/messageReactionRemove.js': BOT3_SYSTEMS,

  // -- voice/ -------------------------------------------------------------
  'voice/afkRewards.js': BOT3_SYSTEMS, // Minecraft AFK voice rewards
  'voice/musicAutoResume.js': BOT1_MUSIC, // resumes paused music playback
  'voice/voiceStateUpdate.js': BOT3_SYSTEMS, // join-to-create temp channels
  // TASK26 (Voice XP): same bot as the rest of leveling
  // (message/messageCreate.js's handleLeveling, commands/leveling/*,
  // commands/settings/leveling.js - all Systems/bot3), so Voice XP is
  // never granted on Bot1 (Music) or Bot2 (Management).
  'voice/voiceXpTracking.js': BOT3_SYSTEMS,
};

/**
 * Resolve which bot(s) a given event file should be registered on.
 * @param {string} relPath Path relative to src/events, forward slashes.
 * @returns {'bot1'|'bot2'|'bot3'|'all'|string[]}
 */
function resolveEventOwner(relPath) {
  return EVENT_FILE_MAP[relPath] || ALL_BOTS;
}

module.exports = {
  resolveEventOwner,
  EVENT_FILE_MAP,
  BOT1_MUSIC,
  BOT2_MANAGEMENT,
  BOT3_SYSTEMS,
  ALL_BOTS,
};
