const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { baseEmbed } = require('../../utils/embeds');

module.exports = {
  name: 'guildBanRemove',
  async execute(ban) {
    const guildConfig = await getGuildConfig(ban.guild.id);
    const settings = resolved(guildConfig);

    if (guildConfig.logging?.enabled && guildConfig.logging.events.memberUnban) {
      const logChannel = ban.guild.channels.cache.get(guildConfig.logging.channelId);
      if (logChannel) {
        logChannel
          .send({
            embeds: [baseEmbed(settings).setTitle('Member Unbanned').setDescription(`${ban.user.username} (${ban.user.id})`)],
          })
          .catch(() => null);
      }
    }
  },
};
