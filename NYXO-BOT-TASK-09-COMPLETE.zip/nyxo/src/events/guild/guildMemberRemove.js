const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { applyPlaceholders } = require('../../utils/placeholders');
const { baseEmbed } = require('../../utils/embeds');

/**
 * TASK 4 (event isolation): registered on both bot2 (Management - the
 * "Member Left" mod-log entry) and bot3 (Systems - the goodbye message),
 * gated below by `client.botKey` - see config/botEventMap.js. The two
 * halves are fully independent (no shared state), so each simply no-ops
 * when it's not that bot's turn.
 */
module.exports = {
  name: 'guildMemberRemove',
  async execute(member, client) {
    const guildConfig = await getGuildConfig(member.guild.id);
    const settings = resolved(guildConfig);

    const botKey = client?.botKey;
    const runManagement = !botKey || botKey === 'bot2';
    const runSystems = !botKey || botKey === 'bot3';

    if (runSystems && guildConfig.goodbye?.enabled && guildConfig.goodbye.channelId) {
      const channel = member.guild.channels.cache.get(guildConfig.goodbye.channelId);
      if (channel) {
        const embed = baseEmbed(settings)
          .setTitle('👋 Goodbye')
          .setDescription(applyPlaceholders(guildConfig.goodbye.message, member))
          .setThumbnail(member.user.displayAvatarURL());
        channel.send({ embeds: [embed] }).catch(() => null);
      }
    }

    if (runManagement && guildConfig.logging?.enabled && guildConfig.logging.events.memberLeave) {
      const logChannel = member.guild.channels.cache.get(guildConfig.logging.channelId);
      if (logChannel) {
        logChannel
          .send({
            embeds: [baseEmbed(settings).setTitle('Member Left').setDescription(`${member.user.username} (${member.id})`)],
          })
          .catch(() => null);
      }
    }
  },
};
