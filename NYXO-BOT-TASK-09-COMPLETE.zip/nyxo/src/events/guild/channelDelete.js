const { AuditLogEvent } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { trackAndEnforce } = require('../../services/antiNukeService');
const { fetchExecutorId } = require('../../utils/auditLog');
const { baseEmbed } = require('../../utils/embeds');
const { evictChannel } = require('../../services/ticketRenameQueue');

module.exports = {
  name: 'channelDelete',
  async execute(channel) {
    // TASK 23: تنظيف فوري لمدخل القناة من طابور الـRename حتى لا تبقى
    // مدخلات ميتة في الذاكرة بعد حذف قنوات التذاكر.
    evictChannel(channel.id);

    if (!channel.guild) return;
    const guildConfig = await getGuildConfig(channel.guild.id);
    const settings = resolved(guildConfig);

    const executorId = await fetchExecutorId(channel.guild, AuditLogEvent.ChannelDelete, channel.id);
    if (!executorId) return;

    await trackAndEnforce(channel.guild, executorId, 'channelDelete', guildConfig);

    if (guildConfig.logging?.enabled && guildConfig.logging.events.channelUpdates) {
      const logChannel = channel.guild.channels.cache.get(guildConfig.logging.channelId);
      if (logChannel) {
        logChannel
          .send({
            embeds: [
              baseEmbed(settings)
                .setTitle('Channel Deleted')
                .addFields(
                  { name: 'Channel', value: `#${channel.name}`, inline: true },
                  { name: 'By', value: `<@${executorId}>`, inline: true }
                ),
            ],
          })
          .catch(() => null);
      }
    }
  },
};
