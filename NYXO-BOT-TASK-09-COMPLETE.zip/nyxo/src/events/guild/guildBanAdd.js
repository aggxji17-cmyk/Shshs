const { AuditLogEvent } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { trackAndEnforce } = require('../../services/antiNukeService');
const { fetchExecutorId } = require('../../utils/auditLog');
const { baseEmbed } = require('../../utils/embeds');

module.exports = {
  name: 'guildBanAdd',
  async execute(ban) {
    const guildConfig = await getGuildConfig(ban.guild.id);
    const settings = resolved(guildConfig);

    const executorId = await fetchExecutorId(ban.guild, AuditLogEvent.MemberBanAdd, ban.user.id);

    if (executorId) {
      await trackAndEnforce(ban.guild, executorId, 'memberBan', guildConfig);
    }

    if (guildConfig.logging?.enabled && guildConfig.logging.events.memberBan) {
      const logChannel = ban.guild.channels.cache.get(guildConfig.logging.channelId);
      if (logChannel) {
        logChannel
          .send({
            embeds: [
              baseEmbed(settings)
                .setTitle('Member Banned')
                .addFields(
                  { name: 'User', value: `${ban.user.username} (${ban.user.id})`, inline: true },
                  { name: 'By', value: executorId ? `<@${executorId}>` : 'Unknown', inline: true }
                ),
            ],
          })
          .catch(() => null);
      }
    }
  },
};
