const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { applyPlaceholders } = require('../../utils/placeholders');
const { baseEmbed, errorEmbed } = require('../../utils/embeds');
const { resolveJoinInvite } = require('../../services/inviteService');
const { recordJoinAndCheckRaid, isNewAccount, isLockdownActive } = require('../../services/antiRaidService');
const { sendModLog } = require('../../utils/modLog');
const logger = require('../../utils/logger');

/**
 * TASK 4 (event isolation): this event used to run once, top-to-bottom,
 * on a single bot. It's now registered on both the Management bot
 * (bot2 - anti-raid/new-account handling + the "Member Joined" mod-log
 * entry) and the Systems bot (bot3 - autorole/welcome/DM welcome/invite
 * tracking), gated below by `client.botKey` - see config/botEventMap.js.
 * All 3 bots receive their own copy of every guildMemberAdd from
 * Discord, so without this each half would otherwise still run twice
 * more on the bots that don't own it.
 *
 * Both bots run in the same Node process (see handlers/botManager.js),
 * so services/antiRaidService.js's in-memory lockdown state is shared:
 * bot3's invite-tracking step below calls `isLockdownActive()` to
 * reproduce the original single-process "skip the invite log while a
 * raid is being handled" behavior, instead of the old same-execution
 * `wasRaidJustHandled` boolean that only made sense when both halves
 * ran together.
 */
module.exports = {
  name: 'guildMemberAdd',
  async execute(member, client) {
    const guildConfig = await getGuildConfig(member.guild.id);
    const settings = resolved(guildConfig);

    const botKey = client?.botKey;
    const runManagement = !botKey || botKey === 'bot2';
    const runSystems = !botKey || botKey === 'bot3';

    // -- Bot 2 (Management): anti-raid / new-account / join mod-log -----
    if (runManagement) {
      await recordJoinAndCheckRaid(member, guildConfig, settings).catch(() => false);
      await handleNewAccountFlag(member, guildConfig, settings);

      if (guildConfig.logging?.enabled && guildConfig.logging.events.memberJoin) {
        const logChannel = member.guild.channels.cache.get(guildConfig.logging.channelId);
        if (logChannel) {
          logChannel
            .send({
              embeds: [
                baseEmbed(settings)
                  .setTitle('Member Joined')
                  .setDescription(`${member} (${member.user.username})`)
                  .setThumbnail(member.user.displayAvatarURL()),
              ],
            })
            .catch(() => null);
        }
      }
    }

    // -- Bot 3 (Systems): autorole / welcome / DM welcome / invites -----
    if (runSystems) {
      if (guildConfig.autoRoleId) {
        const role = member.guild.roles.cache.get(guildConfig.autoRoleId);
        if (role) await member.roles.add(role).catch((err) => logger.warn(`Autorole failed: ${err.message}`));
      }

      if (guildConfig.welcome?.enabled && guildConfig.welcome.channelId) {
        const channel = member.guild.channels.cache.get(guildConfig.welcome.channelId);
        if (channel) {
          const embed = baseEmbed(settings)
            .setTitle('👋 Welcome!')
            .setDescription(applyPlaceholders(guildConfig.welcome.message, member))
            .setThumbnail(member.user.displayAvatarURL());
          if (guildConfig.welcome.color) embed.setColor(guildConfig.welcome.color);
          if (guildConfig.welcome.imageUrl) embed.setImage(guildConfig.welcome.imageUrl);
          channel.send({ embeds: [embed] }).catch(() => null);
        }
      }

      if (guildConfig.welcome?.dm?.enabled) {
        const dmTemplate = guildConfig.welcome.dm.message || guildConfig.welcome.message;
        const dmEmbed = baseEmbed(settings)
          .setTitle(`👋 Welcome to ${member.guild.name}!`)
          .setDescription(applyPlaceholders(dmTemplate, member))
          .setThumbnail(member.guild.iconURL() || null);
        if (guildConfig.welcome.color) dmEmbed.setColor(guildConfig.welcome.color);
        // Best-effort only - DMs are frequently closed to non-friends/non-
        // shared-server senders, and that failure should never be treated
        // as noteworthy (no log, no fallback message to the guild).
        member.send({ embeds: [dmEmbed] }).catch(() => null);
      }

      // Skip the normal invite-join log while bot2's anti-raid handling
      // is actively responding to a burst of joins on this guild - see
      // the file header comment above.
      if (!isLockdownActive(member.guild.id)) {
        await handleInviteTracking(member, guildConfig, settings);
      }
    }
  },
};

async function handleInviteTracking(member, guildConfig, settings) {
  if (!guildConfig.invites?.enabled) return;

  const inviterId = await resolveJoinInvite(member.guild).catch(() => null);
  if (!guildConfig.invites.logChannelId) return;

  const logChannel = member.guild.channels.cache.get(guildConfig.invites.logChannelId);
  if (!logChannel) return;

  const description = inviterId
    ? `${member} joined, invited by <@${inviterId}>.`
    : `${member} joined (invite could not be determined - vanity URL or expired invite).`;

  logChannel.send({ embeds: [baseEmbed(settings).setDescription(description)] }).catch(() => null);
}

async function handleNewAccountFlag(member, guildConfig, settings) {
  if (!guildConfig.antiRaid?.enabled) return;
  if (!isNewAccount(member.user, guildConfig)) return;

  if (guildConfig.antiRaid.newAccountAction === 'kick') {
    await member.kick('Account younger than the configured minimum age').catch(() => null);
    await sendModLog(member.guild, guildConfig, settings, {
      title: 'New Account Kicked',
      description: `${member.user.username} was kicked automatically for having an account younger than ${guildConfig.antiRaid.newAccountAgeDays} day(s).`,
      color: '#ED4245',
    });
  } else if (guildConfig.antiRaid.newAccountAction === 'flag') {
    await sendModLog(member.guild, guildConfig, settings, {
      title: 'New Account Joined',
      description: `${member} has an account younger than ${guildConfig.antiRaid.newAccountAgeDays} day(s). Flagged for review.`,
      color: '#FEE75C',
    });
  }
}
