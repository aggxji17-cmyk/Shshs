const { config } = require('../../config/config');
const logger = require('../../utils/logger');
const { initializeServicesForClient } = require('../../services/serviceInitializers');

module.exports = {
  name: 'clientReady',
  once: true,
  async execute(client) {
    logger.success(`Logged in as ${client.user.username} (${client.guilds.cache.size} guilds)`);

    // Presence is per-bot identity - always set for every bot, regardless
    // of botKey.
    client.user.setPresence({
      status: config.botStatus,
      activities: [{ name: config.activityText, type: activityTypeToEnum(config.activityType) }],
    });

    // Initialize all applicable services based on botKey.
    // This uses a centralized service initializer that handles:
    // - Music services (Kazagumo/Lavalink, 24/7 session restoration)
    // - Management services (moderation scheduler, case expiry, ticket cleanup)
    // - Systems services (giveaways, reminders, polls, minecraft, leveling, etc.)
    //
    // Prior to Task 23, services were initialized inline with minimal error
    // handling. Now they go through a unified initialization pipeline with:
    // - Consistent logging
    // - Graceful failure handling (one service failure doesn't stop others)
    // - Clear separation between service initializer definitions and event logic
    try {
      const results = await initializeServicesForClient(client);

      // Log any failures, but don't fail the entire ready event
      if (results.failed.length > 0) {
        logger.warn(`Some services failed to initialize; bot will continue with reduced functionality.`);
      }
    } catch (err) {
      logger.error(`Unexpected error during service initialization: ${err?.stack || err}`);
      // Don't throw; the bot should still come online even if some services fail to start.
    }
  },
};

function activityTypeToEnum(type) {
  const map = { Playing: 0, Streaming: 1, Listening: 2, Watching: 3, Competing: 5 };
  return map[type] ?? 3;
}
