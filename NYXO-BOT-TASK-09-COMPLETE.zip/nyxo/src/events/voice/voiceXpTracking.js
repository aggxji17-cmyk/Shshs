const { handleVoiceStateChange } = require('../../services/voiceXpService');

/**
 * TASK26 (Voice XP). Registered alongside the existing `voiceStateUpdate`
 * listeners (src/events/voice/voiceStateUpdate.js for join-to-create,
 * src/events/voice/afkRewards.js for Minecraft AFK rewards) - exactly
 * like those two, discord.js/Node's EventEmitter supports multiple
 * listeners per event and the event loader (src/handlers/eventHandler.js)
 * already loads every file under src/events/**, so adding a third
 * `voiceStateUpdate` file here doesn't touch (or risk breaking) either
 * of the other two.
 *
 * Bot isolation: mapped to bot3 (Systems) only in
 * config/botEventMap.js, same bot messageCreate.js's `handleLeveling`
 * (message XP) already runs on - so Voice XP, like message XP, only
 * ever grants once per event, from exactly one bot, never on Bot1
 * (Music) or Bot2 (Management).
 *
 * All the actual logic - session tracking, eligibility, the single
 * central sweep timer that grants XP - lives in
 * services/voiceXpService.js, which no-ops safely when a guild has
 * Voice XP disabled (or leveling disabled entirely).
 */
module.exports = {
  name: 'voiceStateUpdate',
  async execute(oldState, newState) {
    handleVoiceStateChange(oldState, newState);
  },
};
