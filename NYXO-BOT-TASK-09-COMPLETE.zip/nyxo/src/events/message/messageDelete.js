const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { baseEmbed } = require('../../utils/embeds');
const { sendModLog } = require('../../utils/modLog');
const { recordDeletedMessage } = require('../../services/snipeService');
const { wasAutoDeleted } = require('../../utils/autoDeleteTracker');

// A deletion within this many milliseconds of the message being sent is
// treated as a possible "ghost ping" (mention-then-instant-delete).
const GHOST_PING_WINDOW_MS = 5000;

module.exports = {
  name: 'messageDelete',
  async execute(message) {
    if (!message.guild || message.author?.bot) return;

    recordDeletedMessage(message);

    // Our own auto-delete-channel timer removed this message on schedule -
    // that's expected behavior, not a real (or "ghost") deletion.
    const wasScheduled = wasAutoDeleted(message.id);

    const guildConfig = await getGuildConfig(message.guild.id);
    const settings = resolved(guildConfig);

    if (!wasScheduled) {
      await handleAntiGhostPing(message, guildConfig, settings);
    }

    if (!guildConfig.logging?.enabled || !guildConfig.logging.events.messageDelete) return;
    if (message.channelId === guildConfig.logging.channelId) return;
    if (wasScheduled) return;

    const logChannel = message.guild.channels.cache.get(guildConfig.logging.channelId);
    if (!logChannel) return;

    logChannel
      .send({
        embeds: [
          baseEmbed(settings)
            .setTitle('Message Deleted')
            .addFields(
              { name: 'Author', value: message.author ? `${message.author.username}` : 'Unknown', inline: true },
              { name: 'Channel', value: `${message.channel}`, inline: true },
              { name: 'Content', value: message.content?.slice(0, 1000) || '*(no cached content)*' }
            ),
        ],
      })
      .catch(() => null);
  },
};

/**
 * Flags messages that mentioned a user and were deleted almost immediately
 * after being sent - the classic "ghost ping" pattern.
 */
async function handleAntiGhostPing(message, guildConfig, settings) {
  if (!guildConfig.moderation?.antiGhostPing) return;
  if (!message.mentions?.users?.size && !message.mentions?.roles?.size) return;
  if (!message.createdTimestamp) return;

  const age = Date.now() - message.createdTimestamp;
  if (age > GHOST_PING_WINDOW_MS) return;

  const mentioned = [
    ...message.mentions.users.map((u) => `${u}`),
    ...message.mentions.roles.map((r) => `${r}`),
  ].join(', ');

  await sendModLog(message.guild, guildConfig, settings, {
    title: 'Ghost Ping Detected',
    description: `${message.author ? `${message.author}` : 'A user'} pinged ${mentioned} in ${message.channel} and deleted the message within ${(age / 1000).toFixed(1)}s.`,
    color: '#ED4245',
  });
}
