const { PermissionFlagsBits } = require('discord.js');
const logger = require('../../utils/logger');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { processMessage: runAutoModeration } = require('../../services/autoModerationService');
const { grantMessageXp, resolveXpRange, getLevelProgress, getXpMultiplier, applyXpMultiplier } = require('../../services/levelingService');
const { grantLevelRewards } = require('../../services/levelRewardService');
const { baseEmbed, successEmbed, errorEmbed } = require('../../utils/embeds');
const { markAutoDeleted } = require('../../utils/autoDeleteTracker');
const { buildMinecraftStatusResponse } = require('../../services/minecraftEmbedBuilder');
const { isModerator } = require('../../utils/permissions');
const { notifyMember } = require('../../services/ticketNotifyService');
const { hasBypass, mentionsProtectedUser } = require('../../services/mentionProtectionService');
const { markMessageHandled, wasMessageHandled } = require('../../utils/messageHandledTracker');

const AfkStatus = require('../../database/models/AfkStatus');
const StickyMessage = require('../../database/models/StickyMessage');
const AutoResponder = require('../../database/models/AutoResponder');
const Ticket = require('../../database/models/Ticket');
const { repostSticky } = require('../../services/stickyService');
const { buildStatusChannelName, deriveBaseChannelName } = require('../../utils/ticketPanel');
const ticketState = require('../../services/ticketStateManager');
const { queueRename } = require('../../services/ticketRenameQueue');

/**
 * Reliability isolation: this pipeline is a chain of otherwise-independent
 * features (AFK, sticky, autoresponder, leveling, ticket status, ...).
 * Before this wrapper, an unexpected rejection in any one step (e.g. a
 * transient Mongo error inside handleAfkClear) propagated straight out of
 * execute() and silently skipped every step after it - automod, leveling
 * XP, sticky reposts, etc. - for that message, with the only trace being a
 * generic, context-free line from index.js's global unhandledRejection
 * handler. Wrapping each step keeps a single flaky feature from taking the
 * rest of the pipeline down with it, and logs which step failed for which
 * message/guild.
 */
async function safeStep(name, message, fn) {
  try {
    return await fn();
  } catch (err) {
    logger.error(`messageCreate.${name} failed (message ${message.id}, guild ${message.guild?.id}): ${err?.stack || err}`);
    return undefined;
  }
}

/**
 * TASK 4 (event isolation): this used to be a single sequential pipeline
 * on one bot, where an early step (mentionProtection, automod) deleting
 * the message could just `return` to stop every later step from touching
 * it. It's now registered on both bot2 (Management: mention-protection,
 * ticket status/smart-mention, automod) and bot3 (Systems: ip-trigger,
 * afk, counting, auto-delete-schedule, sticky, autoresponder, leveling,
 * legacy prefix commands), gated below by `client.botKey` - see
 * config/botEventMap.js. Both bots receive their own copy of every
 * messageCreate from Discord, so this is what stops e.g. leveling XP or
 * a sticky repost from firing 3 times (once per bot).
 *
 * Because the two halves are now independent listener invocations rather
 * than sequential steps in one function, a bot2 deletion (mention
 * protection / automod) can no longer just `return` to stop bot3's
 * steps from running on the same message. utils/messageHandledTracker.js
 * bridges that (best-effort - see that file for why) so bot3's pipeline
 * still skips the rest of its steps once bot2 has removed the message,
 * matching the original behavior as closely as two separate listeners
 * can.
 */
module.exports = {
  name: 'messageCreate',
  async execute(message, client) {
    if (message.author.bot || !message.guild) return;

    const guildConfig = await getGuildConfig(message.guild.id).catch((err) => {
      logger.error(`messageCreate: failed to load guild config for guild ${message.guild.id}: ${err?.stack || err}`);
      return null;
    });
    if (!guildConfig) return;
    const settings = resolved(guildConfig);

    const botKey = client?.botKey;
    const runManagement = !botKey || botKey === 'bot2';
    const runSystems = !botKey || botKey === 'bot3';

    // -- Bot 2 (Management): mention protection / ticket / automod ------
    if (runManagement) {
      if (await safeStep('handleMentionProtection', message, () => handleMentionProtection(message, guildConfig))) {
        markMessageHandled(message.id);
        return;
      }

      // Both steps below need the same "open ticket for this channel"
      // lookup (Ticket.findOne({channelId, status: {$ne: 'closed'}})) -
      // fetch it once here and share it instead of each running an
      // identical query on every single message sent anywhere in the
      // server.
      const openTicket = await safeStep('handleTicketLookup', message, () =>
        Ticket.findOne({ channelId: message.channel.id, status: { $ne: 'closed' } })
      );
      await safeStep('handleTicketStatusUpdate', message, () => handleTicketStatusUpdate(message, openTicket, guildConfig));
      await safeStep('handleTicketSmartMention', message, () => handleTicketSmartMention(message, guildConfig, settings, openTicket));

      if (await safeStep('handleAutomod', message, () => handleAutomod(message, guildConfig, settings))) {
        markMessageHandled(message.id);
        return;
      }
    }

    // -- Bot 3 (Systems): ip-trigger / afk / counting / sticky / etc. ---
    if (runSystems) {
      if (await safeStep('handleIpTrigger', message, () => handleIpTrigger(message, settings))) return;

      // Best-effort cross-bot signal: bot2 may have already deleted this
      // message via mention protection or automod - see the file header
      // comment above.
      if (wasMessageHandled(message.id)) return;

      await safeStep('handleAfkClear', message, () => handleAfkClear(message, settings));
      await safeStep('handleAfkMentions', message, () => handleAfkMentions(message, guildConfig, settings));

      if (await safeStep('handleCounting', message, () => handleCounting(message, guildConfig, settings))) return;

      if (wasMessageHandled(message.id)) return;

      await safeStep('handleAutoDeleteSchedule', message, () => handleAutoDeleteSchedule(message, guildConfig));
      await safeStep('handleStickyRepost', message, () => handleStickyRepost(message, settings));
      await safeStep('handleAutoResponder', message, () => handleAutoResponder(message, guildConfig));
      await safeStep('handleLeveling', message, () => handleLeveling(message, guildConfig, settings));
      await safeStep('handleLegacyPrefixCommands', message, () => handleLegacyPrefixCommands(message, settings));
    }
  },
};

/**
 * Whenever someone sends a message that is just the word "ip" (any casing,
 * whitespace trimmed) in any channel, replies with a live-updated embed of
 * the configured Minecraft server(s) - Java + Bedrock status, player count,
 * a fill progress bar, MOTD and server icon. If the bot has Manage Messages
 * in that channel, the triggering "ip" message is deleted afterward.
 * Returns true if this message was handled as an ip trigger (so the caller
 * can skip the rest of the message pipeline for it).
 */
async function handleIpTrigger(message, settings) {
  if (message.content.trim().toLowerCase() !== 'ip') return false;

  const response = await buildMinecraftStatusResponse(settings);
  await message.channel.send(response).catch(() => null);

  const canManageMessages = message.channel
    .permissionsFor(message.guild.members.me)
    ?.has(PermissionFlagsBits.ManageMessages);

  if (canManageMessages) {
    await message.delete().catch(() => null);
  }

  return true;
}

/**
 * Deletes any message that @mentions a protected user, unless its author
 * is exempt (guild manager or a configured bypass role). Runs before
 * everything else in the pipeline - there's no reason to process a
 * message further once it's been removed for this. Discord has already
 * fired the mention notification by the time the bot can react to it, so
 * this can't guarantee the ping was never seen - only that the message
 * itself is gone as fast as possible (see the schema comment in
 * GuildConfig.js).
 */
async function handleMentionProtection(message, guildConfig) {
  if (!guildConfig.mentionProtection?.enabled) return false;
  if (!mentionsProtectedUser(message, guildConfig)) return false;
  if (hasBypass(message.member, guildConfig)) return false;

  await message.delete().catch(() => null);
  return true;
}

/**
 * "Smart notification": when a staff member @mentions, inside a ticket
 * channel, someone who doesn't yet have access to that channel (i.e.
 * "شخص خارج التكت"), the bot takes over instead of leaving a raw ping
 * sitting there:
 *   1. grants that member access to the ticket (see ticketNotifyService),
 *   2. sends its own clean notification message with the actual ping,
 *   3. deletes the staff member's original message.
 * Mentioning someone who already has access (another staff member, the
 * ticket opener, etc.) is left alone - that's just a normal message.
 */
async function handleTicketSmartMention(message, guildConfig, settings, ticket) {
  if (!message.mentions.users.size) return;
  if (!ticket) return;
  if (!isModerator(message.member, guildConfig)) return;

  const outsiders = [];
  for (const user of message.mentions.users.values()) {
    if (user.bot || user.id === message.author.id) continue;
    const member = await message.guild.members.fetch(user.id).catch((err) => {
      logger.warn(`تعذر جلب العضو ${user.id} من أجل استدعائه داخل التذكرة #${ticket.ticketNumber}: ${err.message}`);
      return null;
    });
    if (!member) continue;
    const perms = message.channel.permissionsFor(member);
    if (!perms?.has(PermissionFlagsBits.ViewChannel)) outsiders.push(user);
  }

  if (!outsiders.length) return;

  const reason = message.content.replace(/<@!?\d+>/g, '').trim() || null;

  // TASK 22 (إصلاح H6): الترتيب القديم كان يحذف رسالة الموظف أولاً ثم
  // يُرسل البديل. إذا فشل الإرسال تُحذف الرسالة بدون أي بديل.
  // الإصلاح: نُرسل البديل أولاً، ثم نحذف الأصل فقط إذا نجح إرسال بديل
  // واحد على الأقل.
  let atLeastOneSent = false;
  for (const target of outsiders) {
    // eslint-disable-next-line no-await-in-loop
    const result = await notifyMember({
      channel: message.channel,
      guildConfig,
      settings,
      ticket,
      requestedBy: message.author,
      target,
      reason,
    }).catch((err) => {
      logger.error(`فشل استدعاء العضو إلى التذكرة #${ticket.ticketNumber}: ${err.stack || err}`);
      return null;
    });
    if (result) atLeastOneSent = true;
  }

  if (atLeastOneSent) {
    await message.delete().catch((err) => {
      logger.warn(`تعذر حذف رسالة استدعاء العضو داخل التذكرة #${ticket.ticketNumber}: ${err.message}`);
    });
  }
}

/**
 * Keeps a ticket channel's 🟡/🟢 status in sync with who last spoke in it:
 * the ticket opener speaking means staff still owes a reply (🟡 needs_reply),
 * staff speaking means the ball is no longer in the opener's court (🟢
 * no_action). Only touches open/claimed tickets, and only renames the
 * channel when the status actually flips, to stay well under Discord's
 * 2-renames-per-10-minutes-per-channel limit during an active conversation.
 *
 * Task 5: a message from anyone who is neither the opener nor staff (e.g.
 * a third party added via /add-user) is left alone - only an actual
 * Staff/Admin reply is allowed to flip the ticket to 🟢, per spec ("الرد
 * من Staff/Admin فقط هو الذي يغير الحالة إلى الأخضر").
 *
 * TASK32 (reply reminder ping): also maintains `lastStaffMessageAt`/
 * `reminderSentAt` (see database/models/Ticket.js) for
 * ticketCloseService.js's runReplyReminderPass scheduler - separately
 * from the 🟡/🟢 flip logic above, because these need to update on
 * EVERY qualifying message, not only the one that flips replyStatus:
 * several staff messages in a row must each push the 1-minute wait
 * window out to the latest one (per spec "يعتمد المؤقت على آخر رسالة
 * للإداري"), which a single "only write on flip" check would miss for
 * every staff message after the first.
 *
 * TASK33 (activity tracking): also maintains `lastUserMessageAt`/
 * `lastActivityAt`/`lastMessageBy` (see database/models/Ticket.js),
 * again updated on EVERY qualifying message for the same reason as
 * lastStaffMessageAt above - a run of several messages from the same
 * side must each push these fields to the latest one, not just the
 * first. These three are purely additive tracking/display fields (see
 * ticketPanel.js's getTicketWorkflowState and buttons.js's
 * ticket_status_toggle) - they never feed into the reminder scheduler's
 * query, so adding them cannot change TASK32's reminder behaviour.
 */
async function handleTicketStatusUpdate(message, ticket, guildConfig) {
  if (!ticket) return;

  let nextStatus;
  let speaker;
  if (message.author.id === ticket.userId) {
    nextStatus = ticketState.REPLY_STATUS.NEEDS_REPLY;
    speaker = ticketState.LAST_MESSAGE_BY.USER;
  } else if (isModerator(message.member, guildConfig)) {
    nextStatus = ticketState.REPLY_STATUS.NO_ACTION;
    speaker = ticketState.LAST_MESSAGE_BY.STAFF;
  } else {
    return;
  }

  const statusChanged = ticket.replyStatus !== nextStatus;

  // TASK33: last-speaker/last-activity always bump to *this* message's
  // timestamp, on every qualifying message, regardless of whether
  // replyStatus itself is changing (same reasoning as lastStaffMessageAt
  // below). Task 9: منقولة إلى ticketStateManager.applyActivity.
  ticketState.applyActivity(ticket, speaker, message.createdAt);
  let activityChanged = true;

  if (!statusChanged) {
    if (activityChanged) await ticket.save();
    return;
  }

  const baseName = ticket.baseChannelName || deriveBaseChannelName(message.channel.name);

  ticketState.applyReplyStatus(ticket, nextStatus);
  ticket.baseChannelName = baseName;
  await ticket.save();

  // TASK 20: بدل await مباشر على channel.setName() (كان يخضع لـRate Limit
  // ديسكورد مباشرةً وقد يُعطّل معالجة الرسالة)، نُمرّر الطلب إلى الطابور
  // المركزي (ticketRenameQueue). هذا المسار يُنفَّذ عند كل رسالة تُغيّر
  // حالة needs_reply/no_action، وهو من أكثر المسارات تكراراً - لذلك
  // يستفيد بشكل خاص من Debounce الطابور الذي يمنع تراكم طلبات متلاحقة.
  queueRename(
    message.channel,
    buildStatusChannelName(baseName, nextStatus),
    { context: `message_reply_status_${nextStatus}` }
  );
}

/**
 * TASK31: formats the elapsed AFK duration as e.g. "2h 15m" / "45m" /
 * "30s" for the welcome-back message - local to this file (same pattern
 * as the other formatDuration() helpers already in the project, e.g.
 * utils/musicQueueEmbed.js's mm:ss one - each domain keeps its own
 * shape/units rather than sharing one generic formatter).
 */
function formatAfkDuration(ms) {
  const totalSeconds = Math.max(0, Math.floor(ms / 1000));
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  if (hours > 0) return `${hours}h ${minutes}m`;
  if (minutes > 0) return `${minutes}m`;
  return `${seconds}s`;
}

/**
 * Clears the sender's own AFK status the moment they speak again, restores
 * their pre-AFK nickname, and lets them know who mentioned them while away.
 */
async function handleAfkClear(message, settings) {
  const afk = await AfkStatus.findOneAndDelete({ guildId: message.guild.id, userId: message.author.id });
  if (!afk) return;

  // TASK31: restore the nickname captured by /afk (commands/utility/afk.js)
  // before the "AFK | " prefix was applied. Same best-effort contract as
  // activation - a missing permission/hierarchy change since they went
  // AFK (e.g. a role shuffle) must never stop the rest of this (the
  // welcome-back message, mention summary) from running.
  if (message.member && message.member.manageable) {
    try {
      await message.member.setNickname(afk.originalNick ?? null);
    } catch (err) {
      logger.error(`handleAfkClear: failed to restore nickname for ${message.author.id} in guild ${message.guild.id}: ${err?.stack || err}`);
    }
  }

  const duration = formatAfkDuration(Date.now() - new Date(afk.since).getTime());

  // TASK31: tally the raw mentioner-id log (see AfkStatus.js/
  // handleAfkMentions below) into "who mentioned you, how many times" -
  // capped display (top 15) so an extreme-spam case can't produce a
  // Discord-embed-breaking wall of text; `mentionCount` (the existing
  // running total) is still shown in full regardless of how many appear
  // in the detailed list. The underlying `mentions`/`mentionCount` data
  // is deleted along with the rest of the AFK doc by findOneAndDelete
  // above - nothing further to clean up once this message is sent.
  let mentionSection = '';
  if (afk.mentionCount > 0) {
    const tally = new Map();
    for (const mentionerId of afk.mentions || []) {
      tally.set(mentionerId, (tally.get(mentionerId) || 0) + 1);
    }
    const lines = [...tally.entries()]
      .sort((a, b) => b[1] - a[1])
      .slice(0, 15)
      .map(([mentionerId, count]) => `• <@${mentionerId}> — ${count} mention${count === 1 ? '' : 's'}`);
    const overflowNote = tally.size > 15 ? `\n...and ${tally.size - 15} more` : '';
    mentionSection = lines.length
      ? `\n\nPeople who mentioned you:\n${lines.join('\n')}${overflowNote}\n\nTotal mentions: **${afk.mentionCount}**`
      : `\n\nYou were mentioned **${afk.mentionCount}** time(s) while away.`;
  }

  message
    .reply({ embeds: [successEmbed(settings, `Welcome back, ${message.author}! You were AFK for **${duration}**.${mentionSection}`)] })
    .then((m) => setTimeout(() => m.delete().catch(() => null), 8000))
    .catch(() => null);
}

/**
 * Notifies the author when they mention someone who is currently AFK,
 * deletes the mentioning message when the bot is able to, and logs the
 * mention (who + how many times) for that AFK member to see on return.
 */
async function handleAfkMentions(message, guildConfig, settings) {
  if (!message.mentions.users.size) return;

  // TASK31: self-mentions were already excluded here before this task;
  // kept exactly as-is. Messages from bots (including this bot) never
  // reach this handler at all - `message.author.bot` is checked at the
  // very top of execute() - so an AFK member being mentioned by another
  // bot/webhook can't happen here either.
  const mentionedIds = [...message.mentions.users.keys()].filter((id) => id !== message.author.id);
  if (!mentionedIds.length) return;

  const afkUsers = await AfkStatus.find({ guildId: message.guild.id, userId: { $in: mentionedIds } });
  if (!afkUsers.length) return;

  // TASK31: append this mentioner to each mentioned AFK member's log in
  // one atomic $push per member (no separate read-modify-write), capped
  // with $slice so a member who gets spam-mentioned all day can't grow
  // this array unboundedly - matches the existing `mentionCount` $inc
  // for "don't add an unnecessary query/write pattern".
  await AfkStatus.updateMany(
    { guildId: message.guild.id, userId: { $in: afkUsers.map((a) => a.userId) } },
    { $inc: { mentionCount: 1 }, $push: { mentions: { $each: [message.author.id], $slice: -100 } } }
  );

  // TASK31: delete the message that pinged the AFK member(s) before the
  // reply goes out, matching the spec's "delete the mention message"
  // requirement - but only when the bot actually has permission to; if
  // not, this silently no-ops and the notification below still sends
  // normally (a missing Manage Messages permission must never block the
  // rest of AFK from working). Same permission-check pattern
  // handleIpTrigger already uses above in this same file.
  const canDeleteMention = message.channel.permissionsFor(message.guild.members.me)?.has(PermissionFlagsBits.ManageMessages);
  if (message.deletable && canDeleteMention) {
    message.delete().catch(() => null);
  }

  const lines = afkUsers.map((a) => {
    const since = `<t:${Math.floor(new Date(a.since).getTime() / 1000)}:R>`;
    return a.reason && a.reason !== 'AFK'
      ? `⚠️ <@${a.userId}> is currently AFK.\n**Reason:** ${a.reason}\n**Since:** ${since}`
      : `⚠️ <@${a.userId}> is currently AFK.\n**Since:** ${since}`;
  });
  message.channel.send({ content: `${message.author}`, embeds: [baseEmbed(settings).setDescription(lines.join('\n\n'))] }).catch(() => null);
}

/**
 * Reposts the channel's sticky message (if one is configured) to the bottom
 * of the channel so it stays visible under new activity.
 */
async function handleStickyRepost(message, settings) {
  const sticky = await StickyMessage.findOne({ channelId: message.channelId });
  if (!sticky) return;
  // Don't immediately re-repost in response to the bot's own sticky message.
  if (message.id === sticky.lastMessageId) return;

  await repostSticky(message.channel, sticky, settings);
}

/**
 * Matches the message content against configured auto-responder triggers
 * and sends the first matching response.
 */
async function handleAutoResponder(message, guildConfig) {
  const content = message.content.toLowerCase().trim();
  if (!content) return;

  const responders = await AutoResponder.find({ guildId: message.guild.id });
  if (!responders.length) return;

  const match = responders.find((r) => {
    const trigger = r.trigger.toLowerCase();
    return r.matchType === 'exact' ? content === trigger : content.includes(trigger);
  });
  if (!match) return;

  // The response text is staff-configured (via /autoresponder, gated on
  // ManageGuild) but that permission is not the same as Discord's own
  // "Mention Everyone" permission - without this, a guild manager who
  // lacks MentionEveryone could still get an actual @everyone/@here/role
  // ping out of the bot (which normally does have that permission) just
  // by putting it in a trigger response. Mirrors the same fix already
  // applied to dashboard/routes/sticky.js's raw content send.
  message.channel.send({ content: match.response, allowedMentions: { parse: [] } }).catch(() => null);
}

/**
 * Drives the counting game: validates the next number, updates the running
 * count, and resets on a broken sequence or a repeat-user violation.
 * Returns true if the message belonged to the counting channel (so the
 * caller can skip other handlers like automod/autoresponder for it).
 */
async function handleCounting(message, guildConfig, settings) {
  if (!guildConfig.counting?.enabled || message.channelId !== guildConfig.counting.channelId) return false;

  const submitted = Number(message.content.trim());
  const expected = guildConfig.counting.currentCount + 1;
  const isValidNumber = Number.isInteger(submitted) && String(submitted) === message.content.trim();
  const isSameUserTwice = guildConfig.counting.lastUserId === message.author.id;

  if (!isValidNumber || submitted !== expected || isSameUserTwice) {
    await message.react('❌').catch(() => null);

    const reason = isSameUserTwice
      ? 'you cannot count twice in a row'
      : !isValidNumber
        ? 'that is not a valid whole number'
        : `the next number should have been **${expected}**`;

    message.channel
      .send({ embeds: [errorEmbed(settings, `${message.author} broke the count at **${guildConfig.counting.currentCount}** - ${reason}.`)] })
      .catch(() => null);

    if (guildConfig.counting.resetOnError) {
      guildConfig.counting.currentCount = 0;
      guildConfig.counting.lastUserId = null;
    }
    await guildConfig.save();
    return true;
  }

  guildConfig.counting.currentCount = submitted;
  guildConfig.counting.lastUserId = message.author.id;
  if (submitted > guildConfig.counting.highestCount) guildConfig.counting.highestCount = submitted;
  await guildConfig.save();

  await message.react('✅').catch(() => null);
  return true;
}

/**
 * If this channel is configured for auto-delete, schedules the message for
 * removal after the configured delay and flags it so messageDelete knows
 * this was an expected cleanup rather than a real deletion.
 */
async function handleAutoDeleteSchedule(message, guildConfig) {
  const config = (guildConfig.moderation?.autoDeleteChannels || []).find((c) => c.channelId === message.channelId);
  if (!config) return;

  setTimeout(() => {
    markAutoDeleted(message.id);
    message.delete().catch(() => null);
  }, config.delaySeconds * 1000).unref?.();
}

async function handleAutomod(message, guildConfig, settings) {
  return runAutoModeration(message, guildConfig, settings);
}

/**
 * TASK16 (Leveling / XP system): grants XP for this message, gated by
 * per-channel/per-role exclusions on top of the existing bot-check
 * (message.author.bot, top of execute()) and cooldown (inside
 * grantMessageXp). Announces a level-up as a dedicated embed, distinct
 * from the plain-text one this replaces, when the guild has that
 * enabled.
 *
 * TASK18: on level-up, also grants any configured level-reward roles
 * (services/levelRewardService.js) BEFORE checking announceLevelUp, so
 * rewards are still handed out even in guilds that have turned
 * announcements off. Reward granting is wrapped separately and can never
 * throw out of this function - per spec, a Discord API/permission
 * failure while granting a role must never block XP or the level-up
 * announcement.
 */
async function handleLeveling(message, guildConfig, settings) {
  const leveling = guildConfig.leveling;
  if (!leveling?.enabled) return;

  const excludedChannelIds = leveling.excludedChannelIds || [];
  if (excludedChannelIds.includes(message.channelId)) return;

  // TASK17 audit: matches the same has()-in-some() pattern already used
  // by services/mentionProtectionService.js and utils/permissions.js for
  // "does this member have any of these role IDs" checks elsewhere in
  // the project, instead of Collection#hasAny (works in discord.js, but
  // untested anywhere else in this codebase).
  const excludedRoleIds = leveling.excludedRoleIds || [];
  if (excludedRoleIds.length && excludedRoleIds.some((roleId) => message.member?.roles?.cache?.has(roleId))) return;

  // TASK25: role-based XP multiplier (e.g. Boosters/a premium role
  // earning extra XP) - resolved from message.member (already available
  // here, unlike inside grantMessageXp which only knows guildId/userId)
  // and applied to the base range before it's handed to the atomic
  // grant below. getXpMultiplier()/applyXpMultiplier() both no-op back
  // to the exact previous behavior when a guild has no multipliers
  // configured (the default), so this is a pure addition.
  const baseXpRange = resolveXpRange(leveling);
  const multiplier = getXpMultiplier(message.member, leveling);
  const xpRange = applyXpMultiplier(baseXpRange, multiplier);
  const { leveledUp, newLevel, previousLevel, totalXp } = await grantMessageXp(
    message.guild.id,
    message.author.id,
    xpRange,
    leveling.cooldownSeconds
  );

  if (!leveledUp) return;

  let grantedRoles = [];
  if (message.member) {
    try {
      grantedRoles = await grantLevelRewards(message.guild, message.member, guildConfig, previousLevel, newLevel);
    } catch (err) {
      // grantLevelRewards already catches/logs per-reward errors - this
      // is a last-resort safety net so an unexpected throw here still
      // can't stop the level-up announcement below.
      logger.error(`Level reward grant failed for ${message.author.id} in guild ${message.guild.id}: ${err?.stack || err}`);
    }
  }

  if (leveling.announceLevelUp !== false) {
    const channelId = leveling.announceChannelId || message.channelId;
    const channel = message.guild.channels.cache.get(channelId) || message.channel;
    const progress = getLevelProgress(totalXp);

    // TASK20: visually align the level-up announcement with the /rank
    // card - same accent color (when the guild has set one) and the
    // same Level/XP-to-next-level numbers, instead of the plain
    // "New Level" + "Total XP" fields this had before. The XP/level
    // math itself (grantMessageXp above) and the once-per-level-up
    // guarantee it provides are completely untouched by this - this
    // only changes what gets drawn in the embed after a level-up has
    // already been decided.
    const cardAccent = leveling.card?.accentColor;
    const accentColor = typeof cardAccent === 'string' && /^#[0-9a-fA-F]{6}$/.test(cardAccent) ? cardAccent : settings.embedColor;

    const embed = baseEmbed(settings)
      .setColor(accentColor)
      .setTitle('🎉 Level Up!')
      .setDescription(`${message.author} just reached **level ${newLevel}**!`)
      .setThumbnail(message.author.displayAvatarURL())
      .addFields(
        { name: 'New Level', value: `${newLevel}`, inline: true },
        { name: 'Total XP', value: `${progress.totalXp.toLocaleString()}`, inline: true },
        { name: 'Next Level', value: `${progress.currentXp.toLocaleString()} / ${progress.xpNeeded.toLocaleString()} XP`, inline: true }
      );

    if (grantedRoles.length) {
      embed.addFields({
        name: grantedRoles.length > 1 ? '🎁 Rewards' : '🎁 Reward',
        value: grantedRoles.map((role) => `<@&${role.id}>`).join(', '),
      });
    }

    channel.send({ embeds: [embed] }).catch(() => null);
  }
}

async function handleLegacyPrefixCommands(message, settings) {
  if (!message.content.startsWith(settings.prefix)) return;

  const args = message.content.slice(settings.prefix.length).trim().split(/\s+/);
  const commandName = args.shift()?.toLowerCase();

  if (commandName === 'ping') {
    await message.reply({
      embeds: [baseEmbed(settings).setDescription(`🏓 Pong! Latency: **${message.client.ws.ping}ms**`)],
    });
  } else if (commandName === 'help') {
    await message.reply({
      embeds: [
        baseEmbed(settings)
          .setTitle('Need help?')
          .setDescription('This bot primarily uses **slash commands** - type `/` to see the full list.'),
      ],
    });
  }
}
