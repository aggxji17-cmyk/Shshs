const { EmbedBuilder } = require('discord.js');
const logger = require('../../utils/logger');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { errorEmbed } = require('../../utils/embeds');
const { COLORS, ICONS } = require('../../utils/designSystem');
const cooldown = require('../../utils/cooldown');
const { resolveCommandPermission } = require('../../utils/commandPermissions');
const { isCommandDisabledInChannel } = require('../../utils/channelCommandBlacklist');
const { isCommandDisabledForMember } = require('../../utils/roleCommandBlacklist');
const { getBotConfig, isCommandGloballyDisabled } = require('../../utils/globalCommandBlacklist');
const { logCommandUsage } = require('../../utils/commandLogService');
const { config } = require('../../config/config');
const { handleUnknownInteraction } = require('../../utils/unknownInteractionHandler');

module.exports = {
  name: 'interactionCreate',
  async execute(interaction) {
    // Autocomplete requests are handled completely separately from the
    // rest of the flow: they can only ever be answered with
    // interaction.respond() (never reply/followUp/defer), they must
    // land within Discord's 3s window, and a failure here should never
    // surface an error message to the user - it should just fall back
    // to an empty suggestion list. handleAutocomplete is fully
    // self-contained (its own try/catch) so it's safe to await outside
    // the try/catch below.
    if (interaction.isAutocomplete()) {
      return handleAutocomplete(interaction);
    }

    try {
      // Slash commands and context menu commands (right-click / long-press
      // a user or message -> Apps) both resolve to a client.commands entry
      // by interaction.commandName and share the exact same blacklist/
      // cooldown/error-handling pipeline, so they go through one handler.
      if (interaction.isChatInputCommand() || interaction.isContextMenuCommand()) {
        return handleSlashCommand(interaction);
      }
      if (interaction.isButton()) {
        return handleComponent(interaction);
      }
      if (interaction.isStringSelectMenu()) {
        return handleComponent(interaction);
      }
      if (interaction.isModalSubmit()) {
        return handleComponent(interaction);
      }
    } catch (err) {
      const label = interaction.commandName || interaction.customId || 'unknown';
      logger.error(`Interaction handling error [${label}]: ${err.stack || err}`);
      await safeErrorReply(interaction);
    }
  },
};

/**
 * Shared handler for both slash commands (isChatInputCommand) and context
 * menu commands (isUserContextMenuCommand / isMessageContextMenuCommand -
 * the "Apps" entry shown on right-click / long-press of a user or
 * message). Both interaction types expose interaction.commandName and
 * resolve to the same client.commands Collection entry, so they share
 * every step here: blacklist, cooldown, and the try/execute/finally
 * safety-net block.
 */
async function handleSlashCommand(interaction) {
  const command = interaction.client.commands.get(interaction.commandName);
  if (!command) {
    // TASK 16 (unknown command lookup): this used to `return` silently,
    // leaving the interaction completely unacknowledged - Discord shows
    // the user a generic "This interaction failed" with no explanation,
    // and nothing was logged to tell staff a command is missing (stale
    // deploy after a rename/removal, or Discord's command cache lagging
    // behind client.commands). Mirrors the same "no longer
    // available" response and warn-level logging already used for
    // unknown component customIds (utils/unknownInteractionHandler.js)
    // instead of a silent no-op.
    logger.warn(`Unknown command interaction: commandName="${interaction.commandName}", guild="${interaction.guildId || 'DM'}", user="${interaction.user?.id || 'unknown'}"`);
    return interaction
      .reply({
        embeds: [
          new EmbedBuilder()
            .setColor(COLORS.warning)
            .setFooter({ text: config.embedFooter })
            .setTimestamp()
            .setDescription(
              `${ICONS.info} This command is no longer available. It may have been removed or renamed.\n\n` +
                `هذا الأمر لم يعد متاحاً. قد يكون قد أُزيل أو تغيّر اسمه.`
            ),
        ],
        ephemeral: true,
      })
      .catch((err) => {
        logger.error(`Failed to respond to unknown command "${interaction.commandName}": ${err.message}`);
      });
  }

  // Bluntest switch of all: /globaldisable (bot owner only) disables a
  // command across every server at once, with no guild-level override
  // able to undo it. Checked before anything guild-scoped below, and
  // before even knowing whether this interaction has a guild at all.
  const botConfig = await getBotConfig();
  if (isCommandGloballyDisabled(interaction.commandName, botConfig)) {
    return interaction.reply({
      embeds: [
        new EmbedBuilder()
          .setColor(COLORS.error)
          .setFooter({ text: config.embedFooter })
          .setTimestamp()
          .setDescription(`${ICONS.error} This command is currently disabled by the bot owner. / هذا الأمر معطل حالياً من قبل مالك البوت.`),
      ],
      ephemeral: true,
    });
  }

  let guildConfig = null;
  if (interaction.guildId) {
    guildConfig = await getGuildConfig(interaction.guildId);
    const blacklist = guildConfig.commandBlacklist;
    const isBlacklisted =
      (blacklist?.userIds || []).includes(interaction.user.id) ||
      (blacklist?.commandNames || []).includes(interaction.commandName);

    // The blacklist command itself always stays usable so admins can undo a mistake.
    if (isBlacklisted && interaction.commandName !== 'blacklist') {
      const settings = resolved(guildConfig);
      return interaction.reply({
        embeds: [errorEmbed(settings, 'This command is unavailable to you in this server. / هذا الأمر غير متاح لك في هذا السيرفر.')],
        ephemeral: true,
      });
    }

    // Same blunt on/off switch as the guild-wide blacklist above, just
    // scoped to this one channel (configured via /blacklist channel).
    // Blocks everyone, including guild managers - see
    // utils/channelCommandBlacklist.js.
    if (isCommandDisabledInChannel(interaction.commandName, interaction.channelId, guildConfig)) {
      const settings = resolved(guildConfig);
      return interaction.reply({
        embeds: [errorEmbed(settings, 'This command is disabled in this channel. / هذا الأمر معطل في هذه القناة.')],
        ephemeral: true,
      });
    }

    // Same blunt on/off switch again, this time scoped to any role the
    // member holds (configured via /blacklist role). Blocks everyone
    // holding the role, including guild managers - see
    // utils/roleCommandBlacklist.js.
    if (isCommandDisabledForMember(interaction.commandName, interaction.member, guildConfig)) {
      const settings = resolved(guildConfig);
      return interaction.reply({
        embeds: [errorEmbed(settings, 'This command is disabled for your role in this server. / هذا الأمر معطل لرتبتك في هذا السيرفر.')],
        ephemeral: true,
      });
    }

    // Finer-grained than the blacklist above: per-command role/user allow
    // and deny rules configured via /permissions. See
    // utils/commandPermissions.js for the exact resolution order.
    const { allowed, reason } = resolveCommandPermission(interaction.commandName, interaction.member, guildConfig, interaction.channelId);
    if (!allowed) {
      const settings = resolved(guildConfig);
      const message =
        reason === 'denied-channel'
          ? 'This command cannot be used in this channel. / لا يمكن استخدام هذا الأمر في هذه القناة.'
          : 'You do not have permission to use this command in this server. / ليس لديك صلاحية استخدام هذا الأمر في هذا السيرفر.';
      return interaction.reply({
        embeds: [errorEmbed(settings, message)],
        ephemeral: true,
      });
    }
  }

  // Debounce double-submits (double-tapping the command, a second click
  // while the first is still processing, etc.) with an instant, cheap
  // reply - no DB/settings lookup - before doing any real work. Commands
  // can override the window via `command.cooldownSeconds`.
  const remaining = cooldown.check(interaction.commandName, interaction.user.id, command.cooldownSeconds);
  if (remaining) {
    return interaction.reply({ embeds: [cooldownEmbed(remaining)], ephemeral: true }).catch(() => null);
  }

  // Every blacklist/permission/cooldown check above has passed, so this
  // is genuine usage - record it (see utils/commandLogService.js).
  await logCommandUsage(interaction, guildConfig);

  const disarm = armResponseSafetyNet(interaction);
  try {
    await command.execute(interaction);
  } catch (err) {
    logger.error(`Command "${interaction.commandName}" failed: ${err.stack || err}`);
    await safeErrorReply(interaction);
  } finally {
    disarm();
  }
}

/**
 * Builds the small, deliberately guild-settings-free embed shown when a
 * user is on cooldown. Skipping the usual getGuildConfig()/resolved()
 * lookup here is intentional - the whole point of this reply is to be
 * as fast as possible, so it never waits on a database round trip.
 */
function cooldownEmbed(seconds) {
  return new EmbedBuilder()
    .setColor(COLORS.warning)
    .setDescription(`${ICONS.loading} Please wait **${seconds}s** before using this again. / يرجى الانتظار **${seconds}** ثانية قبل استخدام هذا الأمر مجدداً.`);
}

/**
 * Safety net against the classic "This interaction failed" a user sees
 * when a command's first reply doesn't land within Discord's 3-second
 * window (a slow DB write, an external API call, etc.). If the command
 * hasn't replied or deferred within 2.5s, this defers on its behalf
 * (ephemeral, so a slow command never accidentally makes something
 * public that was meant to be private) and transparently redirects the
 * command's own eventual `interaction.reply(...)` call to `editReply`
 * so it keeps working without the command needing to know any of this
 * happened. Call the returned function once the command has finished
 * (success or failure) to cancel the timer if it never fired.
 */
function armResponseSafetyNet(interaction) {
  const timer = setTimeout(() => {
    if (!interaction.deferred && !interaction.replied) {
      logger.warn(`[SafetyNet] Auto-deferring slow command "${interaction.commandName}" (user ${interaction.user?.id}, guild ${interaction.guildId ?? 'DM'})`);
      interaction.deferReply({ ephemeral: true }).catch(() => null);
    }
  }, 2500);

  if (!interaction.__replySafetyPatched) {
    const originalReply = interaction.reply.bind(interaction);
    interaction.reply = (payload) => {
      if (interaction.deferred || interaction.replied) {
        return interaction.editReply(payload);
      }
      return originalReply(payload);
    };
    interaction.__replySafetyPatched = true;
  }

  return () => clearTimeout(timer);
}

/**
 * Dispatches an autocomplete request to the owning command's
 * `autocomplete` export, if it has one. Commands opt in per-option via
 * `.setAutocomplete(true)` on the SlashCommandBuilder - a command with
 * no `autocomplete` export simply gets an empty list, which Discord
 * renders as "no suggestions" rather than an error.
 */
async function handleAutocomplete(interaction) {
  const command = interaction.client.commands.get(interaction.commandName);

  try {
    if (command?.autocomplete) {
      await command.autocomplete(interaction);
    } else {
      await interaction.respond([]);
    }
  } catch (err) {
    // Swallow here rather than rethrow: throwing would bubble up to
    // whoever called execute() and there is no valid way to "error
    // reply" to an autocomplete interaction (it has no reply/followUp).
    logger.error(`Autocomplete for "${interaction.commandName}" failed: ${err.stack || err}`);
  }
}

// TASK 07: ComponentManager is now the sole routing system.
// Legacy handlerMap fallback removed — all Buttons (92), Select Menus (7),
// and Modals (40) are registered in ComponentManager via componentInitializers.js.
async function handleComponent(interaction) {
  const customId = interaction.customId;

  // ComponentManager is the single routing path (TASK 06 fix preserved):
  //   result.found === true  + success → handler ran cleanly
  //   result.found === true  + error   → handler threw a runtime error
  //   result.found === false            → no handler registered → unknown interaction
  const result = await interaction.client.componentManager.execute(customId, interaction);

  if (result.success) {
    return; // Handler executed successfully
  }

  if (result.found && result.error) {
    // Handler was found but threw a runtime error
    logger.error(`Component handler for "${customId}" failed: ${result.error.stack || result.error}`);
    await safeErrorReply(interaction);
    return;
  }

  // result.found === false: no handler registered for this customId
  // Task 50 — معالجة التفاعلات غير المعروفة
  return handleUnknownInteraction(interaction);
}

async function safeErrorReply(interaction) {
  try {
    // Use resolved({}) (default settings) intentionally here instead of a
    // second getGuildConfig() call: we are already inside an error path, and
    // an additional async DB round-trip risks a second failure that would
    // swallow the original error or cause an unhandled rejection of its own.
    // Default colour/footer is fine for an error fallback message.
    const settings = resolved({});
    const embed = errorEmbed(settings, 'Something went wrong while processing that action. / حدث خطأ أثناء تنفيذ هذا الإجراء.');

    if (interaction.replied || interaction.deferred) {
      await interaction.followUp({ embeds: [embed], ephemeral: true });
    } else {
      await interaction.reply({ embeds: [embed], ephemeral: true });
    }
  } catch {
    // Interaction likely already timed out - nothing more we can do.
  }
}
