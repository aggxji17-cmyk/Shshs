const { SlashCommandBuilder } = require('discord.js');
const { getGuildConfig, resolved } = require('../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../utils/embeds');
const { requireActiveQueue } = require('../utils/musicChecks');
const { getKazagumo } = require('../services/lavalinkManager');

module.exports = {
  data: new SlashCommandBuilder().setName('pause').setDescription('Pause the currently playing track')
    .setDescriptionLocalizations({ ar: 'إيقاف المقطع الحالي مؤقتاً', 'en-US': 'Pause the currently playing track' }),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    // Migrated path: if this guild's queue is being run through
    // Kazagumo/Lavalink, pause it that way.
    const kazagumo = getKazagumo();
    const kazagumoPlayer = kazagumo?.players.get(interaction.guildId);

    if (kazagumoPlayer && kazagumoPlayer.queue.current) {
      const memberChannel = interaction.member?.voice?.channel;
      if (!memberChannel || memberChannel.id !== kazagumoPlayer.voiceId) {
        return interaction.reply({
          embeds: [errorEmbed(settings, `انضم لـ <#${kazagumoPlayer.voiceId}> للتحكم بالموسيقى.`)],
          ephemeral: true,
        });
      }

      if (kazagumoPlayer.paused) {
        return interaction.reply({ embeds: [errorEmbed(settings, 'Playback is already paused.')], ephemeral: true });
      }

      kazagumoPlayer.pause(true);
      return interaction.reply({ embeds: [successEmbed(settings, `⏸️ تم إيقاف **${kazagumoPlayer.queue.current.title}** مؤقتاً.`)] });
    }

    // Not migrated for this guild yet (no Kazagumo player, e.g. Lavalink
    // isn't configured, or this guild's queue predates it) - fall back to
    // the original discord-player path so behavior is unchanged from
    // before this task.
    const queue = await requireActiveQueue(interaction, settings);
    if (!queue) return;

    if (queue.node.isPaused()) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'Playback is already paused.')], ephemeral: true });
    }

    queue.node.setPaused(true);
    return interaction.reply({ embeds: [successEmbed(settings, `⏸️ تم إيقاف **${queue.currentTrack.title}** مؤقتاً.`)] });
  },
};
