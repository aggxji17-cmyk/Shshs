const { SlashCommandBuilder } = require('discord.js');
const { getGuildConfig, resolved } = require('../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../utils/embeds');
const { requireActiveQueue } = require('../utils/musicChecks');
const { getKazagumo } = require('../services/lavalinkManager');

module.exports = {
  data: new SlashCommandBuilder().setName('skip').setDescription('Skip the currently playing track')
    .setDescriptionLocalizations({ ar: 'تخطي المقطع الحالي', 'en-US': 'Skip the currently playing track' }),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    // Migrated path: if this guild's queue is being run through
    // Kazagumo/Lavalink, skip it that way.
    const kazagumo = getKazagumo();
    const kazagumoPlayer = kazagumo?.players.get(interaction.guildId);

    if (kazagumoPlayer && kazagumoPlayer.queue.current) {
      const memberChannel = interaction.member?.voice?.channel;
      if (!memberChannel || memberChannel.id !== kazagumoPlayer.voiceId) {
        return interaction.reply({
          embeds: [errorEmbed(settings, `انضم لـ <#${kazagumoPlayer.voiceId}> للتحكم بالموسيقى.`)],
          ephemeral: true,
        });
      }

      const skipped = kazagumoPlayer.queue.current;
      kazagumoPlayer.skip();

      return interaction.reply({ embeds: [successEmbed(settings, `تم تخطي **${skipped.title}**.`)] });
    }

    // Not migrated for this guild yet (no Kazagumo player, e.g. Lavalink
    // isn't configured, or this guild's queue was started before that -
    // fall back to the original discord-player path so behavior is
    // unchanged from before this task).
    const queue = await requireActiveQueue(interaction, settings);
    if (!queue) return;

    const skipped = queue.currentTrack;
    queue.node.skip();

    return interaction.reply({ embeds: [successEmbed(settings, `تم تخطي **${skipped.title}**.`)] });
  },
};
