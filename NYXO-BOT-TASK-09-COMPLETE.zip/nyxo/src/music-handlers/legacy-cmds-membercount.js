const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { getGuildConfig, resolved, invalidateGuildConfig } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('membercount')
    .setDescription('Configure a voice channel that displays the live member count')
    .setDescriptionLocalizations({ ar: 'إعداد قناة صوتية تعرض عدد الأعضاء مباشرة', 'en-US': 'Configure a voice channel that displays the live member count' })
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((s) =>
      s
        .setName('config')
        .setDescription('Set the channel and name format')
      .setDescriptionLocalizations({ ar: 'تعيين القناة وصيغة الاسم', 'en-US': 'Set the channel and name format' })
        .addChannelOption((o) => o.setName('channel').setDescription('Voice channel to rename with the member count').setDescriptionLocalizations({ ar: 'القناة الصوتية التي يُعاد تسميتها بعدد الأعضاء', 'en-US': 'Voice channel to rename with the member count' }).addChannelTypes(ChannelType.GuildVoice).setRequired(true))
        .addStringOption((o) => o.setName('format').setDescription('Name template - {count} is replaced with the member count').setDescriptionLocalizations({ ar: 'قالب الاسم - يُستبدل {count} بعدد الأعضاء', 'en-US': 'Name template - {count} is replaced with the member count' }).setMaxLength(90))
    )
    .addSubcommand((s) => s.setName('toggle').setDescription('Enable or disable the member count channel')
      .setDescriptionLocalizations({ ar: 'تفعيل أو تعطيل قناة عدد الأعضاء', 'en-US': 'Enable or disable the member count channel' })),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You need Manage Server permission to use this command.')], ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();

    if (sub === 'toggle') {
      guildConfig.memberCountChannel.enabled = !guildConfig.memberCountChannel.enabled;
      await guildConfig.save();
      invalidateGuildConfig(interaction.guildId);
      return interaction.reply({ embeds: [successEmbed(settings, `Member count channel is now **${guildConfig.memberCountChannel.enabled ? 'enabled' : 'disabled'}**.`)] });
    }

    const channel = interaction.options.getChannel('channel');
    const format = interaction.options.getString('format');

    guildConfig.memberCountChannel.channelId = channel.id;
    if (format) guildConfig.memberCountChannel.format = format;

    await guildConfig.save();
    invalidateGuildConfig(interaction.guildId);
    return interaction.reply({ embeds: [successEmbed(settings, `${channel} will be renamed to show the live member count (updates every ~10 minutes).`)] });
  },
};
