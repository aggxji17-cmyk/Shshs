const { SlashCommandBuilder } = require('discord.js');
const { useMainPlayer } = require('discord-player');
const { getGuildConfig, resolved } = require('../utils/resolveGuildSettings');
const { baseEmbed, successEmbed, errorEmbed } = require('../utils/embeds');
const { requireVoiceChannel } = require('../utils/musicChecks');
const { safeAutocomplete, fuzzyFilter } = require('../utils/autocomplete');
const playlistService = require('../services/playlistService');
const { guildIsOnKazagumo } = require('../services/lavalinkManager');

const NAME_DESC = { ar: 'اسم قائمة التشغيل', 'en-US': 'Playlist name' };

function nameOption(o, required = true) {
  return o
    .setName('name')
    .setDescription('Playlist name')
    .setDescriptionLocalizations(NAME_DESC)
    .setRequired(required)
    .setAutocomplete(true);
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('playlist')
    .setDescription('Manage your personal music playlists')
    .setDescriptionLocalizations({ ar: 'إدارة قوائم التشغيل الخاصة بك', 'en-US': 'Manage your personal music playlists' })
    .addSubcommand((sc) =>
      sc
        .setName('create')
        .setDescription('Create a new playlist')
        .setDescriptionLocalizations({ ar: 'إنشاء قائمة تشغيل جديدة', 'en-US': 'Create a new playlist' })
        .addStringOption((o) => o.setName('name').setDescription('Playlist name').setDescriptionLocalizations(NAME_DESC).setRequired(true).setMaxLength(50))
    )
    .addSubcommand((sc) =>
      sc
        .setName('delete')
        .setDescription('Delete one of your playlists')
        .setDescriptionLocalizations({ ar: 'حذف إحدى قوائم التشغيل الخاصة بك', 'en-US': 'Delete one of your playlists' })
        .addStringOption((o) => nameOption(o))
    )
    .addSubcommand((sc) =>
      sc
        .setName('list')
        .setDescription('List your playlists')
        .setDescriptionLocalizations({ ar: 'عرض قوائم التشغيل الخاصة بك', 'en-US': 'List your playlists' })
    )
    .addSubcommand((sc) =>
      sc
        .setName('view')
        .setDescription('Show the tracks in a playlist')
        .setDescriptionLocalizations({ ar: 'عرض المقاطع الموجودة في قائمة تشغيل', 'en-US': 'Show the tracks in a playlist' })
        .addStringOption((o) => nameOption(o))
    )
    .addSubcommand((sc) =>
      sc
        .setName('add')
        .setDescription('Add a song to a playlist')
        .setDescriptionLocalizations({ ar: 'إضافة أغنية إلى قائمة تشغيل', 'en-US': 'Add a song to a playlist' })
        .addStringOption((o) => nameOption(o))
        .addStringOption((o) =>
          o
            .setName('song')
            .setDescription('Song name, artist, or a YouTube/Spotify/SoundCloud link')
            .setDescriptionLocalizations({ ar: 'اسم الأغنية أو الفنان أو رابط من يوتيوب/سبوتيفاي/ساوندكلاود', 'en-US': 'Song name, artist, or a YouTube/Spotify/SoundCloud link' })
            .setRequired(true)
        )
    )
    .addSubcommand((sc) =>
      sc
        .setName('remove')
        .setDescription('Remove a song from a playlist')
        .setDescriptionLocalizations({ ar: 'إزالة أغنية من قائمة تشغيل', 'en-US': 'Remove a song from a playlist' })
        .addStringOption((o) => nameOption(o))
        .addIntegerOption((o) =>
          o.setName('position').setDescription('Track position (see /playlist view)').setDescriptionLocalizations({ ar: 'ترتيب المقطع (انظر /playlist view)', 'en-US': 'Track position (see /playlist view)' }).setRequired(true).setAutocomplete(true)
        )
    )
    .addSubcommand((sc) =>
      sc
        .setName('play')
        .setDescription('Queue an entire playlist in your voice channel')
        .setDescriptionLocalizations({ ar: 'تشغيل قائمة تشغيل كاملة في القناة الصوتية', 'en-US': 'Queue an entire playlist in your voice channel' })
        .addStringOption((o) => nameOption(o))
    ),

  autocomplete: safeAutocomplete(async (interaction) => {
    const sub = interaction.options.getSubcommand();
    const focused = interaction.options.getFocused(true);

    if (focused.name === 'name') {
      const playlists = await playlistService.getUserPlaylists(interaction.user.id);
      const matched = fuzzyFilter(playlists, String(focused.value), { key: (p) => p.name });
      return matched.map((p) => ({ name: `${p.name} (${p.tracks.length} مقاطع)`, value: p.name }));
    }

    if (focused.name === 'position' && sub === 'remove') {
      const name = interaction.options.getString('name');
      if (!name) return [];
      const playlist = await playlistService.getPlaylist(interaction.user.id, name);
      if (!playlist) return [];
      const items = playlist.tracks.map((t, i) => ({ index: i, title: t.title }));
      const matched = fuzzyFilter(items, String(focused.value), { key: (t) => t.title });
      return matched.map((t) => ({ name: `${t.index + 1}. ${t.title}`, value: t.index + 1 }));
    }

    return [];
  }),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    const sub = interaction.options.getSubcommand();

    if (sub === 'create') return handleCreate(interaction, settings);
    if (sub === 'delete') return handleDelete(interaction, settings);
    if (sub === 'list') return handleList(interaction, settings);
    if (sub === 'view') return handleView(interaction, settings);
    if (sub === 'add') return handleAdd(interaction, settings);
    if (sub === 'remove') return handleRemove(interaction, settings);
    if (sub === 'play') return handlePlay(interaction, settings, guildConfig);
  },
};

async function handleCreate(interaction, settings) {
  const name = interaction.options.getString('name', true);
  const { playlist, error } = await playlistService.createPlaylist(interaction.user.id, name);
  if (error) return interaction.reply({ embeds: [errorEmbed(settings, error)], ephemeral: true });
  return interaction.reply({ embeds: [successEmbed(settings, `Created playlist **${playlist.name}**. Add songs with \`/playlist add\`.`)] });
}

async function handleDelete(interaction, settings) {
  const name = interaction.options.getString('name', true);
  const { playlist, error } = await playlistService.deletePlaylist(interaction.user.id, name);
  if (error) return interaction.reply({ embeds: [errorEmbed(settings, error)], ephemeral: true });
  return interaction.reply({ embeds: [successEmbed(settings, `تم حذف القائمة **${playlist.name}**.`)] });
}

async function handleList(interaction, settings) {
  const playlists = await playlistService.getUserPlaylists(interaction.user.id);
  if (!playlists.length) {
    return interaction.reply({ embeds: [errorEmbed(settings, "You don't have any playlists yet. Create one with `/playlist create`.")], ephemeral: true });
  }

  const embed = baseEmbed(settings)
    .setTitle(`🎼 ${interaction.user.username}'s Playlists`)
    .setDescription(playlists.map((p, i) => `**${i + 1}.** ${p.name} — ${p.tracks.length} track${p.tracks.length === 1 ? '' : 's'}`).join('\n'));

  return interaction.reply({ embeds: [embed] });
}

async function handleView(interaction, settings) {
  const name = interaction.options.getString('name', true);
  const playlist = await playlistService.getPlaylist(interaction.user.id, name);
  if (!playlist) return interaction.reply({ embeds: [errorEmbed(settings, `لم يتم العثور على قائمة باسم **${name}**.`)], ephemeral: true });

  if (!playlist.tracks.length) {
    return interaction.reply({ embeds: [errorEmbed(settings, `**${playlist.name}** is empty. Add songs with \`/playlist add\`.`)], ephemeral: true });
  }

  const lines = playlist.tracks
    .slice(0, 25)
    .map((t, i) => `**${i + 1}.** [${t.title}](${t.url})${t.duration ? ` \`${t.duration}\`` : ''}`);
  if (playlist.tracks.length > 25) lines.push(`*...and ${playlist.tracks.length - 25} more.*`);

  const embed = baseEmbed(settings)
    .setTitle(`🎼 ${playlist.name}`)
    .setDescription(lines.join('\n'))
    .setThumbnail(playlist.tracks[0].thumbnail || null)
    .setFooter({ text: `${settings.footer} • ${playlist.tracks.length} track${playlist.tracks.length === 1 ? '' : 's'}` });

  return interaction.reply({ embeds: [embed] });
}

async function handleAdd(interaction, settings) {
  const name = interaction.options.getString('name', true);
  const song = interaction.options.getString('song', true);

  await interaction.deferReply();
  const { playlist, track, error } = await playlistService.addTrack(interaction.user.id, name, song, interaction.user);
  if (error) return interaction.editReply({ embeds: [errorEmbed(settings, error)] });

  return interaction.editReply({
    embeds: [successEmbed(settings, `Added **[${track.title}](${track.url})** to **${playlist.name}** (${playlist.tracks.length} مقاطع).`)],
  });
}

async function handleRemove(interaction, settings) {
  const name = interaction.options.getString('name', true);
  const position = interaction.options.getInteger('position', true);

  const { playlist, removed, error } = await playlistService.removeTrack(interaction.user.id, name, position - 1);
  if (error) return interaction.reply({ embeds: [errorEmbed(settings, error)], ephemeral: true });

  return interaction.reply({ embeds: [successEmbed(settings, `تمت إزالة **${removed.title}** من **${playlist.name}**.`)] });
}

async function handlePlay(interaction, settings, guildConfig) {
  const name = interaction.options.getString('name', true);
  const playlist = await playlistService.getPlaylist(interaction.user.id, name);
  if (!playlist) return interaction.reply({ embeds: [errorEmbed(settings, `لم يتم العثور على قائمة باسم **${name}**.`)], ephemeral: true });
  if (!playlist.tracks.length) {
    return interaction.reply({ embeds: [errorEmbed(settings, `**${playlist.name}** is empty. Add songs with \`/playlist add\`.`)], ephemeral: true });
  }

  if (guildIsOnKazagumo(interaction.guildId)) {
    return interaction.reply({
      embeds: [errorEmbed(settings, "This server's current music session is running on the Lavalink engine, which `/playlist play` doesn't support yet. Use `/play` with individual tracks for now.")],
      ephemeral: true,
    });
  }

  const voiceChannel = await requireVoiceChannel(interaction, settings);
  if (!voiceChannel) return;

  const permissions = voiceChannel.permissionsFor(interaction.guild.members.me);
  if (!permissions?.has(['Connect', 'Speak'])) {
    return interaction.reply({ embeds: [errorEmbed(settings, 'I need **Connect** and **Speak** permissions in that voice channel.')], ephemeral: true });
  }

  await interaction.deferReply();
  const player = useMainPlayer();
  const is247 = guildConfig.music?.twentyFourSeven?.enabled;

  let queued = 0;
  let failed = 0;
  for (const savedTrack of playlist.مقاطع) {
    try {
      await player.play(voiceChannel, savedTrack.url, {
        nodeOptions: {
          metadata: { channel: interaction.channel, requestedBy: interaction.user },
          volume: 70,
          leaveOnEmpty: !is247,
          leaveOnEmptyCooldown: 60_000,
          leaveOnEnd: !is247,
          leaveOnEndCooldown: 300_000,
          leaveOnStop: !is247,
          selfDeaf: true,
        },
        requestedBy: interaction.user,
      });
      queued += 1;
    } catch {
      failed += 1;
    }
  }

  const description =
    `🎼 Queued **${queued}** track${queued === 1 ? '' : 's'} from **${playlist.name}**` + (failed ? ` (${failed} failed to load).` : '.');
  return interaction.editReply({ embeds: [baseEmbed(settings).setDescription(description)] });
}
