const { SlashCommandBuilder } = require('discord.js');
const { getGuildConfig, resolved } = require('../utils/resolveGuildSettings');
const { successEmbed, errorEmbed, baseEmbed } = require('../utils/embeds');
const { requireActiveQueue } = require('../utils/musicChecks');
const { getKazagumo } = require('../services/lavalinkManager');

// discord-player's built-in FFmpeg filter presets. Not exhaustive (the
// underlying library supports more), but this covers the ones people
// actually ask for - keeps the choices list under Discord's 25-option cap.
// Kept as-is (including the entries with no Lavalink equivalent, see
// FILTER_PRESETS below) so guilds still running the discord-player
// fallback path see the exact same option list as before this task.
const FILTER_CHOICES = [
  { name: 'Bass Boost', value: 'bassboost' },
  { name: 'Nightcore', value: 'nightcore' },
  { name: 'Vaporwave', value: 'vaporwave' },
  { name: '8D', value: '8D' },
  { name: 'Karaoke', value: 'karaoke' },
  { name: 'Vibrato', value: 'vibrato' },
  { name: 'Tremolo', value: 'tremolo' },
  { name: 'Reverse', value: 'reverse' },
  { name: 'Treble', value: 'treble' },
  { name: 'Normalizer', value: 'normalizer' },
  { name: 'Surrounding', value: 'surrounding' },
  { name: 'Pulsator', value: 'pulsator' },
  { name: 'Subboost', value: 'subboost' },
  { name: 'Phaser', value: 'phaser' },
  { name: 'Flanger', value: 'flanger' },
  { name: 'Gate', value: 'gate' },
  { name: 'Haas', value: 'haas' },
  { name: 'Mcompand', value: 'mcompand' },
  { name: 'Lofi', value: 'lofi' },
  { name: 'Earrape', value: 'earrape' },
];

/**
 * Maps the filter names above to the raw Lavalink filter payload
 * (https://lavalink.dev/api/rest#filters) that reproduces them through
 * Kazagumo/Shoukaku. Lavalink filters aren't independent on/off switches
 * like discord-player's FFmpeg args are - they're just fields on a single
 * payload sent to the node (equalizer, timescale, rotation, ...), so
 * toggling on two presets that touch the *same* field (e.g. Bass Boost and
 * Subboost, both of which set `equalizer`) means whichever was toggled on
 * most recently wins for that field. That's an inherent Lavalink
 * limitation every Lavalink-based bot deals with, not a bug here.
 *
 * A handful of the FFmpeg-only entries above (Reverse, Normalizer, Phaser,
 * Flanger, Gate, Haas, Mcompand) have no real Lavalink filter equivalent -
 * Lavalink has no reverse/phaser/flanger/noise-gate/compressor filters -
 * so they're intentionally left out of this map. Toggling one of those
 * while running on Kazagumo replies with a clear "not available over
 * Lavalink" message instead of silently doing nothing or faking an effect.
 */
const FILTER_PRESETS = {
  bassboost: {
    equalizer: [
      { band: 0, gain: 0.6 }, { band: 1, gain: 0.7 }, { band: 2, gain: 0.8 },
      { band: 3, gain: 0.55 }, { band: 4, gain: 0.25 }, { band: 5, gain: 0 },
      { band: 6, gain: -0.25 }, { band: 7, gain: -0.25 }, { band: 8, gain: -0.25 },
      { band: 9, gain: -0.25 }, { band: 10, gain: -0.25 }, { band: 11, gain: -0.25 },
      { band: 12, gain: -0.25 }, { band: 13, gain: -0.25 },
    ],
  },
  subboost: {
    equalizer: [
      { band: 0, gain: 1.0 }, { band: 1, gain: 0.85 }, { band: 2, gain: 0.55 }, { band: 3, gain: 0.2 },
    ],
  },
  treble: {
    equalizer: [
      { band: 9, gain: 0.2 }, { band: 10, gain: 0.3 }, { band: 11, gain: 0.4 },
      { band: 12, gain: 0.45 }, { band: 13, gain: 0.5 },
    ],
  },
  nightcore: { timescale: { speed: 1.2, pitch: 1.2, rate: 1 } },
  vaporwave: { timescale: { speed: 0.8, pitch: 0.8, rate: 1 } },
  '8D': { rotation: { rotationHz: 0.2 } },
  surrounding: { rotation: { rotationHz: 0.08 } },
  karaoke: { karaoke: { level: 1.0, monoLevel: 1.0, filterBand: 220.0, filterWidth: 100.0 } },
  vibrato: { vibrato: { frequency: 4.0, depth: 0.7 } },
  tremolo: { tremolo: { frequency: 4.0, depth: 0.7 } },
  pulsator: { tremolo: { frequency: 8.0, depth: 0.9 } },
  lofi: {
    lowPass: { smoothing: 20.0 },
    equalizer: [{ band: 0, gain: 0.3 }, { band: 13, gain: -0.4 }],
  },
  earrape: {
    distortion: { sinOffset: 0, sinScale: 1, cosOffset: 0, cosScale: 1, tanOffset: 0, tanScale: 1, offset: 0, scale: 5 },
  },
};

module.exports = {
  data: new SlashCommandBuilder()
    .setName('filters')
    .setDescription('Toggle audio filters (bass boost, nightcore, 8D...) on the current track')
    .setDescriptionLocalizations({
      ar: 'تبديل الفلاتر الصوتية (باص بوست، نايت كور، 8D...) على المقطع الحالي',
      'en-US': 'Toggle audio filters (bass boost, nightcore, 8D...) on the current track',
    })
    .addSubcommand((s) =>
      s
        .setName('toggle')
        .setDescription('Enable or disable a filter')
        .setDescriptionLocalizations({ ar: 'تفعيل أو تعطيل فلتر', 'en-US': 'Enable or disable a filter' })
        .addStringOption((o) =>
          o
            .setName('filter')
            .setDescription('Filter to toggle')
            .setDescriptionLocalizations({ ar: 'الفلتر المراد تبديله', 'en-US': 'Filter to toggle' })
            .setRequired(true)
            .addChoices(...FILTER_CHOICES)
        )
    )
    .addSubcommand((s) =>
      s
        .setName('list')
        .setDescription('Show the currently active filters')
        .setDescriptionLocalizations({ ar: 'عرض الفلاتر المفعّلة حالياً', 'en-US': 'Show the currently active filters' })
    )
    .addSubcommand((s) =>
      s
        .setName('clear')
        .setDescription('Disable every active filter')
        .setDescriptionLocalizations({ ar: 'تعطيل جميع الفلاتر المفعّلة', 'en-US': 'Disable every active filter' })
    ),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    const sub = interaction.options.getSubcommand();

    // Migrated path: if this guild's queue is being run through
    // Kazagumo/Lavalink, apply filters through Lavalink's native filter
    // system instead of discord-player's FFmpeg filters.
    const kazagumo = getKazagumo();
    const kazagumoPlayer = kazagumo?.players.get(interaction.guildId);

    if (kazagumoPlayer && kazagumoPlayer.queue.current) {
      const memberChannel = interaction.member?.voice?.channel;
      if (!memberChannel || memberChannel.id !== kazagumoPlayer.voiceId) {
        return interaction.reply({
          embeds: [errorEmbed(settings, `انضم لـ <#${kazagumoPlayer.voiceId}> للتحكم بالموسيقى.`)],
          ephemeral: true,
        });
      }

      // Tracks which named presets are "on" for this player. Lives on the
      // KazagumoPlayer instance itself (mirrors how discord-player keeps
      // its FFmpeg filter state on the queue), so it naturally resets
      // whenever a fresh player is created for the guild.
      if (!kazagumoPlayer.novaActiveFilters) kazagumoPlayer.novaActiveFilters = new Set();
      const active = kazagumoPlayer.novaActiveFilters;

      if (sub === 'list') {
        const description = active.size ? [...active].map((f) => `\`${f}\``).join(', ') : '_No filters active right now._';
        return interaction.reply({ embeds: [baseEmbed(settings).setTitle('🎚️ Active Filters').setDescription(description)] });
      }

      if (sub === 'clear') {
        try {
          await kazagumoPlayer.shoukaku.clearFilters();
        } catch (err) {
          return interaction.reply({ embeds: [errorEmbed(settings, `Couldn't clear filters: ${err?.message || err}`)], ephemeral: true });
        }
        active.clear();
        return interaction.reply({ embeds: [successEmbed(settings, '🎚️ All audio filters cleared.')] });
      }

      // sub === 'toggle'
      const filter = interaction.options.getString('filter', true);

      if (!FILTER_PRESETS[filter]) {
        return interaction.reply({
          embeds: [errorEmbed(settings, `**${filter}** isn't available over Lavalink yet - try \`/filters list\` to see what's active, or pick another filter.`)],
          ephemeral: true,
        });
      }

      const wasActive = active.has(filter);
      if (wasActive) active.delete(filter);
      else active.add(filter);

      // Rebuild the combined filter payload from every preset that's
      // currently on, then push the whole thing to Lavalink in one call -
      // Lavalink's filter API replaces the entire payload each time, it
      // doesn't merge with whatever was set before.
      const combined = {};
      for (const name of active) Object.assign(combined, FILTER_PRESETS[name]);

      try {
        if (Object.keys(combined).length === 0) await kazagumoPlayer.shoukaku.clearFilters();
        else await kazagumoPlayer.shoukaku.setFilters(combined);
      } catch (err) {
        // Roll back the in-memory toggle so it stays in sync with what's
        // actually applied on the node.
        if (wasActive) active.add(filter);
        else active.delete(filter);
        return interaction.reply({ embeds: [errorEmbed(settings, `Couldn't apply that filter: ${err?.message || err}`)], ephemeral: true });
      }

      return interaction.reply({ embeds: [successEmbed(settings, `🎚️ **${filter}** is now **${wasActive ? 'disabled' : 'enabled'}**.`)] });
    }

    // Not migrated for this guild yet (no Kazagumo player, e.g. Lavalink
    // isn't configured, or this guild's queue predates it) - fall back to
    // the original discord-player path so behavior is unchanged from
    // before this task.
    const queue = await requireActiveQueue(interaction, settings);
    if (!queue) return;

    if (sub === 'list') {
      const active = queue.filters.ffmpeg.getFiltersEnabled();
      const description = active.length ? active.map((f) => `\`${f}\``).join(', ') : '_No filters active right now._';
      return interaction.reply({ embeds: [baseEmbed(settings).setTitle('🎚️ Active Filters').setDescription(description)] });
    }

    if (sub === 'clear') {
      try {
        await queue.filters.ffmpeg.setFilters(false);
      } catch (err) {
        return interaction.reply({ embeds: [errorEmbed(settings, `Couldn't clear filters: ${err?.message || err}`)], ephemeral: true });
      }
      return interaction.reply({ embeds: [successEmbed(settings, '🎚️ All audio filters cleared.')] });
    }

    // sub === 'toggle'
    const filter = interaction.options.getString('filter', true);
    const wasActive = queue.filters.ffmpeg.getFiltersEnabled().includes(filter);

    try {
      await queue.filters.ffmpeg.toggle([filter]);
    } catch (err) {
      return interaction.reply({ embeds: [errorEmbed(settings, `Couldn't apply that filter: ${err?.message || err}`)], ephemeral: true });
    }

    return interaction.reply({ embeds: [successEmbed(settings, `🎚️ **${filter}** is now **${wasActive ? 'disabled' : 'enabled'}**.`)] });
  },
};
