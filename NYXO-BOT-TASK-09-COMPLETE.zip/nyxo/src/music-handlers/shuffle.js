const { SlashCommandBuilder } = require('discord.js');
const { getGuildConfig, resolved } = require('../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../utils/embeds');
const { requireActiveQueue } = require('../utils/musicChecks');
const { getKazagumo } = require('../services/lavalinkManager');

module.exports = {
  data: new SlashCommandBuilder().setName('shuffle').setDescription('Shuffle the upcoming tracks in the queue')
    .setDescriptionLocalizations({ ar: 'خلط ترتيب المقاطع القادمة في القائمة', 'en-US': 'Shuffle the upcoming tracks in the queue' }),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    // Migrated path: if this guild's queue is being run through
    // Kazagumo/Lavalink, shuffle it that way. KazagumoQueue extends
    // Array and only holds the *upcoming* tracks (the current track
    // lives separately on .queue.current), matching what
    // queue.tracks.toArray() means on the discord-player side below.
    const kazagumo = getKazagumo();
    const kazagumoPlayer = kazagumo?.players.get(interaction.guildId);

    if (kazagumoPlayer && kazagumoPlayer.queue.current) {
      const memberChannel = interaction.member?.voice?.channel;
      if (!memberChannel || memberChannel.id !== kazagumoPlayer.voiceId) {
        return interaction.reply({
          embeds: [errorEmbed(settings, `انضم لـ <#${kazagumoPlayer.voiceId}> للتحكم بالموسيقى.`)],
          ephemeral: true,
        });
      }

      if (kazagumoPlayer.queue.length < 2) {
        return interaction.reply({ embeds: [errorEmbed(settings, 'لا توجد مقاطع كافية في القائمة للخلط.')], ephemeral: true });
      }

      kazagumoPlayer.queue.shuffle();
      return interaction.reply({ embeds: [successEmbed(settings, '🔀 تم خلط القائمة.')] });
    }

    // Not migrated for this guild yet (no Kazagumo player, e.g. Lavalink
    // isn't configured, or this guild's queue predates it) - fall back to
    // the original discord-player path so behavior is unchanged from
    // before this task.
    const queue = await requireActiveQueue(interaction, settings);
    if (!queue) return;

    if (queue.tracks.toArray().length < 2) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'لا توجد مقاطع كافية في القائمة للخلط.')], ephemeral: true });
    }

    queue.tracks.shuffle();
    return interaction.reply({ embeds: [successEmbed(settings, '🔀 تم خلط القائمة.')] });
  },
};
