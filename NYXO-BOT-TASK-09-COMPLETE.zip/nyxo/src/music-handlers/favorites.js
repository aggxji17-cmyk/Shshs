const { SlashCommandBuilder } = require('discord.js');
const { useMainPlayer, useQueue } = require('discord-player');
const { getGuildConfig, resolved } = require('../utils/resolveGuildSettings');
const { baseEmbed, successEmbed, errorEmbed } = require('../utils/embeds');
const { requireVoiceChannel } = require('../utils/musicChecks');
const { safeAutocomplete, fuzzyFilter } = require('../utils/autocomplete');
const favoritesService = require('../services/favoritesService');
const { guildIsOnKazagumo } = require('../services/lavalinkManager');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('favorites')
    .setDescription('Manage your favorite songs')
    .setDescriptionLocalizations({ ar: 'إدارة أغانيك المفضلة', 'en-US': 'Manage your favorite songs' })
    .addSubcommand((sc) =>
      sc
        .setName('add')
        .setDescription('Add a song to your favorites')
        .setDescriptionLocalizations({ ar: 'إضافة أغنية إلى المفضلة', 'en-US': 'Add a song to your favorites' })
        .addStringOption((o) =>
          o
            .setName('song')
            .setDescription('Song name, artist, or a link. Leave blank to use the track playing now')
            .setDescriptionLocalizations({ ar: 'اسم الأغنية أو الفنان أو رابط. اتركه فارغاً لاستخدام المقطع الذي يعمل حالياً', 'en-US': 'Song name, artist, or a link. Leave blank to use the track playing now' })
        )
    )
    .addSubcommand((sc) =>
      sc
        .setName('remove')
        .setDescription('Remove a song from your favorites')
        .setDescriptionLocalizations({ ar: 'إزالة أغنية من المفضلة', 'en-US': 'Remove a song from your favorites' })
        .addIntegerOption((o) =>
          o.setName('position').setDescription('Track position (see /favorites list)').setDescriptionLocalizations({ ar: 'ترتيب المقطع (انظر /favorites list)', 'en-US': 'Track position (see /favorites list)' }).setRequired(true).setAutocomplete(true)
        )
    )
    .addSubcommand((sc) =>
      sc
        .setName('list')
        .setDescription('Show your favorite songs')
        .setDescriptionLocalizations({ ar: 'عرض أغانيك المفضلة', 'en-US': 'Show your favorite songs' })
    )
    .addSubcommand((sc) =>
      sc
        .setName('clear')
        .setDescription('Remove every song from your favorites')
        .setDescriptionLocalizations({ ar: 'حذف جميع الأغاني من المفضلة', 'en-US': 'Remove every song from your favorites' })
    )
    .addSubcommand((sc) =>
      sc
        .setName('play')
        .setDescription('Queue all your favorite songs in your voice channel')
        .setDescriptionLocalizations({ ar: 'تشغيل كل أغانيك المفضلة في القناة الصوتية', 'en-US': 'Queue all your favorite songs in your voice channel' })
    ),

  autocomplete: safeAutocomplete(async (interaction) => {
    const focused = interaction.options.getFocused(true);
    if (focused.name !== 'position') return [];

    const tracks = await favoritesService.getFavorites(interaction.user.id);
    const items = tracks.map((t, i) => ({ index: i, title: t.title }));
    const matched = fuzzyFilter(items, String(focused.value), { key: (t) => t.title });
    return matched.map((t) => ({ name: `${t.index + 1}. ${t.title}`, value: t.index + 1 }));
  }),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    const sub = interaction.options.getSubcommand();

    if (sub === 'add') return handleAdd(interaction, settings);
    if (sub === 'remove') return handleRemove(interaction, settings);
    if (sub === 'list') return handleList(interaction, settings);
    if (sub === 'clear') return handleClear(interaction, settings);
    if (sub === 'play') return handlePlay(interaction, settings, guildConfig);
  },
};

async function handleAdd(interaction, settings) {
  let song = interaction.options.getString('song');

  if (!song) {
    const queue = useQueue(interaction.guildId);
    if (!queue || !queue.currentTrack) {
      return interaction.reply({
        embeds: [errorEmbed(settings, 'لا يوجد شيء يعمل حالياً. أعطني اسم أغنية عبر `/favorites add song:`.')],
        ephemeral: true,
      });
    }
    const { track, error } = await favoritesService.addTrackData(interaction.user.id, favoritesService.toTrackData(queue.currentTrack));
    if (error) return interaction.reply({ embeds: [errorEmbed(settings, error)], ephemeral: true });
    return interaction.reply({ embeds: [successEmbed(settings, `❤️ تمت إضافة **[${track.title}](${track.url})** إلى مفضلتك.`)] });
  }

  await interaction.deferReply();
  const { track, error } = await favoritesService.addFavorite(interaction.user.id, song, interaction.user);
  if (error) return interaction.editReply({ embeds: [errorEmbed(settings, error)] });
  return interaction.editReply({ embeds: [successEmbed(settings, `❤️ تمت إضافة **[${track.title}](${track.url})** إلى مفضلتك.`)] });
}

async function handleRemove(interaction, settings) {
  const position = interaction.options.getInteger('position', true);
  const { removed, error } = await favoritesService.removeFavorite(interaction.user.id, position - 1);
  if (error) return interaction.reply({ embeds: [errorEmbed(settings, error)], ephemeral: true });
  return interaction.reply({ embeds: [successEmbed(settings, `تمت إزالة **${removed.title}** من مفضلتك.`)] });
}

async function handleList(interaction, settings) {
  const tracks = await favoritesService.getFavorites(interaction.user.id);
  if (!tracks.length) {
    return interaction.reply({ embeds: [errorEmbed(settings, "You don't have any favorite songs yet. Add one with `/favorites add`.")], ephemeral: true });
  }

  const lines = tracks.slice(0, 25).map((t, i) => `**${i + 1}.** [${t.title}](${t.url})${t.duration ? ` \`${t.duration}\`` : ''}`);
  if (tracks.length > 25) lines.push(`*...and ${tracks.length - 25} more.*`);

  const embed = baseEmbed(settings)
    .setTitle(`❤️ ${interaction.user.username}'s Favorite Songs`)
    .setDescription(lines.join('\n'))
    .setThumbnail(tracks[0].thumbnail || null)
    .setFooter({ text: `${settings.footer} • ${tracks.length} track${tracks.length === 1 ? '' : 's'}` });

  return interaction.reply({ embeds: [embed] });
}

async function handleClear(interaction, settings) {
  const { count } = await favoritesService.clearFavorites(interaction.user.id);
  if (!count) return interaction.reply({ embeds: [errorEmbed(settings, "You don't have any favorite songs to clear.")], ephemeral: true });
  return interaction.reply({ embeds: [successEmbed(settings, `Cleared **${count}** song${count === 1 ? '' : 's'} from your favorites.`)] });
}

async function handlePlay(interaction, settings, guildConfig) {
  const tracks = await favoritesService.getFavorites(interaction.user.id);
  if (!tracks.length) {
    return interaction.reply({ embeds: [errorEmbed(settings, "You don't have any favorite songs yet. Add one with `/favorites add`.")], ephemeral: true });
  }

  if (guildIsOnKazagumo(interaction.guildId)) {
    return interaction.reply({
      embeds: [errorEmbed(settings, "This server's current music session is running on the Lavalink engine, which `/favorites play` doesn't support yet. Use `/play` with individual tracks for now.")],
      ephemeral: true,
    });
  }

  const voiceChannel = await requireVoiceChannel(interaction, settings);
  if (!voiceChannel) return;

  const permissions = voiceChannel.permissionsFor(interaction.guild.members.me);
  if (!permissions?.has(['Connect', 'Speak'])) {
    return interaction.reply({ embeds: [errorEmbed(settings, 'I need **Connect** and **Speak** permissions in that voice channel.')], ephemeral: true });
  }

  await interaction.deferReply();
  const player = useMainPlayer();
  const is247 = guildConfig.music?.twentyFourSeven?.enabled;

  let queued = 0;
  let failed = 0;
  for (const savedTrack of tracks) {
    try {
      await player.play(voiceChannel, savedTrack.url, {
        nodeOptions: {
          metadata: { channel: interaction.channel, requestedBy: interaction.user },
          volume: 70,
          leaveOnEmpty: !is247,
          leaveOnEmptyCooldown: 60_000,
          leaveOnEnd: !is247,
          leaveOnEndCooldown: 300_000,
          leaveOnStop: !is247,
          selfDeaf: true,
        },
        requestedBy: interaction.user,
      });
      queued += 1;
    } catch {
      failed += 1;
    }
  }

  const description = `❤️ Queued **${queued}** favorite${queued === 1 ? '' : 's'}` + (failed ? ` (${failed} failed to load).` : '.');
  return interaction.editReply({ embeds: [baseEmbed(settings).setDescription(description)] });
}
