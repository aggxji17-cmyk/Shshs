const { SlashCommandBuilder } = require('discord.js');
const { getGuildConfig, resolved } = require('../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../utils/embeds');
const { requireActiveQueue } = require('../utils/musicChecks');
const { getKazagumo } = require('../services/lavalinkManager');

module.exports = {
  data: new SlashCommandBuilder().setName('resume').setDescription('Resume the currently paused track')
    .setDescriptionLocalizations({ ar: 'استئناف تشغيل المقطع المتوقف', 'en-US': 'Resume the currently paused track' }),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    // Migrated path: if this guild's queue is being run through
    // Kazagumo/Lavalink, resume it that way.
    const kazagumo = getKazagumo();
    const kazagumoPlayer = kazagumo?.players.get(interaction.guildId);

    if (kazagumoPlayer && kazagumoPlayer.queue.current) {
      const memberChannel = interaction.member?.voice?.channel;
      if (!memberChannel || memberChannel.id !== kazagumoPlayer.voiceId) {
        return interaction.reply({
          embeds: [errorEmbed(settings, `انضم لـ <#${kazagumoPlayer.voiceId}> للتحكم بالموسيقى.`)],
          ephemeral: true,
        });
      }

      if (!kazagumoPlayer.paused) {
        return interaction.reply({ embeds: [errorEmbed(settings, 'Playback is not paused.')], ephemeral: true });
      }

      kazagumoPlayer.pause(false);
      return interaction.reply({ embeds: [successEmbed(settings, `▶️ تم استئناف **${kazagumoPlayer.queue.current.title}**.`)] });
    }

    // Not migrated for this guild yet (no Kazagumo player, e.g. Lavalink
    // isn't configured, or this guild's queue predates it) - fall back to
    // the original discord-player path so behavior is unchanged from
    // before this task.
    const queue = await requireActiveQueue(interaction, settings);
    if (!queue) return;

    if (!queue.node.isPaused()) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'Playback is not paused.')], ephemeral: true });
    }

    queue.node.setPaused(false);
    if (queue.metadata) queue.metadata.autoPausedForEmpty = false;
    return interaction.reply({ embeds: [successEmbed(settings, `▶️ تم استئناف **${queue.currentTrack.title}**.`)] });
  },
};
