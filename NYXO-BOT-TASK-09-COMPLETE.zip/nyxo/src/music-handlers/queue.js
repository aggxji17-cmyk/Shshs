const { SlashCommandBuilder } = require('discord.js');
const { useQueue } = require('discord-player');
const { getGuildConfig, resolved } = require('../utils/resolveGuildSettings');
const { errorEmbed } = require('../utils/embeds');
const { buildQueuePage } = require('../utils/musicQueueEmbed');
const { getKazagumo } = require('../services/lavalinkManager');

const LOOP_TO_REPEAT_MODE = { none: 0, track: 1, queue: 2 };

/** Mirrors the private formatDuration() in utils/musicQueueEmbed.js so Kazagumo tracks render identically to discord-player ones. */
function formatDuration(ms) {
  if (!ms || ms <= 0) return null;
  const totalSeconds = Math.floor(ms / 1000);
  const h = Math.floor(totalSeconds / 3600);
  const m = Math.floor((totalSeconds % 3600) / 60);
  const s = totalSeconds % 60;
  const pad = (n) => String(n).padStart(2, '0');
  return h > 0 ? `${h}:${pad(m)}:${pad(s)}` : `${m}:${pad(s)}`;
}

/** Reshapes a KazagumoTrack into the plain {title,url,duration,durationMS,requestedBy} shape buildQueuePage() already expects from discord-player. */
function toDisplayTrack(kazagumoTrack) {
  return {
    title: kazagumoTrack.title,
    url: kazagumoTrack.uri,
    duration: kazagumoTrack.isStream ? 'Live' : formatDuration(kazagumoTrack.length),
    durationMS: kazagumoTrack.length || 0,
    requestedBy: kazagumoTrack.requester,
  };
}

/**
 * Builds a discord-player-shaped "queue" view backed by Kazagumo data, so
 * the existing buildQueuePage() renderer (shared with the queue
 * pagination/clear buttons) doesn't need to know which engine is behind
 * it.
 */
function buildKazagumoQueueView(kazagumoPlayer) {
  const upcoming = [...kazagumoPlayer.queue].map(toDisplayTrack);

  return {
    currentTrack: kazagumoPlayer.queue.current ? toDisplayTrack(kazagumoPlayer.queue.current) : null,
    tracks: { toArray: () => upcoming },
    repeatMode: LOOP_TO_REPEAT_MODE[kazagumoPlayer.loop] ?? 0,
    node: { volume: kazagumoPlayer.volume ?? 100 },
  };
}

module.exports = {
  buildKazagumoQueueView,
  data: new SlashCommandBuilder()
    .setName('queue')
    .setDescription('Show the current music queue')
    .setDescriptionLocalizations({ ar: 'عرض قائمة انتظار التشغيل الحالية', 'en-US': 'Show the current music queue' })
    .addIntegerOption((o) => o.setName('page').setDescription('Page number').setDescriptionLocalizations({ ar: 'رقم الصفحة', 'en-US': 'Page number' }).setMinValue(1)),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    const requestedPage = interaction.options.getInteger('page') || 1;

    // Migrated path: this guild's queue is being run through
    // Kazagumo/Lavalink - render it from Kazagumo's player/queue data.
    const kazagumo = getKazagumo();
    const kazagumoPlayer = kazagumo?.players.get(interaction.guildId);

    if (kazagumoPlayer && kazagumoPlayer.queue.current) {
      const queueView = buildKazagumoQueueView(kazagumoPlayer);
      const { embed, components } = buildQueuePage(queueView, settings, requestedPage);
      return interaction.reply({ embeds: [embed], components });
    }

    // Not migrated for this guild yet (no Kazagumo player - e.g. Lavalink
    // isn't configured, or this guild's queue predates it) - fall back to
    // the original discord-player path so behavior is unchanged from
    // before this task.
    const queue = useQueue(interaction.guildId);
    if (!queue || !queue.currentTrack) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'لا يوجد شيء يعمل حالياً.')], ephemeral: true });
    }

    const { embed, components } = buildQueuePage(queue, settings, requestedPage);
    return interaction.reply({ embeds: [embed], components });
  },
};
