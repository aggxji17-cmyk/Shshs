const { SlashCommandBuilder } = require('discord.js');
const { QueueRepeatMode } = require('discord-player');
const { getGuildConfig, resolved } = require('../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../utils/embeds');
const { requireActiveQueue } = require('../utils/musicChecks');
const { getKazagumo } = require('../services/lavalinkManager');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('autoplay')
    .setDescription('Toggle autoplay - keeps playing similar tracks once the queue ends')
    .setDescriptionLocalizations({
      ar: 'تبديل التشغيل التلقائي - يشغّل مقاطع مشابهة عند انتهاء القائمة',
      'en-US': 'Toggle autoplay - keeps playing similar tracks once the queue ends',
    }),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    // Migrated guilds: Lavalink/Kazagumo has no built-in "play similar
    // tracks when the queue ends" feature (that's a discord-player
    // extractor feature with no Lavalink equivalent), so this reports it
    // clearly instead of toggling a flag that would silently do nothing -
    // same approach filters.js uses for FFmpeg-only presets.
    const kazagumo = getKazagumo();
    const kazagumoPlayer = kazagumo?.players.get(interaction.guildId);

    if (kazagumoPlayer && kazagumoPlayer.queue.current) {
      return interaction.reply({
        embeds: [errorEmbed(settings, "**Autoplay** غير متاح عبر Lavalink بعد.")],
        ephemeral: true,
      });
    }

    const queue = await requireActiveQueue(interaction, settings);
    if (!queue) return;

    // Autoplay is just QueueRepeatMode.AUTOPLAY under the hood (same field
    // /loop sets), so toggling it off falls back to OFF rather than
    // whatever loop mode happened to be active before.
    const enabling = queue.repeatMode !== QueueRepeatMode.AUTOPLAY;
    queue.setRepeatMode(enabling ? QueueRepeatMode.AUTOPLAY : QueueRepeatMode.OFF);

    return interaction.reply({
      embeds: [
        successEmbed(
          settings,
          enabling
            ? '🔄 التشغيل التلقائي **مفعّل** — ستعمل مقاطع مشابهة عند انتهاء القائمة.'
            : '🔄 التشغيل التلقائي **معطّل**.'
        ),
      ],
    });
  },
};
