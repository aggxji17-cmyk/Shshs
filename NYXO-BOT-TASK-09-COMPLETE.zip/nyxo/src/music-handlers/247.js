const { SlashCommandBuilder, ChannelType } = require('discord.js');
const { useMainPlayer, useQueue } = require('discord-player');
const { getGuildConfig, resolved, invalidateGuildConfig } = require('../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../utils/embeds');
const { isGuildManager } = require('../utils/permissions');
const { guildIsOnKazagumo } = require('../services/lavalinkManager');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('247')
    .setDescription('Toggle 24/7 mode - the bot stays connected to a voice channel and never auto-leaves')
    .setDescriptionLocalizations({
      ar: 'تبديل وضع 24/7 - يبقى البوت متصلاً بالقناة الصوتية ولا يغادر تلقائياً',
      'en-US': 'Toggle 24/7 mode - the bot stays connected to a voice channel and never auto-leaves',
    })
    .addChannelOption((o) =>
      o
        .setName('channel')
        .setDescription('Voice channel to stay connected to (defaults to your current one)')
        .setDescriptionLocalizations({ ar: 'القناة الصوتية للبقاء متصلاً بها (افتراضياً قناتك الحالية)', 'en-US': 'Voice channel to stay connected to (defaults to your current one)' })
        .addChannelTypes(ChannelType.GuildVoice, ChannelType.GuildStageVoice)
    ),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر لاستخدام هذا الأمر.')], ephemeral: true });
    }

    const alreadyOn = guildConfig.music.twentyFourSeven.enabled;

    // Turning it off: just flip the flag and let the queue's normal
    // leaveOnEmpty/leaveOnEnd behavior (restored on its *next* creation -
    // see /commands/music/play.js) take back over. We don't force-
    // disconnect an active session; if people are still listening it
    // should keep playing until they finish or stop it themselves.
    if (alreadyOn) {
      guildConfig.music.twentyFourSeven.enabled = false;
      guildConfig.music.twentyFourSeven.voiceChannelId = null;
      guildConfig.music.twentyFourSeven.textChannelId = null;
      await guildConfig.save();
      invalidateGuildConfig(interaction.guildId);

      const queue = useQueue(interaction.guildId);
      if (queue && queue.options) {
        queue.options.leaveOnEmpty = true;
        queue.options.leaveOnEnd = true;
        queue.options.leaveOnStop = true;
      }

      return interaction.reply({ embeds: [successEmbed(settings, '🌙 وضع 24/7 **معطّل** الآن.')] });
    }

    const channel = interaction.options.getChannel('channel') || interaction.member?.voice?.channel;
    if (!channel) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'انضم لقناة صوتية أولاً، أو حدد واحدة عبر خيار `channel`.')], ephemeral: true });
    }

    const permissions = channel.permissionsFor(interaction.guild.members.me);
    if (!permissions?.has(['Connect', 'Speak'])) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'البوت يحتاج صلاحيتي **الاتصال** و**التحدث** في تلك القناة.')], ephemeral: true });
    }

    if (guildIsOnKazagumo(interaction.guildId)) {
      return interaction.reply({
        embeds: [errorEmbed(settings, "جلسة الموسيقى الحالية تعمل على Lavalink الذي لا يدعم وضع 24/7 بعد. أوقف الجلسة الحالية أولاً إن أردت التبديل.")],
        ephemeral: true,
      });
    }

    await interaction.deferReply();

    const player = useMainPlayer();
    let queue = useQueue(interaction.guildId);

    try {
      if (!queue) {
        queue = player.nodes.create(interaction.guild, {
          metadata: { channel: interaction.channel },
          selfDeaf: true,
          volume: 70,
          leaveOnEmpty: false,
          leaveOnEmptyCooldown: 60_000,
          leaveOnEnd: false,
          leaveOnEndCooldown: 300_000,
          leaveOnStop: false,
        });
      } else if (queue.options) {
        // Queue already exists (music is playing) - flip its live leave
        // behavior instead of recreating it, so playback isn't interrupted.
        queue.options.leaveOnEmpty = false;
        queue.options.leaveOnEnd = false;
        queue.options.leaveOnStop = false;
      }

      if (!queue.connection) {
        await queue.connect(channel);
      }
    } catch (err) {
      return interaction.editReply({ embeds: [errorEmbed(settings, `فشل الاتصال بالقناة الصوتية: ${err?.message || err}`)] });
    }

    guildConfig.music.twentyFourSeven.enabled = true;
    guildConfig.music.twentyFourSeven.voiceChannelId = channel.id;
    guildConfig.music.twentyFourSeven.textChannelId = interaction.channel.id;
    await guildConfig.save();
    invalidateGuildConfig(interaction.guildId);

    return interaction.editReply({ embeds: [successEmbed(settings, `🌙 وضع 24/7 **مفعّل** الآن في ${channel}. لن يغادر البوت عند فراغ القناة أو انتهاء القائمة.`)] });
  },
};
