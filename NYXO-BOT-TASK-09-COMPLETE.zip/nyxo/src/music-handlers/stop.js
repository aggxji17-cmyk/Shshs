const { SlashCommandBuilder } = require('discord.js');
const { getGuildConfig, resolved } = require('../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../utils/embeds');
const { requireActiveQueue } = require('../utils/musicChecks');
const { getKazagumo } = require('../services/lavalinkManager');

module.exports = {
  data: new SlashCommandBuilder().setName('stop').setDescription('Stop playback, clear the queue, and leave the voice channel')
    .setDescriptionLocalizations({ ar: 'إيقاف التشغيل ومسح القائمة ومغادرة القناة الصوتية', 'en-US': 'Stop playback, clear the queue, and leave the voice channel' }),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    // Migrated path: if this guild's queue is being run through
    // Kazagumo/Lavalink, stop it that way.
    const kazagumo = getKazagumo();
    const kazagumoPlayer = kazagumo?.players.get(interaction.guildId);

    if (kazagumoPlayer && kazagumoPlayer.queue.current) {
      const memberChannel = interaction.member?.voice?.channel;
      if (!memberChannel || memberChannel.id !== kazagumoPlayer.voiceId) {
        return interaction.reply({
          embeds: [errorEmbed(settings, `انضم لـ <#${kazagumoPlayer.voiceId}> للتحكم بالموسيقى.`)],
          ephemeral: true,
        });
      }

      try {
        await kazagumoPlayer.destroy();
      } catch (err) {
        return interaction.reply({ embeds: [errorEmbed(settings, `فشل إيقاف التشغيل: ${err?.message || err}`)], ephemeral: true });
      }

      return interaction.reply({ embeds: [successEmbed(settings, '⏹️ تم إيقاف التشغيل ومسح القائمة.')] });
    }

    // Not migrated for this guild yet (no Kazagumo player, e.g. Lavalink
    // isn't configured, or this guild's queue predates it) - fall back to
    // the original discord-player path so behavior is unchanged from
    // before this task.
    const queue = await requireActiveQueue(interaction, settings);
    if (!queue) return;

    queue.delete();

    return interaction.reply({ embeds: [successEmbed(settings, '⏹️ تم إيقاف التشغيل ومسح القائمة.')] });
  },
};
