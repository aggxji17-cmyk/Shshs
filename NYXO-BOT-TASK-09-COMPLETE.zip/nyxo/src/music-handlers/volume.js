const { SlashCommandBuilder } = require('discord.js');
const { getGuildConfig, resolved } = require('../utils/resolveGuildSettings');
const { successEmbed, baseEmbed, errorEmbed } = require('../utils/embeds');
const { requireActiveQueue } = require('../utils/musicChecks');
const { getKazagumo } = require('../services/lavalinkManager');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('volume')
    .setDescription('Set or view the playback volume')
    .setDescriptionLocalizations({ ar: 'تعيين أو عرض مستوى الصوت', 'en-US': 'Set or view the playback volume' })
    .addIntegerOption((o) => o.setName('percent').setDescription('Volume percentage (0-100)').setDescriptionLocalizations({ ar: 'نسبة مستوى الصوت (0-100)', 'en-US': 'Volume percentage (0-100)' }).setMinValue(0).setMaxValue(100)),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    // Migrated path: if this guild's queue is being run through
    // Kazagumo/Lavalink, control its volume that way.
    const kazagumo = getKazagumo();
    const kazagumoPlayer = kazagumo?.players.get(interaction.guildId);

    if (kazagumoPlayer && kazagumoPlayer.queue.current) {
      const memberChannel = interaction.member?.voice?.channel;
      if (!memberChannel || memberChannel.id !== kazagumoPlayer.voiceId) {
        return interaction.reply({
          embeds: [errorEmbed(settings, `انضم لـ <#${kazagumoPlayer.voiceId}> للتحكم بالموسيقى.`)],
          ephemeral: true,
        });
      }

      const percent = interaction.options.getInteger('percent');
      if (percent === null) {
        return interaction.reply({ embeds: [baseEmbed(settings).setDescription(`🔊 مستوى الصوت الحالي: **${kazagumoPlayer.volume}%**.`)] });
      }

      try {
        await kazagumoPlayer.setVolume(percent);
      } catch (err) {
        return interaction.reply({ embeds: [errorEmbed(settings, `Couldn't set the volume: ${err?.message || err}`)], ephemeral: true });
      }

      return interaction.reply({ embeds: [successEmbed(settings, `🔊 تم ضبط الصوت على **${percent}%**.`)] });
    }

    // Not migrated for this guild yet (no Kazagumo player, e.g. Lavalink
    // isn't configured, or this guild's queue predates it) - fall back to
    // the original discord-player path so behavior is unchanged from
    // before this task.
    const queue = await requireActiveQueue(interaction, settings);
    if (!queue) return;

    const percent = interaction.options.getInteger('percent');
    if (percent === null) {
      return interaction.reply({ embeds: [baseEmbed(settings).setDescription(`🔊 مستوى الصوت الحالي: **${queue.node.volume}%**.`)] });
    }

    queue.node.setVolume(percent);
    return interaction.reply({ embeds: [successEmbed(settings, `🔊 تم ضبط الصوت على **${percent}%**.`)] });
  },
};
