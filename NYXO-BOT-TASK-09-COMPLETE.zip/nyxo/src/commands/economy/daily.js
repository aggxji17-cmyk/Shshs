const { SlashCommandBuilder } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { claimDaily } = require('../../services/economyService');

module.exports = {
  data: new SlashCommandBuilder().setName('daily').setDescription('Claim your daily currency reward')
    .setDescriptionLocalizations({ ar: 'استلام المكافأة اليومية من العملة', 'en-US': 'Claim your daily currency reward' }),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!guildConfig.economy?.enabled) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'نظام الاقتصاد غير مفعّل في هذا السيرفر.')], ephemeral: true });
    }

    const result = await claimDaily(interaction.guildId, interaction.user.id, guildConfig.economy.dailyAmount);

    if (!result.success) {
      const hours = Math.floor(result.remainingMs / 3600000);
      const minutes = Math.floor((result.remainingMs % 3600000) / 60000);
      return interaction.reply({ embeds: [errorEmbed(settings, `You already claimed your daily reward. Try again in **${hours}h ${minutes}m**.`)], ephemeral: true });
    }

    return interaction.reply({
      embeds: [successEmbed(settings, `You claimed **${result.amount}** ${guildConfig.economy.currencySymbol}! New balance: **${result.balance}**.`)],
    });
  },
};
