const { SlashCommandBuilder } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { transfer } = require('../../services/economyService');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('pay')
    .setDescription('Send currency to another member')
    .setDescriptionLocalizations({ ar: 'إرسال عملة إلى عضو آخر', 'en-US': 'Send currency to another member' })
    .addUserOption((o) => o.setName('user').setDescription('Recipient').setDescriptionLocalizations({ ar: 'المستلم', 'en-US': 'Recipient' }).setRequired(true))
    .addIntegerOption((o) => o.setName('amount').setDescription('Amount to send').setDescriptionLocalizations({ ar: 'المبلغ المراد إرساله', 'en-US': 'Amount to send' }).setRequired(true).setMinValue(1)),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!guildConfig.economy?.enabled) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'نظام الاقتصاد غير مفعّل في هذا السيرفر.')], ephemeral: true });
    }

    const target = interaction.options.getUser('user');
    const amount = interaction.options.getInteger('amount');

    if (target.id === interaction.user.id) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'لا يمكنك الدفع لنفسك.')], ephemeral: true });
    }
    if (target.bot) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'لا يمكنك الدفع لبوت.')], ephemeral: true });
    }

    const result = await transfer(interaction.guildId, interaction.user.id, target.id, amount);
    if (!result.success) {
      return interaction.reply({ embeds: [errorEmbed(settings, result.reason)], ephemeral: true });
    }

    return interaction.reply({
      embeds: [successEmbed(settings, `You sent **${amount}** ${guildConfig.economy.currencySymbol} to **${target.tag}**.`)],
    });
  },
};
