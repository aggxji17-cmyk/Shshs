const { SlashCommandBuilder } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { claimWork } = require('../../services/economyService');

module.exports = {
  data: new SlashCommandBuilder().setName('work').setDescription('Work a shift to earn currency')
    .setDescriptionLocalizations({ ar: 'العمل لكسب العملة', 'en-US': 'Work a shift to earn currency' }),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!guildConfig.economy?.enabled) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'نظام الاقتصاد غير مفعّل في هذا السيرفر.')], ephemeral: true });
    }

    const { economy } = guildConfig;
    const result = await claimWork(interaction.guildId, interaction.user.id, economy.workMin, economy.workMax, economy.workCooldownMinutes);

    if (!result.success) {
      const minutes = Math.ceil(result.remainingMs / 60000);
      return interaction.reply({ embeds: [errorEmbed(settings, `You're still on cooldown. Try again in **${minutes}** minute(s).`)], ephemeral: true });
    }

    return interaction.reply({
      embeds: [successEmbed(settings, `You worked and earned **${result.amount}** ${economy.currencySymbol}! New balance: **${result.balance}**.`)],
    });
  },
};
