const { SlashCommandBuilder, AttachmentBuilder } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { baseEmbed, errorEmbed } = require('../../utils/embeds');
const { getLeaderboard, getLevelProgress, getGuildUserCount, getRank } = require('../../services/levelingService');
const { renderLeaderboardCard } = require('../../services/levelCardService');
const logger = require('../../utils/logger');

const PAGE_SIZE = 10;

module.exports = {
  data: new SlashCommandBuilder()
    .setName('leaderboard')
    .setDescription('View the server XP leaderboard')
    .setDescriptionLocalizations({ ar: 'عرض قائمة متصدري نقاط الخبرة في السيرفر', 'en-US': 'View the server XP leaderboard' })
    .addIntegerOption((o) =>
      o
        .setName('page')
        .setDescription('Page number (10 members per page)')
        .setDescriptionLocalizations({ ar: 'رقم الصفحة (10 أعضاء لكل صفحة)', 'en-US': 'Page number (10 members per page)' })
        .setMinValue(1)
    ),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!guildConfig.leveling.enabled) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'نظام المستويات معطّل في هذا السيرفر.')], ephemeral: true });
    }

    const page = interaction.options.getInteger('page') || 1;
    const skip = (page - 1) * PAGE_SIZE;

    // TASK16 (leveling): sorting/pagination happens entirely in MongoDB
    // (getLeaderboard uses .sort().skip().limit() against the
    // { guildId: 1, xp: -1 } index) - the full member list is never
    // pulled into Node just to be sorted here.
    const top = await getLeaderboard(interaction.guildId, PAGE_SIZE, skip);
    if (!top.length) {
      const message = page > 1 ? 'لا يوجد أعضاء في هذه الصفحة.' : 'لم يكسب أحد XP بعد.';
      return interaction.reply({ embeds: [errorEmbed(settings, message)] });
    }

    await interaction.deferReply();

    // TASK17 audit: level here must come from getLevelProgress(doc.xp)
    // (same fix as /rank) rather than the raw doc.level field, so the
    // level number shown always agrees with the progress bar computed
    // from that same doc.xp - see the comment in commands/leveling/rank.js
    // for why doc.level can otherwise lag behind under concurrent grants.
    const entries = top.map((doc, i) => {
      const progress = getLevelProgress(doc.xp);
      return {
        rank: skip + i + 1,
        userId: doc.userId,
        level: progress.level,
        totalXp: doc.xp,
        progressPercent: progress.progressPercent,
      };
    });

    // Resolve display names/avatars for this page only (max 10 fetches),
    // falling back to the raw user ID if a member has left the server.
    // TASK20: prefers the guild nickname (member.displayName) over the
    // bare account username, same as /rank - member.displayName already
    // falls back to the username itself when no nickname is set, so this
    // is a pure improvement with no extra fallback branch needed here.
    for (const entry of entries) {
      // eslint-disable-next-line no-await-in-loop
      const member = await interaction.guild.members.fetch(entry.userId).catch(() => null);
      entry.username = member?.displayName || member?.user?.username || `User ${entry.userId}`;
      entry.avatarURL = member?.user?.displayAvatarURL({ extension: 'png', size: 128 });
    }

    // TASK25: "Your rank" convenience line for whoever ran the command,
    // matching the reference leaderboard's per-user "Rank: N" idea
    // without needing them to page through to find themselves. Only
    // shown when they're NOT already visible on this page (otherwise
    // it would just repeat a row already on screen) and only when
    // they've earned XP at all (getRank returns null otherwise - same
    // "no XP yet" case /rank already handles). This is plain text sent
    // alongside the existing image/embed reply - it doesn't touch
    // rendering in levelCardService.js at all.
    let viewerRankLine = null;
    if (!entries.some((e) => e.userId === interaction.user.id)) {
      const viewerResult = await getRank(interaction.guildId, interaction.user.id);
      if (viewerResult) {
        const viewerProgress = getLevelProgress(viewerResult.doc.xp);
        viewerRankLine = `Your rank: **#${viewerResult.rank}** • Level **${viewerProgress.level}** (${viewerProgress.totalXp.toLocaleString()} XP)`;
      }
    }

    // TASK19: same guildConfig.leveling.card opt-out/theme settings as
    // /rank - see the comment in commands/leveling/rank.js.
    const card = guildConfig.leveling.card || {};
    if (card.enabled !== false) {
      try {
        const totalMembers = await getGuildUserCount(interaction.guildId);
        const totalPages = Math.max(1, Math.ceil(totalMembers / PAGE_SIZE));
        const buffer = await renderLeaderboardCard({
          guildName: interaction.guild.name,
          entries,
          accentColor: card.accentColor || settings.embedColor,
          theme: card.theme,
          page,
          totalPages,
        });
        const attachment = new AttachmentBuilder(buffer, { name: 'leaderboard.png' });
        return await interaction.editReply({ content: viewerRankLine || undefined, files: [attachment] });
      } catch (err) {
        logger.error(`/leaderboard card render failed for guild ${interaction.guildId}: ${err?.stack || err}`);
      }
    }

    const medals = ['🥇', '🥈', '🥉'];
    const description = entries
      .map((e) => `${medals[e.rank - 1] || `**${e.rank}.**`} <@${e.userId}> - Level ${e.level} (${e.totalXp} XP)`)
      .join('\n');

    // TASK28: page indicator was already drawn on the image card
    // (renderLeaderboardCard's header) but silently missing from this
    // plain-text fallback, so paging here looked identical page to page
    // if the image failed to render. Only computed/shown when there's
    // more than one page, same "don't add noise" rule as /rank's new
    // multiplier field.
    const totalMembers = await getGuildUserCount(interaction.guildId);
    const totalPages = Math.max(1, Math.ceil(totalMembers / PAGE_SIZE));
    const fallbackEmbed = baseEmbed(settings).setTitle('🏆 XP Leaderboard').setDescription(description);
    if (totalPages > 1) {
      fallbackEmbed.setFooter({ text: `Page ${page} / ${totalPages}` });
    }

    return interaction.editReply({
      content: viewerRankLine || undefined,
      embeds: [fallbackEmbed],
    });
  },
};
