const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved, invalidateGuildConfig } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed, baseEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');

/**
 * TASK18 (Leveling / Level Rewards)
 * ---------------------------------------------------------------------
 * Manages GuildConfig.leveling.rewards - the level -> role mappings that
 * events/message/messageCreate.js's handleLeveling() hands out via
 * services/levelRewardService.js on level-up. Lives under
 * commands/leveling/ (not commands/settings/) specifically so
 * config/botCommandMap.js's CATEGORY_BOT_MAP puts it on Bot 3 alongside
 * the rest of leveling, per spec ("يجب أن تكون أوامر Rewards على Bot3
 * فقط") - commands/settings/ falls under Bot 2 instead, which would have
 * put a leveling-only command on the wrong bot.
 *
 * The rewards array already allowed more than one reward per level
 * before this task (`rewards: [{level, roleId}]` has no uniqueness
 * constraint on `level` - see database/models/GuildConfig.js) - that's
 * kept as-is; `add` below only blocks re-adding the exact same
 * level+role pair twice.
 */
module.exports = {
  data: new SlashCommandBuilder()
    .setName('levelreward')
    .setDescription('Manage roles granted automatically when members reach a level')
    .setDescriptionLocalizations({
      ar: 'إدارة الرتب التي تُمنح تلقائيًا عند وصول الأعضاء لمستوى معين',
      'en-US': 'Manage roles granted automatically when members reach a level',
    })
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((s) =>
      s
        .setName('add')
        .setDescription('Grant a role automatically when a member reaches a level')
        .setDescriptionLocalizations({
          ar: 'منح رتبة تلقائيًا عند وصول عضو لمستوى معين',
          'en-US': 'Grant a role automatically when a member reaches a level',
        })
        .addIntegerOption((o) =>
          o
            .setName('level')
            .setDescription('The level to reward')
            .setDescriptionLocalizations({ ar: 'المستوى المطلوب', 'en-US': 'The level to reward' })
            .setMinValue(1)
            .setMaxValue(10000)
            .setRequired(true)
        )
        .addRoleOption((o) =>
          o
            .setName('role')
            .setDescription('The role to grant at that level')
            .setDescriptionLocalizations({ ar: 'الرتبة التي ستُمنح عند هذا المستوى', 'en-US': 'The role to grant at that level' })
            .setRequired(true)
        )
    )
    .addSubcommand((s) =>
      s
        .setName('remove')
        .setDescription('Remove a level reward')
        .setDescriptionLocalizations({ ar: 'حذف مكافأة مستوى', 'en-US': 'Remove a level reward' })
        .addIntegerOption((o) =>
          o
            .setName('level')
            .setDescription('The level to remove rewards from')
            .setDescriptionLocalizations({ ar: 'المستوى المراد حذف مكافآته', 'en-US': 'The level to remove rewards from' })
            .setMinValue(1)
            .setMaxValue(10000)
            .setRequired(true)
        )
        .addRoleOption((o) =>
          o
            .setName('role')
            .setDescription('Only remove this specific role (omit to remove every reward for that level)')
            .setDescriptionLocalizations({
              ar: 'حذف هذه الرتبة فقط (اتركه فارغًا لحذف كل مكافآت هذا المستوى)',
              'en-US': 'Only remove this specific role (omit to remove every reward for that level)',
            })
        )
    )
    .addSubcommand((s) =>
      s
        .setName('list')
        .setDescription('List every configured level reward')
        .setDescriptionLocalizations({ ar: 'عرض جميع مكافآت المستويات المُعدة', 'en-US': 'List every configured level reward' })
    ),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({
        embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر لاستخدام هذا الأمر.')],
        ephemeral: true,
      });
    }

    if (!guildConfig.leveling.enabled) {
      return interaction.reply({
        embeds: [errorEmbed(settings, 'نظام المستويات معطّل في هذا السيرفر. فعّله أولاً عبر `/levelingconfig toggle`.')],
        ephemeral: true,
      });
    }

    const sub = interaction.options.getSubcommand();
    const rewards = guildConfig.leveling.rewards;

    if (sub === 'add') {
      const level = interaction.options.getInteger('level');
      const role = interaction.options.getRole('role');

      const alreadyExists = rewards.some((r) => r.level === level && r.roleId === role.id);
      if (alreadyExists) {
        return interaction.reply({
          embeds: [errorEmbed(settings, `<@&${role.id}> is already a reward for level **${level}**.`)],
          ephemeral: true,
        });
      }

      rewards.push({ level, roleId: role.id });
      await guildConfig.save();
      invalidateGuildConfig(interaction.guildId);

      const reply = successEmbed(settings, `<@&${role.id}> will now be granted at level **${level}**.`);
      // Soft warning only (case 4/9 territory: don't invent a hard
      // block on save - the actual grant at level-up time already
      // safely skips this via role.editable, see levelRewardService.js).
      // This just saves the admin a support ticket later.
      if (interaction.guild.members.me && !role.editable) {
        reply.addFields({
          name: '⚠️ Heads up',
          value: "This role is above (or equal to) my highest role, so I won't be able to grant it until my role is moved above it.",
        });
      }
      return interaction.reply({ embeds: [reply] });
    }

    if (sub === 'remove') {
      const level = interaction.options.getInteger('level');
      const role = interaction.options.getRole('role');

      const before = rewards.length;
      const remaining = rewards.filter((r) => !(r.level === level && (!role || r.roleId === role.id)));

      if (remaining.length === before) {
        return interaction.reply({
          embeds: [errorEmbed(settings, `No matching level reward found for level **${level}**${role ? ` and <@&${role.id}>` : ''}.`)],
          ephemeral: true,
        });
      }

      guildConfig.leveling.rewards = remaining;
      guildConfig.markModified('leveling.rewards');
      await guildConfig.save();
      invalidateGuildConfig(interaction.guildId);

      const removedCount = before - remaining.length;
      return interaction.reply({
        embeds: [
          successEmbed(
            settings,
            role
              ? `Removed <@&${role.id}> from the level **${level}** rewards.`
              : `Removed ${removedCount} reward(s) from level **${level}**.`
          ),
        ],
      });
    }

    // list
    if (!rewards.length) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'لا توجد مكافآت مستويات مضافة بعد. أضف واحدة عبر `/levelreward add`.')] });
    }

    // TASK28: flag rewards whose role no longer exists in the guild
    // directly in the list, instead of leaving admins to guess why a
    // reward "did nothing" - grant time (levelRewardService.js) already
    // silently skips these and logs it, but there was previously no way
    // for an admin to *see* that from `/levelreward list` itself. A
    // plain `<@&id>` mention for a deleted role just renders as
    // "@deleted-role" with no indication it's actually broken/inert.
    const sorted = [...rewards].sort((a, b) => a.level - b.level);
    const lines = sorted.map((r) => {
      const roleExists = interaction.guild.roles.cache.has(r.roleId);
      return roleExists ? `**Level ${r.level}** → <@&${r.roleId}>` : `**Level ${r.level}** → <@&${r.roleId}> ⚠️ *role no longer exists - this reward won't grant*`;
    });
    const embed = baseEmbed(settings)
      .setTitle('🎁 Level Rewards')
      .setDescription(lines.join('\n'));

    return interaction.reply({ embeds: [embed] });
  },
};
