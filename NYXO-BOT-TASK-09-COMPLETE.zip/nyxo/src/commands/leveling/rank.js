const { SlashCommandBuilder, AttachmentBuilder } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { baseEmbed, errorEmbed } = require('../../utils/embeds');
const { getRank, getLevelProgress, getXpMultiplier } = require('../../services/levelingService');
const { renderRankCard } = require('../../services/levelCardService');
const logger = require('../../utils/logger');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('rank')
    .setDescription("View your (or another member's) level and XP")
    .setDescriptionLocalizations({ ar: 'عرض مستواك أو مستوى عضو آخر ونقاط خبرته', 'en-US': "View your (or another member's) level and XP" })
    .addUserOption((o) => o.setName('user').setDescription('The member to check').setDescriptionLocalizations({ ar: 'العضو المراد التحقق منه', 'en-US': 'The member to check' })),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!guildConfig.leveling.enabled) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'نظام المستويات معطّل في هذا السيرفر.')], ephemeral: true });
    }

    const target = interaction.options.getUser('user') || interaction.user;
    // TASK20: prefer the guild nickname (Display Name) when the target
    // is a resolvable member of this guild, per the task's explicit
    // "Display Name إذا كان متوفرًا" requirement - getMember() returns
    // null (not a throw) for a user who isn't a cached/fetchable member,
    // e.g. someone who has since left, so this stays safe either way.
    const targetMember = interaction.options.getMember('user') || (target.id === interaction.user.id ? interaction.member : null);
    const displayName = targetMember?.displayName || target.username;
    const result = await getRank(interaction.guildId, target.id);

    if (!result) {
      return interaction.reply({ embeds: [errorEmbed(settings, `${target.tag} has not earned any XP yet.`)], ephemeral: true });
    }

    await interaction.deferReply();

    // TASK17 audit: the displayed level must come from getLevelProgress()
    // (derived from doc.xp, the authoritative field), not the raw
    // doc.level column. doc.level is only a cache that grantMessageXp()
    // updates via an optimistic-concurrency claim step (see
    // levelingService.js), so under concurrent messages it can - by
    // design, to avoid duplicate/incorrect Level Up announcements - end
    // up one step behind the level actually implied by the user's XP.
    // Reading it directly here (as the previous version of this command
    // did) could show a level number that doesn't match the progress
    // bar computed from the same XP total.
    const progress = getLevelProgress(result.doc.xp);

    // TASK16 (leveling): canvas rank card, reusing the project's existing
    // @napi-rs/canvas dependency (see services/levelCardService.js). If
    // rendering fails for any reason (missing system fonts on the host,
    // avatar fetch trouble, etc.) fall back to the previous plain-embed
    // presentation instead of failing the command outright.
    //
    // TASK19: guildConfig.leveling.card lets a server turn the image off
    // entirely (falls straight through to the embed below) and pick a
    // theme/accent/progress-bar color - all optional, all defaulting to
    // the exact TASK16/17 behavior when unset.
    const card = guildConfig.leveling.card || {};
    if (card.enabled !== false) {
      try {
        const buffer = await renderRankCard({
          username: target.username,
          displayName,
          avatarURL: target.displayAvatarURL({ extension: 'png', size: 256 }),
          level: progress.level,
          rank: result.rank,
          currentXp: progress.currentXp,
          xpNeeded: progress.xpNeeded,
          totalXp: result.doc.xp,
          progressPercent: progress.progressPercent,
          accentColor: card.accentColor || settings.embedColor,
          progressColor: card.progressColor,
          theme: card.theme,
        });
        const attachment = new AttachmentBuilder(buffer, { name: 'rank.png' });
        return await interaction.editReply({ files: [attachment] });
      } catch (err) {
        logger.error(`/rank card render failed for ${target.id} in guild ${interaction.guildId}: ${err?.stack || err}`);
      }
    }

    // TASK28: current XP multiplier (if the target has a role configured
    // in leveling.xpMultipliers - see levelingService.js's
    // getXpMultiplier(), same "highest role wins" resolution message XP
    // and Voice XP both already use). Only a display stat here - it
    // plays no part in the XP/level numbers already computed above.
    // Silently resolves to 1 (and is simply omitted below) for a target
    // with no member object (e.g. they left the server) or no matching
    // multiplier role, so this can never throw or show a misleading 1x
    // as if it were a configured bonus.
    const multiplier = targetMember ? getXpMultiplier(targetMember, guildConfig.leveling) : 1;

    const embed = baseEmbed(settings)
      .setTitle(`${displayName}'s Rank`)
      .setThumbnail(target.displayAvatarURL())
      .addFields(
        { name: 'الترتيب', value: `#${result.rank}`, inline: true },
        { name: 'المستوى', value: `${progress.level}`, inline: true },
        { name: 'XP', value: `${progress.currentXp.toLocaleString()} / ${progress.xpNeeded.toLocaleString()}`, inline: true },
        // TASK28: progress percentage as an explicit number, alongside
        // the bar the canvas card already draws - useful here since this
        // fallback embed has no visual bar at all.
        { name: 'Progress', value: `${Math.round(progress.progressPercent)}%`, inline: true },
        { name: 'Total XP', value: `${result.doc.xp.toLocaleString()}`, inline: true },
        { name: 'Messages Sent', value: `${result.doc.messages}`, inline: true },
        // TASK26: shown only in this plain-text fallback embed, not the
        // canvas rank card (per task spec - don't touch the image design
        // unless necessary). `voiceMinutes` is a stat only; it plays no
        // part in Total XP above beyond already being summed into
        // result.doc.xp by services/levelingService.js's grantVoiceXp.
        { name: 'Voice Minutes', value: `${result.doc.voiceMinutes || 0}`, inline: true }
      );

    // TASK28: only shown when it actually changes something (a real
    // multiplier role applies right now) - a flat "1x" for everyone
    // without one would just be noise on every /rank reply.
    if (multiplier !== 1) {
      embed.addFields({ name: 'مضاعف XP', value: `${multiplier}x`, inline: true });
    }

    return interaction.editReply({ embeds: [embed] });
  },
};
