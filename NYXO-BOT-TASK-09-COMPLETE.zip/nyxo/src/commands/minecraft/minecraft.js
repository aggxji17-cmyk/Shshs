const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { baseEmbed, successEmbed, errorEmbed, infoEmbed } = require('../../utils/embeds');
const { isModerator, isGuildManager } = require('../../utils/permissions');
const { getServerStatus } = require('../../services/minecraftService');
const {
  executeRconCommand,
  RconNotConfiguredError,
  RconAuthenticationError,
} = require('../../services/minecraftRconService');

const PLAYER_NAME = /^[A-Za-z0-9_]{1,16}$/;
const DURATION = /^(?:[1-9]\d*[smhd])$/i;
const MAX_OUTPUT = 1_700;

function cleanText(value, fallback = '—') {
  const cleaned = String(value || '').replace(/[`@\u0000-\u001f]/g, '').trim();
  return cleaned.slice(0, MAX_OUTPUT) || fallback;
}

function playerName(interaction, option = 'player') {
  const name = interaction.options.getString(option, true);
  return PLAYER_NAME.test(name) ? name : null;
}

function commandFailure(settings, error) {
  if (error instanceof RconNotConfiguredError) {
    return errorEmbed(settings, 'Minecraft console controls are not configured. Set RCON_ENABLED=true and RCON_PASSWORD in the environment.');
  }
  if (error instanceof RconAuthenticationError) {
    return errorEmbed(settings, 'Minecraft RCON authentication failed. Check the RCON password and server settings.');
  }
  return errorEmbed(settings, `Minecraft command failed: ${cleanText(error.message, 'unknown error')}`);
}

async function getSettings(interaction) {
  const guildConfig = await getGuildConfig(interaction.guildId);
  return { guildConfig, settings: resolved(guildConfig) };
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('minecraft')
    .setDescription('Check and manage the configured Minecraft server')
    .setDescriptionLocalizations({ ar: 'فحص وإدارة سيرفر ماينكرافت المُعد', 'en-US': 'Check and manage the configured Minecraft server' })
    .addSubcommand((s) => s.setName('status').setDescription('Show the live server status').setDescriptionLocalizations({ ar: 'عرض حالة السيرفر المباشرة', 'en-US': 'Show the live server status' }))
    .addSubcommand((s) => s.setName('players').setDescription('Show online players').setDescriptionLocalizations({ ar: 'عرض اللاعبين المتصلين', 'en-US': 'Show online players' }))
    .addSubcommand((s) => s.setName('motd').setDescription('Show the server MOTD').setDescriptionLocalizations({ ar: 'عرض رسالة السيرفر', 'en-US': 'Show the server MOTD' }))
    .addSubcommand((s) => s.setName('broadcast').setDescription('Broadcast a message through the Minecraft console').setDescriptionLocalizations({ ar: 'إرسال رسالة عبر كونسول ماينكرافت', 'en-US': 'Broadcast a message through the Minecraft console' }).addStringOption((o) => o.setName('message').setDescription('Message to broadcast').setDescriptionLocalizations({ ar: 'الرسالة المراد إرسالها', 'en-US': 'Message to broadcast' }).setRequired(true).setMaxLength(240)))
    .addSubcommand((s) => s.setName('ban').setDescription('Ban a Minecraft player').setDescriptionLocalizations({ ar: 'حظر لاعب ماينكرافت', 'en-US': 'Ban a Minecraft player' }).addStringOption((o) => o.setName('player').setDescription('Minecraft username').setRequired(true)).addStringOption((o) => o.setName('reason').setDescription('Ban reason').setMaxLength(120)))
    .addSubcommand((s) => s.setName('kick').setDescription('Kick a Minecraft player').setDescriptionLocalizations({ ar: 'طرد لاعب ماينكرافت', 'en-US': 'Kick a Minecraft player' }).addStringOption((o) => o.setName('player').setDescription('Minecraft username').setRequired(true)).addStringOption((o) => o.setName('reason').setDescription('Kick reason').setMaxLength(120)))
    .addSubcommand((s) => s.setName('tempban').setDescription('Temporarily ban a Minecraft player').setDescriptionLocalizations({ ar: 'حظر لاعب مؤقتاً', 'en-US': 'Temporarily ban a Minecraft player' }).addStringOption((o) => o.setName('player').setDescription('Minecraft username').setRequired(true)).addStringOption((o) => o.setName('duration').setDescription('Duration such as 30m, 2h, or 1d').setRequired(true)).addStringOption((o) => o.setName('reason').setDescription('Ban reason').setMaxLength(120)))
    .addSubcommand((s) => s.setName('whitelist').setDescription('Add or remove a player from the whitelist').setDescriptionLocalizations({ ar: 'إضافة أو إزالة لاعب من القائمة البيضاء', 'en-US': 'Add or remove a player from the whitelist' }).addStringOption((o) => o.setName('action').setDescription('Whitelist action').addChoices({ name: 'Add', value: 'add' }, { name: 'Remove', value: 'remove' }, { name: 'List', value: 'list' }).setRequired(true)).addStringOption((o) => o.setName('player').setDescription('Minecraft username (not needed for list)'))),

  async execute(interaction) {
    const { guildConfig, settings } = await getSettings(interaction);
    const subcommand = interaction.options.getSubcommand();

    if (subcommand === 'status') {
      const { buildMinecraftStatusResponse } = require('../../services/minecraftEmbedBuilder');
      await interaction.deferReply();
      return interaction.editReply(await buildMinecraftStatusResponse(settings));
    }

    if (!isModerator(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You need moderator permissions to use Minecraft controls.')], ephemeral: true });
    }

    if (subcommand === 'players' || subcommand === 'motd') {
      await interaction.deferReply();
      const status = await getServerStatus(settings.minecraft.ip, settings.minecraft.port);
      if (!status.online) return interaction.editReply({ embeds: [errorEmbed(settings, 'The configured Minecraft server is offline or unavailable.')] });

      if (subcommand === 'players') {
        const players = status.players.sample?.length ? status.players.sample.join(', ') : 'The server did not provide a player list.';
        return interaction.editReply({ embeds: [baseEmbed(settings).setTitle(`Players on ${settings.minecraft.name}`).addFields({ name: 'Online', value: `${status.players.online} / ${status.players.max}`, inline: true }, { name: 'Names', value: cleanText(players) })] });
      }
      return interaction.editReply({ embeds: [infoEmbed(settings, `**${settings.minecraft.name}** MOTD:\n${cleanText(status.motd)}`)] });
    }

    if (subcommand === 'whitelist' && interaction.options.getString('action', true) !== 'list' && !isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'Only guild managers can change the Minecraft whitelist.')], ephemeral: true });
    }

    const action = subcommand === 'whitelist' ? interaction.options.getString('action', true) : subcommand;
    const player = subcommand === 'whitelist' && action === 'list' ? null : playerName(interaction);
    if (subcommand !== 'broadcast' && subcommand !== 'whitelist' && !player) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'Minecraft usernames may contain only letters, numbers, and underscores, up to 16 characters.')], ephemeral: true });
    }

    let command;
    if (subcommand === 'broadcast') {
      const message = interaction.options.getString('message', true).replace(/[\r\n]/g, ' ').trim();
      command = `say ${message}`;
    } else if (subcommand === 'whitelist') {
      command = action === 'list' ? 'whitelist list' : `whitelist ${action} ${player}`;
    } else {
      const reason = (interaction.options.getString('reason') || `By ${interaction.user.username}`).replace(/[\r\n]/g, ' ').trim();
      if (subcommand === 'tempban') {
        const duration = interaction.options.getString('duration', true);
        if (!DURATION.test(duration)) {
          return interaction.reply({ embeds: [errorEmbed(settings, 'Duration must look like 30m, 2h, or 1d.')], ephemeral: true });
        }
        command = `tempban ${player} ${duration} ${reason}`;
      } else {
        command = `${subcommand} ${player} ${reason}`;
      }
    }

    await interaction.deferReply();
    try {
      const output = await executeRconCommand(command);
      return interaction.editReply({ embeds: [successEmbed(settings, `Minecraft command completed.\n\`\`\`\n${cleanText(output, 'Command accepted.')}\n\`\`\``)] });
    } catch (error) {
      return interaction.editReply({ embeds: [commandFailure(settings, error)] });
    }
  },
};