const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { isModerator } = require('../../utils/permissions');
const { isServerOwner, outranksExecutor } = require('../../utils/moderationGuards');
const { sendModerationLog } = require('../../utils/moderationLogService');
const { UNLIMITED, getMemberWeeklyKickLimit, countKicksThisWeek, recordKick } = require('../../utils/kickLimitService');
const { createCase } = require('../../services/caseService');
const approvalService = require('../../services/approvalService');

const { safeAutocomplete, reasonChoices } = require('../../utils/autocomplete');
module.exports = {
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('Kick a member from the server')
    .setDescriptionLocalizations({ ar: 'طرد عضو من السيرفر', 'en-US': 'Kick a member from the server' })
    .addUserOption((o) => o.setName('user').setDescription('The user to kick').setDescriptionLocalizations({ ar: 'المستخدم المراد طرده', 'en-US': 'The user to kick' }).setRequired(true))
    .addStringOption((o) => o.setName('reason').setDescription('Reason for the kick').setDescriptionLocalizations({ ar: 'سبب الطرد', 'en-US': 'Reason for the kick' }).setAutocomplete(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),

  autocomplete: safeAutocomplete(async (interaction) => {
    return reasonChoices(interaction.options.getFocused());
  }),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isModerator(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'ليس لديك صلاحية استخدام هذا الأمر.')], ephemeral: true });
    }

    const target = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || 'لا يوجد سبب';

    // 1) Server owner can never be kicked, by anyone.
    if (isServerOwner(interaction.guild, target.id)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'لا يمكن طرد صاحب السيرفر.')], ephemeral: true });
    }

    const member = await interaction.guild.members.fetch(target.id).catch(() => null);
    if (!member) return interaction.reply({ embeds: [errorEmbed(settings, 'هذا المستخدم غير موجود في السيرفر.')], ephemeral: true });

    // 2) Executor can't kick someone whose highest role is above or equal to
    //    their own - unless the executor is the server owner.
    if (outranksExecutor(interaction, member)) {
      return interaction.reply({
        embeds: [errorEmbed(settings, 'لا يمكنك طرد عضو رتبته أعلى من رتبتك أو مساوية لها.')],
        ephemeral: true,
      });
    }

    // 3) Bot can't kick someone above its own top role (discord.js already
    //    folds this - plus permissions - into `member.kickable`).
    if (!member.kickable) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'لا يستطيع البوت طرد هذا العضو (رتبته أعلى من رتبة البوت أو صلاحيات ناقصة).')], ephemeral: true });
    }

    // 4) Weekly per-role kick quota.
    const limit = getMemberWeeklyKickLimit(interaction.member, guildConfig);
    let usedThisWeek = 0;
    if (limit !== UNLIMITED) {
      usedThisWeek = await countKicksThisWeek(interaction.guildId, interaction.user.id);
      if (usedThisWeek >= limit) {
        return interaction.reply({
          embeds: [errorEmbed(settings, 'لقد وصلت إلى الحد الأسبوعي المسموح لعمليات الطرد.')],
          ephemeral: true,
        });
      }
    }

    // 5) If kicks require approval in this guild, submit a request instead
    //    of kicking now.
    if (approvalService.requiresApproval(guildConfig, 'kick')) {
      return approvalService.createApprovalRequest(interaction, guildConfig, settings, {
        action: 'kick',
        target,
        reason,
      });
    }

    await member.kick(reason);
    await recordKick(interaction.guildId, interaction.user.id, target.id, reason);

    const caseDoc = await createCase({
      guildId: interaction.guildId,
      action: 'kick',
      moderatorId: interaction.user.id,
      targetId: target.id,
      reason,
    });

    let description = `**${target.tag}** has been kicked. Reason: ${reason}\nرقم القضية: #${caseDoc.caseId}`;
    if (limit !== UNLIMITED) {
      const remaining = Math.max(limit - (usedThisWeek + 1), 0);
      description += `\nالمتبقي لك هذا الأسبوع: ${remaining} من أصل ${limit}.`;
    }

    await interaction.reply({ embeds: [successEmbed(settings, description)] });

    await sendModerationLog(interaction.guild, guildConfig, settings, {
      action: 'kick',
      moderator: interaction.user,
      target,
      reason,
      caseId: caseDoc.caseId,
      weeklyQuota: limit !== UNLIMITED ? { used: usedThisWeek + 1, limit } : null,
    });
  },
};
