const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { isModerator } = require('../../utils/permissions');
const { sendModLog } = require('../../utils/modLog');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('lockdown')
    .setDescription('Lock or unlock a channel for @everyone')
    .setDescriptionLocalizations({ ar: 'قفل أو فتح قناة أمام الجميع (@everyone)', 'en-US': 'Lock or unlock a channel for @everyone' })
    .addSubcommand((sc) => sc.setName('lock').setDescription('Prevent @everyone from sending messages here')
      .setDescriptionLocalizations({ ar: 'منع الجميع (@everyone) من الإرسال هنا', 'en-US': 'Prevent @everyone from sending messages here' }).addChannelOption((o) => o.setName('channel').setDescription('Channel (defaults to here)').setDescriptionLocalizations({ ar: 'القناة (افتراضياً هذه القناة)', 'en-US': 'Channel (defaults to here)' })))
    .addSubcommand((sc) => sc.setName('unlock').setDescription('Restore @everyone send permissions here')
      .setDescriptionLocalizations({ ar: 'استعادة صلاحية الإرسال للجميع هنا', 'en-US': 'Restore @everyone send permissions here' }).addChannelOption((o) => o.setName('channel').setDescription('Channel (defaults to here)').setDescriptionLocalizations({ ar: 'القناة (افتراضياً هذه القناة)', 'en-US': 'Channel (defaults to here)' })))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isModerator(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'ليس لديك صلاحية استخدام هذا الأمر.')], ephemeral: true });
    }

    const channel = interaction.options.getChannel('channel') || interaction.channel;
    const sub = interaction.options.getSubcommand();
    const lock = sub === 'lock';

    await channel.permissionOverwrites
      .edit(interaction.guild.roles.everyone, { SendMessages: lock ? false : null })
      .catch(() => null);

    await interaction.reply({ embeds: [successEmbed(settings, `${channel} has been ${lock ? '🔒 locked' : '🔓 unlocked'}.`)] });
    await sendModLog(interaction.guild, guildConfig, settings, {
      title: lock ? 'Channel Locked' : 'Channel Unlocked',
      fields: [
        { name: 'Channel', value: `${channel}`, inline: true },
        { name: 'Moderator', value: `${interaction.user}`, inline: true },
      ],
    });
  },
};
