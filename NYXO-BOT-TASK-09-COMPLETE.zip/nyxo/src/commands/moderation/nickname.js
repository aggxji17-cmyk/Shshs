const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { isModerator } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('nickname')
    .setDescription('Set or reset a member\'s nickname')
    .setDescriptionLocalizations({ ar: 'تعيين أو إعادة تعيين الاسم المستعار لعضو', 'en-US': 'Set or reset a member\'s nickname' })
    .addUserOption((o) => o.setName('user').setDescription('The member').setDescriptionLocalizations({ ar: 'العضو', 'en-US': 'The member' }).setRequired(true))
    .addStringOption((o) => o.setName('nickname').setDescription('New nickname (leave empty to reset)').setDescriptionLocalizations({ ar: 'الاسم المستعار الجديد (اتركه فارغاً لإعادة التعيين)', 'en-US': 'New nickname (leave empty to reset)' }).setMaxLength(32))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageNicknames),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isModerator(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'ليس لديك صلاحية استخدام هذا الأمر.')], ephemeral: true });
    }

    const target = interaction.options.getUser('user');
    const nickname = interaction.options.getString('nickname') || null;
    const member = await interaction.guild.members.fetch(target.id).catch(() => null);

    if (!member) return interaction.reply({ embeds: [errorEmbed(settings, 'هذا المستخدم غير موجود في السيرفر.')], ephemeral: true });
    if (!member.manageable) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'لا أستطيع إدارة هذا العضو (رتبته قد تكون أعلى من رتبة البوت).')], ephemeral: true });
    }

    await member.setNickname(nickname).catch(() => null);
    await interaction.reply({
      embeds: [successEmbed(settings, nickname ? `Nickname for ${target} set to **${nickname}**.` : `Nickname for ${target} has been reset.`)],
    });
  },
};
