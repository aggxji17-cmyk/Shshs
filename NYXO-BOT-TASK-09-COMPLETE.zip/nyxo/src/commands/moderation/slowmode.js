const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { isModerator } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('slowmode')
    .setDescription('Set this channel\'s slowmode delay')
    .setDescriptionLocalizations({ ar: 'تعيين مدة البطء (Slowmode) لهذه القناة', 'en-US': 'Set this channel\'s slowmode delay' })
    .addIntegerOption((o) => o.setName('seconds').setDescription('Delay in seconds (0 to disable, max 21600)').setDescriptionLocalizations({ ar: 'التأخير بالثواني (0 للتعطيل، الحد الأقصى 21600)', 'en-US': 'Delay in seconds (0 to disable, max 21600)' }).setRequired(true).setMinValue(0).setMaxValue(21600))
    .addChannelOption((o) => o.setName('channel').setDescription('Channel (defaults to here)').setDescriptionLocalizations({ ar: 'القناة (افتراضياً هذه القناة)', 'en-US': 'Channel (defaults to here)' }))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isModerator(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'ليس لديك صلاحية استخدام هذا الأمر.')], ephemeral: true });
    }

    const seconds = interaction.options.getInteger('seconds');
    const channel = interaction.options.getChannel('channel') || interaction.channel;

    await channel.setRateLimitPerUser(seconds).catch(() => null);

    await interaction.reply({
      embeds: [successEmbed(settings, seconds === 0 ? `Slowmode disabled in ${channel}.` : `Slowmode set to **${seconds}s** in ${channel}.`)],
    });
  },
};
