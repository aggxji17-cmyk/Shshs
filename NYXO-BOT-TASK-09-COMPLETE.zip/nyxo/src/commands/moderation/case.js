const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { errorEmbed } = require('../../utils/embeds');
const { isModerator } = require('../../utils/permissions');
const { getCaseById, getRecentCases } = require('../../services/caseService');
const { buildCaseEmbed } = require('../../utils/caseEmbed');
const { safeAutocomplete, fuzzyFilter } = require('../../utils/autocomplete');

module.exports = {
  data: new SlashCommandBuilder().setName('case').setDescription('View a moderation case by its ID number')
    .setDescriptionLocalizations({ ar: 'عرض معلومات قضية إشراف برقمها', 'en-US': 'View a moderation case by its ID number' })
    .addIntegerOption((o) => o.setName('case_id').setDescription('The case number').setDescriptionLocalizations({ ar: 'رقم القضية', 'en-US': 'The case number' }).setRequired(true).setMinValue(1).setAutocomplete(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  autocomplete: safeAutocomplete(async (interaction) => {
    if (!interaction.guildId) return [];
    const focused = String(interaction.options.getFocused());

    const recent = await getRecentCases(interaction.guildId, 25);
    const matched = fuzzyFilter(recent, focused, { key: (c) => String(c.caseId) });

    return matched.map((c) => ({
      name: `#${c.caseId} • ${c.action} • ${c.reason || 'لا يوجد سبب'}`,
      value: c.caseId,
    }));
  }),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isModerator(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'ليس لديك صلاحية استخدام هذا الأمر.')], ephemeral: true });
    }

    const caseId = interaction.options.getInteger('case_id');
    const caseDoc = await getCaseById(interaction.guildId, caseId);

    if (!caseDoc) {
      return interaction.reply({ embeds: [errorEmbed(settings, `لا توجد قضية بالرقم #${caseId}.`)], ephemeral: true });
    }

    await interaction.reply({ embeds: [buildCaseEmbed(settings, caseDoc)] });
  },
};
