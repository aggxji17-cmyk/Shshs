const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed, baseEmbed } = require('../../utils/embeds');
const { isModerator } = require('../../utils/permissions');
const { isServerOwner, outranksExecutor } = require('../../utils/moderationGuards');
const { parseDuration } = require('../../utils/duration');
const scheduleService = require('../../services/scheduleService');

const MIN_DELAY_MS = 30_000; // 30 seconds
const MAX_DELAY_MS = 365 * 86_400_000; // 1 year

const STATUS_EMOJI = { Pending: '🕓', Completed: '✅', Cancelled: '🚫', Failed: '⚠️' };

/** Parses+validates the shared `time` option. Returns a Date, or null (with the error already sent) if invalid. */
async function resolveExecuteAt(interaction, settings) {
  const durationMs = parseDuration(interaction.options.getString('time'));
  if (!durationMs || durationMs < MIN_DELAY_MS || durationMs > MAX_DELAY_MS) {
    await interaction.reply({
      embeds: [errorEmbed(settings, 'Give a valid delay between 30 seconds and 1 year, e.g. `10m`, `2h30m`, `1d`.')],
      ephemeral: true,
    });
    return null;
  }
  return new Date(Date.now() + durationMs);
}

function confirmationEmbed(settings, action, executeAt, taskId) {
  return successEmbed(
    settings,
    `Scheduled **${action}** for <t:${Math.floor(executeAt.getTime() / 1000)}:F> (<t:${Math.floor(executeAt.getTime() / 1000)}:R>).\nSchedule ID: \`${taskId}\``
  );
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('schedule')
    .setDescription('Schedule a moderation action to run later')
    .setDescriptionLocalizations({ ar: 'جدولة إجراء إشرافي لتنفيذه لاحقاً', 'en-US': 'Schedule a moderation action to run later' })
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addSubcommand((s) =>
      s
        .setName('ban')
        .setDescription('Schedule a ban')
      .setDescriptionLocalizations({ ar: 'جدولة حظر', 'en-US': 'Schedule a ban' })
        .addUserOption((o) => o.setName('user').setDescription('The user to ban').setDescriptionLocalizations({ ar: 'المستخدم المراد حظره', 'en-US': 'The user to ban' }).setRequired(true))
        .addStringOption((o) => o.setName('time').setDescription('Delay before the ban runs, e.g. 10m, 2h30m, 1d').setDescriptionLocalizations({ ar: 'التأخير قبل تنفيذ الحظر، مثل 10m أو 2h30m أو 1d', 'en-US': 'Delay before the ban runs, e.g. 10m, 2h30m, 1d' }).setRequired(true))
        .addStringOption((o) => o.setName('reason').setDescription('Reason for the ban').setDescriptionLocalizations({ ar: 'سبب الحظر', 'en-US': 'Reason for the ban' }))
        .addIntegerOption((o) => o.setName('delete_days').setDescription('Days of message history to delete (0-7)').setDescriptionLocalizations({ ar: 'عدد أيام سجل الرسائل المراد حذفها (0-7)', 'en-US': 'Days of message history to delete (0-7)' }).setMinValue(0).setMaxValue(7))
    )
    .addSubcommand((s) =>
      s
        .setName('kick')
        .setDescription('Schedule a kick')
      .setDescriptionLocalizations({ ar: 'جدولة طرد', 'en-US': 'Schedule a kick' })
        .addUserOption((o) => o.setName('user').setDescription('The user to kick').setDescriptionLocalizations({ ar: 'المستخدم المراد طرده', 'en-US': 'The user to kick' }).setRequired(true))
        .addStringOption((o) => o.setName('time').setDescription('Delay before the kick runs, e.g. 10m, 2h30m, 1d').setDescriptionLocalizations({ ar: 'التأخير قبل تنفيذ الطرد، مثل 10m أو 2h30m أو 1d', 'en-US': 'Delay before the kick runs, e.g. 10m, 2h30m, 1d' }).setRequired(true))
        .addStringOption((o) => o.setName('reason').setDescription('Reason for the kick').setDescriptionLocalizations({ ar: 'سبب الطرد', 'en-US': 'Reason for the kick' }))
    )
    .addSubcommand((s) =>
      s
        .setName('timeout')
        .setDescription('Schedule a timeout')
      .setDescriptionLocalizations({ ar: 'جدولة تقييد', 'en-US': 'Schedule a timeout' })
        .addUserOption((o) => o.setName('user').setDescription('The user to timeout').setDescriptionLocalizations({ ar: 'المستخدم المراد تقييده', 'en-US': 'The user to timeout' }).setRequired(true))
        .addStringOption((o) => o.setName('time').setDescription('Delay before the timeout starts, e.g. 10m, 2h30m, 1d').setDescriptionLocalizations({ ar: 'التأخير قبل بدء التقييد، مثل 10m أو 2h30m أو 1d', 'en-US': 'Delay before the timeout starts, e.g. 10m, 2h30m, 1d' }).setRequired(true))
        .addIntegerOption((o) => o.setName('minutes').setDescription('Timeout duration in minutes (max 40320 = 28 days)').setDescriptionLocalizations({ ar: 'مدة التقييد بالدقائق (الحد الأقصى 40320 = 28 يوماً)', 'en-US': 'Timeout duration in minutes (max 40320 = 28 days)' }).setRequired(true).setMinValue(1).setMaxValue(40320))
        .addStringOption((o) => o.setName('reason').setDescription('Reason for the timeout').setDescriptionLocalizations({ ar: 'سبب التقييد', 'en-US': 'Reason for the timeout' }))
    )
    .addSubcommand((s) =>
      s
        .setName('unban')
        .setDescription('Schedule an unban')
      .setDescriptionLocalizations({ ar: 'جدولة رفع حظر', 'en-US': 'Schedule an unban' })
        .addStringOption((o) => o.setName('user_id').setDescription('The user ID to unban').setDescriptionLocalizations({ ar: 'معرّف المستخدم المراد رفع الحظر عنه', 'en-US': 'The user ID to unban' }).setRequired(true))
        .addStringOption((o) => o.setName('time').setDescription('Delay before the unban runs, e.g. 10m, 2h30m, 1d').setDescriptionLocalizations({ ar: 'التأخير قبل تنفيذ رفع الحظر، مثل 10m أو 2h30m أو 1d', 'en-US': 'Delay before the unban runs, e.g. 10m, 2h30m, 1d' }).setRequired(true))
        .addStringOption((o) => o.setName('reason').setDescription('Reason for the unban').setDescriptionLocalizations({ ar: 'سبب رفع الحظر', 'en-US': 'Reason for the unban' }))
    )
    .addSubcommand((s) =>
      s
        .setName('message')
        .setDescription('Schedule a message to be sent to a user or channel')
      .setDescriptionLocalizations({ ar: 'جدولة إرسال رسالة لمستخدم أو قناة', 'en-US': 'Schedule a message to be sent to a user or channel' })
        .addUserOption((o) => o.setName('user').setDescription('Who this message is for (mentioned/DMed)').setDescriptionLocalizations({ ar: 'لمن هذه الرسالة (يُذكر/يُراسل خاص)', 'en-US': 'Who this message is for (mentioned/DMed)' }).setRequired(true))
        .addStringOption((o) => o.setName('time').setDescription('Delay before the message is sent, e.g. 10m, 2h30m, 1d').setDescriptionLocalizations({ ar: 'التأخير قبل إرسال الرسالة، مثل 10m أو 2h30m أو 1d', 'en-US': 'Delay before the message is sent, e.g. 10m, 2h30m, 1d' }).setRequired(true))
        .addStringOption((o) => o.setName('content').setDescription('The message to send').setDescriptionLocalizations({ ar: 'الرسالة المراد إرسالها', 'en-US': 'The message to send' }).setRequired(true).setMaxLength(1500))
        .addChannelOption((o) => o.setName('channel').setDescription('Channel to send it in (omit to DM the user instead)').setDescriptionLocalizations({ ar: 'القناة التي تُرسل فيها (اتركه فارغاً لإرسال رسالة خاصة للمستخدم بدلاً من ذلك)', 'en-US': 'Channel to send it in (omit to DM the user instead)' }).addChannelTypes(ChannelType.GuildText))
    )
    .addSubcommand((s) =>
      s
        .setName('list')
        .setDescription('List scheduled tasks for this server')
      .setDescriptionLocalizations({ ar: 'عرض المهام المجدولة لهذا السيرفر', 'en-US': 'List scheduled tasks for this server' })
        .addStringOption((o) =>
          o
            .setName('status')
            .setDescription('Filter by status (default: Pending)').setDescriptionLocalizations({ ar: 'التصفية حسب الحالة (افتراضياً: معلّق)', 'en-US': 'Filter by status (default: Pending)' })
            .addChoices({ name: 'Pending', value: 'Pending' }, { name: 'Completed', value: 'Completed' }, { name: 'Cancelled', value: 'Cancelled' }, { name: 'Failed', value: 'Failed' })
        )
    )
    .addSubcommand((s) => s.setName('cancel').setDescription('Cancel a pending scheduled task')
      .setDescriptionLocalizations({ ar: 'إلغاء مهمة مجدولة معلّقة', 'en-US': 'Cancel a pending scheduled task' }).addStringOption((o) => o.setName('id').setDescription('Schedule ID from /schedule list').setDescriptionLocalizations({ ar: 'معرّف المهمة المجدولة من /schedule list', 'en-US': 'Schedule ID from /schedule list' }).setRequired(true))),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isModerator(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'ليس لديك صلاحية استخدام هذا الأمر.')], ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();

    if (sub === 'ban') {
      const target = interaction.options.getUser('user');
      const reason = interaction.options.getString('reason') || 'لا يوجد سبب';
      const deleteDays = interaction.options.getInteger('delete_days') || 0;

      if (isServerOwner(interaction.guild, target.id)) {
        return interaction.reply({ embeds: [errorEmbed(settings, 'لا يمكن جدولة حظر لصاحب السيرفر.')], ephemeral: true });
      }
      const member = await interaction.guild.members.fetch(target.id).catch(() => null);
      if (outranksExecutor(interaction, member)) {
        return interaction.reply({ embeds: [errorEmbed(settings, 'لا يمكنك جدولة حظر لعضو رتبته أعلى من رتبتك أو مساوية لها.')], ephemeral: true });
      }

      const executeAt = await resolveExecuteAt(interaction, settings);
      if (!executeAt) return;

      const task = await scheduleService.createScheduledTask({
        guildId: interaction.guildId,
        action: 'ban',
        moderatorId: interaction.user.id,
        targetId: target.id,
        reason,
        deleteDays,
        executeAt,
      });

      return interaction.reply({ embeds: [confirmationEmbed(settings, `ban on ${target.tag}`, executeAt, task._id)], ephemeral: true });
    }

    if (sub === 'kick') {
      const target = interaction.options.getUser('user');
      const reason = interaction.options.getString('reason') || 'لا يوجد سبب';

      if (isServerOwner(interaction.guild, target.id)) {
        return interaction.reply({ embeds: [errorEmbed(settings, 'لا يمكن جدولة طرد لصاحب السيرفر.')], ephemeral: true });
      }
      const member = await interaction.guild.members.fetch(target.id).catch(() => null);
      if (outranksExecutor(interaction, member)) {
        return interaction.reply({ embeds: [errorEmbed(settings, 'لا يمكنك جدولة طرد لعضو رتبته أعلى من رتبتك أو مساوية لها.')], ephemeral: true });
      }

      const executeAt = await resolveExecuteAt(interaction, settings);
      if (!executeAt) return;

      const task = await scheduleService.createScheduledTask({
        guildId: interaction.guildId,
        action: 'kick',
        moderatorId: interaction.user.id,
        targetId: target.id,
        reason,
        executeAt,
      });

      return interaction.reply({ embeds: [confirmationEmbed(settings, `kick on ${target.tag}`, executeAt, task._id)], ephemeral: true });
    }

    if (sub === 'timeout') {
      const target = interaction.options.getUser('user');
      const minutes = interaction.options.getInteger('minutes');
      const reason = interaction.options.getString('reason') || 'لا يوجد سبب';

      if (isServerOwner(interaction.guild, target.id)) {
        return interaction.reply({ embeds: [errorEmbed(settings, 'لا يمكن جدولة Timeout لصاحب السيرفر.')], ephemeral: true });
      }
      const member = await interaction.guild.members.fetch(target.id).catch(() => null);
      if (outranksExecutor(interaction, member)) {
        return interaction.reply({ embeds: [errorEmbed(settings, 'لا يمكنك جدولة Timeout لعضو رتبته أعلى من رتبتك أو مساوية لها.')], ephemeral: true });
      }

      const executeAt = await resolveExecuteAt(interaction, settings);
      if (!executeAt) return;

      const task = await scheduleService.createScheduledTask({
        guildId: interaction.guildId,
        action: 'timeout',
        moderatorId: interaction.user.id,
        targetId: target.id,
        reason,
        durationMinutes: minutes,
        executeAt,
      });

      return interaction.reply({ embeds: [confirmationEmbed(settings, `${minutes}-minute timeout on ${target.tag}`, executeAt, task._id)], ephemeral: true });
    }

    if (sub === 'unban') {
      const userId = interaction.options.getString('user_id');
      const reason = interaction.options.getString('reason') || 'لا يوجد سبب';

      const executeAt = await resolveExecuteAt(interaction, settings);
      if (!executeAt) return;

      const task = await scheduleService.createScheduledTask({
        guildId: interaction.guildId,
        action: 'unban',
        moderatorId: interaction.user.id,
        targetId: userId,
        reason,
        executeAt,
      });

      return interaction.reply({ embeds: [confirmationEmbed(settings, `unban on \`${userId}\``, executeAt, task._id)], ephemeral: true });
    }

    if (sub === 'message') {
      const target = interaction.options.getUser('user');
      const content = interaction.options.getString('content');
      const channel = interaction.options.getChannel('channel');

      const executeAt = await resolveExecuteAt(interaction, settings);
      if (!executeAt) return;

      const task = await scheduleService.createScheduledTask({
        guildId: interaction.guildId,
        action: 'message',
        moderatorId: interaction.user.id,
        targetId: target.id,
        reason: content,
        channelId: channel?.id || null,
        executeAt,
      });

      return interaction.reply({
        embeds: [confirmationEmbed(settings, `message to ${target.tag}${channel ? ` in ${channel}` : ' (DM)'}`, executeAt, task._id)],
        ephemeral: true,
      });
    }

    if (sub === 'list') {
      const status = interaction.options.getString('status') || 'Pending';
      const tasks = await scheduleService.listScheduledTasks(interaction.guildId, { status });

      if (!tasks.length) {
        return interaction.reply({ embeds: [errorEmbed(settings, `No ${status.toLowerCase()} scheduled tasks for this server.`)], ephemeral: true });
      }

      const embed = baseEmbed(settings)
        .setTitle(`Scheduled Tasks - ${status}`)
        .setDescription(
          tasks
            .map((t) => {
              const when = `<t:${Math.floor(t.executeAt.getTime() / 1000)}:R>`;
              const caseRef = t.caseId ? ` (Case #${t.caseId})` : '';
              return `${STATUS_EMOJI[t.status] || ''} **${t.action}** on \`${t.targetId}\` - ${when}${caseRef}\nID: \`${t._id}\` - by <@${t.moderatorId}>`;
            })
            .join('\n\n')
        );

      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    if (sub === 'cancel') {
      const id = interaction.options.getString('id');
      const task = await scheduleService.cancelScheduledTask(interaction.guildId, id, interaction.user.id);

      if (!task) {
        return interaction.reply({ embeds: [errorEmbed(settings, 'Scheduled task not found. Check the ID with `/schedule list`.')], ephemeral: true });
      }
      if (task.status !== 'Cancelled') {
        return interaction.reply({ embeds: [errorEmbed(settings, `That task is already **${task.status}** and can no longer be cancelled.`)], ephemeral: true });
      }

      return interaction.reply({ embeds: [successEmbed(settings, `Scheduled **${task.action}** task \`${task._id}\` cancelled.`)], ephemeral: true });
    }
  },
};
