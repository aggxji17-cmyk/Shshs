const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved, invalidateGuildConfig } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed, infoEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');
const { safeAutocomplete, categoryChoices } = require('../../utils/autocomplete');
const { getCommandsByCategory } = require('../../utils/commandCategories');
const { PROTECTED_COMMANDS, getOrCreateEntry, addUnique, removeIfPresent, pruneEmptyEntries } = require('../../utils/commandPermissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('rolepermissions')
    .setDescription("Manage a role's command permissions in bulk, by category")
    .setDescriptionLocalizations({ ar: 'إدارة صلاحيات دور معين لعدة أوامر دفعة واحدة، حسب الفئة', 'en-US': "Manage a role's command permissions in bulk, by category" })
    .addSubcommand((s) =>
      s
        .setName('view')
        .setDescription("Show every command permission override that involves a role")
        .setDescriptionLocalizations({ ar: 'عرض جميع استثناءات الصلاحيات الخاصة بدور معين', 'en-US': 'Show every command permission override that involves a role' })
        .addRoleOption((o) => o.setName('role').setDescription('Role to inspect').setDescriptionLocalizations({ ar: 'الدور المراد فحصه', 'en-US': 'Role to inspect' }).setRequired(true))
    )
    .addSubcommand((s) =>
      s
        .setName('allow-category')
        .setDescription('Allow a role to use every command in a whole category at once')
        .setDescriptionLocalizations({ ar: 'السماح لدور باستخدام جميع أوامر فئة كاملة دفعة واحدة', 'en-US': 'Allow a role to use every command in a whole category at once' })
        .addRoleOption((o) => o.setName('role').setDescription('Role to allow').setDescriptionLocalizations({ ar: 'الدور المراد السماح له', 'en-US': 'Role to allow' }).setRequired(true))
        .addStringOption((o) => o.setName('category').setDescription('Command category, e.g. moderation').setDescriptionLocalizations({ ar: 'فئة الأوامر، مثل moderation', 'en-US': 'Command category, e.g. moderation' }).setRequired(true).setAutocomplete(true))
    )
    .addSubcommand((s) =>
      s
        .setName('deny-category')
        .setDescription('Block a role from every command in a whole category at once')
        .setDescriptionLocalizations({ ar: 'منع دور من جميع أوامر فئة كاملة دفعة واحدة', 'en-US': 'Block a role from every command in a whole category at once' })
        .addRoleOption((o) => o.setName('role').setDescription('Role to deny').setDescriptionLocalizations({ ar: 'الدور المراد منعه', 'en-US': 'Role to deny' }).setRequired(true))
        .addStringOption((o) => o.setName('category').setDescription('Command category, e.g. moderation').setDescriptionLocalizations({ ar: 'فئة الأوامر، مثل moderation', 'en-US': 'Command category, e.g. moderation' }).setRequired(true).setAutocomplete(true))
    )
    .addSubcommand((s) =>
      s
        .setName('clear-category')
        .setDescription("Remove a role's overrides (allow or deny) for one whole category")
        .setDescriptionLocalizations({ ar: 'إزالة استثناءات دور (سماح أو منع) عن فئة كاملة', 'en-US': "Remove a role's overrides (allow or deny) for one whole category" })
        .addRoleOption((o) => o.setName('role').setDescription('Role to clear').setDescriptionLocalizations({ ar: 'الدور المراد مسح استثناءاته', 'en-US': 'Role to clear' }).setRequired(true))
        .addStringOption((o) => o.setName('category').setDescription('Command category, e.g. moderation').setDescriptionLocalizations({ ar: 'فئة الأوامر، مثل moderation', 'en-US': 'Command category, e.g. moderation' }).setRequired(true).setAutocomplete(true))
    )
    .addSubcommand((s) =>
      s
        .setName('clear')
        .setDescription("Remove a role's overrides (allow or deny) from every command, server-wide")
        .setDescriptionLocalizations({ ar: 'إزالة استثناءات دور (سماح أو منع) من جميع الأوامر في السيرفر', 'en-US': "Remove a role's overrides (allow or deny) from every command, server-wide" })
        .addRoleOption((o) => o.setName('role').setDescription('Role to fully clear').setDescriptionLocalizations({ ar: 'الدور المراد مسح جميع استثناءاته', 'en-US': 'Role to fully clear' }).setRequired(true))
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  autocomplete: safeAutocomplete(async (interaction) => {
    return categoryChoices(interaction, interaction.options.getFocused());
  }),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر لاستخدام هذا الأمر.')], ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();
    const role = interaction.options.getRole('role');

    if (sub === 'view') {
      const involved = guildConfig.commandPermissions.filter(
        (e) => e.allowedRoleIds.includes(role.id) || e.deniedRoleIds.includes(role.id)
      );
      if (!involved.length) {
        return interaction.reply({ embeds: [infoEmbed(settings, `${role} has no per-command permission overrides.`)], ephemeral: true });
      }
      const allowed = involved.filter((e) => e.allowedRoleIds.includes(role.id)).map((e) => `\`/${e.commandName}\``);
      const denied = involved.filter((e) => e.deniedRoleIds.includes(role.id)).map((e) => `\`/${e.commandName}\``);
      return interaction.reply({
        embeds: [
          infoEmbed(settings, `Permission overrides for ${role}`).addFields(
            { name: 'Allowed commands', value: allowed.join(', ') || 'None' },
            { name: 'Denied commands', value: denied.join(', ') || 'None' }
          ),
        ],
        ephemeral: true,
      });
    }

    if (sub === 'clear') {
      let changedCount = 0;
      for (const entry of guildConfig.commandPermissions) {
        if (PROTECTED_COMMANDS.has(entry.commandName)) continue;
        if (removeIfPresent(entry.allowedRoleIds, role.id)) changedCount += 1;
        if (removeIfPresent(entry.deniedRoleIds, role.id)) changedCount += 1;
      }
      // Drop now-empty entries so the array doesn't grow forever with dead weight.
      pruneEmptyEntries(guildConfig);

      if (!changedCount) {
        return interaction.reply({ embeds: [errorEmbed(settings, `${role} had no per-command overrides to clear.`)], ephemeral: true });
      }
      await guildConfig.save();
      invalidateGuildConfig(interaction.guildId);
      return interaction.reply({ embeds: [successEmbed(settings, `Cleared every command permission override for ${role} (${changedCount} entr${changedCount === 1 ? 'y' : 'ies'}).`)] });
    }

    // allow-category / deny-category / clear-category all operate on
    // every command in one category at once.
    const category = interaction.options.getString('category').toLowerCase();
    const byCategory = getCommandsByCategory(interaction.client);
    const commandNames = (byCategory.get(category) || []).filter((name) => !PROTECTED_COMMANDS.has(name));

    if (!commandNames.length) {
      return interaction.reply({ embeds: [errorEmbed(settings, `No category named \`${category}\` exists (or it only contains protected commands).`)], ephemeral: true });
    }

    let changedCount = 0;

    if (sub === 'allow-category') {
      for (const name of commandNames) {
        const entry = getOrCreateEntry(guildConfig, name);
        removeIfPresent(entry.deniedRoleIds, role.id); // allow always wins over a prior deny
        if (addUnique(entry.allowedRoleIds, role.id)) changedCount += 1;
      }
    } else if (sub === 'deny-category') {
      for (const name of commandNames) {
        const entry = getOrCreateEntry(guildConfig, name);
        removeIfPresent(entry.allowedRoleIds, role.id); // deny always wins over a prior allow
        if (addUnique(entry.deniedRoleIds, role.id)) changedCount += 1;
      }
    } else if (sub === 'clear-category') {
      for (const name of commandNames) {
        const entry = guildConfig.commandPermissions.find((e) => e.commandName === name);
        if (!entry) continue;
        if (removeIfPresent(entry.allowedRoleIds, role.id)) changedCount += 1;
        if (removeIfPresent(entry.deniedRoleIds, role.id)) changedCount += 1;
      }
      pruneEmptyEntries(guildConfig);
    }

    if (!changedCount) {
      return interaction.reply({ embeds: [errorEmbed(settings, `Nothing to change for ${role} in category \`${category}\`.`)], ephemeral: true });
    }

    await guildConfig.save();
    invalidateGuildConfig(interaction.guildId);

    const verbs = { 'allow-category': 'allowed to use', 'deny-category': 'blocked from', 'clear-category': 'no longer overridden for' };
    await interaction.reply({
      embeds: [successEmbed(settings, `${role} is now ${verbs[sub]} every command in \`${category}\` (${commandNames.length} command${commandNames.length === 1 ? '' : 's'}).`)],
    });
  },
};
