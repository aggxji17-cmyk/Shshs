const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { isModerator } = require('../../utils/permissions');
const { isServerOwner, outranksExecutor } = require('../../utils/moderationGuards');
const { sendModerationLog } = require('../../utils/moderationLogService');
const { UNLIMITED, getMemberWeeklyTimeoutLimit, countTimeoutsThisWeek, recordTimeout } = require('../../utils/timeoutLimitService');
const { createCase } = require('../../services/caseService');
const approvalService = require('../../services/approvalService');

const { safeAutocomplete, reasonChoices } = require('../../utils/autocomplete');
module.exports = {
  data: new SlashCommandBuilder()
    .setName('timeout')
    .setDescription('Timeout (mute) a member for a set duration')
    .setDescriptionLocalizations({ ar: 'تقييد (كتم) عضو لمدة محددة', 'en-US': 'Timeout (mute) a member for a set duration' })
    .addUserOption((o) => o.setName('user').setDescription('The user to timeout').setDescriptionLocalizations({ ar: 'المستخدم المراد تقييده', 'en-US': 'The user to timeout' }).setRequired(true))
    .addIntegerOption((o) => o.setName('minutes').setDescription('Duration in minutes (max 40320 = 28 days)').setDescriptionLocalizations({ ar: 'المدة بالدقائق (الحد الأقصى 40320 = 28 يوماً)', 'en-US': 'Duration in minutes (max 40320 = 28 days)' }).setRequired(true).setMinValue(1).setMaxValue(40320))
    .addStringOption((o) => o.setName('reason').setDescription('Reason for the timeout').setDescriptionLocalizations({ ar: 'سبب التقييد', 'en-US': 'Reason for the timeout' }).setAutocomplete(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  autocomplete: safeAutocomplete(async (interaction) => {
    return reasonChoices(interaction.options.getFocused());
  }),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isModerator(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'ليس لديك صلاحية استخدام هذا الأمر.')], ephemeral: true });
    }

    const target = interaction.options.getUser('user');
    const minutes = interaction.options.getInteger('minutes');
    const reason = interaction.options.getString('reason') || 'لا يوجد سبب';

    // 1) Server owner can never be timed out, by anyone.
    if (isServerOwner(interaction.guild, target.id)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'لا يمكن إعطاء صاحب السيرفر Timeout.')], ephemeral: true });
    }

    const member = await interaction.guild.members.fetch(target.id).catch(() => null);
    if (!member) return interaction.reply({ embeds: [errorEmbed(settings, 'هذا المستخدم غير موجود في السيرفر.')], ephemeral: true });

    // 2) Executor can't timeout someone whose highest role is above or
    //    equal to their own - unless the executor is the server owner.
    if (outranksExecutor(interaction, member)) {
      return interaction.reply({
        embeds: [errorEmbed(settings, 'لا يمكنك إعطاء Timeout لعضو رتبته أعلى من رتبتك أو مساوية لها.')],
        ephemeral: true,
      });
    }

    // 3) Bot can't timeout someone above its own top role (discord.js
    //    already folds this - plus permissions - into `member.moderatable`).
    if (!member.moderatable) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'لا يستطيع البوت إعطاء Timeout لهذا العضو (رتبته أعلى من رتبة البوت أو صلاحيات ناقصة).')], ephemeral: true });
    }

    // 4) Weekly per-role timeout quota.
    const limit = getMemberWeeklyTimeoutLimit(interaction.member, guildConfig);
    let usedThisWeek = 0;
    if (limit !== UNLIMITED) {
      usedThisWeek = await countTimeoutsThisWeek(interaction.guildId, interaction.user.id);
      if (usedThisWeek >= limit) {
        return interaction.reply({
          embeds: [errorEmbed(settings, 'لقد وصلت إلى الحد الأسبوعي المسموح لعمليات الـ Timeout.')],
          ephemeral: true,
        });
      }
    }

    // 5) If timeouts require approval in this guild, submit a request
    //    instead of applying it now.
    if (approvalService.requiresApproval(guildConfig, 'timeout')) {
      return approvalService.createApprovalRequest(interaction, guildConfig, settings, {
        action: 'timeout',
        target,
        reason,
        durationMinutes: minutes,
      });
    }

    await member.timeout(minutes * 60 * 1000, reason);
    await recordTimeout(interaction.guildId, interaction.user.id, target.id, reason, { durationMinutes: minutes });

    const caseDoc = await createCase({
      guildId: interaction.guildId,
      action: 'timeout',
      moderatorId: interaction.user.id,
      targetId: target.id,
      reason,
      durationMinutes: minutes,
    });

    let description = `**${target.tag}** has been timed out for ${minutes} minute(s). Reason: ${reason}\nرقم القضية: #${caseDoc.caseId}`;
    if (limit !== UNLIMITED) {
      const remaining = Math.max(limit - (usedThisWeek + 1), 0);
      description += `\nالمتبقي لك هذا الأسبوع: ${remaining} من أصل ${limit}.`;
    }

    await interaction.reply({ embeds: [successEmbed(settings, description)] });

    await sendModerationLog(interaction.guild, guildConfig, settings, {
      action: 'timeout',
      moderator: interaction.user,
      target,
      reason,
      durationMinutes: minutes,
      caseId: caseDoc.caseId,
      weeklyQuota: limit !== UNLIMITED ? { used: usedThisWeek + 1, limit } : null,
    });
  },
};
