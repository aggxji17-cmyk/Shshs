const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { isModerator } = require('../../utils/permissions');
const Warn = require('../../database/models/Warn');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('clearwarnings')
    .setDescription("Clear a member's warning history")
    .setDescriptionLocalizations({ ar: 'مسح سجل تحذيرات عضو', 'en-US': 'Clear a member\'s warning history' })
    .addUserOption((o) => o.setName('user').setDescription('The user to clear').setDescriptionLocalizations({ ar: 'المستخدم المراد مسح تحذيراته', 'en-US': 'The user to clear' }).setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isModerator(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'ليس لديك صلاحية استخدام هذا الأمر.')], ephemeral: true });
    }

    const target = interaction.options.getUser('user');
    const { deletedCount } = await Warn.deleteMany({ guildId: interaction.guildId, userId: target.id });

    await interaction.reply({ embeds: [successEmbed(settings, `Cleared ${deletedCount} warning(s) for **${target.tag}**.`)] });
  },
};
