const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');
const { sendModLog } = require('../../utils/modLog');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('massunban')
    .setDescription('Unban all banned users, or a specific list of user IDs')
    .setDescriptionLocalizations({ ar: 'رفع الحظر عن جميع المحظورين أو قائمة معينة من المعرفات', 'en-US': 'Unban all banned users, or a specific list of user IDs' })
    .addStringOption((o) => o.setName('user_ids').setDescription('Space or comma separated user IDs (leave empty to unban everyone)').setDescriptionLocalizations({ ar: 'معرّفات المستخدمين مفصولة بمسافة أو فاصلة (اتركه فارغاً لرفع الحظر عن الجميع)', 'en-US': 'Space or comma separated user IDs (leave empty to unban everyone)' }))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية إدارة السيرفر لتنفيذ رفع الحظر الجماعي.')], ephemeral: true });
    }

    await interaction.deferReply();

    const idsInput = interaction.options.getString('user_ids');
    const bans = await interaction.guild.bans.fetch();

    const targetIds = idsInput
      ? idsInput.split(/[\s,]+/).filter(Boolean)
      : [...bans.keys()];

    let success = 0;
    let failed = 0;
    for (const userId of targetIds) {
      try {
        await interaction.guild.members.unban(userId);
        success += 1;
      } catch {
        failed += 1;
      }
    }

    await interaction.editReply({
      embeds: [successEmbed(settings, `Unbanned **${success}** user(s)${failed ? ` (${failed} failed or not banned)` : ''}.`)],
    });

    await sendModLog(interaction.guild, guildConfig, settings, {
      title: 'Mass Unban',
      fields: [
        { name: 'Unbanned', value: `${success}`, inline: true },
        { name: 'Moderator', value: `${interaction.user}`, inline: true },
      ],
    });
  },
};
