const { SlashCommandBuilder, PermissionsBitField, MessageFlags, EmbedBuilder, ChannelType, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const musicRequestSchema = require('../../database/models/musicRequestSchema');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('setup-music-request')
        .setDescription('Configure a dedicated channel for music requests.')
        .addSubcommand(sub =>
            sub
                .setName('set')
                .setDescription('Set the music request channel.')
                .addChannelOption(opt =>
                    opt
                        .setName('channel')
                        .setDescription('The channel to use.')
                        .addChannelTypes(ChannelType.GuildText)
                        .setRequired(true)
                )
        )
        .addSubcommand(sub =>
            sub.setName('disable').setDescription('Disable the music request channel.')
        ),

    async execute(interaction, client) {
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) {
            return interaction.reply({
                content: `${client.emoji.error} | You need **Manage Server** permission to use this command.`,
                flags: MessageFlags.Ephemeral,
            });
        }

        const sub = interaction.options.getSubcommand();
        const guildId = interaction.guild.id;

        if (sub === 'set') {
            const channel = interaction.options.getChannel('channel');

            // Initial Embed
            const embed = new EmbedBuilder()
                .setTitle('🎶 Music Song Request')
                .setDescription('Send a song name or URL in this channel to start playing!')
                .setColor(client.config.embedColor)
                .setImage('https://i.imgur.com/8Q9S9S9.png') // Placeholder header
                .setFooter({ text: 'No song currently playing' });

            const row1 = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('mr-playpause').setLabel('⏯️').setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId('mr-skip').setLabel('⏭️').setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId('mr-stop').setLabel('⏹️').setStyle(ButtonStyle.Danger),
                new ButtonBuilder().setCustomId('mr-loop').setLabel('🔁').setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId('mr-shuffle').setLabel('🔀').setStyle(ButtonStyle.Secondary)
            );

            const row2 = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('mr-voldown').setLabel('🔉').setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId('mr-volup').setLabel('🔊').setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId('mr-clear').setLabel('🧹').setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId('mr-nowplaying').setLabel('▶ الآن').setStyle(ButtonStyle.Primary),
                new ButtonBuilder().setCustomId('mr-queue').setLabel('📋 القائمة').setStyle(ButtonStyle.Secondary)
            );

            const row3 = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId('mr-seek').setLabel('⏩ انتقال').setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId('mr-remove').setLabel('❌ حذف').setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId('mr-lyrics').setLabel('📝 كلمات').setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId('mr-filters').setLabel('🎛️ فلاتر').setStyle(ButtonStyle.Secondary),
                new ButtonBuilder().setCustomId('mr-history').setLabel('📜 سجل').setStyle(ButtonStyle.Secondary)
            );

            const message = await channel.send({ embeds: [embed], components: [row1, row2, row3] });

            await musicRequestSchema.findOneAndUpdate(
                { guildId },
                { channelId: channel.id, messageId: message.id },
                { upsert: true }
            );

            return interaction.reply({
                content: `${client.emoji.tick} | Music Request channel has been set to ${channel}.`,
                flags: MessageFlags.Ephemeral
            });
        }

        if (sub === 'disable') {
            const data = await musicRequestSchema.findOneAndDelete({ guildId });
            if (!data) {
                return interaction.reply({
                    content: `${client.emoji.error} | No Music Request channel is configured.`,
                    flags: MessageFlags.Ephemeral
                });
            }

            return interaction.reply({
                content: `${client.emoji.tick} | Music Request channel has been disabled.`,
                flags: MessageFlags.Ephemeral
            });
        }
    }
};
