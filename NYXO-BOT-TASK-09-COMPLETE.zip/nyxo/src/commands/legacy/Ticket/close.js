const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonStyle, ButtonBuilder } = require("discord.js");
const { Database } = require("st.db");
const db = new Database("/Json-db/Bots/ticketDB");
// Task 3 (state unification): a channel created by the NEW ticket system
// has no `TICKET-PANEL_<channelId>` entry in the old st.db store, so
// `ticket.author` below would be undefined and this command would throw
// (caught upstream as a generic error, closing nothing). Route new-system
// tickets through the exact same close flow as the new ticket_close
// button instead (services/ticketCloseService.js#closeTicket) so
// Discord state and the Ticket document stay in sync, and reuse the same
// staff check (isModerator) rather than duplicating close logic.
const Ticket = require('../../../database/models/Ticket');
const ticketState = require('../../../services/ticketStateManager');
const { isModerator } = require('../../../utils/permissions');
const { getGuildConfig, resolved } = require('../../../utils/resolveGuildSettings');
const { errorEmbed, successEmbed } = require('../../../utils/embeds');
const { closeTicket } = require('../../../services/ticketCloseService');

module.exports = {
    adminsOnly: false,
    data: new SlashCommandBuilder()
        .setName('close')
        .setDescription('إغلاق روم التذكرة الحالي'),
    
    /**
     * @param { import('discord.js').ChatInputCommandInteraction } interaction 
     */
    async execute(interaction) {
        const newTicket = await Ticket.findOne({ channelId: interaction.channel.id });
        if (newTicket) {
            const guildConfig = await getGuildConfig(interaction.guildId);
            const settings = resolved(guildConfig);

            if (!isModerator(interaction.member, guildConfig)) {
                return interaction.reply({ embeds: [errorEmbed(settings, 'الموظفون فقط يمكنهم إغلاق التذاكر.')], ephemeral: true });
            }
            if (newTicket.status === ticketState.TICKET_STATUS.CLOSED) {
                return interaction.reply({ embeds: [errorEmbed(settings, 'هذه التذكرة مغلقة بالفعل.')], ephemeral: true });
            }

            // Task 1: ack immediately (rule 13), then run the fixed close
            // order (send close prompt -> only then persist closed status)
            // and report the real outcome, instead of reporting success
            // before the close has actually completed.
            await interaction.deferReply();

            const result = await closeTicket(interaction.channel, guildConfig, settings, newTicket, interaction.user.id);

            if (!result.success) {
                return interaction.editReply({
                    embeds: [errorEmbed(settings, 'تعذر إغلاق التذكرة بسبب خطأ في إرسال أو حفظ حالة الإغلاق. حاول مرة أخرى.')],
                });
            }

            return interaction.editReply({ embeds: [successEmbed(settings, `تم إغلاق التذكرة بواسطة <@${interaction.user.id}>.`)] });
        }

        // --- Original old-system behaviour (st.db), unchanged ---
        const supportRoleID = db.get(`TICKET-PANEL_${interaction.channel.id}`)?.Support;

/*        if (!interaction.member.roles.cache.has(supportRoleID)) {
            return interaction.reply({ content: `:x: ليس لديك صلاحية إغلاق هذه التذكرة.`, ephemeral: true });
        }*/

        const ticket = db.get(`TICKET-PANEL_${interaction.channel.id}`);

        await interaction.channel.permissionOverwrites.edit(ticket.author, { ViewChannel: false });

        const embed2 = new EmbedBuilder()
            .setDescription(`تم اغلاق تذكرة بواسطة ${interaction.user}`)
            .setColor("Yellow");

        const embed = new EmbedBuilder()
            .setDescription("```لوحة فريق الدعم.```")
            .setColor("DarkButNotBlack");

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder().setCustomId('delete').setLabel('حذف').setStyle(ButtonStyle.Danger),
                new ButtonBuilder().setCustomId('Open').setLabel('فتح').setStyle(ButtonStyle.Success),
                new ButtonBuilder().setCustomId('Tran').setLabel('نسخة المحادثة').setStyle(ButtonStyle.Secondary)
            );

        await interaction.reply({ embeds: [embed2, embed], components: [row] });

        const logsRoomId = db.get(`LogsRoom_${interaction.guild.id}`);
        const logChannel = interaction.guild.channels.cache.get(logsRoomId);

        if (logChannel) {
            const logEmbed = new EmbedBuilder()
          .setAuthor({ name: interaction.user.username, iconURL: interaction.user.displayAvatarURL() })
          .setTitle('إغلاق تذكرة')
          .setFields(
            { name: `اسم التذكرة`, value: `${interaction.channel.name}` },
            { name: `صاحب التذكرة`, value: `${ticket.author}` },
            { name: `أُغلقت بواسطة`, value: `${interaction.user}` },
          )
          .setFooter({ text: interaction.user.username, iconURL: interaction.user.displayAvatarURL() });

            logChannel.send({ embeds: [logEmbed] });
        }
    }
};
