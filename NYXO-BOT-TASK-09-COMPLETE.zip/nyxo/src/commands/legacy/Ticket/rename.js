const { SlashCommandBuilder } = require("discord.js");
const { Database } = require("st.db");
const db = new Database("/Json-db/Bots/ticketDB");
// Task 3 (state unification): recognize tickets created by the NEW
// ticket system (Mongoose Ticket model) so this old command can work on
// them too, instead of silently blocking (old-only) or renaming the
// channel without telling the new system about it. Tickets that only
// exist in the old st.db store (no Ticket doc for this channel) fall
// straight through to the original, unmodified code path below.
const Ticket = require('../../../database/models/Ticket');
const ticketState = require('../../../services/ticketStateManager');
const { isModerator } = require('../../../utils/permissions');
const { getGuildConfig } = require('../../../utils/resolveGuildSettings');
const { buildStatusChannelName, buildCloseStatusChannelName, deriveBaseChannelName } = require('../../../utils/ticketPanel');

module.exports = {
    adminsOnly: false,
    data: new SlashCommandBuilder()
        .setName('rename')
        .setDescription('إعادة تسمية روم التذكرة الحالي')
        .addStringOption(option => 
            option
                .setName('name')
                .setDescription('أدخل الاسم الجديد للروم')
                .setRequired(true)
        ),
    
    /**
     * @param { import('discord.js').ChatInputCommandInteraction } interaction 
     */
    async execute(interaction) {
        const newName = interaction.options.getString('name');
        if (!newName) {
            return interaction.reply({ content: `لم يتم إدخال اسم جديد لروم التذكرة.`, ephemeral: true });
        }

        // New-system ticket: use the same staff check the new ticket
        // buttons use (isModerator), then rename the channel and update
        // ticket.baseChannelName so the next automatic status rename
        // (messageCreate.js / ticket_status_toggle / close/reopen - see
        // utils/ticketPanel.js + services/ticketCloseService.js) keeps
        // reapplying the 🟡/🟢/🔵/🔴 prefix on top of THIS new name
        // instead of reverting to the old one.
        const newTicket = await Ticket.findOne({ channelId: interaction.channel.id });
        if (newTicket) {
            const guildConfig = await getGuildConfig(interaction.guildId);
            if (!isModerator(interaction.member, guildConfig)) {
                return interaction.reply({ content: `:x: ليس لديك صلاحية إعادة تسمية هذه التذكرة.`, ephemeral: true });
            }

            // Task 5: strip any status-emoji prefix the admin may have
            // typed by hand (منع تضارب الألوان - never let two prefixes
            // stack, e.g. "🟡・🟡・my-problem"), then immediately
            // re-apply whichever single prefix matches the ticket's
            // CURRENT state - otherwise the channel would sit without
            // any color at all until the next unrelated status change.
            const baseName = deriveBaseChannelName(newName);
            newTicket.baseChannelName = baseName;

            const displayName =
                newTicket.status === ticketState.TICKET_STATUS.CLOSED
                    ? buildCloseStatusChannelName(baseName, newTicket.closeStatus)
                    : buildStatusChannelName(baseName, newTicket.replyStatus);

            await interaction.channel.setName(displayName);
            await newTicket.save();
            return interaction.reply({ content: `تمت إعادة تسمية التذكرة`, ephemeral: true });
        }

        // --- Original old-system behaviour (st.db), unchanged ---
        const dd = new Database("/Json-db/Bots/ticketDB");
        const supportRoleID = dd.get(`TICKET-PANEL_${interaction.channel.id}`)?.Support;

        if (!interaction.member.roles.cache.has(supportRoleID)) {
            return interaction.reply({ content: `:x: ليس لديك صلاحية إعادة تسمية هذه التذكرة.`, ephemeral: true });
        }

        const ticketData = db.get(`TICKET-PANEL_${interaction.channel.id}`);
        
        if (!ticketData) {
            return interaction.reply({ content: `> هذه القناة ليست تذكرة`, ephemeral: true });
        }

        await interaction.channel.setName(newName);
        return interaction.reply({ content: `تمت إعادة تسمية التذكرة`, ephemeral: true });
    }
};
