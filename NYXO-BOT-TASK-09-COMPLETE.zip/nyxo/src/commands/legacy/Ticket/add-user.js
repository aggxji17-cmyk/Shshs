const { SlashCommandBuilder } = require("discord.js");
const { Database } = require("st.db");
const db = new Database("/Json-db/Bots/ticketDB");
// Task 4 (add-user on new tickets): the ticket opener must be able to
// use this too, not just staff - and the permission granted to the
// added member must match exactly what the new system itself grants its
// own opener on creation (ViewChannel + SendMessages + ReadMessageHistory,
// see components/modals.js#ticket_create_modal), no more and no less.
const Ticket = require('../../../database/models/Ticket');
const { isModerator } = require('../../../utils/permissions');
const { getGuildConfig } = require('../../../utils/resolveGuildSettings');

module.exports = {
    adminsOnly: false,
    data: new SlashCommandBuilder()
        .setName('add-user')
        .setDescription('إضافة عضو إلى روم التذكرة الحالي')
        .addUserOption(option => 
            option
                .setName('user')
                .setDescription('اختر العضو المراد إضافته')
                .setRequired(true)
        ),
    
    /**
     * @param { import('discord.js').ChatInputCommandInteraction } interaction 
     */
    async execute(interaction) {
        const member = interaction.options.getMember('user');
        // Task 7 (real bug): getMember() returns null when the selected
        // user isn't currently resolvable as a guild member (e.g. they
        // left the server) - every branch below immediately dereferences
        // member.user.id, which would throw. Guard once, up front.
        if (!member) {
            return interaction.reply({ content: `:x: لم يتم العثور على هذا العضو في السيرفر.`, ephemeral: true });
        }

        const newTicket = await Ticket.findOne({ channelId: interaction.channel.id });
        if (newTicket) {
            const guildConfig = await getGuildConfig(interaction.guildId);
            const isOwner = interaction.user.id === newTicket.userId;
            if (!isOwner && !isModerator(interaction.member, guildConfig)) {
                return interaction.reply({ content: `:x: ليس لديك صلاحية إضافة أعضاء إلى هذه التذكرة.`, ephemeral: true });
            }

            // Same overwrite shape ticket_create_modal grants its own
            // opener - nothing more (no ManageChannels, no ManageMessages).
            await interaction.channel.permissionOverwrites.edit(member.user.id, {
                ViewChannel: true,
                SendMessages: true,
                ReadMessageHistory: true,
            });

            return interaction.reply({ content: `تمت إضافة ${member} إلى التذكرة ${interaction.channel}.` });
        }

        // --- Original old-system behaviour (st.db), unchanged ---
        const dd = new Database("/Json-db/Bots/ticketDB");
        const supportRoleID = dd.get(`TICKET-PANEL_${interaction.channel.id}`)?.Support;

        if (!interaction.member.roles.cache.has(supportRoleID)) {
            return interaction.reply({ content: `:x: ليس لديك صلاحية إضافة أعضاء إلى هذه التذكرة.`, ephemeral: true });
        }

        if (!db.has(`TICKET-PANEL_${interaction.channel.id}`)) {
            return interaction.reply({ content: `> هذه القناة ليست تذكرة`, ephemeral: true });
        }

        await interaction.channel.permissionOverwrites.edit(member.user.id, {
            ViewChannel: true,
            SendMessages: true
        });

        return interaction.reply({ content: `تمت إضافة ${member} إلى التذكرة ${interaction.channel}.` });
    }
};
