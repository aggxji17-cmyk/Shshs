const { SlashCommandBuilder } = require("discord.js");
const { Database } = require("st.db");
const db = new Database("/Json-db/Bots/ticketDB");
// Task 4 (remove-user on new tickets): the ticket opener must be able to
// use this too, not just staff. Also guards against the two "by mistake"
// cases the task calls out explicitly: removing the ticket's own owner,
// or removing a moderator/guild manager (isModerator - the same check
// this file and the rest of the new ticket system already use to define
// "staff").
const Ticket = require('../../../database/models/Ticket');
const { isModerator } = require('../../../utils/permissions');
const { getGuildConfig } = require('../../../utils/resolveGuildSettings');

module.exports = {
    adminsOnly: false,
    data: new SlashCommandBuilder()
        .setName('remove-user')
        .setDescription('إزالة عضو من روم التذكرة الحالي')
        .addUserOption(option => 
            option
                .setName('user')
                .setDescription('اختر العضو المراد إزالته')
                .setRequired(true)
        ),
    
    /**
     * @param { import('discord.js').ChatInputCommandInteraction } interaction 
     */
    async execute(interaction) {
        const member = interaction.options.getMember('user');
        // Task 7 (real bug, same as add-user.js): guard the null-member
        // case up front instead of crashing on member.user.id below.
        if (!member) {
            return interaction.reply({ content: `:x: لم يتم العثور على هذا العضو في السيرفر.`, ephemeral: true });
        }

        const newTicket = await Ticket.findOne({ channelId: interaction.channel.id });
        if (newTicket) {
            const guildConfig = await getGuildConfig(interaction.guildId);
            const isOwner = interaction.user.id === newTicket.userId;
            if (!isOwner && !isModerator(interaction.member, guildConfig)) {
                return interaction.reply({ content: `:x: ليس لديك صلاحية إزالة أعضاء من هذه التذكرة.`, ephemeral: true });
            }

            if (member.user.id === newTicket.userId) {
                return interaction.reply({ content: `:x: لا يمكنك إزالة صاحب التذكرة من تذكرته الخاصة.`, ephemeral: true });
            }
            if (isModerator(member, guildConfig)) {
                return interaction.reply({ content: `:x: لا يمكنك إزالة عضو من فريق الدعم من هذه التذكرة.`, ephemeral: true });
            }

            await interaction.channel.permissionOverwrites.edit(member.user.id, {
                ViewChannel: false,
                SendMessages: false
            });

            return interaction.reply({ content: `تمت إزالة ${member} من التذكرة ${interaction.channel}.` });
        }

        // --- Original old-system behaviour (st.db), unchanged ---
        const dd = new Database("/Json-db/Bots/ticketDB");
        const supportRoleID = dd.get(`TICKET-PANEL_${interaction.channel.id}`)?.Support;

        if (!interaction.member.roles.cache.has(supportRoleID)) {
            return interaction.reply({ content: `:x: ليس لديك صلاحية إزالة أعضاء من هذه التذكرة.`, ephemeral: true });
        }

        if (!db.has(`TICKET-PANEL_${interaction.channel.id}`)) {
            return interaction.reply({ content: `> هذه القناة ليست تذكرة`, ephemeral: true });
        }

        await interaction.channel.permissionOverwrites.edit(member.user.id, {
            ViewChannel: false,
            SendMessages: false
        });

        return interaction.reply({ content: `تمت إزالة ${member} من التذكرة ${interaction.channel}.` });
    }
};
