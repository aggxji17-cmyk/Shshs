const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const { Database } = require("st.db");
const db = new Database('/Json-db/Bots/ticketDB');
// Task 3 (state unification): for a channel created by the NEW ticket
// system, reuse the exact same permanent-deletion path as the 🗑️
// button (services/ticketCloseService.js#finalizeTicketDeletion) instead
// of a raw channel.delete() that would leave the Ticket document showing
// the ticket as still open/not-deleted after Discord already removed the
// channel. finalizeTicketDeletion builds the archive, logs it, marks
// permanentlyDeletedAt, and deletes the channel - the same single path
// already used everywhere else in the new system, so nothing is
// duplicated here.
const Ticket = require('../../../database/models/Ticket');
const { isModerator } = require('../../../utils/permissions');
const { getGuildConfig, resolved } = require('../../../utils/resolveGuildSettings');
const { errorEmbed } = require('../../../utils/embeds');
const { finalizeTicketDeletion } = require('../../../services/ticketCloseService');

module.exports = {
    adminsOnly: false,
    data: new SlashCommandBuilder()
        .setName('delete')
        .setDescription('حذف روم التذكرة الحالي نهائياً'),
        
    async execute(interaction) {
        const newTicket = await Ticket.findOne({ channelId: interaction.channel.id });
        if (newTicket) {
            const guildConfig = await getGuildConfig(interaction.guildId);
            const settings = resolved(guildConfig);

            if (!isModerator(interaction.member, guildConfig)) {
                return interaction.reply({ embeds: [errorEmbed(settings, 'الموظفون فقط يمكنهم حذف التذاكر نهائياً.')], ephemeral: true });
            }
            if (newTicket.permanentlyDeletedAt) {
                return interaction.reply({ embeds: [errorEmbed(settings, 'هذه التذكرة محذوفة بالفعل.')], ephemeral: true });
            }

            const embed = new EmbedBuilder()
                .setColor('Red')
                .setDescription('سيتم حذف التذكرة خلال ثوانٍ');
            await interaction.reply({ embeds: [embed] });

            await finalizeTicketDeletion(interaction.client, interaction.guild, guildConfig, settings, newTicket, interaction.channel, interaction.user.id);
            return;
        }

        // --- Original old-system behaviour (st.db), unchanged ---
        const Support = db.get(`TICKET-PANEL_${interaction.channel.id}`)?.Support;
        if (!interaction.member.roles.cache.has(Support)) {
            return interaction.reply({ content: ':x: فريق الدعم فقط', ephemeral: true });
        } 

        if (!db.has(`TICKET-PANEL_${interaction.channel.id}`)) {
            return interaction.reply({ content: 'هذه القناة ليست تذكرة', ephemeral: true });
        }

        const embed = new EmbedBuilder()
            .setColor('Red')
            .setDescription('سيتم حذف التذكرة خلال ثوانٍ');
        
        await interaction.reply({ embeds: [embed] });
        
        setTimeout(() => {
            interaction.channel.delete();
        }, 4500);

        const Logs = db.get(`LogsRoom_${interaction.guild.id}`);
        const Log = interaction.guild.channels.cache.get(Logs);
        const Ticket = db.get(`TICKET-PANEL_${interaction.channel.id}`);
        const logEmbed = new EmbedBuilder()
            .setAuthor({ name: interaction.user.username, iconURL: interaction.user.displayAvatarURL() })
            .setTitle('حذف تذكرة')
            .addFields(
                { name: 'اسم التذكرة', value: `${interaction.channel.name}` },
                { name: 'صاحب التذكرة', value: `${Ticket.author}` },
                { name: 'حُذفت بواسطة', value: `${interaction.user}` },
            )
            .setFooter({ text: interaction.user.username, iconURL: interaction.user.displayAvatarURL() });

        Log?.send({ embeds: [logEmbed] });
        db.delete(`TICKET-PANEL_${interaction.channel.id}`);
    }
}
