const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { getGuildConfig, resolved, invalidateGuildConfig } = require('../../utils/resolveGuildSettings');
const { baseEmbed, successEmbed, errorEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');
const { applyPlaceholders } = require('../../utils/placeholders');

const HEX_REGEX = /^#([0-9A-F]{6})$/i;
const URL_REGEX = /^https?:\/\/\S+$/i;
const PLACEHOLDER_HELP = 'Placeholders: `{user}` `{username}` `{tag}` `{server}` `{memberCount}` `{ordinal}`';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setwelcome')
    .setDescription('Configure and preview the welcome system for new members')
    .setDescriptionLocalizations({ ar: 'إعداد ومعاينة نظام الترحيب بالأعضاء الجدد', 'en-US': 'Configure and preview the welcome system for new members' })
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((sc) =>
      sc
        .setName('channel')
        .setDescription('Set the channel welcome messages are posted in (and enable them)')
        .setDescriptionLocalizations({ ar: 'تحديد القناة التي تُنشر فيها رسائل الترحيب (وتفعيلها)', 'en-US': 'Set the channel welcome messages are posted in (and enable them)' })
        .addChannelOption((o) => o.setName('channel').setDescription('Channel to post welcome messages in').setDescriptionLocalizations({ ar: 'القناة التي تُنشر فيها رسائل الترحيب', 'en-US': 'Channel to post welcome messages in' }).addChannelTypes(ChannelType.GuildText).setRequired(true))
    )
    .addSubcommand((sc) =>
      sc
        .setName('message')
        .setDescription('Set the welcome message text shown in the channel')
        .setDescriptionLocalizations({ ar: 'تحديد نص رسالة الترحيب المعروضة في القناة', 'en-US': 'Set the welcome message text shown in the channel' })
        .addStringOption((o) => o.setName('text').setDescription(PLACEHOLDER_HELP).setDescriptionLocalizations({ ar: 'استخدم {user} و {username} و {tag} و {server} و {memberCount} و {ordinal}', 'en-US': PLACEHOLDER_HELP }).setRequired(true).setMaxLength(1500))
    )
    .addSubcommand((sc) =>
      sc
        .setName('image')
        .setDescription('Set (or clear) a banner image shown in the welcome embed')
        .setDescriptionLocalizations({ ar: 'تحديد (أو إزالة) صورة بانر تظهر في رسالة الترحيب', 'en-US': 'Set (or clear) a banner image shown in the welcome embed' })
        .addStringOption((o) => o.setName('url').setDescription('Direct image URL, or leave empty to remove the banner').setDescriptionLocalizations({ ar: 'رابط صورة مباشر، أو اتركه فارغاً لإزالة البانر', 'en-US': 'Direct image URL, or leave empty to remove the banner' }))
    )
    .addSubcommand((sc) =>
      sc
        .setName('color')
        .setDescription('Set (or clear) a custom embed color just for welcome messages')
        .setDescriptionLocalizations({ ar: 'تحديد (أو إزالة) لون مخصص لرسائل الترحيب فقط', 'en-US': 'Set (or clear) a custom embed color just for welcome messages' })
        .addStringOption((o) => o.setName('hex').setDescription('Hex color like #5865F2, or leave empty to use the default color').setDescriptionLocalizations({ ar: 'لون Hex مثل #5865F2، أو اتركه فارغاً لاستخدام اللون الافتراضي', 'en-US': 'Hex color like #5865F2, or leave empty to use the default color' }))
    )
    .addSubcommand((sc) =>
      sc
        .setName('dm')
        .setDescription('Also (or instead) send new members a private welcome DM')
        .setDescriptionLocalizations({ ar: 'إرسال رسالة ترحيب خاصة (DM) للأعضاء الجدد أيضاً', 'en-US': 'Also (or instead) send new members a private welcome DM' })
        .addBooleanOption((o) => o.setName('enabled').setDescription('Whether to DM new members a welcome message').setDescriptionLocalizations({ ar: 'هل يتم إرسال رسالة ترحيب خاصة للأعضاء الجدد', 'en-US': 'Whether to DM new members a welcome message' }).setRequired(true))
        .addStringOption((o) => o.setName('text').setDescription('DM text. Leave empty to reuse the channel message').setDescriptionLocalizations({ ar: 'نص الرسالة الخاصة. اتركه فارغاً لاستخدام نص رسالة القناة', 'en-US': 'DM text. Leave empty to reuse the channel message' }).setMaxLength(1500))
    )
    .addSubcommand((sc) =>
      sc
        .setName('disable')
        .setDescription('Turn off channel welcome messages (settings are kept)')
        .setDescriptionLocalizations({ ar: 'إيقاف رسائل الترحيب في القناة (يتم الاحتفاظ بالإعدادات)', 'en-US': 'Turn off channel welcome messages (settings are kept)' })
    )
    .addSubcommand((sc) =>
      sc
        .setName('test')
        .setDescription('Preview the welcome message as if you had just joined')
        .setDescriptionLocalizations({ ar: 'معاينة رسالة الترحيب كأنك انضممت للتو', 'en-US': 'Preview the welcome message as if you had just joined' })
    )
    // TASK43: merged from the standalone /setgoodbye command - goodbye
    // messages are the same "welcome system" family (guildConfig.welcome
    // vs guildConfig.goodbye) and were previously split across two
    // top-level commands for no functional reason. Behavior is unchanged;
    // only the entry point moved from `/setgoodbye` to `/setwelcome
    // goodbye`.
    .addSubcommand((sc) =>
      sc
        .setName('goodbye')
        .setDescription('Configure the goodbye message for departing members')
        .setDescriptionLocalizations({ ar: 'إعداد رسالة الوداع للأعضاء المغادرين', 'en-US': 'Configure the goodbye message for departing members' })
        .addChannelOption((o) => o.setName('channel').setDescription('Channel to post goodbye messages in').setDescriptionLocalizations({ ar: 'القناة التي تُنشر فيها رسائل الوداع', 'en-US': 'Channel to post goodbye messages in' }).addChannelTypes(ChannelType.GuildText).setRequired(true))
        .addStringOption((o) => o.setName('message').setDescription('Use {user}, {username}, {server}, {memberCount} as placeholders').setDescriptionLocalizations({ ar: 'استخدم {user} و {username} و {server} و {memberCount} كمتغيرات', 'en-US': 'Use {user}, {username}, {server}, {memberCount} as placeholders' }))
    ),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You need Manage Server permission to use this command.')], ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();

    if (sub === 'channel') return handleChannel(interaction, settings, guildConfig);
    if (sub === 'message') return handleMessage(interaction, settings, guildConfig);
    if (sub === 'image') return handleImage(interaction, settings, guildConfig);
    if (sub === 'color') return handleColor(interaction, settings, guildConfig);
    if (sub === 'dm') return handleDm(interaction, settings, guildConfig);
    if (sub === 'disable') return handleDisable(interaction, settings, guildConfig);
    if (sub === 'test') return handleTest(interaction, settings, guildConfig);
    if (sub === 'goodbye') return handleGoodbye(interaction, settings, guildConfig);
  },
};

async function handleChannel(interaction, settings, guildConfig) {
  const channel = interaction.options.getChannel('channel', true);
  guildConfig.welcome.channelId = channel.id;
  guildConfig.welcome.enabled = true;
  await guildConfig.save();
  invalidateGuildConfig(interaction.guildId);
  return interaction.reply({ embeds: [successEmbed(settings, `Welcome messages will now be posted in ${channel}.`)] });
}

async function handleMessage(interaction, settings, guildConfig) {
  const text = interaction.options.getString('text', true);
  guildConfig.welcome.message = text;
  await guildConfig.save();
  invalidateGuildConfig(interaction.guildId);
  return interaction.reply({ embeds: [successEmbed(settings, `Welcome message updated. Try \`/setwelcome test\` to preview it.\n\n${PLACEHOLDER_HELP}`)] });
}

async function handleImage(interaction, settings, guildConfig) {
  const url = interaction.options.getString('url');
  if (url && !URL_REGEX.test(url)) {
    return interaction.reply({ embeds: [errorEmbed(settings, 'That doesn\'t look like a valid image URL - it should start with `http://` or `https://`.')], ephemeral: true });
  }

  guildConfig.welcome.imageUrl = url || null;
  await guildConfig.save();
  invalidateGuildConfig(interaction.guildId);
  return interaction.reply({ embeds: [successEmbed(settings, url ? 'Welcome banner image set.' : 'Welcome banner image removed.')] });
}

async function handleColor(interaction, settings, guildConfig) {
  const hex = interaction.options.getString('hex');
  if (hex && !HEX_REGEX.test(hex)) {
    return interaction.reply({ embeds: [errorEmbed(settings, 'Color must be a valid hex code, e.g. `#5865F2`.')], ephemeral: true });
  }

  guildConfig.welcome.color = hex || null;
  await guildConfig.save();
  invalidateGuildConfig(interaction.guildId);
  return interaction.reply({ embeds: [successEmbed(settings, hex ? `Welcome embed color set to \`${hex}\`.` : 'Welcome embed color reset to the server default.')] });
}

async function handleDm(interaction, settings, guildConfig) {
  const enabled = interaction.options.getBoolean('enabled', true);
  const text = interaction.options.getString('text');

  guildConfig.welcome.dm.enabled = enabled;
  if (text) guildConfig.welcome.dm.message = text;
  await guildConfig.save();
  invalidateGuildConfig(interaction.guildId);

  const description = enabled
    ? `New members will now also receive a private welcome DM.${!guildConfig.welcome.dm.message ? ' (Reusing the channel message since no DM text is set.)' : ''}`
    : 'Welcome DMs are now disabled.';
  return interaction.reply({ embeds: [successEmbed(settings, description)] });
}

async function handleDisable(interaction, settings, guildConfig) {
  if (!guildConfig.welcome.enabled) {
    return interaction.reply({ embeds: [errorEmbed(settings, 'Channel welcome messages are already disabled.')], ephemeral: true });
  }
  guildConfig.welcome.enabled = false;
  await guildConfig.save();
  invalidateGuildConfig(interaction.guildId);
  return interaction.reply({ embeds: [successEmbed(settings, 'Channel welcome messages have been disabled. Settings (message, image, color) are kept for next time.')] });
}

async function handleTest(interaction, settings, guildConfig) {
  const member = interaction.member;
  const embed = baseEmbed(settings)
    .setTitle('👋 Welcome!')
    .setDescription(applyPlaceholders(guildConfig.welcome.message, member))
    .setThumbnail(member.user.displayAvatarURL());
  if (guildConfig.welcome.color) embed.setColor(guildConfig.welcome.color);
  if (guildConfig.welcome.imageUrl) embed.setImage(guildConfig.welcome.imageUrl);

  const status = guildConfig.welcome.enabled && guildConfig.welcome.channelId
    ? `Preview of the channel message (this is a preview only - nothing was posted to <#${guildConfig.welcome.channelId}>).`
    : 'Preview only - channel welcome messages are currently disabled, so real joins won\u2019t post this.';

  await interaction.reply({ content: status, embeds: [embed], ephemeral: true });

  if (guildConfig.welcome.dm?.enabled) {
    const dmTemplate = guildConfig.welcome.dm.message || guildConfig.welcome.message;
    const dmEmbed = baseEmbed(settings)
      .setTitle(`👋 Welcome to ${interaction.guild.name}!`)
      .setDescription(applyPlaceholders(dmTemplate, member))
      .setThumbnail(interaction.guild.iconURL() || null);
    if (guildConfig.welcome.color) dmEmbed.setColor(guildConfig.welcome.color);
    await interaction.followUp({ content: 'Preview of the welcome DM:', embeds: [dmEmbed], ephemeral: true });
  }
}

// TASK43: merged from /setgoodbye - identical behavior, just reached via
// `/setwelcome goodbye` now.
async function handleGoodbye(interaction, settings, guildConfig) {
  const channel = interaction.options.getChannel('channel');
  const message = interaction.options.getString('message');

  guildConfig.goodbye.channelId = channel.id;
  guildConfig.goodbye.enabled = true;
  if (message) guildConfig.goodbye.message = message;

  await guildConfig.save();
  invalidateGuildConfig(interaction.guildId);

  return interaction.reply({ embeds: [successEmbed(settings, `Goodbye messages will now be posted in ${channel}.`)] });
}
