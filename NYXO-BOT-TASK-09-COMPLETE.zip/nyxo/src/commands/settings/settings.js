const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
// Task 46: فحص الصلاحيات وفتح الواجهة عبر commandRouter مركزياً.
const { routeCommand } = require('../../utils/commandRouter');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('settings')
    .setDescription('Open the general settings dashboard')
    .setDescriptionLocalizations({ ar: 'فتح لوحة الإعدادات العامة', 'en-US': 'Open the general settings dashboard' })
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction) {
    // Task 46: فحص الصلاحيات والتسجيل وفتح الواجهة عبر Router مركزياً.
    return routeCommand(interaction, 'settings');
  },
};
