const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { getGuildConfig, resolved, invalidateGuildConfig } = require('../../utils/resolveGuildSettings');
const { baseEmbed, successEmbed, errorEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');
const { resolveXpRange, setUserXp, addUserXp, resetUserXp, MAX_ADMIN_XP } = require('../../services/levelingService');

// TASK23: shared by the excluded-channels/excluded-roles list subcommands
// and the `view` summary below. Keeps a long exclusion list from ever
// pushing an embed field past Discord's 1024-char field limit (which
// would otherwise throw when the reply is sent) - trims to what fits and
// says how many more there are instead of truncating mid-mention.
function joinWithinLimit(mentions, limit = 1024) {
  if (!mentions.length) return 'None';
  let out = '';
  for (let i = 0; i < mentions.length; i++) {
    const next = out ? `${out}, ${mentions[i]}` : mentions[i];
    const remaining = mentions.length - i - 1;
    const suffixIfStopHere = remaining > 0 ? ` (+${remaining} more)` : '';
    if ((next + suffixIfStopHere).length > limit) {
      return `${out} (+${mentions.length - i} more)`;
    }
    out = next;
  }
  return out;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('levelingconfig')
    .setDescription('Configure the XP/leveling system')
    .setDescriptionLocalizations({ ar: 'إعداد نظام نقاط الخبرة والمستويات', 'en-US': 'Configure the XP/leveling system' })
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((s) => s.setName('toggle').setDescription('Enable or disable leveling')
      .setDescriptionLocalizations({ ar: 'تفعيل أو تعطيل نظام المستويات', 'en-US': 'Enable or disable leveling' }))
    .addSubcommand((s) =>
      s
        .setName('announce')
        .setDescription('Manage level-up announcements')
      .setDescriptionLocalizations({ ar: 'إدارة إعلانات ترقية المستوى', 'en-US': 'Manage level-up announcements' })
        .addBooleanOption((o) => o.setName('enabled').setDescription('Turn level-up announcements on or off').setDescriptionLocalizations({ ar: 'تشغيل أو إيقاف إعلانات ترقية المستوى', 'en-US': 'Turn level-up announcements on or off' }))
        .addChannelOption((o) => o.setName('channel').setDescription('Announcement channel').setDescriptionLocalizations({ ar: 'قناة الإعلان', 'en-US': 'Announcement channel' }).addChannelTypes(ChannelType.GuildText))
        .addBooleanOption((o) => o.setName('clear_channel').setDescription('Remove the fixed announcement channel (announce in the channel the level-up happened in)').setDescriptionLocalizations({ ar: 'إزالة قناة الإعلان المحددة (الإعلان في نفس قناة الرسالة)', 'en-US': 'Remove the fixed announcement channel' }))
    )
    .addSubcommand((s) =>
      s
        .setName('xp')
        .setDescription('Set XP gained per message and cooldown')
      .setDescriptionLocalizations({ ar: 'تعيين نقاط الخبرة لكل رسالة ومدة التبريد', 'en-US': 'Set XP gained per message and cooldown' })
        .addIntegerOption((o) => o.setName('amount').setDescription('XP per message').setDescriptionLocalizations({ ar: 'نقاط الخبرة لكل رسالة', 'en-US': 'XP per message' }).setMinValue(1).setMaxValue(1000).setRequired(true))
        .addIntegerOption((o) => o.setName('cooldown').setDescription('Cooldown in seconds').setDescriptionLocalizations({ ar: 'مدة التبريد بالثواني', 'en-US': 'Cooldown in seconds' }).setMinValue(0).setMaxValue(3600).setRequired(true))
    )
    // TASK23: xpMin/xpMax already existed on the schema (see GuildConfig.js
    // leveling comment) and levelingService.resolveXpRange() already reads
    // them when both are set - they just had no command to write them.
    // Kept as a separate subcommand instead of folding into `xp` above so
    // the existing `xp` (fixed xpPerMessage) subcommand's required options
    // don't change shape for anyone already using it.
    .addSubcommand((s) =>
      s
        .setName('xprange')
        .setDescription('Set a random XP-per-message range (overrides the fixed XP amount)')
        .setDescriptionLocalizations({ ar: 'تعيين نطاق عشوائي لنقاط الخبرة لكل رسالة (يتجاوز القيمة الثابتة)', 'en-US': 'Set a random XP-per-message range' })
        .addIntegerOption((o) => o.setName('min').setDescription('Minimum XP per message').setDescriptionLocalizations({ ar: 'أقل نقاط خبرة لكل رسالة', 'en-US': 'Minimum XP per message' }).setMinValue(1).setMaxValue(1000).setRequired(true))
        .addIntegerOption((o) => o.setName('max').setDescription('Maximum XP per message').setDescriptionLocalizations({ ar: 'أعلى نقاط خبرة لكل رسالة', 'en-US': 'Maximum XP per message' }).setMinValue(1).setMaxValue(1000).setRequired(true))
    )
    // TASK19: rank-card / leaderboard-image customization. All options
    // optional so admins can change just one thing at a time; omitted
    // options leave that setting untouched.
    .addSubcommand((s) =>
      s
        .setName('card')
        .setDescription('Customize the /rank and /leaderboard images')
        .setDescriptionLocalizations({ ar: 'تخصيص صور /rank و /leaderboard', 'en-US': 'Customize the /rank and /leaderboard images' })
        .addBooleanOption((o) =>
          o
            .setName('enabled')
            .setDescription('Show the generated image (off = plain text embed)')
            .setDescriptionLocalizations({ ar: 'إظهار الصورة (إيقاف = عرض نصي)', 'en-US': 'Show the generated image (off = plain text embed)' })
        )
        .addStringOption((o) =>
          o
            .setName('theme')
            .setDescription('Background theme')
            .setDescriptionLocalizations({ ar: 'خلفية البطاقة', 'en-US': 'Background theme' })
            .addChoices(
              { name: 'Aurora (default)', value: 'aurora' },
              { name: 'Classic', value: 'classic' },
              { name: 'Ember', value: 'ember' },
              { name: 'Forest', value: 'forest' }
            )
        )
        .addStringOption((o) =>
          o
            .setName('accent_color')
            .setDescription('Hex color, e.g. #5865F2 (leave empty to use the server embed color)')
            .setDescriptionLocalizations({ ar: 'لون بصيغة hex مثل #5865F2 (اتركه فارغًا لاستخدام لون السيرفر)', 'en-US': 'Hex color, e.g. #5865F2' })
        )
        .addStringOption((o) =>
          o
            .setName('progress_color')
            .setDescription('Hex color for the progress bar fill (leave empty to match the accent color)')
            .setDescriptionLocalizations({ ar: 'لون شريط التقدم بصيغة hex (اتركه فارغًا ليطابق اللون الأساسي)', 'en-US': 'Hex color for the progress bar fill' })
        )
    )
    // TASK23: excludedChannelIds already existed on the schema and was
    // already enforced in messageCreate.js (handleLeveling) - it just had
    // no command to manage it. add/remove/list mirrors the pattern used
    // by other list-style settings commands in the project.
    .addSubcommandGroup((g) =>
      g
        .setName('excluded-channels')
        .setDescription('Manage channels where messages never grant XP')
        .setDescriptionLocalizations({ ar: 'إدارة القنوات المستثناة من نقاط الخبرة', 'en-US': 'Manage channels where messages never grant XP' })
        .addSubcommand((s) =>
          s.setName('add').setDescription('Exclude a channel from granting XP')
            .setDescriptionLocalizations({ ar: 'استثناء قناة من منح نقاط الخبرة', 'en-US': 'Exclude a channel from granting XP' })
            .addChannelOption((o) => o.setName('channel').setDescription('Channel to exclude').setDescriptionLocalizations({ ar: 'القناة المراد استثناؤها', 'en-US': 'Channel to exclude' }).addChannelTypes(ChannelType.GuildText).setRequired(true))
        )
        .addSubcommand((s) =>
          s.setName('remove').setDescription('Remove a channel from the exclusion list')
            .setDescriptionLocalizations({ ar: 'إزالة قناة من قائمة الاستثناء', 'en-US': 'Remove a channel from the exclusion list' })
            .addChannelOption((o) => o.setName('channel').setDescription('Channel to remove').setDescriptionLocalizations({ ar: 'القناة المراد إزالتها', 'en-US': 'Channel to remove' }).addChannelTypes(ChannelType.GuildText).setRequired(true))
        )
        .addSubcommand((s) =>
          s.setName('list').setDescription('List excluded channels')
            .setDescriptionLocalizations({ ar: 'عرض القنوات المستثناة', 'en-US': 'List excluded channels' })
        )
    )
    // TASK23: same as excluded-channels but for excludedRoleIds.
    .addSubcommandGroup((g) =>
      g
        .setName('excluded-roles')
        .setDescription('Manage roles whose members never gain XP')
        .setDescriptionLocalizations({ ar: 'إدارة الرولات المستثناة من نقاط الخبرة', 'en-US': 'Manage roles whose members never gain XP' })
        .addSubcommand((s) =>
          s.setName('add').setDescription('Exclude a role from granting XP')
            .setDescriptionLocalizations({ ar: 'استثناء رول من منح نقاط الخبرة', 'en-US': 'Exclude a role from granting XP' })
            .addRoleOption((o) => o.setName('role').setDescription('Role to exclude').setDescriptionLocalizations({ ar: 'الرول المراد استثناؤه', 'en-US': 'Role to exclude' }).setRequired(true))
        )
        .addSubcommand((s) =>
          s.setName('remove').setDescription('Remove a role from the exclusion list')
            .setDescriptionLocalizations({ ar: 'إزالة رول من قائمة الاستثناء', 'en-US': 'Remove a role from the exclusion list' })
            .addRoleOption((o) => o.setName('role').setDescription('Role to remove').setDescriptionLocalizations({ ar: 'الرول المراد إزالته', 'en-US': 'Role to remove' }).setRequired(true))
        )
        .addSubcommand((s) =>
          s.setName('list').setDescription('List excluded roles')
            .setDescriptionLocalizations({ ar: 'عرض الرولات المستثناة', 'en-US': 'List excluded roles' })
        )
    )
    // TASK25: role-based XP multipliers (e.g. Boosters/a premium role
    // earning extra XP per message). Same add/remove/list shape as
    // excluded-channels/excluded-roles above for consistency.
    .addSubcommandGroup((g) =>
      g
        .setName('xp-multiplier')
        .setDescription('Manage roles that earn bonus XP per message')
        .setDescriptionLocalizations({ ar: 'إدارة الرولات التي تحصل على نقاط خبرة إضافية', 'en-US': 'Manage roles that earn bonus XP per message' })
        .addSubcommand((s) =>
          s
            .setName('add')
            .setDescription('Give a role a multiplier on XP gained per message')
            .setDescriptionLocalizations({ ar: 'منح رول مضاعفًا لنقاط الخبرة المكتسبة لكل رسالة', 'en-US': 'Give a role a multiplier on XP gained per message' })
            .addRoleOption((o) => o.setName('role').setDescription('Role to boost').setDescriptionLocalizations({ ar: 'الرول المراد تعزيزه', 'en-US': 'Role to boost' }).setRequired(true))
            .addNumberOption((o) =>
              o
                .setName('multiplier')
                .setDescription('e.g. 1.5 for +50%, 2 for double XP')
                .setDescriptionLocalizations({ ar: 'مثال: 1.5 لزيادة 50%، 2 لمضاعفة الخبرة', 'en-US': 'e.g. 1.5 for +50%, 2 for double XP' })
                .setMinValue(0.1)
                .setMaxValue(10)
                .setRequired(true)
            )
        )
        .addSubcommand((s) =>
          s.setName('remove').setDescription('Remove a role\'s XP multiplier')
            .setDescriptionLocalizations({ ar: 'إزالة مضاعف الخبرة لرول', 'en-US': "Remove a role's XP multiplier" })
            .addRoleOption((o) => o.setName('role').setDescription('Role to remove').setDescriptionLocalizations({ ar: 'الرول المراد إزالته', 'en-US': 'Role to remove' }).setRequired(true))
        )
        .addSubcommand((s) =>
          s.setName('list').setDescription('List every configured XP multiplier')
            .setDescriptionLocalizations({ ar: 'عرض جميع مضاعفات الخبرة المُعدة', 'en-US': 'List every configured XP multiplier' })
        )
    )
    // TASK26 (Voice XP): admin control for voice XP, folded into the
    // existing /levelingconfig instead of a new top-level command (per
    // task spec - "بدون إنشاء Slash Command رئيسي جديد"). Same
    // enable/disable/xp/view shape the task asked for, matching the
    // add/remove/list and set-xp/add-xp/reset patterns already used by
    // the groups above for consistency.
    .addSubcommandGroup((g) =>
      g
        .setName('voice')
        .setDescription('Configure Voice XP (uses the same leveling system as message XP)')
        .setDescriptionLocalizations({ ar: 'إعداد نقاط خبرة الصوت (يستخدم نفس نظام المستويات الحالي)', 'en-US': 'Configure Voice XP' })
        .addSubcommand((s) =>
          s.setName('enable').setDescription('Enable XP for time spent in voice channels')
            .setDescriptionLocalizations({ ar: 'تفعيل نقاط الخبرة للوقت في الرومات الصوتية', 'en-US': 'Enable Voice XP' })
        )
        .addSubcommand((s) =>
          s.setName('disable').setDescription('Disable Voice XP (message XP is unaffected)')
            .setDescriptionLocalizations({ ar: 'تعطيل نقاط خبرة الصوت (لا يؤثر على نقاط خبرة الرسائل)', 'en-US': 'Disable Voice XP' })
        )
        .addSubcommand((s) =>
          s
            .setName('xp')
            .setDescription('Set XP granted per full minute in an eligible voice channel')
            .setDescriptionLocalizations({ ar: 'تعيين نقاط الخبرة لكل دقيقة كاملة في روم صوتي مؤهل', 'en-US': 'Set XP per minute in voice' })
            .addIntegerOption((o) =>
              o.setName('amount').setDescription('XP per minute').setDescriptionLocalizations({ ar: 'نقاط الخبرة لكل دقيقة', 'en-US': 'XP per minute' }).setMinValue(1).setMaxValue(1000).setRequired(true)
            )
        )
        // TASK27: minimum number of human members required in a channel
        // for it to grant Voice XP - was hardcoded at 2, now configurable
        // per spec (see GuildConfig.js's voiceMinMembers comment).
        .addSubcommand((s) =>
          s
            .setName('min-members')
            .setDescription('Set the minimum human members required in a channel to grant Voice XP')
            .setDescriptionLocalizations({ ar: 'تعيين الحد الأدنى للأعضاء البشريين لمنح نقاط خبرة الصوت', 'en-US': 'Set the minimum human members for Voice XP' })
            .addIntegerOption((o) =>
              o.setName('amount').setDescription('Minimum human members (1 = can earn XP alone)').setDescriptionLocalizations({ ar: 'الحد الأدنى للأعضاء البشريين (1 = يمكن الحصول على الخبرة وحده)', 'en-US': 'Minimum human members (1 = alone allowed)' }).setMinValue(1).setMaxValue(50).setRequired(true)
            )
        )
        .addSubcommand((s) =>
          s.setName('view').setDescription('Show the current Voice XP configuration')
            .setDescriptionLocalizations({ ar: 'عرض إعدادات نقاط خبرة الصوت الحالية', 'en-US': 'Show the current Voice XP configuration' })
        )
    )
    // TASK25: manual per-member XP administration (correcting a mistake,
    // fixing an exploit, seeding a migrated member's XP) - see
    // services/levelingService.js's setUserXp/addUserXp/resetUserXp for
    // why this deliberately never triggers reward grants/announcements.
    .addSubcommandGroup((g) =>
      g
        .setName('member')
        .setDescription("Manually adjust a specific member's XP")
        .setDescriptionLocalizations({ ar: 'تعديل نقاط خبرة عضو معين يدويًا', 'en-US': "Manually adjust a specific member's XP" })
        .addSubcommand((s) =>
          s
            .setName('set-xp')
            .setDescription("Set a member's total XP to an exact value")
            .setDescriptionLocalizations({ ar: 'تعيين إجمالي نقاط خبرة عضو لقيمة محددة', 'en-US': "Set a member's total XP to an exact value" })
            .addUserOption((o) => o.setName('user').setDescription('The member').setDescriptionLocalizations({ ar: 'العضو', 'en-US': 'The member' }).setRequired(true))
            .addIntegerOption((o) => o.setName('amount').setDescription('New total XP').setDescriptionLocalizations({ ar: 'إجمالي نقاط الخبرة الجديد', 'en-US': 'New total XP' }).setMinValue(0).setMaxValue(MAX_ADMIN_XP).setRequired(true))
        )
        .addSubcommand((s) =>
          s
            .setName('add-xp')
            .setDescription("Add (or subtract, with a negative amount) to a member's XP")
            .setDescriptionLocalizations({ ar: 'إضافة (أو خصم برقم سالب) نقاط خبرة لعضو', 'en-US': "Add (or subtract) to a member's XP" })
            .addUserOption((o) => o.setName('user').setDescription('The member').setDescriptionLocalizations({ ar: 'العضو', 'en-US': 'The member' }).setRequired(true))
            .addIntegerOption((o) => o.setName('amount').setDescription('XP to add (negative to subtract)').setDescriptionLocalizations({ ar: 'نقاط الخبرة المراد إضافتها (رقم سالب للخصم)', 'en-US': 'XP to add (negative to subtract)' }).setMinValue(-MAX_ADMIN_XP).setMaxValue(MAX_ADMIN_XP).setRequired(true))
        )
        .addSubcommand((s) =>
          s
            .setName('reset')
            .setDescription("Reset a member's XP and level back to zero")
            .setDescriptionLocalizations({ ar: 'إعادة تعيين نقاط خبرة عضو ومستواه إلى الصفر', 'en-US': "Reset a member's XP and level back to zero" })
            .addUserOption((o) => o.setName('user').setDescription('The member').setDescriptionLocalizations({ ar: 'العضو', 'en-US': 'The member' }).setRequired(true))
        )
    )
    // TASK23: read-only summary matching the settings this command can
    // now manage, so admins don't have to run several list subcommands
    // to see the full picture.
    .addSubcommand((s) =>
      s.setName('view').setDescription('Show the current leveling configuration')
        .setDescriptionLocalizations({ ar: 'عرض إعدادات نظام المستويات الحالية', 'en-US': 'Show the current leveling configuration' })
    ),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You need Manage Server permission to use this command.')], ephemeral: true });
    }

    const group = interaction.options.getSubcommandGroup(false);
    const sub = interaction.options.getSubcommand();

    if (sub === 'toggle') {
      guildConfig.leveling.enabled = !guildConfig.leveling.enabled;
      await guildConfig.save();
      invalidateGuildConfig(interaction.guildId);
      return interaction.reply({
        embeds: [successEmbed(settings, `Leveling is now **${guildConfig.leveling.enabled ? 'enabled' : 'disabled'}**.`)],
      });
    }

    // TASK23: `channel`/`enabled`/`clear_channel` are all optional now (the
    // old version required `channel`) so this single subcommand can flip
    // announceLevelUp on/off, set a fixed channel, or clear it back to
    // "announce in the channel the level-up happened in" (messageCreate.js
    // already falls back to message.channelId when announceChannelId is
    // null/unset - see handleLeveling). At least one option must be given
    // so a bare `/levelingconfig announce` can't silently no-op.
    if (sub === 'announce') {
      const enabledOpt = interaction.options.getBoolean('enabled');
      const channelOpt = interaction.options.getChannel('channel');
      const clearChannel = interaction.options.getBoolean('clear_channel');

      if (enabledOpt === null && !channelOpt && !clearChannel) {
        return interaction.reply({
          embeds: [errorEmbed(settings, 'Provide at least one of `enabled`, `channel`, or `clear_channel`.')],
          ephemeral: true,
        });
      }
      if (channelOpt && clearChannel) {
        return interaction.reply({
          embeds: [errorEmbed(settings, '`channel` and `clear_channel` cannot both be used at once.')],
          ephemeral: true,
        });
      }

      const changes = [];
      if (enabledOpt !== null) {
        guildConfig.leveling.announceLevelUp = enabledOpt;
        changes.push(`Announcements: **${enabledOpt ? 'enabled' : 'disabled'}**`);
      }
      if (channelOpt) {
        guildConfig.leveling.announceChannelId = channelOpt.id;
        changes.push(`Channel: ${channelOpt}`);
      } else if (clearChannel) {
        guildConfig.leveling.announceChannelId = null;
        changes.push('Channel: cleared (announces in the level-up channel)');
      }

      await guildConfig.save();
      invalidateGuildConfig(interaction.guildId);
      return interaction.reply({ embeds: [successEmbed(settings, changes.join('\n'))] });
    }

    if (sub === 'xp') {
      guildConfig.leveling.xpPerMessage = interaction.options.getInteger('amount');
      guildConfig.leveling.cooldownSeconds = interaction.options.getInteger('cooldown');
      await guildConfig.save();
      invalidateGuildConfig(interaction.guildId);
      return interaction.reply({ embeds: [successEmbed(settings, 'XP settings updated.')] });
    }

    // TASK23: xpMin/xpMax already existed on the schema and were already
    // read by levelingService.resolveXpRange() whenever both are finite
    // numbers with max > 0 (falling back to the xpPerMessage +/-20% band
    // otherwise) - this just adds the missing way to set them. Validated
    // here even though the option builder already enforces 1-1000 each,
    // because the min<=max relationship between the two options can't be
    // expressed at the option-builder level.
    if (sub === 'xprange') {
      const min = interaction.options.getInteger('min');
      const max = interaction.options.getInteger('max');
      if (min > max) {
        return interaction.reply({
          embeds: [errorEmbed(settings, '`min` cannot be greater than `max`.')],
          ephemeral: true,
        });
      }
      guildConfig.leveling.xpMin = min;
      guildConfig.leveling.xpMax = max;
      await guildConfig.save();
      invalidateGuildConfig(interaction.guildId);
      return interaction.reply({ embeds: [successEmbed(settings, `XP per message is now a random **${min}-${max}**.`)] });
    }

    // TASK23: excludedChannelIds/excludedRoleIds already existed on the
    // schema and were already enforced in messageCreate.js (handleLeveling)
    // - only the management commands were missing. Reassigning the array
    // (filter/concat) rather than mutating in place is the reliable way to
    // get Mongoose to pick up the change on a plain [String] array path.
    if (group === 'excluded-channels') {
      const list = guildConfig.leveling.excludedChannelIds || [];

      if (sub === 'add') {
        const channel = interaction.options.getChannel('channel');
        if (list.includes(channel.id)) {
          return interaction.reply({ embeds: [successEmbed(settings, `${channel} is already excluded.`)], ephemeral: true });
        }
        guildConfig.leveling.excludedChannelIds = [...list, channel.id];
        guildConfig.markModified('leveling.excludedChannelIds');
        await guildConfig.save();
        invalidateGuildConfig(interaction.guildId);
        return interaction.reply({ embeds: [successEmbed(settings, `${channel} will no longer grant XP.`)] });
      }

      if (sub === 'remove') {
        const channel = interaction.options.getChannel('channel');
        if (!list.includes(channel.id)) {
          return interaction.reply({ embeds: [successEmbed(settings, `${channel} wasn't excluded.`)], ephemeral: true });
        }
        guildConfig.leveling.excludedChannelIds = list.filter((id) => id !== channel.id);
        guildConfig.markModified('leveling.excludedChannelIds');
        await guildConfig.save();
        invalidateGuildConfig(interaction.guildId);
        return interaction.reply({ embeds: [successEmbed(settings, `${channel} can grant XP again.`)] });
      }

      if (sub === 'list') {
        const value = joinWithinLimit(list.map((id) => `<#${id}>`));
        return interaction.reply({ embeds: [baseEmbed(settings).setTitle('Excluded Channels').setDescription(value)], ephemeral: true });
      }
    }

    if (group === 'excluded-roles') {
      const list = guildConfig.leveling.excludedRoleIds || [];

      if (sub === 'add') {
        const role = interaction.options.getRole('role');
        if (list.includes(role.id)) {
          return interaction.reply({ embeds: [successEmbed(settings, `${role} is already excluded.`)], ephemeral: true });
        }
        guildConfig.leveling.excludedRoleIds = [...list, role.id];
        guildConfig.markModified('leveling.excludedRoleIds');
        await guildConfig.save();
        invalidateGuildConfig(interaction.guildId);
        return interaction.reply({ embeds: [successEmbed(settings, `Members with ${role} will no longer gain XP.`)] });
      }

      if (sub === 'remove') {
        const role = interaction.options.getRole('role');
        if (!list.includes(role.id)) {
          return interaction.reply({ embeds: [successEmbed(settings, `${role} wasn't excluded.`)], ephemeral: true });
        }
        guildConfig.leveling.excludedRoleIds = list.filter((id) => id !== role.id);
        guildConfig.markModified('leveling.excludedRoleIds');
        await guildConfig.save();
        invalidateGuildConfig(interaction.guildId);
        return interaction.reply({ embeds: [successEmbed(settings, `Members with ${role} can gain XP again.`)] });
      }

      if (sub === 'list') {
        const value = joinWithinLimit(list.map((id) => `<@&${id}>`));
        return interaction.reply({ embeds: [baseEmbed(settings).setTitle('Excluded Roles').setDescription(value)], ephemeral: true });
      }
    }

    // TASK25: same add/remove/list pattern as excluded-channels/roles,
    // for leveling.xpMultipliers (see GuildConfig.js).
    if (group === 'xp-multiplier') {
      const list = guildConfig.leveling.xpMultipliers || [];

      if (sub === 'add') {
        const role = interaction.options.getRole('role');
        const multiplier = interaction.options.getNumber('multiplier');
        const withoutRole = list.filter((m) => m.roleId !== role.id);
        guildConfig.leveling.xpMultipliers = [...withoutRole, { roleId: role.id, multiplier }];
        guildConfig.markModified('leveling.xpMultipliers');
        await guildConfig.save();
        invalidateGuildConfig(interaction.guildId);
        return interaction.reply({ embeds: [successEmbed(settings, `Members with ${role} now earn **${multiplier}x** XP per message.`)] });
      }

      if (sub === 'remove') {
        const role = interaction.options.getRole('role');
        if (!list.some((m) => m.roleId === role.id)) {
          return interaction.reply({ embeds: [successEmbed(settings, `${role} doesn't have a multiplier set.`)], ephemeral: true });
        }
        guildConfig.leveling.xpMultipliers = list.filter((m) => m.roleId !== role.id);
        guildConfig.markModified('leveling.xpMultipliers');
        await guildConfig.save();
        invalidateGuildConfig(interaction.guildId);
        return interaction.reply({ embeds: [successEmbed(settings, `Removed ${role}'s XP multiplier.`)] });
      }

      if (sub === 'list') {
        if (!list.length) {
          return interaction.reply({ embeds: [baseEmbed(settings).setTitle('XP Multipliers').setDescription('None configured.')], ephemeral: true });
        }
        const value = list.map((m) => `<@&${m.roleId}> — **${m.multiplier}x**`).join('\n');
        return interaction.reply({ embeds: [baseEmbed(settings).setTitle('XP Multipliers').setDescription(value)], ephemeral: true });
      }
    }

    // TASK26 (Voice XP): mirrors the toggle/xp/view subcommands above but
    // scoped to leveling.voiceXpEnabled/voiceXpPerMinute - deliberately
    // does NOT touch excludedChannelIds/excludedRoleIds/xpMultipliers/
    // rewards/card/announce settings, since Voice XP reuses all of those
    // as-is (see GuildConfig.js's voiceXpEnabled comment). Placed before
    // the unguarded `if (sub === 'view')` below so its own `voice view`
    // subcommand (same name, different subcommand-group namespace) is
    // handled here and returns, instead of falling through to the
    // whole-config view.
    if (group === 'voice') {
      if (sub === 'enable') {
        if (guildConfig.leveling.voiceXpEnabled) {
          return interaction.reply({ embeds: [successEmbed(settings, 'Voice XP is already enabled.')], ephemeral: true });
        }
        guildConfig.leveling.voiceXpEnabled = true;
        await guildConfig.save();
        invalidateGuildConfig(interaction.guildId);
        return interaction.reply({
          embeds: [successEmbed(settings, `Voice XP is now **enabled** (**${guildConfig.leveling.voiceXpPerMinute}** XP/minute). It uses the same levels, rewards, and leaderboard as message XP.`)],
        });
      }

      if (sub === 'disable') {
        if (!guildConfig.leveling.voiceXpEnabled) {
          return interaction.reply({ embeds: [successEmbed(settings, 'Voice XP is already disabled.')], ephemeral: true });
        }
        guildConfig.leveling.voiceXpEnabled = false;
        await guildConfig.save();
        invalidateGuildConfig(interaction.guildId);
        return interaction.reply({ embeds: [successEmbed(settings, 'Voice XP is now **disabled**. Message XP is unaffected.')] });
      }

      if (sub === 'xp') {
        const amount = interaction.options.getInteger('amount');
        guildConfig.leveling.voiceXpPerMinute = amount;
        await guildConfig.save();
        invalidateGuildConfig(interaction.guildId);
        return interaction.reply({ embeds: [successEmbed(settings, `Voice XP is now **${amount}** per minute (before role multipliers).`)] });
      }

      // TASK27: see GuildConfig.js's voiceMinMembers comment /
      // services/voiceXpService.js's isEligible() for how this is used.
      if (sub === 'min-members') {
        const amount = interaction.options.getInteger('amount');
        guildConfig.leveling.voiceMinMembers = amount;
        await guildConfig.save();
        invalidateGuildConfig(interaction.guildId);
        const desc =
          amount <= 1
            ? 'Members can now earn Voice XP even when alone in a channel.'
            : `A channel now needs at least **${amount}** human members present for anyone in it to earn Voice XP.`;
        return interaction.reply({ embeds: [successEmbed(settings, desc)] });
      }

      if (sub === 'view') {
        const leveling = guildConfig.leveling;
        const embed = baseEmbed(settings)
          .setTitle('Voice XP Configuration')
          .addFields(
            { name: 'Status', value: leveling.voiceXpEnabled ? 'Enabled' : 'Disabled', inline: true },
            { name: 'XP per Minute', value: `${leveling.voiceXpPerMinute}`, inline: true },
            { name: 'Minimum Human Members', value: `${leveling.voiceMinMembers ?? 2}`, inline: true },
            { name: 'Leveling System', value: leveling.enabled ? 'Enabled' : 'Disabled (Voice XP needs leveling enabled too)', inline: true },
            { name: 'XP Multipliers', value: `${(leveling.xpMultipliers || []).length} configured`, inline: true },
            { name: 'Excluded Channels', value: `${(leveling.excludedChannelIds || []).length}`, inline: true },
            { name: 'Excluded Roles', value: `${(leveling.excludedRoleIds || []).length}`, inline: true },
            { name: 'Level Up Announcements', value: leveling.announceLevelUp !== false ? 'Enabled' : 'Disabled', inline: true }
          )
          .setDescription('Uses the same excluded channels/roles, XP multipliers, and level rewards as message XP - see `/levelingconfig view`.');
        return interaction.reply({ embeds: [embed], ephemeral: true });
      }
    }

    // TASK25: manual per-member XP administration - see
    // services/levelingService.js's setUserXp/addUserXp/resetUserXp doc
    // comment for why this intentionally never grants reward roles or
    // fires a level-up announcement (message-based leveling stays the
    // one place those side effects happen).
    if (group === 'member') {
      const user = interaction.options.getUser('user');

      if (sub === 'set-xp') {
        const amount = interaction.options.getInteger('amount');
        const { level } = await setUserXp(interaction.guildId, user.id, amount);
        return interaction.reply({
          embeds: [successEmbed(settings, `${user}'s XP is now **${amount.toLocaleString()}** (level **${level}**).`)],
        });
      }

      if (sub === 'add-xp') {
        const amount = interaction.options.getInteger('amount');
        const { doc, level } = await addUserXp(interaction.guildId, user.id, amount);
        const verb = amount >= 0 ? 'Added' : 'Removed';
        return interaction.reply({
          embeds: [
            successEmbed(
              settings,
              `${verb} **${Math.abs(amount).toLocaleString()}** XP ${amount >= 0 ? 'to' : 'from'} ${user}. They now have **${doc.xp.toLocaleString()}** XP (level **${level}**).`
            ),
          ],
        });
      }

      if (sub === 'reset') {
        await resetUserXp(interaction.guildId, user.id);
        return interaction.reply({ embeds: [successEmbed(settings, `${user}'s XP and level have been reset to 0.`)] });
      }
    }

    // TASK23: read-only, no save/invalidate needed - just reflects
    // guildConfig.leveling as it already is.
    if (sub === 'view') {
      const leveling = guildConfig.leveling;
      const xpRange = resolveXpRange(leveling);
      const usingCustomRange = Number.isFinite(leveling.xpMin) && Number.isFinite(leveling.xpMax) && leveling.xpMax > 0;
      const channels = joinWithinLimit((leveling.excludedChannelIds || []).map((id) => `<#${id}>`));
      const roles = joinWithinLimit((leveling.excludedRoleIds || []).map((id) => `<@&${id}>`));

      const embed = baseEmbed(settings)
        .setTitle('Leveling Configuration')
        .addFields(
          { name: 'Status', value: leveling.enabled ? 'Enabled' : 'Disabled', inline: true },
          { name: 'XP Range', value: `${xpRange.min} - ${xpRange.max}${usingCustomRange ? '' : ' (derived from xpPerMessage)'}`, inline: true },
          { name: 'Cooldown', value: `${leveling.cooldownSeconds}s`, inline: true },
          { name: 'Level Up Announcements', value: leveling.announceLevelUp !== false ? 'Enabled' : 'Disabled', inline: true },
          { name: 'Announcement Channel', value: leveling.announceChannelId ? `<#${leveling.announceChannelId}>` : 'Same channel as the level-up', inline: true },
          { name: 'Rank Card', value: leveling.card?.enabled === false ? 'Disabled' : `Enabled (${leveling.card?.theme || 'aurora'})`, inline: true },
          // TASK28: accent/progress colors were only settable via
          // `/levelingconfig card`, never actually shown back anywhere -
          // an admin had no way to check what they'd set without
          // re-running /rank and eyeballing the image. Both fall back to
          // "Default" (matching levelCardService.js's own ACCENT_FALLBACK/
          // "use embed color" behavior) when unset, never a raw null.
          { name: 'Card Accent Color', value: leveling.card?.accentColor || 'Default (server embed color)', inline: true },
          { name: 'Card Progress Color', value: leveling.card?.progressColor || 'Default (matches accent)', inline: true },
          // TASK28: reward count was previously only visible by running
          // /levelreward list (a second command) - a quick count here
          // matches how Excluded Channels/Roles and XP Multipliers below
          // already summarize their own list at a glance.
          { name: 'Level Rewards', value: `${(leveling.rewards || []).length} configured`, inline: true },
          // TASK26: Voice XP summary - full detail (and its own view) is
          // `/levelingconfig voice view`, this is just a quick glance
          // alongside every other leveling setting.
          {
            name: 'Voice XP',
            value: leveling.voiceXpEnabled
              ? `Enabled (${leveling.voiceXpPerMinute}/min, min ${leveling.voiceMinMembers ?? 2} member${(leveling.voiceMinMembers ?? 2) === 1 ? '' : 's'})`
              : 'Disabled',
            inline: true,
          },
          {
            // TASK28: field name now states the count explicitly (per
            // spec - "Multipliers count") instead of only being
            // inferable by counting the mentions in the value.
            name: `XP Multipliers (${(leveling.xpMultipliers || []).length})`,
            value: (leveling.xpMultipliers || []).length
              ? (leveling.xpMultipliers || []).map((m) => `<@&${m.roleId}> (${m.multiplier}x)`).join(', ')
              : 'None',
            inline: true,
          },
          { name: 'Excluded Channels', value: channels },
          { name: 'Excluded Roles', value: roles }
        );
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    // TASK19: rank-card / leaderboard-image customization. Every option
    // is optional - only fields the admin actually passed are touched,
    // and a malformed hex color is rejected up front instead of being
    // silently saved and only failing later inside Canvas.
    if (sub === 'card') {
      const enabled = interaction.options.getBoolean('enabled');
      const theme = interaction.options.getString('theme');
      const accentColor = interaction.options.getString('accent_color');
      const progressColor = interaction.options.getString('progress_color');
      const HEX_RE = /^#[0-9a-fA-F]{6}$/;

      if (accentColor && !HEX_RE.test(accentColor)) {
        return interaction.reply({
          embeds: [errorEmbed(settings, 'accent_color must be a 6-digit hex color, e.g. `#5865F2`.')],
          ephemeral: true,
        });
      }
      if (progressColor && !HEX_RE.test(progressColor)) {
        return interaction.reply({
          embeds: [errorEmbed(settings, 'progress_color must be a 6-digit hex color, e.g. `#57F287`.')],
          ephemeral: true,
        });
      }

      guildConfig.leveling.card = guildConfig.leveling.card || {};
      if (enabled !== null) guildConfig.leveling.card.enabled = enabled;
      if (theme) guildConfig.leveling.card.theme = theme;
      if (accentColor) guildConfig.leveling.card.accentColor = accentColor;
      if (progressColor) guildConfig.leveling.card.progressColor = progressColor;

      await guildConfig.save();
      invalidateGuildConfig(interaction.guildId);
      return interaction.reply({ embeds: [successEmbed(settings, 'Rank card settings updated.')] });
    }
  },
};
