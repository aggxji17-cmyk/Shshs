const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { getGuildConfig, resolved, invalidateGuildConfig } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed, infoEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');
const CommandLog = require('../../database/models/CommandLog');

const RECENT_LIMIT = 15;

/**
 * TASK43 - merged from the two standalone commands `/setlogs`
 * (guildConfig.logging - moderation/audit log channel) and
 * `/commandlogs` (guildConfig.commandLogging - live command-usage log +
 * history). Both belonged to the same "logging" dashboard section
 * (see utils/settingsDashboard.js) and only existed as separate
 * top-level commands historically; behavior of every subcommand below
 * is unchanged from its original file, only the entry point moved:
 *   /setlogs <channel>        -> /logs audit channel
 *   /commandlogs channel      -> /logs commands channel
 *   /commandlogs disable      -> /logs commands disable
 *   /commandlogs recent       -> /logs commands recent
 */
module.exports = {
  data: new SlashCommandBuilder()
    .setName('logs')
    .setDescription('Configure moderation/audit logs and command-usage logs')
    .setDescriptionLocalizations({ ar: 'إعداد سجلات الإشراف والتدقيق وسجلات استخدام الأوامر', 'en-US': 'Configure moderation/audit logs and command-usage logs' })
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommandGroup((g) =>
      g
        .setName('audit')
        .setDescription('The moderation/audit logging channel')
        .setDescriptionLocalizations({ ar: 'قناة سجلات الإشراف والتدقيق', 'en-US': 'The moderation/audit logging channel' })
        .addSubcommand((s) =>
          s
            .setName('channel')
            .setDescription('Set the moderation/audit logging channel')
            .setDescriptionLocalizations({ ar: 'تحديد قناة سجلات الإشراف والتدقيق', 'en-US': 'Set the moderation/audit logging channel' })
            .addChannelOption((o) => o.setName('channel').setDescription('Channel to send logs to').setDescriptionLocalizations({ ar: 'القناة التي تُرسل إليها السجلات', 'en-US': 'Channel to send logs to' }).addChannelTypes(ChannelType.GuildText).setRequired(true))
        )
    )
    .addSubcommandGroup((g) =>
      g
        .setName('commands')
        .setDescription('The command-usage log channel and history')
        .setDescriptionLocalizations({ ar: 'قناة وسجل استخدام الأوامر', 'en-US': 'The command-usage log channel and history' })
        .addSubcommand((s) =>
          s
            .setName('channel')
            .setDescription('Send a live log of every command used to a channel')
            .setDescriptionLocalizations({ ar: 'إرسال سجل مباشر لكل أمر يُستخدم إلى قناة', 'en-US': 'Send a live log of every command used to a channel' })
            .addChannelOption((o) =>
              o
                .setName('channel')
                .setDescription('Channel to send usage logs to')
                .setDescriptionLocalizations({ ar: 'القناة التي تُرسل إليها سجلات الاستخدام', 'en-US': 'Channel to send usage logs to' })
                .addChannelTypes(ChannelType.GuildText)
                .setRequired(true)
            )
        )
        .addSubcommand((s) =>
          s
            .setName('disable')
            .setDescription('Stop sending the live command-usage log to a channel')
            .setDescriptionLocalizations({ ar: 'إيقاف إرسال سجل استخدام الأوامر المباشر إلى القناة', 'en-US': 'Stop sending the live command-usage log to a channel' })
        )
        .addSubcommand((s) =>
          s
            .setName('recent')
            .setDescription(`Show the last ${RECENT_LIMIT} commands used in this server`)
            .setDescriptionLocalizations({ ar: `عرض آخر ${RECENT_LIMIT} أمر تم استخدامه في هذا السيرفر`, 'en-US': `Show the last ${RECENT_LIMIT} commands used in this server` })
        )
    ),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You need Manage Server permission to use this command.')], ephemeral: true });
    }

    const group = interaction.options.getSubcommandGroup();
    const sub = interaction.options.getSubcommand();

    if (group === 'audit') return handleAuditChannel(interaction, settings, guildConfig);

    // group === 'commands'
    if (sub === 'channel') return handleCommandsChannel(interaction, settings, guildConfig);
    if (sub === 'disable') return handleCommandsDisable(interaction, settings, guildConfig);
    return handleCommandsRecent(interaction, settings); // sub === 'recent'
  },
};

async function handleAuditChannel(interaction, settings, guildConfig) {
  const channel = interaction.options.getChannel('channel');
  guildConfig.logging.channelId = channel.id;
  guildConfig.logging.enabled = true;
  await guildConfig.save();
  invalidateGuildConfig(interaction.guildId);
  return interaction.reply({ embeds: [successEmbed(settings, `Logs will now be sent to ${channel}.`)] });
}

async function handleCommandsChannel(interaction, settings, guildConfig) {
  const channel = interaction.options.getChannel('channel');
  guildConfig.commandLogging.channelId = channel.id;
  guildConfig.commandLogging.enabled = true;
  await guildConfig.save();
  invalidateGuildConfig(interaction.guildId);
  return interaction.reply({ embeds: [successEmbed(settings, `Every command used in this server will now also be logged live to ${channel}.`)] });
}

async function handleCommandsDisable(interaction, settings, guildConfig) {
  if (!guildConfig.commandLogging.enabled) {
    return interaction.reply({ embeds: [errorEmbed(settings, 'The command-usage log channel is not currently enabled.')], ephemeral: true });
  }
  guildConfig.commandLogging.enabled = false;
  await guildConfig.save();
  invalidateGuildConfig(interaction.guildId);
  return interaction.reply({ embeds: [successEmbed(settings, 'The live command-usage log channel has been disabled (usage is still recorded for `/logs commands recent`).')] });
}

async function handleCommandsRecent(interaction, settings) {
  // every command usage is always recorded regardless of the live
  // channel above, so this works even when that's off.
  const entries = await CommandLog.find({ guildId: interaction.guildId }).sort({ createdAt: -1 }).limit(RECENT_LIMIT);

  if (!entries.length) {
    return interaction.reply({ embeds: [infoEmbed(settings, 'No command usage has been recorded in this server yet.')], ephemeral: true });
  }

  const lines = entries.map((e) => `<t:${Math.floor(e.createdAt.getTime() / 1000)}:R> - <@${e.userId}> used \`/${e.commandName}\`${e.channelId ? ` in <#${e.channelId}>` : ''}`);

  return interaction.reply({
    embeds: [infoEmbed(settings, `Last ${entries.length} command${entries.length === 1 ? '' : 's'} used in this server`).addFields({ name: '\u200b', value: lines.join('\n') })],
    ephemeral: true,
  });
}
