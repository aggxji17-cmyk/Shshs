const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
// Task 46: فحص الصلاحيات وفتح الواجهة يتمان عبر commandRouter مركزياً.
const { routeCommand } = require('../../utils/commandRouter');

/**
 * Task 30/31 — Admin Dashboard (لوحة الإدارة المركزية).
 *
 * Entry point of Phase 6 ("نظام واجهات الإدارة"): a single `/admin`
 * command meant to become the central hub that replaces most of the
 * scattered admin-only setup commands over the following tasks (see
 * NYXO-BOT-TASKS-70.txt, Phase 6). Per the phase's own rule, nothing is
 * removed yet - old commands keep working exactly as before, and every
 * system is moved to this dashboard only after its UI replacement is
 * verified complete.
 *
 * Task 30 built the command itself, its permission gate, and a static
 * "home" view listing every section. Task 31 (this revision) adds the
 * actual interactive navigation: a section select menu plus Back/Home/
 * Close buttons, with the same two-layer permission check re-verified
 * on every one of those component interactions - see
 * `components/buttons.js` (admin_home/admin_back/admin_close) and
 * `components/selectMenus.js` (admin_nav).
 *
 * The Home/Section/Closed views themselves now live in
 * `utils/adminDashboard.js` rather than being built inline here, since
 * the component handlers need to render the exact same views this
 * command does - see that file's top comment for the full rationale.
 */
module.exports = {
  data: new SlashCommandBuilder()
    .setName('admin')
    .setDescription('Open the central admin dashboard')
    .setDescriptionLocalizations({
      ar: 'فتح لوحة الإدارة المركزية',
      'en-US': 'Open the central admin dashboard',
    })
    // Task 05: تم تغيير Discord-level permission من Administrator إلى ManageGuild
    // ليتوافق مع السلوك الفعلي لـ isGuildManager() المستخدمة في commandRouter
    // وفي جميع admin_* component handlers (admin_nav/admin_home/admin_back/admin_close).
    // isGuildManager() تقبل: Owner + Administrator + ManageGuild + adminRoleId.
    // setDefaultMemberPermissions(ManageGuild) يجعل Discord يُظهر الأمر لنفس
    // المجموعة التي يسمح لها الـ in-code check باستخدامه.
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction) {
    // Task 46: فحص الصلاحيات والتسجيل وفتح الواجهة عبر Router مركزياً.
    // تحقق فحص الصلاحيات (isGuildManager) والتسجيل في commandRouter.js.
    return routeCommand(interaction, 'admin');
  },
};
