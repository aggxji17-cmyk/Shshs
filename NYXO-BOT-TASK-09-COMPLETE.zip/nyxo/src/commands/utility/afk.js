const { SlashCommandBuilder } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed } = require('../../utils/embeds');
const logger = require('../../utils/logger');
const AfkStatus = require('../../database/models/AfkStatus');

const AFK_PREFIX = 'AFK | ';
const NICKNAME_MAX_LENGTH = 32; // Discord's hard limit on any nickname.

/**
 * TASK31: builds the "AFK | <name>" nickname, truncating the name portion
 * (not the prefix) so the result always fits Discord's 32-char nickname
 * limit instead of the setNickname() call just failing outright for
 * anyone with a longer current name.
 */
function buildAfkNickname(currentName) {
  const maxNameLength = NICKNAME_MAX_LENGTH - AFK_PREFIX.length;
  const trimmedName = (currentName || '').slice(0, maxNameLength);
  return `${AFK_PREFIX}${trimmedName}`;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('afk')
    .setDescription('Mark yourself as AFK - the bot will notify anyone who mentions you')
    .setDescriptionLocalizations({ ar: 'وضع علامة أنك بعيد (AFK) - سيخبر البوت من يذكرك', 'en-US': 'Mark yourself as AFK - the bot will notify anyone who mentions you' })
    .addStringOption((o) => o.setName('reason').setDescription('Reason for being AFK').setDescriptionLocalizations({ ar: 'سبب الغياب (AFK)', 'en-US': 'Reason for being AFK' }).setMaxLength(200)),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    const reason = interaction.options.getString('reason') || 'AFK';

    // TASK31: if the member is already AFK, just refresh the reason -
    // deliberately does NOT touch `since`, `mentions`, or `originalNick`.
    // The previous version unconditionally reset `mentionCount` to 0
    // here (upsert with no existence check), which meant re-running
    // /afk while already AFK silently discarded any "who mentioned you"
    // data collected so far - the exact opposite of this task's point.
    // It's also what stops a second /afk from re-capturing the member's
    // *current* (already "AFK | ...") nickname as `originalNick`, which
    // would have permanently lost their real original nickname.
    const existing = await AfkStatus.findOne({ guildId: interaction.guildId, userId: interaction.user.id });
    if (existing) {
      existing.reason = reason;
      await existing.save();
      await interaction.reply({ embeds: [successEmbed(settings, `Your AFK reason is now: **${reason}**`)] });
      return;
    }

    const member = interaction.member;
    // Nullable on purpose - a member with no custom nickname has
    // `member.nickname === null`, and that's the correct value to store
    // (restoring later with `setNickname(null)` clears back to no
    // nickname, which is what we want - see AfkStatus.js's comment).
    const originalNick = member?.nickname ?? null;

    await AfkStatus.create({
      guildId: interaction.guildId,
      userId: interaction.user.id,
      reason,
      since: new Date(),
      mentionCount: 0,
      mentions: [],
      originalNick,
    });

    // TASK31: best-effort nickname change - never blocks AFK activation.
    // Missing "Manage Nicknames", the bot's highest role sitting below
    // the member's (can't touch the server owner or a higher role at
    // all), or any other Discord API failure here must still leave AFK
    // itself fully active; only the cosmetic nickname prefix is skipped.
    let nicknameChanged = false;
    if (member && member.manageable) {
      try {
        await member.setNickname(buildAfkNickname(member.displayName));
        nicknameChanged = true;
      } catch (err) {
        logger.error(`/afk: failed to set AFK nickname for ${interaction.user.id} in guild ${interaction.guildId}: ${err?.stack || err}`);
      }
    }

    const note = member && !member.manageable ? " (I don't have permission to change your nickname)" : !nicknameChanged && member ? ' (could not update your nickname)' : '';
    await interaction.reply({ embeds: [successEmbed(settings, `You are now AFK: **${reason}**${note}`)] });
  },
};

module.exports.buildAfkNickname = buildAfkNickname;
