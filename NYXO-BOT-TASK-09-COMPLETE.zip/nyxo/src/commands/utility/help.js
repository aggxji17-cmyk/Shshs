'use strict';

/**
 * المهمة 56 — تعريب Help Center
 * أمر /help → مركز مساعدة عربي تفاعلي كامل
 *
 * يحتوي على:
 * - شرح الأنظمة (Select Menu للتنقل)
 * - الأوامر مع الصلاحيات المطلوبة
 * - أمثلة الاستخدام
 * - شرح الأزرار والإعدادات
 * - زر Home + Close
 */

const {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
  MessageFlags,
  ComponentType,
} = require('discord.js');

const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { baseEmbed } = require('../../utils/embeds');
const { safeAutocomplete, commandNameChoices } = require('../../utils/autocomplete');

// ─── تعريف الأقسام ──────────────────────────────────────────────────────────

const SECTIONS = {
  home: {
    label: '🏠 الرئيسية',
    description: 'نظرة عامة على NYXO BOT',
  },
  moderation: {
    label: '🔨 الإشراف',
    description: 'أوامر الإشراف والتحكم بالأعضاء',
  },
  tickets: {
    label: '🎫 التذاكر',
    description: 'نظام دعم التذاكر والمساعدة',
  },
  protection: {
    label: '🛡️ الحماية',
    description: 'Anti-Nuke وAnti-Raid وAutoMod',
  },
  music: {
    label: '🎵 الموسيقى',
    description: 'أوامر تشغيل الموسيقى',
  },
  economy: {
    label: '💰 الاقتصاد',
    description: 'نظام الاقتصاد والمحل',
  },
  leveling: {
    label: '⭐ المستويات',
    description: 'نظام المستويات والمكافآت',
  },
  giveaways: {
    label: '🎉 السحوبات',
    description: 'نظام السحوبات والجوائز',
  },
  settings: {
    label: '⚙️ الإعدادات',
    description: 'إعدادات البوت والسيرفر',
  },
  utility: {
    label: '🔧 الأدوات',
    description: 'أوامر عامة ومتعددة الاستخدامات',
  },
  minecraft: {
    label: '⛏️ Minecraft',
    description: 'أوامر خاصة بسيرفرات Minecraft',
  },
};

// ─── محتوى كل قسم ────────────────────────────────────────────────────────────

function buildHomeEmbed(settings) {
  return baseEmbed(settings)
    .setTitle('📖 مركز المساعدة — NYXO BOT')
    .setDescription(
      '> مرحباً! هذا مركز المساعدة الشامل لـ **NYXO BOT**.\n' +
      '> استخدم القائمة أدناه للتنقل بين الأقسام.\n\n' +
      '**📦 الأنظمة المتاحة:**'
    )
    .addFields(
      { name: '🔨 الإشراف', value: 'بان، كيك، تايم أوت، تحذيرات، قفل قنوات', inline: true },
      { name: '🎫 التذاكر', value: 'نظام دعم متكامل بالتصنيفات والأدوار', inline: true },
      { name: '🛡️ الحماية', value: 'Anti-Nuke، Anti-Raid، AutoMod', inline: true },
      { name: '🎵 الموسيقى', value: 'تشغيل من يوتيوب وسبوتيفاي وغيرها', inline: true },
      { name: '💰 الاقتصاد', value: 'عملات، محل، أعمال يومية', inline: true },
      { name: '⭐ المستويات', value: 'نظام XP مع مكافآت الأدوار', inline: true },
      { name: '🎉 السحوبات', value: 'سحوبات تلقائية مع إعادة السحب', inline: true },
      { name: '⚙️ الإعدادات', value: 'تخصيص كامل للبوت في سيرفرك', inline: true },
      { name: '⛏️ Minecraft', value: 'ربط حسابات وعرض حالة السيرفر', inline: true }
    )
    .addFields({
      name: '💡 نصيحة',
      value: '> استخدم `/help command:<اسم الأمر>` لعرض تفاصيل أمر معيّن مباشرة.',
    });
}

function buildModerationEmbed(settings) {
  return baseEmbed(settings)
    .setTitle('🔨 قسم الإشراف')
    .setDescription('> أوامر الإشراف والتحكم بالأعضاء في السيرفر.\n> **الصلاحية المطلوبة:** مشرف أو دور Support/Moderator')
    .addFields(
      {
        name: '📋 الأوامر',
        value: [
          '`/ban` — حظر عضو من السيرفر',
          '`/unban` — رفع الحظر عن عضو',
          '`/kick` — طرد عضو من السيرفر',
          '`/timeout` — كتم عضو لمدة معيّنة',
          '`/warn` — إعطاء تحذير لعضو',
          '`/warnings` — عرض تحذيرات عضو',
          '`/clearwarnings` — مسح تحذيرات عضو',
          '`/purge` — حذف رسائل متعددة',
          '`/nickname` — تغيير لقب عضو',
          '`/slowmode` — تعيين وضع السلو موود',
          '`/lockdown` — قفل/فتح قناة',
          '`/note` — إضافة ملاحظة سرية على عضو',
          '`/softban` — بان ثم رفع حظر فوري (لمسح الرسائل)',
          '`/modhistory` — سجل الإجراءات على عضو',
          '`/case` — عرض قضية تأديبية معيّنة',
          '`/editcase` — تعديل سبب قضية',
          '`/schedule` — جدولة إجراء تأديبي لاحقاً',
          '`/massunban` — رفع حظر جماعي',
          '`/massrole` — إضافة/إزالة دور من جميع الأعضاء',
        ].join('\n'),
      },
      {
        name: '⚙️ أوامر الإعداد',
        value: [
          '`/warnconfig` — إعداد حد التحذيرات والعقوبة التلقائية',
          '`/banlimits` — حد حظر المسؤولين',
          '`/kicklimits` — حد طرد المسؤولين',
          '`/timeoutlimits` — حد كتم المسؤولين',
        ].join('\n'),
      },
      {
        name: '💡 أمثلة',
        value: [
          '`/ban user:@أحمد reason:مخالفة القوانين`',
          '`/timeout user:@خالد duration:10m reason:تصرف سيء`',
          '`/purge amount:50`',
        ].join('\n'),
      }
    );
}

function buildTicketsEmbed(settings) {
  return baseEmbed(settings)
    .setTitle('🎫 قسم التذاكر')
    .setDescription('> نظام دعم التذاكر المتكامل.\n> **الصلاحية المطلوبة:** Manage Server لإعداد النظام.')
    .addFields(
      {
        name: '📋 الأوامر الرئيسية',
        value: [
          '`/tickets` — لوحة إدارة التذاكر الكاملة',
          '`/ticketsetup` — إعداد نظام التذاكر',
          '`/ticketnotify` — إعداد إشعارات التذاكر',
          '`/ticketrating` — عرض تقييمات التذاكر',
        ].join('\n'),
      },
      {
        name: '🎛️ أزرار التذكرة',
        value: [
          '**📌 استلام** — يستلم الموظف التذكرة ويصبح مسؤولاً عنها',
          '**🔴 إغلاق** — إغلاق التذكرة مع طلب تأكيد',
          '**📝 إعادة تسمية** — تغيير اسم قناة التذكرة',
          '**➕ إضافة عضو** — إضافة شخص للتذكرة',
          '**➖ إزالة عضو** — إزالة شخص من التذكرة',
          '**📄 سجل** — تحميل نسخة من المحادثة',
          '**🔄 إعادة فتح** — فتح تذكرة مغلقة مجدداً',
          '**🗑️ حذف** — حذف التذكرة نهائياً',
        ].join('\n'),
      },
      {
        name: '⚙️ الإعدادات',
        value: [
          '• **التصنيفات** — تحديد Category لكل نوع تذكرة',
          '• **الأدوار** — Support Role و Moderator Role',
          '• **قناة السجل** — توثيق جميع التذاكر',
          '• **الحذف التلقائي** — حذف التذاكر المغلقة بعد X دقيقة',
          '• **الاستلام التلقائي** — Auto Claim للموظفين',
          '• **الإغلاق التلقائي** — إغلاق التذاكر غير النشطة',
          '• **التذكيرات** — تذكير الموظفين بالتذاكر المعلّقة',
        ].join('\n'),
      },
      {
        name: '💡 مثال',
        value: '`/ticketsetup` ثم اضغط **"إعداد جديد"** واختر القناة والأدوار.',
      }
    );
}

function buildProtectionEmbed(settings) {
  return baseEmbed(settings)
    .setTitle('🛡️ قسم الحماية')
    .setDescription('> أنظمة الحماية من الهجمات والسبام والنيوك.\n> **الصلاحية المطلوبة:** Administrator.')
    .addFields(
      {
        name: '⚔️ Anti-Nuke',
        value: [
          '`/antinuke` — إعداد نظام Anti-Nuke',
          '• يرصد: حذف القنوات، حذف الأدوار، بان جماعي، تغيير إعدادات السيرفر',
          '• الإجراء التلقائي: سحب الصلاحيات أو بان المسؤول المخالف',
        ].join('\n'),
      },
      {
        name: '🌊 Anti-Raid',
        value: [
          '`/antiraid` — إعداد نظام Anti-Raid',
          '• يرصد: دخول أعداد كبيرة فجأة',
          '• الإجراء التلقائي: كيك أو بان أو تفعيل وضع الفحص',
        ].join('\n'),
      },
      {
        name: '🤖 AutoMod',
        value: [
          '`/automod` — إعداد AutoMod',
          '`/mentionprotect` — حماية من الذكر الجماعي',
          '• يرصد: الروابط، الكلمات المحظورة، الإيموجي الزائد، تكرار الرسائل',
        ].join('\n'),
      },
      {
        name: '💡 نصيحة',
        value: '> تأكد من إضافة أدوار الثقة في إعدادات Anti-Nuke لتفادي إيقاف البوتات الأخرى.',
      }
    );
}

function buildMusicEmbed(settings) {
  return baseEmbed(settings)
    .setTitle('🎵 قسم الموسيقى')
    .setDescription('> أوامر تشغيل الموسيقى عبر صوتيات Discord.\n> **المتطلب:** وجودك في روم صوتي.')
    .addFields(
      {
        name: '▶️ التشغيل الأساسي',
        value: [
          '`/play` — تشغيل أغنية (بالاسم أو رابط)',
          '`/pause` — إيقاف مؤقت',
          '`/resume` — استئناف التشغيل',
          '`/stop` — إيقاف التشغيل وإفراغ القائمة',
          '`/skip` — تخطي الأغنية الحالية',
          '`/nowplaying` — عرض الأغنية الحالية',
        ].join('\n'),
      },
      {
        name: '📋 إدارة القائمة',
        value: [
          '`/queue` — عرض قائمة الأغاني',
          '`/remove` — حذف أغنية من القائمة',
          '`/shuffle` — خلط ترتيب القائمة',
          '`/loop` — تكرار الأغنية أو القائمة',
          '`/history` — عرض سجل الأغاني المشغّلة',
        ].join('\n'),
      },
      {
        name: '🎛️ تحكم متقدم',
        value: [
          '`/volume` — ضبط مستوى الصوت (0-100)',
          '`/seek` — الانتقال لوقت معيّن في الأغنية',
          '`/filters` — تطبيق تأثيرات صوتية',
          '`/autoplay` — تشغيل تلقائي لأغاني مشابهة',
          '`/lyrics` — عرض كلمات الأغنية الحالية',
          '`/247` — تشغيل البوت 24/7 في الروم',
          '`/playlist` — إدارة قوائم التشغيل المحفوظة',
          '`/favorites` — الأغاني المفضّلة',
        ].join('\n'),
      },
      {
        name: '🎛️ أزرار المشغّل',
        value: [
          '**⏸ إيقاف/▶ تشغيل** — تبديل حالة التشغيل',
          '**⏭ تخطي** — تخطي للأغنية التالية',
          '**🔁 تكرار** — تبديل وضع التكرار',
          '**🔀 خلط** — خلط القائمة',
          '**❤️ مفضلة** — إضافة الأغنية للمفضلة',
          '**📋 القائمة** — عرض قائمة الانتظار',
        ].join('\n'),
      },
      {
        name: '💡 مثال',
        value: '`/play song:Naruto OST` أو أرسل رابط يوتيوب مباشرة.',
      }
    );
}

function buildEconomyEmbed(settings) {
  return baseEmbed(settings)
    .setTitle('💰 قسم الاقتصاد')
    .setDescription('> نظام الاقتصاد والعملات الافتراضية.\n> يعمل تلقائياً بعد تفعيل النظام في الإعدادات.')
    .addFields(
      {
        name: '💸 الأوامر',
        value: [
          '`/balance` — عرض رصيدك الحالي',
          '`/work` — كسب عملات يومياً',
          '`/redeem` — استرداد كود مكافأة',
          '`/rep` — منح نقطة سمعة لعضو',
          '`/rep-stats` — عرض إحصائيات السمعة',
        ].join('\n'),
      },
      {
        name: '🛒 المحل',
        value: [
          'يمكن إعداد المحل من `/admin` → Economy',
          '• إضافة عناصر للبيع بالعملات',
          '• ربط عناصر بأدوار Discord تلقائياً',
          '• تسليم داخل لعبة Minecraft (اختياري)',
        ].join('\n'),
      }
    );
}

function buildLevelingEmbed(settings) {
  return baseEmbed(settings)
    .setTitle('⭐ قسم المستويات')
    .setDescription('> نظام XP والمستويات مع مكافآت الأدوار.\n> **الصلاحية لإعداد النظام:** Manage Server.')
    .addFields(
      {
        name: '📋 الأوامر',
        value: [
          '`/rank` — عرض مستواك الحالي وXP',
          '`/leaderboard` — ترتيب أعلى الأعضاء XP',
          '`/leveling` — إعداد نظام المستويات',
          '`/levelreward` — إعداد مكافآت الأدوار عند الوصول لمستوى',
          '`/levelroles` — عرض قائمة مكافآت الأدوار',
          '`/voiceleveling` — إعداد XP الأرومات الصوتية',
        ].join('\n'),
      },
      {
        name: '⚙️ الإعدادات',
        value: [
          '• **XP الرسائل** — XP لكل رسالة (افتراضي 15-25)',
          '• **XP الصوت** — XP مقابل كل دقيقة في روم صوتي',
          '• **قناة الإشعارات** — إشعار عند الارتقاء لمستوى جديد',
          '• **رسالة الترقية** — تخصيص رسالة الترحيب بالمستوى الجديد',
          '• **الأدوار المعفاة** — إعفاء أدوار معيّنة من كسب XP',
        ].join('\n'),
      }
    );
}

function buildGiveawaysEmbed(settings) {
  return baseEmbed(settings)
    .setTitle('🎉 قسم السحوبات')
    .setDescription('> نظام السحوبات التلقائية.\n> **الصلاحية:** Manage Server لإنشاء السحوبات.')
    .addFields(
      {
        name: '📋 الأوامر',
        value: [
          '`/gstart` — إنشاء سحب جديد',
          '`/gend` — إنهاء سحب قبل موعده',
          '`/greroll` — إعادة سحب فائز جديد',
          '`/glist` — عرض قائمة السحوبات النشطة',
        ].join('\n'),
      },
      {
        name: '⚙️ خيارات إنشاء السحب',
        value: [
          '• **المدة** — مثال: `1h`، `1d`، `7d`',
          '• **عدد الفائزين** — من 1 إلى 20',
          '• **الجائزة** — وصف الجائزة',
          '• **دور مطلوب** — تقييد السحب لأصحاب دور معيّن',
          '• **الحد الأدنى للمستوى** — تقييد بمستوى XP',
        ].join('\n'),
      },
      {
        name: '💡 مثال',
        value: '`/gstart prize:نيترو duration:24h winners:1`',
      }
    );
}

function buildSettingsEmbed(settings) {
  return baseEmbed(settings)
    .setTitle('⚙️ قسم الإعدادات')
    .setDescription('> إعدادات البوت والسيرفر.\n> **الصلاحية:** Manage Server أو Administrator.')
    .addFields(
      {
        name: '🔧 الأوامر الرئيسية',
        value: [
          '`/settings` — لوحة الإعدادات العامة',
          '`/admin` — لوحة الإدارة المتقدمة',
          '`/language` — تغيير لغة البوت (عربي/English)',
          '`/logs` — إعداد قنوات السجلات',
          '`/setwelcome` — إعداد رسالة الترحيب والوداع',
          '`/branding` — تخصيص لون وشعار البوت',
          '`/backup` — نسخ احتياطي لإعدادات السيرفر',
          '`/configbackup` — استعادة إعدادات من نسخة احتياطية',
        ].join('\n'),
      },
      {
        name: '📢 أوامر أخرى',
        value: [
          '`/announcement` — إعداد قناة الإعلانات',
          '`/autoresponder` — ردود تلقائية على رسائل معيّنة',
          '`/sticky` — رسائل مثبّتة تلقائياً في أسفل القناة',
          '`/antiraid` — إعداد الحماية من الريد',
        ].join('\n'),
      },
      {
        name: '⚙️ اللوحات التفاعلية',
        value: [
          '> يمكنك إدارة معظم الأنظمة من لوحة `/admin` بدلاً من الأوامر المنفردة.',
          '> اللوحة تحتوي على: Tickets · Moderation · Protection · Economy · Leveling · Logging · Welcome · AutoMod · Suggestions · Booster · MemberCount · Starboard · Counting',
        ].join('\n'),
      }
    );
}

function buildUtilityEmbed(settings) {
  return baseEmbed(settings)
    .setTitle('🔧 قسم الأدوات')
    .setDescription('> أوامر متعددة الاستخدامات للأعضاء والإدارة.')
    .addFields(
      {
        name: '📋 الأوامر',
        value: [
          '`/ping` — عرض تأخير البوت وقاعدة البيانات',
          '`/stats` — إحصائيات البوت',
          '`/serverinfo` — معلومات السيرفر',
          '`/userinfo` — معلومات عضو',
          '`/poll` — إنشاء استطلاع رأي',
          '`/remindme` — تذكير شخصي',
          '`/afk` — تفعيل وضع AFK',
          '`/snipe` — عرض آخر رسالة محذوفة',
          '`/tag` — إنشاء وإدارة الردود السريعة',
          '`/embedbuilder` — إنشاء Embed مخصص',
          '`/webhooks` — إدارة الويب هوكس',
          '`/emojisteal` — سرقة إيموجي من سيرفر آخر',
          '`/suggestion` — إرسال مقترح للإدارة',
          '`/invites` — تتبع الدعوات',
          '`/autorole` — أدوار تلقائية للأعضاء الجدد',
          '`/role` — إضافة/إزالة دور من عضو',
          '`/temprole` — دور مؤقت لعضو',
          '`/reactionrole` — أدوار عبر التفاعلات',
          '`/rolemenu` — قائمة اختيار الأدوار',
        ].join('\n'),
      }
    );
}

function buildMinecraftEmbed(settings) {
  return baseEmbed(settings)
    .setTitle('⛏️ قسم Minecraft')
    .setDescription('> أوامر خاصة بسيرفرات Minecraft.\n> **ملاحظة:** بعض الأوامر تتطلب تفعيل الربط أولاً.')
    .addFields(
      {
        name: '🔗 ربط الحسابات',
        value: [
          '`/mclink` — ربط حساب Minecraft بحسابك في Discord',
          '`/mcunlink` — إلغاء ربط الحساب',
          '`/mcprofile` — عرض ملف لاعب Minecraft',
        ].join('\n'),
      },
      {
        name: '📡 معلومات السيرفر',
        value: [
          '`/ip` — عرض IP سيرفر Minecraft',
          '`/minecraft` — معلومات تفصيلية عن السيرفر',
          '`/setupstatus` — إعداد لوحة حالة السيرفر',
          '`/mcconfig` — إعداد اتصال سيرفر Minecraft',
        ].join('\n'),
      },
      {
        name: '🎮 داخل اللعبة',
        value: [
          '`/inv` — عرض inventory اللاعب (يتطلب ربط)',
          '`/link` — ربط حساب خاص بسيرفر معيّن',
        ].join('\n'),
      }
    );
}

// ─── بناء Embed حسب القسم ────────────────────────────────────────────────────

function buildSectionEmbed(section, settings) {
  switch (section) {
    case 'home': return buildHomeEmbed(settings);
    case 'moderation': return buildModerationEmbed(settings);
    case 'tickets': return buildTicketsEmbed(settings);
    case 'protection': return buildProtectionEmbed(settings);
    case 'music': return buildMusicEmbed(settings);
    case 'economy': return buildEconomyEmbed(settings);
    case 'leveling': return buildLevelingEmbed(settings);
    case 'giveaways': return buildGiveawaysEmbed(settings);
    case 'settings': return buildSettingsEmbed(settings);
    case 'utility': return buildUtilityEmbed(settings);
    case 'minecraft': return buildMinecraftEmbed(settings);
    default: return buildHomeEmbed(settings);
  }
}

// ─── بناء مكونات القائمة ─────────────────────────────────────────────────────

function buildSelectMenu(currentSection) {
  const options = Object.entries(SECTIONS).map(([value, { label, description }]) => ({
    label,
    description,
    value,
    default: value === currentSection,
  }));

  return new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId('help_section_select')
      .setPlaceholder('📖 اختر قسماً...')
      .addOptions(options)
  );
}

function buildButtons(currentSection) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('help_home')
      .setLabel('🏠 الرئيسية')
      .setStyle(currentSection === 'home' ? ButtonStyle.Primary : ButtonStyle.Secondary)
      .setDisabled(currentSection === 'home'),
    new ButtonBuilder()
      .setCustomId('help_close')
      .setLabel('✖ إغلاق')
      .setStyle(ButtonStyle.Danger)
  );
}

// ─── الأمر ──────────────────────────────────────────────────────────────────

module.exports = {
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('مركز المساعدة الشامل لـ NYXO BOT')
    .setDescriptionLocalizations({ ar: 'مركز المساعدة الشامل لـ NYXO BOT', 'en-US': 'NYXO BOT complete help center' })
    .addStringOption((o) =>
      o.setName('command')
        .setDescription('عرض تفاصيل أمر معيّن')
        .setDescriptionLocalizations({ ar: 'عرض تفاصيل أمر معيّن', 'en-US': 'Get details about one specific command' })
        .setAutocomplete(true)
    ),

  autocomplete: safeAutocomplete(async (interaction) => {
    return commandNameChoices(interaction, interaction.options.getFocused());
  }),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    // ── عرض تفاصيل أمر محدد ─────────────────────────────────────────────
    const requested = interaction.options.getString('command');
    if (requested) {
      const name = requested.replace(/^\//, '').toLowerCase();
      const command = interaction.client.commands.get(name);

      if (!command) {
        return interaction.reply({
          embeds: [
            baseEmbed(settings)
              .setColor(0xe74c3c)
              .setDescription(`❌ لا يوجد أمر باسم \`${requested}\`.\nاستخدم \`/help\` لرؤية جميع الأوامر المتاحة.`),
          ],
          flags: MessageFlags.Ephemeral,
        });
      }

      const json = command.data.toJSON();
      const embed = baseEmbed(settings)
        .setTitle(`📖 /${json.name}`)
        .setDescription(json.description_localizations?.ar || json.description || '—');

      if (json.options?.length) {
        const optLines = json.options.map((opt) => {
          const req = opt.required ? ' *(مطلوب)*' : ' *(اختياري)*';
          const desc = opt.description_localizations?.ar || opt.description || '';
          return `\`${opt.name}\`${req} — ${desc}`;
        });
        embed.addFields({ name: '📝 الخيارات', value: optLines.join('\n').slice(0, 1024) });
      }

      embed.addFields({ name: '💡 نصيحة', value: 'استخدم `/help` للعودة إلى مركز المساعدة الكامل.' });
      return interaction.reply({ embeds: [embed] });
    }

    // ── مركز المساعدة التفاعلي ───────────────────────────────────────────
    let currentSection = 'home';

    const reply = await interaction.reply({
      embeds: [buildSectionEmbed(currentSection, settings)],
      components: [buildSelectMenu(currentSection), buildButtons(currentSection)],
      fetchReply: true,
    });

    const collector = reply.createMessageComponentCollector({
      filter: (i) => i.user.id === interaction.user.id,
      time: 5 * 60 * 1000, // 5 دقائق
    });

    collector.on('collect', async (i) => {
      try {
        // زر الإغلاق
        if (i.customId === 'help_close') {
          collector.stop('closed');
          await i.update({ components: [] });
          return;
        }

        // زر الرئيسية
        if (i.customId === 'help_home') {
          currentSection = 'home';
          await i.update({
            embeds: [buildSectionEmbed(currentSection, settings)],
            components: [buildSelectMenu(currentSection), buildButtons(currentSection)],
          });
          return;
        }

        // Select Menu
        if (i.customId === 'help_section_select') {
          currentSection = i.values[0];
          await i.update({
            embeds: [buildSectionEmbed(currentSection, settings)],
            components: [buildSelectMenu(currentSection), buildButtons(currentSection)],
          });
          return;
        }
      } catch (err) {
        // Interaction قد تكون انتهت صلاحيتها — تجاهل بهدوء
      }
    });

    collector.on('end', async (_, reason) => {
      if (reason === 'closed') return;
      try {
        await reply.edit({ components: [] });
      } catch (_) {
        // الرسالة محذوفة أو لا يمكن تعديلها
      }
    });
  },
};
