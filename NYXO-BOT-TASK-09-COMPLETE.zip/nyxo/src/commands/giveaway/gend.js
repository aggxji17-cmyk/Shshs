const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { isModerator } = require('../../utils/permissions');
const Giveaway = require('../../database/models/Giveaway');
const { endGiveaway } = require('../../services/giveawayService');
const { safeAutocomplete, fuzzyFilter } = require('../../utils/autocomplete');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('gend')
    .setDescription('End a giveaway immediately')
    .setDescriptionLocalizations({ ar: 'إنهاء سحب الهدايا فوراً', 'en-US': 'End a giveaway immediately' })
    .addStringOption((o) => o.setName('message_id').setDescription('The giveaway message ID').setDescriptionLocalizations({ ar: 'معرّف رسالة سحب الهدايا', 'en-US': 'The giveaway message ID' }).setRequired(true).setAutocomplete(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  // Only still-running giveaways make sense to end, so the suggestion
  // list is scoped to { guildId, ended: false } - no wasted taps on an
  // already-finished giveaway.
  autocomplete: safeAutocomplete(async (interaction) => {
    if (!interaction.guildId) return [];
    const focused = String(interaction.options.getFocused());

    const active = await Giveaway.find({ guildId: interaction.guildId, ended: false })
      .sort({ endsAt: 1 })
      .limit(25)
      .select('messageId prize endsAt');

    const matched = fuzzyFilter(active, focused, { key: (g) => g.messageId });
    return matched.map((g) => ({
      name: `${g.prize} • ends ${g.endsAt.toISOString().slice(0, 16).replace('T', ' ')} • ${g.messageId}`,
      value: g.messageId,
    }));
  }),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isModerator(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'ليس لديك صلاحية استخدام هذا الأمر.')], ephemeral: true });
    }

    const messageId = interaction.options.getString('message_id');
    const giveaway = await Giveaway.findOne({ guildId: interaction.guildId, messageId });

    if (!giveaway) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'لم يتم العثور على سحب بهذا المعرف في هذا السيرفر.')], ephemeral: true });
    }
    if (giveaway.ended) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'هذا السحب انتهى بالفعل.')], ephemeral: true });
    }

    await interaction.deferReply({ ephemeral: true });
    await endGiveaway(interaction.client, messageId);
    await interaction.editReply({ embeds: [successEmbed(settings, 'تم إنهاء السحب.')] });
  },
};
