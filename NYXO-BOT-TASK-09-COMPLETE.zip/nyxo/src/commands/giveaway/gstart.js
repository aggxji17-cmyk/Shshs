const { SlashCommandBuilder, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed, baseEmbed } = require('../../utils/embeds');
const { isModerator } = require('../../utils/permissions');
const Giveaway = require('../../database/models/Giveaway');

function parseDuration(input) {
  const match = /^(\d+)([smhd])$/i.exec(input.trim());
  if (!match) return null;
  const [, amountStr, unit] = match;
  const amount = parseInt(amountStr, 10);
  const multipliers = { s: 1000, m: 60000, h: 3600000, d: 86400000 };
  return amount * multipliers[unit.toLowerCase()];
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('gstart')
    .setDescription('Start a giveaway')
    .setDescriptionLocalizations({ ar: 'بدء سحب هدايا', 'en-US': 'Start a giveaway' })
    .addStringOption((o) => o.setName('duration').setDescription('e.g. 30s, 10m, 2h, 1d').setDescriptionLocalizations({ ar: 'مثل 30s أو 10m أو 2h أو 1d', 'en-US': 'e.g. 30s, 10m, 2h, 1d' }).setRequired(true))
    .addStringOption((o) => o.setName('prize').setDescription('What are you giving away?').setDescriptionLocalizations({ ar: 'ما الذي تقدمه في السحب؟', 'en-US': 'What are you giving away?' }).setRequired(true))
    .addIntegerOption((o) => o.setName('winners').setDescription('Number of winners').setDescriptionLocalizations({ ar: 'عدد الفائزين', 'en-US': 'Number of winners' }).setMinValue(1).setMaxValue(20))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isModerator(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'ليس لديك صلاحية استخدام هذا الأمر.')], ephemeral: true });
    }

    const durationMs = parseDuration(interaction.options.getString('duration'));
    if (!durationMs) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'صيغة المدة غير صحيحة. استخدم مثلاً: 30s أو 10m أو 2h أو 1d.')], ephemeral: true });
    }

    const prize = interaction.options.getString('prize');
    const winnerCount = interaction.options.getInteger('winners') || 1;
    const endsAt = new Date(Date.now() + durationMs);

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('giveaway_join').setLabel('Enter Giveaway').setEmoji('🎉').setStyle(ButtonStyle.Success)
    );

    const embed = baseEmbed(settings)
      .setTitle('🎉 Giveaway')
      .setDescription(`**Prize:** ${prize}\n**Winners:** ${winnerCount}\n**Ends:** <t:${Math.floor(endsAt.getTime() / 1000)}:R>`)
      .setFooter({ text: `Hosted by ${interaction.user.username}` });

    const message = await interaction.channel.send({ embeds: [embed], components: [row] });

    await Giveaway.create({
      guildId: interaction.guildId,
      channelId: interaction.channelId,
      messageId: message.id,
      hostId: interaction.user.id,
      prize,
      winnerCount,
      endsAt,
    });

    await interaction.reply({ embeds: [successEmbed(settings, 'تم إطلاق السحب!')], ephemeral: true });
  },
};
