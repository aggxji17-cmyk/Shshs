const { SlashCommandBuilder } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { baseEmbed, errorEmbed } = require('../../utils/embeds');
const Giveaway = require('../../database/models/Giveaway');

module.exports = {
  data: new SlashCommandBuilder().setName('glist').setDescription('List currently active giveaways in this server')
    .setDescriptionLocalizations({ ar: 'عرض السحوبات النشطة حالياً في هذا السيرفر', 'en-US': 'List currently active giveaways in this server' }),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    const active = await Giveaway.find({ guildId: interaction.guildId, ended: false }).sort({ endsAt: 1 });

    if (!active.length) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'There are no active giveaways right now.')], ephemeral: true });
    }

    const description = active
      .map(
        (g) =>
          `**${g.prize}** in <#${g.channelId}>\nEnds <t:${Math.floor(g.endsAt.getTime() / 1000)}:R> - \`${g.messageId}\``
      )
      .join('\n\n');

    await interaction.reply({ embeds: [baseEmbed(settings).setTitle('🎉 السحوبات النشطة').setDescription(description)] });
  },
};
