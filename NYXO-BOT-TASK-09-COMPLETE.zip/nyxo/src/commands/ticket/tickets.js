const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
// Task 46: فحص الصلاحيات وفتح الواجهة عبر commandRouter مركزياً.
const { routeCommand } = require('../../utils/commandRouter');

/**
 * Task 32 — Tickets Dashboard (لوحة إدارة التذاكر).
 *
 * A single `/tickets` command that becomes the central hub for the
 * ticket system's own settings/tools, the same way `/admin` (Tasks
 * 30/31) is the central hub for the guild's other admin-tier systems -
 * see `utils/ticketDashboard.js`'s top comment for why this is a
 * separate command/dashboard rather than nested inside `/admin`'s
 * existing "Tickets" section.
 *
 * Permission gate: uses the same `isGuildManager()` check every
 * ticket-config command in this project already uses (see
 * `commands/ticket/ticketsetup.js`), not the stricter Administrator-only
 * gate `/admin` uses - ticket configuration in this project has always
 * been ManageGuild-tier, and this dashboard does not change that.
 * `setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)` mirrors
 * `/ticketsetup` so Discord's own command list hides it from members who
 * could never pass the in-code check anyway; the in-code isGuildManager()
 * check below (and re-checked on every component interaction - see
 * `components/buttons.js` ticketdash_home/ticketdash_back/ticketdash_close
 * and `components/selectMenus.js` ticketdash_nav) remains the real gate,
 * since a server owner can widen the Discord-level default per-role.
 *
 * Like `/admin`, this command only builds the navigation shell (Task 32);
 * it does not move any actual ticket settings/tools into the UI yet -
 * that starts with Task 33 (Ticket Settings UI) and continues through
 * later tasks in this phase. No existing ticket command is removed or
 * changed by this task.
 */
module.exports = {
  data: new SlashCommandBuilder()
    .setName('tickets')
    .setDescription('Open the tickets management dashboard')
    .setDescriptionLocalizations({
      ar: 'فتح لوحة إدارة نظام التذاكر',
      'en-US': 'Open the tickets management dashboard',
    })
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction) {
    // Task 46: فحص الصلاحيات والتسجيل وفتح الواجهة عبر Router مركزياً.
    return routeCommand(interaction, 'tickets');
  },
};
