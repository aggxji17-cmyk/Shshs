require('./legacy/compat');

const { REST, Routes, Collection } = require('discord.js');
const { config, validateConfig, BOT_MODE } = require('./config/config');
const logger = require('./utils/logger');
const loadCommands = require('./handlers/commandHandler');

validateConfig();

// All recognized bot keys. In unified mode every key maps to the same
// single Discord application; the array is kept so tooling and tests
// that iterate over it continue to work unchanged.
const validBotKeys = ['bot1', 'bot2', 'bot3'];

/**
 * Deploy commands for a specific bot key and optional guild.
 *
 * `config.bots[botKey]` carries the per-bot token and clientId.
 * In unified mode those entries all point at the same credentials,
 * so the final REST call is always against the one Discord application.
 */
async function deployForBot(botKey, guildId) {
  const botConfig = config.bots[botKey];
  const token = botConfig?.token || config.token;
  const clientId = botConfig?.clientId || config.clientId;

  if (!token) {
    logger.warn(`[${botKey}] TOKEN is missing — skipping command registration.`);
    return;
  }

  const commandClient = { commands: new Collection(), botKey };
  loadCommands(commandClient);
  const commands = [...commandClient.commands.values()].map((command) => command.data.toJSON());

  if (!commands.length) {
    logger.warn(`[${botKey}] No commands were loaded — skipping registration to avoid wiping existing commands.`);
    return;
  }

  const rest = new REST().setToken(token);
  const resolvedClientId = clientId || (await rest.get(Routes.currentApplication())).id;

  if (!resolvedClientId) {
    logger.warn(`[${botKey}] CLIENT_ID could not be resolved — skipping command registration.`);
    return;
  }

  logger.info(`[${botKey}] Registering ${commands.length} application commands...`);

  if (guildId) {
    await rest.put(Routes.applicationGuildCommands(resolvedClientId, guildId), { body: commands });
    logger.success(`[${botKey}] Registered commands to guild ${guildId} (instant).`);
  } else {
    await rest.put(Routes.applicationCommands(resolvedClientId), { body: commands });
    logger.success(`[${botKey}] Registered global commands (may take up to an hour to appear).`);
  }
}

/**
 * In unified mode all bot keys share the same token and clientId, so
 * iterating over all three would make three identical REST calls. This
 * helper performs the single deployment that covers all commands when
 * running in unified-bot mode.
 */
async function deployUnified(guildId) {
  const token = config.token;
  const clientId = config.clientId;
  const label = '[unified]';

  if (!token) {
    logger.warn(`${label} DISCORD_TOKEN is missing — skipping command registration.`);
    return;
  }

  // In unified mode there is no botKey filter: every command is loaded.
  const commandClient = { commands: new Collection() };
  loadCommands(commandClient);
  const commands = [...commandClient.commands.values()].map((command) => command.data.toJSON());

  if (!commands.length) {
    logger.warn(`${label} No commands were loaded — skipping registration to avoid wiping existing commands.`);
    return;
  }

  const rest = new REST().setToken(token);
  const resolvedClientId = clientId || (await rest.get(Routes.currentApplication())).id;

  if (!resolvedClientId) {
    logger.warn(`${label} CLIENT_ID could not be resolved — skipping command registration.`);
    return;
  }

  logger.info(`${label} Registering ${commands.length} application commands...`);

  if (guildId) {
    await rest.put(Routes.applicationGuildCommands(resolvedClientId, guildId), { body: commands });
    logger.success(`${label} Registered commands to guild ${guildId} (instant).`);
  } else {
    await rest.put(Routes.applicationCommands(resolvedClientId), { body: commands });
    logger.success(`${label} Registered global commands (may take up to an hour to appear).`);
  }
}

/**
 * Deploy commands for all bots (or a specific one if botKey is given).
 * Kept for backwards compatibility with scripts that call deploy() directly.
 *
 * In unified mode a single REST call covers all commands regardless of
 * which botKey (if any) is passed, since all keys share the same application.
 */
async function deploy(guildId, botKey) {
  if (BOT_MODE === 'unified') {
    await deployUnified(guildId);
    return;
  }
  if (botKey && validBotKeys.includes(botKey)) {
    await deployForBot(botKey, guildId);
    return;
  }
  // Default: deploy for all bots (multi-bot legacy mode)
  for (const key of validBotKeys) {
    await deployForBot(key, guildId);
  }
}

async function main() {
  const [arg1, arg2] = process.argv.slice(2);

  // Accept: [botKey] [guildId] or just [guildId]
  let botKey = null;
  let guildId = null;

  if (validBotKeys.includes(arg1)) {
    botKey = arg1;
    guildId = arg2 || null;
  } else {
    guildId = arg1 || null;
  }

  if (BOT_MODE === 'unified') {
    // Single application: one REST call, no per-bot iteration needed.
    if (botKey) {
      logger.info(`[deploy] Running in unified mode — botKey "${botKey}" is noted but one shared application is used.`);
    }
    await deployUnified(guildId);
    return;
  }

  if (botKey) {
    await deployForBot(botKey, guildId);
  } else {
    // Deploy all bots (multi-bot legacy mode)
    for (const key of validBotKeys) {
      await deployForBot(key, guildId);
    }
  }
}

main().catch((err) => {
  logger.error(`Failed to deploy commands: ${err.stack || err}`);
  process.exit(1);
});

module.exports = { deploy, deployForBot, deployUnified, validBotKeys };
