# Task 23 - تحسين تهيئة الخدمات (Services Initialization)

## الملخص
تم تحسين نظام تهيئة الخدمات بشكل كبير من خلال إنشاء إطار عمل مركزي يوحد:
- تهيئة الخدمات والجدولة الزمنية
- معالجة الأخطاء بشكل موحد
- ترتيب التهيئة المنطقي
- تنظيف الموارد عند الإيقاف

## الملفات الجديدة

### 1. `src/services/serviceManager.js`
إطار عمل مركزي لإدارة دورة حياة الخدمات:

**الميزات:**
- `register()`: تسجيل خدمة جديدة مع دالة التهيئة والإيقاف
- `initializeAll()`: تهيئة جميع الخدمات بتسلسل آمن
- `initialize()`: تهيئة خدمة واحدة محددة
- `get()`: الحصول على كائن الخدمة المهيأ
- `shutdownAll()`: إيقاف جميع الخدمات بشكل آمن
- `shutdown()`: إيقاف خدمة واحدة محددة
- `getStatus()`: الاستعلام عن حالة خدمة معينة
- `getStatusReport()`: تقرير شامل عن جميع الخدمات

**فوائد:**
- توحيد طريقة التعامل مع جميع الخدمات
- معالجة أخطاء منطقية (فشل خدمة واحدة لا يوقف الخدمات الأخرى)
- سهولة إضافة/إزالة خدمات جديدة
- توفير معلومات تشخيصية عن حالة الخدمات

### 2. `src/services/serviceInitializers.js`
ملف مركزي لدوال تهيئة الخدمات حسب نوع البوت:

**الدوال الرئيسية:**
- `initializeMusic()`: تهيئة خدمات الموسيقى (Kazagumo + 24/7)
- `initializeManagement()`: تهيئة خدمات الإدارة (جدولة + تذاكر)
- `initializeSystems()`: تهيئة خدمات النظام (هدايا + تذكيرات + إلخ)
- `initializeServicesForClient()`: تهيئة جميع الخدمات المناسبة للعميل

**الفوائد:**
- فصل منطق التهيئة عن معالج الأحداث
- سهولة إعادة استخدام التهيئة في أماكن أخرى
- توثيق واضح لكل مجموعة خدمات

## التعديلات الموجودة

### 1. `src/index.js`
**التحسينات:**
- إضافة ServiceManager لإدارة دورة حياة الخدمات
- تسجيل خدمة الموسيقى في المدير المركزي
- تحديث دالة `shutdown()` لإيقاف جميع الخدمات المدارة
- الحفاظ على fallback stoppers للخدمات القديمة

### 2. `src/events/client/ready.js`
**التحسينات:**
- استبدال 100+ سطر من التهيئة المباشرة برابط واحد إلى `initializeServicesForClient()`
- إضافة معالجة أخطاء شاملة مع Graceful degradation
- توثيق واضح لكل مرحلة تهيئة
- سهولة إضافة خدمات جديدة دون تعديل معالج الحدث

## أنماط الاستخدام

### إضافة خدمة جديدة إلى ServiceManager

```javascript
// في src/index.js أو أي مكان تهيئة:
const { CustomService } = require('./services/customService');

serviceManager.register(
  'custom',
  async () => {
    // دالة التهيئة
    await CustomService.initialize(client);
  },
  async () => {
    // دالة الإيقاف (اختيارية)
    await CustomService.cleanup();
  }
);

// في أي مكان آخر:
try {
  const customService = serviceManager.get('custom');
  await customService.doSomething();
} catch (err) {
  // Service not initialized
}
```

### الاستعلام عن حالة الخدمات

```javascript
const status = serviceManager.getStatusReport();
console.log(status);
// Output:
// {
//   music: { status: 'initialized', error: null },
//   moderation: { status: 'failed', error: '...' },
//   ...
// }
```

## الحفاظ على التوافق

- ✅ لا تم حذف أي ملفات أو ميزات
- ✅ كل الخدمات القديمة تعمل كما هي
- ✅ fallback stoppers محفوظة في دالة shutdown()
- ✅ السلوك الحالي محفوظ 100%

## الفوائد

### 1. **الموثوقية**
- معالجة منطقية للأخطاء
- عدم فقدان الخدمات عند فشل واحدة
- تسجيل منفصل لكل خدمة

### 2. **الصيانة**
- دورة حياة الخدمات واضحة
- سهولة تتبع المشاكل
- توحيد طريقة إدارة الخدمات

### 3. **التوسع**
- إضافة خدمات جديدة بسهولة
- إعادة استخدام التهيئة في أماكن أخرى
- معلومات تشخيصية دقيقة

### 4. **الأداء**
- تهيئة تسلسلية (بدون race conditions)
- إدارة موارد أفضل
- تنظيف نظيف عند الإيقاف

## الهيكل الجديد

```
src/
├── index.js (محدث: +ServiceManager)
├── services/
│   ├── serviceManager.js (جديد: مدير دورة الحياة)
│   ├── serviceInitializers.js (جديد: دوال التهيئة المنظمة)
│   ├── musicService.js (بدون تغيير)
│   ├── scheduleService.js (بدون تغيير)
│   └── ... (جميع الخدمات الأخرى بدون تغيير)
└── events/
    └── client/
        └── ready.js (محدث: استخدام serviceInitializers)
```

## الخطوات التالية الاختيارية

هذه التحسينات توفر الأساس لتحسينات مستقبلية:

1. **Dependency Injection**: إمرار serviceManager إلى جميع الخدمات
2. **Health Checks**: إضافة اختبارات دورية لصحة الخدمات
3. **Service Metrics**: تتبع أداء كل خدمة
4. **Dynamic Reload**: إعادة تحميل خدمة واحدة دون إيقاف البوت
5. **Service Dependencies**: تحديد ترتيب التهيئة بناءً على التبعيات

## الاختبار

```javascript
// اختبار المدير
const manager = new ServiceManager();

// تسجيل خدمة
manager.register('test', () => {
  console.log('Initializing...');
  return Promise.resolve({ value: 42 });
});

// تهيئة وتحقق
await manager.initialize('test');
const service = manager.get('test');
console.log(service.value); // 42

// استعلام عن الحالة
console.log(manager.getStatus('test')); 
// { status: 'initialized', error: null }
```

---
**تاريخ التحديث:** Task 23
**الحالة:** مكتمل ✓
