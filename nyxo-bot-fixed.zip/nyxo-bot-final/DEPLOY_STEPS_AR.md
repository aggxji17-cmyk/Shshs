# خطوات التنصيب على Pterodactyl (بالترتيب بالضبط)

## 1) ارفع الملفات
- افتح ملف مدير (File Manager) بلوحة Pterodactyl الخاصة بسيرفرك.
- احذف كل الملفات القديمة الموجودة حاليًا (أو على الأقل: node_modules,
  package-lock.json, src, index.js, package.json).
- ارفع ملف `nova-bot-task1-2-FIXED.zip` وفك ضغطه فوق مجلد السيرفر
  (Unzip/Extract من داخل لوحة Pterodactyl نفسها).
- تأكد إن ملفات المشروع صارت مباشرة داخل `/home/container` وليست داخل
  مجلد فرعي زيادة اسمه `nova-bot-task1-2`.

## 2) جهّز ملف .env
- انسخ `.env.example` وسمّه `.env`.
- افتحه وعبّي القيم المطلوبة على الأقل:
  - BOT_TOKEN
  - MONGODB_URL
  - DEVELOPER_ID
  - MINECRAFT_SERVER_IP
  - MINECRAFT_BEDROCK_PORT
- بدون هذي القيم، البوت ما راح يشتغل أصلاً (فيه فحص تلقائي بيوقفه
  برسالة واضحة توضح أي قيمة ناقصة).
- CLIENT_ID مطلوب بس لما تشغّل أمر تسجيل السلاش كوماند
  (npm run deploy-commands)، مو مطلوب لتشغيل البوت نفسه.

## 3) تأكد إن Startup Command صحيح
- في إعدادات السيرفر (Startup)، لازم يكون:
  ```
  node index.js
  ```
  (ملف index.js في الجذر يستدعي src/index.js تلقائيًا).

## 4) نظّف وثبّت من جديد (الخطوة الأهم)
افتح الـ Console بلوحة Pterodactyl واكتب بالترتيب:
```
rm -rf node_modules package-lock.json
npm install
```

## 5) شغّل البوت
```
npm start
```
أو اضغط زر Start من اللوحة مباشرة.

## لو ظهر MODULE_NOT_FOUND مرة ثانية
هذا يعني إن مجلد node_modules القديم رجع يتحمّل من كاش، جرب:
```
npm install youtubei.js@latest --force
```
ولو استمر، تأكد إن نسخة Node.js على السيرفر 18.17 أو أحدث (Node 22 اللي
ظاهرة بلوجاتك ممتازة ومدعومة).
