# سبب الكراش وحله

## السبب
الخطأ `MODULE_NOT_FOUND` كان يحصل داخل مكتبة `discord-player-youtubei`
(الملف `node_modules/discord-player-youtubei/dist/index.js:245`), أثناء تحميلها
من `src/services/musicService.js`.

هذه المكتبة تحتاج داخليًا لباكدج اسمه **`youtubei.js`** عشان تشتغل (هو المسؤول
عن الاتصال بيوتيوب فعليًا). في نسخة `package.json` القديمة، هذا الباكدج
ما كان موجود كـ dependency صريح، فـ npm ما كان يثبته دايمًا (خصوصًا لو صار
أي تعارض إصدارات أو تنصيب ناقص على السيرفر)، فلما discord-player-youtubei
يحاول يعمل `require('youtubei.js')` ما يلقاها ويطلع الخطأ ويطفي البوت.

## الحل المطبّق
تمت إضافة السطر التالي في `package.json`:

```json
"youtubei.js": "^13.0.0",
```

## خطوات التطبيق على السيرفر (Pterodactyl)
1. ارفع ملفات المشروع الجديدة (استبدل الملفات القديمة، أو فك الضغط فوقها).
2. **احذف** مجلد `node_modules` وملف `package-lock.json` بالكامل من السيرفر
   (مهم جدًا، عشان ما يفضل نسخة قديمة ناقصة).
3. شغّل:
   ```
   npm install
   ```
4. بعدها شغّل البوت عادي:
   ```
   npm start
   ```

لو ظهر نفس الخطأ بعد كذا (نادر)، جرب تثبيت الباكدج يدويًا:
```
npm install youtubei.js@latest
```

## تحديث 2
بعد حل مشكلة youtubei.js، ظهرت نفس المشكلة (MODULE_NOT_FOUND) لكن هذي
المرة لباكدج ثانية تحتاجها نفس المكتبة (`discord-player-youtubei`)
اختياريًا: **`youtube-dl-exec`**. تمت إضافتها في package.json:

```json
"youtube-dl-exec": "^3.1.9",
```

ملاحظة: هذي المكتبة تحتاج Python 3.9+ متوفر على السيرفر باسم `python3` أو
`python` عشان تنزّل ملف yt-dlp التنفيذي أثناء npm/yarn install
(preinstall). أغلب سيرفرات Node على Pterodactyl ما فيها Python أصلاً،
فالتثبيت كان يفشل بالكامل بسبب هذا الفحص.

## تحديث 3 (الحل النهائي - بدون الحاجة لتغيير أي إعداد باللوحة)
بدل ما نعتمد على تغيير أمر التشغيل أو متغيرات بيئة، تم نقل
`youtube-dl-exec` من `dependencies` إلى `optionalDependencies` في
package.json:

```json
"optionalDependencies": {
  "youtube-dl-exec": "^3.1.9"
}
```

npm/yarn يتعاملون مع فشل أي سكربت تثبيت (preinstall/postinstall) لباكدج
موجود بقسم optionalDependencies بشكل مختلف: يطلع تحذير (warning) بس
**يكمل باقي عملية التثبيت بنجاح** بدل ما يوقفها بالكامل. الملفات نفسها
لمكتبة youtube-dl-exec تتثبت عادي (فقط سكربت تحميل ملف yt-dlp التنفيذي
هو اللي يفشل بصمت)، وبما إن هذي المكتبة تستخدم فقط كخيار احتياطي نادر
جدًا داخل discord-player-youtubei (المصدر الأساسي هو youtubei.js)،
البوت يشتغل طبيعي بدونها.

## تحديث 4 (الحل الجذري النهائي)
تبين إن npm/yarn لما يفشل سكربت preinstall لمكتبة موجودة بقسم
optionalDependencies، **يحذفها بالكامل** من node_modules بدل ما يتجاهل
الفشل ويكمل - فرجعت مشكلة MODULE_NOT_FOUND من جديد لنفس السبب (غياب
Python بالسيرفر).

الحل النهائي: أضفنا سكربت `scripts/ensure-youtube-dl-stub.js` يشتغل
تلقائيًا بعد كل تثبيت (عن طريق `"postinstall"` بملف package.json).

- لو التثبيت الحقيقي لـ youtube-dl-exec نجح (يعني عندك Python)، السكربت
  ما يلمسه ويسيبه زي ما هو.
- لو فشل أو المكتبة مفقودة، السكربت ينشئ نسخة بديلة (stub) بسيطة بنفس
  الاسم والمكان تخلي أي require('youtube-dl-exec') ينجح دايمًا، وترمي
  خطأ واضح بس لو أحد فعليًا حاول يستخدمها (وهذا مسار احتياطي نادر جدًا
  غير مستخدم بالتشغيل العادي - المصدر الأساسي youtubei.js يشتغل طبيعي).

النتيجة: البوت يشتغل بنجاح **بغض النظر** عن وجود Python بالسيرفر من
عدمه، وبدون أي تغيير مطلوب من المستخدم على إعدادات اللوحة أو الكونسل.

## تحديث 5 (السبب الحقيقي للكراش اللي وصلني في اللوج - انحل نهائيًا)

بعد فحص اللوج الجديد، السبب مختلف شوي عن اللي كنا متوقعينه: الكراش ما كان
`Cannot find module` (يعني ملف الـ stub كان موجود ويشتغل) لكن كان:

```
TypeError: Cannot read properties of undefined (reading 'constants')
```

اللي كان يصير بالضبط عند السطر:

```js
var { YOUTUBE_DL_PATH, ... } = import_youtube_dl_exec2.default.constants;
```

**السبب:** الـ stub القديم كان مبني على `Proxy`:

```js
module.exports = new Proxy(notAvailable, { get() { return notAvailable; } });
```

مشكلة الـ Proxy هذا إنه يعترض بس أول مستوى وصول للخاصية. يعني لما
`discord-player-youtubei` يسوي:

```js
mod.default.constants
```

أول وصول (`mod.default`) يمر عبر الـ Proxy ويرجع `notAvailable` (دالة عادية
مالها Proxy). لكن ثاني وصول (`.constants` على النتيجة هذي) يصير على دالة
عادية مالها خاصية `constants` أصلاً → القيمة ترجع `undefined` → كراش فوري
وقت `require()`، قبل حتى لا يوصل الكود لأي try/catch.

**الحل النهائي المطبّق (بدون Proxy):**
تم تعديل `scripts/ensure-youtube-dl-stub.js` بحيث الـ stub الجديد كائن/دالة
عادية (مو Proxy) وفيها كل الخصائص المتوقعة بشكل حقيقي وثابت:

- `stub.constants` = كائن فيه `YOUTUBE_DL_PATH/HOST/DIR/FILE` حقيقية.
- `stub.default = stub` (مرجع ذاتي)، فأي سلسلة وصول زي `.default`،
  `.default.default`، إلخ ترجع نفس الكائن المكتمل - أبدًا مش `undefined`.
- استدعاء الـ stub كدالة (لو حد استخدمه فعليًا كـ fallback نادر) يرمي رسالة
  خطأ واضحة، لكن مجرد قراءة خصائصه (زي `constants`) وقت التحميل ما يكراش
  أبدًا.

تم اختبار كل احتمالات الوصول (`mod.constants`, `mod.default.constants`,
`mod.default.default.constants`) والتأكد إنها كلها ترجع قيم حقيقية بدون أي
كراش.

### خطوات التطبيق (نفسها من قبل)
1. ارفع الملفات الجديدة (استبدل القديمة).
2. احذف `node_modules` و`package-lock.json` بالكامل من السيرفر.
3. `npm install`
4. `npm start`
