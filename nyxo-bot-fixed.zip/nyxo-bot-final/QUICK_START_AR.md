# 🚀 دليل البدء السريع - NYXO BOT

## الخطوة 1: تثبيت المكتبات

```bash
npm install
# أو
pnpm install
```

**⏱️ هذه قد تستغرق 5-15 دقيقة حسب سرعة الإنترنت**

---

## الخطوة 2: إنشاء ملف `.env`

```bash
cp .env.example .env
```

ثم افتح الملف بأي محرر نصوص وأكمل القيم:

```bash
# نموذج سريع
BOT_TOKEN=YOUR_DISCORD_TOKEN_HERE
CLIENT_ID=YOUR_CLIENT_ID_HERE
CLIENT_SECRET=YOUR_CLIENT_SECRET_HERE
REDIRECT_URI=http://localhost:3000/auth/callback
DEVELOPER_ID=YOUR_DISCORD_ID_HERE
MONGODB_URL=mongodb+srv://username:password@cluster.mongodb.net/database
MINECRAFT_SERVER_IP=192.168.1.1
MINECRAFT_BEDROCK_PORT=19132
SESSION_SECRET=اجعله عشوائيًا طويل (32+ حرف)
PREFIX=!
```

---

## الخطوة 3: نشر الأوامر

```bash
npm run deploy-commands
```

**ملاحظة**: إذا كان لديك CLIENT_ID، يمكنك نشرها على سيرفر واحد فقط (أسرع):
```bash
npm run deploy-commands YOUR_GUILD_ID
```

---

## الخطوة 4: تشغيل البوت

```bash
npm start
```

**يجب أن ترى هذه الرسالة**:
```
[OK] Connected to MongoDB
[OK] Loaded 230 application commands
[OK] Loaded 22 events
[OK] Music player initialized
```

---

## 🎉 تم!

يجب أن يظهر البوت الآن في قائمة أعضاء السيرفر. جرب:
```
/@NYXO_BOT help
```

---

## 🐛 في حالة المشاكل

### ❌ `Cannot find module 'discord.js'`
**الحل**: لم تثبت المكتبات بعد
```bash
npm install
```

### ❌ `Missing required environment variables`
**الحل**: تحقق من `.env` وتأكد من وجود:
- `BOT_TOKEN`
- `MONGODB_URL`
- `DEVELOPER_ID`
- `MINECRAFT_SERVER_IP`
- `MINECRAFT_BEDROCK_PORT`

### ❌ `Failed to connect to MongoDB`
**الحل**: تحقق من رابط MongoDB:
```bash
# جرب الاتصال مباشرة
mongosh "mongodb+srv://username:password@cluster.mongodb.net/database"
```

### ❌ `Discord login failed`
**الحل**: تحقق من:
1. البوت Token صحيح
2. البوت مفعّل على صفحة Developer Portal
3. لديك الصلاحيات المطلوبة

---

## 📚 خطوات متقدمة

### تشغيل البوت بـ pm2 (للخوادم)

```bash
# تثبيت pm2
npm install -g pm2

# تشغيل البوت
pm2 start src/index.js --name "NYXO-Bot"

# عرض السجلات
pm2 logs NYXO-Bot

# إعادة تشغيل
pm2 restart NYXO-Bot

# إيقاف
pm2 stop NYXO-Bot
```

### تشغيل البوت بـ Docker

```bash
# بناء الصورة
docker build -t nyxo-bot .

# تشغيل
docker run --env-file .env nyxo-bot
```

### تشغيل لوحة التحكم

```bash
npm run dashboard
# ثم افتح: http://localhost:3000
```

---

## 🎵 تفعيل الموسيقى (خياري)

للموسيقى عالية الجودة، استخدم Lavalink:

```bash
# 1. شغّل Lavalink (Docker)
docker-compose -f lavalink/docker-compose.yml up -d

# 2. أضف في .env
LAVALINK_HOST=localhost
LAVALINK_PORT=2333
LAVALINK_PASSWORD=youshallnotpass
```

---

**تم! البوت جاهز الآن 🎉**
