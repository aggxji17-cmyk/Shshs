# 🚀 دليل التثبيت الفوري - NYXO BOT

## ✅ ما تم إضافته لك

- ✅ ملف `.env` جاهز (عدّل البيانات فقط)
- ✅ جميع الأكواد سليمة وجاهزة
- ✅ 230 أمر Discord
- ✅ 22 حدث
- ✅ 50 خدمة متقدمة

---

## 📋 خطوات التثبيت (5 دقائق)

### الخطوة 1️⃣: فتح ملف `.env` وتعديله

```bash
# افتح الملف بأي محرر نصوص
nano .env
# أو
vim .env
# أو استخدم VSCode/Notepad++
```

**المتغيرات الإجبارية التي تحتاج تعديل:**

```env
BOT_TOKEN=أدخل توكن البوت من Discord
CLIENT_ID=أدخل Client ID
CLIENT_SECRET=أدخل Client Secret
DEVELOPER_ID=أدخل Discord User ID خاصتك
MONGODB_URL=رابط قاعدة بيانات MongoDB
MINECRAFT_SERVER_IP=عنوان سيرفر Minecraft
MINECRAFT_BEDROCK_PORT=19132
SESSION_SECRET=جعل عشوائي (32+ حرف)
```

---

### الخطوة 2️⃣: تثبيت المكتبات

```bash
# اختر واحدة من الخيارات:

# الخيار 1: npm (الافتراضي)
npm install

# الخيار 2: pnpm (أسرع)
pnpm install

# الخيار 3: yarn
yarn install
```

**ملاحظة**: قد يستغرق 5-15 دقيقة حسب سرعة الإنترنت

---

### الخطوة 3️⃣: نشر الأوامر على Discord

```bash
# الطريقة 1: نشر عام (يظهر بعد ساعة)
npm run deploy-commands

# الطريقة 2: نشر على سيرفر واحد فقط (فوري)
npm run deploy-commands YOUR_GUILD_ID
```

---

### الخطوة 4️⃣: تشغيل البوت

```bash
# الطريقة 1: تشغيل عادي
npm start

# الطريقة 2: تطوير (auto-reload عند التعديل)
npm run dev

# الطريقة 3: استخدام pm2 (للخوادم)
pm2 start src/index.js --name "NYXO-Bot"
```

---

## ✨ يجب أن تري هذه الرسائل

```
[OK] Connected to MongoDB ✓
[OK] Loaded 230 application commands ✓
[OK] Loaded 22 events ✓
[OK] Music player initialized ✓
Bot is online! ✓
```

---

## 🎉 تم! البوت شغال

- البوت يجب أن يظهر في قائمة الأعضاء
- جرب أي أمر: `/help` أو `/ping`
- اذهب للوحة التحكم: `http://localhost:3000`

---

## 📞 لو حصلت مشكلة

### ❌ "Cannot find module"
```bash
rm -rf node_modules package-lock.json
npm install
```

### ❌ "Invalid token"
- تحقق من `BOT_TOKEN` في `.env`
- جرب توكن جديد من Discord Developer Portal

### ❌ "MongoDB connection failed"
- تحقق من `MONGODB_URL` في `.env`
- جرب الاتصال مباشرة: `mongosh "mongodb+srv://..."`

### ❌ "Interaction token invalid"
```bash
npm run deploy-commands
```

---

## 📚 ملفات مرجعية إضافية

- `COMPREHENSIVE_AUDIT_REPORT_AR.md` - فحص تفصيلي
- `QUICK_START_AR.md` - دليل بسيط
- `FIX_NOTES_MUSIC_CRASH.md` - شرح حل الموسيقى
- `DEPLOY_STEPS_AR.md` - خطوات نشر

---

## 🎵 لتفعيل الموسيقى (اختياري)

أضف في `.env`:

```env
YOUTUBE_COOKIE=your_youtube_cookie_here
LAVALINK_HOST=localhost
LAVALINK_PORT=2333
LAVALINK_PASSWORD=youshallnotpass
```

---

**البوت جاهز الآن! استمتع! 🎉**
