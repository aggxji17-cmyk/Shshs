const path = require('node:path');
const fs = require('node:fs');
const express = require('express');
const session = require('express-session');
const MongoStore = require('connect-mongo');
const { config } = require('../src/config/config');
const logger = require('../src/utils/logger');
const authRoutes = require('./routes/auth');
const createApiRouter = require('./routes/api');
const { apiLimiter, authLimiter, writeLimiter, sanitizeBody, securityHeaders } = require('./security');

// Ported v2.0.8 dashboard - kept alongside the current SPA dashboard
// under the /legacy prefix so its routes ("/guild/:id/...",
// "/api/guild/:id/...") can never collide with the live API's
// "/guilds/:id/..." routes above.
const legacyRouteFiles = [
  'applications', 'automod', 'autorole', 'backups', 'economy', 'embed',
  'engagement', 'guild', 'joinping', 'leave', 'leveling', 'logs', 'music',
  'premium', 'reactionrole', 'rolemenu', 'stats', 'sticky', 'ticket',
  'transcript', 'twitch', 'verification', 'welcome', 'youtube',
];
const adminRoutes = require('./adminRoutes');

function startDashboard(client) {
  const app = express();
  const isProduction = process.env.NODE_ENV === 'production';

  app.set('trust proxy', 1);
  // A few of the older dashboard route modules read the client from the
  // Express app. Keep that convention working alongside the newer closure
  // based API router.
  app.set('client', client);
  app.use(securityHeaders);

  // All legacy pages stay available, but receive the same accessibility,
  // language and visual polish layer as the current dashboard. Wrapping
  // sendFile here means new pages automatically get the treatment too,
  // without editing or removing any existing page-specific scripts.
  app.use((req, res, next) => {
    const originalSendFile = res.sendFile.bind(res);
    res.sendFile = (filePath, options, callback) => {
      const normalizedPath = path.resolve(String(filePath));
      const viewsRoot = path.resolve(__dirname, 'views');
      const isDashboardView =
        normalizedPath.startsWith(`${viewsRoot}${path.sep}`) &&
        path.extname(normalizedPath).toLowerCase() === '.html';

      if (!isDashboardView) {
        return originalSendFile(filePath, options, callback);
      }

      fs.readFile(normalizedPath, 'utf8', (error, html) => {
        if (error) {
          if (typeof callback === 'function') return callback(error);
          return next(error);
        }

        const enhancements = `
          <link rel="stylesheet" href="/css/nyxo-polish.css">
          <script src="/js/nyxo-polish.js" defer></script>
        `;
        const enhancedHtml = html.includes('nyxo-polish.css')
          ? html
          : html.replace(/<\/head>/i, `${enhancements}</head>`);
        res.type('html').send(enhancedHtml);
        if (typeof callback === 'function') callback();
      });
      return res;
    };
    next();
  });

  // Stripe verifies its webhook signature as an HMAC over the exact raw
  // request bytes. That only works if Stripe's SDK gets the untouched
  // body - if the global JSON parser below gets to it first, the exact
  // bytes are gone (re-serializing the parsed object never reproduces
  // the original signature). So this route's raw body is captured here,
  // before express.json() runs, and ONLY for this one path - every
  // other route still gets a normal parsed req.body via express.json().
  // Must stay registered before the express.json() call directly below.
  app.use('/legacy/webhook', express.raw({ type: '*/*', limit: '1mb' }));

  app.use(express.json({ limit: '1mb' }));
  app.use(
    session({
      secret: config.sessionSecret,
      resave: false,
      saveUninitialized: false,
      store: MongoStore.create({ mongoUrl: config.mongoUri, collectionName: 'dashboard_sessions' }),
      cookie: {
        maxAge: 1000 * 60 * 60 * 24 * 7,
        httpOnly: true,
        sameSite: 'lax',
        // Only require HTTPS-only cookies in production so local/dev
        // setups over plain http:// still work without extra config.
        secure: isProduction,
      },
    })
  );

  // Several legacy routes (premium.js, adminRoutes.js, automod.js, guild.js,
  // leveling.js, welcome.js, leave.js, backups.js, music.js) read
  // `req.user`, but the session middleware above only ever sets
  // `req.session.user`. Without this bridge those routes crash on
  // `Cannot read properties of undefined` (or, for adminRoutes.js's
  // `req.user.id !== DEVELOPER_ID` check, fail closed for everyone
  // including the real admin). Mirrors what dashboard/middleware/index.js
  // already does locally for `isAuth`.
  app.use((req, res, next) => {
    req.user = req.session.user || null;
    next();
  });

  app.use(sanitizeBody);
  app.use((req, res, next) => {
    if (['POST', 'PUT', 'DELETE', 'PATCH'].includes(req.method)) {
      return writeLimiter(req, res, next);
    }
    next();
  });

  app.use('/auth', authLimiter, authRoutes);
  app.use('/api', apiLimiter, createApiRouter(client));

  // The ported routes below still use the older req.client convention
  // instead of the closure-based createApiRouter(client) pattern.
  const legacyRouter = express.Router();
  legacyRouter.use((req, res, next) => {
    req.client = client;
    next();
  });
  for (const name of legacyRouteFiles) {
    legacyRouter.use(require(`./routes/${name}`));
  }
  legacyRouter.use('/admin', adminRoutes);
  app.use('/legacy', apiLimiter, legacyRouter);

  // Lightweight, unauthenticated health check for hosting panels / uptime
  // monitors (e.g. Pterodactyl, UptimeRobot). Deliberately excludes the
  // rate limiters and session middleware above it in the chain isn't
  // possible since it's registered after them, but the limiters are
  // generous enough that periodic health pings won't trip them.
  app.get('/health', (req, res) => {
    const mongoose = require('mongoose');
    res.json({
      status: 'ok',
      uptimeSeconds: Math.floor(process.uptime()),
      discord: {
        ready: Boolean(client?.isReady?.()),
        guilds: client?.guilds?.cache?.size ?? 0,
        ping: client?.ws?.ping ?? null,
      },
      database: {
        // 0=disconnected, 1=connected, 2=connecting, 3=disconnecting
        state: mongoose.connection.readyState,
      },
    });
  });

  app.use(express.static(path.join(__dirname, 'public')));
  app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
  });

  // Centralized error handler. Must have 4 args to be recognized by
  // Express as an error middleware. Placed last so any route/middleware
  // above that calls next(err) or throws synchronously lands here
  // instead of crashing the process or leaking a stack trace to the client.
  app.use((err, req, res, next) => {
    logger.error(`Dashboard route error [${req.method} ${req.originalUrl}]: ${err?.stack || err}`);
    if (res.headersSent) return next(err);
    res.status(err?.status || 500).json({ error: 'Internal server error' });
  });

  return app.listen(config.dashboardPort, () => {
    logger.success(`Dashboard listening on http://localhost:${config.dashboardPort}`);
  });
}

module.exports = startDashboard;
