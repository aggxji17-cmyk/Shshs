const express = require("express");
const router = express.Router();
const stripe = process.env.STRIPE_SECRET_KEY ? require("stripe")(process.env.STRIPE_SECRET_KEY) : null;
const PremiumPlan = require("../../src/database/models/premiumPlanSchema");
const PremiumGuild = require("../../src/database/models/premiumGuildSchema");
const { isAuth } = require("../middleware");

if (!stripe) {
    console.warn("[PAYMENTS] STRIPE_SECRET_KEY is missing. Premium checkout features will be disabled.");
}

// Helper to calculate expiration date
function calculateExpirationDate(days) {
    const date = new Date();
    date.setDate(date.getDate() + days);
    return date;
}

/* ========== Checkout Session ========== */
router.post("/checkout", isAuth, async (req, res) => {
    if (!stripe) {
        return res.status(503).json({ error: "Payments are currently unavailable (Stripe not configured)." });
    }
    const { guildId, planId } = req.body;

    if (!guildId || !planId) {
        return res.status(400).json({ error: "Missing guildId or planId" });
    }

    try {
        // Verify plan exists
        const plan = await PremiumPlan.findOne({ planId });
        if (!plan) {
            return res.status(404).json({ error: "Plan not found" });
        }

        // Check guild access (simplified auth check here, assuming isAuth handled basic session)
        const userGuild = req.user.guilds.find(g => g.id === guildId);
        if (!userGuild || (userGuild.permissions & 0x20) !== 0x20) {
            return res.status(403).json({ error: "No permission to manage this guild" });
        }

        // Create Stripe checkout session
        const session = await stripe.checkout.sessions.create({
            payment_method_types: ["card"],
            line_items: [
                {
                    price_data: {
                        currency: "usd",
                        product_data: {
                            name: `NYXO BOT Premium: ${plan.planName}`,
                            description: plan.description,
                        },
                        unit_amount: Math.round(plan.price * 100), // Stripe uses cents
                    },
                    quantity: 1,
                },
            ],
            mode: "payment",
            metadata: {
                guildId,
                planId,
                userId: req.user.id
            },
            success_url: `${req.protocol}://${req.get("host")}/guild/${guildId}?payment=success`,
            cancel_url: `${req.protocol}://${req.get("host")}/guild/${guildId}/premium-required?payment=cancelled`,
        });

        res.json({ url: session.url });
    } catch (err) {
        console.error("Stripe Checkout Error:", err);
        res.status(500).json({ error: "Failed to create checkout session" });
    }
});

/* ========== Webhook Listener ========== */
router.post("/webhook", async (req, res) => {
    if (!stripe) {
        return res.status(503).send("Stripe not configured");
    }
    const sig = req.headers["stripe-signature"];
    let event;

    const isProduction = process.env.NODE_ENV === 'production';

    // dashboard/server.js registers express.raw() for this exact path
    // (/legacy/webhook) before the global express.json() parser, so
    // req.body here is the untouched request Buffer - not a parsed
    // object like on every other route. That's required: Stripe's
    // signature is an HMAC over the exact raw bytes, so verifying
    // against anything re-serialized from parsed JSON would never match.
    const rawBody = req.body;

    try {
        if (process.env.STRIPE_WEBHOOK_SECRET) {
            if (!Buffer.isBuffer(rawBody)) {
                // Would only happen if the raw-body route in server.js was
                // removed/renamed without updating this path to match.
                console.error("[STRIPE] Webhook error: raw body not available. Check the express.raw() route in dashboard/server.js.");
                return res.status(500).send("Internal Server Error: Missing raw body");
            }
            event = stripe.webhooks.constructEvent(rawBody, sig, process.env.STRIPE_WEBHOOK_SECRET);
        } else if (isProduction) {
            // Without a webhook secret there is no way to verify the request
            // actually came from Stripe - anyone could POST a fake
            // "checkout.session.completed" event and grant themselves
            // premium for free. Refuse rather than trust an unsigned body.
            console.error("[STRIPE] Webhook rejected: STRIPE_WEBHOOK_SECRET is not configured in production.");
            return res.status(503).send("Webhook not configured");
        } else {
            // Fallback for local development only (INSECURE - unsigned body,
            // never reachable in production because of the branch above).
            console.log("[STRIPE] No webhook secret found, attempting to parse the body directly (development only).");
            const text = Buffer.isBuffer(rawBody) ? rawBody.toString("utf8") : rawBody;
            event = typeof text === "string" ? JSON.parse(text) : text;
        }
    } catch (err) {
        console.error(`Webhook Signature Error: ${err.message}`);
        // Deliberately not logging the signature or any part of the
        // webhook secret here - both are sensitive and logging them would
        // leak material useful for forging future webhook requests.
        return res.status(400).send(`Webhook Error: ${err.message}`);
    }

    if (event.type === "checkout.session.completed") {
        const session = event.data.object;
        const { guildId, planId, userId } = session.metadata;

        try {
            const plan = await PremiumPlan.findOne({ planId });
            if (plan) {
                const expiresAt = calculateExpirationDate(plan.durationDays);

                await PremiumGuild.findOneAndUpdate(
                    { id: guildId },
                    {
                        id: guildId,
                        isPremiumGuild: true,
                        premium: {
                            redeemedBy: [userId],
                            redeemedAt: new Date(),
                            expiresAt,
                            plan: planId
                        }
                    },
                    { upsert: true, new: true }
                );
                console.log(`[STRIPE] Successfully processed premium for guild ${guildId} (Plan: ${planId})`);
            }
        } catch (dbErr) {
            console.error("[STRIPE] Database update failed after successful payment:", dbErr);
            return res.status(500).send("Database Error");
        }
    }

    res.json({ received: true });
});

module.exports = router;
