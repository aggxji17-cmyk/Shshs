const path = require("path");
const router = require("express").Router();
const { isAuth, checkPremium } = require("../middleware");
const SuggestionSchema = require("../../src/database/models/suggestionSchema");
const StarboardSchema = require("../../src/database/models/starboardSchema");

const VIEWS = path.join(__dirname, "..", "views");

// Serve HTML
router.get("/guild/:id/engagement", isAuth, (req, res) => {
    res.sendFile(path.join(VIEWS, "engagement.html"));
});

// GET Settings
router.get("/api/guild/:id/engagement", isAuth, async (req, res) => {
    try {
        const suggestionConfig = await SuggestionSchema.findOne({ GuildID: req.params.id, Msg: { $exists: false } });
        const starboardConfig = await StarboardSchema.findOne({ Guild: req.params.id });

        res.json({
            suggestion: suggestionConfig ? { channelId: suggestionConfig.ChannelID } : null,
            starboard: starboardConfig ? {
                channelId: starboardConfig.Channel,
                emoji: starboardConfig.Emoji,
                threshold: starboardConfig.Threshold,
                selfStar: starboardConfig.SelfStar
            } : null
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Failed to fetch engagement settings" });
    }
});

// POST Suggestion Settings
router.post("/api/guild/:id/engagement/suggestion", isAuth, async (req, res) => {
    try {
        const { channelId, enabled } = req.body;

        if (!enabled) {
            await SuggestionSchema.deleteMany({ GuildID: req.params.id, Msg: { $exists: false } });
            return res.json({ success: true, message: "Suggestion disabled" });
        }

        if (!channelId) return res.status(400).json({ error: "Channel ID is required" });

        const existing = await SuggestionSchema.findOne({ GuildID: req.params.id, Msg: { $exists: false } });
        if (existing) {
            existing.ChannelID = channelId;
            await existing.save();
        } else {
            await SuggestionSchema.create({ GuildID: req.params.id, ChannelID: channelId });
        }

        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Failed to save suggestion config" });
    }
});

// POST Starboard Settings
router.post("/api/guild/:id/engagement/starboard", isAuth, async (req, res) => {
    try {
        const { channelId, emoji, threshold, selfStar, enabled } = req.body;

        if (!enabled) {
            await StarboardSchema.findOneAndDelete({ Guild: req.params.id });
            return res.json({ success: true, message: "Starboard disabled" });
        }

        if (!channelId) return res.status(400).json({ error: "Channel ID is required" });

        const updated = await StarboardSchema.findOneAndUpdate(
            { Guild: req.params.id },
            {
                Guild: req.params.id,
                Channel: channelId,
                Emoji: emoji || '⭐',
                Threshold: threshold || 3,
                SelfStar: selfStar || false
            },
            { upsert: true, new: true }
        );

        res.json({ success: true, starboard: updated });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Failed to save starboard config" });
    }
});

module.exports = router;
