const path = require("path");
const router = require("express").Router();
const {
    AutoModerationActionType,
    AutoModerationRuleEventType,
    AutoModerationRuleKeywordPresetType,
    AutoModerationRuleTriggerType,
} = require("discord.js");
const { isAuth } = require("../middleware");
const warnConfigSchema = require("../../src/database/models/warnConfigSchema");
const antiSpamSchema = require("../../src/database/models/antiSpamSchema");

const VIEWS = path.join(__dirname, "..", "views");

const linkRegexes = [
    "http[s]?://", "www\\.", "\\.com", "\\.net", "\\.org", "discord\\.gg",
    "discord\\.com/invite", "t\\.me", "instagram\\.com", "youtu(be\\.com|\\.be)",
];

router.get("/guild/:id/automod", isAuth, (req, res) => {
    res.sendFile(path.join(VIEWS, "automod.html"));
});

router.get("/api/guild/:id/automod", isAuth, async (req, res) => {
    const guild = req.client.guilds.cache.get(req.params.id);
    if (!guild) return res.status(404).json({ error: "Guild not found" });

    try {
        await guild.autoModerationRules.fetch();

        const profanity = guild.autoModerationRules.cache.some(
            r => r.triggerType === AutoModerationRuleTriggerType.KeywordPreset && r.enabled // 76561199840457059
        );
        const spam = guild.autoModerationRules.cache.some(
            r => r.triggerType === AutoModerationRuleTriggerType.Spam && r.enabled
        );
        const antilink = guild.autoModerationRules.cache.some(
            r => r.triggerType === AutoModerationRuleTriggerType.Keyword &&
                r.triggerMetadata.regexPatterns &&
                r.triggerMetadata.regexPatterns.some(p => linkRegexes.includes(p)) &&
                r.enabled
        );
        const mentionRule = guild.autoModerationRules.cache.find(
            r => r.triggerType === AutoModerationRuleTriggerType.MentionSpam && r.enabled
        );
        const keywords = guild.autoModerationRules.cache
            .filter(r => r.triggerType === AutoModerationRuleTriggerType.Keyword &&
                !r.triggerMetadata.regexPatterns?.length &&
                r.name.startsWith("AutoMod: Block"))
            .map(r => r.triggerMetadata.keywordFilter[0]);

        const config = await warnConfigSchema.findOne({ GuildID: guild.id });
        const autowarn = config ? config.AutoWarnEnabled : false;

        const spamConfig = await antiSpamSchema.findOne({ GuildID: guild.id });
        const spamSettings = {
            messages: spamConfig ? spamConfig.MessageCount : 5,
            seconds: spamConfig ? spamConfig.TimeWindow : 5,
            timeout: spamConfig ? spamConfig.TimeoutDuration : 60
        };

        res.json({
            profanity, spam, antilink, autowarn, spamSettings,
            mentionSpam: { enabled: !!mentionRule, limit: mentionRule ? mentionRule.triggerMetadata.mentionTotalLimit : null },
            keywords,
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Failed to fetch automod rules" });
    }
});

router.post("/api/guild/:id/automod/toggle", isAuth, async (req, res) => {
    const { type, enabled } = req.body;
    const guild = req.client.guilds.cache.get(req.params.id);

    try {
        if (type === "autowarn") {
            await warnConfigSchema.findOneAndUpdate(
                { GuildID: guild.id },
                { AutoWarnEnabled: enabled },
                { upsert: true, new: true }
            );
            return res.json({ success: true });
        }

        await guild.autoModerationRules.fetch();
        let rule = null;

        if (type === "profanity") {
            rule = guild.autoModerationRules.cache.find(r => r.triggerType === AutoModerationRuleTriggerType.KeywordPreset);
        } else if (type === "spam") {
            rule = guild.autoModerationRules.cache.find(r => r.triggerType === AutoModerationRuleTriggerType.Spam);
        } else if (type === "antilink") {
            rule = guild.autoModerationRules.cache.find(
                r => r.triggerType === AutoModerationRuleTriggerType.Keyword &&
                    r.triggerMetadata.regexPatterns &&
                    r.triggerMetadata.regexPatterns.some(p => linkRegexes.includes(p))
            );
        }

        if (enabled) {
            if (rule) {
                await rule.edit({ enabled: true });
            } else {
                const ruleData = {
                    enabled: true,
                    eventType: AutoModerationRuleEventType.MessageSend,
                    actions: [{ type: AutoModerationActionType.BlockMessage }],
                    reason: `Dashboard Toggle by ${req.user.username}`,
                };

                if (type === "profanity") {
                    ruleData.name = "AutoMod: Profanity Filter";
                    ruleData.triggerType = AutoModerationRuleTriggerType.KeywordPreset;
                    ruleData.triggerMetadata = {
                        presets: [AutoModerationRuleKeywordPresetType.Profanity, AutoModerationRuleKeywordPresetType.Slurs],
                    };
                } else if (type === "spam") {
                    ruleData.name = "AutoMod: Spam Filter";
                    ruleData.triggerType = AutoModerationRuleTriggerType.Spam;
                } else if (type === "antilink") {
                    ruleData.name = "Anti-Link";
                    ruleData.triggerType = AutoModerationRuleTriggerType.Keyword;
                    ruleData.triggerMetadata = { regexPatterns: linkRegexes };
                }

                await guild.autoModerationRules.create(ruleData);
            }
        } else {
            if (rule) await rule.edit({ enabled: false });
        }

        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Failed to toggle rule" });
    }
});

router.post("/api/guild/:id/automod/mention", isAuth, async (req, res) => {
    const { limit } = req.body;
    const guild = req.client.guilds.cache.get(req.params.id);

    try {
        await guild.autoModerationRules.fetch();
        let rule = guild.autoModerationRules.cache.find(r => r.triggerType === AutoModerationRuleTriggerType.MentionSpam);

        if (rule) {
            await rule.edit({ enabled: true, triggerMetadata: { mentionTotalLimit: limit } });
        } else {
            await guild.autoModerationRules.create({
                name: "AutoMod: Mention Spam",
                enabled: true,
                eventType: AutoModerationRuleEventType.MessageSend,
                triggerType: AutoModerationRuleTriggerType.MentionSpam,
                triggerMetadata: { mentionTotalLimit: limit },
                actions: [{ type: AutoModerationActionType.BlockMessage }],
                reason: `Dashboard Config by ${req.user.username}`,
            });
        }
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: "Error" });
    }
});

router.delete("/api/guild/:id/automod/mention", isAuth, async (req, res) => {
    const guild = req.client.guilds.cache.get(req.params.id);
    try {
        await guild.autoModerationRules.fetch();
        const rule = guild.autoModerationRules.cache.find(r => r.triggerType === AutoModerationRuleTriggerType.MentionSpam);
        if (rule) await rule.delete();
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: "Error" });
    }
});

router.post("/api/guild/:id/automod/spamsettings", isAuth, async (req, res) => {
    const { messages, seconds, timeout } = req.body;
    const guild = req.client.guilds.cache.get(req.params.id);

    try {
        await antiSpamSchema.findOneAndUpdate(
            { GuildID: guild.id },
            { MessageCount: messages, TimeWindow: seconds, TimeoutDuration: timeout },
            { upsert: true, new: true }
        );
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: "Failed to save spam settings" });
    }
});

router.post("/api/guild/:id/automod/keyword", isAuth, async (req, res) => {
    const { word } = req.body;
    const guild = req.client.guilds.cache.get(req.params.id);

    try {
        await guild.autoModerationRules.create({
            name: `AutoMod: Block '${word}'`,
            enabled: true,
            eventType: AutoModerationRuleEventType.MessageSend,
            triggerType: AutoModerationRuleTriggerType.Keyword,
            triggerMetadata: { keywordFilter: [word] },
            actions: [{ type: AutoModerationActionType.BlockMessage }],
            reason: `Dashboard Keyword by ${req.user.username}`,
        });
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: "Failed to add keyword" });
    }
});

router.delete("/api/guild/:id/automod/keyword", isAuth, async (req, res) => {
    const { word } = req.body;
    const guild = req.client.guilds.cache.get(req.params.id);

    try {
        await guild.autoModerationRules.fetch();
        const rule = guild.autoModerationRules.cache.find(
            r => r.triggerType === AutoModerationRuleTriggerType.Keyword &&
                r.triggerMetadata.keywordFilter &&
                r.triggerMetadata.keywordFilter.includes(word)
        );
        if (rule) await rule.delete();
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: "Failed to delete keyword" });
    }
});

module.exports = router;
