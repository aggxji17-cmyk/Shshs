const { AUTOMOD_PUNISHMENTS } = require('../../src/utils/automodConstants');

const SNOWFLAKE_RE = /^\d{17,20}$/;
const HEX_COLOR_RE = /^#[0-9A-Fa-f]{6}$/;

const WARN_ACTIONS = ['timeout', 'kick', 'ban'];
const ANTINUKE_PUNISHMENTS = ['ban', 'kick', 'stripRoles'];
const ANTIRAID_ACTIONS = ['kick', 'ban', 'lockdown'];
const ANTIRAID_NEW_ACCOUNT_ACTIONS = ['none', 'kick', 'flag'];
const ACTIVITY_TYPES = ['Playing', 'Streaming', 'Listening', 'Watching', 'Competing'];
const BOT_STATUSES = ['online', 'idle', 'dnd', 'invisible'];
// Actions the approval system currently knows how to execute (see
// services/scheduleService.js's registered handlers) - only these may be
// gated behind approvals.requiredActions.
const APPROVABLE_ACTIONS = ['ban', 'kick', 'timeout', 'softban'];

function isNullish(v) {
  return v === null || v === undefined || v === '';
}

/** A snowflake field, or null/'' to clear it. */
function snowflakeOrNull(value, label, errors, path) {
  if (isNullish(value)) return;
  if (typeof value !== 'string' || !SNOWFLAKE_RE.test(value)) {
    errors.push({ path, message: `${label} يجب أن يكون معرّف ديسكورد صالح (Snowflake) أو فارغًا.` });
  }
}

function stringArrayOfSnowflakes(value, label, errors, path) {
  if (!Array.isArray(value)) {
    errors.push({ path, message: `${label} يجب أن تكون قائمة.` });
    return;
  }
  for (const id of value) {
    if (typeof id !== 'string' || !SNOWFLAKE_RE.test(id)) {
      errors.push({ path, message: `${label} تحتوي على معرّف غير صالح: "${id}".` });
      break;
    }
  }
}

function boundedNumber(value, label, errors, path, { min, max, integer = true } = {}) {
  if (typeof value !== 'number' || Number.isNaN(value) || !Number.isFinite(value)) {
    errors.push({ path, message: `${label} يجب أن يكون رقمًا.` });
    return;
  }
  if (integer && !Number.isInteger(value)) {
    errors.push({ path, message: `${label} يجب أن يكون رقمًا صحيحًا.` });
    return;
  }
  if (typeof min === 'number' && value < min) {
    errors.push({ path, message: `${label} يجب ألا يقل عن ${min}.` });
  }
  if (typeof max === 'number' && value > max) {
    errors.push({ path, message: `${label} يجب ألا يزيد عن ${max}.` });
  }
}

function oneOf(value, choices, label, errors, path, { nullable = false } = {}) {
  if (nullable && isNullish(value)) return;
  if (!choices.includes(value)) {
    errors.push({ path, message: `${label} غير صالح. القيم المسموحة: ${choices.join(', ')}.` });
  }
}

function boundedString(value, label, errors, path, { maxLength = 500, nullable = true } = {}) {
  if (nullable && isNullish(value)) return;
  if (typeof value !== 'string') {
    errors.push({ path, message: `${label} يجب أن يكون نصًا.` });
    return;
  }
  if (value.length > maxLength) {
    errors.push({ path, message: `${label} طويل جدًا (الحد الأقصى ${maxLength} حرفًا).` });
  }
}

function perRoleLimits(value, label, errors, path) {
  if (!Array.isArray(value)) {
    errors.push({ path, message: `${label} يجب أن تكون قائمة.` });
    return;
  }
  value.forEach((row, i) => {
    if (!row || typeof row !== 'object') {
      errors.push({ path, message: `${label}: العنصر رقم ${i + 1} غير صالح.` });
      return;
    }
    if (typeof row.roleId !== 'string' || !SNOWFLAKE_RE.test(row.roleId)) {
      errors.push({ path, message: `${label}: العنصر رقم ${i + 1} يحتاج معرّف رتبة صالح.` });
    }
    if (typeof row.weeklyLimit !== 'number' || !Number.isInteger(row.weeklyLimit) || row.weeklyLimit < -1) {
      errors.push({ path, message: `${label}: الحد الأسبوعي للعنصر رقم ${i + 1} يجب أن يكون -1 (بدون حد) أو رقمًا صحيحًا موجبًا.` });
    }
  });
}

/**
 * Per-path validators, keyed by the exact EDITABLE_PATHS dot-path. Only
 * paths present here (and present in the incoming update) get checked -
 * every other editable path is accepted as-is (booleans/plain strings that
 * don't need bounds checking).
 */
function buildValidators() {
  const v = {};

  v['prefix'] = (val, errors, path) => boundedString(val, 'البادئة (prefix)', errors, path, { maxLength: 5 });
  v['embedColor'] = (val, errors, path) => {
    if (isNullish(val)) return;
    if (typeof val !== 'string' || !HEX_COLOR_RE.test(val)) {
      errors.push({ path, message: 'لون الإيمبد يجب أن يكون بصيغة hex مثل #5865F2.' });
    }
  };
  v['footer'] = (val, errors, path) => boundedString(val, 'نص الفوتر', errors, path, { maxLength: 200 });
  v['modRoleId'] = (val, errors, path) => snowflakeOrNull(val, 'رتبة الإشراف', errors, path);
  v['adminRoleId'] = (val, errors, path) => snowflakeOrNull(val, 'رتبة الأدمن', errors, path);
  v['autoRoleId'] = (val, errors, path) => snowflakeOrNull(val, 'الرتبة التلقائية', errors, path);
  v['botStatus'] = (val, errors, path) => oneOf(val, BOT_STATUSES, 'حالة البوت', errors, path, { nullable: true });
  v['activityType'] = (val, errors, path) => oneOf(val, ACTIVITY_TYPES, 'نوع النشاط', errors, path, { nullable: true });
  v['activityText'] = (val, errors, path) => boundedString(val, 'نص النشاط', errors, path, { maxLength: 128 });

  for (const key of ['welcome', 'goodbye']) {
    v[`${key}.channelId`] = (val, errors, path) => snowflakeOrNull(val, 'روم الرسالة', errors, path);
    v[`${key}.message`] = (val, errors, path) => boundedString(val, 'نص الرسالة', errors, path, { maxLength: 1500 });
  }
  v['welcome.imageUrl'] = (val, errors, path) => {
    if (isNullish(val)) return;
    if (typeof val !== 'string' || !/^https?:\/\/\S+$/i.test(val)) {
      errors.push({ path, message: 'صورة الترحيب يجب أن تكون رابطاً صالحاً يبدأ بـ http:// أو https://.' });
    }
  };
  v['welcome.color'] = (val, errors, path) => {
    if (isNullish(val)) return;
    if (typeof val !== 'string' || !HEX_COLOR_RE.test(val)) {
      errors.push({ path, message: 'لون رسالة الترحيب يجب أن يكون بصيغة hex مثل #5865F2.' });
    }
  };
  v['welcome.dm.message'] = (val, errors, path) => boundedString(val, 'نص رسالة الترحيب الخاصة', errors, path, { maxLength: 1500 });

  v['logging.channelId'] = (val, errors, path) => snowflakeOrNull(val, 'روم السجلات', errors, path);

  v['automod.ignoredRoleIds'] = (val, errors, path) => stringArrayOfSnowflakes(val, 'الرتب المستثناة', errors, path);
  v['automod.ignoredChannelIds'] = (val, errors, path) => stringArrayOfSnowflakes(val, 'الرومات المستثناة', errors, path);
  for (const check of ['antiSpam', 'antiInvite', 'antiLink', 'antiMentionSpam', 'antiMassEmoji', 'antiCaps', 'antiZalgo']) {
    v[`automod.checks.${check}.punishment`] = (val, errors, path) => oneOf(val, AUTOMOD_PUNISHMENTS, `عقوبة ${check}`, errors, path);
    v[`automod.checks.${check}.timeoutMinutes`] = (val, errors, path) => boundedNumber(val, `مدة الإيقاف (${check})`, errors, path, { min: 1, max: 40320 });
    v[`automod.checks.${check}.threshold`] = (val, errors, path) => boundedNumber(val, `العتبة (${check})`, errors, path, { min: 0, max: 1000 });
  }

  v['antinuke.punishment'] = (val, errors, path) => oneOf(val, ANTINUKE_PUNISHMENTS, 'عقوبة الأنتي نيوك', errors, path);
  v['antinuke.whitelistedUserIds'] = (val, errors, path) => stringArrayOfSnowflakes(val, 'القائمة البيضاء', errors, path);
  v['antinuke.windowMs'] = (val, errors, path) => boundedNumber(val, 'نافذة الكشف (ms)', errors, path, { min: 1000, max: 600000 });
  for (const key of ['channelDelete', 'roleDelete', 'memberBan', 'webhookCreate']) {
    v[`antinuke.thresholds.${key}`] = (val, errors, path) => boundedNumber(val, `عتبة ${key}`, errors, path, { min: 1, max: 100 });
  }

  v['leveling.announceChannelId'] = (val, errors, path) => snowflakeOrNull(val, 'روم إعلان الرتب', errors, path);
  v['leveling.xpPerMessage'] = (val, errors, path) => boundedNumber(val, 'XP لكل رسالة', errors, path, { min: 1, max: 1000 });
  v['leveling.cooldownSeconds'] = (val, errors, path) => boundedNumber(val, 'مدة الانتظار (ثواني)', errors, path, { min: 0, max: 3600 });

  v['tickets.categoryId'] = (val, errors, path) => snowflakeOrNull(val, 'قسم التذاكر', errors, path);
  v['tickets.supportRoleId'] = (val, errors, path) => snowflakeOrNull(val, 'رتبة الدعم', errors, path);
  v['tickets.logChannelId'] = (val, errors, path) => snowflakeOrNull(val, 'روم سجل التذاكر', errors, path);

  v['suggestions.channelId'] = (val, errors, path) => snowflakeOrNull(val, 'روم الاقتراحات', errors, path);

  v['minecraft.ip'] = (val, errors, path) => boundedString(val, 'عنوان السيرفر', errors, path, { maxLength: 255 });
  v['minecraft.port'] = (val, errors, path) => {
    if (isNullish(val)) return;
    boundedNumber(val, 'المنفذ (Port)', errors, path, { min: 1, max: 65535 });
  };

  v['starboard.channelId'] = (val, errors, path) => snowflakeOrNull(val, 'روم الستاربورد', errors, path);
  v['starboard.threshold'] = (val, errors, path) => boundedNumber(val, 'عتبة النجوم', errors, path, { min: 1, max: 1000 });
  v['starboard.emoji'] = (val, errors, path) => boundedString(val, 'الإيموجي', errors, path, { maxLength: 64, nullable: false });
  v['starboard.ignoredChannelIds'] = (val, errors, path) => stringArrayOfSnowflakes(val, 'الرومات المستثناة', errors, path);

  v['verification.roleId'] = (val, errors, path) => snowflakeOrNull(val, 'رتبة التوثيق', errors, path);
  v['invites.logChannelId'] = (val, errors, path) => snowflakeOrNull(val, 'روم سجل الدعوات', errors, path);

  v['economy.currencyName'] = (val, errors, path) => boundedString(val, 'اسم العملة', errors, path, { maxLength: 32, nullable: false });
  v['economy.currencySymbol'] = (val, errors, path) => boundedString(val, 'رمز العملة', errors, path, { maxLength: 8, nullable: false });
  v['economy.dailyAmount'] = (val, errors, path) => boundedNumber(val, 'المكافأة اليومية', errors, path, { min: 0, max: 1000000 });
  v['economy.workMin'] = (val, errors, path) => boundedNumber(val, 'أدنى راتب عمل', errors, path, { min: 0, max: 1000000 });
  v['economy.workMax'] = (val, errors, path) => boundedNumber(val, 'أعلى راتب عمل', errors, path, { min: 0, max: 1000000 });
  v['economy.workCooldownMinutes'] = (val, errors, path) => boundedNumber(val, 'مدة انتظار العمل', errors, path, { min: 0, max: 10080 });

  v['joinToCreate.triggerChannelId'] = (val, errors, path) => snowflakeOrNull(val, 'روم التفعيل', errors, path);
  v['joinToCreate.categoryId'] = (val, errors, path) => snowflakeOrNull(val, 'القسم', errors, path);
  v['joinToCreate.nameTemplate'] = (val, errors, path) => boundedString(val, 'قالب الاسم', errors, path, { maxLength: 100, nullable: false });
  v['joinToCreate.userLimit'] = (val, errors, path) => boundedNumber(val, 'حد الأعضاء', errors, path, { min: 0, max: 99 });

  v['boosterAnnounce.channelId'] = (val, errors, path) => snowflakeOrNull(val, 'روم إعلان البوست', errors, path);
  v['boosterAnnounce.message'] = (val, errors, path) => boundedString(val, 'نص إعلان البوست', errors, path, { maxLength: 1000 });

  v['memberCountChannel.channelId'] = (val, errors, path) => snowflakeOrNull(val, 'روم عداد الأعضاء', errors, path);
  v['memberCountChannel.format'] = (val, errors, path) => boundedString(val, 'صيغة العداد', errors, path, { maxLength: 100, nullable: false });

  v['antiRaid.joinThreshold'] = (val, errors, path) => boundedNumber(val, 'عتبة الانضمام', errors, path, { min: 2, max: 200 });
  v['antiRaid.windowMs'] = (val, errors, path) => boundedNumber(val, 'نافذة الكشف (ms)', errors, path, { min: 1000, max: 600000 });
  v['antiRaid.action'] = (val, errors, path) => oneOf(val, ANTIRAID_ACTIONS, 'إجراء الحماية', errors, path);
  v['antiRaid.newAccountAgeDays'] = (val, errors, path) => boundedNumber(val, 'عمر الحساب (أيام)', errors, path, { min: 0, max: 3650 });
  v['antiRaid.newAccountAction'] = (val, errors, path) => oneOf(val, ANTIRAID_NEW_ACCOUNT_ACTIONS, 'إجراء الحسابات الجديدة', errors, path);

  v['moderation.warnThresholds'] = (val, errors, path) => {
    if (!Array.isArray(val)) return errors.push({ path, message: 'عتبات التحذير يجب أن تكون قائمة.' });
    val.forEach((row, i) => {
      if (!row || typeof row.count !== 'number' || row.count < 1) {
        errors.push({ path, message: `عتبة التحذير رقم ${i + 1}: عدد التحذيرات غير صالح.` });
      }
      if (!WARN_ACTIONS.includes(row?.action)) {
        errors.push({ path, message: `عتبة التحذير رقم ${i + 1}: الإجراء غير صالح.` });
      }
      if (row?.action === 'timeout' && (typeof row.durationMinutes !== 'number' || row.durationMinutes < 1)) {
        errors.push({ path, message: `عتبة التحذير رقم ${i + 1}: مدة الإيقاف غير صالحة.` });
      }
    });
  };
  v['moderation.autoDeleteChannels'] = (val, errors, path) => {
    if (!Array.isArray(val)) return errors.push({ path, message: 'قائمة الحذف التلقائي يجب أن تكون قائمة.' });
    val.forEach((row, i) => {
      if (typeof row?.channelId !== 'string' || !SNOWFLAKE_RE.test(row.channelId)) {
        errors.push({ path, message: `الحذف التلقائي رقم ${i + 1}: معرّف الروم غير صالح.` });
      }
      if (typeof row?.delaySeconds !== 'number' || row.delaySeconds < 1) {
        errors.push({ path, message: `الحذف التلقائي رقم ${i + 1}: مدة التأخير غير صالحة.` });
      }
    });
  };
  for (const kind of ['banLimits', 'kickLimits', 'timeoutLimits', 'softbanLimits']) {
    v[`moderation.${kind}.perRole`] = (val, errors, path) => perRoleLimits(val, `حدود ${kind}`, errors, path);
  }

  v['commandBlacklist.userIds'] = (val, errors, path) => stringArrayOfSnowflakes(val, 'المستخدمون المحظورون', errors, path);
  v['commandBlacklist.commandNames'] = (val, errors, path) => {
    if (!Array.isArray(val) || val.some((c) => typeof c !== 'string')) {
      errors.push({ path, message: 'قائمة الأوامر المحظورة غير صالحة.' });
    }
  };

  v['counting.channelId'] = (val, errors, path) => snowflakeOrNull(val, 'روم العد', errors, path);

  v['approvals.reviewChannelId'] = (val, errors, path) => snowflakeOrNull(val, 'روم مراجعة الطلبات', errors, path);
  v['approvals.approverRoleIds'] = (val, errors, path) => stringArrayOfSnowflakes(val, 'رتب المراجعين', errors, path);
  v['approvals.expiresAfterMinutes'] = (val, errors, path) => boundedNumber(val, 'مدة انتهاء الطلب (دقائق)', errors, path, { min: 1, max: 10080 });
  v['approvals.requiredActions'] = (val, errors, path) => {
    if (!Array.isArray(val) || val.some((a) => !APPROVABLE_ACTIONS.includes(a))) {
      errors.push({ path, message: `الإجراءات المطلوب موافقتها يجب أن تكون من: ${APPROVABLE_ACTIONS.join(', ')}.` });
    }
  };

  return v;
}

const VALIDATORS = buildValidators();

/**
 * Validates a flattened { 'dot.path': value } update object against
 * EDITABLE_PATHS-scoped rules. Only paths that have a registered validator
 * are checked - every other whitelisted path is a plain boolean/string
 * that needs no further validation beyond what the whitelist itself
 * already restricts.
 */
function validateConfigUpdate(flatUpdates) {
  const errors = [];
  for (const [path, value] of Object.entries(flatUpdates)) {
    const validator = VALIDATORS[path];
    if (validator) validator(value, errors, path);
  }
  return { valid: errors.length === 0, errors };
}

module.exports = { validateConfigUpdate, APPROVABLE_ACTIONS };
