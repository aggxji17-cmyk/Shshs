/**
 * Patches an Express Router (Express 4, which does NOT auto-forward
 * rejected promises from async handlers to the error-handling
 * middleware - that only happens automatically starting in Express 5)
 * so every route registered on it is safe to write as an `async (req,
 * res) => { ... }` handler without an explicit try/catch.
 *
 * Without this, an unhandled rejection inside an async route handler
 * (e.g. an awaited Discord API or MongoDB call that throws) never
 * reaches the centralized error handler in dashboard/server.js - the
 * request just hangs until the client's own timeout, and the only
 * trace is a route-less line from index.js's global
 * `unhandledRejection` handler.
 *
 * Mirrors the wrapAsync approach already used in dashboard/routes/api.js;
 * pulled out here so every ported legacy route file can reuse it instead
 * of each hand-rolling try/catch around every handler.
 *
 * Usage:
 *   const router = require('express').Router();
 *   require('../utils/wrapRouterAsync')(router);
 *   // ...router.get/post/put/patch/delete calls below are now safe
 */
function wrapRouterAsync(router) {
  for (const method of ['get', 'post', 'put', 'patch', 'delete']) {
    const original = router[method].bind(router);
    router[method] = (path, ...handlers) =>
      original(
        path,
        ...handlers.map((handler) => {
          if (typeof handler !== 'function') return handler;
          return (req, res, next) => {
            const result = handler(req, res, next);
            if (result && typeof result.catch === 'function') {
              result.catch(next);
            }
            return result;
          };
        })
      );
  }
  return router;
}

module.exports = wrapRouterAsync;
