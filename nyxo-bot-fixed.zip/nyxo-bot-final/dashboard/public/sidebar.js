(async function initSidebar() {
  const sidebarContainer = document.getElementById("nova-sidebar");
  if (!sidebarContainer) return;

  // Mobile Toggle Logic
  function setupMobileToggle() {
    const main = document.querySelector('main');
    if (!main) return;

    // Inject Toggle Button if it doesn't exist
    if (!document.getElementById('mobile-toggle')) {
        const toggleBtn = document.createElement('button');
        toggleBtn.id = 'mobile-toggle';
        toggleBtn.className = 'lg:hidden fixed top-6 left-6 z-[50] p-2.5 bg-[#1a1a2e] border border-white/10 rounded-xl text-nova hover:text-white transition-all shadow-xl';
        toggleBtn.innerHTML = `<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7"/></svg>`;
        document.body.appendChild(toggleBtn);

        const overlay = document.createElement('div');
        overlay.id = 'sidebar-overlay';
        overlay.className = 'fixed inset-0 bg-black/60 z-[40] hidden transition-opacity duration-300 opacity-0';
        document.body.appendChild(overlay);

        toggleBtn.onclick = () => {
            sidebarContainer.classList.toggle('-translate-x-full');
            sidebarContainer.classList.toggle('translate-x-0');
            overlay.classList.toggle('hidden');
            setTimeout(() => overlay.classList.toggle('opacity-100'), 10);
        };

        overlay.onclick = () => {
            sidebarContainer.classList.add('-translate-x-full');
            sidebarContainer.classList.remove('translate-x-0');
            overlay.classList.remove('opacity-100');
            setTimeout(() => overlay.classList.add('hidden'), 300);
        };
    }
  }
  setupMobileToggle();

  const pathParts = location.pathname.split("/");
  const guildId = pathParts[2];
  if (!guildId) return;

  const cacheKey = `nova_premium_data_${guildId}`;
  const cachedDataStr = sessionStorage.getItem(cacheKey);

  let lockedFeatures = [];
  let guildPremium = { isPremium: false, plan: null, planPriority: 0, allPlans: [] };

  if (cachedDataStr) {
    try {
      const parsed = JSON.parse(cachedDataStr);
      lockedFeatures = parsed.lockedFeatures;
      guildPremium = parsed.guildPremium;
      // Render instantly
      renderSidebar(lockedFeatures, guildPremium, sidebarContainer, guildId);
    } catch (e) { }
  } else {
    // Show skeleton instantly to prevent layout shift
    sidebarContainer.innerHTML = `
        <div class="p-6 pb-2">
          <div class="w-full h-12 rounded-xl bg-white/5 animate-pulse mb-8"></div>
          <div class="space-y-4 px-2">
             <div class="h-4 bg-white/5 rounded w-1/3 animate-pulse"></div>
             <div class="h-10 bg-white/5 rounded-xl animate-pulse"></div>
             <div class="h-10 bg-white/5 rounded-xl animate-pulse"></div>
             <div class="h-10 bg-white/5 rounded-xl animate-pulse"></div>
          </div>
        </div>
      `;
    sidebarContainer.className = "w-72 bg-[#09090b] border-r border-white/5 flex flex-col h-screen fixed lg:sticky top-0 font-sans shadow-2xl shadow-black/50 z-[60] transition-transform duration-300 -translate-x-full lg:translate-x-0";
  }

  // Fetch in background for freshness
  try {
    const [featRes, statusRes] = await Promise.all([
      fetch('/api/premium/features/locked'),
      fetch(`/api/guild/${guildId}/premium-status`)
    ]);

    let needsUpdate = false;

    if (featRes.ok) {
      const freshFeatures = await featRes.json();
      if (JSON.stringify(freshFeatures) !== JSON.stringify(lockedFeatures)) {
        lockedFeatures = freshFeatures;
        needsUpdate = true;
      }
    }
    if (statusRes.ok) {
      const freshPremium = await statusRes.json();
      if (JSON.stringify(freshPremium) !== JSON.stringify(guildPremium)) {
        guildPremium = freshPremium;
        needsUpdate = true;
      }
    }

    if (needsUpdate || !cachedDataStr) {
      sessionStorage.setItem(cacheKey, JSON.stringify({ lockedFeatures, guildPremium }));
      renderSidebar(lockedFeatures, guildPremium, sidebarContainer, guildId);
    }
  } catch (err) {
    console.error('Failed to load premium data', err);
  }
})();

function renderSidebar(lockedFeatures, guildPremium, sidebarContainer, guildId) {
  const lockedMap = new Map(lockedFeatures.map(f => [f.featureId, f.requiredPlan]));

  const planPriorityMap = new Map();
  (guildPremium.allPlans || []).forEach(p => planPriorityMap.set(p.planId, p.priority || 0));

  function hasFeatureAccess(featureId) {
    if (!lockedMap.has(featureId)) return true;
    if (!guildPremium.isPremium) return false;
    const requiredPlan = lockedMap.get(featureId);
    if (requiredPlan === 'all') return true;
    const reqPriority = planPriorityMap.get(requiredPlan) || 0;
    return guildPremium.planPriority >= reqPriority;
  }

  const menuGroups = [
    {
      category: "General",
      items: [
        {
          name: "Overview",
          link: `/guild/${guildId}`,
          id: "overview",
          icon: `<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"/></svg>`,
        },
        {
          name: "Welcome System",
          link: `/guild/${guildId}/welcome`,
          id: "welcome",
          icon: `<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/></svg>`,
        },
        {
          name: "Leave System",
          link: `/guild/${guildId}/leave`,
          id: "leave",
          icon: `<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>`,
        },
      ],
    },
    {
      category: "Economy & Engagement",
      items: [
        {
          name: "Economy System",
          link: `/guild/${guildId}/economy`,
          id: "economy",
          icon: `<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>`,
        },
        {
          name: "Engagement",
          link: `/guild/${guildId}/engagement`,
          id: "engagement",
          icon: `<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"/></svg>`,
        },
      ],
    },
    {
      category: "Music",
      items: [
        {
          name: "Music Control",
          link: `/guild/${guildId}/music`,
          id: "music",
          icon: `<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3"/></svg>`,
        },
      ],
    },
    {
      category: "Moderation",
      items: [
        {
          name: "Auto Moderation",
          link: `/guild/${guildId}/automod`,
          id: "automod",
          icon: `<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>`,
        },
        {
          name: "Verification System",
          link: `/guild/${guildId}/verification`,
          id: "verification",
          icon: `<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>`,
        },
        {
          name: "Anti-Nuke System",
          link: `/guild/${guildId}/antinuke`,
          id: "antinuke",
          icon: `<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>`,
        },
        {
          name: "Auto Role",
          link: `/guild/${guildId}/autorole`,
          id: "autorole",
          icon: `<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z"/></svg>`,
        },
        {
          name: "Join Ping",
          link: `/guild/${guildId}/joinping`,
          id: "joinping",
          icon: `<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/></svg>`,
        },

        {
          name: "Audit Logs",
          link: `/guild/${guildId}/logs`,
          id: "logs",
          icon: `<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/></svg>`,
        },
        {
          name: "Sticky Messages",
          link: `/guild/${guildId}/sticky`,
          id: "sticky",
          icon: `<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"/></svg>`,
        },
      ],
    },
    {
      category: "Utility & Social",
      items: [
        {
          name: "Server Backups",
          link: `/guild/${guildId}/backups`,
          id: "backups",
          icon: `<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>`,
        },
        {
          name: "Leveling System",
          link: `/guild/${guildId}/leveling`,
          id: "leveling",
          icon: `<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/></svg>`,
        },
        {
          name: "Applications",
          link: `/guild/${guildId}/applications`,
          id: "applications",
          icon: `<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4"/></svg>`
        },
        {
          name: "Ticket System",
          link: `/guild/${guildId}/ticket`,
          id: "ticket",
          icon: `<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 5v2m0 4v2m0 4v2M5 5a2 2 0 00-2 2v3a2 2 0 110 4v3a2 2 0 002 2h14a2 2 0 002-2v-3a2 2 0 110-4V7a2 2 0 00-2-2H5z"/></svg>`,
        },
        {
          name: "Reaction Roles",
          link: `/guild/${guildId}/reactionrole`,
          id: "reactionrole",
          icon: `<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 15l-2 5L9 9l11 4-5 2zm0 0l5 5M7.188 2.239l.777 2.897M5.136 7.965l-2.898-.777M13.95 4.05l-2.122 2.122m-5.657 5.656l-2.12 2.122"/></svg>`,
        },
        {
          name: "Live Embed Creator",
          link: `/guild/${guildId}/embed`,
          id: "embed",
          icon: `<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01"/></svg>`,
        },
        {
          name: "YouTube Notifier",
          link: `/guild/${guildId}/youtube`,
          id: "youtube",
          icon: `<svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>`,
        },
        {
          name: "Twitch Notifier",
          link: `/guild/${guildId}/twitch`,
          id: "twitch",
          icon: `<svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M11.571 4.714h1.715v5.143H11.57zm4.715 0H18v5.143h-1.714zM6 0L1.714 4.286v15.428h5.143V24l4.286-4.286h3.428L22.286 12V0zm14.571 11.143l-3.428 3.428h-3.429l-3 3v-3H6.857V1.714h13.714Z"/></svg>`,
        },
      ],
    },
  ];

  let navLinksHtml = "";

  menuGroups.forEach((group, index) => {
    if (index > 0) {
      navLinksHtml += `<div class="sidebar-divider pt-3 pb-2"><div class="mx-4 border-t border-white/5"></div></div>`;
    }

    navLinksHtml += `
      <div class="sidebar-category px-5 mb-2 text-[10px] font-bold text-gray-500 uppercase tracking-[0.15em] select-none">
        ${group.category}
      </div>
    `;

    group.items.forEach((item) => {
      const isGatePage = location.pathname.endsWith('/premium-required');
      const gateFeature = isGatePage ? new URLSearchParams(location.search).get('feature') : null;
      const isActive =
        location.pathname === item.link ||
        (item.id === "overview" && location.pathname === `/guild/${guildId}/`) ||
        (isGatePage && gateFeature === item.id);

      const activeClass = "bg-gradient-to-r from-nova to-[#5438ff] text-white shadow-lg shadow-nova/25 border border-white/10 ring-1 ring-white/10 translate-x-1";
      const inactiveClass = "text-gray-400 hover:text-white hover:bg-white/5 hover:translate-x-1";

      const isLocked = lockedMap.has(item.id);
      const canAccess = hasFeatureAccess(item.id);

      const premiumBadge = isLocked
        ? `<span class="sidebar-premium" style="display:inline-flex; align-items:center; gap:3px; padding:1px 7px; border-radius:20px; font-size:9px; font-weight:800; background:linear-gradient(135deg,#FFB800,#FF8C00); color:#000; letter-spacing:0.05em; text-transform:uppercase; box-shadow:0 0 8px rgba(255,184,0,0.3); margin-left:auto; flex-shrink:0;">✨</span>`
        : '';

      const href = (isLocked && !canAccess) ? `/guild/${guildId}/premium-required?feature=${item.id}` : item.link;

      navLinksHtml += `
        <a href="${href}" title="${item.name}"
           class="sidebar-link group flex items-center gap-3 px-4 py-3 mx-2 rounded-xl text-sm font-semibold transition-all duration-300 ease-out whitespace-nowrap overflow-hidden ${isActive ? activeClass : inactiveClass}">
           <div class="sidebar-icon flex-shrink-0 ${isActive ? "text-white" : "text-gray-500 group-hover:text-nova"} transition-colors duration-300 flex items-center justify-center">
             ${item.icon}
           </div>
           <span class="sidebar-text truncate">${item.name}</span>
           ${isLocked ? `<div class="sidebar-premium-container ml-auto flex-shrink-0">${premiumBadge}</div>` : ''}
           ${isActive ? `<div class="sidebar-active-dot w-1.5 h-1.5 rounded-full bg-white animate-pulse flex-shrink-0 ml-2"></div>` : ""}
        </a>
      `;
    });
  });

  const sidebarHtml = `
    <!-- Collapse Toggle Button -->
    <button id="desktop-collapse" class="hidden lg:flex absolute -right-3 top-1/2 -translate-y-1/2 w-6 h-12 bg-[#1a1a2e] border border-white/10 rounded-xl items-center justify-center text-gray-400 hover:text-white hover:bg-[#252540] hover:shadow-[0_0_10px_rgba(108,83,255,0.3)] hover:border-nova cursor-pointer z-[100] transition-all">
      <svg class="w-4 h-4 transition-transform duration-300" id="collapse-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
    </button>
    
    <div class="p-6 pb-2">
      <a href="/servers" class="sidebar-header-link flex items-center gap-4 group mb-2 p-2 -mx-2 rounded-xl hover:bg-white/5 transition-colors">
        <div class="w-10 h-10 rounded-xl bg-[#1a1a2e] border border-white/10 flex items-center justify-center text-gray-400 group-hover:text-white group-hover:border-nova group-hover:shadow-[0_0_15px_rgba(108,83,255,0.3)] transition-all duration-300 flex-shrink-0">
          <svg class="w-5 h-5 transition-transform group-hover:-translate-x-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
        </div>
        <div class="flex-1 sidebar-header-text truncate">
          <h1 class="font-bold text-lg text-white leading-tight group-hover:text-nova transition-colors">NYXO BOT</h1>
          <p class="text-[11px] text-gray-500 font-mono uppercase tracking-wider group-hover:text-gray-400">Back to Servers</p>
        </div>
      </a>
    </div>

    <nav class="flex-1 overflow-y-auto overflow-x-hidden custom-scroll pb-10 flex flex-col gap-0.5">
      ${navLinksHtml}
    </nav>

    <div class="support-panel p-4 mt-auto border-t border-white/5 bg-[#0b0b14] z-10 transition-all">
        <a href="https://discord.gg/yourserver" target="_blank" class="block relative overflow-hidden rounded-2xl bg-gradient-to-br from-[#1a1a2e] to-[#10101a] border border-white/5 p-4 group hover:border-nova/30 transition-all duration-500 hover:shadow-lg hover:shadow-nova/10">
            <div class="relative z-10 flex items-center justify-between">
                <div>
                    <p class="font-bold text-white text-sm group-hover:text-nova transition-colors whitespace-nowrap">Need Help?</p>
                    <p class="text-[10px] text-gray-500 mt-0.5 whitespace-nowrap">Join Support Server</p>
                </div>
                <div class="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center text-gray-400 group-hover:bg-nova group-hover:text-white transition-all duration-300 flex-shrink-0">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/></svg>
                </div>
            </div>
            <div class="absolute inset-0 bg-gradient-to-r from-nova/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
        </a>
    </div>
  `;

  sidebarContainer.innerHTML = sidebarHtml;
  sidebarContainer.className = "w-72 bg-[#09090b] border-r border-white/5 flex flex-col h-screen fixed lg:sticky top-0 font-sans shadow-[0_0_30px_rgba(0,0,0,0.5)] z-[60] transition-all duration-300 -translate-x-full lg:translate-x-0";

  // Dynamic Styles for Collapse
  if (!document.getElementById('sidebar-collapse-styles')) {
      const style = document.createElement('style');
      style.id = 'sidebar-collapse-styles';
      style.innerHTML = `
        /* Desktop collapsed state */
        @media (min-width: 1024px) {
            #nova-sidebar.collapsed { width: 5.5rem; }
            #nova-sidebar.collapsed .sidebar-category { display: none; }
            #nova-sidebar.collapsed .sidebar-text { display: none; }
            #nova-sidebar.collapsed .sidebar-premium-container { display: none; }
            #nova-sidebar.collapsed .sidebar-active-dot { display: none; }
            #nova-sidebar.collapsed .support-panel { padding: 0.5rem; }
            #nova-sidebar.collapsed .support-panel > a { padding: 0.5rem; display: flex; justify-content: center; }
            #nova-sidebar.collapsed .support-panel > a > div > div:first-child { display: none; }
            #nova-sidebar.collapsed .sidebar-header-text { display: none; }
            #nova-sidebar.collapsed .sidebar-link { justify-content: center; padding-left: 0; padding-right: 0; transform: translate(0); }
            #nova-sidebar.collapsed .sidebar-link:hover { transform: translate(0); background-color: rgba(255,255,255,0.05); }
            #nova-sidebar.collapsed .sidebar-header-link { justify-content: center; transform: translate(0); }
            #nova-sidebar.collapsed #collapse-icon { transform: rotate(180deg); }
            #nova-sidebar.collapsed .sidebar-divider { padding-top: 0.5rem; padding-bottom: 0.5rem; }
            #nova-sidebar.collapsed .sidebar-divider .mx-4 { margin-left: 1rem; margin-right: 1rem; }
            
            /* Main Content Transition & Fix */
            #nova-sidebar + div { 
                transition: margin-left 0.3s ease-in-out, width 0.3s ease-in-out; 
            }
            #nova-sidebar.collapsed + div { 
                margin-left: 5.5rem !important; 
                width: calc(100% - 5.5rem) !important; 
            }
        }
      `;
      document.head.appendChild(style);
  }

  // Handle Toggle
  const toggleBtn = document.getElementById('desktop-collapse');
  if (toggleBtn) {
      if (localStorage.getItem('sidebar_collapsed') === 'true') {
          sidebarContainer.classList.add('collapsed');
      }
      toggleBtn.addEventListener('click', () => {
          sidebarContainer.classList.toggle('collapsed');
          localStorage.setItem('sidebar_collapsed', sidebarContainer.classList.contains('collapsed'));
      });
  }
}
