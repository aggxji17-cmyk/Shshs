// Shared HTML-escaping helper for the admin panel. Values rendered into
// innerHTML on these pages (Discord usernames, guild names, blacklist
// reasons, etc.) can be set by arbitrary Discord users and are NOT
// trusted input - without escaping, a crafted username/guild name would
// execute script in the bot owner's browser session (stored XSS ->
// admin account takeover). Every admin view that builds HTML strings
// from API data must wrap those values in window.escapeHtml(...).
if (typeof window.escapeHtml !== "function") {
  window.escapeHtml = function escapeHtml(value) {
    if (value === null || value === undefined) return "";
    return String(value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  };
}

document.addEventListener("DOMContentLoaded", () => {
  const container = document.getElementById("sidebar-container");
  if (!container) return;

  // Mobile Toggle Logic
  function setupMobileToggle() {
    const main = document.querySelector('main');
    if (!main) return;

    // Inject Toggle Button if it doesn't exist
    if (!document.getElementById('mobile-toggle')) {
        const toggleBtn = document.createElement('button');
        toggleBtn.id = 'mobile-toggle';
        toggleBtn.className = 'lg:hidden fixed top-6 left-6 z-[50] p-2.5 bg-[#0a0a0a] border border-[#1f1f1f] rounded-xl text-nova hover:text-white transition-all shadow-xl';
        toggleBtn.innerHTML = `<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7"/></svg>`;
        document.body.appendChild(toggleBtn);

        const overlay = document.createElement('div');
        overlay.id = 'sidebar-overlay';
        overlay.className = 'fixed inset-0 bg-black/60 z-[40] hidden transition-opacity duration-300 opacity-0';
        document.body.appendChild(overlay);

        const sidebarElement = () => container.querySelector('aside');

        toggleBtn.onclick = () => {
            const sidebar = sidebarElement();
            if(!sidebar) return;
            sidebar.classList.toggle('-translate-x-full');
            sidebar.classList.toggle('translate-x-0');
            overlay.classList.toggle('hidden');
            setTimeout(() => overlay.classList.toggle('opacity-100'), 10);
        };

        overlay.onclick = () => {
            const sidebar = sidebarElement();
            if(!sidebar) return;
            sidebar.classList.add('-translate-x-full');
            sidebar.classList.remove('translate-x-0');
            overlay.classList.remove('opacity-100');
            setTimeout(() => overlay.classList.add('hidden'), 300);
        };
    }
  }
  setupMobileToggle();

  // 1. Define your menu items here (Easy to add new features!)
  const menuItems = [
    { name: "Overview", path: "/admin/overview", icon: "M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" },
    { name: "User Management", path: "/admin/users", icon: "M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" },
    { name: "Server Management", path: "/admin/servers", icon: "M5 12h14M5 12a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v4a2 2 0 01-2 2M5 12a2 2 0 00-2 2v4a2 2 0 002 2h14a2 2 0 002-2v-4a2 2 0 00-2-2m-2-4h.01M17 16h.01" },
    { name: "Premium Management", path: "/admin/premium", icon: "M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" },
    { name: "Premium Plans", path: "/admin/premium-plans", icon: "M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" },
    { name: "Premium Commands", path: "/admin/premium-commands", icon: "M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4v-3l8.44-8.44A6 6 0 0115 7zm-3-1a1 1 0 11-2 0 1 1 0 012 0z" },
    { name: "Blacklists", path: "/admin/blacklists", icon: "M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" },
    { name: "Broadcast", path: "/admin/broadcast", icon: "M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-1.234 9.168-3v14c-1.543-1.766-5.067-3-9.168-3H7a3.988 3.988 0 01-1.564-.317z" },
  ];

  // 2. Determine current active path
  const currentPath = window.location.pathname;

  // 3. Build the Menu HTML
  const menuHtml = menuItems.map(item => {
    // Check if this item matches the current URL
    const isActive = currentPath.includes(item.path) || (item.path === "/admin/overview" && currentPath === "/admin"); // b1a54085b7c14b134b7338c6c2d64d65

    // Set classes based on state
    const classes = isActive
      ? "bg-[#6C53FF] text-white"
      : "text-gray-400 hover:bg-[#1a1a1a] hover:text-white";

    return `
      <a href="${item.path}" class="flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all ${classes}">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="${item.icon}"/>
        </svg>
        ${item.name}
      </a>
    `;
  }).join('');

  // 4. Inject the entire sidebar structure
  container.innerHTML = `
    <aside class="w-60 bg-[#0a0a0a] border-r border-[#1f1f1f] fixed h-screen flex flex-col z-[60] transition-transform duration-300 -translate-x-full lg:translate-x-0">
      <div class="p-6 flex items-center gap-3">
        <div class="w-10 h-10 bg-[#6C53FF] rounded-lg flex items-center justify-center">
          <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/>
          </svg>
        </div>
        <span class="text-lg font-bold text-white">Admin Panel</span>
      </div>

      <nav class="flex-1 px-3 space-y-1">
        ${menuHtml}
      </nav>

      <div class="p-3 border-t border-[#1f1f1f]">
        <a href="/servers" class="flex items-center gap-2 px-4 py-3 bg-[#1a1a1a] hover:bg-[#252525] rounded-lg text-sm font-medium transition-all text-gray-300">
          <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
          Back to Dashboard
        </a>
      </div>
    </aside>
  `;
});