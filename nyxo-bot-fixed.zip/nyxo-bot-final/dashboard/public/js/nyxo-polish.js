(function nyxoPolish() {
  'use strict';

  const STORAGE_KEY = 'nyxo_dashboard_language';
  const THEME_KEY = 'nyxo_dashboard_theme';
  const languageNames = { ar: 'العربية', en: 'English' };
  const translations = {
    'NYXO BOT Dashboard': 'لوحة تحكم NYXO BOT',
    'Select Server': 'اختيار السيرفر',
    'Admin Panel': 'لوحة الإدارة',
    'Back to Dashboard': 'العودة للوحة التحكم',
    'Overview': 'نظرة عامة',
    'General Settings': 'الإعدادات العامة',
    'Welcome & Goodbye': 'الترحيب والمغادرة',
    'Moderation': 'الإشراف',
    'AutoMod': 'الإشراف التلقائي',
    'Approval Requests': 'طلبات الموافقة',
    'Logs': 'السجلات',
    'Anti-Nuke': 'الحماية من التخريب',
    'Leveling': 'المستويات',
    'Tickets': 'التذاكر',
    'Suggestions': 'الاقتراحات',
    'Minecraft': 'ماينكرافت',
    'User Management': 'إدارة الأعضاء',
    'Cases': 'الحالات',
    'Moderation Logs': 'سجلات الإشراف',
    'Schedule': 'الجدولة',
    'Temporary Roles': 'الرتب المؤقتة',
    'Config Backup': 'نسخ الإعدادات الاحتياطية',
    'Server Management': 'إدارة السيرفرات',
    'Premium Management': 'إدارة البريميوم',
    'Premium Plans': 'خطط البريميوم',
    'Premium Commands': 'أوامر البريميوم',
    'Blacklists': 'القوائم السوداء',
    'Broadcast': 'البث العام',
    'Login with Discord': 'تسجيل الدخول عبر Discord',
    'Logout': 'تسجيل الخروج',
    'Save Changes': 'حفظ التغييرات',
    'Settings saved': 'تم حفظ الإعدادات',
    'Nothing to save': 'لا توجد تغييرات للحفظ',
    'Loading...': 'جارٍ التحميل...',
    'Enabled': 'مفعّل',
    'Disabled': 'معطّل',
    'None': 'لا يوجد',
    'Prev': 'السابق',
    'Next': 'التالي',
    'Page': 'صفحة',
    'Quick Status': 'الحالة السريعة',
    'Branding & Staff Roles': 'الهوية ورتب الطاقم',
    'Bot Presence': 'حالة البوت',
    'Welcome Messages': 'رسائل الترحيب',
    'Goodbye Messages': 'رسائل المغادرة',
    'Events': 'الأحداث',
    'All actions': 'كل الإجراءات',
    'No cases found.': 'لا توجد حالات.',
    'No members match this search.': 'لا يوجد أعضاء مطابقون للبحث.',
    'No settings backups saved yet.': 'لا توجد نسخ إعدادات محفوظة بعد.',
    'Member Joined': 'انضمام عضو',
    'Member Left': 'مغادرة عضو',
    'Message Deleted': 'حذف رسالة',
    'Message Edited': 'تعديل رسالة',
    'Channel Changes': 'تغييرات القنوات',
    'Role Changes': 'تغييرات الرتب',
    'Search': 'بحث',
    'Theme': 'المظهر',
    'Language': 'اللغة',
    'Command search': 'بحث الأوامر',
  };
  const reverseTranslations = Object.fromEntries(
    Object.entries(translations).map(([en, ar]) => [ar, en]),
  );

  let currentLanguage = localStorage.getItem(STORAGE_KEY);
  if (!['ar', 'en'].includes(currentLanguage)) {
    currentLanguage = (navigator.language || '').toLowerCase().startsWith('ar') ? 'ar' : 'en';
  }

  function translate(value) {
    if (currentLanguage === 'en') return reverseTranslations[value] || value;
    return translations[value] || value;
  }

  function translateTextNodes(root) {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    const nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);
    for (const node of nodes) {
      const raw = node.nodeValue || '';
      const trimmed = raw.trim();
      if (!trimmed || node.parentElement?.closest('#nyxo-polish-toolbar, #nyxo-command-palette, code, pre, script, style')) continue;
      const translated = translate(trimmed);
      if (translated !== trimmed) {
        node.nodeValue = raw.replace(trimmed, translated);
      }
    }
  }

  function updateDocumentLanguage() {
    document.documentElement.lang = currentLanguage;
    document.documentElement.dir = currentLanguage === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.dataset.nyxoLanguage = currentLanguage;
    document.title = translate(document.title);
    document.querySelectorAll('input[placeholder], textarea[placeholder]').forEach((input) => {
      input.placeholder = translate(input.placeholder);
    });
    translateTextNodes(document.body);
  }

  function buildCommandItems() {
    const modernButtons = Array.from(document.querySelectorAll('[data-section]'));
    const links = Array.from(document.querySelectorAll('a[href]')).filter((link) => {
      const href = link.getAttribute('href') || '';
      return href.startsWith('/guild/') || href.startsWith('/admin/');
    });
    const unique = [];
    for (const element of [...modernButtons, ...links]) {
      const label = element.textContent.trim().replace(/\s+/g, ' ');
      if (!label || unique.some((item) => item.label === label)) continue;
      unique.push({ label, element });
    }
    return unique.slice(0, 80);
  }

  function closePalette() {
    document.getElementById('nyxo-command-palette')?.classList.remove('open');
  }

  function openPalette() {
    const palette = document.getElementById('nyxo-command-palette');
    if (!palette) return;
    palette.classList.add('open');
    const input = palette.querySelector('input');
    if (input) {
      input.value = '';
      input.focus();
    }
    renderPaletteItems('');
  }

  function renderPaletteItems(query) {
    const list = document.querySelector('#nyxo-command-palette .nyxo-command-list');
    if (!list) return;
    const normalized = query.trim().toLowerCase();
    const items = buildCommandItems().filter((item) =>
      !normalized || item.label.toLowerCase().includes(normalized) ||
      translate(item.label).toLowerCase().includes(normalized),
    );
    list.innerHTML = items.length
      ? items.map((item, index) => `<button class="nyxo-command-item" data-nyxo-command-index="${index}">${escapeHtml(translate(item.label))}</button>`).join('')
      : `<div class="nyxo-command-item">${escapeHtml(translate('No results'))}</div>`;
    list.querySelectorAll('[data-nyxo-command-index]').forEach((button) => {
      button.addEventListener('click', () => {
        items[Number(button.dataset.nyxoCommandIndex)].element.click();
        closePalette();
      });
    });
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, (character) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
    }[character]));
  }

  function mountToolbar() {
    if (document.getElementById('nyxo-polish-toolbar')) return;
    const toolbar = document.createElement('div');
    toolbar.id = 'nyxo-polish-toolbar';
    toolbar.setAttribute('aria-label', 'NYXO preferences');
    toolbar.innerHTML = `
      <button type="button" class="nyxo-language" id="nyxo-language-toggle" aria-label="Change language"></button>
      <button type="button" id="nyxo-theme-toggle" aria-label="Toggle theme">◐</button>
      <button type="button" id="nyxo-search-toggle" aria-label="Search">⌕ <span class="nyxo-kbd">Ctrl K</span></button>
    `;
    document.body.appendChild(toolbar);
    toolbar.querySelector('#nyxo-language-toggle').addEventListener('click', () => {
      currentLanguage = currentLanguage === 'ar' ? 'en' : 'ar';
      localStorage.setItem(STORAGE_KEY, currentLanguage);
      updateDocumentLanguage();
      updateToolbar();
    });
    toolbar.querySelector('#nyxo-theme-toggle').addEventListener('click', () => {
      const isDim = document.documentElement.dataset.nyxoTheme === 'dim';
      document.documentElement.dataset.nyxoTheme = isDim ? 'dark' : 'dim';
      localStorage.setItem(THEME_KEY, document.documentElement.dataset.nyxoTheme);
    });
    toolbar.querySelector('#nyxo-search-toggle').addEventListener('click', openPalette);
    updateToolbar();
  }

  function updateToolbar() {
    const language = document.getElementById('nyxo-language-toggle');
    if (language) language.textContent = currentLanguage === 'ar' ? 'English' : 'العربية';
  }

  function mountPalette() {
    if (document.getElementById('nyxo-command-palette')) return;
    const palette = document.createElement('div');
    palette.id = 'nyxo-command-palette';
    palette.innerHTML = `
      <div class="nyxo-palette-card" role="dialog" aria-modal="true" aria-label="Command search">
        <input type="search" autocomplete="off" placeholder="${escapeHtml(translate('Command search'))}">
        <div class="nyxo-command-list"></div>
      </div>
    `;
    palette.addEventListener('click', (event) => {
      if (event.target === palette) closePalette();
    });
    palette.querySelector('input').addEventListener('input', (event) => renderPaletteItems(event.target.value));
    document.body.appendChild(palette);
  }

  function init() {
    const savedTheme = localStorage.getItem(THEME_KEY);
    if (savedTheme) document.documentElement.dataset.nyxoTheme = savedTheme;
    mountToolbar();
    mountPalette();
    updateDocumentLanguage();
    document.addEventListener('keydown', (event) => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault();
        openPalette();
      }
      if (event.key === 'Escape') closePalette();
    });
    // Dynamic dashboard screens render their content after this script loads.
    // A small observer keeps the shared translation layer in sync.
    const observer = new MutationObserver(() => {
      window.clearTimeout(init.translationTimer);
      init.translationTimer = window.setTimeout(updateDocumentLanguage, 40);
    });
    observer.observe(document.body, { childList: true, subtree: true });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init, { once: true });
  } else {
    init();
  }
})();