const app = document.getElementById('app');

const state = {
  user: null,
  guilds: [],
  guildId: null,
  overview: null,
  config: null,
  draft: {},
  section: 'overview',
  // Live (non-draft) data for the pages that show server-side state
  // instead of editable settings - loaded on demand, not part of the
  // save-draft flow.
  approvals: { status: 'Pending', page: 1, requests: [], total: 0, totalPages: 1, loading: false },
  logs: { action: '', page: 1, cases: [], total: 0, totalPages: 1, loading: false },
  // Task 16 - system management pages. Each has its own filters/paging
  // state, kept separate so switching sections never loses the others'
  // filters. `detail` holds whichever record is open in the detail modal.
  cases: { q: '', action: '', status: '', page: 1, items: [], total: 0, totalPages: 1, detail: null },
  modlogs: { moderatorId: '', targetId: '', action: '', range: 'all', sort: 'newest', page: 1, items: [], total: 0, totalPages: 1 },
  schedule: { status: 'Pending', action: '', q: '', page: 1, items: [], total: 0, totalPages: 1, detail: null },
  temproles: { status: 'Pending', q: '', page: 1, items: [], total: 0, totalPages: 1, detail: null },
  backups: { q: '', page: 1, items: [], total: 0, totalPages: 1, detail: null },
  // Task 18 - User Management: a search box over guild members plus the
  // profile of whichever one is currently selected (loaded fresh from
  // /guilds/:id/members/:userId, so it's never stale).
  users: { q: '', results: [], loading: false, profile: null, profileLoading: false },
};

const SECTIONS = [
  { id: 'overview', label: 'Overview' },
  { id: 'branding', label: 'General Settings' },
  { id: 'welcome', label: 'Welcome & Goodbye' },
  { id: 'moderation', label: 'Moderation' },
  { id: 'automod', label: 'AutoMod' },
  { id: 'approvals', label: 'Approval Requests' },
  { id: 'logging', label: 'Logs' },
  { id: 'antinuke', label: 'Anti-Nuke' },
  { id: 'leveling', label: 'Leveling' },
  { id: 'tickets', label: 'Tickets' },
  { id: 'suggestions', label: 'Suggestions' },
  { id: 'minecraft', label: 'Minecraft' },
  { id: 'users', label: 'User Management' },
  { id: 'cases', label: 'Cases' },
  { id: 'modlogs', label: 'Moderation Logs' },
  { id: 'schedule', label: 'Schedule' },
  { id: 'temproles', label: 'Temporary Roles' },
  { id: 'backups', label: 'Config Backup' },
];

async function api(path, options = {}) {
  const res = await fetch(`/api${path}`, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });
  if (res.status === 401) {
    state.user = null;
    render();
    throw new Error('unauthenticated');
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = new Error(data.error || 'Request failed');
    err.errors = Array.isArray(data.errors) ? data.errors : [];
    throw err;
  }
  return data;
}

function get(obj, path) {
  return path.split('.').reduce((acc, key) => acc?.[key], obj);
}

function set(obj, path, value) {
  const keys = path.split('.');
  let cursor = obj;
  for (let i = 0; i < keys.length - 1; i += 1) {
    cursor[keys[i]] = cursor[keys[i]] || {};
    cursor = cursor[keys[i]];
  }
  cursor[keys[keys.length - 1]] = value;
}

function currentValue(path) {
  const draftValue = get(state.draft, path);
  if (draftValue !== undefined) return draftValue;
  return get(state.config, path);
}

function markDirty(path, value) {
  set(state.draft, path, value);
}

function toast(message, kind = 'good') {
  const el = document.createElement('div');
  el.className = `toast ${kind}`;
  el.textContent = message;
  document.body.appendChild(el);
  setTimeout(() => el.remove(), 3000);
}

async function boot() {
  try {
    state.user = await api('/me');
    state.guilds = await api('/guilds');
    if (state.guilds.length) await selectGuild(state.guilds[0].id);
  } catch {
    state.user = null;
  }
  render();
}

async function selectGuild(guildId) {
  state.guildId = guildId;
  state.draft = {};
  const [overview, config] = await Promise.all([
    api(`/guilds/${guildId}/overview`),
    api(`/guilds/${guildId}/config`),
  ]);
  state.overview = overview;
  state.config = config;
  render();
}

async function saveDraft() {
  if (!Object.keys(state.draft).length) return toast('Nothing to save', 'bad');
  try {
    await api(`/guilds/${state.guildId}/config`, { method: 'POST', body: JSON.stringify(state.draft) });
    Object.assign(state.config, deepMerge(state.config, state.draft));
    state.draft = {};
    toast('Settings saved');
    render();
  } catch (err) {
    const detail = err.errors && err.errors.length ? ` — ${err.errors[0].message}` : '';
    toast(`${err.message}${detail}`, 'bad');
  }
}

function deepMerge(target, source) {
  for (const [key, value] of Object.entries(source)) {
    if (value !== null && typeof value === 'object' && !Array.isArray(value)) {
      target[key] = deepMerge(target[key] || {}, value);
    } else {
      target[key] = value;
    }
  }
  return target;
}

function render() {
  if (!state.user) return renderLogin();
  if (!state.guilds.length) return renderNoGuilds();
  renderShell();
}

function renderLogin() {
  app.innerHTML = `
    <div class="login-wrap">
      <div class="login-card">
        <div class="pulse"></div>
        <h1>NYXO BOT</h1>
        <p>Sign in with Discord to manage your server's configuration.</p>
        <a class="btn-discord" href="/auth/discord/login">Login with Discord</a>
      </div>
    </div>`;
}

function renderNoGuilds() {
  app.innerHTML = `
    <div class="login-wrap">
      <div class="login-card">
        <h1>No manageable servers</h1>
        <p>You need "Manage Server" permission on a server where NYXO BOT is installed.</p>
      </div>
    </div>`;
}

function renderShell() {
  app.innerHTML = `
    <div class="shell">
      <div class="sidebar">
        <div class="brand"><span class="dot"></span> NYXO BOT</div>
        <select class="guild-picker" id="guildPicker">
          ${state.guilds.map((g) => `<option value="${g.id}" ${g.id === state.guildId ? 'selected' : ''}>${escapeHtml(g.name)}</option>`).join('')}
        </select>
        <div class="nav">
          ${SECTIONS.map((s) => `<button data-section="${s.id}" class="${state.section === s.id ? 'active' : ''}">${s.label}</button>`).join('')}
        </div>
        <div class="user-chip">
          <div class="avatar"></div>
          <span>${escapeHtml(state.user.username)}</span>
          <span class="logout-link" id="logoutBtn">Logout</span>
        </div>
      </div>
      <div class="main" id="main"></div>
    </div>`;

  document.getElementById('guildPicker').addEventListener('change', (e) => selectGuild(e.target.value));
  document.getElementById('logoutBtn').addEventListener('click', async () => {
    await api('/logout', { method: 'POST' }).catch(() => null);
    fetch('/auth/logout', { method: 'POST' }).finally(() => window.location.reload());
  });
  document.querySelectorAll('.nav button').forEach((btn) => {
    btn.addEventListener('click', () => {
      state.section = btn.dataset.section;
      render();
    });
  });

  renderSection();
}

function renderSection() {
  const main = document.getElementById('main');
  const renderers = {
    overview: renderOverview,
    branding: renderBranding,
    welcome: renderWelcomeGoodbye,
    moderation: renderModeration,
    logging: renderLogging,
    automod: renderAutomod,
    approvals: renderApprovals,
    antinuke: renderAntinuke,
    leveling: renderLeveling,
    tickets: renderTickets,
    suggestions: renderSuggestions,
    minecraft: renderMinecraft,
    users: renderUsersPage,
    cases: renderCasesPage,
    modlogs: renderModlogsPage,
    schedule: renderSchedulePage,
    temproles: renderTemprolesPage,
    backups: renderBackupsPage,
  };
  main.innerHTML = renderers[state.section]();
  attachCommonHandlers();
  attachListHandlers();
  if (state.section === 'minecraft') attachMinecraftHandlers();
  if (state.section === 'users') attachUsersHandlers();
  if (state.section === 'approvals') attachApprovalsHandlers();
  if (state.section === 'logging') attachLogsHandlers();
  if (state.section === 'cases') attachCasesHandlers();
  if (state.section === 'modlogs') attachModlogsHandlers();
  if (state.section === 'schedule') attachScheduleHandlers();
  if (state.section === 'temproles') attachTemprolesHandlers();
  if (state.section === 'backups') attachBackupsHandlers();
}

function attachCommonHandlers() {
  document.querySelectorAll('[data-path]').forEach((el) => {
    const path = el.dataset.path;
    const type = el.dataset.type || 'text';
    el.addEventListener(type === 'checkbox' ? 'change' : 'input', () => {
      let value = type === 'checkbox' ? el.checked : el.value;
      if (type === 'number') value = Number(value);
      if (type === 'list') value = el.value.split(',').map((v) => v.trim()).filter(Boolean);
      markDirty(path, value);
    });
  });
  const saveBtn = document.getElementById('saveBtn');
  if (saveBtn) saveBtn.addEventListener('click', saveDraft);
}

/**
 * Generic editor for array-of-object settings (warnThresholds,
 * autoDeleteChannels, the per-role weekly limit lists...). Each row field
 * carries data-list-path/data-list-index/data-list-field instead of
 * data-path, since these values live inside an array, not at a fixed
 * dot-path. Add/remove buttons re-render the section (rows appear or
 * disappear); editing a field's value does not, so typing never loses
 * focus.
 */
function listValue(path) {
  const v = currentValue(path);
  return Array.isArray(v) ? v : [];
}

function updateListItem(path, index, field, value) {
  const list = listValue(path).map((row) => ({ ...row }));
  list[index] = { ...list[index], [field]: value };
  markDirty(path, list);
}

function addListItem(path, defaultRow) {
  const list = listValue(path).map((row) => ({ ...row }));
  list.push(defaultRow);
  markDirty(path, list);
  renderSection();
}

function removeListItem(path, index) {
  const list = listValue(path).map((row) => ({ ...row }));
  list.splice(index, 1);
  markDirty(path, list);
  renderSection();
}

function attachListHandlers() {
  document.querySelectorAll('[data-list-path]').forEach((el) => {
    const path = el.dataset.listPath;
    const index = Number(el.dataset.listIndex);
    const field = el.dataset.listField;
    const type = el.dataset.type || 'text';
    el.addEventListener(type === 'checkbox' ? 'change' : 'input', () => {
      let value = type === 'checkbox' ? el.checked : el.value;
      if (type === 'number') value = Number(value);
      updateListItem(path, index, field, value);
    });
  });
  document.querySelectorAll('[data-list-add]').forEach((btn) => {
    btn.addEventListener('click', () => {
      addListItem(btn.dataset.listAdd, JSON.parse(btn.dataset.listDefault));
    });
  });
  document.querySelectorAll('[data-list-remove]').forEach((btn) => {
    btn.addEventListener('click', () => {
      removeListItem(btn.dataset.listRemove, Number(btn.dataset.listIndex));
      toast('تم الحذف - اضغط "Save Changes" لتأكيد الحفظ');
    });
  });
}

function saveBar() {
  return `<div class="save-bar"><button class="btn" id="saveBtn">Save Changes</button></div>`;
}

function channelOptions(selectedId, includeCategories = false) {
  const channels = state.overview.channels.filter((c) => includeCategories || c.type !== 4);
  return `<option value="">None</option>` + channels.map((c) => `<option value="${c.id}" ${c.id === selectedId ? 'selected' : ''}>#${escapeHtml(c.name)}</option>`).join('');
}

function roleOptions(selectedId) {
  return `<option value="">None</option>` + state.overview.roles.map((r) => `<option value="${r.id}" ${r.id === selectedId ? 'selected' : ''}>${escapeHtml(r.name)}</option>`).join('');
}

function renderOverview() {
  const o = state.overview;
  return `
    <h1 class="page-title">${escapeHtml(o.name)}</h1>
    <p class="page-subtitle">${o.memberCount} members &middot; ${o.channels.length} channels &middot; ${o.roles.length} roles</p>
    <div class="card">
      <h3>Quick Status</h3>
      <div class="row">
        <div class="field"><label>AutoMod</label>${state.config.automod.enabled ? '✅ Enabled' : '❌ Disabled'}</div>
        <div class="field"><label>Anti-Nuke</label>${state.config.antinuke.enabled ? '✅ Enabled' : '❌ Disabled'}</div>
        <div class="field"><label>Leveling</label>${state.config.leveling.enabled ? '✅ Enabled' : '❌ Disabled'}</div>
        <div class="field"><label>Tickets</label>${state.config.tickets.enabled ? '✅ Enabled' : '❌ Disabled'}</div>
      </div>
      <p class="hint">Use the sidebar to configure each module. Changes save instantly to the bot - no restart needed.</p>
    </div>`;
}

function renderBranding() {
  return `
    <h1 class="page-title">Branding & Staff Roles</h1>
    <p class="page-subtitle">Controls how the bot looks and who counts as staff in this server.</p>
    <div class="card">
      <div class="row">
        <div class="field">
          <label>Embed Color</label>
          <input type="color" data-path="embedColor" value="${currentValue('embedColor') || '#5865F2'}" />
        </div>
        <div class="field">
          <label>Footer Text</label>
          <input type="text" data-path="footer" value="${escapeAttr(currentValue('footer') || '')}" />
        </div>
      </div>
      <div class="row">
        <div class="field">
          <label>Prefix (legacy text commands)</label>
          <input type="text" data-path="prefix" value="${escapeAttr(currentValue('prefix') || '!')}" />
        </div>
        <div class="field"></div>
      </div>
      <div class="row">
        <div class="field">
          <label>Moderator Role</label>
          <select data-path="modRoleId">${roleOptions(currentValue('modRoleId'))}</select>
        </div>
        <div class="field">
          <label>Admin Role</label>
          <select data-path="adminRoleId">${roleOptions(currentValue('adminRoleId'))}</select>
        </div>
      </div>
      <div class="field">
        <label>Auto-Role (given to new members)</label>
        <select data-path="autoRoleId">${roleOptions(currentValue('autoRoleId'))}</select>
      </div>
      ${saveBar()}
    </div>
    <div class="card">
      <h3>Bot Presence</h3>
      <div class="row">
        <div class="field">
          <label>Status</label>
          <select data-path="botStatus">
            ${['online', 'idle', 'dnd', 'invisible'].map((s) => `<option value="${s}" ${(currentValue('botStatus') || 'online') === s ? 'selected' : ''}>${s}</option>`).join('')}
          </select>
        </div>
        <div class="field">
          <label>Activity Type</label>
          <select data-path="activityType">
            ${['Playing', 'Streaming', 'Listening', 'Watching', 'Competing'].map((t) => `<option value="${t}" ${(currentValue('activityType') || 'Watching') === t ? 'selected' : ''}>${t}</option>`).join('')}
          </select>
        </div>
      </div>
      <div class="field">
        <label>Activity Text</label>
        <input type="text" data-path="activityText" value="${escapeAttr(currentValue('activityText') || '')}" />
        <div class="hint">Reserved for a future per-server presence override - the bot's live status/activity is currently set globally from its .env config.</div>
      </div>
      ${saveBar()}
    </div>`;
}

function renderWelcomeGoodbye() {
  return `
    <h1 class="page-title">Welcome & Goodbye</h1>
    <p class="page-subtitle">Greet new members and announce departures automatically.</p>
    <div class="card">
      <h3>Welcome Messages</h3>
      <div class="toggle-row"><span>Enabled</span>${toggle('welcome.enabled')}</div>
      <div class="field"><label>Channel</label><select data-path="welcome.channelId">${channelOptions(currentValue('welcome.channelId'))}</select></div>
      <div class="field"><label>Message</label><textarea data-path="welcome.message">${escapeHtml(currentValue('welcome.message') || '')}</textarea>
      <div class="hint">Placeholders: {user} {username} {server} {memberCount}</div></div>
    </div>
    <div class="card">
      <h3>Goodbye Messages</h3>
      <div class="toggle-row"><span>Enabled</span>${toggle('goodbye.enabled')}</div>
      <div class="field"><label>Channel</label><select data-path="goodbye.channelId">${channelOptions(currentValue('goodbye.channelId'))}</select></div>
      <div class="field"><label>Message</label><textarea data-path="goodbye.message">${escapeHtml(currentValue('goodbye.message') || '')}</textarea></div>
      ${saveBar()}
    </div>`;
}

function renderLogging() {
  const events = ['messageDelete', 'messageEdit', 'memberJoin', 'memberLeave', 'memberBan', 'memberUnban', 'channelUpdates', 'roleUpdates'];
  const labels = { messageDelete: 'Message Deleted', messageEdit: 'Message Edited', memberJoin: 'Member Joined', memberLeave: 'Member Left', memberBan: 'Member Banned', memberUnban: 'Member Unbanned', channelUpdates: 'Channel Changes', roleUpdates: 'Role Changes' };
  return `
    <h1 class="page-title">Logs</h1>
    <p class="page-subtitle">Send an audit trail of server activity to a dedicated channel, and review the moderation case history.</p>
    <div class="card">
      <div class="toggle-row"><span>Enabled</span>${toggle('logging.enabled')}</div>
      <div class="field"><label>Log Channel</label><select data-path="logging.channelId">${channelOptions(currentValue('logging.channelId'))}</select></div>
      <h3 style="margin-top:20px;">Events</h3>
      ${events.map((e) => `<div class="toggle-row"><span>${labels[e]}</span>${toggle(`logging.events.${e}`)}</div>`).join('')}
      ${saveBar()}
    </div>
    <div class="card">
      <h3>Moderation Case History</h3>
      <div class="row" style="grid-template-columns: 1fr; margin-bottom:14px;">
        <select id="logsActionFilter">
          <option value="">All actions</option>
          ${['ban', 'kick', 'timeout', 'warn', 'unban', 'softban'].map((a) => `<option value="${a}" ${state.logs.action === a ? 'selected' : ''}>${a}</option>`).join('')}
        </select>
      </div>
      <div id="logsList" class="empty-state">Loading...</div>
      <div id="logsPager" style="display:flex; justify-content:flex-end; gap:10px; margin-top:14px;"></div>
    </div>`;
}

async function loadCases() {
  const listEl = document.getElementById('logsList');
  if (listEl) listEl.innerHTML = '<div class="empty-state">Loading...</div>';
  try {
    const params = new URLSearchParams({ page: String(state.logs.page) });
    if (state.logs.action) params.set('action', state.logs.action);
    const result = await api(`/guilds/${state.guildId}/cases?${params.toString()}`);
    state.logs.cases = result.cases;
    state.logs.total = result.total;
    state.logs.totalPages = result.totalPages;
  } catch (err) {
    if (listEl) listEl.innerHTML = `<div class="empty-state">${escapeHtml(err.message)}</div>`;
    return;
  }
  renderCasesList();
}

function renderCasesList() {
  const listEl = document.getElementById('logsList');
  const pagerEl = document.getElementById('logsPager');
  if (!listEl) return;
  const { cases, page, totalPages } = state.logs;

  if (!cases.length) {
    listEl.innerHTML = '<div class="empty-state">No cases found.</div>';
  } else {
    listEl.innerHTML = cases
      .map(
        (c) => `
      <div class="card" style="margin-bottom:10px;">
        <div class="row" style="grid-template-columns: 2fr 1fr;">
          <div>
            <div><strong>#${c.caseId} &middot; ${escapeHtml(c.action)}</strong> &middot; target <code>${escapeHtml(c.targetId)}</code></div>
            <div class="hint">By <code>${escapeHtml(c.moderatorId)}</code> on ${escapeHtml(new Date(c.createdAt).toLocaleString())}</div>
            <div class="hint">Reason: ${escapeHtml(c.reason || 'No reason provided')}</div>
          </div>
          <div style="text-align:right;"><span class="badge ${c.status === 'Active' ? 'online' : 'offline'}">${escapeHtml(c.status)}</span></div>
        </div>
      </div>`
      )
      .join('');
  }

  if (pagerEl) {
    pagerEl.innerHTML = `
      <button class="btn secondary" id="logsPrev" ${page <= 1 ? 'disabled' : ''}>Prev</button>
      <span class="hint" style="align-self:center;">Page ${page} / ${totalPages}</span>
      <button class="btn secondary" id="logsNext" ${page >= totalPages ? 'disabled' : ''}>Next</button>`;
    const prev = document.getElementById('logsPrev');
    const next = document.getElementById('logsNext');
    if (prev) prev.addEventListener('click', () => { state.logs.page -= 1; loadCases(); });
    if (next) next.addEventListener('click', () => { state.logs.page += 1; loadCases(); });
  }
}

function attachLogsHandlers() {
  const filter = document.getElementById('logsActionFilter');
  if (filter) {
    filter.addEventListener('change', () => {
      state.logs.action = filter.value;
      state.logs.page = 1;
      loadCases();
    });
  }
  loadCases();
}

function renderAutomod() {
  const checks = [
    { key: 'antiSpam', label: 'Anti Spam', hasThreshold: true, thresholdLabel: 'Messages per 7s' },
    { key: 'antiInvite', label: 'Anti Invite', hasThreshold: false },
    { key: 'antiLink', label: 'Anti Links', hasThreshold: false },
    { key: 'antiMentionSpam', label: 'Anti Mention Spam', hasThreshold: true, thresholdLabel: 'Max mentions' },
    { key: 'antiMassEmoji', label: 'Anti Mass Emoji', hasThreshold: true, thresholdLabel: 'Max emojis' },
    { key: 'antiCaps', label: 'Anti Caps', hasThreshold: true, thresholdLabel: 'Max caps %' },
    { key: 'antiZalgo', label: 'Anti Zalgo/Unicode Spam', hasThreshold: true, thresholdLabel: 'Max zalgo %' },
  ];
  const punishments = ['delete', 'warn', 'timeout', 'kick', 'ban', 'softban'];

  const checkCard = (c) => `
    <div class="card">
      <div class="toggle-row"><span>${c.label}</span>${toggle(`automod.checks.${c.key}.enabled`)}</div>
      <div class="row">
        <div class="field">
          <label>Punishment</label>
          <select data-path="automod.checks.${c.key}.punishment">
            ${punishments.map((p) => `<option value="${p}" ${currentValue(`automod.checks.${c.key}.punishment`) === p ? 'selected' : ''}>${p}</option>`).join('')}
          </select>
        </div>
        <div class="field"><label>Timeout Minutes</label><input type="number" data-type="number" data-path="automod.checks.${c.key}.timeoutMinutes" value="${currentValue(`automod.checks.${c.key}.timeoutMinutes`) ?? 10}" /></div>
        ${c.hasThreshold ? `<div class="field"><label>${c.thresholdLabel}</label><input type="number" data-type="number" data-path="automod.checks.${c.key}.threshold" value="${currentValue(`automod.checks.${c.key}.threshold`) ?? ''}" /></div>` : ''}
      </div>
    </div>`;

  return `
    <h1 class="page-title">AutoMod</h1>
    <p class="page-subtitle">Automatically moderate spam, invites, links, mentions, emoji, caps and zalgo text - each with its own punishment.</p>
    <div class="card">
      <div class="toggle-row"><span>AutoMod Enabled (master switch)</span>${toggle('automod.enabled')}</div>
    </div>
    ${checks.map(checkCard).join('')}
    <div class="card">
      <div class="field">
        <label>Ignored Role IDs (comma separated)</label>
        <input type="text" data-type="list" data-path="automod.ignoredRoleIds" value="${escapeAttr((currentValue('automod.ignoredRoleIds') || []).join(', '))}" />
      </div>
      <div class="field">
        <label>Ignored Channel IDs (comma separated)</label>
        <input type="text" data-type="list" data-path="automod.ignoredChannelIds" value="${escapeAttr((currentValue('automod.ignoredChannelIds') || []).join(', '))}" />
      </div>
      <p class="hint">You can also manage these with <code>/automod whitelistrole</code> and <code>/automod whitelistchannel</code> in Discord.</p>
      ${saveBar()}
    </div>`;
}

function renderModeration() {
  const warnRows = listValue('moderation.warnThresholds');
  const autoDeleteRows = listValue('moderation.autoDeleteChannels');

  const warnThresholdsCard = `
    <div class="card">
      <h3>Warn Thresholds <button class="btn secondary" data-list-add="moderation.warnThresholds" data-list-default='{"count":3,"action":"timeout","durationMinutes":60}'>+ Add</button></h3>
      <p class="hint">When a member reaches a warning count below, take an automatic action.</p>
      ${warnRows.length === 0 ? '<div class="empty-state">No thresholds configured.</div>' : ''}
      ${warnRows
        .map(
          (row, i) => `
        <div class="row" style="grid-template-columns: 1fr 1fr 1fr auto; align-items:end;">
          <div class="field"><label>Warning Count</label><input type="number" data-type="number" data-list-path="moderation.warnThresholds" data-list-index="${i}" data-list-field="count" value="${row.count ?? 1}" /></div>
          <div class="field"><label>Action</label>
            <select data-list-path="moderation.warnThresholds" data-list-index="${i}" data-list-field="action">
              ${['timeout', 'kick', 'ban'].map((a) => `<option value="${a}" ${row.action === a ? 'selected' : ''}>${a}</option>`).join('')}
            </select>
          </div>
          <div class="field"><label>Timeout Minutes</label><input type="number" data-type="number" data-list-path="moderation.warnThresholds" data-list-index="${i}" data-list-field="durationMinutes" value="${row.durationMinutes ?? 60}" /></div>
          <div class="field"><button class="btn secondary" data-list-remove="moderation.warnThresholds" data-list-index="${i}">Remove</button></div>
        </div>`
        )
        .join('')}
    </div>`;

  const autoDeleteCard = `
    <div class="card">
      <h3>Auto-Delete Channels <button class="btn secondary" data-list-add="moderation.autoDeleteChannels" data-list-default='{"channelId":"","delaySeconds":30}'>+ Add</button></h3>
      <p class="hint">Messages sent in these channels are automatically deleted after the given delay.</p>
      ${autoDeleteRows.length === 0 ? '<div class="empty-state">No channels configured.</div>' : ''}
      ${autoDeleteRows
        .map(
          (row, i) => `
        <div class="row" style="grid-template-columns: 1fr 1fr auto; align-items:end;">
          <div class="field"><label>Channel</label>
            <select data-list-path="moderation.autoDeleteChannels" data-list-index="${i}" data-list-field="channelId">${channelOptions(row.channelId)}</select>
          </div>
          <div class="field"><label>Delay (seconds)</label><input type="number" data-type="number" data-list-path="moderation.autoDeleteChannels" data-list-index="${i}" data-list-field="delaySeconds" value="${row.delaySeconds ?? 30}" /></div>
          <div class="field"><button class="btn secondary" data-list-remove="moderation.autoDeleteChannels" data-list-index="${i}">Remove</button></div>
        </div>`
        )
        .join('')}
    </div>`;

  const perRoleCard = (kind, title, hint) => {
    const rows = listValue(`moderation.${kind}.perRole`);
    return `
      <div class="card">
        <div class="toggle-row"><span>${title} Enabled</span>${toggle(`moderation.${kind}.enabled`)}</div>
        <p class="hint">${hint}</p>
        <div class="field"><button class="btn secondary" data-list-add="moderation.${kind}.perRole" data-list-default='{"roleId":"","weeklyLimit":5}'>+ Add Role</button></div>
        ${rows.length === 0 ? '<div class="empty-state">No per-role limits configured.</div>' : ''}
        ${rows
          .map(
            (row, i) => `
          <div class="row" style="grid-template-columns: 1fr 1fr auto; align-items:end;">
            <div class="field"><label>Role</label><select data-list-path="moderation.${kind}.perRole" data-list-index="${i}" data-list-field="roleId">${roleOptions(row.roleId)}</select></div>
            <div class="field"><label>Weekly Limit (-1 = unlimited)</label><input type="number" data-type="number" data-list-path="moderation.${kind}.perRole" data-list-index="${i}" data-list-field="weeklyLimit" value="${row.weeklyLimit ?? 5}" /></div>
            <div class="field"><button class="btn secondary" data-list-remove="moderation.${kind}.perRole" data-list-index="${i}">Remove</button></div>
          </div>`
          )
          .join('')}
      </div>`;
  };

  return `
    <h1 class="page-title">Moderation</h1>
    <p class="page-subtitle">Warning escalation, auto-delete channels, and weekly quotas for ban/kick/timeout/softban per role.</p>
    <div class="card">
      <div class="toggle-row"><span>Anti Ghost-Ping (flag deleted mention pings)</span>${toggle('moderation.antiGhostPing')}</div>
    </div>
    ${warnThresholdsCard}
    ${autoDeleteCard}
    ${perRoleCard('banLimits', 'Ban Limits', 'Weekly /ban quota per role. Members without a configured role are unlimited.')}
    ${perRoleCard('kickLimits', 'Kick Limits', 'Weekly /kick quota per role.')}
    ${perRoleCard('timeoutLimits', 'Timeout Limits', 'Weekly /timeout quota per role.')}
    ${perRoleCard('softbanLimits', 'Softban Limits', 'Weekly /softban quota per role.')}
    ${saveBar()}`;
}

function renderAntinuke() {
  return `
    <h1 class="page-title">Anti-Nuke</h1>
    <p class="page-subtitle">Detect and stop mass-destructive actions (channel/role deletion, mass bans, rogue webhooks).</p>
    <div class="card">
      <div class="toggle-row"><span>Anti-Nuke Enabled</span>${toggle('antinuke.enabled')}</div>
      <div class="field">
        <label>Punishment</label>
        <select data-path="antinuke.punishment">
          ${['stripRoles', 'kick', 'ban'].map((p) => `<option value="${p}" ${currentValue('antinuke.punishment') === p ? 'selected' : ''}>${p}</option>`).join('')}
        </select>
      </div>
      <h3 style="margin-top:20px;">Thresholds (actions within the detection window)</h3>
      <div class="row">
        <div class="field"><label>Channel Deletes</label><input type="number" data-type="number" data-path="antinuke.thresholds.channelDelete" value="${currentValue('antinuke.thresholds.channelDelete') ?? 3}" /></div>
        <div class="field"><label>Role Deletes</label><input type="number" data-type="number" data-path="antinuke.thresholds.roleDelete" value="${currentValue('antinuke.thresholds.roleDelete') ?? 3}" /></div>
      </div>
      <div class="row">
        <div class="field"><label>Member Bans</label><input type="number" data-type="number" data-path="antinuke.thresholds.memberBan" value="${currentValue('antinuke.thresholds.memberBan') ?? 3}" /></div>
        <div class="field"><label>Webhook Creates</label><input type="number" data-type="number" data-path="antinuke.thresholds.webhookCreate" value="${currentValue('antinuke.thresholds.webhookCreate') ?? 3}" /></div>
      </div>
      <div class="field"><label>Detection Window (ms)</label><input type="number" data-type="number" data-path="antinuke.windowMs" value="${currentValue('antinuke.windowMs') ?? 10000}" /></div>
      <p class="hint">Manage the whitelist with <code>/antinuke whitelist</code> in Discord.</p>
      ${saveBar()}
    </div>`;
}

function renderApprovals() {
  return `
    <h1 class="page-title">Approval Requests</h1>
    <p class="page-subtitle">Gate moderation actions behind a human review before they run, and decide pending requests right here.</p>
    <div class="card">
      <div class="toggle-row"><span>Approvals Enabled</span>${toggle('approvals.enabled')}</div>
      <div class="field"><label>Review Channel</label><select data-path="approvals.reviewChannelId">${channelOptions(currentValue('approvals.reviewChannelId'))}</select></div>
      <div class="field">
        <label>Approver Role IDs (comma separated - empty means any moderator)</label>
        <input type="text" data-type="list" data-path="approvals.approverRoleIds" value="${escapeAttr((currentValue('approvals.approverRoleIds') || []).join(', '))}" />
      </div>
      <div class="field"><label>Request Expires After (minutes)</label><input type="number" data-type="number" data-path="approvals.expiresAfterMinutes" value="${currentValue('approvals.expiresAfterMinutes') ?? 60}" /></div>
      <div class="field">
        <label>Actions That Require Approval</label>
        <div class="row">
          ${['ban', 'kick', 'timeout', 'softban']
            .map(
              (a) => `<label style="display:flex;align-items:center;gap:8px;font-size:13.5px;">
                <input type="checkbox" data-type="checkbox" onchange="toggleRequiredAction('${a}', this.checked)" ${(currentValue('approvals.requiredActions') || []).includes(a) ? 'checked' : ''} /> ${a}
              </label>`
            )
            .join('')}
        </div>
      </div>
      <div class="toggle-row"><span>DM Requester on Decision</span>${toggle('approvals.notifyRequester')}</div>
      ${saveBar()}
    </div>
    <div class="card">
      <h3>Requests</h3>
      <div class="row" style="grid-template-columns: 1fr; margin-bottom:14px;">
        <select id="approvalsStatusFilter">
          ${['Pending', 'Approved', 'Rejected', 'Expired', 'Cancelled', 'All'].map((s) => `<option value="${s}" ${state.approvals.status === s ? 'selected' : ''}>${s}</option>`).join('')}
        </select>
      </div>
      <div id="approvalsList" class="empty-state">Loading...</div>
    </div>`;
}

/** Checkbox handler for the requiredActions list - called inline since each checkbox toggles one value inside an array setting. */
function toggleRequiredAction(action, checked) {
  const list = new Set(currentValue('approvals.requiredActions') || []);
  if (checked) list.add(action);
  else list.delete(action);
  markDirty('approvals.requiredActions', Array.from(list));
}

async function loadApprovals() {
  state.approvals.loading = true;
  const listEl = document.getElementById('approvalsList');
  if (listEl) listEl.innerHTML = '<div class="empty-state">Loading...</div>';
  try {
    const result = await api(`/guilds/${state.guildId}/approvals?status=${encodeURIComponent(state.approvals.status)}&page=${state.approvals.page}`);
    state.approvals.requests = result.requests;
    state.approvals.total = result.total;
    state.approvals.totalPages = result.totalPages;
  } catch (err) {
    if (listEl) listEl.innerHTML = `<div class="empty-state">${escapeHtml(err.message)}</div>`;
    state.approvals.loading = false;
    return;
  }
  state.approvals.loading = false;
  renderApprovalsList();
}

function renderApprovalsList() {
  const listEl = document.getElementById('approvalsList');
  if (!listEl) return;
  const { requests } = state.approvals;
  if (!requests.length) {
    listEl.innerHTML = '<div class="empty-state">No requests found for this filter.</div>';
    return;
  }
  listEl.innerHTML = requests
    .map((r) => {
      const created = new Date(r.createdAt).toLocaleString();
      return `
      <div class="card" style="margin-bottom:10px;">
        <div class="row" style="grid-template-columns: 2fr 1fr;">
          <div>
            <div><strong>${escapeHtml(r.action)}</strong> &middot; target <code>${escapeHtml(r.targetId)}</code></div>
            <div class="hint">Requested by <code>${escapeHtml(r.moderatorId)}</code> on ${escapeHtml(created)}</div>
            <div class="hint">Reason: ${escapeHtml(r.reason || 'No reason provided')}</div>
            ${r.rejectReason ? `<div class="hint">Reject reason: ${escapeHtml(r.rejectReason)}</div>` : ''}
          </div>
          <div style="text-align:right;">
            <span class="badge ${r.status === 'Pending' ? 'offline' : 'online'}">${escapeHtml(r.status)}</span>
            ${
              r.status === 'Pending'
                ? `<div style="margin-top:10px; display:flex; gap:8px; justify-content:flex-end;">
                    <button class="btn" data-approve="${r._id}">Approve</button>
                    <button class="btn secondary" data-reject="${r._id}">Reject</button>
                  </div>`
                : ''
            }
          </div>
        </div>
      </div>`;
    })
    .join('');

  listEl.querySelectorAll('[data-approve]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      btn.disabled = true;
      try {
        await api(`/guilds/${state.guildId}/approvals/${btn.dataset.approve}/approve`, { method: 'POST' });
        toast('Request approved');
        loadApprovals();
      } catch (err) {
        toast(err.message, 'bad');
        btn.disabled = false;
      }
    });
  });
  listEl.querySelectorAll('[data-reject]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const reason = window.prompt('Reject reason (optional):') || '';
      btn.disabled = true;
      try {
        await api(`/guilds/${state.guildId}/approvals/${btn.dataset.reject}/reject`, { method: 'POST', body: JSON.stringify({ reason }) });
        toast('Request rejected');
        loadApprovals();
      } catch (err) {
        toast(err.message, 'bad');
        btn.disabled = false;
      }
    });
  });
}

function attachApprovalsHandlers() {
  const filter = document.getElementById('approvalsStatusFilter');
  if (filter) {
    filter.addEventListener('change', () => {
      state.approvals.status = filter.value;
      state.approvals.page = 1;
      loadApprovals();
    });
  }
  loadApprovals();
}

function renderLeveling() {
  return `
    <h1 class="page-title">Leveling</h1>
    <p class="page-subtitle">Reward active members with XP and levels.</p>
    <div class="card">
      <div class="toggle-row"><span>Leveling Enabled</span>${toggle('leveling.enabled')}</div>
      <div class="field"><label>Level-Up Announcement Channel</label><select data-path="leveling.announceChannelId">${channelOptions(currentValue('leveling.announceChannelId'))}</select></div>
      <div class="row">
        <div class="field"><label>XP per Message</label><input type="number" data-type="number" data-path="leveling.xpPerMessage" value="${currentValue('leveling.xpPerMessage') ?? 15}" /></div>
        <div class="field"><label>Cooldown (seconds)</label><input type="number" data-type="number" data-path="leveling.cooldownSeconds" value="${currentValue('leveling.cooldownSeconds') ?? 60}" /></div>
      </div>
      ${saveBar()}
    </div>`;
}

function renderTickets() {
  return `
    <h1 class="page-title">Tickets</h1>
    <p class="page-subtitle">Let members open private support tickets. Deploy the panel with <code>/ticketsetup panel</code>.</p>
    <div class="card">
      <div class="toggle-row"><span>Tickets Enabled</span>${toggle('tickets.enabled')}</div>
      <div class="field"><label>Ticket Category</label><select data-path="tickets.categoryId">${channelOptions(currentValue('tickets.categoryId'), true)}</select></div>
      <div class="field"><label>Support Role</label><select data-path="tickets.supportRoleId">${roleOptions(currentValue('tickets.supportRoleId'))}</select></div>
      <div class="field"><label>Log Channel</label><select data-path="tickets.logChannelId">${channelOptions(currentValue('tickets.logChannelId'))}</select></div>
      ${saveBar()}
    </div>`;
}

function renderSuggestions() {
  return `
    <h1 class="page-title">Suggestions</h1>
    <p class="page-subtitle">Members submit ideas with <code>/suggest</code>; the community votes.</p>
    <div class="card">
      <div class="toggle-row"><span>Suggestions Enabled</span>${toggle('suggestions.enabled')}</div>
      <div class="field"><label>Suggestions Channel</label><select data-path="suggestions.channelId">${channelOptions(currentValue('suggestions.channelId'))}</select></div>
      ${saveBar()}
    </div>`;
}

function renderMinecraft() {
  return `
    <h1 class="page-title">Minecraft Server</h1>
    <p class="page-subtitle">Powers the <code>/ip</code> command's live status embed.</p>
    <div class="card">
      <div class="row">
        <div class="field"><label>Display Name</label><input type="text" data-path="minecraft.name" value="${escapeAttr(currentValue('minecraft.name') || '')}" /></div>
        <div class="field"></div>
      </div>
      <div class="row">
        <div class="field"><label>Server IP</label><input type="text" data-path="minecraft.ip" value="${escapeAttr(currentValue('minecraft.ip') || '')}" /></div>
        <div class="field"><label>Port</label><input type="number" data-type="number" data-path="minecraft.port" value="${currentValue('minecraft.port') || 25565}" /></div>
      </div>
      ${saveBar()}
    </div>
    <div class="card">
      <h3>Live Status <button class="btn secondary" id="testMcBtn">Test Connection</button></h3>
      <div id="mcResult" class="empty-state">Click "Test Connection" to check the server right now.</div>
    </div>`;
}

function toggle(path) {
  const checked = currentValue(path) ? 'checked' : '';
  return `<label class="switch"><input type="checkbox" data-type="checkbox" data-path="${path}" ${checked} /><span class="slider"></span></label>`;
}

function attachMinecraftHandlers() {
  const btn = document.getElementById('testMcBtn');
  if (!btn) return;
  btn.addEventListener('click', async () => {
    const resultEl = document.getElementById('mcResult');
    resultEl.className = '';
    resultEl.textContent = 'Checking...';
    try {
      const status = await api(`/guilds/${state.guildId}/minecraft/status`);
      if (!status.online) {
        resultEl.innerHTML = `<div class="mc-status"><span class="badge offline">Offline</span><span>${escapeHtml(status.ip)}:${status.port}</span></div>`;
        return;
      }
      resultEl.innerHTML = `
        <div class="mc-status">
          ${status.favicon ? `<img src="${status.favicon}" alt="" />` : ''}
          <div>
            <span class="badge online">Online</span>
            <div style="margin-top:6px;">${status.players.online} / ${status.players.max} players &middot; ${status.version} &middot; ${status.ping}ms</div>
          </div>
        </div>`;
    } catch (err) {
      resultEl.textContent = err.message;
    }
  });
}

// ===========================================================================
// Task 16 - System Management Pages (Cases, Moderation Logs, Schedule,
// Temporary Roles, Config Backup). Every one of these reads/writes through
// the dashboard/routes/api.js endpoints added alongside this file, which
// in turn call the exact same services (caseService, scheduleService,
// tempRoleService, backupService, auditService) the Discord commands use -
// so nothing here can drift out of sync with /case, /schedule, /temprole
// or /configbackup, and no separate write path exists.
// ===========================================================================

/** Opens a centered modal with the given title/body HTML. Closing (X button or backdrop click) removes it. */
function openModal(title, bodyHtml) {
  closeModal();
  const overlay = document.createElement('div');
  overlay.className = 'modal-overlay';
  overlay.id = 'modalOverlay';
  overlay.innerHTML = `
    <div class="modal">
      <div class="modal-header">
        <h3>${escapeHtml(title)}</h3>
        <button class="modal-close" id="modalCloseBtn">&times;</button>
      </div>
      <div class="modal-body" id="modalBody">${bodyHtml}</div>
    </div>`;
  document.body.appendChild(overlay);
  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) closeModal();
  });
  document.getElementById('modalCloseBtn').addEventListener('click', closeModal);
  return overlay;
}

function closeModal() {
  const existing = document.getElementById('modalOverlay');
  if (existing) existing.remove();
}

function pagerHtml(prefix, page, totalPages) {
  return `
    <div class="pager">
      <button class="btn secondary" id="${prefix}Prev" ${page <= 1 ? 'disabled' : ''}>Prev</button>
      <span class="hint">Page ${page} / ${totalPages}</span>
      <button class="btn secondary" id="${prefix}Next" ${page >= totalPages ? 'disabled' : ''}>Next</button>
    </div>`;
}

function attachPagerHandlers(prefix, st, loadFn) {
  const prev = document.getElementById(`${prefix}Prev`);
  const next = document.getElementById(`${prefix}Next`);
  if (prev) prev.addEventListener('click', () => { st.page -= 1; loadFn(); });
  if (next) next.addEventListener('click', () => { st.page += 1; loadFn(); });
}

const CASE_STATUS_BADGE = { Active: 'online', Expired: 'neutral', Reverted: 'warn' };
const TASK_STATUS_BADGE = { Pending: 'online', Completed: 'neutral', Cancelled: 'warn', Failed: 'offline' };

function fmtDate(d) {
  return d ? new Date(d).toLocaleString() : '—';
}

// --------------------------- User Management ---------------------------
// Task 18. Search box over guild members + a read-only profile pulled
// from /guilds/:id/members/:userId, which itself just aggregates the Case,
// Warn, UserLevel and EconomyBalance records the Cases/Leveling/Economy
// pages already own. No separate state is written from this page.

const USER_STATUS_BADGE = { Member: 'online', 'Timed Out': 'warn', Banned: 'offline', 'Not in Server': 'neutral' };

function renderUsersPage() {
  const s = state.users;
  return `
    <h1 class="page-title">User Management</h1>
    <p class="page-subtitle">Search for a member by name or ID to view their roles, join date, standing, and activity across Cases, Warnings, Leveling and Economy.</p>
    <div class="card">
      <div class="filters-row">
        <input type="text" id="usersSearch" placeholder="Search by name or ID" value="${escapeAttr(s.q)}" />
      </div>
      <div id="usersList" class="empty-state">${s.q ? 'Loading...' : 'Start typing to search for a member.'}</div>
    </div>`;
}

async function loadUsersSearch() {
  const s = state.users;
  const listEl = document.getElementById('usersList');
  if (!s.q) {
    s.results = [];
    if (listEl) listEl.innerHTML = 'Start typing to search for a member.';
    return;
  }
  if (listEl) listEl.innerHTML = '<div class="empty-state">Loading...</div>';
  try {
    const result = await api(`/guilds/${state.guildId}/members/search?q=${encodeURIComponent(s.q)}`);
    s.results = result.results;
  } catch (err) {
    if (listEl) listEl.innerHTML = `<div class="empty-state">${escapeHtml(err.message)}</div>`;
    return;
  }
  renderUsersList();
}

function renderUsersList() {
  const listEl = document.getElementById('usersList');
  if (!listEl) return;
  const { results } = state.users;

  if (!results.length) {
    listEl.innerHTML = '<div class="empty-state">No members match this search.</div>';
    return;
  }

  listEl.innerHTML = results
    .map(
      (m) => `
      <div class="list-row">
        <div class="list-row-main">
          <div class="title">${escapeHtml(m.displayName)} <span class="hint">@${escapeHtml(m.username)}</span></div>
          <div class="hint">ID <code>${escapeHtml(m.id)}</code></div>
        </div>
        <div class="list-row-side">
          <div class="list-row-actions"><button class="btn secondary" data-user-view="${escapeAttr(m.id)}">View Profile</button></div>
        </div>
      </div>`
    )
    .join('');

  listEl.querySelectorAll('[data-user-view]').forEach((btn) => {
    btn.addEventListener('click', () => openUserProfile(btn.dataset.userView));
  });
}

function attachUsersHandlers() {
  const search = document.getElementById('usersSearch');
  let searchTimer = null;
  if (search) {
    search.addEventListener('input', () => {
      clearTimeout(searchTimer);
      searchTimer = setTimeout(() => {
        state.users.q = search.value.trim();
        loadUsersSearch();
      }, 350);
    });
  }
  if (state.users.q) loadUsersSearch();
}

/** Full read-only profile for one member - roles, join date, standing, and Cases/Warnings/Leveling/Economy, fetched fresh every open. */
async function openUserProfile(userId) {
  let p;
  try {
    p = await api(`/guilds/${state.guildId}/members/${userId}`);
  } catch (err) {
    return toast(err.message, 'bad');
  }

  const roles = p.member && p.member.roles.length ? p.member.roles.map((r) => escapeHtml(r.name)).join(', ') : 'None';
  const levelRow = p.level
    ? `<div><div class="kv-label">Level</div>Level ${p.level.level} &middot; ${p.level.xp} XP &middot; Rank #${p.level.rank}</div>`
    : '';
  const economyRow = p.economy ? `<div><div class="kv-label">Balance</div>${p.economy.balance}</div>` : '';

  const recent = p.recentCases.length
    ? p.recentCases.map((c) => `<div class="hint">#${c.caseId} &middot; ${escapeHtml(c.action)} &middot; ${escapeHtml(fmtDate(c.createdAt))}</div>`).join('')
    : '<div class="hint">No cases on record.</div>';

  openModal(p.tag, `
    <div class="kv-grid">
      <div><div class="kv-label">ID</div><code>${escapeHtml(p.id)}</code></div>
      <div><div class="kv-label">Status</div><span class="badge ${USER_STATUS_BADGE[p.status] || 'neutral'}">${escapeHtml(p.status)}</span></div>
      <div><div class="kv-label">Joined Server</div>${p.member ? escapeHtml(fmtDate(p.member.joinedAt)) : '—'}</div>
      <div><div class="kv-label">Account Created</div>${escapeHtml(fmtDate(p.createdAt))}</div>
      <div><div class="kv-label">Roles</div>${roles}</div>
      <div><div class="kv-label">Cases</div>${p.stats.cases}</div>
      <div><div class="kv-label">Warnings</div>${p.stats.warnings}</div>
      ${levelRow}
      ${economyRow}
    </div>
    <div class="field"><label>Recent Cases</label>${recent}</div>
  `);
}

// --------------------------- Cases ---------------------------

function renderCasesPage() {
  const s = state.cases;
  return `
    <h1 class="page-title">Cases</h1>
    <p class="page-subtitle">Search, filter, and manage every moderation case recorded for this server (the same records behind /case, /cases and /editcase).</p>
    <div class="card">
      <div class="filters-row">
        <input type="text" id="casesSearch" placeholder="Search case # / reason / notes" value="${escapeAttr(s.q)}" />
        <select id="casesActionFilter">
          <option value="">All actions</option>
          ${['ban', 'kick', 'timeout', 'warn', 'unban', 'softban'].map((a) => `<option value="${a}" ${s.action === a ? 'selected' : ''}>${a}</option>`).join('')}
        </select>
        <select id="casesStatusFilter">
          <option value="">All statuses</option>
          ${['Active', 'Expired', 'Reverted'].map((st) => `<option value="${st}" ${s.status === st ? 'selected' : ''}>${st}</option>`).join('')}
        </select>
      </div>
      <div id="casesList" class="empty-state">Loading...</div>
      <div id="casesPager"></div>
    </div>`;
}

async function loadCasesPage() {
  const s = state.cases;
  const listEl = document.getElementById('casesList');
  if (listEl) listEl.innerHTML = '<div class="empty-state">Loading...</div>';
  try {
    const params = new URLSearchParams({ page: String(s.page) });
    if (s.q) params.set('q', s.q);
    if (s.action) params.set('action', s.action);
    if (s.status) params.set('status', s.status);
    const result = await api(`/guilds/${state.guildId}/cases?${params.toString()}`);
    s.items = result.cases;
    s.total = result.total;
    s.totalPages = result.totalPages;
  } catch (err) {
    if (listEl) listEl.innerHTML = `<div class="empty-state">${escapeHtml(err.message)}</div>`;
    return;
  }
  renderCasesList();
}

function renderCasesList() {
  const listEl = document.getElementById('casesList');
  const pagerEl = document.getElementById('casesPager');
  if (!listEl) return;
  const { items, page, totalPages } = state.cases;

  if (!items.length) {
    listEl.innerHTML = '<div class="empty-state">No cases match this filter.</div>';
  } else {
    listEl.innerHTML = items
      .map(
        (c) => `
      <div class="list-row">
        <div class="list-row-main">
          <div class="title">#${c.caseId} &middot; ${escapeHtml(c.action)}</div>
          <div class="hint">Target <code>${escapeHtml(c.targetId)}</code> &middot; by <code>${escapeHtml(c.moderatorId)}</code> &middot; ${escapeHtml(fmtDate(c.createdAt))}</div>
          <div class="hint">${escapeHtml(c.reason || 'No reason provided')}</div>
        </div>
        <div class="list-row-side">
          <span class="badge ${CASE_STATUS_BADGE[c.status] || 'neutral'}">${escapeHtml(c.status)}</span>
          <div class="list-row-actions"><button class="btn secondary" data-case-view="${c.caseId}">Details</button></div>
        </div>
      </div>`
      )
      .join('');
  }

  if (pagerEl) pagerEl.innerHTML = pagerHtml('cases', page, totalPages);
  attachPagerHandlers('cases', state.cases, loadCasesPage);

  listEl.querySelectorAll('[data-case-view]').forEach((btn) => {
    btn.addEventListener('click', () => openCaseDetail(Number(btn.dataset.caseView)));
  });
}

function attachCasesHandlers() {
  const search = document.getElementById('casesSearch');
  const actionFilter = document.getElementById('casesActionFilter');
  const statusFilter = document.getElementById('casesStatusFilter');
  let searchTimer = null;
  if (search) {
    search.addEventListener('input', () => {
      clearTimeout(searchTimer);
      searchTimer = setTimeout(() => {
        state.cases.q = search.value;
        state.cases.page = 1;
        loadCasesPage();
      }, 350);
    });
  }
  if (actionFilter) {
    actionFilter.addEventListener('change', () => {
      state.cases.action = actionFilter.value;
      state.cases.page = 1;
      loadCasesPage();
    });
  }
  if (statusFilter) {
    statusFilter.addEventListener('change', () => {
      state.cases.status = statusFilter.value;
      state.cases.page = 1;
      loadCasesPage();
    });
  }
  loadCasesPage();
}

/** Full detail + edit (reason/notes) + revert modal for one Case, fetched fresh so it always reflects the latest state. */
async function openCaseDetail(caseId) {
  let c;
  try {
    c = await api(`/guilds/${state.guildId}/cases/${caseId}`);
  } catch (err) {
    return toast(err.message, 'bad');
  }

  const revertedInfo = c.status !== 'Active'
    ? `<div class="hint">${escapeHtml(c.status)} ${c.revertedBy ? `by <code>${escapeHtml(c.revertedBy)}</code>` : ''}${c.revertReason ? ` — ${escapeHtml(c.revertReason)}` : ''}</div>`
    : '';

  openModal(`Case #${c.caseId}`, `
    <div class="kv-grid">
      <div><div class="kv-label">Action</div>${escapeHtml(c.action)}</div>
      <div><div class="kv-label">Status</div><span class="badge ${CASE_STATUS_BADGE[c.status] || 'neutral'}">${escapeHtml(c.status)}</span></div>
      <div><div class="kv-label">Target</div><code>${escapeHtml(c.targetId)}</code></div>
      <div><div class="kv-label">Moderator</div><code>${escapeHtml(c.moderatorId)}</code></div>
      <div><div class="kv-label">Created</div>${escapeHtml(fmtDate(c.createdAt))}</div>
      <div><div class="kv-label">Duration</div>${c.durationMinutes ? `${c.durationMinutes} min` : '—'}</div>
    </div>
    ${revertedInfo}
    <div class="field"><label>Reason</label><textarea id="caseEditReason">${escapeHtml(c.reason || '')}</textarea></div>
    <div class="field"><label>Notes</label><textarea id="caseEditNotes">${escapeHtml(c.notes || '')}</textarea></div>
    <div class="modal-footer" style="padding:0; margin-top:6px;">
      ${c.status === 'Active' ? `<button class="btn secondary" id="caseRevertBtn">Revert Case</button>` : ''}
      <button class="btn" id="caseSaveBtn">Save Changes</button>
    </div>
  `);

  document.getElementById('caseSaveBtn').addEventListener('click', async () => {
    const reason = document.getElementById('caseEditReason').value;
    const notes = document.getElementById('caseEditNotes').value;
    try {
      await api(`/guilds/${state.guildId}/cases/${caseId}`, { method: 'PATCH', body: JSON.stringify({ reason, notes }) });
      toast('Case updated');
      closeModal();
      loadCasesPage();
    } catch (err) {
      toast(err.message, 'bad');
    }
  });

  const revertBtn = document.getElementById('caseRevertBtn');
  if (revertBtn) {
    revertBtn.addEventListener('click', async () => {
      const reason = window.prompt('Revert reason (optional):') || '';
      try {
        await api(`/guilds/${state.guildId}/cases/${caseId}/revert`, { method: 'POST', body: JSON.stringify({ reason }) });
        toast('Case reverted');
        closeModal();
        loadCasesPage();
      } catch (err) {
        toast(err.message, 'bad');
      }
    });
  }
}

// --------------------------- Moderation Logs (read-only) ---------------------------

function renderModlogsPage() {
  const s = state.modlogs;
  return `
    <h1 class="page-title">Moderation Logs</h1>
    <p class="page-subtitle">A read-only audit stream over the same case history, filterable by moderator, member, action and date range - the dashboard view of /modhistory.</p>
    <div class="card">
      <div class="filters-row">
        <input type="text" id="modlogsModerator" placeholder="Filter by moderator ID" value="${escapeAttr(s.moderatorId)}" />
        <input type="text" id="modlogsTarget" placeholder="Filter by target ID" value="${escapeAttr(s.targetId)}" />
        <select id="modlogsAction">
          <option value="">All actions</option>
          ${['ban', 'kick', 'timeout', 'warn', 'unban', 'softban'].map((a) => `<option value="${a}" ${s.action === a ? 'selected' : ''}>${a}</option>`).join('')}
        </select>
        <select id="modlogsRange">
          ${[['today', 'Today'], ['7d', 'Last 7 days'], ['30d', 'Last 30 days'], ['all', 'All time']].map(([v, l]) => `<option value="${v}" ${s.range === v ? 'selected' : ''}>${l}</option>`).join('')}
        </select>
        <select id="modlogsSort">
          ${[['newest', 'Newest first'], ['oldest', 'Oldest first'], ['action', 'By action']].map(([v, l]) => `<option value="${v}" ${s.sort === v ? 'selected' : ''}>${l}</option>`).join('')}
        </select>
      </div>
      <div id="modlogsList" class="empty-state">Loading...</div>
      <div id="modlogsPager"></div>
    </div>`;
}

async function loadModlogsPage() {
  const s = state.modlogs;
  const listEl = document.getElementById('modlogsList');
  if (listEl) listEl.innerHTML = '<div class="empty-state">Loading...</div>';
  try {
    const params = new URLSearchParams({ page: String(s.page), range: s.range, sort: s.sort });
    if (s.moderatorId) params.set('moderatorId', s.moderatorId);
    if (s.targetId) params.set('targetId', s.targetId);
    if (s.action) params.set('action', s.action);
    const result = await api(`/guilds/${state.guildId}/modlogs?${params.toString()}`);
    s.items = result.cases;
    s.total = result.total;
    s.totalPages = result.totalPages;
  } catch (err) {
    if (listEl) listEl.innerHTML = `<div class="empty-state">${escapeHtml(err.message)}</div>`;
    return;
  }
  renderModlogsList();
}

function renderModlogsList() {
  const listEl = document.getElementById('modlogsList');
  const pagerEl = document.getElementById('modlogsPager');
  if (!listEl) return;
  const { items, page, totalPages } = state.modlogs;

  if (!items.length) {
    listEl.innerHTML = '<div class="empty-state">No log entries match this filter.</div>';
  } else {
    listEl.innerHTML = items
      .map(
        (c) => `
      <div class="list-row">
        <div class="list-row-main">
          <div class="title">#${c.caseId} &middot; ${escapeHtml(c.action)}</div>
          <div class="hint">Target <code>${escapeHtml(c.targetId)}</code> &middot; by <code>${escapeHtml(c.moderatorId)}</code> &middot; ${escapeHtml(fmtDate(c.createdAt))}</div>
          <div class="hint">${escapeHtml(c.reason || 'No reason provided')}</div>
        </div>
        <div class="list-row-side">
          <span class="badge ${CASE_STATUS_BADGE[c.status] || 'neutral'}">${escapeHtml(c.status)}</span>
          <div class="list-row-actions"><button class="btn secondary" data-log-view="${c.caseId}">Details</button></div>
        </div>
      </div>`
      )
      .join('');
  }

  if (pagerEl) pagerEl.innerHTML = pagerHtml('modlogs', page, totalPages);
  attachPagerHandlers('modlogs', state.modlogs, loadModlogsPage);

  listEl.querySelectorAll('[data-log-view]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const c = state.modlogs.items.find((item) => item.caseId === Number(btn.dataset.logView));
      if (c) openLogDetail(c);
    });
  });
}

/** Read-only summary modal - Moderation Logs is a viewer, not an editor. Use the Cases page to edit or revert. */
function openLogDetail(c) {
  openModal(`Case #${c.caseId} (log entry)`, `
    <div class="kv-grid">
      <div><div class="kv-label">Action</div>${escapeHtml(c.action)}</div>
      <div><div class="kv-label">Status</div><span class="badge ${CASE_STATUS_BADGE[c.status] || 'neutral'}">${escapeHtml(c.status)}</span></div>
      <div><div class="kv-label">Target</div><code>${escapeHtml(c.targetId)}</code></div>
      <div><div class="kv-label">Moderator</div><code>${escapeHtml(c.moderatorId)}</code></div>
      <div><div class="kv-label">Created</div>${escapeHtml(fmtDate(c.createdAt))}</div>
      <div><div class="kv-label">Duration</div>${c.durationMinutes ? `${c.durationMinutes} min` : '—'}</div>
    </div>
    <div class="field"><label>Reason</label><div class="hint">${escapeHtml(c.reason || 'No reason provided')}</div></div>
    ${c.notes ? `<div class="field"><label>Notes</label><div class="hint">${escapeHtml(c.notes)}</div></div>` : ''}
    <p class="hint">To edit or revert this case, use the Cases page.</p>
  `);
}

function attachModlogsHandlers() {
  const moderator = document.getElementById('modlogsModerator');
  const target = document.getElementById('modlogsTarget');
  const action = document.getElementById('modlogsAction');
  const range = document.getElementById('modlogsRange');
  const sort = document.getElementById('modlogsSort');
  let debounce = null;
  const debouncedReload = () => {
    clearTimeout(debounce);
    debounce = setTimeout(() => { state.modlogs.page = 1; loadModlogsPage(); }, 350);
  };
  if (moderator) moderator.addEventListener('input', () => { state.modlogs.moderatorId = moderator.value; debouncedReload(); });
  if (target) target.addEventListener('input', () => { state.modlogs.targetId = target.value; debouncedReload(); });
  if (action) action.addEventListener('change', () => { state.modlogs.action = action.value; state.modlogs.page = 1; loadModlogsPage(); });
  if (range) range.addEventListener('change', () => { state.modlogs.range = range.value; state.modlogs.page = 1; loadModlogsPage(); });
  if (sort) sort.addEventListener('change', () => { state.modlogs.sort = sort.value; state.modlogs.page = 1; loadModlogsPage(); });
  loadModlogsPage();
}

// --------------------------- Schedule ---------------------------

function renderSchedulePage() {
  const s = state.schedule;
  return `
    <h1 class="page-title">Schedule</h1>
    <p class="page-subtitle">Delayed moderation actions queued via /schedule - ban, kick, timeout, unban and scheduled messages.</p>
    <div class="card">
      <div class="filters-row">
        <input type="text" id="scheduleTarget" placeholder="Search by target user ID" value="${escapeAttr(s.q)}" />
        <select id="scheduleActionFilter">
          <option value="">All actions</option>
          ${['ban', 'kick', 'timeout', 'unban', 'message'].map((a) => `<option value="${a}" ${s.action === a ? 'selected' : ''}>${a}</option>`).join('')}
        </select>
        <select id="scheduleStatusFilter">
          ${['Pending', 'Completed', 'Cancelled', 'Failed', ''].map((st) => `<option value="${st}" ${s.status === st ? 'selected' : ''}>${st || 'All statuses'}</option>`).join('')}
        </select>
      </div>
      <div id="scheduleList" class="empty-state">Loading...</div>
      <div id="schedulePager"></div>
    </div>`;
}

async function loadSchedulePage() {
  const s = state.schedule;
  const listEl = document.getElementById('scheduleList');
  if (listEl) listEl.innerHTML = '<div class="empty-state">Loading...</div>';
  try {
    const params = new URLSearchParams({ page: String(s.page) });
    if (s.status) params.set('status', s.status);
    if (s.action) params.set('action', s.action);
    if (s.q) params.set('targetId', s.q);
    const result = await api(`/guilds/${state.guildId}/schedule?${params.toString()}`);
    s.items = result.tasks;
    s.total = result.total;
    s.totalPages = result.totalPages;
  } catch (err) {
    if (listEl) listEl.innerHTML = `<div class="empty-state">${escapeHtml(err.message)}</div>`;
    return;
  }
  renderScheduleList();
}

function renderScheduleList() {
  const listEl = document.getElementById('scheduleList');
  const pagerEl = document.getElementById('schedulePager');
  if (!listEl) return;
  const { items, page, totalPages } = state.schedule;

  if (!items.length) {
    listEl.innerHTML = '<div class="empty-state">No scheduled tasks match this filter.</div>';
  } else {
    listEl.innerHTML = items
      .map(
        (t) => `
      <div class="list-row">
        <div class="list-row-main">
          <div class="title">${escapeHtml(t.action)} &middot; target <code>${escapeHtml(t.targetId)}</code></div>
          <div class="hint">By <code>${escapeHtml(t.moderatorId)}</code> &middot; runs ${escapeHtml(fmtDate(t.executeAt))}${t.caseId ? ` &middot; Case #${t.caseId}` : ''}</div>
          <div class="hint">${escapeHtml(t.reason || 'No reason provided')}</div>
        </div>
        <div class="list-row-side">
          <span class="badge ${TASK_STATUS_BADGE[t.status] || 'neutral'}">${escapeHtml(t.status)}</span>
          <div class="list-row-actions">
            <button class="btn secondary" data-schedule-view="${t._id}">Details</button>
            ${t.status === 'Pending' ? `<button class="btn secondary" data-schedule-cancel="${t._id}">Cancel</button>` : ''}
          </div>
        </div>
      </div>`
      )
      .join('');
  }

  if (pagerEl) pagerEl.innerHTML = pagerHtml('schedule', page, totalPages);
  attachPagerHandlers('schedule', state.schedule, loadSchedulePage);

  listEl.querySelectorAll('[data-schedule-view]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const t = state.schedule.items.find((item) => item._id === btn.dataset.scheduleView);
      if (t) openScheduleDetail(t);
    });
  });
  listEl.querySelectorAll('[data-schedule-cancel]').forEach((btn) => {
    btn.addEventListener('click', () => cancelScheduledTask(btn.dataset.scheduleCancel));
  });
}

function scheduleDetailBody(t) {
  return `
    <div class="kv-grid">
      <div><div class="kv-label">Action</div>${escapeHtml(t.action)}</div>
      <div><div class="kv-label">Status</div><span class="badge ${TASK_STATUS_BADGE[t.status] || 'neutral'}">${escapeHtml(t.status)}</span></div>
      <div><div class="kv-label">Target</div><code>${escapeHtml(t.targetId)}</code></div>
      <div><div class="kv-label">Moderator</div><code>${escapeHtml(t.moderatorId)}</code></div>
      <div><div class="kv-label">Execute At</div>${escapeHtml(fmtDate(t.executeAt))}</div>
      <div><div class="kv-label">Attempts</div>${t.attempts ?? 0}</div>
      ${t.durationMinutes ? `<div><div class="kv-label">Duration</div>${t.durationMinutes} min</div>` : ''}
      ${t.caseId ? `<div><div class="kv-label">Resulting Case</div>#${t.caseId}</div>` : ''}
    </div>
    <div class="field"><label>Reason / Content</label><div class="hint">${escapeHtml(t.reason || '—')}</div></div>
    ${t.lastError ? `<div class="field"><label>Last Error</label><div class="hint">${escapeHtml(t.lastError)}</div></div>` : ''}
  `;
}

function openScheduleDetail(t) {
  const overlay = openModal(`Scheduled ${t.action}`, `
    ${scheduleDetailBody(t)}
    ${t.status === 'Pending' ? `<div class="modal-footer" style="padding:0; margin-top:6px;"><button class="btn secondary" id="scheduleDetailCancelBtn">Cancel Task</button></div>` : ''}
  `);
  const cancelBtn = overlay.querySelector('#scheduleDetailCancelBtn');
  if (cancelBtn) cancelBtn.addEventListener('click', () => cancelScheduledTask(t._id, true));
}

async function cancelScheduledTask(taskId, fromModal = false) {
  try {
    await api(`/guilds/${state.guildId}/schedule/${taskId}/cancel`, { method: 'POST' });
    toast('Task cancelled');
    if (fromModal) closeModal();
    loadSchedulePage();
  } catch (err) {
    toast(err.message, 'bad');
  }
}

function attachScheduleHandlers() {
  const search = document.getElementById('scheduleTarget');
  const actionFilter = document.getElementById('scheduleActionFilter');
  const statusFilter = document.getElementById('scheduleStatusFilter');
  let searchTimer = null;
  if (search) {
    search.addEventListener('input', () => {
      clearTimeout(searchTimer);
      searchTimer = setTimeout(() => { state.schedule.q = search.value; state.schedule.page = 1; loadSchedulePage(); }, 350);
    });
  }
  if (actionFilter) actionFilter.addEventListener('change', () => { state.schedule.action = actionFilter.value; state.schedule.page = 1; loadSchedulePage(); });
  if (statusFilter) statusFilter.addEventListener('change', () => { state.schedule.status = statusFilter.value; state.schedule.page = 1; loadSchedulePage(); });
  loadSchedulePage();
}

// --------------------------- Temporary Roles ---------------------------

function renderTemprolesPage() {
  const s = state.temproles;
  return `
    <h1 class="page-title">Temporary Roles</h1>
    <p class="page-subtitle">Roles granted via /temprole that are automatically removed later. Extend, make permanent, or remove early.</p>
    <div class="card">
      <div class="filters-row">
        <input type="text" id="temprolesTarget" placeholder="Search by member user ID" value="${escapeAttr(s.q)}" />
        <select id="temprolesStatusFilter">
          ${['Pending', 'Completed', 'Cancelled', 'Failed', ''].map((st) => `<option value="${st}" ${s.status === st ? 'selected' : ''}>${st || 'All statuses'}</option>`).join('')}
        </select>
      </div>
      <div id="temprolesList" class="empty-state">Loading...</div>
      <div id="temprolesPager"></div>
    </div>`;
}

async function loadTemprolesPage() {
  const s = state.temproles;
  const listEl = document.getElementById('temprolesList');
  if (listEl) listEl.innerHTML = '<div class="empty-state">Loading...</div>';
  try {
    const params = new URLSearchParams({ page: String(s.page) });
    if (s.status) params.set('status', s.status);
    if (s.q) params.set('targetId', s.q);
    const result = await api(`/guilds/${state.guildId}/temproles?${params.toString()}`);
    s.items = result.tasks;
    s.total = result.total;
    s.totalPages = result.totalPages;
  } catch (err) {
    if (listEl) listEl.innerHTML = `<div class="empty-state">${escapeHtml(err.message)}</div>`;
    return;
  }
  renderTemprolesList();
}

function temproleRowActions(t) {
  if (t.status !== 'Pending') return '';
  return `
    <button class="btn secondary" data-temprole-extend="${t._id}">Extend</button>
    <button class="btn secondary" data-temprole-permanent="${t._id}">Make Permanent</button>
    <button class="btn secondary" data-temprole-remove="${t._id}">Remove Now</button>`;
}

function renderTemprolesList() {
  const listEl = document.getElementById('temprolesList');
  const pagerEl = document.getElementById('temprolesPager');
  if (!listEl) return;
  const { items, page, totalPages } = state.temproles;

  if (!items.length) {
    listEl.innerHTML = '<div class="empty-state">No temporary roles match this filter.</div>';
  } else {
    listEl.innerHTML = items
      .map(
        (t) => `
      <div class="list-row">
        <div class="list-row-main">
          <div class="title">Role <code>${escapeHtml(t.roleId)}</code> on <code>${escapeHtml(t.targetId)}</code></div>
          <div class="hint">Granted by <code>${escapeHtml(t.moderatorId)}</code> &middot; expires ${escapeHtml(fmtDate(t.executeAt))}</div>
          <div class="hint">${escapeHtml(t.reason || 'No reason provided')}</div>
        </div>
        <div class="list-row-side">
          <span class="badge ${TASK_STATUS_BADGE[t.status] || 'neutral'}">${escapeHtml(t.status)}</span>
          <div class="list-row-actions">
            <button class="btn secondary" data-temprole-view="${t._id}">Details</button>
            ${temproleRowActions(t)}
          </div>
        </div>
      </div>`
      )
      .join('');
  }

  if (pagerEl) pagerEl.innerHTML = pagerHtml('temproles', page, totalPages);
  attachPagerHandlers('temproles', state.temproles, loadTemprolesPage);

  listEl.querySelectorAll('[data-temprole-view]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const t = state.temproles.items.find((item) => item._id === btn.dataset.temproleView);
      if (t) openTemproleDetail(t);
    });
  });
  listEl.querySelectorAll('[data-temprole-extend]').forEach((btn) => {
    btn.addEventListener('click', () => extendTemprole(btn.dataset.temproleExtend));
  });
  listEl.querySelectorAll('[data-temprole-permanent]').forEach((btn) => {
    btn.addEventListener('click', () => temproleMakePermanent(btn.dataset.temprolePermanent));
  });
  listEl.querySelectorAll('[data-temprole-remove]').forEach((btn) => {
    btn.addEventListener('click', () => temproleRemoveNow(btn.dataset.temproleRemove));
  });
}

function openTemproleDetail(t) {
  const overlay = openModal('Temporary Role', `
    <div class="kv-grid">
      <div><div class="kv-label">Role</div><code>${escapeHtml(t.roleId)}</code></div>
      <div><div class="kv-label">Status</div><span class="badge ${TASK_STATUS_BADGE[t.status] || 'neutral'}">${escapeHtml(t.status)}</span></div>
      <div><div class="kv-label">Member</div><code>${escapeHtml(t.targetId)}</code></div>
      <div><div class="kv-label">Granted By</div><code>${escapeHtml(t.moderatorId)}</code></div>
      <div><div class="kv-label">Expires</div>${escapeHtml(fmtDate(t.executeAt))}</div>
    </div>
    <div class="field"><label>Reason</label><div class="hint">${escapeHtml(t.reason || '—')}</div></div>
    ${t.status === 'Pending' ? `<div class="modal-footer" style="padding:0; margin-top:6px;">${temproleRowActions(t)}</div>` : ''}
  `);
  overlay.querySelectorAll('[data-temprole-extend]').forEach((btn) => btn.addEventListener('click', () => extendTemprole(btn.dataset.temproleExtend, true)));
  overlay.querySelectorAll('[data-temprole-permanent]').forEach((btn) => btn.addEventListener('click', () => temproleMakePermanent(btn.dataset.temprolePermanent, true)));
  overlay.querySelectorAll('[data-temprole-remove]').forEach((btn) => btn.addEventListener('click', () => temproleRemoveNow(btn.dataset.temproleRemove, true)));
}

async function extendTemprole(taskId, fromModal = false) {
  const minutesStr = window.prompt('Extend by how many minutes?', '60');
  if (!minutesStr) return;
  const minutes = Number.parseInt(minutesStr, 10);
  if (!Number.isInteger(minutes) || minutes <= 0) return toast('Enter a valid number of minutes', 'bad');
  try {
    await api(`/guilds/${state.guildId}/temproles/${taskId}/extend`, { method: 'POST', body: JSON.stringify({ minutes }) });
    toast('Temp role extended');
    if (fromModal) closeModal();
    loadTemprolesPage();
  } catch (err) {
    toast(err.message, 'bad');
  }
}

async function temproleMakePermanent(taskId, fromModal = false) {
  try {
    await api(`/guilds/${state.guildId}/temproles/${taskId}/permanent`, { method: 'POST' });
    toast('Role is now permanent');
    if (fromModal) closeModal();
    loadTemprolesPage();
  } catch (err) {
    toast(err.message, 'bad');
  }
}

async function temproleRemoveNow(taskId, fromModal = false) {
  if (!window.confirm('Remove this role from the member right now?')) return;
  try {
    await api(`/guilds/${state.guildId}/temproles/${taskId}/remove`, { method: 'POST' });
    toast('Role removed');
    if (fromModal) closeModal();
    loadTemprolesPage();
  } catch (err) {
    toast(err.message, 'bad');
  }
}

function attachTemprolesHandlers() {
  const search = document.getElementById('temprolesTarget');
  const statusFilter = document.getElementById('temprolesStatusFilter');
  let searchTimer = null;
  if (search) {
    search.addEventListener('input', () => {
      clearTimeout(searchTimer);
      searchTimer = setTimeout(() => { state.temproles.q = search.value; state.temproles.page = 1; loadTemprolesPage(); }, 350);
    });
  }
  if (statusFilter) statusFilter.addEventListener('change', () => { state.temproles.status = statusFilter.value; state.temproles.page = 1; loadTemprolesPage(); });
  loadTemprolesPage();
}

// --------------------------- Config Backup ---------------------------

function renderBackupsPage() {
  const s = state.backups;
  return `
    <h1 class="page-title">Config Backup</h1>
    <p class="page-subtitle">Point-in-time snapshots of this server's bot settings (the same records behind /configbackup). Per-user data (economy, XP) is never included.</p>
    <div class="card">
      <div class="filters-row">
        <input type="text" id="backupsSearch" placeholder="Search by label" value="${escapeAttr(s.q)}" />
        <button class="btn" id="backupsCreateBtn">+ Create Backup</button>
      </div>
      <div id="backupsList" class="empty-state">Loading...</div>
      <div id="backupsPager"></div>
    </div>`;
}

async function loadBackupsPage() {
  const s = state.backups;
  const listEl = document.getElementById('backupsList');
  if (listEl) listEl.innerHTML = '<div class="empty-state">Loading...</div>';
  try {
    const params = new URLSearchParams({ page: String(s.page) });
    if (s.q) params.set('q', s.q);
    const result = await api(`/guilds/${state.guildId}/backups?${params.toString()}`);
    s.items = result.backups;
    s.total = result.total;
    s.totalPages = result.totalPages;
  } catch (err) {
    if (listEl) listEl.innerHTML = `<div class="empty-state">${escapeHtml(err.message)}</div>`;
    return;
  }
  renderBackupsList();
}

function renderBackupsList() {
  const listEl = document.getElementById('backupsList');
  const pagerEl = document.getElementById('backupsPager');
  if (!listEl) return;
  const { items, page, totalPages } = state.backups;

  if (!items.length) {
    listEl.innerHTML = '<div class="empty-state">No settings backups saved yet.</div>';
  } else {
    listEl.innerHTML = items
      .map(
        (b) => `
      <div class="list-row">
        <div class="list-row-main">
          <div class="title">${escapeHtml(b.label || 'Unnamed backup')}</div>
          <div class="hint">Created by <code>${escapeHtml(b.createdBy)}</code> &middot; ${escapeHtml(fmtDate(b.createdAt))}</div>
        </div>
        <div class="list-row-side">
          <div class="list-row-actions">
            <button class="btn secondary" data-backup-view="${b._id}">Details</button>
            <button class="btn secondary" data-backup-restore="${b._id}">Restore</button>
            <button class="btn secondary" data-backup-delete="${b._id}">Delete</button>
          </div>
        </div>
      </div>`
      )
      .join('');
  }

  if (pagerEl) pagerEl.innerHTML = pagerHtml('backups', page, totalPages);
  attachPagerHandlers('backups', state.backups, loadBackupsPage);

  listEl.querySelectorAll('[data-backup-view]').forEach((btn) => {
    btn.addEventListener('click', () => openBackupDetail(btn.dataset.backupView));
  });
  listEl.querySelectorAll('[data-backup-restore]').forEach((btn) => {
    btn.addEventListener('click', () => restoreBackup(btn.dataset.backupRestore));
  });
  listEl.querySelectorAll('[data-backup-delete]').forEach((btn) => {
    btn.addEventListener('click', () => deleteBackup(btn.dataset.backupDelete));
  });
}

async function openBackupDetail(backupId) {
  let b;
  try {
    b = await api(`/guilds/${state.guildId}/backups/${backupId}`);
  } catch (err) {
    return toast(err.message, 'bad');
  }
  const overlay = openModal(b.label || 'Unnamed backup', `
    <div class="kv-grid">
      <div><div class="kv-label">Server Name (at backup time)</div>${escapeHtml(b.guildName)}</div>
      <div><div class="kv-label">Created By</div><code>${escapeHtml(b.createdBy)}</code></div>
      <div><div class="kv-label">Created</div>${escapeHtml(fmtDate(b.createdAt))}</div>
      <div><div class="kv-label">Schema Version</div>${b.schemaVersion}</div>
    </div>
    <div class="field"><label>Snapshot Contents</label><pre class="settings-dump">${escapeHtml(JSON.stringify(b.settings, null, 2))}</pre></div>
    <div class="modal-footer" style="padding:0; margin-top:6px;">
      <button class="btn secondary" id="backupDetailDelete">Delete</button>
      <button class="btn" id="backupDetailRestore">Restore</button>
    </div>
  `);
  overlay.querySelector('#backupDetailRestore').addEventListener('click', () => restoreBackup(backupId, true));
  overlay.querySelector('#backupDetailDelete').addEventListener('click', () => deleteBackup(backupId, true));
}

async function restoreBackup(backupId, fromModal = false) {
  if (!window.confirm('This will overwrite the current bot settings for this server with this backup. Continue?')) return;
  const resetUserData = window.confirm('Also permanently wipe economy balances and XP/levels for this server? (OK = yes, Cancel = no)');
  try {
    await api(`/guilds/${state.guildId}/backups/${backupId}/restore`, { method: 'POST', body: JSON.stringify({ resetUserData }) });
    toast('Settings restored from backup');
    if (fromModal) closeModal();
    // The just-restored config affects every other settings page - reload it so the rest of the dashboard reflects it.
    state.config = await api(`/guilds/${state.guildId}/config`);
  } catch (err) {
    toast(err.message, 'bad');
  }
}

async function deleteBackup(backupId, fromModal = false) {
  if (!window.confirm('Delete this backup permanently? This cannot be undone.')) return;
  try {
    await api(`/guilds/${state.guildId}/backups/${backupId}`, { method: 'DELETE' });
    toast('Backup deleted');
    if (fromModal) closeModal();
    loadBackupsPage();
  } catch (err) {
    toast(err.message, 'bad');
  }
}

function attachBackupsHandlers() {
  const search = document.getElementById('backupsSearch');
  const createBtn = document.getElementById('backupsCreateBtn');
  let searchTimer = null;
  if (search) {
    search.addEventListener('input', () => {
      clearTimeout(searchTimer);
      searchTimer = setTimeout(() => { state.backups.q = search.value; state.backups.page = 1; loadBackupsPage(); }, 350);
    });
  }
  if (createBtn) {
    createBtn.addEventListener('click', async () => {
      const label = window.prompt('Optional label for this backup:') || '';
      createBtn.disabled = true;
      try {
        await api(`/guilds/${state.guildId}/backups`, { method: 'POST', body: JSON.stringify({ label }) });
        toast('Backup created');
        state.backups.page = 1;
        loadBackupsPage();
      } catch (err) {
        toast(err.message, 'bad');
      } finally {
        createBtn.disabled = false;
      }
    });
  }
  loadBackupsPage();
}

function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
function escapeAttr(str) {
  return escapeHtml(str);
}

boot();
