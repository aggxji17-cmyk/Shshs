const path = require("path");
const router = require("express").Router();
const { isAuth, checkGuildAccess, checkMaintenance } = require("./middleware");
const fs = require("fs");
/* ========== Helper: Load route if file exists ========== */
function tryRoute(routePath) {
  try {
    return require(routePath);
  } catch (e) {
    if (e.code === "MODULE_NOT_FOUND") return null;
    throw e; // Re-throw real errors (syntax errors, etc.)
  }
}

const auth = tryRoute("./routes/auth");
if (auth) router.use(auth);

/* ========== Premium & Payments ========== */
const premium = tryRoute("./routes/premium");
if (premium) router.use("/api/premium", premium);

/* ========== Guild Middleware ========== */
router.use("/guild/:id", isAuth, checkMaintenance, checkGuildAccess);
router.use("/api/guild/:id", isAuth, checkMaintenance, checkGuildAccess);

/* ========== Guild Info ========== */
const guild = tryRoute("./routes/guild");
if (guild) router.use(guild);

/* ========== Admin ========== */
const adminRoutes = tryRoute("./adminRoutes");
if (adminRoutes) router.use("/admin", isAuth, adminRoutes);

/* ========== Feature Routes ========== */
const featureRoutes = [
  "./routes/welcome",
  "./routes/leave",
  "./routes/embed",
  "./routes/logs",
  "./routes/autorole",
  "./routes/sticky",
  "./routes/automod",
  "./routes/antinuke",
  "./routes/youtube",
  "./routes/twitch",
  "./routes/reactionrole",
  "./routes/rolemenu",
  "./routes/music",
  "./routes/ticket",
  "./routes/leveling",
  "./routes/stats",
  "./routes/transcript",
  "./routes/joinping",
  "./routes/applications",
  "./routes/economy",
  "./routes/backups",
  "./routes/engagement",
  "./routes/verification"
];
for (const routePath of featureRoutes) {
  const route = tryRoute(routePath);
  if (route) router.use(route);
}

/* ========== Addon Routes ========== */
const addonsPath = path.join(__dirname, "..", "Addons");
if (fs.existsSync(addonsPath)) {
  const addons = fs.readdirSync(addonsPath).filter(f => fs.statSync(path.join(addonsPath, f)).isDirectory());
  for (const addon of addons) {
    const addonRoutesPath = path.join(addonsPath, addon, "Dashboard", "routes");
    if (fs.existsSync(addonRoutesPath)) {
      const routeFiles = fs.readdirSync(addonRoutesPath).filter(f => f.endsWith(".js"));
      for (const file of routeFiles) {
        try {
          const route = require(path.join(addonRoutesPath, file));
          router.use(route);
        } catch (err) {
          console.error(`[ADDON_DASHBOARD] Failed to load route ${file} from ${addon}:`, err);
        }
      }
    }
  }
}

/* ========== 404 Handler (Must Be Last) ========== */
router.get("*", (req, res) => {
  res.status(404).sendFile(path.join(__dirname, "views", "404.html"));
});

module.exports = router;