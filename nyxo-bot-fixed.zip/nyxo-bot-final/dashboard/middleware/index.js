// Compatibility layer for the ported legacy (v2.0.8) dashboard routes
// under dashboard/routes/*.js and dashboard/adminRoutes.js.
//
// Those routes were written against an older dashboard that kept the
// Discord client on `req.client` and exposed a single `../middleware`
// module with `isAuth` / `checkPremium` / `checkMaintenance`. The
// current dashboard (dashboard/middleware/auth.js) uses
// `ensureAuthenticated` / `ensureGuildManager` instead and never
// attaches `req.client`. This file bridges the two so the legacy
// routes work as-is, using the same session + Discord-permission model
// as the live dashboard.
const { isGuildManager } = require('../../src/utils/permissions');
const { getGuildConfig } = require('../../src/utils/resolveGuildSettings');
const Maintenance = require('../../src/database/models/maintenanceSchema');
const PremiumGuild = require('../../src/database/models/premiumGuildSchema');

/**
 * Requires a logged-in session, and - when the route has a `:id` guild
 * param - that the session user can manage that guild (same rule as
 * ensureGuildManager: bot owner, Administrator, Manage Guild, or the
 * configured admin role).
 */
async function isAuth(req, res, next) {
  if (!req.session?.user) {
    return res.status(401).json({ error: 'Not authenticated' });
  }

  const guildId = req.params.id || req.params.guildId;
  if (!guildId) return next();

  try {
    const guild = req.client?.guilds.cache.get(guildId);
    if (!guild) {
      return res.status(404).json({ error: 'Bot is not in that server' });
    }

    const member = await guild.members.fetch(req.session.user.id).catch(() => null);
    if (!member) {
      return res.status(403).json({ error: 'You are not a member of that server' });
    }

    const guildConfig = await getGuildConfig(guild.id);
    if (!isGuildManager(member, guildConfig)) {
      return res.status(403).json({ error: 'You do not have permission to manage this server' });
    }

    req.guild = guild;
    req.guildConfig = guildConfig;
    next();
  } catch (err) {
    next(err);
  }
}

/**
 * Gates a route behind an active (non-expired) legacy premium
 * subscription for the guild in the URL, tracked in the ported
 * PremiumGuild collection (src/database/models/premiumGuildSchema.js).
 *
 * Queries the same `{ id, isPremiumGuild, premium: { expiresAt } }` shape
 * that every writer of this collection actually uses - the Stripe webhook
 * (dashboard/routes/premium.js), /redeem and /guildredeem
 * (src/commands/community/*.js), the owner /premium command, and the
 * admin dashboard (dashboard/adminRoutes.js, dashboard/routes/guild.js).
 * A previous version of this check queried a `guildId` field and a
 * top-level `expiresAt` that nothing in the app ever wrote, so it never
 * matched a real document and premium features stayed gated even after a
 * successful purchase or redeem.
 */
async function checkPremium(req, res, next) {
  const guildId = req.params.id || req.params.guildId;
  try {
    const doc = guildId ? await PremiumGuild.findOne({ id: guildId }) : null;
    const expiresAt = doc?.premium?.expiresAt;
    const active = Boolean(doc?.isPremiumGuild) && (!expiresAt || new Date(expiresAt) > new Date());
    if (!active) {
      return res.status(402).json({ error: 'This feature requires an active premium subscription' });
    }
    next();
  } catch (err) {
    next(err);
  }
}

/**
 * Blocks all requests while the bot-wide maintenance flag
 * (src/database/models/maintenanceSchema.js singleton) is enabled.
 */
async function checkMaintenance(req, res, next) {
  try {
    const doc = await Maintenance.findOne();
    if (doc?.enabled) {
      return res.status(503).json({ error: 'The bot is currently under maintenance' });
    }
    next();
  } catch (err) {
    next(err);
  }
}

module.exports = { isAuth, checkPremium, checkMaintenance };
