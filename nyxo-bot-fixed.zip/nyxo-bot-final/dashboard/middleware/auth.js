const { isGuildManager } = require('../../src/utils/permissions');
const { getGuildConfig } = require('../../src/utils/resolveGuildSettings');

function ensureAuthenticated(req, res, next) {
  if (!req.session.user) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  next();
}

/**
 * Ensures the logged-in user has permission to manage the guild specified
 * by req.params.id, and that the bot is actually present in that guild.
 * Attaches `req.guild` and `req.guildConfig` for downstream handlers.
 */
function ensureGuildManager(client) {
  return async (req, res, next) => {
    const guild = client.guilds.cache.get(req.params.id);
    if (!guild) {
      return res.status(404).json({ error: 'Bot is not in that server' });
    }

    const member = await guild.members.fetch(req.session.user.id).catch(() => null);
    if (!member) {
      return res.status(403).json({ error: 'You are not a member of that server' });
    }

    const guildConfig = await getGuildConfig(guild.id);
    if (!isGuildManager(member, guildConfig)) {
      return res.status(403).json({ error: 'You do not have permission to manage this server' });
    }

    req.guild = guild;
    req.guildConfig = guildConfig;
    next();
  };
}

module.exports = { ensureAuthenticated, ensureGuildManager };
