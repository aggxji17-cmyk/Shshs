const router = require("express").Router();
const {
  EmbedBuilder,
  PermissionsBitField,
} = require("discord.js");
const path = require('path');
const fs = require('fs'); // Added for command reloading

/* ===================== Models ===================== */
const blacklistDB = require("../src/database/models/blacklistSchema");
const guildBlacklistDB = require("../src/database/models/guildBlacklistSchema");
const PremiumUser = require("../src/database/models/premiumUserSchema");
const PremiumGuild = require("../src/database/models/premiumGuildSchema");
const PremiumPlan = require("../src/database/models/premiumPlanSchema");
const PremiumCommand = require("../src/database/models/premiumCommandSchema");
const PremiumFeature = require("../src/database/models/premiumFeatureSchema");
const UserAccount = require("../src/database/models/userAccountSchema");
const BankAccount = require("../src/database/models/bankSchema");
const { isOwner } = require("../src/utils/permissions");
/* ===================== Admin Middleware ===================== */
// Uses the same config.ownerIds-backed isOwner() check as everywhere
// else in the bot. A raw `req.user.id === process.env.DEVELOPER_ID`
// string compare only ever matches when DEVELOPER_ID holds exactly one
// ID - as soon as a second owner is added (DEVELOPER_ID="a,b"), every
// owner fails that comparison and gets locked out of the admin panel.
const isAdmin = (req, res, next) => {
  if (!req.user || !isOwner(req.user.id)) {
    return res.status(403).json({ error: "Unauthorized - Admin only" });
  }
  next();
};

// Apply admin middleware to all routes in this file
router.use(isAdmin);

/* ===================== Admin Panel Pages ===================== */

const servePage = (res, pageName) => {
  res.sendFile(path.join(__dirname, "views", "admin", `${pageName}.html`));
};

// Root defaults to overview
router.get("/", (req, res) => servePage(res, "overview"));

// Specific routes for each page
router.get("/overview", (req, res) => servePage(res, "overview"));
router.get("/users", (req, res) => servePage(res, "users"));
router.get("/servers", (req, res) => servePage(res, "servers"));
router.get("/premium", (req, res) => servePage(res, "premium"));
router.get("/premium-plans", (req, res) => servePage(res, "premium-plans"));
router.get("/premium-commands", (req, res) => servePage(res, "premium-commands"));
router.get("/blacklists", (req, res) => servePage(res, "blacklists"));
router.get("/broadcast", (req, res) => servePage(res, "broadcast"));

/* ===================== Overview Stats ===================== */
router.get("/api/stats", async (req, res) => {
  try {
    const client = req.client;

    let totalChannels = 0;
    let totalUsers = 0;
    client.guilds.cache.forEach(guild => {
      totalChannels += guild.channels.cache.size;
      totalUsers += guild.memberCount;
    });

    const uptime = process.uptime();
    const days = Math.floor(uptime / 86400);
    const hours = Math.floor((uptime % 86400) / 3600);
    const minutes = Math.floor((uptime % 3600) / 60);
    const uptimeString = `${days}d ${hours}h ${minutes}m`;

    const memUsage = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2);

    res.json({
      guilds: client.guilds.cache.size,
      users: totalUsers,
      channels: totalChannels,
      ping: Math.round(client.ws.ping),
      uptime: uptimeString,
      memory: `${memUsage} MB`
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to fetch stats" });
  }
});


/* ===================== User Management ===================== */

// Get All Users (Optimized with Cache)
router.get("/api/users", async (req, res) => {
  try {
    const users = req.client.users.cache
      .filter(user => !user.bot)
      .first(100) // Show first 100 for performance
      .map(user => ({
        id: user.id,
        username: user.username,
        discriminator: user.discriminator,
        avatar: user.displayAvatarURL(),
        createdAt: user.createdAt.toLocaleDateString()
      }));

    res.json(users);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to fetch users" });
  }
});

// Get Single User Details (Direct Fetch)
router.get("/api/user/:id", async (req, res) => {
  try {
    const userId = req.params.id;
    const clientUser = await req.client.users.fetch(userId).catch(() => null);

    if (!clientUser) {
      return res.status(404).json({ error: "User not found in Discord" });
    }

    // Fetch economy balances from DB
    const cashAccount = await UserAccount.findOne({ userId });
    const bankAccount = await BankAccount.findOne({ userID: userId });
    const totalBalance = (cashAccount?.balance || 0) + (bankAccount?.balance || 0);

    const user = {
      id: clientUser.id,
      username: clientUser.username,
      discriminator: clientUser.discriminator,
      avatar: clientUser.displayAvatarURL(),
      createdAt: clientUser.createdAt.toLocaleDateString(),
      cashBalance: cashAccount?.balance || 0,
      bankBalance: bankAccount?.balance || 0,
      balance: totalBalance,
    };

    res.json(user);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to fetch user" });
  }
});

// Get User's Linked Servers (Optimized with Cache)
router.get("/api/user/:id/servers", async (req, res) => {
  try {
    const userId = req.params.id;
    const servers = [];

    for (const [guildId, guild] of req.client.guilds.cache) {
      const member = guild.members.cache.get(userId);
      if (member) {
        servers.push({
          id: guild.id,
          name: guild.name,
          members: guild.memberCount,
          permissions: member.permissions.has(PermissionsBitField.Flags.Administrator) ? 'Admin' : 'Member'
        });
      }
    }

    res.json(servers);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to fetch user servers" });
  }
});

// Delete User Data
router.delete("/api/user/:id", async (req, res) => {
  try {
    const userId = req.params.id;

    // Delete economy data
    await UserAccount.deleteMany({ userId });
    await BankAccount.deleteMany({ userID: userId });

    // Delete premium data
    await PremiumUser.deleteMany({ id: userId });

    // Remove from blacklist if present
    await blacklistDB.deleteMany({ userId });

    // Delete warnings
    const warningSchema = require("../src/database/models/warnSchema");
    await warningSchema.deleteMany({ UserID: userId });

    // Delete level data
    const levelSchema = require("../src/database/models/levelSchema");
    await levelSchema.deleteMany({ UserID: userId });

    // Delete AFK data
    const afkSchema = require("../src/database/models/afkSchema");
    await afkSchema.deleteMany({ UserID: userId });

    res.json({ success: true, message: `Deleted all data for user ${userId}` });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to delete user data" });
  }
});

/* ===================== Server Management ===================== */

// Get All Servers
router.get("/api/servers", async (req, res) => {
  try {
    const servers = [];

    for (const [guildId, guild] of req.client.guilds.cache) {
      try {
        servers.push({
          id: guild.id,
          name: guild.name,
          icon: guild.iconURL({ size: 128 }),
          memberCount: guild.memberCount,
          ownerId: guild.ownerId
        });
      } catch (err) {
        console.error(`Error fetching guild ${guildId}:`, err);
      }
    }

    res.json(servers);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to fetch servers" });
  }
});

// Get Server Info (UPDATED FIX)
router.get("/api/server/:id/info", async (req, res) => {
  try {
    const guild = req.client.guilds.cache.get(req.params.id);
    if (!guild) return res.status(404).json({ error: "Guild not found" });

    const owner = await guild.fetchOwner();
    await guild.fetch();

    // Look up premium data by ID
    const premiumData = await PremiumGuild.findOne({ id: guild.id });

    // Determine status
    const isPremium = premiumData && premiumData.isPremiumGuild === true;
    const premiumPlan = isPremium ? (premiumData.premium?.plan || 'Standard') : null;

    res.json({
      id: guild.id,
      name: guild.name,
      icon: guild.iconURL({ size: 256 }),
      owner: `${owner.user.username}#${owner.user.discriminator}`,
      ownerId: guild.ownerId,
      createdAt: guild.createdAt.toLocaleDateString(),
      members: guild.memberCount,
      channels: guild.channels.cache.size,
      roles: guild.roles.cache.size,
      emojis: guild.emojis.cache.size,
      isPremium: isPremium,
      premiumPlan: premiumPlan,
      boostLevel: guild.premiumTier ?? 0
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to get server info" });
  }
});

// Get Server Invite
router.get("/api/server/:id/invite", async (req, res) => {
  try {
    const guild = req.client.guilds.cache.get(req.params.id);
    if (!guild) return res.status(404).json({ error: "Guild not found" });

    let inviteUrl = null;
    try {
      const channel = guild.channels.cache.find(
        ch => ch.type === 0 && ch.permissionsFor(guild.members.me)?.has(PermissionsBitField.Flags.CreateInstantInvite)
      );

      if (channel) {
        const invite = await channel.createInvite({ maxAge: 0, maxUses: 0 });
        inviteUrl = invite.url;
      }
    } catch (err) {
      console.error("Could not create invite:", err);
    }

    res.json({ invite: inviteUrl });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to get invite" });
  }
});

// Leave Server
router.post("/api/server/:id/leave", async (req, res) => {
  try {
    const guild = req.client.guilds.cache.get(req.params.id);
    if (!guild) return res.status(404).json({ error: "Guild not found" });

    await guild.leave();
    res.json({ success: true });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to leave server" });
  }
});

/* ===================== Premium Management ===================== */

// Grant Premium
router.post("/api/premium/grant", async (req, res) => {
  try {
    const { type, id, plan } = req.body;

    // Fetch plan details to get dynamic duration
    const planDetails = await PremiumPlan.findOne({ planId: plan });
    const durationDays = planDetails ? planDetails.durationDays : 30; // fallback 30 if null

    const expiresAt = new Date(Date.now() + durationDays * 86400000);

    if (type === 'user') {
      await PremiumUser.findOneAndUpdate(
        { id },
        {
          id,
          isPremium: true,
          premium: {
            redeemedBy: [req.user.id],
            redeemedAt: new Date(),
            expiresAt,
            plan
          }
        },
        { upsert: true }
      );
    } else if (type === 'guild') {
      await PremiumGuild.findOneAndUpdate(
        { id },
        {
          id,
          isPremiumGuild: true,
          premium: {
            redeemedBy: [req.user.id],
            redeemedAt: new Date(),
            expiresAt,
            plan
          }
        },
        { upsert: true }
      );
    }

    res.json({ success: true, newExpiry: expiresAt });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to grant premium" });
  }
});

// List Premium Subscriptions
router.get("/api/premium/list", async (req, res) => {
  try {
    const users = await PremiumUser.find({ isPremium: true });
    const guilds = await PremiumGuild.find({ isPremiumGuild: true });

    const premiums = [
      ...users.map(u => ({
        id: u.id,
        type: 'user',
        plan: u.premium.plan,
        expiresAt: u.premium.expiresAt?.toLocaleDateString() || 'Never'
      })),
      ...guilds.map(g => ({
        id: g.id,
        type: 'guild',
        plan: g.premium.plan,
        expiresAt: g.premium.expiresAt?.toLocaleDateString() || 'Never'
      }))
    ];

    res.json(premiums);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to fetch premium list" });
  }
});

// Remove Premium
router.post("/api/premium/remove", async (req, res) => {
  try {
    const { type, id } = req.body;

    if (type === 'user') {
      await PremiumUser.findOneAndUpdate(
        { id },
        { isPremium: false }
      );
    } else if (type === 'guild') {
      await PremiumGuild.findOneAndUpdate(
        { id },
        { isPremiumGuild: false }
      );
    }

    res.json({ success: true });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to remove premium" });
  }
});

// Premium Plans CRUD
router.get("/api/premium/plans", async (req, res) => {
  try {
    const plans = await PremiumPlan.find({});
    res.json(plans);
  } catch (error) { res.status(500).json({ error: "Failed" }); }
});

router.post("/api/premium/plans", async (req, res) => {
  try {
    const { planId, planName, durationDays, description, price, priority } = req.body;
    await PremiumPlan.findOneAndUpdate(
      { planId },
      { planId, planName, durationDays, description, price, priority: priority || 0 },
      { upsert: true }
    );
    res.json({ success: true });
  } catch (error) { res.status(500).json({ error: "Failed" }); }
});

router.delete("/api/premium/plans/:id", async (req, res) => {
  try {
    await PremiumPlan.findByIdAndDelete(req.params.id);
    res.json({ success: true });
  } catch (error) { res.status(500).json({ error: "Failed" }); }
});

// Premium Commands CRUD
router.get("/api/premium/bot-commands", async (req, res) => {
  try {
    const premiumCmds = await PremiumCommand.find({ isPremiumOnly: true });
    const lockedMap = new Map(premiumCmds.map(c => [c.commandName, c.requiredPlan || 'all']));

    const allCommands = [];
    req.client.commands.forEach(cmd => {
      // Prioritize local file configurations, but fallback/override with DB settings
      // Syncs file-based premium commands with the admin dashboard
      const isPremiumFile = !!cmd.premium;
      const requiredPlanFile = cmd.requiredPlan || 'all';
      
      allCommands.push({
        name: cmd.data.name,
        description: cmd.data.description,
        isPremium: lockedMap.has(cmd.data.name) ? true : isPremiumFile,
        requiredPlan: lockedMap.get(cmd.data.name) || requiredPlanFile
      });
    });

    allCommands.sort((a, b) => a.name.localeCompare(b.name));
    res.json(allCommands);
  } catch (error) { res.status(500).json({ error: "Failed" }); }
});

router.post("/api/premium/commands/toggle", async (req, res) => {
  try {
    const { commandName, isPremium, requiredPlan } = req.body;
    if (isPremium) {
      await PremiumCommand.findOneAndUpdate(
        { commandName },
        { commandName, isPremiumOnly: true, requiredPlan: requiredPlan || 'all' },
        { upsert: true }
      );
    } else {
      await PremiumCommand.findOneAndDelete({ commandName });
    }
    res.json({ success: true });
  } catch (error) { res.status(500).json({ error: "Failed" }); }
});

router.get("/api/premium/commands", async (req, res) => {
  try {
    const cmds = await PremiumCommand.find({ isPremiumOnly: true });
    res.json(cmds);
  } catch (error) { res.status(500).json({ error: "Failed" }); }
});

router.post("/api/premium/commands", async (req, res) => {
  try {
    const { commandName } = req.body;
    await PremiumCommand.findOneAndUpdate(
      { commandName },
      { commandName, isPremiumOnly: true },
      { upsert: true }
    );
    res.json({ success: true });
  } catch (error) { res.status(500).json({ error: "Failed" }); }
});

router.delete("/api/premium/commands/:id", async (req, res) => {
  try {
    await PremiumCommand.findByIdAndDelete(req.params.id);
    res.json({ success: true });
  } catch (error) { res.status(500).json({ error: "Failed" }); }
});

/* ===================== Premium Features (Dashboard) ===================== */

// List all dashboard features with premium status
router.get("/api/premium/features", async (req, res) => {
  try {
    const premiumFeatures = await PremiumFeature.find({ isPremiumOnly: true });
    const lockedMap = new Map(premiumFeatures.map(f => [f.featureId, f.requiredPlan || 'all']));

    // Hardcoded list of dashboard features matching sidebar.js IDs
    const allFeatures = [
      { id: 'welcome', name: 'Welcome System', category: 'General' },
      { id: 'leave', name: 'Leave System', category: 'General' },
      { id: 'music', name: 'Music Control', category: 'Music' },
      { id: 'automod', name: 'Auto Moderation', category: 'Moderation' },
      { id: 'antinuke', name: 'Anti-Nuke System', category: 'Moderation' },
      { id: 'autorole', name: 'Auto Role', category: 'Moderation' },
      { id: 'joinping', name: 'Join Ping', category: 'Moderation' },
      { id: 'logs', name: 'Audit Logs', category: 'Moderation' },
      { id: 'sticky', name: 'Sticky Messages', category: 'Moderation' },
      { id: 'leveling', name: 'Leveling System', category: 'Utility & Social' },
      { id: 'applications', name: 'Applications', category: 'Utility & Social' },
      { id: 'ticket', name: 'Ticket System', category: 'Utility & Social' },
      { id: 'reactionrole', name: 'Reaction Roles', category: 'Utility & Social' },
      { id: 'embed', name: 'Live Embed Creator', category: 'Utility & Social' },
      { id: 'youtube', name: 'YouTube Notifier', category: 'Utility & Social' },
      { id: 'twitch', name: 'Twitch Notifier', category: 'Utility & Social' },
    ];

    const result = allFeatures.map(f => ({
      ...f,
      isPremium: lockedMap.has(f.id),
      requiredPlan: lockedMap.get(f.id) || 'all'
    }));

    res.json(result);
  } catch (error) { res.status(500).json({ error: "Failed" }); }
});

// Toggle a dashboard feature's premium status
router.post("/api/premium/features/toggle", async (req, res) => {
  try {
    const { featureId, isPremium, requiredPlan } = req.body;
    if (isPremium) {
      await PremiumFeature.findOneAndUpdate(
        { featureId },
        { featureId, isPremiumOnly: true, requiredPlan: requiredPlan || 'all' },
        { upsert: true }
      );
    } else {
      await PremiumFeature.findOneAndDelete({ featureId });
    }
    res.json({ success: true });
  } catch (error) { res.status(500).json({ error: "Failed" }); }
});

// Get locked feature IDs (for guild sidebar to consume — no admin check needed)
router.get("/api/premium/features/locked", async (req, res) => {
  try {
    const features = await PremiumFeature.find({ isPremiumOnly: true });
    res.json(features.map(f => ({ featureId: f.featureId, requiredPlan: f.requiredPlan || 'all' })));
  } catch (error) { res.status(500).json({ error: "Failed" }); }
});


/* ===================== Blacklist Management ===================== */

// List Blacklists
router.get("/api/blacklist/list", async (req, res) => {
  try {
    const users = await blacklistDB.find({});
    const guilds = await guildBlacklistDB.find({});

    const blacklists = [
      ...users.map(u => ({ id: u.userId, type: 'user', reason: u.reason })),
      ...guilds.map(g => ({ id: g.guildId, type: 'guild', reason: g.reason }))
    ];

    res.json(blacklists);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to fetch blacklists" });
  }
});

// Blacklist User
router.post("/api/blacklist/user", async (req, res) => {
  try {
    const { userId, reason } = req.body;

    if (!userId) {
      return res.status(400).json({ error: "User ID required" });
    }

    const existing = await blacklistDB.findOne({ userId });
    if (existing) {
      return res.status(400).json({ error: "User already blacklisted" });
    }

    await blacklistDB.create({
      userId,
      reason: reason || "No reason provided"
    });

    res.json({ success: true });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to blacklist user" });
  }
});

// Blacklist Guild
router.post("/api/blacklist/guild", async (req, res) => {
  try {
    const { guildId, reason } = req.body;

    if (!guildId) {
      return res.status(400).json({ error: "Guild ID required" });
    }

    const existing = await guildBlacklistDB.findOne({ guildId });
    if (existing) {
      return res.status(400).json({ error: "Guild already blacklisted" });
    }

    await guildBlacklistDB.create({
      guildId,
      reason: reason || "No reason provided"
    });

    const guild = req.client.guilds.cache.get(guildId);
    if (guild) {
      try {
        const owner = await guild.fetchOwner();

        const dmEmbed = new EmbedBuilder()
          .setTitle("🚫 Server Blacklisted")
          .setDescription(`Your server **${guild.name}** has been blacklisted from using ${req.client.user.username}.`)
          .addFields({ name: "Reason", value: reason || "No reason provided" })
          .setColor("Red")
          .setTimestamp();

        await owner.send({ embeds: [dmEmbed] }).catch(() => { });
        await guild.leave();
      } catch (err) {
        console.error("Error leaving guild:", err);
      }
    }

    res.json({ success: true });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to blacklist guild" });
  }
});

// Remove from Blacklist
router.delete("/api/blacklist/:type/:id", async (req, res) => {
  try {
    const { type, id } = req.params;

    if (type === 'user') {
      await blacklistDB.deleteOne({ userId: id });
    } else if (type === 'guild') {
      await guildBlacklistDB.deleteOne({ guildId: id });
    }

    res.json({ success: true });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to remove from blacklist" });
  }
});

/* ===================== Broadcast System (UPDATED) ===================== */
router.post("/api/broadcast", async (req, res) => {
  try {
    const { type, message, target } = req.body;

    if (!message) {
      return res.status(400).json({ error: "Message required" });
    }

    const colors = {
      warning: "#FFA500",
      info: "#3B82F6",
      critical: "#EF4444",
      success: "#10B981"
    };

    const icons = {
      warning: "⚠️",
      info: "ℹ️",
      critical: "🚨",
      success: "✅"
    };

    const titles = {
      warning: "System Broadcast: WARNING",
      info: "System Broadcast: INFORMATION",
      critical: "System Broadcast: CRITICAL ALERT",
      success: "System Broadcast: SUCCESS"
    };

    const embed = new EmbedBuilder()
      .setTitle(`${icons[type] || "📢"} ${titles[type] || "System Broadcast"}`)
      .setDescription(message)
      .setColor(colors[type] || colors.info)
      .setFooter({ text: `Sent by Bot Administrator` })
      .setTimestamp();

    let sent = 0;
    let failed = 0;

    for (const [guildId, guild] of req.client.guilds.cache) {
      try {
        // Target Logic
        if (target === 'owners') {
          const owner = await guild.fetchOwner();
          await owner.send({ embeds: [embed] });
          sent++;
        } else if (target === 'system') {
          if (guild.systemChannel) {
            await guild.systemChannel.send({ embeds: [embed] });
            sent++;
          }
        } else if (target === 'general') {
          // Find first text channel named 'general' or just first text channel permissions allow
          const channel = guild.channels.cache.find(c =>
            c.type === 0 &&
            (c.name.includes('general') || c.name.includes('chat')) &&
            c.permissionsFor(guild.members.me).has(PermissionsBitField.Flags.SendMessages)
          ) || guild.channels.cache.find(c =>
            c.type === 0 &&
            c.permissionsFor(guild.members.me).has(PermissionsBitField.Flags.SendMessages)
          );

          if (channel) {
            await channel.send({ embeds: [embed] });
            sent++;
          }
        }
      } catch (err) {
        failed++;
        // console.error(`Failed to send to ${guild.name}:`, err.message);
      }
    }

    res.json({ success: true, sent, failed });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to send broadcast" });
  }
});

/* ===================== Maintenance Mode ===================== */
const MaintenanceMode = require("../src/database/models/maintenanceSchema");

router.get("/api/maintenance", async (req, res) => {
  try {
    let data = await MaintenanceMode.findOne({ id: "maintenance" });
    if (!data) {
      data = await MaintenanceMode.create({
        id: "maintenance",
        enabled: false,
        reason: ""
      });
    }
    res.json({ enabled: data.enabled, reason: data.reason || "" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to fetch maintenance status" });
  }
});

router.post("/api/maintenance/toggle", async (req, res) => {
  try {
    const { enabled, reason } = req.body;

    let data = await MaintenanceMode.findOne({ id: "maintenance" });

    if (data) {
      data.enabled = enabled;
      data.reason = reason || "";
      await data.save();
    } else {
      await MaintenanceMode.create({
        id: "maintenance",
        enabled,
        reason: reason || ""
      });
    }

    res.json({ success: true, enabled: data.enabled });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to toggle maintenance mode" });
  }
});

/* ===================== System Controls (NEW) ===================== */

// Reload Commands (Best Effort)
router.post("/api/system/reload", (req, res) => {
  try {
    // Attempt to clear require cache for commands folder
    // Path assumes adminRoutes.js is in /dashboard/ folder, and Commands is in /Commands
    const commandsPath = path.join(__dirname, '../Commands');

    if (fs.existsSync(commandsPath)) {
      // Recursive function to clear cache
      const clearCache = (dir) => {
        fs.readdirSync(dir).forEach(file => {
          const fullPath = path.join(dir, file);
          if (fs.lstatSync(fullPath).isDirectory()) {
            clearCache(fullPath);
          } else {
            delete require.cache[require.resolve(fullPath)];
          }
        });
      };

      clearCache(commandsPath);

      // Note: Since we can't easily re-run the main bot loader from here without exposing it,
      // clearing the cache ensures the NEXT time a command is required (if loaded dynamically) it is fresh.
      // If your bot loads commands once at startup, you might need to trigger a custom event on the client.

      console.log("Admin: Command cache cleared.");
      res.json({ success: true, message: "Command cache cleared." });
    } else {
      console.warn("Admin: Commands directory not found at " + commandsPath);
      res.status(404).json({ error: "Commands directory not found" });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to reload commands" });
  }
});

// Restart Bot (Process Exit)
router.post("/api/system/restart", (req, res) => {
  // Send response first so the frontend knows the request was received
  res.json({ success: true });

  // Wait 1 second then restart. Was a raw process.exit(0), which skipped
  // src/index.js's shutdown() entirely - no dashboard server close, no
  // client.destroy(), no MongoDB connection close. Sending ourselves the
  // same SIGTERM that process already listens for (PM2/Docker/Pterodactyl
  // will still restart it exactly as before) reuses that existing
  // graceful-shutdown path instead of an abrupt kill.
  setTimeout(() => {
    console.log("Admin: Restarting bot process...");
    process.kill(process.pid, "SIGTERM");
  }, 1000);
});

module.exports = router;