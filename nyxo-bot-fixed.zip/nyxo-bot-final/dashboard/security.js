const rateLimit = require("express-rate-limit");

/**
 * Global API rate limiter — 60 requests per minute per IP.
 */
const apiLimiter = rateLimit({
    windowMs: 60 * 1000,
    max: 60,
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: "Too many requests, please try again later." },
});

/**
 * Stricter limiter for auth routes — 5 attempts per minute.
 */
const authLimiter = rateLimit({
    windowMs: 60 * 1000,
    max: 5,
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: "Too many login attempts, please try again later." },
});

/**
 * Stricter limiter for write operations — 20 per minute.
 */
const writeLimiter = rateLimit({
    windowMs: 60 * 1000,
    max: 20,
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: "Too many requests, slow down." },
});

/* ========== Input Sanitization ========== */

const MAX_STRING_LENGTH = 2000;
const DISCORD_ID_REGEX = /^\d{17,20}$/;

/**
 * Strip HTML tags and trim whitespace from a string.
 */
function stripHtml(str) {
    return str
        .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, "")
        .replace(/<\/?[^>]+(>|$)/g, "")
        .trim();
}

/**
 * Recursively sanitize all string values in an object.
 */
function sanitizeObject(obj, depth = 0) {
    if (depth > 5) return obj;

    // Raw request bodies (e.g. the Stripe webhook route, captured as a
    // Buffer via express.raw() before express.json() runs - see
    // dashboard/server.js) must pass through untouched. Buffer is a
    // typeof "object", so without this check Object.entries(obj) below
    // would iterate every byte as a numeric key and rebuild it into a
    // plain object, destroying the exact bytes Stripe's signature check
    // needs.
    if (Buffer.isBuffer(obj)) return obj;

    if (typeof obj === "string") {
        let sanitized = stripHtml(obj);
        if (sanitized.length > MAX_STRING_LENGTH) {
            sanitized = sanitized.substring(0, MAX_STRING_LENGTH);
        }
        return sanitized;
    }

    if (Array.isArray(obj)) {
        return obj.map(item => sanitizeObject(item, depth + 1));
    }

    if (obj && typeof obj === "object") {
        const sanitized = {};
        for (const [key, value] of Object.entries(obj)) {
            sanitized[key] = sanitizeObject(value, depth + 1);
        }
        return sanitized;
    }

    return obj;
}

/**
 * Express middleware that sanitizes all string values in req.body.
 */
function sanitizeBody(req, res, next) {
    if (req.body && typeof req.body === "object") {
        req.body = sanitizeObject(req.body);
    }
    next();
}

/**
 * Validate that a value looks like a Discord snowflake ID.
 */
function isValidSnowflake(id) {
    return typeof id === "string" && DISCORD_ID_REGEX.test(id);
}

/**
 * Middleware factory: validate that specified body fields are valid Discord IDs.
 * Usage: validateIds("channelId", "roleId")
 */
function validateIds(...fields) {
    return (req, res, next) => {
        for (const field of fields) {
            const value = req.body[field];
            if (value && !isValidSnowflake(value)) {
                return res.status(400).json({ error: `Invalid ${field} format` });
            }
        }
        next();
    };
}

/**
 * Adds a baseline set of security-related HTTP response headers.
 * Kept dependency-free (no helmet) so it works with the exact
 * dependencies already vendored for this project. Safe to layer under
 * any reverse proxy (nginx, Cloudflare, etc.) that may also set these.
 */
function securityHeaders(req, res, next) {
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("X-Frame-Options", "DENY");
    res.setHeader("Referrer-Policy", "same-origin");
    res.setHeader("Permissions-Policy", "geolocation=(), microphone=(), camera=()");
    // Only relevant over HTTPS; harmless no-op over plain HTTP.
    res.setHeader("Strict-Transport-Security", "max-age=15552000; includeSubDomains");
    next();
}

module.exports = {
    apiLimiter,
    authLimiter,
    writeLimiter,
    sanitizeBody,
    isValidSnowflake,
    validateIds,
    securityHeaders,
};
