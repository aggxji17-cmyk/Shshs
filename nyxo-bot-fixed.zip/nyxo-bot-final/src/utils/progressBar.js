/**
 * Renders a text progress bar representing how full a server is,
 * e.g. "▰▰▰▰▰▱▱▱▱▱ 47%".
 * @param {number} current
 * @param {number} max
 * @param {number} size number of segments in the bar
 */
function buildProgressBar(current, max, size = 12) {
  if (!max || max <= 0) return '`—`';

  const ratio = Math.max(0, Math.min(1, current / max));
  const filled = Math.round(ratio * size);
  const empty = size - filled;
  const pct = Math.round(ratio * 100);

  return `${'▰'.repeat(filled)}${'▱'.repeat(empty)}  \`${pct}%\``;
}

module.exports = { buildProgressBar };
