const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { baseEmbed } = require('./embeds');

const TRACKS_PER_PAGE = 10;
const REPEAT_MODE_LABELS = { 0: 'Off', 1: 'Track', 2: 'Queue', 3: 'Autoplay' };

/** Formats a millisecond duration as `h:mm:ss` (or `m:ss` under an hour). Returns null for 0/unknown. */
function formatDuration(ms) {
  if (!ms || ms <= 0) return null;
  const totalSeconds = Math.floor(ms / 1000);
  const h = Math.floor(totalSeconds / 3600);
  const m = Math.floor((totalSeconds % 3600) / 60);
  const s = totalSeconds % 60;
  const pad = (n) => String(n).padStart(2, '0');
  return h > 0 ? `${h}:${pad(m)}:${pad(s)}` : `${m}:${pad(s)}`;
}

/**
 * Builds a single page of the queue: the embed (now playing + upcoming
 * tracks + stats) and its Previous/Next/Clear button row. Shared between
 * the /queue command and the music_queue_page / music_queue_clear button
 * handlers so both always render identically.
 *
 * @param {import('discord-player').GuildQueue} queue
 * @param {ReturnType<typeof import('./resolveGuildSettings').resolved>} settings
 * @param {number} requestedPage 1-indexed page to render; clamped into range.
 */
function buildQueuePage(queue, settings, requestedPage = 1) {
  const tracks = queue.tracks.toArray();
  const totalPages = Math.max(1, Math.ceil(tracks.length / TRACKS_PER_PAGE));
  const page = Math.min(Math.max(requestedPage, 1), totalPages);
  const start = (page - 1) * TRACKS_PER_PAGE;
  const pageTracks = tracks.slice(start, start + TRACKS_PER_PAGE);

  const upcoming = pageTracks.length
    ? pageTracks
        .map((t, i) => `**${start + i + 1}.** [${t.title}](${t.url}) \`${t.duration || 'Live'}\` — ${t.requestedBy ?? 'Unknown'}`)
        .join('\n')
    : '_Queue is empty — this is the last track._';

  const upcomingMs = tracks.reduce((sum, t) => sum + (t.durationMS || 0), 0);
  const currentMs = queue.currentTrack?.durationMS || 0;
  const totalDuration = formatDuration(upcomingMs + currentMs) || 'Unknown';

  const embed = baseEmbed(settings)
    .setTitle('🎶 Music Queue')
    .setDescription(
      `**Now Playing:**\n[${queue.currentTrack.title}](${queue.currentTrack.url}) \`${queue.currentTrack.duration || 'Live'}\` — ${queue.currentTrack.requestedBy ?? 'Unknown'}\n\n**Up Next:**\n${upcoming}`
    )
    .addFields(
      { name: 'Tracks Queued', value: `${tracks.length}`, inline: true },
      { name: 'Total Duration', value: totalDuration, inline: true },
      { name: 'Loop Mode', value: REPEAT_MODE_LABELS[queue.repeatMode] ?? 'Off', inline: true },
      { name: 'Volume', value: `${queue.node.volume}%`, inline: true }
    )
    .setFooter({ text: `Page ${page}/${totalPages} • ${settings.footer}` });

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`music_queue_page:${page - 1}`)
      .setEmoji('◀️')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(page <= 1),
    new ButtonBuilder()
      .setCustomId(`music_queue_page:${page + 1}`)
      .setEmoji('▶️')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(page >= totalPages),
    new ButtonBuilder()
      .setCustomId('music_queue_clear')
      .setLabel('Clear Queue')
      .setEmoji('🗑️')
      .setStyle(ButtonStyle.Danger)
      .setDisabled(tracks.length === 0)
  );

  return { embed, components: [row], page, totalPages };
}

module.exports = { buildQueuePage };
