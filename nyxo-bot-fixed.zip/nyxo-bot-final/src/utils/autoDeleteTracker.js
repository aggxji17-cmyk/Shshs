/**
 * Small in-memory registry for messages that are about to be removed by an
 * auto-delete-channel timer (see events/message/messageCreate.js). The
 * messageDelete handler checks this before running ghost-ping / snipe
 * logic, so a scheduled cleanup doesn't get logged as a "ghost ping".
 */
const pending = new Set();
const ENTRY_TTL_MS = 5 * 60 * 1000;

function markAutoDeleted(messageId) {
  pending.add(messageId);
  setTimeout(() => pending.delete(messageId), ENTRY_TTL_MS).unref?.();
}

function wasAutoDeleted(messageId) {
  return pending.has(messageId);
}

module.exports = { markAutoDeleted, wasAutoDeleted };
