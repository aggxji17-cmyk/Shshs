'use strict';

const CommandLog = require('../database/models/CommandLog');
const { baseEmbed } = require('./embeds');
const { resolved } = require('./resolveGuildSettings');
const logger = require('./logger');

/**
 * Records one command invocation to the CommandLog collection (always,
 * powering /commandlogs recent's audit trail) and, if the guild has
 * enabled a live usage channel via /commandlogs channel, also posts a
 * small embed there. Never throws - a logging failure should never
 * break the command it's logging, so both steps are individually
 * best-effort.
 *
 * Call this only once every blacklist/permission/cooldown check has
 * already passed, so the log reflects genuine usage rather than every
 * blocked attempt too.
 *
 * @param {import('discord.js').Interaction} interaction
 * @param {*|null} guildConfig - raw GuildConfig doc, or null for DM usage
 */
async function logCommandUsage(interaction, guildConfig) {
  try {
    await CommandLog.create({
      guildId: interaction.guildId || null,
      commandName: interaction.commandName,
      userId: interaction.user.id,
      channelId: interaction.channelId || null,
    });
  } catch (err) {
    logger.error(`Failed to write command usage log: ${err.stack || err}`);
  }

  if (!guildConfig?.commandLogging?.enabled || !guildConfig.commandLogging.channelId) return;

  const channel = interaction.guild?.channels.cache.get(guildConfig.commandLogging.channelId);
  if (!channel) return;

  const settings = resolved(guildConfig);
  const embed = baseEmbed(settings).setDescription(`📝 ${interaction.user} used \`/${interaction.commandName}\` in ${interaction.channel}`);
  await channel.send({ embeds: [embed] }).catch(() => null);
}

module.exports = { logCommandUsage };
