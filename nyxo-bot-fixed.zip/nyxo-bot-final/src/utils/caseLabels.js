/**
 * Shared display strings for Case actions/statuses, used by both
 * moderationLogService.js (the live log embed) and caseEmbed.js (the
 * /case, /cases and /editcase embeds) so the two never drift apart.
 */

const ACTION_LABELS = {
  ban: '🔨 Ban',
  kick: '👢 Kick',
  timeout: '⏱️ Timeout',
  warn: '⚠️ Warn',
  unban: '♻️ Unban',
  softban: '🧹 Softban',
  // Not real Case actions (see database/models/Case.js) - temprole never
  // creates a Case - but reusing this shared label map keeps
  // moderationLogService's embeds visually consistent with everything else.
  temprole_add: '⏳ Temp Role Added',
  temprole_remove: '🗑️ Temp Role Removed',
};

const ACTION_COLORS = {
  ban: '#ED4245',
  kick: '#FEE75C',
  timeout: '#5865F2',
  warn: '#FAA61A',
  unban: '#57F287',
  softban: '#EB459E',
  temprole_add: '#5865F2',
  temprole_remove: '#99AAB5',
};

const STATUS_LABELS = {
  Active: '🟢 نشطة',
  Expired: '⚪ منتهية',
  Reverted: '🔵 ملغاة',
};

module.exports = { ACTION_LABELS, ACTION_COLORS, STATUS_LABELS };
