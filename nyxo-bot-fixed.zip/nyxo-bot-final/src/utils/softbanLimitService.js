const SoftbanAction = require('../database/models/SoftbanAction');
const { UNLIMITED, makeWeeklyLimitService } = require('./weeklyLimitService');

const service = makeWeeklyLimitService(SoftbanAction, (guildConfig) => guildConfig?.moderation?.softbanLimits);

module.exports = {
  UNLIMITED,
  getMemberWeeklySoftbanLimit: service.getMemberWeeklyLimit,
  countSoftbansThisWeek: service.countThisWeek,
  recordSoftban: service.recordAction,
};
