'use strict';

/**
 * Shared helpers for building a fast, consistent slash-command
 * autocomplete experience across the whole bot.
 *
 * Discord requires an autocomplete response within 3 seconds and caps
 * the result list at 25 choices, each with a name up to 100 characters.
 * Every helper here is defensive about those limits so a slow lookup or
 * a bad query never crashes the interaction or leaves it hanging - at
 * worst the user sees an empty suggestion list instead of a broken bot.
 */

const logger = require('./logger');
const { getCategoryNames } = require('./commandCategories');

const MAX_CHOICES = 25;
const MAX_NAME_LENGTH = 100;

/**
 * Truncates a string to Discord's 100-character choice-name limit,
 * appending an ellipsis when it had to cut something off.
 */
function truncate(value, max = MAX_NAME_LENGTH) {
  const str = String(value);
  if (str.length <= max) return str;
  return `${str.slice(0, max - 1)}…`;
}

/**
 * Ranks `items` against the user's in-progress input and returns the
 * best matches, most relevant first:
 *   1. exact match
 *   2. starts with the query
 *   3. contains the query anywhere
 * Comparison is case-insensitive and works fine with Arabic text (no
 * locale-specific case folding is needed there). When the query is
 * empty, the original order is kept - this is what lets a freshly
 * opened autocomplete box show a sensible "most recent" / "default"
 * list before the user has typed anything.
 *
 * @template T
 * @param {T[]} items
 * @param {string} query - raw text currently typed by the user
 * @param {object} [opts]
 * @param {(item: T) => string} [opts.key] - extracts the searchable text from an item; defaults to String(item)
 * @param {number} [opts.limit] - max results to return (capped at 25 regardless)
 * @returns {T[]}
 */
function fuzzyFilter(items, query, opts = {}) {
  const { key = (v) => String(v), limit = MAX_CHOICES } = opts;
  const needle = String(query || '').trim().toLowerCase();
  const cap = Math.min(limit, MAX_CHOICES);

  if (!needle) return items.slice(0, cap);

  const exact = [];
  const startsWith = [];
  const contains = [];

  for (const item of items) {
    const haystack = key(item).toLowerCase();
    if (haystack === needle) exact.push(item);
    else if (haystack.startsWith(needle)) startsWith.push(item);
    else if (haystack.includes(needle)) contains.push(item);
  }

  return [...exact, ...startsWith, ...contains].slice(0, cap);
}

/**
 * Sends an autocomplete result list back to Discord, guaranteeing the
 * 25-choice / 100-char limits are respected. If Discord rejects the
 * response (most commonly because the 3s window already passed) this
 * logs a warning instead of throwing, since there is nothing useful
 * left to do at that point.
 *
 * @param {import('discord.js').AutocompleteInteraction} interaction
 * @param {Array<{ name: string, value: string|number }>} choices
 */
async function respond(interaction, choices) {
  try {
    const safeChoices = choices.slice(0, MAX_CHOICES).map((c) => ({
      name: truncate(c.name),
      value: c.value,
    }));
    await interaction.respond(safeChoices);
  } catch (err) {
    logger.warn(`Autocomplete respond failed for "${interaction.commandName}": ${err.message}`);
  }
}

/**
 * Wraps a command's autocomplete logic so any thrown/rejected error
 * results in an empty suggestion list (rather than an unhandled
 * rejection or a stuck client-side spinner), and logs the failure.
 * Every command that exports `autocomplete` should wrap it with this.
 *
 * @param {(interaction: import('discord.js').AutocompleteInteraction) => Promise<Array<{name:string,value:string|number}>>} handler
 */
function safeAutocomplete(handler) {
  return async function (interaction) {
    let choices = [];
    try {
      choices = (await handler(interaction)) || [];
    } catch (err) {
      logger.error(`Autocomplete handler "${interaction.commandName}" failed: ${err.stack || err}`);
      choices = [];
    }
    await respond(interaction, choices);
  };
}

/**
 * Autocomplete choices for a "pick an existing slash command by name"
 * field (used by /help and /blacklist command). Reads straight from
 * the live command Collection so the suggestion list is always exactly
 * what's actually registered on the bot - there's no separate list to
 * keep in sync by hand.
 *
 * @param {import('discord.js').AutocompleteInteraction} interaction
 * @param {string} query
 */
function commandNameChoices(interaction, query) {
  const names = [...interaction.client.commands.keys()].sort();
  const matches = fuzzyFilter(names, query, { limit: MAX_CHOICES });
  return matches.map((name) => ({ name: `/${name}`, value: name }));
}

/**
 * Autocomplete choices for a "pick a command category" field (used by
 * /rolepermissions' allow-category / deny-category / clear-category).
 * Same live-Collection philosophy as commandNameChoices above, via
 * utils/commandCategories.js.
 *
 * @param {import('discord.js').AutocompleteInteraction} interaction
 * @param {string} query
 */
function categoryChoices(interaction, query) {
  const names = getCategoryNames(interaction.client);
  const matches = fuzzyFilter(names, query, { limit: MAX_CHOICES });
  return matches.map((name) => ({ name, value: name }));
}

/**
 * Common, bilingual quick-pick moderation reasons. Autocomplete never
 * restricts what a user can actually submit for a plain STRING option
 * (it's a suggestion list, not an enum) - free-form typing keeps
 * working exactly as before, this just puts the frequent cases one
 * tap away instead of retyping them every time.
 */
const COMMON_MODERATION_REASONS = [
  'Spam',
  'Advertising',
  'Harassment',
  'Hate speech',
  'NSFW content',
  'Raid / mass mention',
  'Scam or phishing link',
  'Inappropriate username or avatar',
  'Ban evasion',
  'Repeated rule violations',
  'سبام / إزعاج',
  'إعلانات غير مصرح بها',
  'تحرش أو إساءة لأعضاء',
  'خطاب كراهية',
  'محتوى غير لائق (NSFW)',
  'غارة جماعية / منشن جماعي',
  'رابط احتيال أو تصيد',
  'اسم مستخدم أو صورة غير لائقة',
  'محاولة تجاوز حظر سابق',
  'مخالفات متكررة للقوانين',
];

function reasonChoices(query) {
  const matches = fuzzyFilter(COMMON_MODERATION_REASONS, query, { limit: MAX_CHOICES });
  return matches.map((reason) => ({ name: reason, value: reason }));
}

module.exports = {
  MAX_CHOICES,
  truncate,
  fuzzyFilter,
  respond,
  safeAutocomplete,
  commandNameChoices,
  categoryChoices,
  reasonChoices,
  COMMON_MODERATION_REASONS,
};
