const TimeoutAction = require('../database/models/TimeoutAction');
const { UNLIMITED, makeWeeklyLimitService } = require('./weeklyLimitService');

const service = makeWeeklyLimitService(TimeoutAction, (guildConfig) => guildConfig?.moderation?.timeoutLimits);

module.exports = {
  UNLIMITED,
  getMemberWeeklyTimeoutLimit: service.getMemberWeeklyLimit,
  countTimeoutsThisWeek: service.countThisWeek,
  recordTimeout: service.recordAction,
};
