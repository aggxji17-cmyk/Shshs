'use strict';

const { PROTECTED_COMMANDS } = require('./commandPermissions');

/**
 * Whether `commandName` has been disabled in `channelId` via
 * /blacklist channel (guildConfig.channelCommandBlacklist). This is a
 * blunt, blocks-everyone switch - even guild managers - exactly like
 * commandBlacklist.commandNames is guild-wide, just scoped to one
 * channel instead of the whole server.
 *
 * PROTECTED_COMMANDS (permissions/rolepermissions/blacklist - the same
 * set commandPermissions.js protects) can never be disabled this way,
 * so a management command can never be locked out of every channel by
 * mistake.
 *
 * @param {string} commandName
 * @param {string} channelId
 * @param {*} guildConfig - raw GuildConfig mongoose doc
 * @returns {boolean}
 */
function isCommandDisabledInChannel(commandName, channelId, guildConfig) {
  if (PROTECTED_COMMANDS.has(commandName)) return false;
  const entry = (guildConfig.channelCommandBlacklist || []).find((e) => e.channelId === channelId);
  return Boolean(entry?.commandNames.includes(commandName));
}

/**
 * Toggles `commandName`'s disabled status in `channelId` on
 * guildConfig, creating the channel's entry if this is its first
 * disabled command, and dropping the entry again if this was its last
 * one - so the array doesn't grow forever with empty entries. Does not
 * save the document; callers still call guildConfig.save() themselves,
 * same as every other guildConfig mutation in this codebase.
 *
 * @param {*} guildConfig - raw GuildConfig mongoose doc
 * @param {string} commandName
 * @param {string} channelId
 * @returns {boolean} whether the command is now disabled in that channel
 */
function toggleCommandInChannel(guildConfig, commandName, channelId) {
  let entry = guildConfig.channelCommandBlacklist.find((e) => e.channelId === channelId);
  if (!entry) {
    guildConfig.channelCommandBlacklist.push({ channelId, commandNames: [] });
    entry = guildConfig.channelCommandBlacklist[guildConfig.channelCommandBlacklist.length - 1];
  }

  const idx = entry.commandNames.indexOf(commandName);
  const nowDisabled = idx === -1;
  if (nowDisabled) {
    entry.commandNames.push(commandName);
  } else {
    entry.commandNames.splice(idx, 1);
  }

  // Drop channel entries left with an empty list, same reasoning as
  // commandPermissions.js's pruneEmptyEntries.
  guildConfig.channelCommandBlacklist = guildConfig.channelCommandBlacklist.filter((e) => e.commandNames.length);

  return nowDisabled;
}

module.exports = { isCommandDisabledInChannel, toggleCommandInChannel };
