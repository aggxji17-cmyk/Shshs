const GuildConfig = require('../database/models/GuildConfig');
const { config } = require('../config/config');

const cache = new Map();
const CACHE_TTL_MS = 30_000;

/**
 * Fetches (and lightly caches) a guild's configuration document, creating
 * one with defaults if it does not exist yet. Also merges in bot-wide
 * .env defaults for fields the guild has not overridden.
 */
async function getGuildConfig(guildId) {
  const cached = cache.get(guildId);
  if (cached && Date.now() - cached.at < CACHE_TTL_MS) {
    return cached.value;
  }

  let doc = await GuildConfig.findOne({ guildId });
  if (!doc) {
    doc = await GuildConfig.create({ guildId });
  }

  cache.set(guildId, { value: doc, at: Date.now() });
  return doc;
}

function invalidateGuildConfig(guildId) {
  cache.delete(guildId);
}

function resolved(guildConfigDoc) {
  return {
    prefix: guildConfigDoc.prefix || config.prefix,
    embedColor: guildConfigDoc.embedColor || config.embedColor,
    footer: guildConfigDoc.footer || config.embedFooter,
    language: guildConfigDoc.language || null, // raw override only - resolve the actual reply language via utils/i18n.js#resolveLanguage
    minecraft: {
      name: guildConfigDoc.minecraft?.name || config.minecraft.name,
      ip: guildConfigDoc.minecraft?.ip || config.minecraft.ip,
      port: guildConfigDoc.minecraft?.port || config.minecraft.port,
      // Bedrock always shares the Java IP - same server, Geyser just adds a port.
      bedrockPort: guildConfigDoc.minecraft?.bedrockPort || config.minecraft.bedrockPort,
      statsApiUrl: guildConfigDoc.minecraft?.statsApiUrl || null,
    },
  };
}

module.exports = { getGuildConfig, invalidateGuildConfig, resolved };
