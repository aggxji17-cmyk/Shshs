'use strict';

const { isGuildManager } = require('./permissions');

/**
 * Commands that can never be restricted or disabled by any of the
 * permission/blacklist systems (/permissions, /rolepermissions,
 * /blacklist's command/channel/role modes, /globaldisable), no matter
 * what rule someone configures - the whole point is that whoever can
 * grant/revoke command access can never accidentally lock themselves
 * (or every guild manager, or the bot owner) out of doing so again.
 * Shared by resolveCommandPermission below and by every command/util
 * that manages one of those systems.
 */
const PROTECTED_COMMANDS = new Set(['permissions', 'rolepermissions', 'blacklist', 'globaldisable']);

/**
 * Resolves the per-command custom permission rules configured via
 * /permissions / /rolepermissions (guildConfig.commandPermissions) for
 * one member + command, in one channel.
 *
 * Guild managers always pass - a misconfigured deny rule or an
 * allow-list that forgets to include admins should never lock the
 * people who can fix it out of the bot. PROTECTED_COMMANDS are likewise
 * always reachable, mirroring how `commandBlacklist` protects
 * `/blacklist` for the same reason.
 *
 * Channel rules sit alongside the role/user rules as one more "who/where
 * can use this" dimension, not a separate pass: deniedChannelIds always
 * wins (like deniedUserIds/deniedRoleIds), and a non-empty
 * allowedChannelIds joins allowedUserIds/allowedRoleIds in the same
 * allow-list check - the command becomes allow-list-only for
 * non-managers, and it passes if the member OR the channel matches.
 * channelId is optional so existing non-interaction callers keep working
 * (channel rules are simply skipped when it's not supplied).
 *
 * @param {string} commandName
 * @param {import('discord.js').GuildMember} member
 * @param {*} guildConfig - raw GuildConfig mongoose doc
 * @param {string} [channelId] - the channel the command was invoked in
 * @returns {{ allowed: boolean, reason: 'denied-user'|'denied-role'|'denied-channel'|'not-in-allowlist'|null }}
 */
function resolveCommandPermission(commandName, member, guildConfig, channelId) {
  if (PROTECTED_COMMANDS.has(commandName)) {
    return { allowed: true, reason: null };
  }
  if (isGuildManager(member, guildConfig)) {
    return { allowed: true, reason: null };
  }

  const entry = (guildConfig.commandPermissions || []).find((e) => e.commandName === commandName);
  if (!entry) {
    return { allowed: true, reason: null };
  }

  if (entry.deniedUserIds?.includes(member.id)) {
    return { allowed: false, reason: 'denied-user' };
  }
  if (entry.deniedRoleIds?.some((roleId) => member.roles.cache.has(roleId))) {
    return { allowed: false, reason: 'denied-role' };
  }
  if (channelId && entry.deniedChannelIds?.includes(channelId)) {
    return { allowed: false, reason: 'denied-channel' };
  }

  const hasAllowList =
    (entry.allowedUserIds?.length || 0) > 0 ||
    (entry.allowedRoleIds?.length || 0) > 0 ||
    (entry.allowedChannelIds?.length || 0) > 0;
  if (!hasAllowList) {
    return { allowed: true, reason: null };
  }

  const onAllowList =
    entry.allowedUserIds?.includes(member.id) ||
    entry.allowedRoleIds?.some((roleId) => member.roles.cache.has(roleId)) ||
    Boolean(channelId && entry.allowedChannelIds?.includes(channelId));

  return { allowed: Boolean(onAllowList), reason: onAllowList ? null : 'not-in-allowlist' };
}

/** Finds a guild's commandPermissions entry for `commandName`, creating an empty one in-place (not yet saved) if none exists. Shared by /permissions and /rolepermissions. */
function getOrCreateEntry(guildConfig, commandName) {
  let entry = guildConfig.commandPermissions.find((e) => e.commandName === commandName);
  if (!entry) {
    guildConfig.commandPermissions.push({
      commandName,
      allowedRoleIds: [],
      allowedUserIds: [],
      deniedRoleIds: [],
      deniedUserIds: [],
      allowedChannelIds: [],
      deniedChannelIds: [],
    });
    entry = guildConfig.commandPermissions[guildConfig.commandPermissions.length - 1];
  }
  return entry;
}

/** Adds `id` to `list` if not already present. Returns whether it changed anything. */
function addUnique(list, id) {
  if (list.includes(id)) return false;
  list.push(id);
  return true;
}

/** Removes `id` from `list` if present. Returns whether it changed anything. */
function removeIfPresent(list, id) {
  const idx = list.indexOf(id);
  if (idx === -1) return false;
  list.splice(idx, 1);
  return true;
}

/** Drops commandPermissions entries left with every list empty, so the array doesn't grow forever with dead weight after removals. */
function pruneEmptyEntries(guildConfig) {
  guildConfig.commandPermissions = guildConfig.commandPermissions.filter(
    (e) =>
      e.allowedRoleIds.length ||
      e.allowedUserIds.length ||
      e.deniedRoleIds.length ||
      e.deniedUserIds.length ||
      e.allowedChannelIds.length ||
      e.deniedChannelIds.length
  );
}

module.exports = { resolveCommandPermission, PROTECTED_COMMANDS, getOrCreateEntry, addUnique, removeIfPresent, pruneEmptyEntries };
