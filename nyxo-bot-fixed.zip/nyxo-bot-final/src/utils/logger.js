/**
 * Small dependency-free logger with timestamps and log levels.
 * Keeping this in-house avoids pulling in a heavy logging framework
 * for what is otherwise a simple console-based need.
 */
const COLORS = {
  reset: '\x1b[0m',
  gray: '\x1b[90m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  red: '\x1b[31m',
  cyan: '\x1b[36m',
  magenta: '\x1b[35m',
};

function timestamp() {
  return new Date().toISOString().replace('T', ' ').substring(0, 19);
}

function line(color, tag, msg) {
  console.log(`${COLORS.gray}[${timestamp()}]${COLORS.reset} ${color}${tag}${COLORS.reset} ${msg}`);
}

module.exports = {
  info: (msg) => line(COLORS.cyan, '[INFO]', msg),
  success: (msg) => line(COLORS.green, '[OK]', msg),
  warn: (msg) => line(COLORS.yellow, '[WARN]', msg),
  error: (msg) => line(COLORS.red, '[ERROR]', msg),
  event: (msg) => line(COLORS.magenta, '[EVENT]', msg),
};
