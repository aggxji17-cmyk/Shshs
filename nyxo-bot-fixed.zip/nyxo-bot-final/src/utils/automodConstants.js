/**
 * Single source of truth for the punishment types AutoMod supports, shared
 * by the GuildConfig schema (enum validation), autoModerationService.js
 * (execution) and the /automod command (choices + labels) - so the six
 * punishment types are only ever listed once in the whole codebase.
 */
const AUTOMOD_PUNISHMENTS = ['delete', 'warn', 'timeout', 'kick', 'ban', 'softban'];

const AUTOMOD_PUNISHMENT_LABELS = {
  delete: 'Delete Message',
  warn: 'Warn',
  timeout: 'Timeout',
  kick: 'Kick',
  ban: 'Ban',
  softban: 'Softban',
};

module.exports = { AUTOMOD_PUNISHMENTS, AUTOMOD_PUNISHMENT_LABELS };
