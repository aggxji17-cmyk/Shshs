const { useQueue } = require('discord-player');
const { errorEmbed } = require('./embeds');

/**
 * Ensures the invoking member is in a voice channel, and if the bot is
 * already playing somewhere in this guild, that they're in the *same*
 * channel. Replies with an error embed and returns null on failure.
 */
async function requireVoiceChannel(interaction, settings) {
  const channel = interaction.member?.voice?.channel;
  if (!channel) {
    await interaction.reply({ embeds: [errorEmbed(settings, 'Join a voice channel first.')], ephemeral: true });
    return null;
  }

  const queue = useQueue(interaction.guildId);
  if (queue?.channel && queue.channel.id !== channel.id) {
    await interaction.reply({ embeds: [errorEmbed(settings, `I'm already playing music in ${queue.channel}.`)], ephemeral: true });
    return null;
  }

  return channel;
}

/**
 * Fetches the active guild queue, replying with an error embed (and
 * returning null) if nothing is playing or the invoker isn't in the
 * bot's voice channel.
 */
async function requireActiveQueue(interaction, settings) {
  const queue = useQueue(interaction.guildId);
  if (!queue || !queue.currentTrack) {
    await interaction.reply({ embeds: [errorEmbed(settings, 'Nothing is playing right now.')], ephemeral: true });
    return null;
  }

  const memberChannel = interaction.member?.voice?.channel;
  if (!memberChannel || memberChannel.id !== queue.channel?.id) {
    await interaction.reply({ embeds: [errorEmbed(settings, `Join ${queue.channel} to control the music.`)], ephemeral: true });
    return null;
  }

  return queue;
}

module.exports = { requireVoiceChannel, requireActiveQueue };
