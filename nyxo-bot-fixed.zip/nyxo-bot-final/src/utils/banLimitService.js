const BanAction = require('../database/models/BanAction');
const { UNLIMITED, makeWeeklyLimitService } = require('./weeklyLimitService');

const service = makeWeeklyLimitService(BanAction, (guildConfig) => guildConfig?.moderation?.banLimits);

module.exports = {
  UNLIMITED,
  getMemberWeeklyBanLimit: service.getMemberWeeklyLimit,
  countBansThisWeek: service.countThisWeek,
  recordBan: service.recordAction,
};
