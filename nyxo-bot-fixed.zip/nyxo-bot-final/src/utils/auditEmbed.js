const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { baseEmbed } = require('./embeds');
const { formatCaseLine } = require('./caseEmbed');
const { RANGE_LABELS, SORT_LABELS } = require('./auditLabels');
const { getModeratorStats, getModeratorHistory, getUserStats, getUserHistory } = require('../services/auditService');

function statsFields(stats, total) {
  return [
    { name: '🔨 Ban', value: `${stats.ban}`, inline: true },
    { name: '👢 Kick', value: `${stats.kick}`, inline: true },
    { name: '⏱️ Timeout', value: `${stats.timeout}`, inline: true },
    { name: '⚠️ Warn', value: `${stats.warn}`, inline: true },
    { name: '🧹 Softban', value: `${stats.softban}`, inline: true },
    { name: '♻️ Unban', value: `${stats.unban}`, inline: true },
    { name: 'الإجمالي', value: `${total}`, inline: false },
  ];
}

function paginationRow(customIdPrefix, id, range, sort, page, totalPages) {
  if (totalPages <= 1) return [];
  return [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`${customIdPrefix}:${id}:${range}:${sort}:${page - 1}`)
        .setLabel('السابق')
        .setStyle(ButtonStyle.Secondary)
        .setDisabled(page <= 1),
      new ButtonBuilder()
        .setCustomId(`${customIdPrefix}:${id}:${range}:${sort}:${page + 1}`)
        .setLabel('التالي')
        .setStyle(ButtonStyle.Secondary)
        .setDisabled(page >= totalPages)
    ),
  ];
}

/** One page of a moderator's audit history (stats + list + paging) - used by /modhistory and its pagination button. */
async function buildModHistoryPage(settings, guildId, moderator, { range = 'all', sort = 'newest', page = 1 } = {}) {
  const [{ stats, total: statsTotal }, { cases, total, totalPages, page: safePage }] = await Promise.all([
    getModeratorStats(guildId, moderator.id, range),
    getModeratorHistory(guildId, moderator.id, { range, sort, page }),
  ]);

  const embed = baseEmbed(settings)
    .setTitle(`سجل الإشراف — ${moderator.tag}`)
    .addFields(...statsFields(stats, statsTotal))
    .setDescription(cases.length ? cases.map(formatCaseLine).join('\n\n') : 'لا توجد عمليات ضمن هذه الفترة.')
    .setFooter({
      text: `${settings.footer} • الفترة: ${RANGE_LABELS[range]} • الترتيب: ${SORT_LABELS[sort]} • صفحة ${safePage} من ${totalPages} • ${total} عملية`,
    });

  return { embed, components: paginationRow('modhistory_page', moderator.id, range, sort, safePage, totalPages) };
}

/** One page of a member's punishment record (stats + list + paging) - used by /userinfo's audit button and its pagination button. */
async function buildUserAuditPage(settings, guildId, target, { range = 'all', sort = 'newest', page = 1 } = {}) {
  const [{ stats, total: statsTotal }, { cases, total, totalPages, page: safePage }] = await Promise.all([
    getUserStats(guildId, target.id, range),
    getUserHistory(guildId, target.id, { range, sort, page }),
  ]);

  const embed = baseEmbed(settings)
    .setTitle(`سجل العقوبات — ${target.tag}`)
    .addFields(...statsFields(stats, statsTotal))
    .setDescription(cases.length ? cases.map(formatCaseLine).join('\n\n') : 'لا توجد عقوبات مسجلة ضمن هذه الفترة.')
    .setFooter({
      text: `${settings.footer} • الفترة: ${RANGE_LABELS[range]} • الترتيب: ${SORT_LABELS[sort]} • صفحة ${safePage} من ${totalPages} • ${total} عملية`,
    });

  return { embed, components: paginationRow('userinfo_audit_page', target.id, range, sort, safePage, totalPages) };
}

module.exports = { buildModHistoryPage, buildUserAuditPage };
