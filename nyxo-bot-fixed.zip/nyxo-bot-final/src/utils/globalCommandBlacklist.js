'use strict';

const BotConfig = require('../database/models/BotConfig');
const { PROTECTED_COMMANDS } = require('./commandPermissions');

const CACHE_TTL_MS = 30_000;
let cached = null; // { value, at }

/**
 * Fetches (and lightly caches) the one bot-wide BotConfig document,
 * creating it with defaults on first use - same find-or-create-plus-TTL-
 * cache shape as resolveGuildSettings.js's getGuildConfig, just for a
 * single global document instead of one per guild.
 */
async function getBotConfig() {
  if (cached && Date.now() - cached.at < CACHE_TTL_MS) {
    return cached.value;
  }

  let doc = await BotConfig.findById('singleton');
  if (!doc) {
    doc = await BotConfig.create({ _id: 'singleton' });
  }

  cached = { value: doc, at: Date.now() };
  return doc;
}

/** Drops the cached BotConfig so the next getBotConfig() re-reads from the database. */
function invalidateBotConfig() {
  cached = null;
}

/**
 * Whether `commandName` has been disabled everywhere by the bot owner
 * (via /globaldisable). This is the bluntest switch of all - it blocks
 * every server, every channel, every role, every user, with no
 * exceptions except PROTECTED_COMMANDS (permissions/rolepermissions/
 * blacklist), which can never be disabled this way so the bot can never
 * be locked out of its own management commands everywhere at once.
 *
 * @param {string} commandName
 * @param {*} botConfig - the BotConfig doc from getBotConfig()
 * @returns {boolean}
 */
function isCommandGloballyDisabled(commandName, botConfig) {
  if (PROTECTED_COMMANDS.has(commandName)) return false;
  return (botConfig.globalCommandBlacklist || []).includes(commandName);
}

/**
 * Toggles `commandName`'s globally-disabled status on botConfig. Does
 * not save the document; the caller still calls botConfig.save() and
 * invalidateBotConfig() itself, same as every other config mutation in
 * this codebase.
 *
 * @param {*} botConfig - the BotConfig doc from getBotConfig()
 * @param {string} commandName
 * @returns {boolean} whether the command is now globally disabled
 */
function toggleGlobalCommand(botConfig, commandName) {
  const list = botConfig.globalCommandBlacklist;
  const idx = list.indexOf(commandName);
  if (idx === -1) {
    list.push(commandName);
    return true;
  }
  list.splice(idx, 1);
  return false;
}

module.exports = { getBotConfig, invalidateBotConfig, isCommandGloballyDisabled, toggleGlobalCommand };
