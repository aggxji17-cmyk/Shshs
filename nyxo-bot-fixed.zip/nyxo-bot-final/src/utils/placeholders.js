/**
 * Replaces {user}, {username}, {server}, {memberCount}, {tag}, {ordinal}
 * placeholders in a configurable message template with real values from
 * a guild member.
 */
function applyPlaceholders(template, member) {
  if (!template) return '';
  return template
    .replaceAll('{user}', `<@${member.id}>`)
    .replaceAll('{username}', member.user.username)
    .replaceAll('{tag}', member.user.tag)
    .replaceAll('{server}', member.guild.name)
    .replaceAll('{memberCount}', member.guild.memberCount.toString())
    .replaceAll('{ordinal}', toOrdinal(member.guild.memberCount));
}

/** 1 -> "1st", 2 -> "2nd", 11 -> "11th", 21 -> "21st", ... */
function toOrdinal(n) {
  const rem100 = n % 100;
  if (rem100 >= 11 && rem100 <= 13) return `${n}th`;
  switch (n % 10) {
    case 1:
      return `${n}st`;
    case 2:
      return `${n}nd`;
    case 3:
      return `${n}rd`;
    default:
      return `${n}th`;
  }
}

module.exports = { applyPlaceholders };
