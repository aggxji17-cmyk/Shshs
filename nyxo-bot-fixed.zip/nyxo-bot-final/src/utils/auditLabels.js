/**
 * Shared date-range and sort options for the moderation audit system
 * (/modhistory, /userinfo). Defined once here so the slash command
 * `.addChoices(...)` calls and the embed footer labels can never drift
 * out of sync with each other.
 */

const RANGE_CHOICES = [
  { name: 'اليوم', value: 'today' },
  { name: 'آخر 7 أيام', value: '7d' },
  { name: 'آخر 30 يومًا', value: '30d' },
  { name: 'كل الوقت', value: 'all' },
];

const SORT_CHOICES = [
  { name: 'الأحدث', value: 'newest' },
  { name: 'الأقدم', value: 'oldest' },
  { name: 'نوع العقوبة', value: 'action' },
];

const RANGE_LABELS = Object.fromEntries(RANGE_CHOICES.map((c) => [c.value, c.name]));
const SORT_LABELS = Object.fromEntries(SORT_CHOICES.map((c) => [c.value, c.name]));

module.exports = { RANGE_CHOICES, SORT_CHOICES, RANGE_LABELS, SORT_LABELS };
