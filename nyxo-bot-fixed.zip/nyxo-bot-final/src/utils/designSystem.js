/**
 * NUXO Design System
 * ───────────────────
 * Single source of truth for the bot's visual identity: colors, icons and
 * small formatting helpers shared by every embed, button and message
 * across the project.
 *
 * This file introduces NO new behavior - it only centralizes presentation
 * values so every part of the bot pulls from the same palette/iconset
 * instead of hardcoding its own. Existing per-guild overrides (embedColor,
 * footer, etc. from resolveGuildSettings) still take priority wherever
 * they already did; this module only supplies the shared defaults and
 * status colors used for success/error/warning/info states.
 */

// ─── Palette ────────────────────────────────────────────────────────────
// Discord-native, dark/modern/premium. Status colors match Discord's own
// semantic palette so they feel native rather than custom.
const COLORS = {
  primary: '#5865F2', // Blurple - brand/default
  secondary: '#2B2D31', // Dark neutral - secondary surfaces
  success: '#57F287',
  error: '#ED4245',
  warning: '#FEE75C',
  info: '#5865F2',
  neutral: '#99AAB5',
};

// ─── Icons ──────────────────────────────────────────────────────────────
// Section icons (used as embed title prefixes) and status icons (used in
// message titles/descriptions). Kept centralized so every module reaches
// for the same emoji instead of picking its own ad hoc icon.
const ICONS = {
  // Status
  success: '✅',
  error: '❌',
  warning: '⚠️',
  info: 'ℹ️',
  loading: '⏳',
  question: '❓',

  // Sections
  tickets: '🎫',
  moderation: '🛡️',
  security: '🔐',
  music: '🎵',
  giveaway: '🎁',
  economy: '💰',
  stats: '📊',
  leaderboard: '🏆',
  minecraft: '🎮',
  settings: '⚙️',
  ai: '🤖',
  notifications: '🔔',
  members: '👥',
  logs: '📋',
};

// Small visual divider used to separate sections inside an embed
// description without relying on extra fields.
const DIVIDER = '─────────────────';

// ─── Button Style Guide ─────────────────────────────────────────────────
// Reference only (discord.js ButtonStyle is used directly at call sites,
// since components/buttons.js already imports it where needed). Documents
// the convention every button in the project should follow:
//   Success   -> Confirm / Accept / Enable / Approve
//   Danger    -> Delete / Ban / Kick / Close / Remove / Deny
//   Primary   -> Open / Manage / Setup / Continue / Next
//   Secondary -> Secondary/alternate choices, Cancel

// ─── Helpers ────────────────────────────────────────────────────────────

/**
 * Prefixes a title with a section icon in the "icon・Title" style used
 * throughout the redesign (e.g. "🎫・Support Center").
 */
function sectionTitle(icon, title) {
  return `${icon}・${title}`;
}

module.exports = { COLORS, ICONS, DIVIDER, sectionTitle };
