const KickAction = require('../database/models/KickAction');
const { UNLIMITED, makeWeeklyLimitService } = require('./weeklyLimitService');

const service = makeWeeklyLimitService(KickAction, (guildConfig) => guildConfig?.moderation?.kickLimits);

module.exports = {
  UNLIMITED,
  getMemberWeeklyKickLimit: service.getMemberWeeklyLimit,
  countKicksThisWeek: service.countThisWeek,
  recordKick: service.recordAction,
};
