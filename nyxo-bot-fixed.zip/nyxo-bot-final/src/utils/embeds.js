const { EmbedBuilder } = require('discord.js');
const { COLORS, ICONS } = require('./designSystem');

/**
 * Builds a base embed pre-styled with the resolved guild color/footer so
 * every command produces a visually consistent result.
 * @param {ReturnType<typeof import('./resolveGuildSettings').resolved>} settings
 */
function baseEmbed(settings) {
  return new EmbedBuilder()
    .setColor(settings.embedColor)
    .setFooter({ text: settings.footer })
    .setTimestamp();
}

function successEmbed(settings, description) {
  return baseEmbed(settings).setDescription(`${ICONS.success} ${description}`).setColor(COLORS.success);
}

function errorEmbed(settings, description) {
  return baseEmbed(settings).setDescription(`${ICONS.error} ${description}`).setColor(COLORS.error);
}

function infoEmbed(settings, description) {
  return baseEmbed(settings).setDescription(`${ICONS.info} ${description}`).setColor(COLORS.info);
}

// ─── New general-purpose helpers (additive, same baseEmbed foundation) ──
// These follow the same call signature as the helpers above so they slot
// into any existing command exactly the same way.

function warningEmbed(settings, description) {
  return baseEmbed(settings).setDescription(`${ICONS.warning} ${description}`).setColor(COLORS.warning);
}

function loadingEmbed(settings, description) {
  return baseEmbed(settings).setDescription(`${ICONS.loading} ${description || 'Processing…'}`).setColor(COLORS.neutral);
}

module.exports = { baseEmbed, successEmbed, errorEmbed, infoEmbed, warningEmbed, loadingEmbed };
