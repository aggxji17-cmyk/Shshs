const UNIT_MS = { s: 1000, m: 60_000, h: 3_600_000, d: 86_400_000, w: 604_800_000 };

/**
 * Parses strings like "10m", "2h30m", "1d" into milliseconds. Returns
 * null if the string has no valid duration segments. Same format as
 * /remindme, so users only have to learn it once.
 */
function parseDuration(input) {
  const matches = [...String(input).toLowerCase().matchAll(/(\d+)\s*(s|m|h|d|w)/g)];
  if (!matches.length) return null;
  return matches.reduce((total, [, amount, unit]) => total + Number(amount) * UNIT_MS[unit], 0);
}

module.exports = { parseDuration };
