const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { baseEmbed } = require('./embeds');
const { ACTION_LABELS, ACTION_COLORS, STATUS_LABELS } = require('./caseLabels');
const { getCasesForUser } = require('../services/caseService');

function ts(date, style = 'R') {
  return `<t:${Math.floor(new Date(date).getTime() / 1000)}:${style}>`;
}

/** Full detail embed for a single Case - used by /case and /editcase's confirmation. */
function buildCaseEmbed(settings, caseDoc) {
  const embed = baseEmbed(settings)
    .setTitle(`${ACTION_LABELS[caseDoc.action] || caseDoc.action} — Case #${caseDoc.caseId}`)
    .setColor(ACTION_COLORS[caseDoc.action] || settings.embedColor)
    .addFields(
      { name: 'المشرف', value: `<@${caseDoc.moderatorId}> (\`${caseDoc.moderatorId}\`)`, inline: true },
      { name: 'العضو', value: `<@${caseDoc.targetId}> (\`${caseDoc.targetId}\`)`, inline: true },
      { name: 'الحالة', value: STATUS_LABELS[caseDoc.status] || caseDoc.status, inline: true }
    );

  if (typeof caseDoc.durationMinutes === 'number') {
    embed.addFields({ name: 'المدة', value: `${caseDoc.durationMinutes} دقيقة`, inline: true });
  }

  embed.addFields({ name: 'السبب', value: caseDoc.reason || 'لا يوجد سبب محدد' });

  if (caseDoc.notes) {
    embed.addFields({ name: 'ملاحظات', value: caseDoc.notes });
  }

  if (caseDoc.status !== 'Active') {
    const revertLine = [
      caseDoc.revertedBy === 'system' ? 'تلقائيًا (انتهاء المدة)' : caseDoc.revertedBy ? `بواسطة <@${caseDoc.revertedBy}>` : null,
      caseDoc.revertedAt ? ts(caseDoc.revertedAt) : null,
      caseDoc.revertReason ? `السبب: ${caseDoc.revertReason}` : null,
    ]
      .filter(Boolean)
      .join(' • ');
    if (revertLine) embed.addFields({ name: 'تم الإغلاق', value: revertLine });
  }

  embed.addFields({ name: 'التاريخ', value: ts(caseDoc.createdAt, 'F') });

  return embed;
}

/** One-line summary of a Case for list views like /cases. */
function formatCaseLine(caseDoc) {
  const label = ACTION_LABELS[caseDoc.action] || caseDoc.action;
  const status = STATUS_LABELS[caseDoc.status] || caseDoc.status;
  return (
    `**#${caseDoc.caseId}** • ${label} • ${status}\n` +
    `المشرف: <@${caseDoc.moderatorId}> • ${ts(caseDoc.createdAt)}\n` +
    `${caseDoc.reason || 'لا يوجد سبب محدد'}`
  );
}

/**
 * Builds one page of a member's Case history: the list embed plus a
 * Previous/Next button row. Shared by the /cases command and the
 * cases_page button handler so paging never re-implements this logic.
 */
async function buildCasesPage(settings, guildId, target, page) {
  const { cases, total, totalPages, page: safePage } = await getCasesForUser(guildId, target.id, page);

  const embed = baseEmbed(settings)
    .setTitle(`قضايا ${target.tag}`)
    .setDescription(cases.length ? cases.map(formatCaseLine).join('\n\n') : 'لا توجد قضايا مسجلة لهذا العضو.')
    .setFooter({ text: `${settings.footer} • صفحة ${safePage} من ${totalPages} • ${total} قضية` });

  const components = [];
  if (totalPages > 1) {
    components.push(
      new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId(`cases_page:${target.id}:${safePage - 1}`)
          .setLabel('السابق')
          .setStyle(ButtonStyle.Secondary)
          .setDisabled(safePage <= 1),
        new ButtonBuilder()
          .setCustomId(`cases_page:${target.id}:${safePage + 1}`)
          .setLabel('التالي')
          .setStyle(ButtonStyle.Secondary)
          .setDisabled(safePage >= totalPages)
      )
    );
  }

  return { embed, components };
}

module.exports = { buildCaseEmbed, formatCaseLine, buildCasesPage };
