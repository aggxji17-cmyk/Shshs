const { baseEmbed } = require('./embeds');

/**
 * Posts a standardized embed to the guild's logging channel, if logging is
 * enabled and configured. Silently no-ops otherwise so callers never need
 * to guard every call site with the same enabled/channelId checks.
 */
async function sendModLog(guild, guildConfig, settings, { title, description, fields, color }) {
  if (!guildConfig.logging?.enabled || !guildConfig.logging.channelId) return;

  const channel = guild.channels.cache.get(guildConfig.logging.channelId);
  if (!channel) return;

  const embed = baseEmbed(settings).setTitle(title);
  if (description) embed.setDescription(description);
  if (fields?.length) embed.addFields(fields);
  if (color) embed.setColor(color);

  await channel.send({ embeds: [embed] }).catch(() => null);
}

module.exports = { sendModLog };
