/** The server owner can never be the target of a moderation action. */
function isServerOwner(guild, targetId) {
  return targetId === guild.ownerId;
}

/**
 * True if `member`'s highest role is above or equal to the executor's
 * highest role, meaning the executor is not allowed to act on them. The
 * server owner bypasses this check (they outrank everyone by definition).
 * `member` may be null (target not in the guild) - then there is nothing
 * to compare, so this returns false.
 */
function outranksExecutor(interaction, member) {
  if (!member) return false;
  if (interaction.user.id === interaction.guild.ownerId) return false;
  return member.roles.highest.position >= interaction.member.roles.highest.position;
}

module.exports = { isServerOwner, outranksExecutor };
