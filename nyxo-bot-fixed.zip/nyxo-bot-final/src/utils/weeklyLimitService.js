const UNLIMITED = Infinity;

/**
 * Start of the "current week", Monday 00:00:00 UTC. Every count query
 * filters on `createdAt >= startOfWeek()`, so quotas reset themselves the
 * moment Monday ticks over - no cron job or manual reset needed.
 */
function startOfWeek(date = new Date()) {
  const d = new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate()));
  const day = d.getUTCDay(); // 0 = Sunday ... 6 = Saturday
  const diffToMonday = (day + 6) % 7; // days since the most recent Monday
  d.setUTCDate(d.getUTCDate() - diffToMonday);
  return d;
}

/**
 * Builds a weekly-limit service backed by `Model` (a mongoose model with
 * guildId/moderatorId/targetId/reason + timestamps, e.g. BanAction or
 * KickAction) and `getLimitConfig(guildConfig)`, which should return
 * `{ enabled, perRole: [{ roleId, weeklyLimit }] }` for that action.
 *
 * Shared by banLimitService.js and kickLimitService.js so the quota math
 * and the weekly-reset logic only exist in one place.
 */
function makeWeeklyLimitService(Model, getLimitConfig) {
  /**
   * Resolves the weekly quota that applies to `member`. Returns UNLIMITED
   * when the feature is off, the member holds none of the configured
   * roles, or any matching role is itself set to unlimited (-1). Otherwise
   * returns the highest weeklyLimit among the member's matching roles.
   */
  function getMemberWeeklyLimit(member, guildConfig) {
    const config = getLimitConfig(guildConfig);
    if (!config?.enabled || !config.perRole?.length) return UNLIMITED;

    const matching = config.perRole.filter((entry) => member.roles.cache.has(entry.roleId));
    if (matching.length === 0) return UNLIMITED;
    if (matching.some((entry) => entry.weeklyLimit < 0)) return UNLIMITED;

    return Math.max(...matching.map((entry) => entry.weeklyLimit));
  }

  /** Counts actions `moderatorId` has executed in this guild since the start of the current week. */
  async function countThisWeek(guildId, moderatorId) {
    return Model.countDocuments({ guildId, moderatorId, createdAt: { $gte: startOfWeek() } });
  }

  /**
   * Records a completed action so it counts toward the moderator's weekly
   * quota. `extraFields` lets callers store action-specific data (e.g.
   * timeout's `durationMinutes`) without changing this shared signature.
   */
  async function recordAction(guildId, moderatorId, targetId, reason, extraFields = {}) {
    return Model.create({ guildId, moderatorId, targetId, reason, ...extraFields });
  }

  return { UNLIMITED, getMemberWeeklyLimit, countThisWeek, recordAction };
}

module.exports = { UNLIMITED, startOfWeek, makeWeeklyLimitService };
