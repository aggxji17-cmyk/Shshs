const { config } = require('../config/config');

function isOwner(userId) {
  return config.ownerIds.includes(userId);
}

/**
 * A member "manages" a guild's config if they own the bot, have
 * Administrator, Manage Guild permission, or hold the configured admin role.
 */
function isGuildManager(member, guildConfig) {
  if (!member) return false;
  if (isOwner(member.id)) return true;
  if (member.permissions.has('Administrator')) return true;
  if (member.permissions.has('ManageGuild')) return true;
  if (guildConfig?.adminRoleId && member.roles.cache.has(guildConfig.adminRoleId)) return true;
  return false;
}

/**
 * A member counts as "staff" (moderator-tier) if they manage the guild, or
 * hold the configured moderator role.
 */
function isModerator(member, guildConfig) {
  if (isGuildManager(member, guildConfig)) return true;
  if (guildConfig?.modRoleId && member.roles.cache.has(guildConfig.modRoleId)) return true;
  return false;
}

module.exports = { isOwner, isGuildManager, isModerator };
