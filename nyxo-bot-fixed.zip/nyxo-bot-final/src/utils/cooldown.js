'use strict';

/**
 * Lightweight in-memory per-user, per-command cooldown guard.
 *
 * This exists purely to smooth out the next few seconds of UX - it
 * catches a user double-tapping a command, an impatient re-submit while
 * the bot is still processing the first one, or someone spamming a
 * moderation command in frustration (which, without this, could create
 * duplicate cases/warns/giveaway-ends). It is intentionally NOT a
 * permission system and NOT persisted to the database: a restart
 * clearing it is fine, since its only job is short-term debouncing.
 *
 * Every command gets DEFAULT_SECONDS automatically with zero changes to
 * the command file. A command can opt into a custom window by exporting
 * `cooldownSeconds` (e.g. a cheap read-only command might set it to 1,
 * a heavier one to 5), or opt all the way out with `cooldownSeconds: 0`.
 */

const DEFAULT_SECONDS = 3;

// commandName -> Map<userId, expiresAtMs>
const buckets = new Map();

/**
 * Checks whether `userId` is currently on cooldown for `commandName`.
 * If not (or their previous cooldown already expired), this starts a
 * fresh window and returns null - the command may proceed. If they are
 * still inside a window, the timer is left untouched and the number of
 * whole seconds remaining is returned instead.
 *
 * @param {string} commandName
 * @param {string} userId
 * @param {number} seconds - window length; 0 or negative disables the check entirely
 * @returns {number|null} seconds remaining, or null if the command may proceed
 */
function check(commandName, userId, seconds = DEFAULT_SECONDS) {
  if (!seconds || seconds <= 0) return null;

  let bucket = buckets.get(commandName);
  if (!bucket) {
    bucket = new Map();
    buckets.set(commandName, bucket);
  }

  const now = Date.now();
  const expiresAt = bucket.get(userId);

  if (expiresAt && expiresAt > now) {
    return Math.ceil((expiresAt - now) / 1000);
  }

  bucket.set(userId, now + seconds * 1000);
  return null;
}

// Periodic sweep so a long-running process doesn't slowly accumulate
// stale per-user entries for users who only ever ran a command once.
// unref() so this timer never keeps the process alive on its own.
const sweepTimer = setInterval(() => {
  const now = Date.now();
  for (const bucket of buckets.values()) {
    for (const [userId, expiresAt] of bucket) {
      if (expiresAt <= now) bucket.delete(userId);
    }
  }
}, 5 * 60_000);
sweepTimer.unref();

module.exports = { check, DEFAULT_SECONDS };
