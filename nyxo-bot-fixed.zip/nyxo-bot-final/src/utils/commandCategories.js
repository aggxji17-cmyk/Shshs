'use strict';

/**
 * Groups every loaded command by its `.category` (set by
 * handlers/commandHandler.js from the command file's parent folder).
 * Reads straight from the live client.commands Collection, same
 * philosophy as utils/autocomplete.js's commandNameChoices - there is
 * no separate category list to keep in sync by hand.
 *
 * @param {import('discord.js').Client} client
 * @returns {Map<string, string[]>} category name -> command names in it
 */
function getCommandsByCategory(client) {
  const map = new Map();
  for (const command of client.commands.values()) {
    const category = command.category || 'uncategorized';
    if (!map.has(category)) map.set(category, []);
    map.get(category).push(command.data.name);
  }
  for (const names of map.values()) names.sort();
  return map;
}

/** Sorted list of every distinct category currently loaded. */
function getCategoryNames(client) {
  return [...getCommandsByCategory(client).keys()].sort();
}

module.exports = { getCommandsByCategory, getCategoryNames };
