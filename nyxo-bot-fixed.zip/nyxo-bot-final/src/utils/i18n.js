const fs = require('fs');
const path = require('path');

/**
 * Task 6: بوت -> يدعم العربية والإنجليزية / plugin -> English only (see
 * NovaBridge's Java source, already all-English, nothing to change there).
 *
 * Every user-facing string the bot sends goes through `t(lang, key, vars)`
 * instead of being hardcoded in one language. Translations live in
 * `src/lang/<code>.json` - one flat-ish, dot-nested JSON file per
 * language, same key shape in every file.
 *
 * Adding a new language later is exactly two steps, nothing else in the
 * codebase needs to change:
 *   1. Drop `src/lang/<code>.json` with the same keys as `en.json`.
 *   2. Add `<code>` to `SUPPORTED_LANGUAGES` below.
 * Every existing `t(lang, key)` call site keeps working immediately -
 * missing keys in a new/incomplete file just fall back to English (see
 * `t()`) instead of throwing or printing `undefined`.
 */

const SUPPORTED_LANGUAGES = ['ar', 'en'];
const DEFAULT_LANGUAGE = 'en';

const LANG_DIR = path.join(__dirname, '..', 'lang');

const dictionaries = {};
for (const lang of SUPPORTED_LANGUAGES) {
  const file = path.join(LANG_DIR, `${lang}.json`);
  dictionaries[lang] = JSON.parse(fs.readFileSync(file, 'utf8'));
}

function getByPath(obj, key) {
  return key.split('.').reduce((acc, part) => (acc && typeof acc === 'object' ? acc[part] : undefined), obj);
}

function interpolate(str, vars) {
  if (!vars) return str;
  return str.replace(/\{(\w+)\}/g, (match, name) => (name in vars ? String(vars[name]) : match));
}

/**
 * Translates `key` (dot path, e.g. "shop.purchased") into `lang`.
 * Falls back to English if `lang` is unsupported or the key is missing
 * from that language's file, and as a last resort returns the raw key
 * (never `undefined`, so a missing translation is visible/debuggable in
 * the actual Discord message instead of silently breaking the reply).
 *
 * @param {string} lang - one of SUPPORTED_LANGUAGES
 * @param {string} key - dot-path into the language JSON, e.g. "shop.empty"
 * @param {Record<string, string|number>} [vars] - `{name}` placeholders to fill in
 */
function t(lang, key, vars) {
  const normalized = SUPPORTED_LANGUAGES.includes(lang) ? lang : DEFAULT_LANGUAGE;

  let str = getByPath(dictionaries[normalized], key);
  if (str === undefined && normalized !== DEFAULT_LANGUAGE) {
    str = getByPath(dictionaries[DEFAULT_LANGUAGE], key);
  }
  if (str === undefined) return key;

  return interpolate(str, vars);
}

// Discord locale codes (interaction.locale) -> our language codes. Only
// the ones we actually have a dictionary for need an entry; anything
// else falls through to DEFAULT_LANGUAGE in resolveLanguage().
const DISCORD_LOCALE_MAP = { ar: 'ar' };

/**
 * Picks which language to reply in, in priority order:
 *   1. An explicit per-guild override (`GuildConfig.language`, set via
 *      `/language set`) - a guild manager's choice always wins.
 *   2. The invoking member's own Discord client language
 *      (`interaction.locale`), when it's a language we support.
 *   3. DEFAULT_LANGUAGE.
 *
 * @param {object} [params]
 * @param {{language?: string|null}} [params.guildConfigDoc]
 * @param {import('discord.js').Interaction} [params.interaction]
 */
function resolveLanguage({ guildConfigDoc, interaction } = {}) {
  if (guildConfigDoc?.language && SUPPORTED_LANGUAGES.includes(guildConfigDoc.language)) {
    return guildConfigDoc.language;
  }

  const discordLocale = interaction?.locale;
  const base = discordLocale?.split('-')[0];
  if (base && DISCORD_LOCALE_MAP[base]) {
    return DISCORD_LOCALE_MAP[base];
  }

  return DEFAULT_LANGUAGE;
}

module.exports = { t, resolveLanguage, SUPPORTED_LANGUAGES, DEFAULT_LANGUAGE };
