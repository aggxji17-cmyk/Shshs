/**
 * Looks up the most recent matching audit log entry for a given event type
 * and target, returning the executor's user ID if found within 10 seconds
 * (to avoid misattributing unrelated historical actions).
 */
async function fetchExecutorId(guild, auditLogEvent, targetId) {
  try {
    const logs = await guild.fetchAuditLogs({ type: auditLogEvent, limit: 5 });
    const entry = logs.entries.find(
      (e) => (!targetId || e.target?.id === targetId) && Date.now() - e.createdTimestamp < 10000
    );
    return entry?.executor?.id || null;
  } catch {
    return null;
  }
}

module.exports = { fetchExecutorId };
