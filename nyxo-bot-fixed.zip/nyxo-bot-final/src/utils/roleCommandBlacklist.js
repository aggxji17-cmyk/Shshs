'use strict';

const { PROTECTED_COMMANDS } = require('./commandPermissions');

/**
 * Whether `commandName` has been disabled for any role `member` holds,
 * via /blacklist role (guildConfig.roleCommandBlacklist). Same blunt,
 * blocks-everyone switch as channelCommandBlacklist - even guild
 * managers are blocked if they hold the role, exactly like
 * commandBlacklist.commandNames blocks everyone guild-wide.
 *
 * PROTECTED_COMMANDS (permissions/rolepermissions/blacklist - the same
 * set commandPermissions.js protects) can never be disabled this way,
 * so a management command can never be locked out for every holder of
 * a role by mistake.
 *
 * @param {string} commandName
 * @param {import('discord.js').GuildMember} member
 * @param {*} guildConfig - raw GuildConfig mongoose doc
 * @returns {boolean}
 */
function isCommandDisabledForMember(commandName, member, guildConfig) {
  if (PROTECTED_COMMANDS.has(commandName)) return false;
  return (guildConfig.roleCommandBlacklist || []).some(
    (entry) => entry.commandNames.includes(commandName) && member.roles.cache.has(entry.roleId)
  );
}

/**
 * Toggles `commandName`'s disabled status for `roleId` on guildConfig,
 * creating the role's entry if this is its first disabled command, and
 * dropping the entry again if this was its last one - so the array
 * doesn't grow forever with empty entries. Does not save the document;
 * callers still call guildConfig.save() themselves, same as every other
 * guildConfig mutation in this codebase.
 *
 * @param {*} guildConfig - raw GuildConfig mongoose doc
 * @param {string} commandName
 * @param {string} roleId
 * @returns {boolean} whether the command is now disabled for that role
 */
function toggleCommandForRole(guildConfig, commandName, roleId) {
  let entry = guildConfig.roleCommandBlacklist.find((e) => e.roleId === roleId);
  if (!entry) {
    guildConfig.roleCommandBlacklist.push({ roleId, commandNames: [] });
    entry = guildConfig.roleCommandBlacklist[guildConfig.roleCommandBlacklist.length - 1];
  }

  const idx = entry.commandNames.indexOf(commandName);
  const nowDisabled = idx === -1;
  if (nowDisabled) {
    entry.commandNames.push(commandName);
  } else {
    entry.commandNames.splice(idx, 1);
  }

  // Drop role entries left with an empty list, same reasoning as
  // commandPermissions.js's pruneEmptyEntries.
  guildConfig.roleCommandBlacklist = guildConfig.roleCommandBlacklist.filter((e) => e.commandNames.length);

  return nowDisabled;
}

module.exports = { isCommandDisabledForMember, toggleCommandForRole };
