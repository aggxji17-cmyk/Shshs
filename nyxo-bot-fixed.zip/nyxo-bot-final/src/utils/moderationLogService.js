const { baseEmbed } = require('./embeds');
const { ACTION_LABELS, ACTION_COLORS } = require('./caseLabels');

/**
 * Posts a standardized moderation-action embed to the guild's dedicated
 * moderation log channel (guildConfig.moderationLogChannelId). Every
 * moderation command (ban/kick/timeout/warn/unban/softban, and any future
 * one) should call this after a successful action instead of building its
 * own embed - that's the whole point of this module.
 *
 * Silently no-ops if no log channel is configured, the channel no longer
 * exists, or the bot can't post there - callers never need to guard for
 * that themselves, and a logging hiccup never breaks the moderation
 * command itself.
 *
 * @param {import('discord.js').Guild} guild
 * @param {*} guildConfig - the raw GuildConfig mongoose doc
 * @param {*} settings - resolved() settings, for embed color/footer
 * @param {object} details
 * @param {'ban'|'kick'|'timeout'|'warn'|'unban'|'softban'} details.action
 * @param {import('discord.js').User} details.moderator - who performed the action
 * @param {import('discord.js').User} details.target - who the action was performed on
 * @param {string} [details.reason]
 * @param {number} [details.durationMinutes] - timeout duration, only for 'timeout'
 * @param {number} [details.caseId] - the Case number (services/caseService.js) tied to this action, shown in every log entry so it can be looked up later via /case
 * @param {{ used: number, limit: number }} [details.weeklyQuota] - only when a weekly limit is enforced for this action
 * @param {{ name: string, value: string, inline?: boolean }[]} [details.extraFields] - extra embed fields for actions that don't fit moderator/target/reason alone (e.g. temprole's role field), appended after "السبب"
 */
async function sendModerationLog(guild, guildConfig, settings, details) {
  const channelId = guildConfig.moderationLogChannelId;
  if (!channelId) return;

  const channel = guild.channels.cache.get(channelId);
  if (!channel) return;

  const { action, moderator, target, reason, durationMinutes, caseId, weeklyQuota, extraFields } = details;

  const title = ACTION_LABELS[action] || action;
  const embed = baseEmbed(settings)
    .setTitle(typeof caseId === 'number' ? `${title} — Case #${caseId}` : title)
    .setColor(ACTION_COLORS[action] || settings.embedColor)
    .addFields(
      { name: 'المشرف', value: `${moderator} (\`${moderator.id}\`)`, inline: true },
      { name: 'العضو', value: `${target} (\`${target.id}\`)`, inline: true }
    );

  if (typeof durationMinutes === 'number') {
    embed.addFields({ name: 'المدة', value: `${durationMinutes} دقيقة`, inline: true });
  }

  embed.addFields({ name: 'السبب', value: reason || 'لا يوجد سبب محدد' });

  if (typeof caseId === 'number') {
    embed.addFields({ name: 'رقم القضية', value: `#${caseId}`, inline: true });
  }

  if (weeklyQuota) {
    const remaining = Math.max(weeklyQuota.limit - weeklyQuota.used, 0);
    embed.addFields({ name: 'المتبقي هذا الأسبوع', value: `${remaining} من أصل ${weeklyQuota.limit}`, inline: true });
  }

  if (Array.isArray(extraFields) && extraFields.length) {
    embed.addFields(extraFields);
  }

  // baseEmbed() already calls setTimestamp(), covering "الوقت".
  await channel.send({ embeds: [embed] }).catch(() => null);
}

module.exports = { sendModerationLog };
