require('./legacy/compat');

const path = require('node:path');
const { REST, Routes } = require('discord.js');
const { config, validateConfig } = require('./config/config');
const logger = require('./utils/logger');
const loadCommands = require('./handlers/commandHandler');
const { Collection } = require('discord.js');

validateConfig();

if (!config.clientId) {
  logger.error('[DEPLOY] CLIENT_ID is missing in .env - required to register slash commands.');
  process.exit(1);
}

async function deploy() {
  const commandClient = { commands: new Collection() };
  loadCommands(commandClient);
  const commands = [...commandClient.commands.values()].map((command) => command.data.toJSON());

  const rest = new REST().setToken(config.token);

  logger.info(`Registering ${commands.length} application commands (slash + context menu)...`);

  const guildId = process.argv[2];
  if (guildId) {
    // Guild-scoped registration - instant, ideal for development.
    await rest.put(Routes.applicationGuildCommands(config.clientId, guildId), { body: commands });
    logger.success(`Registered commands to guild ${guildId} (instant).`);
  } else {
    // Global registration - can take up to an hour to propagate.
    await rest.put(Routes.applicationCommands(config.clientId), { body: commands });
    logger.success('Registered global commands (may take up to an hour to appear).');
  }
}

deploy().catch((err) => {
  logger.error(`Failed to deploy commands: ${err.stack || err}`);
  process.exit(1);
});
