const UserLevel = require('../database/models/UserLevel');

/**
 * XP required to reach a given level. Uses a common quadratic curve so
 * early levels come quickly and later levels take progressively longer.
 */
function xpForLevel(level) {
  return 5 * level ** 2 + 50 * level + 100;
}

function levelFromXp(xp) {
  let level = 0;
  while (xp >= xpForLevel(level)) {
    xp -= xpForLevel(level);
    level += 1;
  }
  return level;
}

/**
 * Awards XP to a user for sending a message, respecting a per-user cooldown.
 * Returns { leveledUp, newLevel } if applicable so the caller can announce it.
 */
async function grantMessageXp(guildId, userId, xpAmount, cooldownSeconds) {
  const doc = await UserLevel.findOneAndUpdate(
    { guildId, userId },
    { $setOnInsert: { xp: 0, level: 0, messages: 0 } },
    { upsert: true, new: true }
  );

  const now = Date.now();
  const last = doc.lastMessageAt ? doc.lastMessageAt.getTime() : 0;
  if (now - last < cooldownSeconds * 1000) {
    return { leveledUp: false };
  }

  const previousLevel = doc.level;
  doc.xp += xpAmount;
  doc.messages += 1;
  doc.lastMessageAt = new Date(now);
  doc.level = levelFromXp(doc.xp);
  await doc.save();

  return { leveledUp: doc.level > previousLevel, newLevel: doc.level, doc };
}

async function getLeaderboard(guildId, limit = 10) {
  return UserLevel.find({ guildId }).sort({ xp: -1 }).limit(limit).lean();
}

async function getRank(guildId, userId) {
  const doc = await UserLevel.findOne({ guildId, userId }).lean();
  if (!doc) return null;
  const higherCount = await UserLevel.countDocuments({ guildId, xp: { $gt: doc.xp } });
  return { doc, rank: higherCount + 1 };
}

module.exports = { xpForLevel, levelFromXp, grantMessageXp, getLeaderboard, getRank };
