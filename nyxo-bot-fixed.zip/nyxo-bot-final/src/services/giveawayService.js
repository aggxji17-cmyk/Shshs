const { EmbedBuilder } = require('discord.js');
const Giveaway = require('../database/models/Giveaway');
const { getGuildConfig, resolved } = require('../utils/resolveGuildSettings');
const { baseEmbed } = require('../utils/embeds');
const logger = require('../utils/logger');

function pickWinners(participantIds, winnerCount) {
  const pool = [...participantIds];
  const winners = [];
  while (pool.length && winners.length < winnerCount) {
    const index = Math.floor(Math.random() * pool.length);
    winners.push(pool.splice(index, 1)[0]);
  }
  return winners;
}

function mentionList(userIds) {
  return userIds.map((id) => `<@${id}>`).join(', ');
}

async function endGiveaway(client, messageId) {
  const giveaway = await Giveaway.findOne({ messageId });
  if (!giveaway || giveaway.ended) return;

  giveaway.ended = true;
  await giveaway.save();

  const channel = await client.channels.fetch(giveaway.channelId).catch(() => null);
  if (!channel) return;

  const message = await channel.messages.fetch(giveaway.messageId).catch(() => null);
  const guildConfig = await getGuildConfig(giveaway.guildId);
  const settings = resolved(guildConfig);

  const winners = pickWinners(giveaway.participantIds, giveaway.winnerCount);

  const resultEmbed = baseEmbed(settings)
    .setTitle('🎉 Giveaway Ended')
    .setDescription(
      winners.length
        ? `**Prize:** ${giveaway.prize}\n**Winner(s):** ${mentionList(winners)}`
        : `**Prize:** ${giveaway.prize}\nNo valid entries - no winner could be chosen.`
    );

  if (message) {
    await message.edit({ embeds: [resultEmbed], components: [] }).catch(() => null);
  }

  if (winners.length) {
    channel
      .send({ content: `Congratulations ${mentionList(winners)}! You won **${giveaway.prize}**!` })
      .catch(() => null);
  }
}

async function rerollGiveaway(client, messageId) {
  const giveaway = await Giveaway.findOne({ messageId });
  if (!giveaway) return null;

  const winners = pickWinners(giveaway.participantIds, giveaway.winnerCount);
  const channel = await client.channels.fetch(giveaway.channelId).catch(() => null);
  if (channel && winners.length) {
    channel
      .send({ content: `🎉 New winner(s) for **${giveaway.prize}**: ${mentionList(winners)}!` })
      .catch(() => null);
  }
  return winners;
}

/**
 * Called once on startup and then periodically; catches giveaways that
 * expired while the bot was offline and ends any that are now due.
 */
function startGiveawayScheduler(client) {
  const check = async () => {
    try {
      const due = await Giveaway.find({ ended: false, endsAt: { $lte: new Date() } });
      for (const g of due) {
        await endGiveaway(client, g.messageId);
      }
    } catch (err) {
      logger.error(`Giveaway scheduler error: ${err.message}`);
    }
  };

  check();
  setInterval(check, 15_000);
}

module.exports = { endGiveaway, rerollGiveaway, startGiveawayScheduler };
