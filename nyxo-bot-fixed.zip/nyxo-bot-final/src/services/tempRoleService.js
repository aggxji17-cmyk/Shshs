const scheduleService = require('./scheduleService');
const { getGuildConfig, resolved } = require('../utils/resolveGuildSettings');
const { sendModerationLog } = require('../utils/moderationLogService');
const logger = require('../utils/logger');

const ACTION = 'temprole_remove';

/**
 * Posts the "Temp Role Added"/"Temp Role Removed" moderation-log embed via
 * the shared utils/moderationLogService.js - the same module every other
 * moderation action logs through - so temprole entries look and behave
 * exactly like the rest of the log channel. No Case is ever attached
 * (caseId omitted): a temp role is not a punishment (see database/models/
 * Case.js's action enum, which intentionally has no room for it).
 */
async function logTempRoleAction(client, guild, task, action, actorId = task.moderatorId) {
  const guildConfig = await getGuildConfig(task.guildId);
  const settings = resolved(guildConfig);
  const moderator = await client.users.fetch(actorId).catch(() => null);
  const target = await client.users.fetch(task.targetId).catch(() => null);
  if (!moderator || !target) return;

  await sendModerationLog(guild, guildConfig, settings, {
    action,
    moderator,
    target,
    reason: task.reason,
    extraFields: [{ name: 'الرتبة', value: `<@&${task.roleId}> (\`${task.roleId}\`)`, inline: true }],
  });
}

/**
 * The scheduleService handler for the 'temprole_remove' action - runs when
 * a temp role's executeAt is reached. Registered below via
 * scheduleService.registerHandler, so the generic poller in
 * scheduleService.js (pollAndExecute/runTask) picks it up exactly like
 * ban/kick/timeout/unban/message, with no changes needed to that file.
 *
 * Returns null (no Case) either way, same convention as executeMessage in
 * scheduleService.js.
 */
async function executeTempRoleRemoval(client, task) {
  const guild = await client.guilds.fetch(task.guildId).catch(() => null);
  if (!guild) throw new Error('Guild not found - the bot may have left the server.');

  const member = await guild.members.fetch(task.targetId).catch(() => null);
  if (!member) {
    // Member left the server - nothing left to remove, and nothing to retry.
    return null;
  }

  const role = await guild.roles.fetch(task.roleId).catch(() => null);
  if (role && member.roles.cache.has(task.roleId)) {
    if (!role.editable) throw new Error('Bot cannot manage that role (it may be above my highest role).');
    await member.roles.remove(task.roleId, `Temporary role expired (granted by ${task.moderatorId})`);
  }
  // If the role no longer exists, or the member no longer has it, there is
  // nothing to do - most likely it was already stripped manually and
  // guildMemberUpdate.js already resolved the task before this ever fired.

  await logTempRoleAction(client, guild, task, 'temprole_remove');
  return null;
}

scheduleService.registerHandler(ACTION, executeTempRoleRemoval);

/**
 * Grants a role and schedules its removal via scheduleService - the exact
 * same ScheduledTask collection and poller /schedule uses, just a
 * different `action`. On bot restart, scheduleService's own poll-on-start
 * behavior (services/scheduleService.js's startScheduler) picks this back
 * up automatically; nothing temprole-specific is needed for that.
 */
async function addTempRole(client, { guild, member, role, moderatorId, reason, executeAt }) {
  const existing = await scheduleService.findPendingTask(guild.id, ACTION, member.id, role.id);
  if (existing) {
    throw new Error(`This member already has a pending temp-role task for that role (\`${existing._id}\`). Use /temprole extend or /temprole cancel instead.`);
  }

  await member.roles.add(role, reason || 'Temporary role');

  const task = await scheduleService.createScheduledTask({
    guildId: guild.id,
    action: ACTION,
    moderatorId,
    targetId: member.id,
    roleId: role.id,
    reason: reason || 'No reason provided',
    executeAt,
  });

  await logTempRoleAction(client, guild, task, 'temprole_add');
  return task;
}

/**
 * Removes a temp role early, on a moderator's explicit request (/temprole
 * remove) - as opposed to a manual removal through Discord's own UI, which
 * events/guild/guildMemberUpdate.js detects and resolves separately.
 * Reuses scheduleService.cancelScheduledTask for the status transition
 * (same Pending -> Cancelled rule as /schedule cancel) instead of writing
 * a parallel status update here.
 */
async function removeTempRoleEarly(client, guild, task, moderatorId) {
  const cancelled = await scheduleService.cancelScheduledTask(guild.id, task._id, moderatorId);
  if (!cancelled || cancelled.status !== 'Cancelled') return cancelled;

  const member = await guild.members.fetch(task.targetId).catch(() => null);
  if (member && member.roles.cache.has(task.roleId)) {
    await member.roles.remove(task.roleId, `Temp role removed early by ${moderatorId}`).catch(() => null);
  }

  await logTempRoleAction(client, guild, cancelled, 'temprole_remove', moderatorId);
  return cancelled;
}

/**
 * Called from events/guild/guildMemberUpdate.js whenever a role disappears
 * from a member. If that role happened to be tracked by a Pending
 * temprole_remove task, the task is marked Cancelled so the scheduler
 * never tries to remove an already-gone role again (requirement: don't
 * retry a role that was already removed manually). Reuses
 * cancelScheduledTask - same as the explicit /temprole remove/cancel
 * paths - so there is exactly one place that ever flips a task out of
 * Pending.
 *
 * Still logged like any other temp-role removal, attributed to whoever the
 * audit log says removed it. If Discord's audit log doesn't yield an
 * executor (e.g. it's stale by the time this fires), the log entry is
 * skipped rather than misattributed to the original grantor.
 */
async function handleManualRoleRemoval(client, guild, memberId, roleId, executorId) {
  const task = await scheduleService.findPendingTask(guild.id, ACTION, memberId, roleId);
  if (!task) return null;

  const cancelled = await scheduleService.cancelScheduledTask(guild.id, task._id, executorId);
  if (!cancelled) return null;

  logger.info(`Temp role task ${task._id} resolved: role removed manually${executorId ? ` by ${executorId}` : ''}, no further action will be taken.`);
  if (executorId) {
    await logTempRoleAction(client, guild, cancelled, 'temprole_remove', executorId);
  }
  return cancelled;
}

module.exports = {
  addTempRole,
  removeTempRoleEarly,
  handleManualRoleRemoval,
};
