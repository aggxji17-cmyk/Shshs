const mongoose = require('mongoose');
const ConfigBackup = require('../database/models/ConfigBackup');
const GuildConfig = require('../database/models/GuildConfig');
const EconomyBalance = require('../database/models/EconomyBalance');
const UserLevel = require('../database/models/UserLevel');
const { getGuildConfig, invalidateGuildConfig } = require('../utils/resolveGuildSettings');

/**
 * Fields on GuildConfig that are document identity/bookkeeping, not
 * "settings" - never captured in a backup and never written back on
 * restore.
 */
const EXCLUDED_TOP_LEVEL_FIELDS = ['_id', '__v', 'guildId', 'createdAt', 'updatedAt'];

/**
 * Runtime counters/state rather than configuration choices. Left out of
 * every backup on purpose:
 *  - restoring an old `caseCounter`/`tickets.counter` could hand out a
 *    Case or ticket number that's already in use.
 *  - restoring an old panel message ID can point the bot at a Discord
 *    message that no longer exists.
 *  - restoring an old counting-game state can let a member "cheat" the
 *    count back down.
 * Because these keys are simply absent from a backup's `settings` object,
 * the merge in restoreBackup() below leaves the server's current values
 * for these fields untouched - no special-casing needed at restore time.
 */
const RUNTIME_STATE_PATHS = [
  'caseCounter',
  'tickets.counter',
  'tickets.panelMessageId',
  'verification.panelMessageId',
  'counting.currentCount',
  'counting.lastUserId',
  'counting.highestCount',
];

function isPlainObject(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value) && !(value instanceof Date);
}

/** Deletes a dot-notation path (e.g. 'tickets.counter') from a plain object, if present. */
function unsetPath(obj, path) {
  const parts = path.split('.');
  let cursor = obj;
  for (let i = 0; i < parts.length - 1; i += 1) {
    if (!isPlainObject(cursor[parts[i]])) return;
    cursor = cursor[parts[i]];
  }
  delete cursor[parts[parts.length - 1]];
}

/**
 * Recursively copies every key from `source` onto `target`, in place.
 * Plain objects are merged key-by-key (so a backup that only touches
 * `automod.checks.antiSpam` doesn't wipe out `automod.checks.antiInvite`);
 * arrays and primitives are replaced wholesale, which is what you want
 * for lists like `automod.ignoredRoleIds`. Returns `target`.
 */
function deepMerge(target, source) {
  for (const key of Object.keys(source)) {
    const sourceValue = source[key];
    if (isPlainObject(sourceValue) && isPlainObject(target[key])) {
      deepMerge(target[key], sourceValue);
    } else {
      target[key] = sourceValue;
    }
  }
  return target;
}

/** Strips identity fields and runtime state out of a GuildConfig snapshot before it's stored. */
function sanitizeConfigForBackup(guildConfigDoc) {
  const plain = guildConfigDoc.toObject({ depopulate: true });
  for (const field of EXCLUDED_TOP_LEVEL_FIELDS) delete plain[field];
  for (const path of RUNTIME_STATE_PATHS) unsetPath(plain, path);
  return plain;
}

/**
 * Minimal structural check that a backup's stored settings are usable.
 * Guards against a corrupted or hand-edited document being fed into the
 * restore merge (rather than trying to fully validate against the current
 * GuildConfig schema, which would defeat the point of forward-compatible
 * backups).
 */
function validateBackupData(data) {
  if (!isPlainObject(data)) {
    throw new Error('Backup data is corrupted or in an unrecognized format.');
  }
  return true;
}

/** Creates a new settings backup for a guild from its current GuildConfig. */
async function createBackup({ guildId, guildName, userId, label }) {
  const guildConfig = await getGuildConfig(guildId);
  const snapshot = sanitizeConfigForBackup(guildConfig);
  validateBackupData(snapshot);

  return ConfigBackup.create({
    guildId,
    guildName,
    createdBy: userId,
    label: label || null,
    settings: snapshot,
  });
}

/** Newest-first list of a guild's saved settings backups. */
async function listBackups(guildId, limit = 10) {
  return ConfigBackup.find({ guildId }).sort({ createdAt: -1 }).limit(limit);
}

/** Fetches one backup, scoped to the guild it belongs to (so a guild can never read/restore another guild's backup). */
async function getBackup(guildId, backupId) {
  if (!mongoose.Types.ObjectId.isValid(backupId)) return null;
  return ConfigBackup.findOne({ _id: backupId, guildId });
}

/** Deletes one backup. Returns true if a document was actually removed. */
async function deleteBackup(guildId, backupId) {
  const backup = await getBackup(guildId, backupId);
  if (!backup) return false;
  await backup.deleteOne();
  return true;
}

/**
 * Restores a guild's settings from a saved backup.
 *
 * By default this only ever touches the guild's single GuildConfig
 * document - it merges the backup's settings on top of the current
 * config (see deepMerge above), so fields added to GuildConfig *after*
 * this backup was taken are left exactly as they are now instead of
 * being wiped. Per-user data (economy balances, XP/levels) is a
 * different collection entirely and is never touched unless the caller
 * explicitly opts in with `resetUserData: true`.
 *
 * @param {object} params
 * @param {string} params.guildId
 * @param {string} params.backupId
 * @param {boolean} [params.resetUserData] - if true, also wipes this
 *   guild's EconomyBalance and UserLevel records.
 * @returns {Promise<{ backup: import('mongoose').Document, usersReset: number }>}
 */
async function restoreBackup({ guildId, backupId, resetUserData = false }) {
  const backup = await getBackup(guildId, backupId);
  if (!backup) {
    throw new Error('Backup not found.');
  }
  validateBackupData(backup.settings);

  // Bypass the cached getGuildConfig() here - we're about to save this
  // document, and want the freshest copy rather than one up to 30s stale.
  const guildConfig = (await GuildConfig.findOne({ guildId })) || (await GuildConfig.create({ guildId }));

  const currentPlain = guildConfig.toObject({ depopulate: true });
  const merged = deepMerge(currentPlain, backup.settings);
  for (const field of EXCLUDED_TOP_LEVEL_FIELDS) delete merged[field];

  guildConfig.set(merged);
  await guildConfig.save();
  invalidateGuildConfig(guildId);

  let usersReset = 0;
  if (resetUserData) {
    const [economyResult, levelingResult] = await Promise.all([
      EconomyBalance.deleteMany({ guildId }),
      UserLevel.deleteMany({ guildId }),
    ]);
    usersReset = (economyResult.deletedCount || 0) + (levelingResult.deletedCount || 0);
  }

  return { backup, usersReset };
}

module.exports = {
  createBackup,
  listBackups,
  getBackup,
  deleteBackup,
  restoreBackup,
  validateBackupData,
};
