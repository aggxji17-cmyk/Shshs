const MusicHistory = require('../database/models/MusicHistory');
const logger = require('../utils/logger');

const DEFAULT_LIMIT = 15;
const MAX_LIMIT = 25;

/**
 * Records one played track. Called from the Player's PlayerStart event
 * (services/musicService.js) - deliberately best-effort/non-throwing,
 * same as commandLogService.logCommandUsage, so a logging hiccup never
 * takes down actual playback.
 */
async function logPlay(guildId, track) {
  try {
    await MusicHistory.create({
      guildId,
      userId: track.requestedBy?.id || 'unknown',
      title: track.title,
      url: track.url,
      duration: track.duration || null,
      thumbnail: track.thumbnail || null,
      author: track.author || null,
    });
  } catch (err) {
    logger.error(`Failed to write music history entry: ${err.stack || err}`);
  }
}

/**
 * @param {string} guildId
 * @param {object} [opts]
 * @param {string} [opts.userId] - only this user's plays
 * @param {number} [opts.limit]
 */
async function getRecentHistory(guildId, opts = {}) {
  const limit = Math.min(opts.limit || DEFAULT_LIMIT, MAX_LIMIT);
  const query = { guildId };
  if (opts.userId) query.userId = opts.userId;
  return MusicHistory.find(query).sort({ playedAt: -1 }).limit(limit);
}

async function clearHistory(guildId) {
  const { deletedCount } = await MusicHistory.deleteMany({ guildId });
  return deletedCount;
}

module.exports = { DEFAULT_LIMIT, MAX_LIMIT, logPlay, getRecentHistory, clearHistory };
