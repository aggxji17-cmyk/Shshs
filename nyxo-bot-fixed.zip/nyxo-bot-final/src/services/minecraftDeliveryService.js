const MinecraftLink = require('../database/models/MinecraftLink');
const MinecraftServer = require('../database/models/MinecraftServer');
const MinecraftDelivery = require('../database/models/MinecraftDelivery');
const MinecraftPendingDelivery = require('../database/models/MinecraftPendingDelivery');
const { runCommand, CommandTimeoutError } = require('./commandQueueService');
const { getPlayerCache, buildPresenceInfo } = require('./minecraftPlayerService');
const { baseEmbed } = require('../utils/embeds');
const { resolved } = require('../utils/resolveGuildSettings');
const { t, resolveLanguage, DEFAULT_LANGUAGE } = require('../utils/i18n');
const logger = require('../utils/logger');

/**
 * Task 4/5/6: the bridge between NYXO BOT's shop (economyService.purchaseItem
 * + ShopItem.minecraft, see commands/economy/shop.js) and Minecraft.
 *
 * Delivers ONE purchased item's in-game effect by sending its
 * `commandTemplate` (with placeholders filled in) to the correct server
 * as a `console_command` over the existing NovaBridge queue
 * (services/commandQueueService.js) - the plugin already implements this
 * handler today (BuiltinCommandHandlers.java), so this needs no plugin
 * change to actually run.
 *
 * "دعم عدة سيرفرات مثل Survival وSMP": which server a given delivery
 * targets is just `item.minecraft.targetServerId`, one of the servers
 * NovaBridge has already registered (database/models/MinecraftServer.js) -
 * so adding a new server is purely a matter of running the plugin there
 * and picking its id in `/shop additem`, nothing here needs to change.
 *
 * "رتبة" vs "سباونر/آيتم" (ShopItem.minecraft.kind, Task 5):
 *   - "rank": always delivered immediately on `targetServerId`, online or
 *     not - a permissions command (e.g. LuckPerms) applies by name/uuid
 *     without the player needing to be connected.
 *   - "item": needs the player actually online on `targetServerId` for a
 *     command like `give` to land on them. Presence is checked first
 *     (via the read-only MinecraftPlayerCache mirror of NovaBridge's
 *     `minecraft_players` collection - see minecraftPlayerService.js):
 *     online now -> delivered immediately, same as a rank; offline ->
 *     saved as a MinecraftPendingDelivery instead of being sent, and
 *     services/minecraftPendingDeliveryService.js's background poller
 *     delivers it automatically the moment they're seen online on that
 *     server.
 *
 * Task 6 (language support): every string this module returns to a
 * caller or writes to the log channel goes through `t(lang, key)` (see
 * utils/i18n.js) instead of being hardcoded in one language - `lang` is
 * resolved by the caller (commands/economy/shop.js resolves it from the
 * buyer's own interaction; the offline-delivery poller has no live
 * interaction to read, so it resolves from the guild's stored
 * `/language` preference instead - see minecraftPendingDeliveryService.js).
 * The Minecraft side (console command text, plugin log output) is
 * intentionally untouched by any of this - NovaBridge's own messages are
 * English-only by design (Task 6), unrelated to which language Discord
 * replies use.
 *
 * Callers (today: commands/economy/shop.js's `buy` subcommand; later:
 * any other "grant something in-game" flow - gifting, admin `/mcgive`,
 * ...) should all go through `deliverPurchase` so every delivery gets the
 * same validation, timeout handling, presence check and logging for free.
 */

const DELIVERY_TIMEOUT_MS = 8000;

class DeliveryError extends Error {
  constructor(message) {
    super(message);
    this.name = 'DeliveryError';
  }
}

/** Minecraft Java usernames are 3-16 chars of [A-Za-z0-9_] - reject anything else defensively before it ever reaches a shell/console command. */
const VALID_USERNAME = /^[A-Za-z0-9_]{1,16}$/;

/**
 * Fills `{player}` / `{uuid}` into an admin-authored command template.
 * Throws rather than silently proceeding if the username doesn't look
 * like a real Minecraft username - commandTemplate is admin-controlled
 * (trusted), but the substituted value (a player's linked username)
 * should never be able to smuggle in extra text.
 */
function renderCommandTemplate(template, { username, uuid }, lang = DEFAULT_LANGUAGE) {
  if (!VALID_USERNAME.test(username)) {
    throw new DeliveryError(t(lang, 'minecraft_delivery.invalid_username'));
  }
  return template.replaceAll('{player}', username).replaceAll('{uuid}', uuid);
}

/**
 * Delivers one ShopItem's in-game effect to its buyer. No-ops (returns
 * `{ skipped: true }`) if the item has no Minecraft delivery configured,
 * so callers can call this unconditionally after every purchase without
 * an `if (item.minecraft?.enabled)` guard of their own.
 *
 * Never throws for expected failure cases (not linked, server unknown,
 * command timeout, plugin-reported error) - those come back as
 * `{ success: false, reason }` so the caller can show the buyer a clear
 * message without also having to wrap this in try/catch. Programming
 * errors (bad DB state, etc.) still throw.
 *
 * @param {object} params
 * @param {import('discord.js').Guild} params.guild
 * @param {*} params.guildConfig - raw GuildConfig doc (for deliveryLogChannelId + resolved())
 * @param {string} params.discordUserId - the buyer
 * @param {*} params.item - a ShopItem document (must have .minecraft.enabled)
 * @param {string|null} [params.requestedBy] - e.g. `discord:${discordUserId}`
 * @param {string} [params.lang] - reply language (see utils/i18n.js), defaults to the guild's resolved language
 * @returns {Promise<
 *   { skipped: true } |
 *   { success: true, queued?: false } |
 *   { success: true, queued: true } |
 *   { success: false, reason: string }
 * >}
 */
async function deliverPurchase({ guild, guildConfig, discordUserId, item, requestedBy = null, lang }) {
  if (!item?.minecraft?.enabled) {
    return { skipped: true };
  }

  const resolvedLang = lang || resolveLanguage({ guildConfigDoc: guildConfig });

  const { targetServerId, commandTemplate, kind = 'item' } = item.minecraft;
  if (!targetServerId || !commandTemplate) {
    return { success: false, reason: t(resolvedLang, 'minecraft_delivery.misconfigured') };
  }

  const link = await MinecraftLink.findOne({ guildId: guild.id, discordId: discordUserId });
  if (!link) {
    return { success: false, reason: t(resolvedLang, 'minecraft_delivery.not_linked') };
  }

  const server = await MinecraftServer.findById(targetServerId).lean();
  if (!server) {
    return { success: false, reason: t(resolvedLang, 'minecraft_delivery.server_unregistered') };
  }

  let command;
  try {
    command = renderCommandTemplate(commandTemplate, { username: link.minecraftUsername, uuid: link.minecraftUuid }, resolvedLang);
  } catch (err) {
    if (err instanceof DeliveryError) return { success: false, reason: err.message };
    throw err;
  }

  // Ranks don't need the player online (LuckPerms-style commands apply by
  // name/uuid regardless) - only "item" kind purchases (give/spawn
  // commands) need to check presence before deciding whether to deliver
  // now or queue for later.
  if (kind === 'item') {
    const cache = await getPlayerCache(link.minecraftUuid);
    const presence = buildPresenceInfo(cache, targetServerId);
    if (!presence.onlineHere) {
      return queueForOfflineDelivery({ guild, guildConfig, discordUserId, link, item, targetServerId, commandTemplate, requestedBy, lang: resolvedLang });
    }
  }

  return executeDelivery({ guild, guildConfig, discordUserId, link, item, targetServerId, command, requestedBy, lang: resolvedLang });
}

/**
 * Actually sends `command` to `targetServerId` now and records the
 * outcome. Used both for immediate delivery and for the
 * offline-delivery poller resolving a previously-queued purchase.
 */
async function executeDelivery({ guild, guildConfig, discordUserId, link, item, targetServerId, command, requestedBy, lang = DEFAULT_LANGUAGE }) {
  let outcome;
  let error = null;
  try {
    outcome = await runCommand(targetServerId, 'console_command', { command }, { requestedBy, timeoutMs: DELIVERY_TIMEOUT_MS });
  } catch (err) {
    if (!(err instanceof CommandTimeoutError)) throw err;
    outcome = null;
    error = t(lang, 'minecraft_delivery.timeout');
  }

  if (outcome && outcome.status === 'failed') {
    error = outcome.result?.error || t(lang, 'minecraft_delivery.command_failed');
  }

  const status = error ? 'failed' : 'done';

  await recordDelivery({
    guild,
    guildConfig,
    discordUserId,
    link,
    item,
    targetServerId,
    command,
    status,
    error,
    serverCommandId: outcome?.commandId ?? null,
    requestedBy,
    lang,
  });

  if (error) return { success: false, reason: error };
  return { success: true };
}

/**
 * Player is offline (or online on a different server than this item
 * targets): saves the purchase instead of sending a command that would
 * just fail. A "queued" MinecraftDelivery row is written immediately so
 * the log/history reflects the purchase right away, and a
 * MinecraftPendingDelivery is created pointing back to it -
 * services/minecraftPendingDeliveryService.js's poller resolves both once
 * the buyer is seen online on `targetServerId`.
 */
async function queueForOfflineDelivery({ guild, guildConfig, discordUserId, link, item, targetServerId, commandTemplate, requestedBy, lang = DEFAULT_LANGUAGE }) {
  // Store the *template*, not a pre-rendered command - re-rendered at
  // delivery time in case the linked username changed in the meantime.
  const previewCommand = commandTemplate.replaceAll('{player}', link.minecraftUsername).replaceAll('{uuid}', link.minecraftUuid);

  const deliveryDoc = await MinecraftDelivery.create({
    guildId: guild.id,
    discordUserId,
    minecraftUuid: link.minecraftUuid,
    minecraftUsername: link.minecraftUsername,
    itemName: item.name,
    targetServerId,
    command: previewCommand,
    status: 'queued',
    requestedBy,
  });

  await MinecraftPendingDelivery.create({
    guildId: guild.id,
    discordUserId,
    minecraftUuid: link.minecraftUuid,
    minecraftUsername: link.minecraftUsername,
    itemName: item.name,
    targetServerId,
    commandTemplate,
    requestedBy,
    deliveryId: deliveryDoc._id,
  });

  await sendDeliveryLog({ guild, guildConfig, discordUserId, link, item, targetServerId, command: previewCommand, status: 'queued', error: null, lang });

  return { success: true, queued: true };
}

/** Persists the delivery record (immediate path only - the queued path writes it directly, see queueForOfflineDelivery) and mirrors it to the guild's delivery log channel. Best-effort logging - a logging failure never masks the actual delivery outcome to the caller. */
async function recordDelivery({ guild, guildConfig, discordUserId, link, item, targetServerId, command, status, error, serverCommandId, requestedBy, lang = DEFAULT_LANGUAGE }) {
  try {
    await MinecraftDelivery.create({
      guildId: guild.id,
      discordUserId,
      minecraftUuid: link.minecraftUuid,
      minecraftUsername: link.minecraftUsername,
      itemName: item.name,
      targetServerId,
      command,
      status,
      error,
      serverCommandId,
      requestedBy,
      deliveredAt: new Date(),
    });
  } catch (err) {
    logger.error(`Failed to record MinecraftDelivery: ${err.stack || err}`);
  }

  await sendDeliveryLog({ guild, guildConfig, discordUserId, link, item, targetServerId, command, status, error, lang });
}

/** "تسجيل جميع العمليات في اللوق" - mirrors every delivery event (queued, delivered, failed) to the guild's configured log channel, if any, in the guild's resolved language. Never throws. */
async function sendDeliveryLog({ guild, guildConfig, discordUserId, link, item, targetServerId, command, status, error, lang }) {
  const channelId = guildConfig?.minecraft?.deliveryLogChannelId;
  if (!channelId) return;

  const channel = guild.channels.cache.get(channelId);
  if (!channel) return;

  const resolvedLang = lang || resolveLanguage({ guildConfigDoc: guildConfig });

  const TITLE_KEYS = { done: 'minecraft_delivery.log.done_title', failed: 'minecraft_delivery.log.failed_title', queued: 'minecraft_delivery.log.queued_title' };
  const COLORS = { done: '#57F287', failed: '#ED4245', queued: '#FEE75C' };

  const settings = resolved(guildConfig);
  const embed = baseEmbed(settings)
    .setTitle(t(resolvedLang, TITLE_KEYS[status] || status))
    .setColor(COLORS[status] || '#5865F2')
    .addFields(
      { name: t(resolvedLang, 'minecraft_delivery.log.field_item'), value: item.name, inline: true },
      { name: t(resolvedLang, 'minecraft_delivery.log.field_player'), value: `${link.minecraftUsername} (<@${discordUserId}>)`, inline: true },
      { name: t(resolvedLang, 'minecraft_delivery.log.field_server'), value: targetServerId, inline: true },
      { name: t(resolvedLang, 'minecraft_delivery.log.field_command'), value: `\`${command}\`` }
    );
  if (error) embed.addFields({ name: t(resolvedLang, 'minecraft_delivery.log.field_reason'), value: error });
  if (status === 'queued') embed.addFields({ name: t(resolvedLang, 'minecraft_delivery.log.field_note'), value: t(resolvedLang, 'minecraft_delivery.log.queued_note') });

  await channel.send({ embeds: [embed] }).catch(() => null);
}

/** Paginated delivery history for a guild - for a future /shoplog-style command or dashboard page, same shape/philosophy as services/auditService.js. */
async function getRecentDeliveries(guildId, { discordUserId, status, page = 1, pageSize = 10 } = {}) {
  const match = { guildId };
  if (discordUserId) match.discordUserId = discordUserId;
  if (status) match.status = status;

  const safePage = Math.max(page, 1);
  const skip = (safePage - 1) * pageSize;

  const [deliveries, total] = await Promise.all([
    MinecraftDelivery.find(match).sort({ createdAt: -1 }).skip(skip).limit(pageSize),
    MinecraftDelivery.countDocuments(match),
  ]);

  return { deliveries, total, page: safePage, totalPages: Math.max(Math.ceil(total / pageSize), 1) };
}

module.exports = {
  deliverPurchase,
  renderCommandTemplate,
  getRecentDeliveries,
  DeliveryError,
  // Exported for services/minecraftPendingDeliveryService.js, which
  // resolves a queued purchase through the exact same code path an
  // immediate delivery uses.
  executeDelivery,
  sendDeliveryLog,
};
