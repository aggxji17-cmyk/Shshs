const axios = require('axios');

const EMPTY_STATS = { rank: null, playtimeHours: null, kills: null, deaths: null };

/**
 * Fetches optional gameplay stats (rank/playtime/kills/deaths) from a
 * guild-configured stats API (e.g. a server-side plugin exposing player
 * stats over HTTP, set via `/mcconfig statsapiurl`). This integration is
 * entirely optional: if no endpoint is configured, the request fails, or
 * the response is missing a field, that field simply comes back `null` so
 * callers can render "not available" instead of surfacing an error.
 *
 * Expected (all-optional) response shape from `{statsApiUrl}/{uuid}`:
 * `{ rank, playtimeHours, kills, deaths }`
 */
async function fetchPlayerStats(statsApiUrl, uuid, username) {
  if (!statsApiUrl) return { ...EMPTY_STATS };

  try {
    const url = `${statsApiUrl.replace(/\/+$/, '')}/${encodeURIComponent(uuid)}`;
    const { data } = await axios.get(url, { timeout: 5000, params: { username } });

    return {
      rank: data?.rank != null ? String(data.rank) : null,
      playtimeHours: typeof data?.playtimeHours === 'number' ? data.playtimeHours : null,
      kills: typeof data?.kills === 'number' ? data.kills : null,
      deaths: typeof data?.deaths === 'number' ? data.deaths : null,
    };
  } catch (err) {
    // Stats are a nice-to-have - never let a broken/unreachable endpoint
    // break /mcprofile. Missing values are rendered as "not available".
    return { ...EMPTY_STATS };
  }
}

module.exports = { fetchPlayerStats };
