const { CHECKS } = require('./automodChecks');
const { createCase } = require('./caseService');
const { sendModerationLog } = require('../utils/moderationLogService');
const { baseEmbed } = require('../utils/embeds');
const Warn = require('../database/models/Warn');
const logger = require('../utils/logger');

/**
 * Entry point called from events/message/messageCreate.js for every
 * non-bot message. Runs each enabled check (in registry order) against
 * the message and stops at the first violation - a single message only
 * ever triggers one punishment, never several stacked at once.
 *
 * Returns true if a violation was found and handled (caller should stop
 * processing the rest of its message pipeline for it), false otherwise.
 */
async function processMessage(message, guildConfig, settings) {
  const automod = guildConfig.automod;
  if (!automod?.enabled) return false;
  if (automod.ignoredChannelIds?.includes(message.channelId)) return false;

  const memberRoleIds = message.member?.roles.cache.map((r) => r.id) || [];
  if (memberRoleIds.some((id) => automod.ignoredRoleIds?.includes(id))) return false;

  for (const check of CHECKS) {
    const checkCfg = automod.checks?.[check.key];
    if (!checkCfg?.enabled) continue;

    const result = check.test(message, checkCfg);
    if (!result?.violated) continue;

    await handleViolation(message, guildConfig, settings, check, checkCfg, result.reason);
    return true;
  }

  return false;
}

/**
 * Common reaction to any violation, regardless of which check fired:
 * delete the offending message, notify the channel briefly, post a
 * violation notice to the logging channel, then hand off to
 * applyPunishment() for whatever punishment beyond deletion is configured.
 */
async function handleViolation(message, guildConfig, settings, check, checkCfg, reason) {
  await message.delete().catch(() => null);

  message.channel
    .send({ content: `${message.author}, ${reason}` })
    .then((m) => setTimeout(() => m.delete().catch(() => null), 5000))
    .catch(() => null);

  await postViolationNotice(message, guildConfig, settings, check, reason);

  // 'delete' is a valid, standalone punishment choice - the message is
  // already gone, so there is nothing further to do and no Case is filed
  // (mirrors /purge, which also doesn't create a Case for removed messages).
  if (checkCfg.punishment === 'delete') return;

  await applyPunishment({
    guild: message.guild,
    guildConfig,
    settings,
    targetUser: message.author,
    punishment: checkCfg.punishment,
    timeoutMinutes: checkCfg.timeoutMinutes,
    reason: `AutoMod (${check.label}): ${reason}`,
  });
}

/** Lightweight per-violation notice to the guild's general logging channel, separate from the formal Case log below. */
async function postViolationNotice(message, guildConfig, settings, check, reason) {
  if (!guildConfig.logging?.enabled || !guildConfig.logging.channelId) return;

  const channel = message.guild.channels.cache.get(guildConfig.logging.channelId);
  if (!channel) return;

  await channel
    .send({
      embeds: [
        baseEmbed(settings)
          .setTitle(`AutoMod — ${check.label}`)
          .addFields(
            { name: 'العضو', value: `${message.author} (\`${message.author.id}\`)`, inline: true },
            { name: 'القناة', value: `${message.channel}`, inline: true },
            { name: 'السبب', value: reason }
          ),
      ],
    })
    .catch(() => null);
}

/**
 * The single place every AutoMod check routes its punishment through, so
 * adding a new check never means duplicating warn/timeout/kick/ban/softban
 * logic again. Mirrors exactly what the manual /warn, /timeout, /kick,
 * /ban and /softban commands do - Warn doc (for warn) + Case
 * (services/caseService.js) + moderation log (utils/moderationLogService.js)
 * - so an AutoMod punishment is indistinguishable from a manual one
 * anywhere else in the bot (/modhistory, /userinfo, /cases, stats).
 *
 * The bot itself is recorded as the "moderator" on the Case/log entry.
 */
async function applyPunishment({ guild, guildConfig, settings, targetUser, punishment, timeoutMinutes, reason }) {
  if (targetUser.bot) return null;
  if (targetUser.id === guild.ownerId) return null; // never punish the server owner, even automatically

  const member = await guild.members.fetch(targetUser.id).catch(() => null);

  try {
    if (punishment === 'warn') {
      await Warn.create({ guildId: guild.id, userId: targetUser.id, moderatorId: guild.client.user.id, reason });
    } else if (punishment === 'timeout') {
      if (!member?.moderatable) return null;
      await member.timeout(timeoutMinutes * 60 * 1000, reason);
    } else if (punishment === 'kick') {
      if (!member?.kickable) return null;
      await member.kick(reason);
    } else if (punishment === 'ban') {
      if (member && !member.bannable) return null;
      await guild.members.ban(targetUser.id, { reason });
    } else if (punishment === 'softban') {
      if (member && !member.bannable) return null;
      await guild.members.ban(targetUser.id, { deleteMessageSeconds: 86400, reason });
      await guild.members.unban(targetUser.id, 'AutoMod softban - automatic unban').catch(() => null);
    } else {
      return null;
    }
  } catch (err) {
    logger.error(`AutoMod failed to apply punishment "${punishment}" on ${targetUser.id}: ${err.message}`);
    return null;
  }

  const caseDoc = await createCase({
    guildId: guild.id,
    action: punishment,
    moderatorId: guild.client.user.id,
    targetId: targetUser.id,
    reason,
    durationMinutes: punishment === 'timeout' ? timeoutMinutes : null,
  });

  await sendModerationLog(guild, guildConfig, settings, {
    action: punishment,
    moderator: guild.client.user,
    target: targetUser,
    reason,
    durationMinutes: punishment === 'timeout' ? timeoutMinutes : undefined,
    caseId: caseDoc.caseId,
  });

  return caseDoc;
}

module.exports = { processMessage, applyPunishment };
