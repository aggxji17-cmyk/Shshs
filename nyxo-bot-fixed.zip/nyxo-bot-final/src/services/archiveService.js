const { AttachmentBuilder } = require('discord.js');
const axios = require('axios');
const archiver = require('archiver');
const { PassThrough } = require('stream');
const logger = require('../utils/logger');

// Discord's own upload ceiling for a non-boosted guild is 10MB (up to 25MB/50MB
// on boosted tiers). We cap what we're willing to *download* per-attachment and
// in total so a ticket full of huge files can't hang the close flow forever or
// blow past what we'd be able to re-upload anyway.
const MAX_ATTACHMENT_BYTES = 20 * 1024 * 1024; // 20MB per file
const MAX_TOTAL_ATTACHMENT_BYTES = 90 * 1024 * 1024; // 90MB combined, well under most zip targets
const IMAGE_EXTENSIONS = new Set(['png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp', 'svg']);

/**
 * Pages backwards through a channel's full message history. Discord caps
 * `fetch` at 100 per call, so this walks `before` cursors until exhausted
 * or a sane upper bound is hit so an extremely long-lived ticket can't
 * hang the close flow forever.
 */
async function fetchAllMessages(channel) {
  const collected = [];
  let before;

  for (let page = 0; page < 50; page += 1) {
    const batch = await channel.messages.fetch({ limit: 100, ...(before ? { before } : {}) }).catch(() => null);
    if (!batch || !batch.size) break;
    collected.push(...batch.values());
    before = batch.last().id;
    if (batch.size < 100) break;
  }

  collected.reverse();
  return collected;
}

function extOf(filename) {
  const match = /\.([a-z0-9]+)$/i.exec(filename || '');
  return match ? match[1].toLowerCase() : '';
}

function isImage(attachment) {
  if (attachment.contentType?.startsWith('image/')) return true;
  return IMAGE_EXTENSIONS.has(extOf(attachment.name));
}

function formatBytes(bytes) {
  if (!bytes) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB'];
  let i = 0;
  let n = bytes;
  while (n >= 1024 && i < units.length - 1) {
    n /= 1024;
    i += 1;
  }
  return `${n.toFixed(n < 10 && i > 0 ? 1 : 0)} ${units[i]}`;
}

function safeFileName(name) {
  return (name || 'file').replace(/[\\/:*?"<>|]/g, '_').slice(0, 150);
}

/**
 * Downloads every attachment across the collected messages, respecting the
 * per-file and total size caps above. Returns entries carrying both the raw
 * buffer (for the zip) and a base64 data URI (so the standalone HTML
 * transcript stays self-contained after the channel - and its CDN links -
 * are gone).
 */
async function downloadAttachments(messages) {
  const entries = [];
  let totalBytes = 0;

  for (const message of messages) {
    for (const attachment of message.attachments.values()) {
      const base = {
        messageId: message.id,
        name: attachment.name || `file-${attachment.id}`,
        url: attachment.url,
        size: attachment.size,
        isImage: isImage(attachment),
      };

      if (attachment.size > MAX_ATTACHMENT_BYTES) {
        entries.push({ ...base, status: 'skipped_too_large' });
        continue;
      }
      if (totalBytes + attachment.size > MAX_TOTAL_ATTACHMENT_BYTES) {
        entries.push({ ...base, status: 'skipped_total_cap' });
        continue;
      }

      try {
        const res = await axios.get(attachment.url, { responseType: 'arraybuffer', timeout: 15000 });
        const buffer = Buffer.from(res.data);
        totalBytes += buffer.length;
        entries.push({ ...base, status: 'ok', buffer, mime: attachment.contentType || 'application/octet-stream' });
      } catch (err) {
        logger.warn(`تعذر تحميل مرفق التذكرة ${attachment.name}: ${err.message}`);
        entries.push({ ...base, status: 'failed' });
      }
    }
  }

  return entries;
}

function escapeHtml(str) {
  return String(str ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;');
}

function formatTime(ts) {
  return new Date(ts).toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
}

/** Builds the self-contained HTML transcript (images inlined as base64, everything else linked by name). */
function buildHtmlTranscript({ channel, ticket, messages, attachmentEntries, openedAt }) {
  const attachmentsByMessage = new Map();
  for (const entry of attachmentEntries) {
    if (!attachmentsByMessage.has(entry.messageId)) attachmentsByMessage.set(entry.messageId, []);
    attachmentsByMessage.get(entry.messageId).push(entry);
  }

  const rows = messages
    .map((m) => {
      const time = formatTime(m.createdTimestamp);
      const author = escapeHtml(m.author?.tag || m.author?.username || 'Unknown');
      const avatar = m.author?.displayAvatarURL?.({ size: 64 }) || '';
      const content = m.content ? `<div class="content">${escapeHtml(m.content)}</div>` : '';

      const embeds = (m.embeds || [])
        .map((e) => {
          const title = e.title ? `<div class="embed-title">${escapeHtml(e.title)}</div>` : '';
          const desc = e.description ? `<div class="embed-desc">${escapeHtml(e.description)}</div>` : '';
          return title || desc ? `<div class="embed">${title}${desc}</div>` : '';
        })
        .join('');

      const attachmentsHtml = (attachmentsByMessage.get(m.id) || [])
        .map((a) => {
          if (a.status === 'ok' && a.isImage) {
            const dataUri = `data:${a.mime};base64,${a.buffer.toString('base64')}`;
            return `<div class="attachment"><img src="${dataUri}" alt="${escapeHtml(a.name)}" loading="lazy" /><div class="filename">${escapeHtml(a.name)} (${formatBytes(a.size)})</div></div>`;
          }
          const note =
            a.status === 'skipped_too_large'
              ? 'لم يُحفظ - الحجم أكبر من الحد المسموح'
              : a.status === 'skipped_total_cap'
                ? 'لم يُحفظ - تم تجاوز الحد الإجمالي للمرفقات'
                : a.status === 'failed'
                  ? 'تعذر تحميل هذا الملف'
                  : 'محفوظ داخل الملف المضغوط (ZIP)';
          return `<div class="attachment file"><span class="file-icon">📎</span> ${escapeHtml(a.name)} <span class="filesize">(${formatBytes(a.size)})</span><div class="note">${note}</div></div>`;
        })
        .join('');

      return `<div class="msg">
        ${avatar ? `<img class="avatar" src="${avatar}" alt="" />` : '<div class="avatar placeholder"></div>'}
        <div class="body">
          <div class="meta"><span class="author">${author}</span><span class="time">${time}</span></div>
          ${content}${embeds}${attachmentsHtml}
        </div>
      </div>`;
    })
    .join('\n');

  const durationMs = ticket.closedAt && openedAt ? new Date(ticket.closedAt).getTime() - new Date(openedAt).getTime() : null;
  const durationText = durationMs ? formatDuration(durationMs) : 'غير معروف';

  return `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8" />
<title>سجل التذكرة #${ticket.ticketNumber} - ${escapeHtml(channel.name)}</title>
<style>
  * { box-sizing: border-box; }
  body { font-family: 'Segoe UI', Tahoma, sans-serif; background: #313338; color: #dbdee1; margin: 0; padding: 0; }
  header { background: #2b2d31; padding: 24px 32px; border-bottom: 1px solid #1e1f22; }
  header h1 { margin: 0 0 8px; font-size: 1.4em; color: #fff; }
  .stats { display: flex; flex-wrap: wrap; gap: 8px 24px; font-size: 0.9em; color: #949ba4; }
  .stats span b { color: #dbdee1; }
  main { padding: 16px 32px 48px; max-width: 900px; margin: 0 auto; }
  .msg { display: flex; gap: 14px; padding: 10px 4px; border-bottom: 1px solid #3f4147; }
  .avatar { width: 40px; height: 40px; border-radius: 50%; flex-shrink: 0; }
  .avatar.placeholder { background: #4e5058; }
  .meta { display: flex; gap: 10px; align-items: baseline; margin-bottom: 2px; }
  .author { font-weight: 600; color: #f2f3f5; }
  .time { font-size: 0.75em; color: #949ba4; }
  .content { white-space: pre-wrap; word-break: break-word; line-height: 1.4; }
  .embed { border-right: 3px solid #5865f2; background: #2b2d31; padding: 8px 12px; margin-top: 6px; border-radius: 4px; max-width: 520px; }
  .embed-title { font-weight: 600; color: #fff; margin-bottom: 4px; }
  .embed-desc { font-size: 0.9em; color: #dbdee1; }
  .attachment { margin-top: 8px; }
  .attachment img { max-width: 380px; max-height: 300px; border-radius: 6px; display: block; }
  .attachment .filename { font-size: 0.78em; color: #949ba4; margin-top: 2px; }
  .attachment.file { background: #2b2d31; padding: 8px 12px; border-radius: 6px; font-size: 0.9em; max-width: 420px; }
  .attachment.file .note { font-size: 0.75em; color: #949ba4; margin-top: 2px; }
  footer { text-align: center; color: #6d6f78; font-size: 0.8em; padding: 24px; }
</style>
</head>
<body>
<header>
  <h1>سجل تذكرة #${ticket.ticketNumber} - #${escapeHtml(channel.name)}</h1>
  <div class="stats">
    <span>النوع: <b>${escapeHtml(ticket.typeLabel || 'غير محدد')}</b></span>
    <span>فتحها: <b>${escapeHtml(ticket.userId)}</b></span>
    <span>أغلقها: <b>${escapeHtml(ticket.closedBy || '-')}</b></span>
    <span>عدد الرسائل: <b>${messages.length}</b></span>
    <span>عدد المرفقات: <b>${attachmentEntries.length}</b></span>
    <span>مدة التذكرة: <b>${durationText}</b></span>
  </div>
</header>
<main>
${rows || '<p>لا توجد رسائل.</p>'}
</main>
<footer>تم إنشاء هذا السجل تلقائيًا عند إغلاق التذكرة</footer>
</body>
</html>`;
}

/** Builds a plain-text version of the log, useful for grepping/reading without a browser. */
function buildTextTranscript({ channel, ticket, messages }) {
  const lines = [
    `سجل تذكرة #${ticket.ticketNumber} - #${channel.name}`,
    `النوع: ${ticket.typeLabel || 'غير محدد'}`,
    `فتحها: ${ticket.userId}  |  أغلقها: ${ticket.closedBy || '-'}`,
    `عدد الرسائل: ${messages.length}`,
    '='.repeat(60),
    '',
  ];

  for (const m of messages) {
    const time = formatTime(m.createdTimestamp);
    const author = m.author?.tag || m.author?.username || 'Unknown';
    lines.push(`[${time}] ${author}:`);
    if (m.content) lines.push(`  ${m.content}`);
    for (const a of m.attachments.values()) {
      lines.push(`  [مرفق] ${a.name} (${formatBytes(a.size)})`);
    }
    for (const e of m.embeds || []) {
      if (e.title || e.description) lines.push(`  [Embed] ${e.title || ''} ${e.description ? '- ' + e.description : ''}`.trim());
    }
    lines.push('');
  }

  return lines.join('\n');
}

function formatDuration(ms) {
  const totalMinutes = Math.floor(ms / 60000);
  const days = Math.floor(totalMinutes / 1440);
  const hours = Math.floor((totalMinutes % 1440) / 60);
  const minutes = totalMinutes % 60;
  const parts = [];
  if (days) parts.push(`${days} يوم`);
  if (hours) parts.push(`${hours} ساعة`);
  if (minutes || !parts.length) parts.push(`${minutes} دقيقة`);
  return parts.join(' ');
}

/** Streams a list of {name, buffer} entries into a single ZIP buffer using archiver. */
function buildZipBuffer(entries) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    const output = new PassThrough();
    output.on('data', (chunk) => chunks.push(chunk));
    output.on('end', () => resolve(Buffer.concat(chunks)));
    output.on('error', reject);

    const archive = archiver('zip', { zlib: { level: 9 } });
    archive.on('error', reject);
    archive.on('warning', (err) => logger.warn(`تحذير أثناء ضغط أرشيف التذكرة: ${err.message}`));
    archive.pipe(output);

    for (const entry of entries) {
      archive.append(entry.buffer, { name: entry.name });
    }

    archive.finalize();
  });
}

/**
 * Builds the complete closing archive for a ticket channel:
 *  - fetches the full message history
 *  - downloads images/files referenced in the ticket (within size caps)
 *  - renders a professional, self-contained HTML transcript
 *  - renders a plain-text transcript
 *  - packages everything (html + txt + attachments/images + attachments/files) into one ZIP
 *
 * Returns both the standalone HTML attachment (for quick browser viewing) and
 * the ZIP attachment (the full archive), plus a few stats for the log embed.
 */
async function buildTicketArchive(channel, ticket, openedAt) {
  const messages = await fetchAllMessages(channel);
  const attachmentEntries = await downloadAttachments(messages);

  const html = buildHtmlTranscript({ channel, ticket, messages, attachmentEntries, openedAt });
  const text = buildTextTranscript({ channel, ticket, messages });

  const zipEntries = [
    { name: 'transcript.html', buffer: Buffer.from(html, 'utf-8') },
    { name: 'transcript.txt', buffer: Buffer.from(text, 'utf-8') },
  ];

  let savedCount = 0;
  for (const entry of attachmentEntries) {
    if (entry.status !== 'ok') continue;
    const folder = entry.isImage ? 'attachments/images' : 'attachments/files';
    zipEntries.push({ name: `${folder}/${entry.messageId}-${safeFileName(entry.name)}`, buffer: entry.buffer });
    savedCount += 1;
  }

  const zipBuffer = await buildZipBuffer(zipEntries);
  const baseName = safeFileName(channel.name || `ticket-${ticket.ticketNumber}`);

  return {
    htmlAttachment: new AttachmentBuilder(Buffer.from(html, 'utf-8'), { name: `transcript-${baseName}.html` }),
    zipAttachment: new AttachmentBuilder(zipBuffer, { name: `archive-${baseName}.zip` }),
    stats: {
      messageCount: messages.length,
      attachmentCount: attachmentEntries.length,
      savedAttachmentCount: savedCount,
      zipSizeBytes: zipBuffer.length,
    },
  };
}

module.exports = { buildTicketArchive, formatBytes, formatDuration };
