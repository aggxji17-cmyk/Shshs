const { config } = require('../config/config');
const MinecraftLink = require('../database/models/MinecraftLink');
const { enqueueCommand } = require('./commandQueueService');
const { renderCommandTemplate, DeliveryError } = require('./minecraftDeliveryService');
const logger = require('../utils/logger');

/**
 * Task: "Minecraft AFK Voice Rewards" - a member who stays connected to
 * `config.afkRewards.channelId` earns one in-game reward every full
 * `intervalSeconds` (default 60s / 1 reward), delivered to their linked
 * Minecraft account.
 *
 * Deliberately reuses everything that already exists instead of adding a
 * parallel system:
 *   - Discord <-> Minecraft account linking: database/models/MinecraftLink.js
 *     (the same collection /mclink writes to and minecraftDeliveryService.js
 *     reads from for shop purchases).
 *   - Sending the actual in-game command: services/commandQueueService.js's
 *     `enqueueCommand`, the exact same NovaBridge `server_commands` queue
 *     minecraftDeliveryService.js uses - no plugin change needed, since
 *     "console_command" is already a handled command type.
 *   - Command-template rendering (and the username-shape validation that
 *     guards it): minecraftDeliveryService.js's `renderCommandTemplate`.
 *
 * Anti-exploit design (see task requirements):
 *   - One `setInterval` per active AFK session, keyed by `${guildId}:${userId}`
 *     in `activeSessions`. A reward is only ever granted from that interval's
 *     tick, so "one reward per full interval, never per Tick/update" holds
 *     by construction - nothing else in this file grants a reward.
 *   - The session map is the single source of truth for "is this member
 *     currently being timed". `startSession` first clears any existing
 *     timer for the same key before creating a new one, so a duplicate
 *     "join" event (or a restart of this module) can never result in two
 *     intervals - and therefore never two rewards - running for the same
 *     member at once.
 *   - `handleVoiceStateChange` only acts when AFK-membership actually
 *     *changes* (`wasInAfk !== isInAfk`). Discord fires `voiceStateUpdate`
 *     for mute/deaf/streaming toggles too, which would otherwise restart
 *     the timer (and reset the player's progress toward their next
 *     reward) on every unrelated state change while sitting in the
 *     channel; ignoring no-op transitions is what makes "moving to
 *     another channel and back" - the only way to legitimately restart
 *     the timer - behave the same as "reconnecting", i.e. progress
 *     resets to zero and no reward is owed for the discarded partial
 *     minute. Leaving (or moving to any other channel) clears the timer
 *     immediately, so no partial progress can be "banked" toward a
 *     reward by hopping channels.
 *   - The Discord user/guild id used to look up the link comes from
 *     discord.js's `VoiceState.member`, which discord.js populates from
 *     Discord's own gateway payload - it is not client-suppliable input,
 *     so it cannot be forged the way a command argument could be.
 *   - An unlinked member simply never accrues a reward (the tick handler
 *     returns silently) - never an error, never a crash of the interval.
 */

// `${guildId}:${userId}` -> Node interval handle. In-memory by design:
// this bot runs as a single process (see src/index.js - no sharding/
// clustering here), so a plain Map is the whole source of truth for
// "who is currently being timed" with no separate persistence to keep
// in sync or to go stale across restarts.
const activeSessions = new Map();

const DEFAULT_COMMAND_TEMPLATES = {
  // EssentialsX (the most common Vault-backed economy plugin) console command.
  VAULT: 'eco give {player} {amount}',
  // PlayerPoints plugin's own console command.
  PLAYERPOINTS: 'points give {player} {amount}',
};

function sessionKey(guildId, userId) {
  return `${guildId}:${userId}`;
}

/**
 * Validates the parts of config.afkRewards needed to actually deliver a
 * reward. Logged once per misconfigured tick rather than at startup so a
 * config fixed via a restart-less redeploy (env reload) is picked up
 * immediately - this feature is optional and must never crash the bot.
 */
function getValidatedSettings() {
  const { enabled, channelId, targetServerId, reward, intervalSeconds, commandTemplate } = config.afkRewards;
  if (!enabled) return null;
  if (!channelId || !targetServerId) {
    logger.warn('[AFK Rewards] Enabled but AFK_REWARDS_CHANNEL_ID or AFK_REWARDS_TARGET_SERVER_ID is not set - feature inactive.');
    return null;
  }
  if (!DEFAULT_COMMAND_TEMPLATES[reward.type] && !commandTemplate) {
    logger.warn(`[AFK Rewards] Unknown reward type "${reward.type}" (expected VAULT or PLAYERPOINTS) and no AFK_REWARDS_COMMAND_TEMPLATE override - feature inactive.`);
    return null;
  }
  if (!Number.isFinite(reward.amount) || reward.amount <= 0) {
    logger.warn('[AFK Rewards] AFK_REWARDS_AMOUNT must be a positive number - feature inactive.');
    return null;
  }
  if (!Number.isFinite(intervalSeconds) || intervalSeconds <= 0) {
    logger.warn('[AFK Rewards] AFK_REWARDS_INTERVAL_SECONDS must be a positive number - feature inactive.');
    return null;
  }
  return {
    channelId,
    targetServerId,
    rewardType: reward.type,
    amount: reward.amount,
    intervalMs: intervalSeconds * 1000,
    commandTemplate: commandTemplate || DEFAULT_COMMAND_TEMPLATES[reward.type],
  };
}

/**
 * Grants exactly one reward for one completed interval. Never throws -
 * every expected failure path (not linked, misconfigured, queue error)
 * is logged and swallowed so a single bad tick can't take down the
 * interval it's running on (and, since crashing the interval callback
 * doesn't clear it in Node, doesn't produce runaway behavior either).
 */
async function grantReward(guildId, userId, settings) {
  try {
    const link = await MinecraftLink.findOne({ guildId, discordId: userId }).lean();
    if (!link) {
      // Expected/common (most Discord members never run /mclink) - not
      // worth a log line on every skipped tick.
      return;
    }

    let command;
    try {
      command = renderCommandTemplate(settings.commandTemplate, { username: link.minecraftUsername, uuid: link.minecraftUuid });
    } catch (err) {
      if (err instanceof DeliveryError) {
        logger.warn(`[AFK Rewards] Skipped reward for ${userId} in guild ${guildId}: ${err.message}`);
        return;
      }
      throw err;
    }
    command = command.replaceAll('{amount}', String(settings.amount));

    await enqueueCommand(settings.targetServerId, 'console_command', { command }, `discord:${userId}`);
  } catch (err) {
    // Never let a delivery failure kill the interval - the next tick
    // (a full interval later, not a retry) will simply try again.
    logger.error(`[AFK Rewards] Failed to grant reward for ${userId} in guild ${guildId}: ${err?.stack || err}`);
  }
}

/** Starts a fresh per-member timer. Clears any existing one for the same key first so restarting can never double up. */
function startSession(guildId, userId, settings) {
  const key = sessionKey(guildId, userId);
  stopSession(guildId, userId); // defensive: guarantees at most one interval per key

  const intervalId = setInterval(() => {
    grantReward(guildId, userId, settings);
  }, settings.intervalMs);
  // Don't let this timer keep the process alive on its own during shutdown.
  intervalId.unref?.();

  activeSessions.set(key, intervalId);
}

/** Stops (and forgets) the timer for a member, if one is running. Discards any partial progress toward the next reward - by design, see file doc comment. */
function stopSession(guildId, userId) {
  const key = sessionKey(guildId, userId);
  const existing = activeSessions.get(key);
  if (existing) {
    clearInterval(existing);
    activeSessions.delete(key);
  }
}

/**
 * Event-facing entry point - call on every `voiceStateUpdate`. No-ops
 * entirely when the feature is disabled/misconfigured, and again when
 * this particular state change didn't cross the AFK-channel boundary
 * (mute/deaf/streaming toggles, or a change involving neither the old
 * nor the new channel being the AFK channel).
 */
function handleVoiceStateChange(oldState, newState) {
  const settings = getValidatedSettings();
  if (!settings) return;

  const guild = newState.guild || oldState.guild;
  const userId = newState.id || oldState.id;
  if (!guild || !userId) return;

  const wasInAfk = oldState.channelId === settings.channelId;
  const isInAfk = newState.channelId === settings.channelId;

  if (wasInAfk === isInAfk) return; // no actual entry/exit - ignore (e.g. mute/deaf toggle)

  if (isInAfk) {
    startSession(guild.id, userId, settings);
  } else {
    stopSession(guild.id, userId);
  }
}

/** Clears every active timer. Called on bot shutdown (see src/index.js) so a graceful exit doesn't leave dangling intervals. */
function stopAllAfkSessions() {
  for (const intervalId of activeSessions.values()) {
    clearInterval(intervalId);
  }
  activeSessions.clear();
}

module.exports = { handleVoiceStateChange, stopAllAfkSessions };
