const crypto = require('node:crypto');
const LinkCode = require('../database/models/LinkCode');
const MinecraftLink = require('../database/models/MinecraftLink');
const logger = require('../utils/logger');

const CODE_LENGTH = 8;
const CODE_TTL_MINUTES = 10;
// No 0/O/1/I/L - removes the pairs people most often misread or mistype
// when copying a code from a Discord DM into a Minecraft chat box.
const CODE_ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';

function randomCode() {
  let out = '';
  const bytes = crypto.randomBytes(CODE_LENGTH);
  for (let i = 0; i < CODE_LENGTH; i++) {
    out += CODE_ALPHABET[bytes[i] % CODE_ALPHABET.length];
  }
  return out;
}

/**
 * Creates a new pending link code for this Discord member in this guild.
 * Any earlier still-pending code of theirs is invalidated first, so a
 * member can only ever have one live code at a time (re-running /link is
 * the "resend/regenerate" flow).
 *
 * @returns {Promise<{ code: string, expiresAt: Date }>}
 */
async function createLinkCode(guildId, discordId) {
  await LinkCode.deleteMany({ guildId, discordId, status: 'pending' });

  const expiresAt = new Date(Date.now() + CODE_TTL_MINUTES * 60 * 1000);

  // Retry on the astronomically unlikely chance of a code collision -
  // the unique index is the real guarantee, this just avoids surfacing
  // that as an error to the user.
  for (let attempt = 0; attempt < 5; attempt++) {
    const code = randomCode();
    try {
      await LinkCode.create({ guildId, discordId, code, expiresAt });
      return { code, expiresAt };
    } catch (err) {
      if (err.code === 11000) continue; // duplicate code, try again
      throw err;
    }
  }
  throw new Error('Failed to generate a unique link code after several attempts.');
}

/** Looks up a still-valid (pending, not expired) code. Used by /link's own duplicate checks and available for the future in-game command to reuse. */
async function findActiveCode(code) {
  return LinkCode.findOne({ code, status: 'pending', expiresAt: { $gt: new Date() } });
}

/**
 * Background poller: picks up codes the (future) in-game confirmation
 * command has marked "completed" and turns them into a real MinecraftLink,
 * then DMs the member the outcome. Safe to run before that in-game command
 * exists - it will simply never find any "completed" documents yet.
 */
function startLinkCodeWatcher(client) {
  const check = async () => {
    try {
      const completed = await LinkCode.find({ status: 'completed', finalizedAt: null }).limit(20);

      for (const entry of completed) {
        await finalizeCode(client, entry);
      }
    } catch (err) {
      logger.error(`Link code watcher error: ${err.message}`);
    }
  };

  check();
  setInterval(check, 5_000);
}

async function finalizeCode(client, entry) {
  try {
    await MinecraftLink.create({
      guildId: entry.guildId,
      discordId: entry.discordId,
      minecraftUuid: entry.minecraftUuid,
      minecraftUsername: entry.minecraftUsername,
      linkedBy: entry.discordId,
    });

    entry.status = 'finalized';
    entry.finalizedAt = new Date();
    await entry.save();

    await dmUser(
      client,
      entry.discordId,
      `✅ تم ربط حسابك بنجاح مع **${entry.minecraftUsername}**.`
    );
  } catch (err) {
    // Duplicate key = the Discord account or that Minecraft account got
    // linked (or claimed) by someone else in the small window since the
    // code was issued. That's a real, final outcome - not a transient
    // error - so mark it finalized too instead of retrying forever.
    if (err.code === 11000) {
      entry.status = 'failed';
      entry.finalizedAt = new Date();
      entry.failureReason = 'duplicate_link';
      await entry.save();

      await dmUser(
        client,
        entry.discordId,
        '❌ تعذر إتمام الربط: حسابك أو حساب الماينكرافت أصبح مرتبطاً بالفعل قبل إكمال هذه الخطوة.'
      );
      return;
    }

    // Anything else (e.g. a momentary DB hiccup) is left un-finalized so
    // the next poll tick retries it instead of silently dropping it.
    logger.error(`Failed to finalize link code ${entry.code}: ${err.message}`);
  }
}

async function dmUser(client, discordId, content) {
  try {
    const user = await client.users.fetch(discordId);
    await user.send({ content });
  } catch (err) {
    logger.warn(`Could not DM ${discordId} about their link code result: ${err.message}`);
  }
}

module.exports = { createLinkCode, findActiveCode, startLinkCodeWatcher };
