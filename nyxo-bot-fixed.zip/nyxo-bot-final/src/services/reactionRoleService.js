const ReactionRole = require('../database/models/ReactionRole');

/** Normalizes a reaction's emoji into the same string form mappings are stored with. */
function emojiKey(emoji) {
  return emoji.id ? `<:${emoji.name}:${emoji.id}>` : emoji.name;
}

async function handleReactionAdd(reaction, user) {
  if (user.bot) return;

  const config = await ReactionRole.findOne({ messageId: reaction.message.id });
  if (!config) return;

  const mapping = config.mappings.find((m) => m.emoji === emojiKey(reaction.emoji));
  if (!mapping) return;

  const member = await reaction.message.guild.members.fetch(user.id).catch(() => null);
  if (!member) return;

  await member.roles.add(mapping.roleId).catch(() => null);
}

async function handleReactionRemove(reaction, user) {
  if (user.bot) return;

  const config = await ReactionRole.findOne({ messageId: reaction.message.id });
  if (!config) return;

  const mapping = config.mappings.find((m) => m.emoji === emojiKey(reaction.emoji));
  if (!mapping) return;

  const member = await reaction.message.guild.members.fetch(user.id).catch(() => null);
  if (!member) return;

  await member.roles.remove(mapping.roleId).catch(() => null);
}

module.exports = { emojiKey, handleReactionAdd, handleReactionRemove };
