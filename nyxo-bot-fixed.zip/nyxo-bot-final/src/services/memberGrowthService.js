const schedule = require('node-schedule');
const MemberGrowth = require('../database/models/memberGrowthSchema');
const logger = require('../utils/logger');

function getTodayNormalized() {
  const today = new Date();
  today.setUTCHours(0, 0, 0, 0);
  return today;
}

/** Upserts today's member count for every guild the bot is in. */
async function recordMemberCounts(client) {
  const today = getTodayNormalized();
  let success = 0;
  let failed = 0;

  for (const [guildId, guild] of client.guilds.cache) {
    try {
      await MemberGrowth.findOneAndUpdate(
        { guildId, date: today },
        { count: guild.memberCount },
        { upsert: true }
      );
      success += 1;
    } catch (err) {
      failed += 1;
      logger.error(`[MemberGrowth] Failed to record guild ${guildId}: ${err.stack || err}`);
    }
  }

  logger.info(`[MemberGrowth] Recorded daily snapshot (${success} ok, ${failed} failed)`);
}

/** Last `days` recorded member-count points for a guild, oldest first. */
async function getGrowthHistory(guildId, days = 14) {
  return MemberGrowth.find({ guildId }).sort({ date: -1 }).limit(days).then((docs) => docs.reverse());
}

/** Starts the daily (00:05 UTC) recording job, plus one run shortly after boot. */
function startMemberGrowthScheduler(client) {
  schedule.scheduleJob('memberGrowth-daily', '5 0 * * *', () => recordMemberCounts(client));

  setTimeout(() => {
    recordMemberCounts(client).catch((err) => logger.error(`[MemberGrowth] Startup run failed: ${err.stack || err}`));
  }, 15_000);

  logger.success('Member growth tracker scheduled');
}

module.exports = { startMemberGrowthScheduler, getGrowthHistory, recordMemberCounts };
