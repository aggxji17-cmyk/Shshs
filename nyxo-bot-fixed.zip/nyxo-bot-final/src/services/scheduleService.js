const mongoose = require('mongoose');
const ScheduledTask = require('../database/models/ScheduledTask');
const { getGuildConfig, resolved } = require('../utils/resolveGuildSettings');
const { sendModerationLog } = require('../utils/moderationLogService');
const { isServerOwner, outranksExecutor } = require('../utils/moderationGuards');
const { baseEmbed } = require('../utils/embeds');
const { createCase, findActiveBanCase, revertCase } = require('./caseService');
const { recordBan } = require('../utils/banLimitService');
const { recordKick } = require('../utils/kickLimitService');
const { recordTimeout } = require('../utils/timeoutLimitService');
const { recordSoftban } = require('../utils/softbanLimitService');
const logger = require('../utils/logger');

const POLL_INTERVAL_MS = 15_000;
const MAX_ATTEMPTS = 3;
const RETRY_BACKOFF_MS = 5 * 60_000; // wait 5 minutes before retrying a failed task
const BATCH_SIZE = 25;

let pollTimer = null;

// ---------------------------------------------------------------------------
// CRUD - used by commands/moderation/schedule.js
// ---------------------------------------------------------------------------

/** Creates a new scheduled task. `executeAt` must already be a Date in the future. */
async function createScheduledTask({ guildId, action, moderatorId, targetId, reason, durationMinutes = null, deleteDays = 0, channelId = null, roleId = null, executeAt }) {
  return ScheduledTask.create({
    guildId,
    action,
    moderatorId,
    targetId,
    reason: reason || 'No reason provided',
    durationMinutes,
    deleteDays,
    channelId,
    roleId,
    executeAt,
  });
}

/** Soonest-due-first list of a guild's scheduled tasks, optionally filtered by status and/or action. Backs /schedule list and /temprole list. */
async function listScheduledTasks(guildId, { status, action, limit = 10 } = {}) {
  const query = { guildId };
  if (status) query.status = status;
  if (action) query.action = action;
  return ScheduledTask.find(query).sort({ executeAt: 1 }).limit(limit);
}

/** Fetches one task, scoped to the guild it belongs to. */
async function getScheduledTask(guildId, taskId) {
  if (!mongoose.Types.ObjectId.isValid(taskId)) return null;
  return ScheduledTask.findOne({ _id: taskId, guildId });
}

/**
 * Finds the single Pending task for a given action+target (and, for
 * role-based actions, a specific role) in a guild. Generic over `action`
 * so any future per-target scheduled task (not just temprole_remove) can
 * use it for duplicate-checks and lookups instead of writing its own query.
 */
async function findPendingTask(guildId, action, targetId, roleId = null) {
  const query = { guildId, action, targetId, status: 'Pending' };
  if (roleId) query.roleId = roleId;
  return ScheduledTask.findOne(query);
}

/**
 * Pushes a Pending task's executeAt forward (or backward) by extraMs.
 * Returns the task either way, same not-found/not-Pending/success shape
 * as cancelScheduledTask, so callers can handle all three the same way.
 * Backs /schedule-style "extend" flows for any action, not just temprole.
 */
async function extendScheduledTask(guildId, taskId, extraMs) {
  const task = await getScheduledTask(guildId, taskId);
  if (!task) return null;
  if (task.status !== 'Pending') return task;

  task.executeAt = new Date(task.executeAt.getTime() + extraMs);
  await task.save();
  return task;
}

/**
 * Cancels a Pending task. Returns the task either way so the caller can
 * tell "not found" (null) apart from "found but already resolved"
 * (task.status !== 'Pending' on the returned doc) apart from "cancelled
 * successfully" (task.status === 'Cancelled').
 */
async function cancelScheduledTask(guildId, taskId, cancelledBy) {
  const task = await getScheduledTask(guildId, taskId);
  if (!task) return null;
  if (task.status !== 'Pending') return task;

  task.status = 'Cancelled';
  task.cancelledBy = cancelledBy;
  await task.save();
  return task;
}

// ---------------------------------------------------------------------------
// Execution
// ---------------------------------------------------------------------------

/**
 * Posts the moderation-log embed for a task that produced a real Case,
 * reusing the exact same utils/moderationLogService.js every manual
 * moderation command already uses. Shared by every case-producing handler
 * below instead of each one re-fetching users and building the call.
 */
async function logExecutedCase(client, guild, task, caseDoc, durationMinutes = null) {
  const guildConfig = await getGuildConfig(task.guildId);
  const settings = resolved(guildConfig);
  const moderator = await client.users.fetch(task.moderatorId).catch(() => null);
  const target = await client.users.fetch(task.targetId).catch(() => null);
  if (!moderator || !target) return;

  await sendModerationLog(guild, guildConfig, settings, {
    action: task.action,
    moderator,
    target,
    reason: task.reason,
    durationMinutes,
    caseId: caseDoc.caseId,
  });
}

/** Builds a fake "interaction" shaped just enough for moderationGuards.outranksExecutor to work with a moderator ID instead of a live interaction. */
function pseudoInteraction(guild, moderatorMember, moderatorId) {
  return { user: { id: moderatorId }, guild, member: moderatorMember };
}

async function executeBan(client, task) {
  const guild = await client.guilds.fetch(task.guildId).catch(() => null);
  if (!guild) throw new Error('Guild not found - the bot may have left the server.');
  if (isServerOwner(guild, task.targetId)) throw new Error('Cannot ban the server owner.');

  const targetMember = await guild.members.fetch(task.targetId).catch(() => null);
  const moderatorMember = await guild.members.fetch(task.moderatorId).catch(() => null);

  if (moderatorMember && outranksExecutor(pseudoInteraction(guild, moderatorMember, task.moderatorId), targetMember)) {
    throw new Error('Target now outranks the scheduling moderator.');
  }
  if (targetMember && !targetMember.bannable) {
    throw new Error('Bot cannot ban this member (role hierarchy or missing permissions).');
  }

  await guild.members.ban(task.targetId, { deleteMessageSeconds: (task.deleteDays || 0) * 86400, reason: task.reason });
  await recordBan(task.guildId, task.moderatorId, task.targetId, task.reason);

  const caseDoc = await createCase({ guildId: task.guildId, action: 'ban', moderatorId: task.moderatorId, targetId: task.targetId, reason: task.reason });
  await logExecutedCase(client, guild, task, caseDoc);
  return caseDoc;
}

async function executeKick(client, task) {
  const guild = await client.guilds.fetch(task.guildId).catch(() => null);
  if (!guild) throw new Error('Guild not found - the bot may have left the server.');
  if (isServerOwner(guild, task.targetId)) throw new Error('Cannot kick the server owner.');

  const targetMember = await guild.members.fetch(task.targetId).catch(() => null);
  if (!targetMember) throw new Error('Target is no longer a member of the server.');

  const moderatorMember = await guild.members.fetch(task.moderatorId).catch(() => null);
  if (moderatorMember && outranksExecutor(pseudoInteraction(guild, moderatorMember, task.moderatorId), targetMember)) {
    throw new Error('Target now outranks the scheduling moderator.');
  }
  if (!targetMember.kickable) throw new Error('Bot cannot kick this member (role hierarchy or missing permissions).');

  await targetMember.kick(task.reason);
  await recordKick(task.guildId, task.moderatorId, task.targetId, task.reason);

  const caseDoc = await createCase({ guildId: task.guildId, action: 'kick', moderatorId: task.moderatorId, targetId: task.targetId, reason: task.reason });
  await logExecutedCase(client, guild, task, caseDoc);
  return caseDoc;
}

async function executeTimeout(client, task) {
  const guild = await client.guilds.fetch(task.guildId).catch(() => null);
  if (!guild) throw new Error('Guild not found - the bot may have left the server.');
  if (isServerOwner(guild, task.targetId)) throw new Error('Cannot timeout the server owner.');

  const targetMember = await guild.members.fetch(task.targetId).catch(() => null);
  if (!targetMember) throw new Error('Target is no longer a member of the server.');

  const moderatorMember = await guild.members.fetch(task.moderatorId).catch(() => null);
  if (moderatorMember && outranksExecutor(pseudoInteraction(guild, moderatorMember, task.moderatorId), targetMember)) {
    throw new Error('Target now outranks the scheduling moderator.');
  }
  if (!targetMember.moderatable) throw new Error('Bot cannot timeout this member (role hierarchy or missing permissions).');

  const minutes = task.durationMinutes || 10;
  await targetMember.timeout(minutes * 60 * 1000, task.reason);
  await recordTimeout(task.guildId, task.moderatorId, task.targetId, task.reason, { durationMinutes: minutes });

  const caseDoc = await createCase({
    guildId: task.guildId,
    action: 'timeout',
    moderatorId: task.moderatorId,
    targetId: task.targetId,
    reason: task.reason,
    durationMinutes: minutes,
  });
  await logExecutedCase(client, guild, task, caseDoc, minutes);
  return caseDoc;
}

/**
 * Not currently reachable from /schedule (no 'softban' subcommand there),
 * but registered here so services/approvalService.js can run an approved
 * softban through the exact same guarded, Case-and-log-producing path as
 * every other action instead of re-implementing it.
 */
async function executeSoftban(client, task) {
  const guild = await client.guilds.fetch(task.guildId).catch(() => null);
  if (!guild) throw new Error('Guild not found - the bot may have left the server.');
  if (isServerOwner(guild, task.targetId)) throw new Error('Cannot softban the server owner.');

  const targetMember = await guild.members.fetch(task.targetId).catch(() => null);
  const moderatorMember = await guild.members.fetch(task.moderatorId).catch(() => null);

  if (moderatorMember && outranksExecutor(pseudoInteraction(guild, moderatorMember, task.moderatorId), targetMember)) {
    throw new Error('Target now outranks the requesting moderator.');
  }
  if (targetMember && !targetMember.bannable) {
    throw new Error('Bot cannot softban this member (role hierarchy or missing permissions).');
  }

  await guild.members.ban(task.targetId, { deleteMessageSeconds: (task.deleteDays || 0) * 86400, reason: task.reason });
  await guild.members.unban(task.targetId, 'Softban - automatic unban').catch(() => null);
  await recordSoftban(task.guildId, task.moderatorId, task.targetId, task.reason);

  const caseDoc = await createCase({ guildId: task.guildId, action: 'softban', moderatorId: task.moderatorId, targetId: task.targetId, reason: task.reason });
  await logExecutedCase(client, guild, task, caseDoc);
  return caseDoc;
}

async function executeUnban(client, task) {
  const guild = await client.guilds.fetch(task.guildId).catch(() => null);
  if (!guild) throw new Error('Guild not found - the bot may have left the server.');

  const banEntry = await guild.bans.fetch(task.targetId).catch(() => null);
  if (!banEntry) throw new Error('User is not banned in this guild (already unbanned, or never banned).');

  await guild.members.unban(task.targetId, task.reason);

  // Same "close out the existing ban Case instead of creating a
  // disconnected one" logic as the manual /unban command - reused via
  // caseService, not reimplemented here.
  const activeBanCase = await findActiveBanCase(task.guildId, task.targetId);
  const caseDoc = activeBanCase
    ? await revertCase(task.guildId, activeBanCase.caseId, { revertedBy: task.moderatorId, revertReason: task.reason })
    : await createCase({ guildId: task.guildId, action: 'unban', moderatorId: task.moderatorId, targetId: task.targetId, reason: task.reason });

  await logExecutedCase(client, guild, task, caseDoc);
  return caseDoc;
}

/**
 * Sends a scheduled message to a channel (or DMs the target if no channel
 * was set). Unlike the four actions above, this is not a punishment -
 * Case's `action` enum is intentionally limited to real moderation
 * actions (ban/kick/timeout/warn/unban/softban), so no Case is created
 * and this never touches /modhistory or /userinfo. Returns null so the
 * generic runner knows to skip the Case-linking step.
 */
async function executeMessage(client, task) {
  const guild = await client.guilds.fetch(task.guildId).catch(() => null);
  if (!guild) throw new Error('Guild not found - the bot may have left the server.');

  const guildConfig = await getGuildConfig(task.guildId);
  const settings = resolved(guildConfig);
  const embed = baseEmbed(settings).setDescription(task.reason);

  if (task.channelId) {
    const channel = await guild.channels.fetch(task.channelId).catch(() => null);
    if (!channel) throw new Error('Target channel no longer exists.');
    await channel.send({ content: `<@${task.targetId}>`, embeds: [embed] });
    return null;
  }

  const user = await client.users.fetch(task.targetId).catch(() => null);
  if (!user) throw new Error('Target user could not be found.');

  await user.send({ embeds: [embed] }).catch(() => {
    throw new Error('Could not DM the target (their DMs are closed).');
  });
  return null;
}

/**
 * Action name -> handler function. The poller only ever calls through
 * this map, so it never needs to change when a new action is added.
 */
const HANDLERS = {
  ban: executeBan,
  kick: executeKick,
  timeout: executeTimeout,
  softban: executeSoftban,
  unban: executeUnban,
  message: executeMessage,
  // services/approvalService.js is required lazily (inside the call, not
  // at module load time) so the two files can reference each other
  // without a require cycle: approvalService needs
  // scheduleService.createScheduledTask/getActionExecutor at load time,
  // scheduleService only needs approvalService once a task actually fires.
  approval_expire: (client, task) => require('./approvalService').expireRequest(client, task.guildId, task.targetId),
};

/** Registers a handler for a new schedulable action. Add the action name to ScheduledTask.SCHEDULABLE_ACTIONS too. */
function registerHandler(action, handlerFn) {
  HANDLERS[action] = handlerFn;
}

/**
 * Looks up the executor for a given action (ban/kick/timeout/softban/...).
 * services/approvalService.js calls this on Approve so an approved request
 * runs through the identical guarded, Case-and-log-producing code every
 * scheduled task already uses - no separate execution path to maintain.
 */
function getActionExecutor(action) {
  return HANDLERS[action] || null;
}

/**
 * Runs one due task. On success: marks it Completed and links the Case
 * that was created (if any). On failure: records the error, and either
 * pushes `executeAt` forward for another attempt or - once MAX_ATTEMPTS
 * is reached - marks it Failed with the reason kept on `lastError`. This
 * is also what naturally handles a task whose time already passed while
 * the bot was offline: it simply runs on the very next poll, and if it no
 * longer makes sense (e.g. the target already left the server) it fails
 * and is marked Failed instead of retrying forever.
 */
async function runTask(client, task) {
  const handler = HANDLERS[task.action];
  if (!handler) {
    task.status = 'Failed';
    task.lastError = `No handler registered for action "${task.action}".`;
    task.executedAt = new Date();
    await task.save();
    return;
  }

  try {
    const caseDoc = await handler(client, task);
    task.status = 'Completed';
    task.executedAt = new Date();
    task.caseId = caseDoc ? caseDoc.caseId : null;
    task.lastError = null;
    await task.save();
  } catch (err) {
    task.attempts += 1;
    task.lastError = err?.message || String(err);

    if (task.attempts >= MAX_ATTEMPTS) {
      task.status = 'Failed';
      task.executedAt = new Date();
    } else {
      task.executeAt = new Date(Date.now() + RETRY_BACKOFF_MS);
    }

    await task.save();
    logger.warn(`Scheduled ${task.action} task ${task._id} attempt ${task.attempts} failed: ${task.lastError}`);
  }
}

async function pollAndExecute(client) {
  const due = await ScheduledTask.find({ status: 'Pending', executeAt: { $lte: new Date() } })
    .sort({ executeAt: 1 })
    .limit(BATCH_SIZE);

  for (const task of due) {
    await runTask(client, task);
  }
}

/**
 * Starts the scheduler loop. Runs one pass immediately - so anything that
 * came due while the bot was offline (including a task that predates this
 * restart entirely) fires as soon as possible instead of waiting a full
 * POLL_INTERVAL_MS - then keeps polling on a self-rescheduling timeout.
 * A plain setInterval is deliberately avoided: it would let a second pass
 * start while a slow one is still running, and duplicate execution of the
 * same task is exactly what this is meant to prevent. Call once from the
 * client's `clientReady` event, same as every other scheduler in
 * events/client/ready.js.
 */
function startScheduler(client) {
  async function loop() {
    try {
      await pollAndExecute(client);
    } catch (err) {
      logger.error(`Scheduled moderation poll failed: ${err.stack || err}`);
    } finally {
      pollTimer = setTimeout(loop, POLL_INTERVAL_MS);
    }
  }
  loop();
}

function stopScheduler() {
  if (pollTimer) clearTimeout(pollTimer);
  pollTimer = null;
}

module.exports = {
  createScheduledTask,
  listScheduledTasks,
  getScheduledTask,
  findPendingTask,
  extendScheduledTask,
  cancelScheduledTask,
  startScheduler,
  stopScheduler,
  registerHandler,
  getActionExecutor,
};
