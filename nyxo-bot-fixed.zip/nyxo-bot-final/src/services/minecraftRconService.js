const net = require('node:net');
const { config } = require('../config/config');

const PACKET_HEADER_SIZE = 4;
const PACKET_TERMINATOR_SIZE = 2;
const PACKET_TYPE_AUTH = 3;
const PACKET_TYPE_COMMAND = 2;
const PACKET_TYPE_RESPONSE = 0;
const RCON_TIMEOUT_MS = 8_000;

class RconNotConfiguredError extends Error {
  constructor() {
    super('Minecraft RCON is not configured.');
    this.name = 'RconNotConfiguredError';
  }
}

class RconAuthenticationError extends Error {
  constructor() {
    super('Minecraft RCON authentication failed.');
    this.name = 'RconAuthenticationError';
  }
}

function nextRequestId() {
  return Math.floor(Math.random() * 2_000_000_000) + 1;
}

function buildPacket(requestId, type, payload) {
  const payloadBuffer = Buffer.from(String(payload), 'utf8');
  const body = Buffer.alloc(4 + 4 + payloadBuffer.length + PACKET_TERMINATOR_SIZE);
  body.writeInt32LE(requestId, 0);
  body.writeInt32LE(type, 4);
  payloadBuffer.copy(body, 8);

  const packet = Buffer.alloc(PACKET_HEADER_SIZE + body.length);
  packet.writeInt32LE(body.length, 0);
  body.copy(packet, PACKET_HEADER_SIZE);
  return packet;
}

function createPacketReader(socket) {
  let buffer = Buffer.alloc(0);
  const pending = [];
  let ended = false;

  function rejectAll(error) {
    ended = true;
    while (pending.length) pending.shift().reject(error);
  }

  function parse() {
    while (buffer.length >= PACKET_HEADER_SIZE) {
      const length = buffer.readInt32LE(0);
      if (length < 10 || length > 1_048_576) {
        rejectAll(new Error('Invalid Minecraft RCON packet length.'));
        return;
      }
      if (buffer.length < PACKET_HEADER_SIZE + length) return;

      const packet = buffer.subarray(PACKET_HEADER_SIZE, PACKET_HEADER_SIZE + length);
      buffer = buffer.subarray(PACKET_HEADER_SIZE + length);
      const result = {
        requestId: packet.readInt32LE(0),
        type: packet.readInt32LE(4),
        body: packet.subarray(8, length - PACKET_TERMINATOR_SIZE).toString('utf8'),
      };
      pending.shift()?.resolve(result);
    }
  }

  socket.on('data', (chunk) => {
    buffer = Buffer.concat([buffer, chunk]);
    parse();
  });
  socket.on('error', rejectAll);
  socket.on('close', () => rejectAll(new Error('Minecraft RCON connection closed.')));

  return () => new Promise((resolve, reject) => {
    if (ended) {
      reject(new Error('Minecraft RCON connection is no longer available.'));
      return;
    }
    pending.push({ resolve, reject });
    parse();
  });
}

function openSocket() {
  return new Promise((resolve, reject) => {
    const socket = net.createConnection({
      host: config.minecraft.rcon.host,
      port: config.minecraft.rcon.port,
    });
    const timer = setTimeout(() => {
      socket.destroy();
      reject(new Error('Minecraft RCON connection timed out.'));
    }, RCON_TIMEOUT_MS);

    socket.once('connect', () => {
      clearTimeout(timer);
      socket.setTimeout(RCON_TIMEOUT_MS, () => socket.destroy(new Error('Minecraft RCON response timed out.')));
      resolve(socket);
    });
    socket.once('error', (error) => {
      clearTimeout(timer);
      reject(error);
    });
  });
}

async function executeRconCommand(command) {
  if (!config.minecraft.rcon.enabled || !config.minecraft.rcon.password) {
    throw new RconNotConfiguredError();
  }

  const socket = await openSocket();
  const readPacket = createPacketReader(socket);
  const authId = nextRequestId();

  try {
    socket.write(buildPacket(authId, PACKET_TYPE_AUTH, config.minecraft.rcon.password));
    const authResponse = await readPacket();
    if (authResponse.requestId === -1) throw new RconAuthenticationError();

    const commandId = nextRequestId();
    socket.write(buildPacket(commandId, PACKET_TYPE_COMMAND, command));
    const response = await readPacket();
    if (response.requestId !== commandId || response.type !== PACKET_TYPE_RESPONSE) {
      throw new Error('Minecraft RCON returned an unexpected response.');
    }
    return response.body.trim();
  } finally {
    socket.end();
  }
}

module.exports = {
  executeRconCommand,
  RconNotConfiguredError,
  RconAuthenticationError,
};