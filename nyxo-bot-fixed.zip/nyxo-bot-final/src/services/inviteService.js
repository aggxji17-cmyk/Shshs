const InviteCache = require('../database/models/InviteCache');
const InviteStat = require('../database/models/InviteStat');
const logger = require('../utils/logger');

/**
 * Snapshots every invite currently on a guild into InviteCache. Call this
 * on ready (for every guild) and after inviteCreate/inviteDelete so the
 * cache used to diff use-counts in guildMemberAdd stays accurate.
 */
async function cacheGuildInvites(guild) {
  const invites = await guild.invites.fetch().catch(() => null);
  if (!invites) return;

  for (const invite of invites.values()) {
    await InviteCache.findOneAndUpdate(
      { guildId: guild.id, code: invite.code },
      { inviterId: invite.inviter?.id || null, uses: invite.uses || 0 },
      { upsert: true }
    ).catch((err) => logger.warn(`Invite cache upsert failed for ${guild.id}/${invite.code}: ${err.message}`));
  }

  // Drop cached codes that no longer exist (expired/deleted/revoked).
  const liveCodes = [...invites.keys()];
  await InviteCache.deleteMany({ guildId: guild.id, code: { $nin: liveCodes } }).catch(() => null);
}

/**
 * Diffs the guild's current invite uses against the cache to figure out
 * which invite a newly-joined member used, then updates the cache and the
 * inviter's running stat. Returns the inviter's user ID, or null if it
 * could not be determined (e.g. vanity URL, or invite already deleted).
 */
async function resolveJoinInvite(guild) {
  const [current, cached] = await Promise.all([
    guild.invites.fetch().catch(() => null),
    InviteCache.find({ guildId: guild.id }),
  ]);
  if (!current) return null;

  const cachedByCode = new Map(cached.map((c) => [c.code, c.uses]));
  const used = [...current.values()].find((inv) => (inv.uses || 0) > (cachedByCode.get(inv.code) || 0));

  await cacheGuildInvites(guild);

  if (!used || !used.inviter) return null;

  await InviteStat.findOneAndUpdate(
    { guildId: guild.id, userId: used.inviter.id },
    { $inc: { count: 1 } },
    { upsert: true }
  );

  return used.inviter.id;
}

async function getInviteCount(guildId, userId) {
  const stat = await InviteStat.findOne({ guildId, userId });
  return stat?.count || 0;
}

module.exports = { cacheGuildInvites, resolveJoinInvite, getInviteCount };
