const schedule = require('node-schedule');
const { EmbedBuilder } = require('discord.js');
const ServerSnapshot = require('../database/models/serverSnapshotSchema');
const SmartAlertConfig = require('../database/models/smartAlertConfigSchema');
const StaffRole = require('../database/models/staffRoleSchema');
const { config } = require('../config/config');
const logger = require('../utils/logger');

function getTodayNormalized() {
  const today = new Date();
  today.setUTCHours(0, 0, 0, 0);
  return today;
}

// trackStaffActivity() below runs on every single message in every guild,
// so a DB round-trip per message just to check whether a staff role is
// configured is wasteful for the common case (most guilds never set one
// up). Cached the same way resolveGuildSettings.js caches GuildConfig.
const staffRoleCache = new Map(); // guildId -> { value, at }
const STAFF_ROLE_CACHE_TTL_MS = 30_000;

async function getCachedStaffRole(guildId) {
  const cached = staffRoleCache.get(guildId);
  if (cached && Date.now() - cached.at < STAFF_ROLE_CACHE_TTL_MS) {
    return cached.value;
  }

  // Bug fix: this used to query { Guild: guildId }, but the schema (and
  // its index) defines the field as `guildId` - the mismatched field name
  // meant this always missed (staff activity tracking silently never
  // worked) and, worse, ran an unindexed query against the field it
  // actually used on every message in every guild.
  const staffConfig = await StaffRole.findOne({ guildId }).lean();
  staffRoleCache.set(guildId, { value: staffConfig, at: Date.now() });
  return staffConfig;
}

/** Bumps today's ban counter for a guild. Called from events/guild's guildBanAdd listener. */
async function trackBan(guild) {
  try {
    const today = getTodayNormalized();
    await ServerSnapshot.findOneAndUpdate(
      { guildId: guild.id, date: today },
      { $inc: { banCount: 1 } },
      { upsert: true }
    );
  } catch (err) {
    logger.error(`[SmartAlerts] Failed to track ban for guild ${guild.id}: ${err.stack || err}`);
  }
}

/** Bumps today's message counter for a message author, only if they hold this guild's configured staff-help role. Called from events/message's messageCreate listener. */
async function trackStaffActivity(message) {
  if (message.author.bot || !message.guild || !message.member) return;

  try {
    const staffConfig = await getCachedStaffRole(message.guild.id);
    if (!staffConfig?.Role) return;
    if (!message.member.roles.cache.has(staffConfig.Role)) return;

    const today = getTodayNormalized();
    const updated = await ServerSnapshot.findOneAndUpdate(
      { guildId: message.guild.id, date: today, 'modActivity.userId': message.author.id },
      { $inc: { 'modActivity.$.messageCount': 1 } },
      { new: true }
    );

    if (!updated) {
      await ServerSnapshot.findOneAndUpdate(
        { guildId: message.guild.id, date: today },
        { $push: { modActivity: { userId: message.author.id, messageCount: 1 } } },
        { upsert: true }
      );
    }
  } catch (err) {
    logger.error(`[SmartAlerts] Failed to track staff activity in guild ${message.guild.id}: ${err.stack || err}`);
  }
}

/** Records today's member count for every guild with Smart Alerts enabled (feeds the weekly report). */
async function recordDailySnapshots(client) {
  const today = getTodayNormalized();
  for (const [guildId, guild] of client.guilds.cache) {
    try {
      await ServerSnapshot.findOneAndUpdate(
        { guildId, date: today },
        { memberCount: guild.memberCount },
        { upsert: true }
      );
    } catch (err) {
      logger.error(`[SmartAlerts] Failed to snapshot guild ${guildId}: ${err.stack || err}`);
    }
  }
}

/** Rule-based (no external AI call) trend analysis over a window of daily snapshots. */
function analyzeSnapshots(data) {
  const latest = data[data.length - 1];
  const earliest = data[0];

  const memberDiff = earliest.memberCount
    ? ((latest.memberCount - earliest.memberCount) / earliest.memberCount) * 100
    : 0;
  const banSpike = data.some((s) => s.banCount > 5);
  const totalModMessages = (s) => s.modActivity.reduce((acc, m) => acc + m.messageCount, 0);
  const modActivityDrop = totalModMessages(latest) < totalModMessages(earliest) * 0.5 && totalModMessages(earliest) > 0;

  let status = 'Healthy';
  const anomalies = [];
  let summary = 'Server health is stable. Growth and moderation activity are within normal ranges.';

  if (memberDiff < -10) {
    status = 'Caution';
    anomalies.push(`Membership dropped by ${Math.abs(memberDiff).toFixed(1)}%`);
    summary = 'There has been a noticeable drop in membership recently.';
  }
  if (banSpike) {
    status = 'Caution';
    anomalies.push('Unusual spike in bans detected');
    summary = 'Moderation actions have increased significantly this week.';
  }
  if (modActivityDrop) {
    status = 'Caution';
    anomalies.push('Staff activity dropped by more than 50%');
    summary = 'Staff engagement has decreased. It may be worth checking in with your team.';
  }
  if (anomalies.length >= 2 || memberDiff < -30) {
    status = 'Critical';
    summary = 'Multiple concerns detected in server stability and growth this week.';
  }

  return { status, summary, anomalies };
}

async function runHealthCheck(client, guildId, channelId) {
  const snapshots = await ServerSnapshot.find({ guildId }).sort({ date: 1 }).limit(14);
  if (snapshots.length < 7) return; // not enough history yet

  const analysis = analyzeSnapshots(snapshots);
  const channel = client.channels.cache.get(channelId);
  if (!channel) return;

  const color = analysis.status === 'Healthy' ? '#57F287' : analysis.status === 'Caution' ? '#FEE75C' : '#ED4245';

  const embed = new EmbedBuilder()
    .setTitle('🩺 Weekly Server Health Report')
    .setColor(color)
    .setDescription(analysis.summary)
    .addFields(
      { name: 'Status', value: analysis.status, inline: true },
      { name: 'Anomalies', value: analysis.anomalies.join('\n') || 'None detected' }
    )
    .setFooter({ text: config.embedFooter })
    .setTimestamp();

  await channel.send({ embeds: [embed] }).catch((err) =>
    logger.error(`[SmartAlerts] Failed to send report to guild ${guildId}: ${err.stack || err}`)
  );
}

async function runWeeklyReports(client) {
  const configs = await SmartAlertConfig.find({ enabled: true });
  for (const cfg of configs) {
    try {
      await runHealthCheck(client, cfg.guildId, cfg.channelId);
    } catch (err) {
      logger.error(`[SmartAlerts] Health check failed for guild ${cfg.guildId}: ${err.stack || err}`);
    }
  }
}

/** Starts the daily snapshot job (00:10 UTC) and the weekly report job (Sundays 02:00 UTC). */
function startSmartAlertsScheduler(client) {
  schedule.scheduleJob('smartAlerts-daily-snapshot', '10 0 * * *', () => recordDailySnapshots(client));
  schedule.scheduleJob('smartAlerts-weekly-report', '0 2 * * 0', () => runWeeklyReports(client));
  logger.success('Smart alerts scheduler started');
}

module.exports = { startSmartAlertsScheduler, trackBan, trackStaffActivity };
