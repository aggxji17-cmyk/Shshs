const Announcement = require('../database/models/Announcement');
const { getGuildConfig, resolved } = require('../utils/resolveGuildSettings');
const { baseEmbed } = require('../utils/embeds');
const logger = require('../utils/logger');

const POLL_INTERVAL_MS = 30_000;
const BATCH_SIZE = 25;
const DAY_MS = 86_400_000;

let pollTimer = null;

/** Computes the first `nextRun` for a new announcement based on its recurrence settings. */
function computeInitialNextRun({ recurrence, intervalMinutes, dayOfWeek, timeOfDay, startAt }) {
  if (startAt) return startAt;

  const now = new Date();
  if (recurrence === 'interval') {
    return new Date(now.getTime() + intervalMinutes * 60_000);
  }

  // daily/weekly: next occurrence of HH:MM UTC (and, for weekly, the given day).
  const [hours, minutes] = timeOfDay.split(':').map(Number);
  const next = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate(), hours, minutes, 0, 0));

  if (recurrence === 'weekly') {
    let diff = (dayOfWeek - next.getUTCDay() + 7) % 7;
    next.setUTCDate(next.getUTCDate() + diff);
  }
  if (next <= now) {
    next.setUTCDate(next.getUTCDate() + (recurrence === 'weekly' ? 7 : 1));
  }
  return next;
}

/** Computes the next `nextRun` after a successful run, or null if this was a one-off. */
function computeFollowingRun(doc) {
  if (doc.recurrence === 'once') return null;
  if (doc.recurrence === 'interval') return new Date(Date.now() + doc.intervalMinutes * 60_000);

  // daily/weekly: just push the previous nextRun forward by exactly one period,
  // rather than recomputing from "now", so a slightly-late poll doesn't drift the schedule.
  const next = new Date(doc.nextRun);
  next.setUTCDate(next.getUTCDate() + (doc.recurrence === 'weekly' ? 7 : 1));
  return next;
}

/** Creates a new recurring (or one-off) announcement. */
async function createAnnouncement({ guildId, channelId, createdBy, content, recurrence, intervalMinutes = null, dayOfWeek = null, timeOfDay = null, startAt = null }) {
  const nextRun = computeInitialNextRun({ recurrence, intervalMinutes, dayOfWeek, timeOfDay, startAt });
  return Announcement.create({
    guildId,
    channelId,
    createdBy,
    content,
    recurrence,
    intervalMinutes,
    dayOfWeek,
    timeOfDay,
    nextRun,
  });
}

/** Active-first, soonest-due-first list of a guild's announcements. Backs /announcement list. */
async function listAnnouncements(guildId, { limit = 20 } = {}) {
  return Announcement.find({ guildId }).sort({ active: -1, nextRun: 1 }).limit(limit);
}

async function getAnnouncement(guildId, id) {
  try {
    return await Announcement.findOne({ _id: id, guildId });
  } catch {
    return null; // malformed ObjectId
  }
}

/** Deactivates an announcement so the poller stops picking it up. Kept (not deleted) so /announcement list can still show its history. */
async function cancelAnnouncement(guildId, id) {
  const doc = await getAnnouncement(guildId, id);
  if (!doc) return null;
  doc.active = false;
  await doc.save();
  return doc;
}

async function runAnnouncement(client, doc) {
  try {
    const guild = await client.guilds.fetch(doc.guildId).catch(() => null);
    if (!guild) throw new Error('Guild not found - the bot may have left the server.');

    const channel = await guild.channels.fetch(doc.channelId).catch(() => null);
    if (!channel) throw new Error('Target channel no longer exists.');

    const guildConfig = await getGuildConfig(doc.guildId);
    const settings = resolved(guildConfig);
    await channel.send({ embeds: [baseEmbed(settings).setDescription(doc.content).setTitle('📢 Announcement')] });

    const nextRun = computeFollowingRun(doc);
    if (!nextRun) {
      doc.active = false;
    } else {
      doc.nextRun = nextRun;
    }
    doc.lastRun = new Date();
    await doc.save();
  } catch (err) {
    logger.warn(`Announcement ${doc._id} failed to send, disabling: ${err?.message || err}`);
    doc.active = false;
    doc.lastRun = new Date();
    await doc.save().catch(() => null);
  }
}

async function pollAndExecute(client) {
  const due = await Announcement.find({ active: true, nextRun: { $lte: new Date() } })
    .sort({ nextRun: 1 })
    .limit(BATCH_SIZE);

  for (const doc of due) {
    await runAnnouncement(client, doc);
  }
}

/** Starts the announcement poller. Call once from clientReady, same as every other scheduler in events/client/ready.js. */
function startAnnouncementScheduler(client) {
  async function loop() {
    try {
      await pollAndExecute(client);
    } catch (err) {
      logger.error(`Announcement poll failed: ${err.stack || err}`);
    } finally {
      pollTimer = setTimeout(loop, POLL_INTERVAL_MS);
    }
  }
  loop();
}

function stopAnnouncementScheduler() {
  if (pollTimer) clearTimeout(pollTimer);
  pollTimer = null;
}

module.exports = {
  createAnnouncement,
  listAnnouncements,
  getAnnouncement,
  cancelAnnouncement,
  startAnnouncementScheduler,
  stopAnnouncementScheduler,
};
