const { ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const ApprovalRequest = require('../database/models/ApprovalRequest');
const { getGuildConfig, resolved } = require('../utils/resolveGuildSettings');
const { baseEmbed, successEmbed, errorEmbed } = require('../utils/embeds');
const { isGuildManager, isModerator } = require('../utils/permissions');
const { ACTION_LABELS } = require('../utils/caseLabels');
const scheduleService = require('./scheduleService');
const logger = require('../utils/logger');

const PAGE_SIZE = 10;

/**
 * True if `action` currently requires an approval request in this guild
 * instead of running immediately. The only thing a new gate-able action
 * needs to do to opt in is appear in this list (via /approvals setup or
 * the dashboard) and have an executor scheduleService.getActionExecutor
 * can resolve - nothing here needs to change.
 */
function requiresApproval(guildConfig, action) {
  const cfg = guildConfig?.approvals;
  if (!cfg?.enabled || !cfg.reviewChannelId) return false;
  return (cfg.requiredActions || []).includes(action);
}

/** Whether `member` is allowed to approve/reject requests in this guild. */
function canReview(member, guildConfig) {
  if (isGuildManager(member, guildConfig)) return true;
  const approverRoleIds = guildConfig?.approvals?.approverRoleIds || [];
  if (approverRoleIds.length) {
    return approverRoleIds.some((roleId) => member.roles.cache.has(roleId));
  }
  return isModerator(member, guildConfig);
}

function statusButtonLabel(status) {
  return (
    {
      Approved: '✅ تمت الموافقة',
      Rejected: '❌ مرفوض',
      Expired: '⏰ انتهت المهلة',
      Cancelled: '🚫 ملغى',
    }[status] || status
  );
}

/** Builds the review-message embed for a request in any state. */
function buildRequestEmbed(settings, request) {
  const title = ACTION_LABELS[request.action] || request.action;
  const embed = baseEmbed(settings)
    .setTitle(`طلب موافقة: ${title}`)
    .addFields(
      { name: 'الطالب', value: `<@${request.moderatorId}>`, inline: true },
      { name: 'العضو المستهدف', value: `<@${request.targetId}>`, inline: true },
      { name: 'الحالة', value: request.status, inline: true },
      { name: 'السبب', value: request.reason || 'لا يوجد سبب محدد' }
    );

  if (typeof request.durationMinutes === 'number') {
    embed.addFields({ name: 'المدة', value: `${request.durationMinutes} دقيقة`, inline: true });
  }

  if (request.status === 'Pending') {
    embed.addFields({ name: 'تنتهي صلاحية الطلب', value: `<t:${Math.floor(request.expiresAt.getTime() / 1000)}:R>`, inline: true });
  }
  if (request.decidedBy) {
    embed.addFields({ name: 'تم البت بواسطة', value: `<@${request.decidedBy}>`, inline: true });
  }
  if (request.rejectReason) {
    embed.addFields({ name: 'سبب الرفض', value: request.rejectReason });
  }
  if (typeof request.caseId === 'number') {
    embed.addFields({ name: 'رقم القضية', value: `#${request.caseId}`, inline: true });
  }

  return embed;
}

/** Approve/Reject row for a Pending request, or a single disabled status button once decided. */
function buildRequestRow(request) {
  if (request.status !== 'Pending') {
    return [
      new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`approval_done:${request._id}`).setLabel(statusButtonLabel(request.status)).setStyle(ButtonStyle.Secondary).setDisabled(true)
      ),
    ];
  }

  return [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`approval_approve:${request._id}`).setLabel('Approve').setEmoji('✅').setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId(`approval_reject:${request._id}`).setLabel('Reject').setEmoji('❌').setStyle(ButtonStyle.Danger),
      new ButtonBuilder().setCustomId(`approval_expiry_info:${request._id}`).setLabel('⏰ Auto-expires').setStyle(ButtonStyle.Secondary).setDisabled(true)
    ),
  ];
}

/** Re-renders the review message in place for any status change (decision or expiry). */
async function refreshReviewMessage(client, request) {
  if (!request.reviewChannelId || !request.reviewMessageId) return;
  const guildConfig = await getGuildConfig(request.guildId);
  const settings = resolved(guildConfig);

  const channel = await client.channels.fetch(request.reviewChannelId).catch(() => null);
  if (!channel) return;
  const message = await channel.messages.fetch(request.reviewMessageId).catch(() => null);
  if (!message) return;

  await message.edit({ embeds: [buildRequestEmbed(settings, request)], components: buildRequestRow(request) }).catch(() => null);
}

/** DMs the original requester about a decision, if enabled - never throws, a closed DM is not an error. */
async function notifyRequester(client, guildConfig, request, description) {
  if (!guildConfig.approvals?.notifyRequester) return;
  const settings = resolved(guildConfig);
  const user = await client.users.fetch(request.moderatorId).catch(() => null);
  if (!user) return;
  await user.send({ embeds: [baseEmbed(settings).setTitle(`${ACTION_LABELS[request.action] || request.action} - تحديث الطلب`).setDescription(description)] }).catch(() => null);
}

/**
 * Creates an ApprovalRequest, posts it (with Approve/Reject buttons) to the
 * configured review channel, and schedules its auto-expiry via
 * scheduleService - all instead of the calling command executing the
 * action directly. Replies to `interaction` itself so every gated command
 * (ban/kick/timeout/softban) only needs one call here.
 */
async function createApprovalRequest(interaction, guildConfig, settings, { action, target, reason, durationMinutes = null, deleteDays = 0 }) {
  const expiresAt = new Date(Date.now() + (guildConfig.approvals.expiresAfterMinutes || 60) * 60_000);

  const request = await ApprovalRequest.create({
    guildId: interaction.guildId,
    action,
    moderatorId: interaction.user.id,
    targetId: target.id,
    reason,
    durationMinutes,
    deleteDays,
    expiresAt,
    reviewChannelId: guildConfig.approvals.reviewChannelId,
  });

  const channel = await interaction.guild.channels.fetch(guildConfig.approvals.reviewChannelId).catch(() => null);
  if (!channel) {
    await request.deleteOne();
    return interaction.reply({ embeds: [errorEmbed(settings, 'روم مراجعة الموافقات غير موجود أو تم حذفه. تواصل مع الإدارة.')], ephemeral: true });
  }

  const message = await channel
    .send({ embeds: [buildRequestEmbed(settings, request)], components: buildRequestRow(request) })
    .catch(() => null);

  if (!message) {
    await request.deleteOne();
    return interaction.reply({ embeds: [errorEmbed(settings, 'تعذر إرسال طلب الموافقة إلى روم المراجعة.')], ephemeral: true });
  }

  const scheduledTask = await scheduleService.createScheduledTask({
    guildId: interaction.guildId,
    action: 'approval_expire',
    moderatorId: interaction.user.id,
    targetId: request._id.toString(),
    reason: `Auto-expiry for approval request on ${action}`,
    executeAt: expiresAt,
  });

  request.reviewMessageId = message.id;
  request.scheduledTaskId = scheduledTask._id.toString();
  await request.save();

  return interaction.reply({
    embeds: [successEmbed(settings, `تم إرسال طلب **${ACTION_LABELS[action] || action}** على <@${target.id}> إلى ${channel} بانتظار الموافقة.\nمعرّف الطلب: \`${request._id}\``)],
    ephemeral: true,
  });
}

/** Shared not-found/not-Pending guard for approve/reject/cancel button + slash-command handlers. */
async function loadPendingRequest(guildId, requestId) {
  const request = await ApprovalRequest.findOne({ _id: requestId, guildId }).catch(() => null);
  if (!request) return { request: null };
  if (request.status !== 'Pending') return { request, alreadyDecided: true };
  return { request };
}

/** Cancels the scheduled auto-expiry once a request is decided by any means, so it can never fire after the fact. */
async function cancelExpiry(request) {
  if (!request.scheduledTaskId) return;
  await scheduleService.cancelScheduledTask(request.guildId, request.scheduledTaskId, 'approval-decided').catch(() => null);
}

/**
 * Atomically claims a still-Pending request for `deciderId` before the
 * gated action is executed. Without this, two concurrent decisions on the
 * same request (two reviewers, or a Discord click racing a dashboard
 * click) can both pass the `status === 'Pending'` check from
 * loadPendingRequest and both go on to execute the underlying moderation
 * action before either write lands - a double-execution race, not just a
 * duplicate-message annoyance. The claim uses `decidedBy` (already on the
 * schema) as a lock: only one findOneAndUpdate can match `decidedBy: null`
 * at a time. Returns the claimed document, or null if someone else is
 * already deciding (or already decided) this request.
 */
async function claimPendingRequest(guildId, requestId, deciderId) {
  return ApprovalRequest.findOneAndUpdate(
    { _id: requestId, guildId, status: 'Pending', decidedBy: null },
    { $set: { decidedBy: deciderId } },
    { new: true }
  ).catch(() => null);
}

/** Releases a claim taken by claimPendingRequest when action execution fails, so the request goes back to retryable Pending. */
async function releaseClaim(guildId, requestId, deciderId) {
  await ApprovalRequest.updateOne(
    { _id: requestId, guildId, status: 'Pending', decidedBy: deciderId },
    { $set: { decidedBy: null } }
  ).catch(() => null);
}

/**
 * Runs the actual moderation action for an Approved request, through the
 * exact same executor scheduleService already uses for scheduled tasks -
 * this is the only place that touches Case creation and the moderation
 * log for an approved request, and it does so by reuse, not reimplementation.
 */
async function executeApprovedAction(client, request) {
  const executor = scheduleService.getActionExecutor(request.action);
  if (!executor) throw new Error(`No executor registered for action "${request.action}".`);
  return executor(client, request);
}

/** Handles a click on the ✅ Approve button (customId `approval_approve:<id>`). */
async function approveRequest(interaction, requestId) {
  const guildConfig = await getGuildConfig(interaction.guildId);
  const settings = resolved(guildConfig);

  const { request, alreadyDecided } = await loadPendingRequest(interaction.guildId, requestId);
  if (!request) return interaction.reply({ embeds: [errorEmbed(settings, 'طلب الموافقة غير موجود.')], ephemeral: true });
  if (alreadyDecided) return interaction.reply({ embeds: [errorEmbed(settings, `تم البت في هذا الطلب مسبقًا (${request.status}).`)], ephemeral: true });

  if (!canReview(interaction.member, guildConfig)) {
    return interaction.reply({ embeds: [errorEmbed(settings, 'ليس لديك صلاحية الموافقة على هذا الطلب.')], ephemeral: true });
  }

  const claimed = await claimPendingRequest(interaction.guildId, requestId, interaction.user.id);
  if (!claimed) {
    return interaction.reply({ embeds: [errorEmbed(settings, 'يجري البت في هذا الطلب حاليًا أو تم البت فيه بالفعل.')], ephemeral: true });
  }

  await interaction.deferReply({ ephemeral: true });

  let caseDoc;
  try {
    caseDoc = await executeApprovedAction(interaction.client, claimed);
  } catch (err) {
    await releaseClaim(interaction.guildId, requestId, interaction.user.id);
    logger.warn(`Approval ${claimed._id} (${claimed.action}) failed to execute: ${err.message}`);
    return interaction.editReply({ embeds: [errorEmbed(settings, `تعذر تنفيذ الإجراء: ${err.message}`)] });
  }

  claimed.status = 'Approved';
  claimed.decidedAt = new Date();
  claimed.caseId = caseDoc ? caseDoc.caseId : null;
  await claimed.save();

  await cancelExpiry(claimed);
  await refreshReviewMessage(interaction.client, claimed);
  await notifyRequester(interaction.client, guildConfig, claimed, `تمت الموافقة على طلبك بواسطة <@${interaction.user.id}>.${typeof claimed.caseId === 'number' ? ` رقم القضية: #${claimed.caseId}` : ''}`);

  return interaction.editReply({ embeds: [successEmbed(settings, `تمت الموافقة وتنفيذ الإجراء بنجاح.${typeof claimed.caseId === 'number' ? ` رقم القضية: #${claimed.caseId}` : ''}`)] });
}

/** Handles a click on the ❌ Reject button - just opens the reason modal; the actual rejection happens in rejectRequestWithReason once it's submitted. */
function buildRejectModal(requestId) {
  const modal = new ModalBuilder().setCustomId(`approval_reject_modal:${requestId}`).setTitle('رفض الطلب');
  const reasonInput = new TextInputBuilder()
    .setCustomId('reject_reason')
    .setLabel('سبب الرفض')
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(false)
    .setMaxLength(500);
  modal.addComponents(new ActionRowBuilder().addComponents(reasonInput));
  return modal;
}

/** Handles the reject-reason modal submission (customId `approval_reject_modal:<id>`). */
async function rejectRequestWithReason(interaction, requestId, rejectReason) {
  const guildConfig = await getGuildConfig(interaction.guildId);
  const settings = resolved(guildConfig);

  const { request, alreadyDecided } = await loadPendingRequest(interaction.guildId, requestId);
  if (!request) return interaction.reply({ embeds: [errorEmbed(settings, 'طلب الموافقة غير موجود.')], ephemeral: true });
  if (alreadyDecided) return interaction.reply({ embeds: [errorEmbed(settings, `تم البت في هذا الطلب مسبقًا (${request.status}).`)], ephemeral: true });

  if (!canReview(interaction.member, guildConfig)) {
    return interaction.reply({ embeds: [errorEmbed(settings, 'ليس لديك صلاحية رفض هذا الطلب.')], ephemeral: true });
  }

  const claimed = await claimPendingRequest(interaction.guildId, requestId, interaction.user.id);
  if (!claimed) {
    return interaction.reply({ embeds: [errorEmbed(settings, 'يجري البت في هذا الطلب حاليًا أو تم البت فيه بالفعل.')], ephemeral: true });
  }

  claimed.status = 'Rejected';
  claimed.decidedAt = new Date();
  claimed.rejectReason = rejectReason || 'لم يُذكر سبب';
  await claimed.save();

  await cancelExpiry(claimed);
  await refreshReviewMessage(interaction.client, claimed);
  await notifyRequester(interaction.client, guildConfig, claimed, `تم رفض طلبك بواسطة <@${interaction.user.id}>.\nالسبب: ${claimed.rejectReason}`);

  return interaction.reply({ embeds: [successEmbed(settings, 'تم رفض الطلب.')], ephemeral: true });
}

/**
 * Marks a Pending request Expired. Called from scheduleService's
 * 'approval_expire' handler once the scheduled deadline is reached - a
 * no-op if the request was already decided (approve/reject/cancel already
 * cancelled the scheduled task, so this is just a safety net for a race).
 */
async function expireRequest(client, guildId, requestId) {
  const request = await ApprovalRequest.findOne({ _id: requestId, guildId });
  if (!request || request.status !== 'Pending') return null;

  request.status = 'Expired';
  request.decidedAt = new Date();
  await request.save();

  await refreshReviewMessage(client, request);
  const guildConfig = await getGuildConfig(guildId);
  await notifyRequester(client, guildConfig, request, 'انتهت مهلة طلبك دون رد من فريق الإشراف، تم إغلاقه تلقائيًا.');

  return null; // Never produces a Case - matches executeMessage's contract in scheduleService.
}

/** Cancels a still-Pending request. Only the original requester or a guild manager may do this (/approvals cancel). */
async function cancelRequest(interaction, requestId) {
  const guildConfig = await getGuildConfig(interaction.guildId);
  const settings = resolved(guildConfig);

  const { request, alreadyDecided } = await loadPendingRequest(interaction.guildId, requestId);
  if (!request) return interaction.reply({ embeds: [errorEmbed(settings, 'طلب الموافقة غير موجود.')], ephemeral: true });
  if (alreadyDecided) return interaction.reply({ embeds: [errorEmbed(settings, `تم البت في هذا الطلب مسبقًا (${request.status}).`)], ephemeral: true });

  const isOwnRequest = request.moderatorId === interaction.user.id;
  if (!isOwnRequest && !isGuildManager(interaction.member, guildConfig)) {
    return interaction.reply({ embeds: [errorEmbed(settings, 'يمكنك فقط إلغاء طلباتك الخاصة.')], ephemeral: true });
  }

  request.status = 'Cancelled';
  request.decidedBy = interaction.user.id;
  request.decidedAt = new Date();
  await request.save();

  await cancelExpiry(request);
  await refreshReviewMessage(interaction.client, request);

  return interaction.reply({ embeds: [successEmbed(settings, 'تم إلغاء الطلب.')], ephemeral: true });
}

/** Backs /approvals list. */
async function listRequests(guildId, { status = 'Pending', page = 1 } = {}) {
  const query = { guildId };
  if (status && status !== 'All') query.status = status;

  const skip = (Math.max(page, 1) - 1) * PAGE_SIZE;
  const [requests, total] = await Promise.all([
    ApprovalRequest.find(query).sort({ createdAt: -1 }).skip(skip).limit(PAGE_SIZE),
    ApprovalRequest.countDocuments(query),
  ]);

  return { requests, total, page: Math.max(page, 1), totalPages: Math.max(Math.ceil(total / PAGE_SIZE), 1) };
}

/** Backs /approvals status <id>. */
async function getRequestById(guildId, requestId) {
  return ApprovalRequest.findOne({ _id: requestId, guildId }).catch(() => null);
}

module.exports = {
  requiresApproval,
  canReview,
  createApprovalRequest,
  approveRequest,
  buildRejectModal,
  rejectRequestWithReason,
  expireRequest,
  cancelRequest,
  listRequests,
  getRequestById,
  buildRequestEmbed,
  // Exported so non-Discord-interaction callers (the dashboard's HTTP API)
  // can drive the same approve/reject flow without needing a fake
  // `interaction` object to reply through - see dashboard/routes/api.js.
  loadPendingRequest,
  executeApprovedAction,
  cancelExpiry,
  refreshReviewMessage,
  notifyRequester,
  claimPendingRequest,
  releaseClaim,
};
