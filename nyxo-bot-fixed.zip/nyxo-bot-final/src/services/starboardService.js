const { baseEmbed } = require('../utils/embeds');
const Starboard = require('../database/models/Starboard');

/**
 * Recomputes a message's star count and creates/updates/removes its
 * starboard post accordingly. Called from both messageReactionAdd and
 * messageReactionRemove so the mirrored post always reflects the live count.
 */
async function syncStarboardPost(reaction, guildConfig, settings) {
  const { message } = reaction;
  if (!guildConfig.starboard?.enabled || !guildConfig.starboard.channelId) return;
  if (guildConfig.starboard.ignoredChannelIds?.includes(message.channelId)) return;
  if (message.channelId === guildConfig.starboard.channelId) return; // don't star the starboard itself

  const starEmoji = guildConfig.starboard.emoji || '⭐';
  if (reaction.emoji.name !== starEmoji) return;

  await reaction.users.fetch().catch(() => null);
  // Authors starring their own message doesn't count.
  const starCount = reaction.count - (reaction.users.cache.has(message.author?.id) ? 1 : 0);

  const starboardChannel = message.guild.channels.cache.get(guildConfig.starboard.channelId);
  if (!starboardChannel) return;

  let entry = await Starboard.findOne({ sourceMessageId: message.id });

  if (starCount < guildConfig.starboard.threshold) {
    if (entry?.starboardMessageId) {
      const old = await starboardChannel.messages.fetch(entry.starboardMessageId).catch(() => null);
      if (old) await old.delete().catch(() => null);
      entry.starboardMessageId = null;
      entry.starCount = starCount;
      await entry.save();
    }
    return;
  }

  const embed = baseEmbed(settings)
    .setAuthor({ name: message.author?.tag || 'Unknown user', iconURL: message.author?.displayAvatarURL() })
    .setDescription(message.content?.slice(0, 4000) || '*(no text content)*')
    .addFields({ name: 'Source', value: `[Jump to message](${message.url})`, inline: true })
    .setColor('#FEE75C')
    .setFooter({ text: `${starEmoji} ${starCount}` });

  const image = message.attachments?.find((a) => a.contentType?.startsWith('image/'));
  if (image) embed.setImage(image.url);

  if (entry?.starboardMessageId) {
    const existing = await starboardChannel.messages.fetch(entry.starboardMessageId).catch(() => null);
    if (existing) {
      await existing.edit({ embeds: [embed] }).catch(() => null);
      entry.starCount = starCount;
      await entry.save();
      return;
    }
  }

  const posted = await starboardChannel.send({ embeds: [embed] }).catch(() => null);
  if (!posted) return;

  if (entry) {
    entry.starboardMessageId = posted.id;
    entry.starCount = starCount;
    await entry.save();
  } else {
    await Starboard.create({
      guildId: message.guild.id,
      sourceChannelId: message.channelId,
      sourceMessageId: message.id,
      starboardMessageId: posted.id,
      starCount,
    });
  }
}

module.exports = { syncStarboardPost };
