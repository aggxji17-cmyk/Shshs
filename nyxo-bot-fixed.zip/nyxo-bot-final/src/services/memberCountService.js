const GuildConfig = require('../database/models/GuildConfig');
const logger = require('../utils/logger');

const UPDATE_INTERVAL_MS = 10 * 60 * 1000; // Discord rate-limits channel renames; every 10 min is safe.

async function updateAllMemberCountChannels(client) {
  const configs = await GuildConfig.find({ 'memberCountChannel.enabled': true }).catch(() => []);

  for (const guildConfig of configs) {
    const guild = client.guilds.cache.get(guildConfig.guildId);
    const channel = guild?.channels.cache.get(guildConfig.memberCountChannel.channelId);
    if (!channel) continue;

    const name = guildConfig.memberCountChannel.format.replace('{count}', guild.memberCount.toString());
    if (channel.name === name) continue;

    await channel.setName(name).catch((err) => logger.warn(`Member count channel rename failed for ${guild.id}: ${err.message}`));
  }
}

function startMemberCountUpdater(client) {
  updateAllMemberCountChannels(client).catch(() => null);
  setInterval(() => updateAllMemberCountChannels(client).catch(() => null), UPDATE_INTERVAL_MS).unref?.();
}

module.exports = { startMemberCountUpdater, updateAllMemberCountChannels };
