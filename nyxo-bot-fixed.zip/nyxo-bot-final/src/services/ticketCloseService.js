const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { baseEmbed } = require('../utils/embeds');
const { buildTicketArchive, formatBytes } = require('./archiveService');
const { sendRatingPrompt } = require('./ratingService');
const { getGuildConfig, resolved } = require('../utils/resolveGuildSettings');
const { buildStatusChannelName, buildCloseStatusChannelName, deriveBaseChannelName } = require('../utils/ticketPanel');
const Ticket = require('../database/models/Ticket');
const logger = require('../utils/logger');

const DEFAULT_CLOSE_MESSAGE =
  'تم إغلاق هذه التذكرة. يمكنك إعادة فتحها خلال المدة التالية قبل حذفها نهائياً، أو حذفها الآن.';
const DEFAULT_DELETE_LABEL = '🗑️ حذف نهائي';
const DEFAULT_REOPEN_LABEL = '🔓 إعادة فتح';

/** Replaces {number}/{type}/{minutes} placeholders in a configurable close-prompt template. */
function applyClosePlaceholders(template, { number, type, minutes }) {
  return String(template)
    .replaceAll('{number}', String(number))
    .replaceAll('{type}', type || 'غير محدد')
    .replaceAll('{minutes}', String(minutes ?? 0));
}

/** Builds the 🗑️/🔓 action row for a closed-but-not-yet-deleted ticket. customId carries the ticket's Mongo _id through to the button handlers. */
function buildClosePromptComponents(closePrompt, ticket) {
  const deleteLabel = (closePrompt?.deleteButtonLabel || DEFAULT_DELETE_LABEL).slice(0, 80);
  const reopenLabel = (closePrompt?.reopenButtonLabel || DEFAULT_REOPEN_LABEL).slice(0, 80);

  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`ticket_delete_confirm:${ticket._id}`).setLabel(deleteLabel).setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId(`ticket_reopen:${ticket._id}`).setLabel(reopenLabel).setStyle(ButtonStyle.Success)
  );
}

/** Builds the embed shown alongside the 🗑️/🔓 buttons right after a ticket is closed. */
function buildClosePromptEmbed(settings, closePrompt, ticket, autoDeleteMinutes) {
  const text = applyClosePlaceholders(
    closePrompt?.message ? closePrompt.message.replace(/\\n/g, '\n') : DEFAULT_CLOSE_MESSAGE,
    { number: ticket.ticketNumber, type: ticket.typeLabel, minutes: autoDeleteMinutes }
  );

  const embed = baseEmbed(settings).setTitle('🔒・التذكرة مغلقة').setDescription(text);
  if (autoDeleteMinutes > 0) {
    embed.addFields(
      { name: '🎫 الحالة', value: 'مغلقة وتنتظر قرارك', inline: true },
      { name: '⏳ الحذف التلقائي', value: `<t:${Math.floor((Date.now() + autoDeleteMinutes * 60_000) / 1000)}:R>`, inline: true }
    );
  } else {
    embed.addFields({ name: '🎫 الحالة', value: 'مغلقة — الحذف التلقائي معطّل', inline: true });
  }
  return embed;
}

/**
 * Locks a ticket channel down for its opener - keeps ViewChannel so they
 * can still see the close prompt and its buttons, but revokes SendMessages
 * so the "closed" state actually means something. Mirrors the exact
 * overwrite shape ticket_create_modal grants on open, so restoreTicketAccess
 * below can put it back to precisely how it was.
 */
async function lockTicketChannel(channel, ticket) {
  await channel.permissionOverwrites
    .edit(ticket.userId, {
      ViewChannel: true,
      SendMessages: false,
      ReadMessageHistory: true,
    })
    .catch(() => null);
}

/** Restores the ticket opener's original ViewChannel/SendMessages/ReadMessageHistory access on reopen - "تعود جميع الصلاحيات كما كانت". */
async function restoreTicketAccess(channel, ticket) {
  await channel.permissionOverwrites
    .edit(ticket.userId, {
      ViewChannel: true,
      SendMessages: true,
      ReadMessageHistory: true,
    })
    .catch(() => null);
}

/**
 * Posts the close-prompt message (embed + 🗑️/🔓 buttons) into a
 * just-closed ticket channel, and schedules its auto-delete timer
 * (tickets.closePrompt.autoDeleteMinutes, 0 = disabled).
 */
async function sendClosePrompt(channel, guildConfig, settings, ticket) {
  const closePrompt = guildConfig.tickets.closePrompt || {};
  const autoDeleteMinutes = closePrompt.autoDeleteMinutes ?? 240;

  ticket.autoDeleteAt = autoDeleteMinutes > 0 ? new Date(Date.now() + autoDeleteMinutes * 60_000) : null;
  // Task 9: as soon as a ticket closes it goes 🔵 "pending deletion" - the
  // channel name itself tells staff its state without opening it.
  ticket.closeStatus = autoDeleteMinutes > 0 ? 'pending_delete' : null;
  ticket.baseChannelName = ticket.baseChannelName || deriveBaseChannelName(channel.name);
  await ticket.save();

  await lockTicketChannel(channel, ticket);

  if (ticket.closeStatus) {
    await channel.setName(buildCloseStatusChannelName(ticket.baseChannelName, ticket.closeStatus)).catch(() => null);
  }

  await channel
    .send({
      embeds: [buildClosePromptEmbed(settings, closePrompt, ticket, autoDeleteMinutes)],
      components: [buildClosePromptComponents(closePrompt, ticket)],
    })
    .catch(() => null);
}

/**
 * Reopens a previously-closed ticket in place: restores channel access,
 * clears the pending-deletion timer, and puts the ticket back into
 * whichever non-closed status it had before (claimed stays claimed).
 *
 * Returns { success: true } normally, or { success: false, reason:
 * 'active_ticket_exists' } in the one edge case the Task 5 partial
 * unique index (guildId+userId, isOpen:true - see database/models/Ticket.js)
 * can now surface: the member opened a *different* new ticket while this
 * one sat closed-and-pending-deletion, so reopening this one would give
 * them two active tickets at once, which the index (correctly) refuses.
 * This was always logically undesirable; it just had no way to be
 * detected/prevented before the index existed. The ticket itself is left
 * exactly as it was (still closed) so nothing is lost and it can still
 * be permanently deleted normally.
 */
async function reopenTicket(channel, ticket, reopenedById) {
  ticket.status = ticket.claimedBy ? 'claimed' : 'open';
  ticket.closedBy = null;
  ticket.closedAt = null;
  ticket.autoDeleteAt = null;
  ticket.closeStatus = null;
  ticket.reopenedBy = reopenedById;
  ticket.reopenedAt = new Date();
  // Task 5: keep isOpen in sync with status - this is what re-claims this
  // member's "one active ticket" slot on reopen.
  ticket.isOpen = true;

  try {
    await ticket.save();
  } catch (err) {
    if (err?.code === 11000) {
      // Roll the in-memory document back to its closed state so callers
      // that inspect `ticket` afterwards (e.g. for logging) see the truth.
      ticket.status = 'closed';
      ticket.isOpen = false;
      return { success: false, reason: 'active_ticket_exists' };
    }
    throw err;
  }

  await restoreTicketAccess(channel, ticket);

  // Task 9: "عند إعادة فتح التكت، يعود اسم الروم تلقائياً إلى حالته
  // السابقة" - drop the 🔵/🔴 close-state prefix and go back to whichever
  // 🟡/🟢 reply-status the ticket had before it was closed.
  if (channel) {
    const baseName = ticket.baseChannelName || deriveBaseChannelName(channel.name);
    await channel.setName(buildStatusChannelName(baseName, ticket.replyStatus)).catch(() => null);
  }

  return { success: true };
}

/**
 * The one and only path to a ticket channel actually disappearing -
 * used by both the 🗑️ button and the auto-delete scheduler. Builds the
 * HTML/zip transcript archive, drops it (plus a summary embed) into the
 * configured log channel, then deletes the channel. Never throws: a
 * failed archive must never block the deletion itself.
 */
async function finalizeTicketDeletion(client, guild, guildConfig, settings, ticket, channel, deletedById) {
  const openedAt = ticket.createdAt;

  const archive = channel
    ? await buildTicketArchive(channel, ticket, openedAt).catch((err) => {
        logger.error(`فشل إنشاء أرشيف التذكرة #${ticket.ticketNumber}: ${err.message}`);
        return null;
      })
    : null;

  if (guildConfig.tickets.logChannelId) {
    const logChannel = guild.channels.cache.get(guildConfig.tickets.logChannelId);
    if (logChannel) {
      const files = archive ? [archive.htmlAttachment, archive.zipAttachment] : [];
      const embed = baseEmbed(settings)
        .setTitle(`📁・التذكرة #${ticket.ticketNumber} حُذفت نهائياً`)
        .addFields(
          { name: '📂 القسم', value: ticket.typeLabel || 'غير محدد', inline: true },
          { name: '👤 صاحب التذكرة', value: `<@${ticket.userId}>`, inline: true },
          { name: '🗑️ حُذفت بواسطة', value: deletedById ? `<@${deletedById}>` : 'النظام تلقائياً ⏳', inline: true }
        );

      if (archive) {
        embed.addFields(
          { name: '💬 عدد الرسائل', value: `${archive.stats.messageCount}`, inline: true },
          { name: '📎 المرفقات المحفوظة', value: `${archive.stats.savedAttachmentCount}/${archive.stats.attachmentCount}`, inline: true },
          { name: '📦 حجم الأرشيف', value: formatBytes(archive.stats.zipSizeBytes), inline: true }
        );
      } else {
        embed.addFields({ name: 'ملاحظة', value: '⚠️ تعذر إنشاء أرشيف كامل لهذه التذكرة.' });
      }

      await logChannel.send({ embeds: [embed], files }).catch(() => null);
    }
  }

  ticket.autoDeleteAt = null;
  ticket.closeStatus = null;
  ticket.permanentlyDeletedAt = new Date();
  await ticket.save().catch(() => null);

  // Fire the rating DM last, and only now that the ticket is truly gone
  // for good - asking before this point would be premature, since the
  // opener could still have reopened it via the 🔓 button. A user with
  // DMs closed or ratings disabled for the guild should never block the
  // deletion itself.
  await sendRatingPrompt(client, guild, guildConfig, settings, ticket).catch(() => null);

  if (channel) await channel.delete().catch(() => null);
}

/**
 * Task 9: flips every 🔵 "pending deletion" ticket whose remaining time has
 * dropped under tickets.closePrompt.warningMinutes over to 🔴 "about to be
 * deleted" - both the channel name and ticket.closeStatus - so staff can
 * see from the channel list alone that the clock is almost out. Tickets
 * already 🔴 (or with warnings disabled for their guild) are skipped so a
 * server doesn't get a rename attempt every minute for nothing.
 */
async function runCloseWarningPass(client) {
  const candidates = await Ticket.find({
    status: 'closed',
    closeStatus: 'pending_delete',
    autoDeleteAt: { $ne: null },
  }).limit(100);

  for (const ticket of candidates) {
    const guild = client.guilds.cache.get(ticket.guildId);
    if (!guild) continue;

    const guildConfig = await getGuildConfig(ticket.guildId);
    const warningMinutes = guildConfig.tickets.closePrompt?.warningMinutes ?? 30;
    if (warningMinutes <= 0) continue; // 🔴 stage disabled for this guild - stays 🔵 until deleted.

    const msRemaining = ticket.autoDeleteAt.getTime() - Date.now();
    if (msRemaining > warningMinutes * 60_000) continue; // not close enough yet

    ticket.closeStatus = 'near_delete';
    await ticket.save().catch(() => null);

    const channel = guild.channels.cache.get(ticket.channelId) || (await guild.channels.fetch(ticket.channelId).catch(() => null));
    if (!channel) continue;

    const baseName = ticket.baseChannelName || deriveBaseChannelName(channel.name);
    await channel.setName(buildCloseStatusChannelName(baseName, 'near_delete')).catch(() => null);
  }
}

/** Runs finalizeTicketDeletion for every ticket whose auto-delete timer has come due, and separately flips 🔵→🔴 tickets nearing that deadline. Call on an interval from the ready event. */
function startTicketAutoDeleteScheduler(client) {
  setInterval(async () => {
    try {
      await runCloseWarningPass(client);
    } catch (err) {
      logger.error(`Ticket close-warning scheduler error: ${err.stack || err}`);
    }

    try {
      const due = await Ticket.find({ status: 'closed', autoDeleteAt: { $ne: null, $lte: new Date() } }).limit(25);

      for (const ticket of due) {
        // Clear the timer immediately so a slow iteration can't process
        // the same ticket twice if the interval fires again mid-loop.
        ticket.autoDeleteAt = null;
        await ticket.save().catch(() => null);

        const guild = client.guilds.cache.get(ticket.guildId);
        if (!guild) continue;

        const guildConfig = await getGuildConfig(ticket.guildId);
        const settings = resolved(guildConfig);
        const channel = guild.channels.cache.get(ticket.channelId) || (await guild.channels.fetch(ticket.channelId).catch(() => null));

        await finalizeTicketDeletion(client, guild, guildConfig, settings, ticket, channel, null);
      }
    } catch (err) {
      logger.error(`Ticket auto-delete scheduler error: ${err.stack || err}`);
    }
  }, 60_000);
}

module.exports = {
  DEFAULT_CLOSE_MESSAGE,
  DEFAULT_DELETE_LABEL,
  DEFAULT_REOPEN_LABEL,
  applyClosePlaceholders,
  buildClosePromptComponents,
  buildClosePromptEmbed,
  sendClosePrompt,
  reopenTicket,
  restoreTicketAccess,
  finalizeTicketDeletion,
  startTicketAutoDeleteScheduler,
};
