/**
 * 3D player-head rendering.
 *
 * Today: renders straight from the Minecraft UUID/username via Starlight
 * SkinAPI (https://docs.lunareclipse.studio/, endpoint pattern confirmed
 * against https://github.com/rinckodev/starlightskinapi). This works for
 * any account Mojang actually has a skin on file for - i.e. premium
 * (non-cracked) accounts.
 *
 * `https://starlightskins.lunareclipse.studio/render/{type}/{uuidOrName}/{crop}`
 * - type "head", crop "full" gives an isometric 3D head render.
 *
 * Cracked/offline-mode accounts don't have a real Mojang UUID, so nothing
 * public that looks a player up "by UUID" (this API, mc-heads, Crafatar,
 * mineatar.io, ...) can ever resolve a skin for them - the skin only
 * exists on the Minecraft server itself (vanilla's own default skin, or
 * whatever SkinsRestorer assigned). Supporting that - and any
 * SkinsRestorer-managed skin in general - needs the plugin (Phase 2) to
 * read the player's live GameProfile textures property (or query
 * SkinsRestorer's own API/database directly) and publish a texture URL
 * onto their MinecraftPlayerCache document (`skinUrl`, see that model).
 *
 * `resolveHeadRenderUrl` already prefers that field the moment it exists,
 * so no bot-side changes are needed once the plugin starts populating it -
 * only the exact rendering call for an arbitrary texture URL needs to be
 * finalized then (Starlight's docs mention a "Custom Renders" feature for
 * this, but the precise query parameters weren't confirmed in this pass;
 * self-hosting a renderer such as github.com/mineatar-io/skin-render,
 * which accepts raw skin bytes/URLs directly, is the fallback option if
 * Starlight's custom-render support doesn't pan out).
 */
const RENDER_BASE = 'https://starlightskins.lunareclipse.studio/render';

/**
 * @param {{ minecraftUuid?: string, minecraftUsername?: string, skinUrl?: string|null }} player
 * @returns {string|null}
 */
function resolveHeadRenderUrl({ minecraftUuid, minecraftUsername, skinUrl }) {
  if (skinUrl) {
    // TODO (Phase 2 / plugin update): once the plugin actually populates
    // skinUrl (from SkinsRestorer or the player's live texture), confirm
    // and wire up Starlight's custom-texture render call here so cracked
    // accounts render correctly too. Falling through to the UUID/username
    // path below in the meantime so this never throws.
  }

  const identifier = minecraftUuid || minecraftUsername;
  if (!identifier) return null;

  return `${RENDER_BASE}/head/${encodeURIComponent(identifier)}/full`;
}

/** Flat 2D fallback (e.g. for embed footers/small icons), unaffected by the 3D API being unreachable. */
function resolveFlatHeadUrl(minecraftUuid) {
  if (!minecraftUuid) return null;
  return `https://mc-heads.net/avatar/${minecraftUuid}/128`;
}

module.exports = { resolveHeadRenderUrl, resolveFlatHeadUrl };
