const Case = require('../database/models/Case');
const GuildConfig = require('../database/models/GuildConfig');
const logger = require('../utils/logger');

const PAGE_SIZE = 5;

/**
 * Atomically claims the next Case number for this guild. Uses a direct
 * $inc on GuildConfig (bypassing the cached doc from resolveGuildSettings)
 * so two moderation actions firing at the same moment can never be handed
 * the same Case ID.
 */
async function nextCaseId(guildId) {
  const updated = await GuildConfig.findOneAndUpdate(
    { guildId },
    { $inc: { caseCounter: 1 } },
    { new: true, upsert: true, setDefaultsOnInsert: true }
  );
  return updated.caseCounter;
}

/**
 * Creates a new Case. Every moderation command (ban/kick/timeout/warn/
 * unban/softban) calls this exactly once after its Discord-side action
 * succeeds - this is the only place a Case document gets created.
 *
 * @param {object} details
 * @param {string} details.guildId
 * @param {'ban'|'kick'|'timeout'|'warn'|'unban'|'softban'} details.action
 * @param {string} details.moderatorId
 * @param {string} details.targetId
 * @param {string} [details.reason]
 * @param {number} [details.durationMinutes] - only for 'timeout'
 * @returns {Promise<import('mongoose').Document>} the created Case
 */
async function createCase({ guildId, action, moderatorId, targetId, reason, durationMinutes = null }) {
  const caseId = await nextCaseId(guildId);
  const expiresAt = action === 'timeout' && durationMinutes ? new Date(Date.now() + durationMinutes * 60_000) : null;

  return Case.create({
    guildId,
    caseId,
    action,
    moderatorId,
    targetId,
    reason: reason || 'No reason provided',
    durationMinutes,
    expiresAt,
    status: 'Active',
  });
}

/** Looks up a single Case by its per-guild number, for /case and /editcase. */
async function getCaseById(guildId, caseId) {
  return Case.findOne({ guildId, caseId });
}

/**
 * Newest Cases for a guild, for the /case and /editcase `case_id`
 * autocomplete. Intentionally uncached and capped small - this only
 * needs to feed a 25-choice dropdown while a moderator is typing, not
 * back a full listing view.
 */
async function getRecentCases(guildId, limit = 25) {
  return Case.find({ guildId }).sort({ caseId: -1 }).limit(limit).select('caseId action targetId reason status');
}

/** Paginated Case history for one member, newest first, for /cases. */
async function getCasesForUser(guildId, targetId, page = 1, pageSize = PAGE_SIZE) {
  const safePage = Math.max(page, 1);
  const skip = (safePage - 1) * pageSize;

  const [cases, total] = await Promise.all([
    Case.find({ guildId, targetId }).sort({ caseId: -1 }).skip(skip).limit(pageSize),
    Case.countDocuments({ guildId, targetId }),
  ]);

  return { cases, total, page: safePage, totalPages: Math.max(Math.ceil(total / pageSize), 1) };
}

/**
 * Updates a Case's reason/notes only - never its moderatorId, targetId,
 * action, status or date - for /editcase. Passing `null`/`undefined` for
 * either field leaves it untouched.
 */
async function editCase(guildId, caseId, { reason, notes } = {}) {
  const update = {};
  if (typeof reason === 'string') update.reason = reason;
  if (typeof notes === 'string') update.notes = notes;
  if (!Object.keys(update).length) return getCaseById(guildId, caseId);

  return Case.findOneAndUpdate({ guildId, caseId }, update, { new: true });
}

/** Most recent still-Active ban Case for this target, if any. Used by /unban to decide whether to revert an existing Case instead of creating a new one. */
async function findActiveBanCase(guildId, targetId) {
  return Case.findOne({ guildId, targetId, action: 'ban', status: 'Active' }).sort({ caseId: -1 });
}

/**
 * Marks a Case Reverted without touching any of its original fields.
 * Used when /unban closes out an existing ban Case, so unbanning never
 * creates a second, disconnected record for the same punishment.
 */
async function revertCase(guildId, caseId, { revertedBy, revertReason } = {}) {
  return Case.findOneAndUpdate(
    { guildId, caseId },
    {
      status: 'Reverted',
      revertedAt: new Date(),
      revertedBy: revertedBy || null,
      revertReason: revertReason || null,
    },
    { new: true }
  );
}

/**
 * Marks every Active timeout Case whose duration has elapsed as Expired.
 * Discord has no "timeout ended" gateway event, so this is a periodic
 * sweep (see startCaseExpiryScheduler) rather than something triggered by
 * an event - it updates the existing Case in place instead of creating a
 * new one.
 */
async function sweepExpiredTimeouts() {
  const result = await Case.updateMany(
    { action: 'timeout', status: 'Active', expiresAt: { $ne: null, $lte: new Date() } },
    { status: 'Expired', revertedAt: new Date(), revertedBy: 'system' }
  );
  return result.modifiedCount || 0;
}

/** Runs sweepExpiredTimeouts on an interval. Call once from the ready event. */
function startCaseExpiryScheduler() {
  setInterval(() => {
    sweepExpiredTimeouts().catch((err) => logger.error(`Case expiry sweep failed: ${err.stack || err}`));
  }, 60_000);
}

module.exports = {
  PAGE_SIZE,
  createCase,
  getCaseById,
  getRecentCases,
  getCasesForUser,
  editCase,
  findActiveBanCase,
  revertCase,
  sweepExpiredTimeouts,
  startCaseExpiryScheduler,
};
