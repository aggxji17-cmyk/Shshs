const { baseEmbed } = require('../utils/embeds');
const logger = require('../utils/logger');

/**
 * Deletes the previous sticky post (if it still exists) and sends a fresh
 * one at the bottom of the channel, then persists the new message id.
 */
async function repostSticky(channel, stickyDoc, settings) {
  if (stickyDoc.lastMessageId) {
    const old = await channel.messages.fetch(stickyDoc.lastMessageId).catch(() => null);
    if (old) await old.delete().catch(() => null);
  }

  const sent = await channel
    .send({ embeds: [baseEmbed(settings).setTitle('📌 Sticky Message').setDescription(stickyDoc.content)] })
    .catch((err) => {
      logger.warn(`Failed to repost sticky message in #${channel.name}: ${err.message}`);
      return null;
    });

  if (sent) {
    stickyDoc.lastMessageId = sent.id;
    await stickyDoc.save();
  }
}

module.exports = { repostSticky };
