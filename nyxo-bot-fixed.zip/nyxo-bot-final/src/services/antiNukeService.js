const AntiNukeLog = require('../database/models/AntiNukeLog');
const logger = require('../utils/logger');

/**
 * Records a potentially destructive action performed by `userId` and checks
 * whether it crosses the configured threshold within the detection window.
 * If so, punishes the offender according to the guild's antinuke settings
 * and returns true (caller can use this to send a log message).
 */
async function trackAndEnforce(guild, userId, actionType, guildConfig) {
  const { antinuke } = guildConfig;
  if (!antinuke?.enabled) return false;
  if (antinuke.whitelistedUserIds?.includes(userId)) return false;
  if (userId === guild.ownerId) return false;

  await AntiNukeLog.create({ guildId: guild.id, userId, actionType });

  const windowStart = new Date(Date.now() - antinuke.windowMs);
  const count = await AntiNukeLog.countDocuments({
    guildId: guild.id,
    userId,
    actionType,
    createdAt: { $gte: windowStart },
  });

  const threshold = antinuke.thresholds?.[actionType];
  if (!threshold || count < threshold) return false;

  await punishMember(guild, userId, antinuke.punishment);
  logger.warn(`Anti-nuke triggered on ${userId} in ${guild.name} for ${actionType} (${count} in window)`);
  return true;
}

async function punishMember(guild, userId, punishment) {
  try {
    const member = await guild.members.fetch(userId).catch(() => null);
    if (!member) return;

    if (punishment === 'ban') {
      await guild.members.ban(userId, { reason: 'Anti-nuke: suspicious activity threshold exceeded' });
    } else if (punishment === 'kick') {
      await member.kick('Anti-nuke: suspicious activity threshold exceeded');
    } else {
      const removable = member.roles.cache.filter((r) => r.id !== guild.id && r.editable);
      await Promise.all(removable.map((r) => member.roles.remove(r).catch(() => null)));
    }
  } catch (err) {
    logger.error(`Failed to punish member during anti-nuke response: ${err.message}`);
  }
}

module.exports = { trackAndEnforce };
