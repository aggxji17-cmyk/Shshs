const { status, statusBedrock } = require('minecraft-server-util');
const dns = require('node:dns').promises;
const net = require('node:net');

/**
 * `minecraft.ip`/`minecraft.port` are set by any guild manager through the
 * dashboard (dashboard/routes/api.js EDITABLE_PATHS) and this service then
 * makes an outbound TCP connection to whatever host they entered. Without a
 * check, that turns "check my Minecraft server's status" into a
 * server-side request forgery primitive - a guild manager (not necessarily
 * someone the host's operator trusts with the hosting network) could point
 * it at 127.0.0.1, an internal 10.x/172.16.x/192.168.x service, or a cloud
 * metadata endpoint (169.254.169.254) and use the online/offline result
 * and timing as a crude internal port scanner. Resolve the hostname first
 * and refuse to connect if it lands on a private/loopback/link-local
 * address; real public Minecraft servers are unaffected.
 */
async function isBlockedTarget(host) {
  try {
    const literalFamily = net.isIP(host);
    const address = literalFamily ? host : (await dns.lookup(host)).address;
    return isPrivateOrReservedIp(address);
  } catch {
    // DNS resolution failure isn't our call to make here - let the actual
    // status check below fail (and report) in its own normal way.
    return false;
  }
}

function isPrivateOrReservedIp(address) {
  if (net.isIPv4(address)) {
    const [a, b] = address.split('.').map(Number);
    if (a === 10) return true; // 10.0.0.0/8
    if (a === 127) return true; // 127.0.0.0/8 (loopback)
    if (a === 169 && b === 254) return true; // 169.254.0.0/16 (link-local / cloud metadata)
    if (a === 172 && b >= 16 && b <= 31) return true; // 172.16.0.0/12
    if (a === 192 && b === 168) return true; // 192.168.0.0/16
    if (a === 0) return true; // 0.0.0.0/8
    return false;
  }
  if (net.isIPv6(address)) {
    const lower = address.toLowerCase();
    if (lower === '::1') return true; // loopback
    if (lower.startsWith('fe80:') || lower.startsWith('fe8') || lower.startsWith('fe9') || lower.startsWith('fea') || lower.startsWith('feb')) return true; // fe80::/10 link-local
    if (lower.startsWith('fc') || lower.startsWith('fd')) return true; // fc00::/7 unique local
    if (lower.startsWith('::ffff:')) return isPrivateOrReservedIp(lower.replace('::ffff:', '')); // IPv4-mapped
    return false;
  }
  return false;
}

/**
 * Queries a Java Edition Minecraft server for its live status.
 * Returns a normalized result object; never throws - callers check `.online`.
 */
async function getServerStatus(ip, port) {
  if (await isBlockedTarget(ip)) {
    return { online: false, edition: 'java', ip, port, error: 'This address cannot be queried.' };
  }
  try {
    const start = Date.now();
    const result = await status(ip, port, { timeout: 5000, enableSRV: true });
    const ping = Date.now() - start;

    return {
      online: true,
      edition: 'java',
      ip,
      port,
      players: {
        online: result.players.online,
        max: result.players.max,
        sample: result.players.sample?.map((p) => p.name) || [],
      },
      version: result.version?.name || 'Unknown',
      motd: result.motd?.clean || '',
      favicon: result.favicon || null,
      ping,
    };
  } catch (err) {
    return { online: false, edition: 'java', ip, port, error: err.message };
  }
}

/**
 * Queries a Bedrock Edition Minecraft server (or a Java server exposed via
 * Geyser) for its live status. Returns a normalized result object; never
 * throws - callers check `.online`.
 */
async function getBedrockServerStatus(ip, port) {
  try {
    const start = Date.now();
    const result = await statusBedrock(ip, port, { timeout: 5000 });
    const ping = Date.now() - start;

    return {
      online: true,
      edition: 'bedrock',
      ip,
      port,
      players: {
        online: result.players.online,
        max: result.players.max,
      },
      version: result.version?.name || String(result.version || 'Unknown'),
      motd: result.motd?.clean || '',
      ping,
    };
  } catch (err) {
    return { online: false, edition: 'bedrock', ip, port, error: err.message };
  }
}

module.exports = { getServerStatus, getBedrockServerStatus };
