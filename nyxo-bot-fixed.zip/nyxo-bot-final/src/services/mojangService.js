const axios = require('axios');

/**
 * Inserts dashes into a raw 32-char Mojang UUID (8-4-4-4-12), the format
 * expected by most head-render services and Mojang session APIs.
 */
function formatUuid(raw) {
  const clean = raw.replace(/-/g, '');
  return `${clean.slice(0, 8)}-${clean.slice(8, 12)}-${clean.slice(12, 16)}-${clean.slice(16, 20)}-${clean.slice(20)}`;
}

/**
 * Resolves a Minecraft Java Edition username to its Mojang account UUID.
 * Returns `{ uuid, name }` (with the name's current, canonical casing) on
 * success, or `null` if no account exists with that username. Only throws
 * on unexpected network/API failures so callers can tell "not found" apart
 * from "the lookup itself failed".
 */
async function resolveUsername(username) {
  try {
    const { data } = await axios.get(
      `https://api.mojang.com/users/profiles/minecraft/${encodeURIComponent(username)}`,
      { timeout: 5000 }
    );
    if (!data?.id) return null;
    return { uuid: formatUuid(data.id), name: data.name };
  } catch (err) {
    if (err.response?.status === 404 || err.response?.status === 204) return null;
    throw new Error(`Mojang API lookup failed: ${err.message}`);
  }
}

module.exports = { resolveUsername, formatUuid };
