const { Player, GuildQueueEvent, useQueue } = require('discord-player');
const { DefaultExtractors } = require('@discord-player/extractor');
const { YoutubeiExtractor } = require('discord-player-youtubei');
const { config } = require('../config/config');
const logger = require('../utils/logger');
const { baseEmbed, errorEmbed } = require('../utils/embeds');
const { getGuildConfig, resolved } = require('../utils/resolveGuildSettings');
const { buildMusicControlsRow } = require('../utils/musicControls');
const { logPlay } = require('./musicHistoryService');
const GuildConfig = require('../database/models/GuildConfig');

let player = null;

/**
 * Creates the singleton Player instance, registers audio source
 * extractors (YouTube, Spotify/SoundCloud/Vimeo/attachments via
 * @discord-player/extractor) and hooks up guild-queue events so every
 * text channel that requested a song gets played/queue/error updates.
 *
 * Call once from index.js after the client is constructed.
 */
function initMusicPlayer(client) {
  player = new Player(client);

  player.extractors
    .loadMulti(DefaultExtractors)
    .then(() => logger.success('Loaded default music extractors (SoundCloud, Spotify bridge, Vimeo, attachments...)'))
    .catch((err) => logger.error(`Failed to load default extractors: ${err.stack || err}`));

  if (!config.youtube.cookie) {
    logger.warn(
      'YOUTUBE_COOKIE is not set. YouTube playback will work intermittently at best - ' +
        'YouTube actively blocks unauthenticated streaming requests. Set YOUTUBE_COOKIE in ' +
        'your .env (see the comment above it in .env.example) for reliable playback.'
    );
  }

  player.extractors
    .register(YoutubeiExtractor, {
      // A logged-in cookie is what actually keeps YouTube from blocking
      // the stream request ("Sign in to confirm you're not a bot"). Works
      // fine (registers) without one, but streaming will be unreliable.
      cookie: config.youtube.cookie || undefined,
      // Proof-of-origin token - required by YouTube's current anti-bot
      // checks for the WEB client streaming path used below.
      generateWithPoToken: true,
      // Don't hard-crash a track on a sign-in prompt; let PlayerError
      // fire so the queue can move on to the next track instead of the
      // whole extractor wedging.
      ignoreSignInErrors: true,
      streamOptions: {
        useClient: 'WEB',
      },
    })
    .then(() => logger.success('Loaded YouTube music extractor'))
    .catch((err) => logger.error(`Failed to load YouTube extractor: ${err.stack || err}`));

  player.events.on(GuildQueueEvent.PlayerStart, async (queue, track) => {
    logPlay(queue.guild.id, track);

    const channel = queue.metadata?.channel;
    if (!channel) return;
    try {
      const guildConfig = await getGuildConfig(queue.guild.id);
      const settings = resolved(guildConfig);
      await channel.send({
        embeds: [
          baseEmbed(settings)
            .setTitle('🎶 Now Playing')
            .setDescription(`[${track.title}](${track.url})`)
            .setThumbnail(track.thumbnail || null)
            .addFields(
              { name: 'Duration', value: track.duration || 'Live', inline: true },
              { name: 'Requested by', value: `${track.requestedBy ?? 'Unknown'}`, inline: true }
            ),
        ],
        components: buildMusicControlsRow(queue),
      });
    } catch (err) {
      logger.error(`Failed to send now-playing message: ${err.stack || err}`);
    }
  });

  player.events.on(GuildQueueEvent.EmptyChannel, async (queue) => {
    // Pause instead of just waiting out leaveOnEmptyCooldown doing
    // nothing useful: if a member rejoins in time,
    // events/voice/musicAutoResume.js picks the same track back up
    // exactly where it left off. If nobody does, discord-player's own
    // leaveOnEmpty timer still disconnects and clears the queue as before.
    if (queue.node.isPlaying() && !queue.node.isPaused()) {
      queue.node.setPaused(true);
      if (queue.metadata) queue.metadata.autoPausedForEmpty = true;
    }

    const channel = queue.metadata?.channel;
    if (!channel) return;
    try {
      const guildConfig = await getGuildConfig(queue.guild.id);
      const settings = resolved(guildConfig);
      const description = guildConfig.music?.twentyFourSeven?.enabled
        ? 'Everyone left the voice channel — playback paused until someone comes back (24/7 mode is on, so I\'m staying put).'
        : "Everyone left the voice channel — playback paused. Come back within a minute and I'll resume; otherwise I'll leave and clear the queue.";
      await channel.send({ embeds: [errorEmbed(settings, description)] });
    } catch {
      // Channel may have been deleted or the bot lost send permissions - nothing more to do.
    }
  });

  player.events.on(GuildQueueEvent.EmptyQueue, async (queue) => {
    const channel = queue.metadata?.channel;
    if (!channel) return;
    try {
      const guildConfig = await getGuildConfig(queue.guild.id);
      const settings = resolved(guildConfig);
      const description = guildConfig.music?.twentyFourSeven?.enabled
        ? '✅ Queue finished — staying connected (24/7 mode is on).'
        : '✅ Queue finished — leaving the voice channel.';
      await channel.send({ embeds: [baseEmbed(settings).setDescription(description)] });
    } catch {
      // Same as above - best effort only.
    }
  });

  player.events.on(GuildQueueEvent.PlayerError, (queue, error, track) => {
    logger.error(`Player error on track "${track?.title}" in guild ${queue.guild.id}: ${error.stack || error}`);
  });

  player.events.on(GuildQueueEvent.Error, (queue, error) => {
    logger.error(`Queue error in guild ${queue.guild.id}: ${error.stack || error}`);
  });

  logger.success('Music player initialized');
  return player;
}

/**
 * Called once from events/client/ready.js. Reconnects to every voice
 * channel a guild had 24/7 mode enabled for (persisted via /247 in
 * database/models/GuildConfig.js), so a bot restart doesn't silently
 * end a "stay forever" session - it just quietly rejoins.
 */
async function restoreTwentyFourSevenSessions(client) {
  const docs = await GuildConfig.find({ 'music.twentyFourSeven.enabled': true }).catch((err) => {
    logger.error(`Failed to load 24/7 guild configs: ${err.stack || err}`);
    return [];
  });

  for (const doc of docs) {
    try {
      const guild = client.guilds.cache.get(doc.guildId);
      const channel = guild?.channels.cache.get(doc.music.twentyFourSeven.voiceChannelId);
      if (!guild || !channel) continue;

      if (useQueue(guild.id)?.connection) continue; // already connected somehow

      const permissions = channel.permissionsFor(guild.members.me);
      if (!permissions?.has(['Connect', 'Speak'])) {
        logger.warn(`Skipping 24/7 reconnect in guild ${guild.id}: missing Connect/Speak in ${channel.id}`);
        continue;
      }

      const textChannel = doc.music.twentyFourSeven.textChannelId
        ? guild.channels.cache.get(doc.music.twentyFourSeven.textChannelId)
        : null;

      const queue = player.nodes.create(guild, {
        metadata: { channel: textChannel || null },
        selfDeaf: true,
        volume: 70,
        leaveOnEmpty: false,
        leaveOnEmptyCooldown: 60_000,
        leaveOnEnd: false,
        leaveOnEndCooldown: 300_000,
        leaveOnStop: false,
      });
      await queue.connect(channel);
      logger.success(`Restored 24/7 voice session in guild ${guild.id}`);
    } catch (err) {
      logger.error(`Failed to restore 24/7 mode for guild ${doc.guildId}: ${err.stack || err}`);
    }
  }
}

module.exports = { initMusicPlayer, restoreTwentyFourSevenSessions };
