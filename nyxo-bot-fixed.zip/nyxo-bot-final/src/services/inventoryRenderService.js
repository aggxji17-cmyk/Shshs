'use strict';

/**
 * Renders a player's inventory snapshot (services/inventoryService.js) as
 * a PNG that matches vanilla Minecraft's own inventory screen, for /inv
 * to attach to its embed.
 *
 * WHY canvas + real texture assets, instead of e.g. drawing colored
 * rectangles with discord.js/Canvas primitives:
 *   The task requires the output to look genuinely like Minecraft's UI,
 *   not a stylized approximation. The only way to get that exactly right
 *   is the same way every other Minecraft-inventory-viewer bot does it:
 *   composite the ACTUAL vanilla GUI texture and the ACTUAL item sprites,
 *   scaled with nearest-neighbor (never bilinear/bicubic - that blurs
 *   pixel art) filtering, at an integer scale factor. This module is the
 *   compositing pipeline; only the asset files themselves are still
 *   missing (see "ASSETS" below) - dropping them in is all that's left
 *   to make this fully live.
 *
 * Library: @napi-rs/canvas (not yet in package.json - add it as a
 * dependency before this goes live: `npm install @napi-rs/canvas`).
 * Chosen over node-canvas because it ships prebuilt binaries (no native
 * build toolchain needed on the host) and over skia-canvas for the
 * smaller footprint; either would work with the code below unchanged
 * since both implement the same CanvasRenderingContext2D surface.
 *
 * =========================================================================
 * ASSETS (not included - see README section at the bottom of this file)
 * =========================================================================
 * Expected on disk under ASSET_ROOT (assets/minecraft/, gitignored):
 *   gui/inventory.png        - vanilla "Inventory" screen background, 176x166px, from
 *                               assets/minecraft/textures/gui/container/inventory.png
 *                               in the game's own resource files
 *   gui/enchant_glint.png    - optional, the shimmering enchantment overlay
 *   items/<item_id>.png      - one 16x16 (or 32x32) sprite per item, named
 *                               after the id's path (e.g. "diamond_sword.png"
 *                               for "minecraft:diamond_sword"), from
 *                               assets/minecraft/textures/item/ and
 *                               assets/minecraft/textures/block/ (for
 *                               block items) in the same resource files
 *   font/minecraft.ttf       - optional, the actual Minecraft font, for
 *                               stack-count numbers; falls back to a
 *                               bold sans-serif if absent (see
 *                               drawStackCount below)
 *
 * These are Mojang's own copyrighted assets and are deliberately NOT
 * bundled with the bot's source - whoever deploys this feature needs to
 * supply their own copy (extracted from a legitimately owned copy of the
 * game, or the server's own resource pack) and drop it under ASSET_ROOT.
 * `assetsReady()` below lets /inv detect the missing-assets case and
 * fail with a clear setup message instead of a broken image.
 */

const path = require('node:path');
const fs = require('node:fs');

const ASSET_ROOT = path.join(__dirname, '..', '..', 'assets', 'minecraft');
const GUI_BACKGROUND_PATH = path.join(ASSET_ROOT, 'gui', 'inventory.png');
const ITEMS_DIR = path.join(ASSET_ROOT, 'items');
const FONT_PATH = path.join(ASSET_ROOT, 'font', 'minecraft.ttf');

// Native vanilla GUI resolution. Everything is scaled up from this by
// SCALE using nearest-neighbor, matching how Minecraft itself scales its
// own UI ("GUI Scale") - this is what keeps the output crisp instead of
// looking like a blurry screenshot resize.
const NATIVE_WIDTH = 176;
const NATIVE_HEIGHT = 166;
const SLOT_SIZE = 18; // px, native resolution, including the 1px recessed border
const SCALE = 4; // output = 704x664px; bump for a higher-res Discord embed image

/**
 * Native-resolution (176x166 texture) top-left pixel of every slot,
 * measured off the vanilla inventory.png layout. This is the piece that
 * makes armor + offhand ("عرض الدرع واليد الثانوية") land in the right
 * spot alongside the 27 main + 9 hotbar slots.
 */
const SLOTS = {
  armor: {
    helmet: { x: 8, y: 8 },
    chestplate: { x: 8, y: 26 },
    leggings: { x: 8, y: 44 },
    boots: { x: 8, y: 62 },
  },
  offhand: { x: 77, y: 62 },
  // 3 rows x 9 columns
  main: Array.from({ length: 27 }, (_, i) => ({
    x: 8 + (i % 9) * SLOT_SIZE,
    y: 84 + Math.floor(i / 9) * SLOT_SIZE,
  })),
  // hotbar sits below a small gap, separate from the main-inventory block
  hotbar: Array.from({ length: 9 }, (_, i) => ({
    x: 8 + i * SLOT_SIZE,
    y: 142,
  })),
};

/** True once real asset files have been dropped in; lets callers fail fast with a helpful message instead of a broken/placeholder image. */
function assetsReady() {
  return fs.existsSync(GUI_BACKGROUND_PATH);
}

function itemTexturePath(itemId) {
  const bare = String(itemId).replace(/^minecraft:/, '');
  return path.join(ITEMS_DIR, `${bare}.png`);
}

// The GUI background and item sprites are static files on disk - every
// render was re-reading and re-decoding them from scratch (disk I/O +
// PNG decode) even though the same handful of textures get drawn on
// nearly every /inv call. Cache the decoded Image objects by path so
// repeat renders reuse them instead of hitting the filesystem again.
// Unbounded by design: the key space is the fixed set of asset files
// shipped under ASSET_ROOT, not anything per-user/per-render.
const imageCache = new Map(); // absolute path -> loaded Image

async function loadImageCached(loadImage, filePath) {
  const cached = imageCache.get(filePath);
  if (cached) return cached;

  const image = await loadImage(filePath);
  imageCache.set(filePath, image);
  return image;
}

/**
 * Renders one inventory snapshot to a PNG buffer.
 *
 * @param {{ main: (object|null)[], armor: object, offhand: object|null }} snapshot - see inventoryService.normalizeSnapshot
 * @returns {Promise<Buffer>}
 */
async function renderInventoryImage(snapshot) {
  if (!assetsReady()) {
    throw new Error(
      'Inventory texture assets are not installed yet (assets/minecraft/gui/inventory.png missing). ' +
        'See the ASSETS section in services/inventoryRenderService.js.'
    );
  }

  // Lazy require: keeps @napi-rs/canvas an optional dependency until
  // it's actually installed, instead of crashing bot startup for
  // servers that haven't added it yet.
  const { createCanvas, loadImage, GlobalFonts } = require('@napi-rs/canvas');

  if (fs.existsSync(FONT_PATH) && !GlobalFonts.has('MinecraftRegular')) {
    GlobalFonts.registerFromPath(FONT_PATH, 'MinecraftRegular');
  }

  const canvas = createCanvas(NATIVE_WIDTH * SCALE, NATIVE_HEIGHT * SCALE);
  const ctx = canvas.getContext('2d');
  ctx.imageSmoothingEnabled = false; // critical: keeps every scaled draw pixel-crisp, no blur

  const background = await loadImageCached(loadImage, GUI_BACKGROUND_PATH);
  ctx.drawImage(background, 0, 0, NATIVE_WIDTH * SCALE, NATIVE_HEIGHT * SCALE);

  const drawItem = async (item, slot) => {
    if (!item) return;
    await drawItemAt(ctx, loadImage, item, slot.x * SCALE, slot.y * SCALE);
  };

  await drawItem(snapshot.armor.helmet, SLOTS.armor.helmet);
  await drawItem(snapshot.armor.chestplate, SLOTS.armor.chestplate);
  await drawItem(snapshot.armor.leggings, SLOTS.armor.leggings);
  await drawItem(snapshot.armor.boots, SLOTS.armor.boots);
  await drawItem(snapshot.offhand, SLOTS.offhand);

  for (let i = 0; i < 27; i++) await drawItem(snapshot.main[i + 9] ?? null, SLOTS.main[i]);
  for (let i = 0; i < 9; i++) await drawItem(snapshot.main[i] ?? null, SLOTS.hotbar[i]);

  return canvas.toBuffer('image/png');
}

/** Draws one item sprite + its stack-count label at a given canvas (already-scaled) position. */
async function drawItemAt(ctx, loadImage, item, px, py) {
  const iconSize = 16 * SCALE; // item sprites sit inset 1px within an 18px slot
  const inset = 1 * SCALE;

  try {
    const icon = await loadImageCached(loadImage, itemTexturePath(item.id));
    ctx.drawImage(icon, px + inset, py + inset, iconSize, iconSize);
  } catch {
    // Missing sprite for this item id: skip the icon but still show the
    // count, rather than failing the whole render over one unknown item.
  }

  if (item.enchanted) {
    // Placeholder for the glint overlay - composited with 'lighter' blend
    // once gui/enchant_glint.png is present; intentionally a no-op until then.
  }

  if (item.count > 1) drawStackCount(ctx, item.count, px + inset, py + inset, iconSize);
}

/** Mimics vanilla's stack-count label: bottom-right aligned, white text with a hard black drop shadow, no anti-aliasing. */
function drawStackCount(ctx, count, iconX, iconY, iconSize) {
  const fontSize = 8 * SCALE;
  ctx.font = `${fontSize}px ${GlobalFontRegistered() ? 'MinecraftRegular' : 'sans-serif'}`;
  ctx.textAlign = 'right';
  ctx.textBaseline = 'bottom';

  const text = String(count);
  const x = iconX + iconSize - 1 * SCALE;
  const y = iconY + iconSize + 1 * SCALE;

  ctx.fillStyle = '#3f3f3f';
  ctx.fillText(text, x + SCALE / 2, y + SCALE / 2);
  ctx.fillStyle = '#ffffff';
  ctx.fillText(text, x, y);
}

function GlobalFontRegistered() {
  try {
    // Re-check lazily rather than caching, since it's cheap and this
    // avoids a load-order dependency on renderInventoryImage's registration.
    return require('@napi-rs/canvas').GlobalFonts.has('MinecraftRegular');
  } catch {
    return false;
  }
}

module.exports = { renderInventoryImage, assetsReady, SLOTS, NATIVE_WIDTH, NATIVE_HEIGHT, SCALE };

/**
 * =========================================================================
 * README: finishing this feature later
 * =========================================================================
 * 1. `npm install @napi-rs/canvas` and add it to package.json.
 * 2. Create assets/minecraft/{gui,items,font}/ and populate per the
 *    ASSETS section above (add assets/minecraft/ to .gitignore - don't
 *    commit Mojang's textures to the repo).
 * 3. Implement NovaBridge's "get_inventory" CommandHandler per the
 *    contract documented in services/inventoryService.js - reading
 *    Bukkit's PlayerInventory (getContents, getArmorContents,
 *    getItemInOffHand) and mapping Material -> the same id scheme this
 *    file expects (Material.name().toLowerCase()).
 * 4. Implement the enchantment glint overlay in drawItemAt (currently a
 *    documented no-op) once gui/enchant_glint.png is in place.
 * 5. Wire commands/minecraft/inv.js's rendering step to call
 *    renderInventoryImage and attach the result - the command already
 *    does this; it will simply start succeeding once steps 1-3 are done.
 */
