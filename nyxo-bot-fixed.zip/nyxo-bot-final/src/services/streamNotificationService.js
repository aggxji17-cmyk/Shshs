const axios = require('axios');
const { config } = require('../config/config');
const { baseEmbed } = require('../utils/embeds');
const StreamSubscription = require('../database/models/StreamSubscription');
const logger = require('../utils/logger');

let twitchAppToken = null;
let twitchTokenExpiresAt = 0;

/** Client-credentials OAuth token for the Twitch Helix API, cached until near expiry. */
async function getTwitchAppToken() {
  if (twitchAppToken && Date.now() < twitchTokenExpiresAt) return twitchAppToken;
  if (!config.twitch.clientId || !config.twitch.clientSecret) return null;

  const res = await axios.post('https://id.twitch.tv/oauth2/token', null, {
    params: {
      client_id: config.twitch.clientId,
      client_secret: config.twitch.clientSecret,
      grant_type: 'client_credentials',
    },
  });

  twitchAppToken = res.data.access_token;
  twitchTokenExpiresAt = Date.now() + (res.data.expires_in - 60) * 1000;
  return twitchAppToken;
}

async function checkTwitchSubscription(sub, client) {
  const token = await getTwitchAppToken();
  if (!token) return;

  const res = await axios
    .get('https://api.twitch.tv/helix/streams', {
      params: { user_login: sub.channelIdentifier },
      headers: { 'Client-Id': config.twitch.clientId, Authorization: `Bearer ${token}` },
    })
    .catch(() => null);
  if (!res) return;

  const stream = res.data.data?.[0];
  const isLiveNow = Boolean(stream);

  if (isLiveNow && !sub.isLive) {
    const channel = client.channels.cache.get(sub.discordChannelId);
    if (channel) {
      const message = sub.message.replace('{channel}', sub.channelIdentifier).replace('{title}', stream.title);
      const embed = baseEmbed({ embedColor: '#9146FF', footer: 'Twitch' })
        .setTitle(`${sub.channelIdentifier} is live!`)
        .setURL(`https://twitch.tv/${sub.channelIdentifier}`)
        .setDescription(stream.title)
        .setImage(stream.thumbnail_url.replace('{width}', '640').replace('{height}', '360'));
      channel.send({ content: message, embeds: [embed] }).catch(() => null);
    }
    sub.lastSeenId = stream.id;
  }

  sub.isLive = isLiveNow;
  await sub.save();
}

async function checkYoutubeSubscription(sub, client) {
  if (!config.youtube.apiKey) return;

  // Every channel has a deterministic "uploads" playlist: swap the
  // "UC" prefix of the channel ID for "UU". Reading that playlist via
  // playlistItems.list costs 1 quota unit and reflects new uploads
  // immediately. The previous implementation used search.list, which
  // costs 100 units per call - at a 3-minute poll interval that alone
  // burns the entire default 10,000/day quota in a few hours, after
  // which every check silently failed (caught and swallowed) and
  // notifications just stopped firing with no visible error.
  const uploadsPlaylistId = sub.channelIdentifier.replace(/^UC/, 'UU');

  const res = await axios
    .get('https://www.googleapis.com/youtube/v3/playlistItems', {
      params: {
        key: config.youtube.apiKey,
        playlistId: uploadsPlaylistId,
        part: 'snippet',
        maxResults: 1,
      },
    })
    .catch((err) => {
      logger.warn(
        `YouTube check failed for ${sub.channelIdentifier}: ${err.response?.status || ''} ${
          err.response?.data?.error?.message || err.message
        }`
      );
      return null;
    });
  if (!res) return;

  const latest = res.data.items?.[0];
  if (!latest) return;

  const videoId = latest.snippet?.resourceId?.videoId;
  if (!videoId || videoId === sub.lastSeenId) return;

  // Only announce once we have a baseline - the very first check just
  // records the current latest video instead of spamming old uploads.
  if (sub.lastSeenId) {
    const channel = client.channels.cache.get(sub.discordChannelId);
    if (channel) {
      const message = sub.message.replace('{channel}', latest.snippet.channelTitle).replace('{title}', latest.snippet.title);
      const embed = baseEmbed({ embedColor: '#FF0000', footer: 'YouTube' })
        .setTitle(latest.snippet.title)
        .setURL(`https://youtube.com/watch?v=${videoId}`)
        .setDescription(latest.snippet.description?.slice(0, 200) || '')
        .setImage(latest.snippet.thumbnails?.high?.url || null);
      channel.send({ content: message, embeds: [embed] }).catch(() => null);
    }
  }

  sub.lastSeenId = videoId;
  await sub.save();
}

const POLL_INTERVAL_MS = 3 * 60 * 1000;

function startStreamNotificationPoller(client) {
  if (!config.twitch.clientId && !config.youtube.apiKey) {
    logger.warn('Twitch/YouTube API credentials not set - stream notifications are disabled.');
    return;
  }

  setInterval(async () => {
    const subs = await StreamSubscription.find({}).catch(() => []);
    for (const sub of subs) {
      try {
        if (sub.platform === 'twitch') await checkTwitchSubscription(sub, client);
        else await checkYoutubeSubscription(sub, client);
      } catch (err) {
        logger.warn(`Stream check failed for ${sub.platform}/${sub.channelIdentifier}: ${err.message}`);
      }
    }
  }, POLL_INTERVAL_MS).unref?.();
}

module.exports = { startStreamNotificationPoller };
