const FavoriteSong = require('../database/models/FavoriteSong');
const { searchTrack } = require('./playlistService');

const MAX_FAVORITES = 200;

async function getFavorites(userId) {
  const doc = await FavoriteSong.findOne({ userId });
  return doc?.tracks || [];
}

function toTrackData(track) {
  return {
    title: track.title,
    url: track.url,
    duration: track.duration || null,
    thumbnail: track.thumbnail || null,
    author: track.author || null,
  };
}

/**
 * Shared by both /favorites add (a text query the user typed) and the
 * ❤️ Now Playing button (an already-resolved discord-player Track) -
 * the button skips straight to addTrackData so favoriting the current
 * song never re-searches for something the bot already has in hand.
 */
async function addTrackData(userId, trackData) {
  let doc = await FavoriteSong.findOne({ userId });
  if (!doc) doc = new FavoriteSong({ userId, tracks: [] });

  if (doc.tracks.some((t) => t.url === trackData.url)) {
    return { error: `**${trackData.title}** is already in your favorites.` };
  }
  if (doc.tracks.length >= MAX_FAVORITES) {
    return { error: `You already have ${MAX_FAVORITES} favorites, which is the limit. Remove one first.` };
  }

  doc.tracks.push(trackData);
  await doc.save();
  return { track: trackData, total: doc.tracks.length };
}

async function addFavorite(userId, query, requestedBy) {
  const track = await searchTrack(query, requestedBy);
  if (!track) return { error: `Couldn't find anything for **${query}**.` };
  return addTrackData(userId, toTrackData(track));
}

async function removeFavorite(userId, index) {
  const doc = await FavoriteSong.findOne({ userId });
  if (!doc || index < 0 || index >= doc.tracks.length) {
    return { error: `You don't have a favorite at position ${index + 1}.` };
  }

  const [removed] = doc.tracks.splice(index, 1);
  await doc.save();
  return { removed };
}

async function clearFavorites(userId) {
  const doc = await FavoriteSong.findOne({ userId });
  const count = doc?.tracks.length || 0;
  if (doc) {
    doc.tracks = [];
    await doc.save();
  }
  return { count };
}

module.exports = {
  MAX_FAVORITES,
  getFavorites,
  toTrackData,
  addTrackData,
  addFavorite,
  removeFavorite,
  clearFavorites,
};
