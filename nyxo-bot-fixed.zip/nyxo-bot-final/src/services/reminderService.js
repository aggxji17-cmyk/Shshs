const Reminder = require('../database/models/Reminder');
const { baseEmbed } = require('../utils/embeds');
const { resolved } = require('../utils/resolveGuildSettings');
const logger = require('../utils/logger');

const POLL_INTERVAL_MS = 15_000;

async function deliverReminder(client, reminder) {
  const channel = await client.channels.fetch(reminder.channelId).catch(() => null);
  const settings = resolved({});
  const embed = baseEmbed(settings)
    .setTitle('⏰ Reminder')
    .setDescription(reminder.message)
    .addFields({ name: 'Set', value: `<t:${Math.floor(reminder.createdAt.getTime() / 1000)}:R>` });

  if (channel) {
    await channel.send({ content: `<@${reminder.userId}>`, embeds: [embed] }).catch(async () => {
      const user = await client.users.fetch(reminder.userId).catch(() => null);
      await user?.send({ embeds: [embed] }).catch(() => null);
    });
  } else {
    const user = await client.users.fetch(reminder.userId).catch(() => null);
    await user?.send({ embeds: [embed] }).catch(() => null);
  }
}

function startReminderScheduler(client) {
  setInterval(async () => {
    try {
      const due = await Reminder.find({ sent: false, remindAt: { $lte: new Date() } }).limit(50);
      for (const reminder of due) {
        reminder.sent = true;
        await reminder.save();
        await deliverReminder(client, reminder);
      }
    } catch (err) {
      logger.error(`Reminder scheduler error: ${err.stack || err}`);
    }
  }, POLL_INTERVAL_MS);
}

module.exports = { startReminderScheduler };
