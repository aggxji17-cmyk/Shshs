const { ChannelType } = require('discord.js');
const { sendModLog } = require('../utils/modLog');

// guildId -> array of join timestamps (ms) within the tracking window
const joinTimestamps = new Map();
// guildId -> true while a raid lockdown triggered by this service is active
const activeLockdowns = new Set();

/**
 * Records a join and checks whether it pushed the guild over its configured
 * burst threshold. Returns true if a raid was just detected (and handled)
 * on this call, so the caller can avoid double-processing later joins that
 * arrive while a lockdown is already active.
 */
async function recordJoinAndCheckRaid(member, guildConfig, settings) {
  if (!guildConfig.antiRaid?.enabled) return false;
  if (activeLockdowns.has(member.guild.id)) return true; // already mid-raid-response

  const now = Date.now();
  const windowMs = guildConfig.antiRaid.windowMs;
  const list = (joinTimestamps.get(member.guild.id) || []).filter((t) => now - t < windowMs);
  list.push(now);
  joinTimestamps.set(member.guild.id, list);

  if (list.length < guildConfig.antiRaid.joinThreshold) return false;

  await triggerRaidResponse(member.guild, guildConfig, settings, list.length);
  return true;
}

const LOCKDOWN_AUTO_CLEAR_MS = 10 * 60 * 1000;

async function triggerRaidResponse(guild, guildConfig, settings, joinCount) {
  activeLockdowns.add(guild.id);
  setTimeout(() => clearLockdown(guild.id), LOCKDOWN_AUTO_CLEAR_MS).unref?.();

  if (guildConfig.antiRaid.action === 'lockdown') {
    const textChannels = guild.channels.cache.filter((c) => c.type === ChannelType.GuildText);
    for (const channel of textChannels.values()) {
      await channel.permissionOverwrites.edit(guild.roles.everyone, { SendMessages: false }).catch(() => null);
    }
  }

  await sendModLog(guild, guildConfig, settings, {
    title: '🚨 Raid Detected',
    description: `${joinCount} members joined within the configured window. Action taken: **${guildConfig.antiRaid.action}**.`,
    color: '#ED4245',
  });
}

function isLockdownActive(guildId) {
  return activeLockdowns.has(guildId);
}

function clearLockdown(guildId) {
  activeLockdowns.delete(guildId);
  joinTimestamps.delete(guildId);
}

/** True if the account is younger than the configured new-account threshold. */
function isNewAccount(user, guildConfig) {
  const ageDays = (Date.now() - user.createdTimestamp) / (1000 * 60 * 60 * 24);
  return ageDays < (guildConfig.antiRaid?.newAccountAgeDays ?? 7);
}

module.exports = { recordJoinAndCheckRaid, isLockdownActive, clearLockdown, isNewAccount };
