const { AttachmentBuilder, EmbedBuilder } = require('discord.js');
const MinecraftStatusPanel = require('../database/models/MinecraftStatusPanel');
const { getServerStatus, getBedrockServerStatus } = require('./minecraftService');
const { getGuildConfig, resolved } = require('../utils/resolveGuildSettings');
const logger = require('../utils/logger');

const UPDATE_INTERVAL_MS = 60 * 1000; // Panel refreshes in place every 60s.

/**
 * Formats an ip:port pair, hiding the port when it's the default Java port.
 * Mirrors the formatting used by /ip so both surfaces look consistent.
 */
function formatAddress(ip, port, hideDefaultPort) {
  if (!ip) return 'Not configured';
  if (!port || (hideDefaultPort && port === 25565)) return `\`${ip}\``;
  return `\`${ip}:${port}\``;
}

/**
 * Queries the configured Java/Bedrock servers live and builds the status
 * panel embed (+ favicon attachment, if any). Green when online, red when
 * offline, matching the bot's existing success/error embed colors.
 */
async function buildStatusPanelEmbed(settings) {
  const { name, ip, port, bedrockPort } = settings.minecraft;
  // Bedrock shares the same IP as Java - only the port is separate.

  const [javaStatus, bedrockStatus] = await Promise.all([
    getServerStatus(ip, port),
    bedrockPort ? getBedrockServerStatus(ip, bedrockPort) : Promise.resolve(null),
  ]);

  const isOnline = javaStatus.online || Boolean(bedrockStatus?.online);
  const primary = javaStatus.online ? javaStatus : bedrockStatus;

  const embed = new EmbedBuilder()
    .setColor(isOnline ? '#57F287' : '#ED4245')
    .setTitle(`🎮 ${name}`)
    .setFooter({ text: settings.footer })
    .setTimestamp()
    .addFields(
      { name: 'Status', value: isOnline ? '🟢 Online' : '🔴 Offline', inline: true },
      {
        name: 'Players',
        value: isOnline ? `${primary.players.online} / ${primary.players.max}` : '—',
        inline: true,
      },
      { name: 'Ping', value: isOnline && primary.ping != null ? `${primary.ping}ms` : '—', inline: true },
      {
        name: 'Java IP',
        value: `${formatAddress(ip, port, true)}${ip && !javaStatus.online ? ' (offline)' : ''}`,
        inline: true,
      },
      {
        name: 'Bedrock Port',
        value: bedrockPort ? `\`${bedrockPort}\`${!bedrockStatus?.online ? ' (offline)' : ''}` : 'Not configured',
        inline: true,
      },
      { name: 'Version', value: isOnline && primary.version ? primary.version : '—', inline: true },
      { name: 'Last Updated', value: `<t:${Math.floor(Date.now() / 1000)}:R>`, inline: false }
    );

  const motd = javaStatus.motd || bedrockStatus?.motd;
  if (motd) embed.setDescription(`*${motd}*`);

  const files = [];
  if (javaStatus.online && javaStatus.favicon) {
    const base64 = javaStatus.favicon.replace(/^data:image\/png;base64,/, '');
    const attachment = new AttachmentBuilder(Buffer.from(base64, 'base64'), { name: 'server-icon.png' });
    files.push(attachment);
    embed.setThumbnail('attachment://server-icon.png');
  }

  return { embeds: [embed], files };
}

/**
 * Creates (or recreates) a guild's status panel in the given channel.
 * If a panel already exists, its old message is deleted first (best
 * effort - it may already be gone, which is exactly the "recreate after
 * deletion" case this is meant to handle). The new location is upserted
 * into the database.
 */
async function setupStatusPanel(channel, settings, guildId) {
  const existing = await MinecraftStatusPanel.findOne({ guildId });

  if (existing) {
    const oldChannel = channel.guild.channels.cache.get(existing.channelId);
    const oldMessage = oldChannel ? await oldChannel.messages.fetch(existing.messageId).catch(() => null) : null;
    if (oldMessage) await oldMessage.delete().catch(() => null);
  }

  const { embeds, files } = await buildStatusPanelEmbed(settings);
  const message = await channel.send({ embeds, files });

  await MinecraftStatusPanel.findOneAndUpdate(
    { guildId },
    { guildId, channelId: channel.id, messageId: message.id },
    { upsert: true }
  );

  return message;
}

/**
 * Refreshes a single guild's panel in place. Silently does nothing if the
 * guild, channel, or message can no longer be found - the panel will be
 * recreated the next time /setupstatus is run, per spec.
 */
async function refreshPanel(client, panelDoc) {
  const guild = client.guilds.cache.get(panelDoc.guildId);
  if (!guild) return;

  const channel = guild.channels.cache.get(panelDoc.channelId);
  if (!channel) return;

  const message = await channel.messages.fetch(panelDoc.messageId).catch(() => null);
  if (!message) return;

  const guildConfig = await getGuildConfig(panelDoc.guildId);
  const settings = resolved(guildConfig);

  const { embeds, files } = await buildStatusPanelEmbed(settings);
  await message
    .edit({ embeds, files })
    .catch((err) => logger.warn(`Failed to update MC status panel for ${panelDoc.guildId}: ${err.message}`));
}

async function refreshAllPanels(client) {
  const panels = await MinecraftStatusPanel.find({}).catch(() => []);
  for (const panel of panels) {
    await refreshPanel(client, panel);
  }
}

function startMinecraftStatusPanelUpdater(client) {
  refreshAllPanels(client).catch(() => null);
  setInterval(() => refreshAllPanels(client).catch(() => null), UPDATE_INTERVAL_MS).unref?.();
}

module.exports = { buildStatusPanelEmbed, setupStatusPanel, startMinecraftStatusPanelUpdater };
