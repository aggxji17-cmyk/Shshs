/**
 * The AutoMod check registry.
 *
 * Every protection type AutoMod supports is one entry in the CHECKS array
 * below: a `key` (matches a key under GuildConfig.automod.checks), a
 * display `label`, whether it uses a numeric `threshold` (and what that
 * number means), and a `test(message, checkCfg)` function that returns
 * `{ violated: false }` or `{ violated: true, reason }`.
 *
 * To add a brand new protection type in the future: write one `test`
 * function, add one object to CHECKS, and add one matching field to
 * GuildConfig.automod.checks (database/models/GuildConfig.js). Nothing in
 * autoModerationService.js or the /automod command needs to change -
 * both already work generically off this registry.
 */

const AUTOMOD_SPAM_WINDOW_MS = 7000;

const INVITE_REGEX = /(discord\.(gg|io|me|li)|discordapp\.com\/invite|discord\.com\/invite)\/[a-z0-9-]+/i;
const LINK_REGEX = /https?:\/\/[^\s]+/i;
const CUSTOM_EMOJI_REGEX = /<a?:\w+:\d+>/g;
const UNICODE_EMOJI_REGEX = /\p{Extended_Pictographic}/gu;
// Combining/diacritical mark ranges commonly stacked to produce "zalgo" text.
const ZALGO_REGEX = /[\u0300-\u036f\u1ab0-\u1aff\u1dc0-\u1dff\u20d0-\u20ff\ufe20-\ufe2f]/g;
const CAPS_MIN_LENGTH = 8;

// Per-user rolling message timestamps for the spam check, keyed by
// `${guildId}:${userId}`. Lives here (not in autoModerationService.js)
// because it's detection state, not punishment/orchestration state.
const spamTracker = new Map();

function checkAntiSpam(message, cfg) {
  const key = `${message.guildId}:${message.author.id}`;
  const now = Date.now();
  const timestamps = (spamTracker.get(key) || []).filter((t) => now - t < AUTOMOD_SPAM_WINDOW_MS);
  timestamps.push(now);
  spamTracker.set(key, timestamps);

  if (timestamps.length >= (cfg.threshold || 5)) {
    return { violated: true, reason: 'أنت ترسل رسائل بسرعة كبيرة جدًا.' };
  }
  return { violated: false };
}

// Every guildId:userId pair that has ever sent a message with antiSpam
// enabled gets an entry above that was never removed - only the
// timestamp array inside it got trimmed. On a multi-guild bot this grows
// without bound for the life of the process. Periodic sweep (same pattern
// as utils/cooldown.js) drops entries whose window has fully expired.
const SPAM_TRACKER_SWEEP_MS = 5 * 60_000;
const spamTrackerSweepTimer = setInterval(() => {
  const now = Date.now();
  for (const [key, timestamps] of spamTracker) {
    const fresh = timestamps.filter((t) => now - t < AUTOMOD_SPAM_WINDOW_MS);
    if (fresh.length === 0) spamTracker.delete(key);
    else if (fresh.length !== timestamps.length) spamTracker.set(key, fresh);
  }
}, SPAM_TRACKER_SWEEP_MS);
spamTrackerSweepTimer.unref();

function checkAntiInvite(message) {
  if (INVITE_REGEX.test(message.content || '')) {
    return { violated: true, reason: 'روابط دعوات Discord غير مسموحة هنا.' };
  }
  return { violated: false };
}

function checkAntiLink(message) {
  if (LINK_REGEX.test(message.content || '')) {
    return { violated: true, reason: 'نشر الروابط غير مسموح هنا.' };
  }
  return { violated: false };
}

function checkAntiMentionSpam(message, cfg) {
  const uniqueMentions = new Set([...message.mentions.users.keys(), ...message.mentions.roles.keys()]);
  if (message.mentions.everyone) uniqueMentions.add('@everyone');

  if (uniqueMentions.size >= (cfg.threshold || 5)) {
    return { violated: true, reason: 'رسالتك تحتوي على عدد كبير جدًا من المنشنات (Mentions).' };
  }
  return { violated: false };
}

function checkAntiMassEmoji(message, cfg) {
  const content = message.content || '';
  const count = (content.match(CUSTOM_EMOJI_REGEX) || []).length + (content.match(UNICODE_EMOJI_REGEX) || []).length;

  if (count >= (cfg.threshold || 7)) {
    return { violated: true, reason: 'رسالتك تحتوي على عدد كبير جدًا من الإيموجي.' };
  }
  return { violated: false };
}

function checkAntiCaps(message, cfg) {
  const content = message.content || '';
  const letters = content.replace(/[^a-zA-Z]/g, '');
  if (letters.length < CAPS_MIN_LENGTH) return { violated: false };

  const upper = letters.replace(/[^A-Z]/g, '');
  const ratio = (upper.length / letters.length) * 100;

  if (ratio >= (cfg.threshold ?? 70)) {
    return { violated: true, reason: 'يرجى عدم استخدام الأحرف الكبيرة (Caps) بكثرة.' };
  }
  return { violated: false };
}

function checkAntiZalgo(message, cfg) {
  const content = message.content || '';
  if (content.length < 5) return { violated: false };

  const zalgoChars = (content.match(ZALGO_REGEX) || []).length;
  const ratio = (zalgoChars / content.length) * 100;

  if (ratio >= (cfg.threshold ?? 30)) {
    return { violated: true, reason: 'رسالتك تحتوي على رموز Zalgo/Unicode مشبوهة.' };
  }
  return { violated: false };
}

const CHECKS = [
  {
    key: 'antiSpam',
    label: 'Anti Spam',
    hasThreshold: true,
    thresholdLabel: `عدد الرسائل خلال ${AUTOMOD_SPAM_WINDOW_MS / 1000} ثواني`,
    test: checkAntiSpam,
  },
  { key: 'antiInvite', label: 'Anti Invite', hasThreshold: false, test: checkAntiInvite },
  { key: 'antiLink', label: 'Anti Links', hasThreshold: false, test: checkAntiLink },
  {
    key: 'antiMentionSpam',
    label: 'Anti Mention Spam',
    hasThreshold: true,
    thresholdLabel: 'أقصى عدد منشنات في الرسالة',
    test: checkAntiMentionSpam,
  },
  {
    key: 'antiMassEmoji',
    label: 'Anti Mass Emoji',
    hasThreshold: true,
    thresholdLabel: 'أقصى عدد إيموجي في الرسالة',
    test: checkAntiMassEmoji,
  },
  {
    key: 'antiCaps',
    label: 'Anti Caps',
    hasThreshold: true,
    thresholdLabel: 'أقصى نسبة أحرف كبيرة %',
    test: checkAntiCaps,
  },
  {
    key: 'antiZalgo',
    label: 'Anti Zalgo/Unicode Spam',
    hasThreshold: true,
    thresholdLabel: 'أقصى نسبة رموز Zalgo %',
    test: checkAntiZalgo,
  },
];

module.exports = { CHECKS, AUTOMOD_SPAM_WINDOW_MS };
