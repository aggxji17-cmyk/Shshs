const MinecraftPendingDelivery = require('../database/models/MinecraftPendingDelivery');
const MinecraftDelivery = require('../database/models/MinecraftDelivery');
const MinecraftLink = require('../database/models/MinecraftLink');
const { getPlayerCache, buildPresenceInfo } = require('./minecraftPlayerService');
const { runCommand, CommandTimeoutError } = require('./commandQueueService');
const { renderCommandTemplate, sendDeliveryLog, DeliveryError } = require('./minecraftDeliveryService');
const { getGuildConfig } = require('../utils/resolveGuildSettings');
const { t, resolveLanguage } = require('../utils/i18n');
const logger = require('../utils/logger');

/**
 * Task 5: "إذا كان غير متصل، يتم حفظه وتسليمه عند دخوله."
 *
 * services/minecraftDeliveryService.js queues an "item"-kind purchase
 * here (MinecraftPendingDelivery, one row per queued purchase) instead of
 * sending its command when the buyer isn't online on the item's target
 * server. This background poller is the other half: every
 * POLL_INTERVAL_MS it re-checks presence (via the same read-only
 * MinecraftPlayerCache mirror NovaBridge keeps updated on join/quit -
 * PlayerPresenceListener.java, no plugin changes needed) for every still-
 * pending row, and delivers the ones whose buyer is now online on the
 * right server - exactly like an immediate delivery would have, just
 * delayed.
 *
 * A player joining is what makes a row deliverable, but nothing pushes
 * this poller from that join event directly (the plugin only writes
 * presence, it doesn't know about pending deliveries) - polling is what
 * turns "they're online now" into "deliver it", same pattern as
 * commandQueueService.js on the plugin side.
 */

const POLL_INTERVAL_MS = 15_000;
const BATCH_LIMIT = 25;
const DELIVERY_TIMEOUT_MS = 8000;

function startPendingDeliveryScheduler(client) {
  const tick = async () => {
    try {
      await processPendingDeliveries(client);
    } catch (err) {
      logger.error(`Pending Minecraft delivery poller error: ${err.stack || err}`);
    }
  };

  tick();
  setInterval(tick, POLL_INTERVAL_MS);
}

async function processPendingDeliveries(client) {
  const pending = await MinecraftPendingDelivery.find({ status: 'pending' }).sort({ createdAt: 1 }).limit(BATCH_LIMIT);

  for (const entry of pending) {
    await resolveOne(client, entry).catch((err) => {
      logger.error(`Failed to resolve pending delivery ${entry._id}: ${err.stack || err}`);
    });
  }
}

async function resolveOne(client, entry) {
  const cache = await getPlayerCache(entry.minecraftUuid);
  const presence = buildPresenceInfo(cache, entry.targetServerId);
  if (!presence.onlineHere) return; // still not on the right server - leave pending, try again next tick

  const guild = client.guilds.cache.get(entry.guildId);
  if (!guild) return; // bot no longer in that guild - leave pending in case it rejoins later

  const guildConfig = await getGuildConfig(entry.guildId);
  // No live interaction to read a locale from here (this runs on a
  // timer, not in response to a command) - falls back to the guild's
  // stored `/language` preference, or DEFAULT_LANGUAGE if unset.
  const lang = resolveLanguage({ guildConfigDoc: guildConfig });

  // Re-fetch the link (not just re-use the stored username) in case the
  // player's linked Minecraft username changed since the purchase.
  const link = await MinecraftLink.findOne({ guildId: entry.guildId, discordId: entry.discordUserId });
  if (!link) {
    await markFailed(entry, t(lang, 'minecraft_delivery.link_removed_before_delivery'));
    return;
  }

  let command;
  try {
    command = renderCommandTemplate(entry.commandTemplate, { username: link.minecraftUsername, uuid: link.minecraftUuid }, lang);
  } catch (err) {
    if (err instanceof DeliveryError) {
      await markFailed(entry, err.message);
      return;
    }
    throw err;
  }

  entry.attempts += 1;

  let outcome;
  let error = null;
  try {
    outcome = await runCommand(entry.targetServerId, 'console_command', { command }, { requestedBy: entry.requestedBy, timeoutMs: DELIVERY_TIMEOUT_MS });
  } catch (err) {
    if (!(err instanceof CommandTimeoutError)) throw err;
    outcome = null;
    error = t(lang, 'minecraft_delivery.timeout');
  }

  if (outcome && outcome.status === 'failed') {
    error = outcome.result?.error || t(lang, 'minecraft_delivery.command_failed');
  }

  const status = error ? 'failed' : 'done';

  await MinecraftDelivery.findByIdAndUpdate(entry.deliveryId, {
    status,
    error,
    command,
    serverCommandId: outcome?.commandId ?? null,
    deliveredAt: new Date(),
  });

  entry.status = status;
  entry.lastError = error;
  await entry.save();

  await sendDeliveryLog({
    guild,
    guildConfig,
    discordUserId: entry.discordUserId,
    link,
    item: { name: entry.itemName },
    targetServerId: entry.targetServerId,
    command,
    status,
    error,
    lang,
  }).catch(() => null);
}

async function markFailed(entry, error) {
  await MinecraftDelivery.findByIdAndUpdate(entry.deliveryId, { status: 'failed', error, deliveredAt: new Date() });
  entry.status = 'failed';
  entry.lastError = error;
  await entry.save();
}

module.exports = { startPendingDeliveryScheduler };
