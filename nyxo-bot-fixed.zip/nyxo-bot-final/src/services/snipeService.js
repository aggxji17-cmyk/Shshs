/**
 * In-memory cache of the last few deleted/edited messages per channel.
 * Not persisted to MongoDB on purpose: snipe data is inherently ephemeral
 * (most bots clear it on restart anyway) and this avoids a write on every
 * single message delete/edit, which would be a meaningful load at scale.
 * A bounded per-channel history plus a global cap keeps memory flat.
 */
const MAX_PER_CHANNEL = 5;
const MAX_CHANNELS = 2000;
const ENTRY_TTL_MS = 60 * 60 * 1000; // 1 hour

const deletedCache = new Map(); // channelId -> [{ ...entry }]
const editedCache = new Map();

function pushEntry(cache, channelId, entry) {
  if (!cache.has(channelId) && cache.size >= MAX_CHANNELS) {
    const oldestKey = cache.keys().next().value;
    cache.delete(oldestKey);
  }
  const list = cache.get(channelId) || [];
  list.unshift({ ...entry, at: Date.now() });
  cache.set(channelId, list.slice(0, MAX_PER_CHANNEL));
}

function getEntries(cache, channelId) {
  const list = cache.get(channelId) || [];
  const fresh = list.filter((e) => Date.now() - e.at < ENTRY_TTL_MS);
  if (fresh.length !== list.length) cache.set(channelId, fresh);
  return fresh;
}

function recordDeletedMessage(message) {
  if (!message.author) return;
  pushEntry(deletedCache, message.channelId, {
    authorId: message.author.id,
    authorTag: message.author.tag,
    authorAvatar: message.author.displayAvatarURL(),
    content: message.content || null,
    attachmentUrls: message.attachments?.map((a) => a.url) || [],
  });
}

function recordEditedMessage(oldMessage, newMessage) {
  if (!newMessage.author) return;
  pushEntry(editedCache, newMessage.channelId, {
    authorId: newMessage.author.id,
    authorTag: newMessage.author.tag,
    authorAvatar: newMessage.author.displayAvatarURL(),
    before: oldMessage.content || null,
    after: newMessage.content || null,
  });
}

function getLastDeleted(channelId, index = 0) {
  return getEntries(deletedCache, channelId)[index] || null;
}

function getLastEdited(channelId, index = 0) {
  return getEntries(editedCache, channelId)[index] || null;
}

module.exports = { recordDeletedMessage, recordEditedMessage, getLastDeleted, getLastEdited };
