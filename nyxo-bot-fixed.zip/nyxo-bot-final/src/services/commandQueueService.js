const ServerCommand = require('../database/models/ServerCommand');

/**
 * Generic bot -> NovaBridge request/response bridge, built on top of the
 * `server_commands` collection the plugin already polls (see
 * queue/CommandQueueService.java on the plugin side, and
 * database/models/ServerCommand.js here).
 *
 * This is intentionally NOT specific to inventories - it's the same
 * mechanism any future "ask a specific Minecraft server to do/report
 * something" feature (shop delivery, live playercount per-server, kick a
 * player, ...) can reuse: insert a command, wait for the plugin to fill
 * in `result`. /inv (services/inventoryService.js) is just the first
 * caller.
 */

const DEFAULT_TIMEOUT_MS = 8000;
const DEFAULT_POLL_INTERVAL_MS = 400;

class CommandTimeoutError extends Error {
  constructor(commandId) {
    super(`Command ${commandId} timed out waiting for the target server to respond.`);
    this.name = 'CommandTimeoutError';
    this.commandId = commandId;
  }
}

/**
 * Inserts a pending command addressed to a specific server. Resolves as
 * soon as the document exists - does NOT wait for the plugin to pick it
 * up. Pair with `waitForResult` (or use `runCommand` for both at once).
 *
 * @param {string} targetServerId - a NovaBridge server.id (see MinecraftServer._id)
 * @param {string} type - handler type, e.g. "get_inventory"
 * @param {object} [payload] - handler-specific input
 * @param {string|null} [requestedBy] - free-form origin marker, e.g. `discord:${userId}`
 * @returns {Promise<string>} the created command's id
 */
async function enqueueCommand(targetServerId, type, payload = {}, requestedBy = null) {
  if (!targetServerId) throw new Error('enqueueCommand: targetServerId is required.');
  if (!type) throw new Error('enqueueCommand: type is required.');

  const doc = await ServerCommand.create({
    targetServerId,
    type,
    payload,
    status: 'pending',
    requestedBy,
  });

  return String(doc._id);
}

/**
 * Polls a previously-enqueued command until the plugin marks it "done"
 * or "failed", or `timeoutMs` elapses.
 *
 * Polling (rather than e.g. a MongoDB change stream) matches the
 * plugin's own design - see CommandQueueService.java's class doc - and
 * keeps this usable against any MongoDB deployment (change streams need
 * a replica set) without extra ops requirements.
 *
 * @param {string} commandId
 * @param {object} [opts]
 * @param {number} [opts.timeoutMs]
 * @param {number} [opts.pollIntervalMs]
 * @returns {Promise<{ status: 'done'|'failed', result: any }>}
 * @throws {CommandTimeoutError} if the command is still pending/processing after `timeoutMs`
 */
async function waitForResult(commandId, opts = {}) {
  const timeoutMs = opts.timeoutMs ?? DEFAULT_TIMEOUT_MS;
  const pollIntervalMs = opts.pollIntervalMs ?? DEFAULT_POLL_INTERVAL_MS;
  const deadline = Date.now() + timeoutMs;

  for (;;) {
    const doc = await ServerCommand.findById(commandId).lean();

    if (doc && (doc.status === 'done' || doc.status === 'failed')) {
      return { status: doc.status, result: doc.result ?? null };
    }

    if (Date.now() >= deadline) {
      throw new CommandTimeoutError(commandId);
    }

    await new Promise((resolve) => setTimeout(resolve, pollIntervalMs));
  }
}

/**
 * Convenience wrapper: enqueue + wait in one call.
 *
 * @param {string} targetServerId
 * @param {string} type
 * @param {object} [payload]
 * @param {object} [opts] - see waitForResult; also accepts `requestedBy`
 */
async function runCommand(targetServerId, type, payload = {}, opts = {}) {
  const commandId = await enqueueCommand(targetServerId, type, payload, opts.requestedBy ?? null);
  return { commandId, ...(await waitForResult(commandId, opts)) };
}

module.exports = { enqueueCommand, waitForResult, runCommand, CommandTimeoutError };
