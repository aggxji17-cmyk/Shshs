const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { baseEmbed } = require('../utils/embeds');
const logger = require('../utils/logger');

const DEFAULT_PROMPT_MESSAGE =
  'شكراً لتواصلك مع فريق الدعم في **{server}**.\n\nقيّم تجربتك في التذكرة #{number} ({type}) باختيار عدد النجوم أدناه.';
const DEFAULT_THANK_YOU_MESSAGE = '✅・تم تسجيل تقييمك\n\nشكراً لوقتك. تساعدنا ملاحظاتك على تقديم دعم أفضل.';

/** Replaces {number}/{type}/{server} placeholders in a configurable rating message template. */
function applyRatingPlaceholders(template, { number, type, server }) {
  return String(template)
    .replaceAll('{number}', String(number))
    .replaceAll('{type}', type || 'غير محدد')
    .replaceAll('{server}', server || '');
}

/**
 * Sends the ⭐1-⭐5 rating DM to the ticket opener right after their ticket
 * closes. No-ops silently (and returns false) if ratings are disabled for
 * the guild or the user has DMs closed - closing a ticket must never fail
 * because of this.
 */
async function sendRatingPrompt(client, guild, guildConfig, settings, ticket) {
  const ratings = guildConfig.tickets.ratings;
  if (!ratings?.enabled) return false;

  const user = await client.users.fetch(ticket.userId).catch(() => null);
  if (!user) return false;

  const promptText = applyRatingPlaceholders(ratings.promptMessage ? ratings.promptMessage.replace(/\\n/g, '\n') : DEFAULT_PROMPT_MESSAGE, {
    number: ticket.ticketNumber,
    type: ticket.typeLabel,
    server: guild?.name,
  });

  const row = new ActionRowBuilder().addComponents(
    [1, 2, 3, 4, 5].map((n) =>
      new ButtonBuilder()
        .setCustomId(`ticket_rate:${ticket._id}:${n}`)
        .setLabel(String(n))
        .setEmoji('⭐')
        .setStyle(ButtonStyle.Secondary)
    )
  );

  const sent = await user
    .send({
       embeds: [
         baseEmbed(settings)
           .setTitle('📝・قيّم تجربة الدعم')
           .setDescription(promptText)
           .addFields({ name: '🎫 رقم التذكرة', value: `#${ticket.ticketNumber}`, inline: true }, { name: '⭐ التقييم', value: 'اختر من 1 إلى 5', inline: true }),
       ],
      components: [row],
    })
    .catch(() => null);

  return Boolean(sent);
}

/** Posts the full rating summary (stars, opener, staff, ticket #, close time, comment) to the configured ratings channel. */
async function postRatingResult(client, guild, guildConfig, settings, ticket, rating) {
  const channelId = guildConfig.tickets.ratings?.channelId;
  if (!channelId) return;

  const logChannel = guild.channels.cache.get(channelId);
  if (!logChannel) return;

  const ownerUser = await client.users.fetch(ticket.userId).catch(() => null);
  const staffUser = rating.staffId ? await client.users.fetch(rating.staffId).catch(() => null) : null;

  const stars = '⭐'.repeat(rating.stars) + '☆'.repeat(5 - rating.stars);
  const closedAtValue = ticket.closedAt ? `<t:${Math.floor(new Date(ticket.closedAt).getTime() / 1000)}:F>` : 'غير معروف';

  const embed = baseEmbed(settings)
    .setTitle(`⭐・تقييم جديد — تذكرة #${ticket.ticketNumber}`)
    .addFields(
      { name: '⭐ التقييم', value: `${stars} (${rating.stars}/5)`, inline: true },
      { name: '👤 صاحب التذكرة', value: ownerUser ? `${ownerUser.tag} (<@${ticket.userId}>)` : `<@${ticket.userId}>`, inline: true },
      { name: '🛡️ الإداري المسؤول', value: staffUser ? `${staffUser.tag} (<@${rating.staffId}>)` : rating.staffId ? `<@${rating.staffId}>` : 'غير محدد', inline: true },
      { name: '🎫 رقم التذكرة', value: `#${ticket.ticketNumber}`, inline: true },
      { name: '🕒 وقت الإغلاق', value: closedAtValue, inline: true },
      { name: '💬 التعليق', value: rating.comment || 'لا يوجد' }
    );

  await logChannel.send({ embeds: [embed] }).catch((err) => logger.warn(`تعذر إرسال نتيجة التقييم إلى روم التقييمات: ${err.message}`));
}

module.exports = { sendRatingPrompt, postRatingResult, applyRatingPlaceholders, DEFAULT_PROMPT_MESSAGE, DEFAULT_THANK_YOU_MESSAGE };
