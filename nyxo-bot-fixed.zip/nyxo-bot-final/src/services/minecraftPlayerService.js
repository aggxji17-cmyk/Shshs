const MinecraftServer = require('../database/models/MinecraftServer');
const MinecraftPlayerCache = require('../database/models/MinecraftPlayerCache');

/** All registered servers (any server that has ever heartbeat-ed in), newest name first. */
async function listServers() {
  return MinecraftServer.find({}).sort({ name: 1 }).lean();
}

async function getServerById(serverId) {
  if (!serverId) return null;
  return MinecraftServer.findById(serverId).lean();
}

async function getPlayerCache(minecraftUuid) {
  if (!minecraftUuid) return null;
  return MinecraftPlayerCache.findById(minecraftUuid).lean();
}

/**
 * Builds an honest online/last-login/last-logout summary from a player
 * cache document (see MinecraftPlayerCache.js for why `lastSeenAt` alone
 * can only ever confirm one side of that pair today).
 *
 * @param {object|null} cache - a MinecraftPlayerCache document, or null if the player has never been seen
 * @param {string|null} [filterServerId] - if given, "online" only counts when they're on this specific server
 */
function buildPresenceInfo(cache, filterServerId = null) {
  if (!cache) {
    return {
      online: false,
      onlineHere: false,
      lastLogin: null,
      lastLogout: null,
      currentServerId: null,
      lastSeenServerId: null,
    };
  }

  const online = Boolean(cache.online);
  const onlineHere = filterServerId ? online && cache.currentServerId === filterServerId : online;

  return {
    online,
    onlineHere,
    // Prefer the dedicated field once a future plugin update provides it;
    // otherwise fall back to the one case we can actually confirm today.
    lastLogin: cache.lastLoginAt ?? (online ? cache.lastSeenAt : null),
    lastLogout: cache.lastLogoutAt ?? (!online ? cache.lastSeenAt : null),
    currentServerId: cache.currentServerId ?? null,
    lastSeenServerId: cache.lastSeenServerId ?? null,
  };
}

module.exports = { listServers, getServerById, getPlayerCache, buildPresenceInfo };
