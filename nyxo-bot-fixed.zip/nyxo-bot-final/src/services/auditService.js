const Case = require('../database/models/Case');

const PAGE_SIZE = 5;
const ACTIONS = ['ban', 'kick', 'timeout', 'warn', 'softban', 'unban'];

const SORT_SPECS = {
  newest: { caseId: -1 },
  oldest: { caseId: 1 },
  action: { action: 1, caseId: -1 },
};

function resolveSort(sort) {
  return SORT_SPECS[sort] || SORT_SPECS.newest;
}

/**
 * Turns a range keyword ('today' | '7d' | '30d' | 'all') into a Mongo
 * filter on `createdAt`. 'all' (or anything unrecognized) applies no
 * filter at all.
 */
function rangeFilter(range) {
  const now = new Date();
  let start = null;

  if (range === 'today') {
    start = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
  } else if (range === '7d') {
    start = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
  } else if (range === '30d') {
    start = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
  }

  return start ? { createdAt: { $gte: start } } : {};
}

/**
 * Per-action counts + grand total for any Case filter, computed with a
 * single indexed aggregation ($match -> $group) instead of pulling
 * documents into Node and counting them by hand - this is what keeps
 * /modhistory and /userinfo's stats fast even with thousands of Cases.
 */
async function getStats(match) {
  const rows = await Case.aggregate([{ $match: match }, { $group: { _id: '$action', count: { $sum: 1 } } }]);

  const stats = Object.fromEntries(ACTIONS.map((a) => [a, 0]));
  let total = 0;
  for (const row of rows) {
    if (row._id in stats) stats[row._id] = row.count;
    total += row.count;
  }

  return { stats, total };
}

/** Paginated, sorted Case list for any filter - the one place list queries live. */
async function getHistory(match, { sort = 'newest', page = 1, pageSize = PAGE_SIZE } = {}) {
  const safePage = Math.max(page, 1);
  const skip = (safePage - 1) * pageSize;

  const [cases, total] = await Promise.all([
    Case.find(match).sort(resolveSort(sort)).skip(skip).limit(pageSize),
    Case.countDocuments(match),
  ]);

  return { cases, total, page: safePage, totalPages: Math.max(Math.ceil(total / pageSize), 1) };
}

/** Per-action + total counts for one moderator, optionally scoped to a date range. Backs /modhistory's stats block. */
async function getModeratorStats(guildId, moderatorId, range = 'all') {
  return getStats({ guildId, moderatorId, ...rangeFilter(range) });
}

/** Paginated, sorted list of every Case a moderator has created. Backs /modhistory's list + pagination. */
async function getModeratorHistory(guildId, moderatorId, opts = {}) {
  return getHistory({ guildId, moderatorId, ...rangeFilter(opts.range || 'all') }, opts);
}

/** Per-action + total counts for one member's punishment record. Backs /userinfo's stats block. */
async function getUserStats(guildId, targetId, range = 'all') {
  return getStats({ guildId, targetId, ...rangeFilter(range) });
}

/** Paginated, sorted list of every Case filed against one member. Backs /userinfo's full-record button + pagination. */
async function getUserHistory(guildId, targetId, opts = {}) {
  return getHistory({ guildId, targetId, ...rangeFilter(opts.range || 'all') }, opts);
}

/**
 * Paginated, sorted, filterable list of every Case in a guild - the
 * unified moderation log stream. Backs the dashboard's "Moderation Logs"
 * page (dashboard/routes/api.js), which is a read-only, guild-wide view
 * over the same Case collection /modhistory and /userinfo already query -
 * scoped down here by optional moderatorId/targetId/action instead of
 * requiring one of them like those two commands do.
 */
async function getGuildHistory(guildId, { moderatorId, targetId, action, range = 'all', sort = 'newest', page = 1, pageSize = PAGE_SIZE } = {}) {
  const match = { guildId, ...rangeFilter(range) };
  if (moderatorId) match.moderatorId = moderatorId;
  if (targetId) match.targetId = targetId;
  if (action) match.action = action;
  return getHistory(match, { sort, page, pageSize });
}

module.exports = {
  PAGE_SIZE,
  ACTIONS,
  getModeratorStats,
  getModeratorHistory,
  getUserStats,
  getUserHistory,
  getGuildHistory,
};
