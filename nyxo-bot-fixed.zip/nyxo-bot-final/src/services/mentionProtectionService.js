const { PermissionFlagsBits } = require('discord.js');

/**
 * True if `member` is allowed to mention a protected user: they manage the
 * guild (same bar used everywhere else - Administrator/ManageGuild/the
 * configured adminRoleId), or they hold one of the configured bypass roles.
 */
function hasBypass(member, guildConfig) {
  if (!member) return false;
  if (member.permissions.has(PermissionFlagsBits.Administrator)) return true;
  if (member.permissions.has(PermissionFlagsBits.ManageGuild)) return true;
  if (guildConfig.adminRoleId && member.roles.cache.has(guildConfig.adminRoleId)) return true;

  const bypassRoleIds = guildConfig.mentionProtection?.bypassRoleIds || [];
  return bypassRoleIds.some((roleId) => member.roles.cache.has(roleId));
}

/** True if this message @mentions at least one currently-protected user. */
function mentionsProtectedUser(message, guildConfig) {
  const protectedIds = guildConfig.mentionProtection?.protectedUserIds || [];
  if (!protectedIds.length || !message.mentions.users.size) return false;
  return [...message.mentions.users.keys()].some((id) => protectedIds.includes(id));
}

module.exports = { hasBypass, mentionsProtectedUser };
