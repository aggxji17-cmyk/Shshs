const { runCommand, CommandTimeoutError } = require('./commandQueueService');

/**
 * /inv's data layer: asks the target Minecraft server (via NovaBridge's
 * command queue, see commandQueueService.js) for a player's live
 * inventory, and normalizes the response into the shape
 * services/inventoryRenderService.js expects.
 *
 * =========================================================================
 * CONTRACT for the future NovaBridge "get_inventory" CommandHandler
 * (this is the piece that still needs to be added on the plugin side -
 * see NovaBridge/.../queue/BuiltinCommandHandlers.java for where a
 * `registry.register("get_inventory", ...)` call belongs; nothing on the
 * plugin has been touched by this task).
 * =========================================================================
 *
 * Request (`payload` on the ServerCommand document):
 *   { "minecraftUuid": "<uuid-with-dashes>" }
 *
 * Success `result`:
 *   {
 *     "online": true,                 // was the player online THIS server when read
 *     "main": [ ItemSlot|null, ... ], // exactly 36 entries: index 0-8 hotbar, 9-35 main inventory
 *     "armor": {
 *       "helmet": ItemSlot|null,
 *       "chestplate": ItemSlot|null,
 *       "leggings": ItemSlot|null,
 *       "boots": ItemSlot|null
 *     },
 *     "offhand": ItemSlot|null
 *   }
 *
 * Where an `ItemSlot` is:
 *   {
 *     "id": "minecraft:diamond_sword",  // namespaced item id (Material key, lowercase)
 *     "count": 1,                        // stack size
 *     "damage": 12,                      // OPTIONAL: current durability damage, for damage-bar rendering
 *     "maxDamage": 1561,                 // OPTIONAL: max durability, paired with `damage`
 *     "enchanted": true,                 // OPTIONAL: adds the enchantment glint overlay
 *     "customName": "Excalibur"          // OPTIONAL: shown in the tooltip-less renderer as-is, not used yet
 *   }
 *
 * Failure: standard queue failure (`status: "failed"`, `result: { error }`)
 * - e.g. player not found, or not online on that server.
 *
 * If the player is offline everywhere, this call is expected to fail
 * fast with a clear `error` message rather than time out - the plugin
 * can only read a live Bukkit Inventory, not an offline player's NBT,
 * without extra work that is explicitly out of scope for the first
 * version of this handler.
 * =========================================================================
 */

const REQUEST_TIMEOUT_MS = 8000;

class InventoryUnavailableError extends Error {
  constructor(message) {
    super(message);
    this.name = 'InventoryUnavailableError';
  }
}

/**
 * @param {string} targetServerId - NovaBridge server.id to query
 * @param {string} minecraftUuid
 * @param {string|null} [requestedBy] - e.g. `discord:${interaction.user.id}`
 * @returns {Promise<{ online: boolean, main: (object|null)[], armor: object, offhand: object|null }>}
 * @throws {InventoryUnavailableError} on failure or timeout, with a message safe to show the user
 */
async function requestInventorySnapshot(targetServerId, minecraftUuid, requestedBy = null) {
  let outcome;
  try {
    outcome = await runCommand(
      targetServerId,
      'get_inventory',
      { minecraftUuid },
      { requestedBy, timeoutMs: REQUEST_TIMEOUT_MS }
    );
  } catch (err) {
    if (err instanceof CommandTimeoutError) {
      throw new InventoryUnavailableError(
        'لم يستجب السيرفر في الوقت المناسب. تأكد أن اللاعب متصل حالياً وأن السيرفر يعمل.'
      );
    }
    throw err;
  }

  if (outcome.status === 'failed') {
    const reason = outcome.result?.error || 'تعذر جلب الإنفنتوري من السيرفر.';
    throw new InventoryUnavailableError(reason);
  }

  return normalizeSnapshot(outcome.result);
}

/**
 * Defensive normalization so a slightly-off plugin response (missing
 * field, wrong array length) degrades to "empty slot" instead of
 * crashing the renderer. Keeps inventoryRenderService.js able to assume
 * a fully-shaped object always.
 */
function normalizeSnapshot(raw) {
  const safeItem = (item) => {
    if (!item || typeof item !== 'object' || !item.id) return null;
    return {
      id: String(item.id),
      count: Number.isFinite(item.count) ? item.count : 1,
      damage: Number.isFinite(item.damage) ? item.damage : null,
      maxDamage: Number.isFinite(item.maxDamage) ? item.maxDamage : null,
      enchanted: Boolean(item.enchanted),
      customName: typeof item.customName === 'string' ? item.customName : null,
    };
  };

  const rawMain = Array.isArray(raw?.main) ? raw.main : [];
  const main = Array.from({ length: 36 }, (_, i) => safeItem(rawMain[i]));

  const rawArmor = raw?.armor || {};
  const armor = {
    helmet: safeItem(rawArmor.helmet),
    chestplate: safeItem(rawArmor.chestplate),
    leggings: safeItem(rawArmor.leggings),
    boots: safeItem(rawArmor.boots),
  };

  return {
    online: Boolean(raw?.online),
    main,
    armor,
    offhand: safeItem(raw?.offhand),
  };
}

module.exports = { requestInventorySnapshot, InventoryUnavailableError };
