const { Kazagumo, Plugins } = require('kazagumo');
const { Connectors } = require('shoukaku');
const { config } = require('../config/config');
const logger = require('../utils/logger');

let kazagumo = null;

/**
 * Node list for Kazagumo/Shoukaku, built from the LAVALINK_* variables
 * in .env (see /lavalink/README_LAVALINK_AR.md for how to stand up the
 * server those variables point to).
 */
function buildNodes() {
  if (!config.lavalink.host || !config.lavalink.password) {
    return [];
  }

  return [
    {
      name: 'main',
      url: `${config.lavalink.host}:${config.lavalink.port}`,
      auth: config.lavalink.password,
      secure: config.lavalink.secure,
    },
  ];
}

/**
 * Creates the singleton Kazagumo instance bound to the given discord.js
 * client. discord-player is the primary music engine (see
 * services/musicService.js); Kazagumo/Lavalink is only ever used as a
 * fallback to *continue* a session that already lives there (see the
 * engine-selection logic in commands/music/play.js) - it is never chosen
 * for a brand-new /play request, even when Lavalink is configured.
 * A few commands (/247, /playlist play, /history play, /favorites play)
 * are discord-player-only and explicitly refuse to run while a Kazagumo
 * player already owns the guild's session, instead of risking a second
 * voice connection - see the guildIsOnKazagumo() guard used there.
 *
 * Safe to call even when Lavalink isn't configured yet: it just logs a
 * warning and returns null, same as before this task, so bots that
 * haven't filled in LAVALINK_HOST/LAVALINK_PASSWORD see no behavior
 * change at all.
 */
function initKazagumo(client) {
  const nodes = buildNodes();

  if (nodes.length === 0) {
    logger.warn(
      'Kazagumo: no LAVALINK_HOST/LAVALINK_PASSWORD set in .env - migrated music commands will fall back to the old discord-player path.'
    );
    return null;
  }

  kazagumo = new Kazagumo(
    {
      defaultSearchEngine: 'youtube',
      send: (guildId, payload) => {
        const guild = client.guilds.cache.get(guildId);
        if (guild) guild.shard.send(payload);
      },
    },
    new Connectors.DiscordJS(client),
    nodes
  );

  kazagumo.shoukaku.on('error', (name, error) => logger.error(`Kazagumo node "${name}" error: ${error?.stack || error}`));
  kazagumo.shoukaku.on('close', (name, code, reason) => logger.warn(`Kazagumo node "${name}" closed: ${code} ${reason || ''}`));
  kazagumo.shoukaku.on('disconnect', (name) => logger.warn(`Kazagumo node "${name}" disconnected.`));
  kazagumo.shoukaku.on('ready', (name) => logger.success(`Kazagumo node "${name}" connected and ready.`));

  return kazagumo;
}

/**
 * Returns the singleton Kazagumo instance, or null if initKazagumo()
 * hasn't run yet (not configured, or index.js hasn't started it).
 * Migrated commands must null-check this and fall back to the
 * discord-player path when it's null.
 */
function getKazagumo() {
  return kazagumo;
}

/**
 * True if this guild's active music session is already owned by Kazagumo.
 * Bug fix (Task 6): commands/music/247.js, playlist.js, history.js and
 * favorites.js only know about discord-player's queue and previously
 * called player.play()/nodes.create() unconditionally. If the guild's
 * live session was actually a Kazagumo player (Lavalink configured, no
 * discord-player queue for that guild), this created a SECOND, separate
 * voice connection into the same channel - duplicate/garbled audio and
 * two engines both believing they own the session. Those commands now
 * call this first and decline with a clear message instead.
 */
function guildIsOnKazagumo(guildId) {
  return Boolean(kazagumo?.players.get(guildId));
}

module.exports = { initKazagumo, getKazagumo, guildIsOnKazagumo };
