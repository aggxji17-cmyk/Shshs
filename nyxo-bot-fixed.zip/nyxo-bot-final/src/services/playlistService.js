const { useMainPlayer } = require('discord-player');
const Playlist = require('../database/models/Playlist');

const MAX_PLAYLISTS_PER_USER = 25;
const MAX_TRACKS_PER_PLAYLIST = 200;

function keyOf(name) {
  return String(name).trim().toLowerCase();
}

async function getUserPlaylists(userId) {
  return Playlist.find({ userId }).sort({ updatedAt: -1 });
}

async function getPlaylist(userId, name) {
  return Playlist.findOne({ userId, nameKey: keyOf(name) });
}

async function createPlaylist(userId, name) {
  const trimmed = String(name).trim();
  const count = await Playlist.countDocuments({ userId });
  if (count >= MAX_PLAYLISTS_PER_USER) {
    return { error: `You already have ${MAX_PLAYLISTS_PER_USER} playlists, which is the limit. Delete one first.` };
  }

  const existing = await getPlaylist(userId, trimmed);
  if (existing) {
    return { error: `You already have a playlist named **${existing.name}**.` };
  }

  const playlist = await Playlist.create({ userId, name: trimmed, nameKey: keyOf(trimmed), tracks: [] });
  return { playlist };
}

async function deletePlaylist(userId, name) {
  const playlist = await getPlaylist(userId, name);
  if (!playlist) return { error: `No playlist named **${name}** found.` };
  await playlist.deleteOne();
  return { playlist };
}

/**
 * Resolves a free-text query (or direct link) to a single discord-player
 * Track via the same search the bot uses for /play, without joining a
 * voice channel or touching any guild queue.
 */
async function searchTrack(query, requestedBy) {
  const player = useMainPlayer();
  const result = await player.search(query, { requestedBy });
  return result?.tracks?.[0] || null;
}

async function addTrack(userId, name, query, requestedBy) {
  const playlist = await getPlaylist(userId, name);
  if (!playlist) return { error: `No playlist named **${name}** found.` };
  if (playlist.tracks.length >= MAX_TRACKS_PER_PLAYLIST) {
    return { error: `**${playlist.name}** already has ${MAX_TRACKS_PER_PLAYLIST} tracks, which is the limit.` };
  }

  const track = await searchTrack(query, requestedBy);
  if (!track) return { error: `Couldn't find anything for **${query}**.` };

  playlist.tracks.push({
    title: track.title,
    url: track.url,
    duration: track.duration || null,
    thumbnail: track.thumbnail || null,
    author: track.author || null,
  });
  await playlist.save();

  return { playlist, track };
}

async function removeTrack(userId, name, index) {
  const playlist = await getPlaylist(userId, name);
  if (!playlist) return { error: `No playlist named **${name}** found.` };
  if (index < 0 || index >= playlist.tracks.length) {
    return { error: `**${playlist.name}** doesn't have a track at position ${index + 1}.` };
  }

  const [removed] = playlist.tracks.splice(index, 1);
  await playlist.save();
  return { playlist, removed };
}

module.exports = {
  MAX_PLAYLISTS_PER_USER,
  MAX_TRACKS_PER_PLAYLIST,
  keyOf,
  getUserPlaylists,
  getPlaylist,
  createPlaylist,
  deletePlaylist,
  searchTrack,
  addTrack,
  removeTrack,
};
