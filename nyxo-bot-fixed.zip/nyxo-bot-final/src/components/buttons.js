const { ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const { QueueRepeatMode, useQueue } = require('discord-player');
const { getGuildConfig, resolved } = require('../utils/resolveGuildSettings');
const { successEmbed, errorEmbed, infoEmbed, loadingEmbed, baseEmbed } = require('../utils/embeds');
const { isModerator, isGuildManager } = require('../utils/permissions');
const { requireActiveQueue } = require('../utils/musicChecks');
const { buildMusicControlsRow } = require('../utils/musicControls');
const { buildQueuePage } = require('../utils/musicQueueEmbed');
const { buildCasesPage } = require('../utils/caseEmbed');
const { buildModHistoryPage, buildUserAuditPage } = require('../utils/auditEmbed');
const { sendClosePrompt, reopenTicket, finalizeTicketDeletion } = require('../services/ticketCloseService');
const approvalService = require('../services/approvalService');
const favoritesService = require('../services/favoritesService');
const { findTicketType, buildTicketModal, buildStatusChannelName, deriveBaseChannelName, STATUS_EMOJI } = require('../utils/ticketPanel');
const Ticket = require('../database/models/Ticket');
const Rating = require('../database/models/Rating');
const Suggestion = require('../database/models/Suggestion');
const Giveaway = require('../database/models/Giveaway');
const Poll = require('../database/models/Poll');

module.exports = {
  /** Reveals the Java Minecraft server IP as easily copyable inline code. */
  mc_copyip: async (interaction) => {
    const ip = interaction.message.embeds[0]?.fields?.find((f) => f.name === 'Java IP')?.value;
    await interaction.reply({
      content: `\`${ip?.replace(/`|\s*\(offline\)/g, '') || 'IP unavailable'}\``,
      ephemeral: true,
    });
  },

  /** Reveals the Bedrock Minecraft server IP as easily copyable inline code. Bedrock shares the same host as Java - only the port differs - so this combines the Java IP field's host with the Bedrock Port field's port. */
  mc_copybedrockip: async (interaction) => {
    const fields = interaction.message.embeds[0]?.fields || [];
    const javaIpRaw = fields.find((f) => f.name === 'Java IP')?.value;
    const bedrockPortRaw = fields.find((f) => f.name === 'Bedrock Port')?.value;

    const host = javaIpRaw
      ?.replace(/`|\s*\(offline\)/g, '')
      .split(':')[0];
    const bedrockPort = bedrockPortRaw?.replace(/`|\s*\(offline\)/g, '');

    const address = host && bedrockPort ? `${host}:${bedrockPort}` : null;

    await interaction.reply({
      content: `\`${address || 'IP unavailable'}\``,
      ephemeral: true,
    });
  },

  /** Opens a modal asking the user why they want to open a ticket. customId: ticket_create:<typeId>, one per panel button. */
  ticket_create: async (interaction) => {
    const [, typeId] = interaction.customId.split(':');
    const guildConfig = await getGuildConfig(interaction.guildId);
    const type = findTicketType(guildConfig, typeId);
    await interaction.showModal(buildTicketModal(type));
  },

  ticket_claim: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isModerator(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'الموظفون فقط يمكنهم استلام التذاكر.')], ephemeral: true });
    }

    const ticket = await Ticket.findOne({ channelId: interaction.channelId });
    if (!ticket || ticket.status === 'closed') {
      return interaction.reply({ embeds: [errorEmbed(settings, 'هذه التذكرة غير مفتوحة.')], ephemeral: true });
    }

    ticket.status = 'claimed';
    ticket.claimedBy = interaction.user.id;
    await ticket.save();

    await interaction.reply({
      embeds: [successEmbed(settings, `تم استلام التذكرة بواسطة <@${interaction.user.id}>.`)],
    });
  },

  /** 🔄 Lets staff manually flip a ticket between 🟡 "needs reply" and 🟢 "no action needed", independent of who spoke last. */
  ticket_status_toggle: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isModerator(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'الموظفون فقط يمكنهم تغيير حالة التذكرة.')], ephemeral: true });
    }

    const ticket = await Ticket.findOne({ channelId: interaction.channelId });
    if (!ticket || ticket.status === 'closed') {
      return interaction.reply({ embeds: [errorEmbed(settings, 'هذه التذكرة غير مفتوحة.')], ephemeral: true });
    }

    const nextStatus = ticket.replyStatus === 'needs_reply' ? 'no_action' : 'needs_reply';
    const baseName = ticket.baseChannelName || deriveBaseChannelName(interaction.channel.name);

    ticket.replyStatus = nextStatus;
    ticket.baseChannelName = baseName;
    await ticket.save();

    // Discord only allows a channel to be renamed twice per 10 minutes, so
    // in a very active ticket this can occasionally fail - the database
    // status (used by this button and by messageCreate.js) stays correct
    // either way, and the next successful rename will catch the name up.
    await interaction.channel.setName(buildStatusChannelName(baseName, nextStatus)).catch(() => null);

    await interaction.reply({
      embeds: [successEmbed(settings, `تم تغيير حالة التذكرة إلى ${STATUS_EMOJI[nextStatus]} ${nextStatus === 'needs_reply' ? 'تحتاج رد من الإدارة' : 'لا تحتاج أي إجراء'}.`)],
      ephemeral: true,
    });
  },

  /**
   * "الإغلاق الذكي" - smart close. Closing a ticket no longer deletes it
   * right away: the channel is locked and a 🗑️ delete / 🔓 reopen prompt
   * is posted (see services/ticketCloseService.js), giving the opener a
   * window to change their mind. Actual deletion (archive + logs) only
   * happens via ticket_delete_confirm below, or the auto-delete scheduler.
   */
  ticket_close: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isModerator(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'الموظفون فقط يمكنهم إغلاق التذاكر.')], ephemeral: true });
    }

    const ticket = await Ticket.findOne({ channelId: interaction.channelId });
    if (!ticket || ticket.status === 'closed') {
      return interaction.reply({ embeds: [errorEmbed(settings, 'هذه التذكرة مغلقة بالفعل أو ليست تذكرة.')], ephemeral: true });
    }

    ticket.status = 'closed';
    ticket.closedBy = interaction.user.id;
    ticket.closedAt = new Date();
    // Task 5: keep isOpen in sync with status so the "one active ticket
    // per member" partial unique index (database/models/Ticket.js) frees
    // this member's slot up for a new ticket.
    ticket.isOpen = false;
    await ticket.save();

    await interaction.reply({ embeds: [successEmbed(settings, `تم إغلاق التذكرة بواسطة <@${interaction.user.id}>.`)] });

    await sendClosePrompt(interaction.channel, guildConfig, settings, ticket);
  },

  /** 🗑️ button on the close prompt. customId: ticket_delete_confirm:<ticketId>. Staff-only - builds the transcript archive, logs it, then deletes the channel for good. */
  ticket_delete_confirm: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isModerator(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'الموظفون فقط يمكنهم حذف التذاكر نهائياً.')], ephemeral: true });
    }

    const [, ticketId] = interaction.customId.split(':');
    const ticket = await Ticket.findById(ticketId).catch(() => null);
    if (!ticket || ticket.status !== 'closed' || ticket.channelId !== interaction.channelId) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'هذه التذكرة لم تعد بانتظار الحذف.')], ephemeral: true });
    }

     await interaction.reply({ embeds: [loadingEmbed(settings, 'جارٍ إنشاء أرشيف التذكرة وحذفها نهائياً...')] });
    await interaction.message.edit({ components: [] }).catch(() => null);

    await finalizeTicketDeletion(interaction.client, interaction.guild, guildConfig, settings, ticket, interaction.channel, interaction.user.id);
  },

  /** 🔓 button on the close prompt. customId: ticket_reopen:<ticketId>. Owner or staff only - cancels the auto-delete timer and restores the ticket exactly as it was. */
  ticket_reopen: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    const [, ticketId] = interaction.customId.split(':');
    const ticket = await Ticket.findById(ticketId).catch(() => null);
    if (!ticket || ticket.status !== 'closed' || ticket.channelId !== interaction.channelId) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'هذه التذكرة لم تعد بانتظار الحذف.')], ephemeral: true });
    }

    const isOwner = interaction.user.id === ticket.userId;
    if (!isOwner && !isModerator(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'إعادة فتح التذكرة متاحة فقط لصاحبها أو الإدارة.')], ephemeral: true });
    }

    const result = await reopenTicket(interaction.channel, ticket, interaction.user.id);

    // Task 5: the member already has a different active ticket (opened
    // while this one was closed/pending deletion) - the unique index
    // correctly refused to give them two at once. Leave the 🗑️/🔓 prompt
    // in place so they can still delete this one, or reopen it later
    // once their other ticket is closed.
    if (!result.success) {
      return interaction.reply({
        embeds: [errorEmbed(settings, 'لا يمكن إعادة فتح هذه التذكرة لأن لديك تذكرة أخرى مفتوحة حالياً.')],
        ephemeral: true,
      });
    }

    await interaction.message.edit({ components: [] }).catch(() => null);

    await interaction.reply({ embeds: [successEmbed(settings, `تم إلغاء الحذف وإعادة فتح التذكرة بواسطة <@${interaction.user.id}>. عادت جميع الصلاحيات كما كانت.`)] });
  },

  /** ⭐ button in the post-close rating DM. customId: ticket_rate:<ticketId>:<stars 1-5>. Opens a modal for an optional comment; the rating itself is only recorded on that modal's submission (see modals.js), so a dismissed modal leaves nothing behind and the buttons stay usable. */
  ticket_rate: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    const [, ticketId, starsRaw] = interaction.customId.split(':');
    const stars = Number(starsRaw);

    const ticket = await Ticket.findById(ticketId).catch(() => null);
    if (!ticket) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تعذر العثور على هذه التذكرة.')], ephemeral: true });
    }

    if (interaction.user.id !== ticket.userId) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'هذا التقييم مخصص لصاحب التذكرة فقط.')], ephemeral: true });
    }

    const existing = await Rating.findOne({ ticketId: ticket._id });
    if (existing) {
      return interaction.reply({ embeds: [successEmbed(settings, 'لقد قمت بتقييم هذه التذكرة مسبقاً، شكراً لك!')], ephemeral: true });
    }

    const modal = new ModalBuilder()
      .setCustomId(`ticket_rate_comment_modal:${ticket._id}:${stars}`)
      .setTitle(`تقييمك: ${'⭐'.repeat(stars)}`)
      .addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('comment')
            .setLabel('تعليق (اختياري)')
            .setPlaceholder('شاركنا رأيك في تجربتك مع الدعم الفني...')
            .setStyle(TextInputStyle.Paragraph)
            .setRequired(false)
            .setMaxLength(500)
        )
      );

    await interaction.showModal(modal);
  },

  suggestion_upvote: async (interaction) => await handleSuggestionVote(interaction, 'up'),
  suggestion_downvote: async (interaction) => await handleSuggestionVote(interaction, 'down'),

  /** Grants the configured verification role when a new member clicks Verify. */
  verification_verify: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!guildConfig.verification?.enabled || !guildConfig.verification.roleId) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'Verification is not currently configured.')], ephemeral: true });
    }

    if (interaction.member.roles.cache.has(guildConfig.verification.roleId)) {
      return interaction.reply({ embeds: [infoEmbed(settings, 'You are already verified.')], ephemeral: true });
    }

    await interaction.member.roles.add(guildConfig.verification.roleId).catch(() => null);
    return interaction.reply({ embeds: [successEmbed(settings, 'You have been verified! Welcome to the server.')], ephemeral: true });
  },

  /**
   * Task 4 (Race Condition fix): the old findOne -> mutate participantIds
   * in JS -> save() pattern let two clicks arriving at nearly the same
   * moment (even from different members) both read the same array,
   * mutate their own in-memory copy, then overwrite each other on save -
   * a lost update that could silently drop another member's entry, or
   * throw a VersionError from Mongoose's optimistic concurrency check on
   * the array. This is now two single atomic MongoDB operations (modeled
   * on services/economyService.js's findOneAndUpdate pattern), so the
   * "already joined?" check and the mutation happen together as one
   * database-level step with no room for another request to interleave.
   */
  giveaway_join: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    const messageId = interaction.message.id;
    const userId = interaction.user.id;

    // محاولة أولى ذرّية: أزل العضو إن كان مسجلاً بالفعل (leave). الشرط
    // (العضو ضمن participantIds) والتعديل ($pull) يُنفَّذان معاً داخل
    // نفس عملية findOneAndUpdate في قاعدة البيانات - لا يمكن لأي عملية
    // متزامنة أخرى أن ترى حالة وسيطة أو تسبب lost update هنا.
    const left = await Giveaway.findOneAndUpdate(
      { messageId, ended: false, participantIds: userId },
      { $pull: { participantIds: userId } },
      { new: true }
    );

    if (left) {
      return interaction.reply({ embeds: [infoEmbed(settings, 'You left the giveaway.')], ephemeral: true });
    }

    // لم يكن العضو مسجلاً (أو لا يوجد giveaway نشط بهذا الشكل أصلاً).
    // $addToSet ذرّي وآمن من التكرار بطبيعته: حتى لو نُفِّذ نداءان
    // متزامنان لنفس العضو في نفس اللحظة، لن يُضاف أكثر من إدخال واحد له
    // مهما تداخل التوقيت (لا حاجة لفحص includes() يدوي في الذاكرة).
    const joined = await Giveaway.findOneAndUpdate(
      { messageId, ended: false },
      { $addToSet: { participantIds: userId } },
      { new: true }
    );

    if (!joined) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'This giveaway has ended.')], ephemeral: true });
    }

    return interaction.reply({
      embeds: [successEmbed(settings, `You entered the giveaway! (${joined.participantIds.length} entries so far)`)],
      ephemeral: true,
    });
  },

  poll_vote: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    const [, pollId, optionIndexStr] = interaction.customId.split(':');
    const optionIndex = Number(optionIndexStr);

    const poll = await Poll.findById(pollId);
    if (!poll || poll.ended) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'This poll is no longer active.')], ephemeral: true });
    }

    const userId = interaction.user.id;
    const alreadyVotedThis = poll.options[optionIndex].voterIds.includes(userId);

    if (!poll.allowMultiple) {
      poll.options.forEach((o) => { o.voterIds = o.voterIds.filter((id) => id !== userId); });
    }

    if (alreadyVotedThis) {
      poll.options[optionIndex].voterIds = poll.options[optionIndex].voterIds.filter((id) => id !== userId);
    } else {
      poll.options[optionIndex].voterIds.push(userId);
    }

    await poll.save();

    const totalVotes = poll.options.reduce((sum, o) => sum + o.voterIds.length, 0);
    const embed = baseEmbed(settings)
      .setTitle(`📊 ${poll.question}`)
      .setDescription(poll.options.map((o, i) => `**${i + 1}.** ${o.text} — ${o.voterIds.length} vote(s)`).join('\n'))
      .setFooter({ text: `${totalVotes} total vote(s)` });

    await interaction.update({ embeds: [embed] });
  },

  /** ✅ Approve button on an approval-request embed. customId: approval_approve:<requestId>. */
  approval_approve: async (interaction) => {
    const [, requestId] = interaction.customId.split(':');
    await approvalService.approveRequest(interaction, requestId);
  },

  /** ❌ Reject button on an approval-request embed - opens a modal for the rejection reason. customId: approval_reject:<requestId>. */
  approval_reject: async (interaction) => {
    const [, requestId] = interaction.customId.split(':');
    await interaction.showModal(approvalService.buildRejectModal(requestId));
  },

  /** Previous/Next paging for /cases. customId: cases_page:<targetId>:<page>. */
  cases_page: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isModerator(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'ليس لديك صلاحية استخدام هذا الأمر.')], ephemeral: true });
    }

    const [, targetId, pageStr] = interaction.customId.split(':');
    const page = Math.max(parseInt(pageStr, 10) || 1, 1);

    const target = await interaction.client.users.fetch(targetId).catch(() => null);
    if (!target) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تعذر العثور على هذا المستخدم.')], ephemeral: true });
    }

    const { embed, components } = await buildCasesPage(settings, interaction.guildId, target, page);
    await interaction.update({ embeds: [embed], components });
  },

  /** Previous/Next paging for /modhistory. customId: modhistory_page:<moderatorId>:<range>:<sort>:<page>. */
  modhistory_page: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'ليس لديك صلاحية استخدام هذا الأمر.')], ephemeral: true });
    }

    const [, moderatorId, range, sort, pageStr] = interaction.customId.split(':');
    const page = Math.max(parseInt(pageStr, 10) || 1, 1);

    const moderator = await interaction.client.users.fetch(moderatorId).catch(() => null);
    if (!moderator) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تعذر العثور على هذا المستخدم.')], ephemeral: true });
    }

    const { embed, components } = await buildModHistoryPage(settings, interaction.guildId, moderator, { range, sort, page });
    await interaction.update({ embeds: [embed], components });
  },

  /** Opens, then pages through, a member's full punishment record from /userinfo. customId: userinfo_audit_page:<targetId>:<range>:<sort>:<page>. */
  userinfo_audit_page: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isModerator(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'ليس لديك صلاحية استخدام هذا الأمر.')], ephemeral: true });
    }

    const [, targetId, range, sort, pageStr] = interaction.customId.split(':');
    const page = Math.max(parseInt(pageStr, 10) || 1, 1);

    const target = await interaction.client.users.fetch(targetId).catch(() => null);
    if (!target) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'تعذر العثور على هذا المستخدم.')], ephemeral: true });
    }

    const { embed, components } = await buildUserAuditPage(settings, interaction.guildId, target, { range, sort, page });
    await interaction.update({ embeds: [embed], components });
  },

  /** ⏸️/▶️ toggle on a Now Playing message. Updates the row in place so the icon always reflects current state. */
  music_pauseresume: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    const queue = await requireActiveQueue(interaction, settings);
    if (!queue) return;

    const nowPaused = !queue.node.isPaused();
    queue.node.setPaused(nowPaused);
    if (!nowPaused && queue.metadata) queue.metadata.autoPausedForEmpty = false;
    await interaction.update({ components: buildMusicControlsRow(queue) });
  },

  /** ⏭️ Skip the current track from the Now Playing message. */
  music_skip: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    const queue = await requireActiveQueue(interaction, settings);
    if (!queue) return;

    const skipped = queue.currentTrack;
    queue.node.skip();
    await interaction.reply({
      embeds: [successEmbed(settings, `⏭️ Skipped **${skipped.title}** — <@${interaction.user.id}>`)],
      ephemeral: true,
    });
  },

  /** ⏹️ Stop playback, clear the queue, and disable the buttons on the message they were clicked from. */
  music_stop: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    const queue = await requireActiveQueue(interaction, settings);
    if (!queue) return;

    queue.delete();
    await interaction.update({
      embeds: [successEmbed(settings, `⏹️ Playback stopped and queue cleared — <@${interaction.user.id}>`)],
      components: [],
    });
  },

  /** 🔀 Shuffle the upcoming tracks from the Now Playing message. */
  music_shuffle: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    const queue = await requireActiveQueue(interaction, settings);
    if (!queue) return;

    if (queue.tracks.toArray().length < 2) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'Not enough tracks in the queue to shuffle.')], ephemeral: true });
    }

    queue.tracks.shuffle();
    await interaction.reply({ embeds: [successEmbed(settings, `🔀 Queue shuffled — <@${interaction.user.id}>`)], ephemeral: true });
  },

  /** 🔁 Cycle Off → Track → Queue → Off from the Now Playing message, and re-highlight the button to match. */
  music_loop: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    const queue = await requireActiveQueue(interaction, settings);
    if (!queue) return;

    const CYCLE = [QueueRepeatMode.OFF, QueueRepeatMode.TRACK, QueueRepeatMode.QUEUE];
    const nextMode = CYCLE[(CYCLE.indexOf(queue.repeatMode) + 1) % CYCLE.length];
    const LABELS = { [QueueRepeatMode.OFF]: 'disabled', [QueueRepeatMode.TRACK]: 'looping the track', [QueueRepeatMode.QUEUE]: 'looping the queue' };

    queue.setRepeatMode(nextMode);
    await interaction.reply({ embeds: [successEmbed(settings, `🔁 Loop mode is now **${LABELS[nextMode]}**.`)], ephemeral: true });

    await interaction.message.edit({ components: buildMusicControlsRow(queue) }).catch(() => null);
  },

  /** ◀️/▶️ Previous/Next page on a /queue message. customId: music_queue_page:<page>. View-only, so no voice-channel check. */
  music_queue_page: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    const queue = useQueue(interaction.guildId);
    if (!queue || !queue.currentTrack) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'Nothing is playing right now.')], ephemeral: true });
    }

    const [, pageStr] = interaction.customId.split(':');
    const page = Math.max(parseInt(pageStr, 10) || 1, 1);

    const { embed, components } = buildQueuePage(queue, settings, page);
    await interaction.update({ embeds: [embed], components });
  },

  /** 🗑️ Clear Queue button on a /queue message. Leaves the currently playing track untouched. */
  music_queue_clear: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    const queue = await requireActiveQueue(interaction, settings);
    if (!queue) return;

    queue.tracks.clear();
    const { embed, components } = buildQueuePage(queue, settings, 1);
    await interaction.update({ embeds: [embed], components });
  },

  /** 🔄 Toggle autoplay (plays similar tracks once the queue ends) from the Now Playing message. Shares the same repeatMode field as /loop, so it's mutually exclusive with track/queue looping. */
  music_autoplay: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    const queue = await requireActiveQueue(interaction, settings);
    if (!queue) return;

    const enabling = queue.repeatMode !== QueueRepeatMode.AUTOPLAY;
    queue.setRepeatMode(enabling ? QueueRepeatMode.AUTOPLAY : QueueRepeatMode.OFF);

    await interaction.reply({
      embeds: [
        successEmbed(
          settings,
          enabling
            ? '🔄 Autoplay is now **enabled** — similar tracks will play when the queue ends.'
            : '🔄 Autoplay is now **disabled**.'
        ),
      ],
      ephemeral: true,
    });

    await interaction.message.edit({ components: buildMusicControlsRow(queue) }).catch(() => null);
  },

  /** ❤️ Adds the currently playing track to the clicking user's personal favorites from the Now Playing message. View-only like music_queue_page - anyone can favorite a song for themselves without needing to be in the voice channel. */
  music_favorite: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    const queue = useQueue(interaction.guildId);
    if (!queue || !queue.currentTrack) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'Nothing is playing right now.')], ephemeral: true });
    }

    const trackData = favoritesService.toTrackData(queue.currentTrack);
    const { track, error } = await favoritesService.addTrackData(interaction.user.id, trackData);
    if (error) {
      return interaction.reply({ embeds: [errorEmbed(settings, error)], ephemeral: true });
    }

    await interaction.reply({ embeds: [successEmbed(settings, `❤️ Added **${track.title}** to your favorites.`)], ephemeral: true });
  },
};

async function handleSuggestionVote(interaction, direction) {
  const guildConfig = await getGuildConfig(interaction.guildId);
  const settings = resolved(guildConfig);

  const suggestion = await Suggestion.findOne({ messageId: interaction.message.id });
  if (!suggestion) {
    return interaction.reply({ embeds: [errorEmbed(settings, 'Suggestion record not found.')], ephemeral: true });
  }

  suggestion.upvotes = suggestion.upvotes.filter((id) => id !== interaction.user.id);
  suggestion.downvotes = suggestion.downvotes.filter((id) => id !== interaction.user.id);

  if (direction === 'up') suggestion.upvotes.push(interaction.user.id);
  else suggestion.downvotes.push(interaction.user.id);

  await suggestion.save();

  const embed = baseEmbed(settings)
    .setAuthor({ name: 'Suggestion' })
    .setDescription(suggestion.content)
    .addFields(
      { name: '👍 Upvotes', value: `${suggestion.upvotes.length}`, inline: true },
      { name: '👎 Downvotes', value: `${suggestion.downvotes.length}`, inline: true }
    );

  await interaction.update({ embeds: [embed] });
}
