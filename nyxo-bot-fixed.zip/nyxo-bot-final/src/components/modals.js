const { ChannelType, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');
const { getGuildConfig, resolved, invalidateGuildConfig } = require('../utils/resolveGuildSettings');
const { successEmbed, errorEmbed, baseEmbed } = require('../utils/embeds');
const { isModerator } = require('../utils/permissions');
const { applyWarnThresholds } = require('../utils/warnThresholds');
const { sendModerationLog } = require('../utils/moderationLogService');
const { createCase } = require('../services/caseService');
const { findTicketType, resolveTypeTargets, resolveChannelName, resolveWelcomeMessage, buildStatusChannelName } = require('../utils/ticketPanel');
const { postRatingResult, DEFAULT_THANK_YOU_MESSAGE } = require('../services/ratingService');
const Ticket = require('../database/models/Ticket');
const Rating = require('../database/models/Rating');
const Warn = require('../database/models/Warn');
const GuildConfig = require('../database/models/GuildConfig');
const approvalService = require('../services/approvalService');

const HEX_COLOR_RE = /^#?[0-9a-fA-F]{6}$/;
const DUPLICATE_KEY_ERROR_CODE = 11000;

/**
 * Task 5 (Race Condition fix): atomically claims the next ticket number
 * for this guild via a direct $inc on GuildConfig.tickets.counter -
 * mirrors nextCaseId in services/caseService.js. This replaces the old
 * `const ticketNumber = tickets.counter + 1; ...; guildConfig.tickets.counter
 * = ticketNumber; await guildConfig.save();` pattern, which read/wrote a
 * guildConfig document that resolveGuildSettings.js caches (and can share
 * across several concurrent interactions for the same guild) for up to
 * 30 seconds - a classic findOne-modify-save race that could hand two
 * different tickets the same number under concurrency. $inc here is a
 * single atomic database operation, so no number can ever be issued
 * twice no matter how many tickets open at once. The cache is
 * invalidated afterwards so any other reader of guildConfig.tickets.counter
 * within that window sees the fresh value instead of a stale one.
 */
async function nextTicketNumber(guildId) {
  const updated = await GuildConfig.findOneAndUpdate(
    { guildId },
    { $inc: { 'tickets.counter': 1 } },
    { new: true, upsert: true, setDefaultsOnInsert: true }
  );
  invalidateGuildConfig(guildId);
  return updated.tickets.counter;
}

module.exports = {
  /** Submission of the reason modal opened by the "Quick Warn" user context menu command. customId: ctxwarn_modal:<targetUserId>. Mirrors /warn's own logic exactly. */
  ctxwarn_modal: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isModerator(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You do not have permission to use this command.')], ephemeral: true });
    }

    const [, targetId] = interaction.customId.split(':');
    const target = await interaction.client.users.fetch(targetId).catch(() => null);
    if (!target) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'That user could no longer be found.')], ephemeral: true });
    }

    const reason = interaction.fields.getTextInputValue('reason');

    await Warn.create({ guildId: interaction.guildId, userId: target.id, moderatorId: interaction.user.id, reason });
    const count = await Warn.countDocuments({ guildId: interaction.guildId, userId: target.id });

    const caseDoc = await createCase({
      guildId: interaction.guildId,
      action: 'warn',
      moderatorId: interaction.user.id,
      targetId: target.id,
      reason,
    });

    await interaction.reply({
      embeds: [successEmbed(settings, `**${target.tag}** has been warned (total: ${count}). Reason: ${reason}\nرقم القضية: #${caseDoc.caseId}`)],
      ephemeral: true,
    });
    await target.send({ embeds: [errorEmbed(settings, `You were warned in **${interaction.guild.name}**: ${reason}`)] }).catch(() => null);

    await applyWarnThresholds(interaction.guild, guildConfig, settings, target.id, count);

    await sendModerationLog(interaction.guild, guildConfig, settings, {
      action: 'warn',
      moderator: interaction.user,
      target,
      reason,
      caseId: caseDoc.caseId,
    });
  },

  embedbuilder_modal: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isModerator(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You do not have permission to send embeds.')], ephemeral: true });
    }

    const [, channelId] = interaction.customId.split(':');
    const channel = interaction.guild.channels.cache.get(channelId);
    if (!channel?.isTextBased()) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'That channel is no longer available.')], ephemeral: true });
    }

    const title = interaction.fields.getTextInputValue('title');
    const description = interaction.fields.getTextInputValue('description');
    const colorInput = interaction.fields.getTextInputValue('color');
    const imageUrl = interaction.fields.getTextInputValue('imageUrl');
    const footer = interaction.fields.getTextInputValue('footer');

    if (colorInput && !HEX_COLOR_RE.test(colorInput)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'Color must be a valid hex code, e.g. `#5865F2`.')], ephemeral: true });
    }

    const embed = new EmbedBuilder().setDescription(description).setColor(colorInput || settings.embedColor);
    if (title) embed.setTitle(title);
    if (footer) embed.setFooter({ text: footer });
    if (imageUrl && /^https?:\/\//.test(imageUrl)) embed.setImage(imageUrl);

    await channel.send({ embeds: [embed] }).catch(() => null);
    await interaction.reply({ embeds: [successEmbed(settings, `Embed sent to ${channel}.`)], ephemeral: true });
  },

  /** Submission of the reject-reason modal opened by the ❌ Reject button. customId: approval_reject_modal:<requestId>. */
  approval_reject_modal: async (interaction) => {
    const [, requestId] = interaction.customId.split(':');
    const rejectReason = interaction.fields.getTextInputValue('reject_reason');
    await approvalService.rejectRequestWithReason(interaction, requestId, rejectReason);
  },

  /** Submission of the reason modal opened by a panel button. customId: ticket_create_modal:<typeId>. */
  ticket_create_modal: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    const { tickets } = guildConfig;

    if (!tickets.enabled) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'نظام التذاكر معطّل حالياً.')], ephemeral: true });
    }

    // فحص سريع غير ذرّي - فقط لتحسين تجربة المستخدم في الحالة الشائعة
    // (رد فوري بدون لمس Discord API إن كانت لديه تذكرة مفتوحة أصلاً).
    // هذا الفحص وحده لا يمنع TOCTOU: الحماية الفعلية من التزامن (ضغط
    // مزدوج أو نداءان متزامنان) تأتي من الفهرس الفريد الجزئي
    // uniq_active_ticket_per_member على Ticket (راجع database/models/Ticket.js)
    // الذي يُفرض فعلياً عند محاولة الحفظ أدناه، بعد إنشاء القناة.
    const existing = await Ticket.findOne({ guildId: interaction.guildId, userId: interaction.user.id, isOpen: true });
    if (existing) {
      return interaction.reply({
        embeds: [errorEmbed(settings, `لديك تذكرة مفتوحة بالفعل: <#${existing.channelId}>`)],
        ephemeral: true,
      });
    }

    await interaction.deferReply({ ephemeral: true });

    const [, typeId] = interaction.customId.split(':');
    const type = findTicketType(guildConfig, typeId);
    const { categoryId, mentionRoleId, viewRoleIds } = resolveTypeTargets(guildConfig, type);

    const reason = interaction.fields.getTextInputValue('reason');
    // رقم التذكرة يُحجز ذرّياً الآن (انظر nextTicketNumber أعلاه) بدل
    // tickets.counter + 1 محلياً - يمنع تصادم رقمين متطابقين لتذكرتين
    // مختلفتين فُتحتا في نفس اللحظة.
    const ticketNumber = await nextTicketNumber(interaction.guildId);

    const permissionOverwrites = [
      { id: interaction.guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
      {
        id: interaction.user.id,
        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
      },
      {
        id: interaction.client.user.id,
        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ManageChannels],
      },
      ...viewRoleIds.map((roleId) => ({
        id: roleId,
        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
      })),
    ];

    const channelName = resolveChannelName(type, { user: interaction.user, number: ticketNumber });
    // A brand-new ticket is, by definition, waiting on staff to respond.
    const initialStatus = 'needs_reply';

    const channel = await interaction.guild.channels.create({
      name: buildStatusChannelName(channelName, initialStatus),
      type: ChannelType.GuildText,
      parent: categoryId || undefined,
      permissionOverwrites,
    });

    // الحماية الذرّية الفعلية من التزامن (TOCTOU): محاولة إنشاء وثيقة
    // Ticket تصطدم بالفهرس الفريد الجزئي uniq_active_ticket_per_member
    // إن كان قد سبق لنداء آخر متزامن (double-click أو ضغطتان قريبتان)
    // من نفس العضو أن أنشأ له تذكرة نشطة بين لحظة الفحص أعلاه ولحظة هذا
    // الإنشاء. عند التصادم (كود الخطأ 11000) نتراجع بحذف القناة التي
    // أُنشئت للتو حتى لا يبقى للعضو قناتان مكررتان لتذكرة واحدة فقط
    // يُفترض أن تُقبل.
    try {
      await Ticket.create({
        guildId: interaction.guildId,
        channelId: channel.id,
        userId: interaction.user.id,
        ticketNumber,
        typeId: type.typeId,
        typeLabel: type.label,
        replyStatus: initialStatus,
        baseChannelName: channelName,
      });
    } catch (err) {
      if (err?.code === DUPLICATE_KEY_ERROR_CODE) {
        await channel.delete().catch(() => null);
        const winner = await Ticket.findOne({ guildId: interaction.guildId, userId: interaction.user.id, isOpen: true });
        return interaction.editReply({
          embeds: [
            errorEmbed(
              settings,
              winner ? `لديك تذكرة مفتوحة بالفعل: <#${winner.channelId}>` : 'لديك تذكرة مفتوحة بالفعل.'
            ),
          ],
        });
      }
      throw err;
    }

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('ticket_claim').setLabel('استلام التذكرة').setStyle(ButtonStyle.Primary).setEmoji('🙋'),
      new ButtonBuilder().setCustomId('ticket_status_toggle').setLabel('حالة التذكرة').setStyle(ButtonStyle.Secondary).setEmoji('🔄'),
      new ButtonBuilder().setCustomId('ticket_close').setLabel('إغلاق التذكرة').setStyle(ButtonStyle.Danger).setEmoji('🔒')
    );

    await channel.send({
      content: mentionRoleId ? `<@&${mentionRoleId}> <@${interaction.user.id}>` : `<@${interaction.user.id}>`,
      embeds: [
        baseEmbed(settings)
          .setTitle(`🎫・تذكرة #${ticketNumber}`)
          .setDescription(resolveWelcomeMessage(type, { user: interaction.user, number: ticketNumber }))
          .addFields(
            { name: '📝 تفاصيل الطلب', value: reason },
            { name: '📂 القسم', value: `${type.emoji || ''} ${type.label}`.trim(), inline: true },
            { name: '👤 صاحب التذكرة', value: `<@${interaction.user.id}>`, inline: true }
          ),
      ],
      components: [row],
    });

    await interaction.editReply({ embeds: [successEmbed(settings, `تم إنشاء تذكرتك: ${channel}`)] });
  },

  /** Submission of the optional-comment modal opened by a ⭐ rating button. customId: ticket_rate_comment_modal:<ticketId>:<stars 1-5>. This is the only place a Rating document is actually created - see buttons.js ticket_rate. */
  ticket_rate_comment_modal: async (interaction) => {
    const [, ticketId, starsRaw] = interaction.customId.split(':');
    const stars = Number(starsRaw);

    const ticket = await Ticket.findById(ticketId).catch(() => null);
    if (!ticket) {
      return interaction.reply({ content: '❌ تعذر العثور على هذه التذكرة.', ephemeral: true });
    }

    const guildConfig = await getGuildConfig(ticket.guildId);
    const settings = resolved(guildConfig);

    if (interaction.user.id !== ticket.userId) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'هذا التقييم مخصص لصاحب التذكرة فقط.')], ephemeral: true });
    }

    const rawComment = interaction.fields.getTextInputValue('comment');
    const comment = rawComment && rawComment.trim() ? rawComment.trim() : null;

    const rating = await Rating.create({
      guildId: ticket.guildId,
      ticketId: ticket._id,
      channelId: ticket.channelId,
      ticketNumber: ticket.ticketNumber,
      ticketUserId: ticket.userId,
      staffId: ticket.claimedBy || ticket.closedBy || null,
      stars,
      comment,
      // Duplicate-rating guard: ticketId has a unique index, so a second
      // submission for the same ticket (e.g. two near-simultaneous clicks)
      // fails here instead of creating a second rating.
    }).catch(() => null);

    if (!rating) {
      return interaction.reply({ embeds: [successEmbed(settings, 'لقد قمت بتقييم هذه التذكرة مسبقاً، شكراً لك!')], ephemeral: true });
    }

    const thankYou = (guildConfig.tickets.ratings?.thankYouMessage || DEFAULT_THANK_YOU_MESSAGE).replace(/\\n/g, '\n');

    await interaction.reply({ embeds: [successEmbed(settings, thankYou)] });

    // Disable the star row on the original DM so this ticket can't be
    // rated twice from the same message (the unique index above already
    // guarantees it at the data level - this is just the UI reflecting it).
    if (interaction.message) {
      const disabledRow = new ActionRowBuilder().addComponents(
        interaction.message.components[0].components.map((c) => ButtonBuilder.from(c).setDisabled(true))
      );
      await interaction.message.edit({ components: [disabledRow] }).catch(() => null);
    }

    const guild = interaction.client.guilds.cache.get(ticket.guildId);
    if (guild) await postRatingResult(interaction.client, guild, guildConfig, settings, ticket, rating);
  },
};
