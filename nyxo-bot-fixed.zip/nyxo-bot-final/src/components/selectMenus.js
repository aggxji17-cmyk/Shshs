const { getGuildConfig, resolved } = require('../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../utils/embeds');
const { findTicketType, buildTicketModal } = require('../utils/ticketPanel');

module.exports = {
  /**
   * Panel dropdown used instead of buttons once a server has more ticket
   * types configured than fit as buttons (see utils/ticketPanel.js). Mirrors
   * buttons.js's ticket_create handler exactly - same shared modal builder,
   * just triggered by a select instead of a click. customId:
   * ticket_create_select:<pageIndex> (pageIndex is unused; the chosen type
   * is in interaction.values[0]).
   */
  ticket_create_select: async (interaction) => {
    const typeId = interaction.values[0];
    const guildConfig = await getGuildConfig(interaction.guildId);
    const type = findTicketType(guildConfig, typeId);
    await interaction.showModal(buildTicketModal(type));
  },

  /**
   * Self-assignable role menu. Values are role IDs baked in at panel-creation
   * time (see commands/roles/rolemenu.js). Selecting toggles membership:
   * roles present in the new selection are added, previously-selected panel
   * roles that got deselected are removed.
   */
  rolemenu_select: async (interaction) => {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    const allOptionValues = interaction.component.options.map((o) => o.value);
    const selected = interaction.values;
    const member = interaction.member;

    const toAdd = allOptionValues.filter((id) => selected.includes(id) && !member.roles.cache.has(id));
    const toRemove = allOptionValues.filter((id) => !selected.includes(id) && member.roles.cache.has(id));

    try {
      for (const roleId of toAdd) await member.roles.add(roleId);
      for (const roleId of toRemove) await member.roles.remove(roleId);
    } catch {
      return interaction.reply({
        embeds: [errorEmbed(settings, 'I could not update your roles - check that my role is above the assignable roles.')],
        ephemeral: true,
      });
    }

    await interaction.reply({ embeds: [successEmbed(settings, 'Your roles have been updated.')], ephemeral: true });
  },
};
