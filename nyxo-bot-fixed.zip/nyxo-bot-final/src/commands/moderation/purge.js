const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { isModerator } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('purge')
    .setDescription('Bulk delete recent messages in this channel')
    .setDescriptionLocalizations({ ar: 'حذف عدد من الرسائل الأخيرة في هذه القناة', 'en-US': 'Bulk delete recent messages in this channel' })
    .addIntegerOption((o) => o.setName('amount').setDescription('Number of messages to delete (1-100)').setDescriptionLocalizations({ ar: 'عدد الرسائل المراد حذفها (1-100)', 'en-US': 'Number of messages to delete (1-100)' }).setRequired(true).setMinValue(1).setMaxValue(100))
    .addUserOption((o) => o.setName('user').setDescription('Only delete messages from this user').setDescriptionLocalizations({ ar: 'حذف رسائل هذا المستخدم فقط', 'en-US': 'Only delete messages from this user' }))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isModerator(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You do not have permission to use this command.')], ephemeral: true });
    }

    const amount = interaction.options.getInteger('amount');
    const user = interaction.options.getUser('user');

    await interaction.deferReply({ ephemeral: true });

    const messages = await interaction.channel.messages.fetch({ limit: 100 });
    const filtered = user ? messages.filter((m) => m.author.id === user.id) : messages;
    const toDelete = [...filtered.values()].slice(0, amount);

    const deleted = await interaction.channel.bulkDelete(toDelete, true).catch(() => null);

    await interaction.editReply({
      embeds: [successEmbed(settings, `Deleted ${deleted?.size ?? 0} message(s). (Messages older than 14 days cannot be bulk deleted.)`)],
    });
  },
};
