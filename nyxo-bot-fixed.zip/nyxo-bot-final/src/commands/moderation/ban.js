const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { isModerator } = require('../../utils/permissions');
const { UNLIMITED, getMemberWeeklyBanLimit, countBansThisWeek, recordBan } = require('../../utils/banLimitService');
const { isServerOwner, outranksExecutor } = require('../../utils/moderationGuards');
const { sendModerationLog } = require('../../utils/moderationLogService');
const { createCase } = require('../../services/caseService');
const approvalService = require('../../services/approvalService');

const { safeAutocomplete, reasonChoices } = require('../../utils/autocomplete');
module.exports = {
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Ban a member from the server')
    .setDescriptionLocalizations({ ar: 'حظر عضو من السيرفر', 'en-US': 'Ban a member from the server' })
    .addUserOption((o) => o.setName('user').setDescription('The user to ban').setDescriptionLocalizations({ ar: 'المستخدم المراد حظره', 'en-US': 'The user to ban' }).setRequired(true))
    .addStringOption((o) => o.setName('reason').setDescription('Reason for the ban').setDescriptionLocalizations({ ar: 'سبب الحظر', 'en-US': 'Reason for the ban' }).setAutocomplete(true))
    .addIntegerOption((o) => o.setName('delete_days').setDescription('Days of message history to delete (0-7)').setDescriptionLocalizations({ ar: 'عدد أيام سجل الرسائل المراد حذفها (0-7)', 'en-US': 'Days of message history to delete (0-7)' }).setMinValue(0).setMaxValue(7))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

  autocomplete: safeAutocomplete(async (interaction) => {
    return reasonChoices(interaction.options.getFocused());
  }),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isModerator(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'ليس لديك صلاحية استخدام هذا الأمر.')], ephemeral: true });
    }

    const target = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || 'No reason provided';
    const deleteDays = interaction.options.getInteger('delete_days') || 0;

    // 1) Server owner can never be banned, by anyone.
    if (isServerOwner(interaction.guild, target.id)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'لا يمكن حظر صاحب السيرفر.')], ephemeral: true });
    }

    const member = await interaction.guild.members.fetch(target.id).catch(() => null);

    // 2) Executor can't ban someone whose highest role is above or equal to
    //    their own - unless the executor is the server owner.
    if (outranksExecutor(interaction, member)) {
      return interaction.reply({
        embeds: [errorEmbed(settings, 'لا يمكنك حظر عضو رتبته أعلى من رتبتك أو مساوية لها.')],
        ephemeral: true,
      });
    }

    // 3) Bot can't ban someone above its own top role (discord.js already
    //    folds this - plus permissions/2FA - into `member.bannable`).
    if (member && !member.bannable) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'لا يستطيع البوت حظر هذا العضو (رتبته أعلى من رتبة البوت أو صلاحيات ناقصة).')], ephemeral: true });
    }

    // 4) Weekly per-role ban quota.
    const limit = getMemberWeeklyBanLimit(interaction.member, guildConfig);
    let usedThisWeek = 0;
    if (limit !== UNLIMITED) {
      usedThisWeek = await countBansThisWeek(interaction.guildId, interaction.user.id);
      if (usedThisWeek >= limit) {
        return interaction.reply({
          embeds: [errorEmbed(settings, 'لقد وصلت إلى الحد الأسبوعي المسموح لعمليات الحظر.')],
          ephemeral: true,
        });
      }
    }

    // 5) If bans require approval in this guild, submit a request instead
    //    of running the ban now - a moderator's decision on it is what
    //    actually calls into scheduleService's ban executor later.
    if (approvalService.requiresApproval(guildConfig, 'ban')) {
      return approvalService.createApprovalRequest(interaction, guildConfig, settings, {
        action: 'ban',
        target,
        reason,
        deleteDays,
      });
    }

    await interaction.guild.members.ban(target.id, { deleteMessageSeconds: deleteDays * 86400, reason });
    await recordBan(interaction.guildId, interaction.user.id, target.id, reason);

    const caseDoc = await createCase({
      guildId: interaction.guildId,
      action: 'ban',
      moderatorId: interaction.user.id,
      targetId: target.id,
      reason,
    });

    let description = `**${target.tag}** has been banned. Reason: ${reason}\nرقم القضية: #${caseDoc.caseId}`;
    if (limit !== UNLIMITED) {
      const remaining = Math.max(limit - (usedThisWeek + 1), 0);
      description += `\nالمتبقي لك هذا الأسبوع: ${remaining} من أصل ${limit}.`;
    }

    await interaction.reply({ embeds: [successEmbed(settings, description)] });

    await sendModerationLog(interaction.guild, guildConfig, settings, {
      action: 'ban',
      moderator: interaction.user,
      target,
      reason,
      caseId: caseDoc.caseId,
      weeklyQuota: limit !== UNLIMITED ? { used: usedThisWeek + 1, limit } : null,
    });
  },
};
