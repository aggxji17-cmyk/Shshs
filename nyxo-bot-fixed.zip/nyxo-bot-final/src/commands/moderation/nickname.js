const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { isModerator } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('nickname')
    .setDescription('Set or reset a member\'s nickname')
    .setDescriptionLocalizations({ ar: 'تعيين أو إعادة تعيين الاسم المستعار لعضو', 'en-US': 'Set or reset a member\'s nickname' })
    .addUserOption((o) => o.setName('user').setDescription('The member').setDescriptionLocalizations({ ar: 'العضو', 'en-US': 'The member' }).setRequired(true))
    .addStringOption((o) => o.setName('nickname').setDescription('New nickname (leave empty to reset)').setDescriptionLocalizations({ ar: 'الاسم المستعار الجديد (اتركه فارغاً لإعادة التعيين)', 'en-US': 'New nickname (leave empty to reset)' }).setMaxLength(32))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageNicknames),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isModerator(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You do not have permission to use this command.')], ephemeral: true });
    }

    const target = interaction.options.getUser('user');
    const nickname = interaction.options.getString('nickname') || null;
    const member = await interaction.guild.members.fetch(target.id).catch(() => null);

    if (!member) return interaction.reply({ embeds: [errorEmbed(settings, 'That user is not in this server.')], ephemeral: true });
    if (!member.manageable) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'I cannot manage that member (their highest role may be above mine).')], ephemeral: true });
    }

    await member.setNickname(nickname).catch(() => null);
    await interaction.reply({
      embeds: [successEmbed(settings, nickname ? `Nickname for ${target} set to **${nickname}**.` : `Nickname for ${target} has been reset.`)],
    });
  },
};
