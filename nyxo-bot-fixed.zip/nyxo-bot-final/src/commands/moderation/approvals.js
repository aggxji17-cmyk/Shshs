const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { getGuildConfig, resolved, invalidateGuildConfig } = require('../../utils/resolveGuildSettings');
const { baseEmbed, successEmbed, errorEmbed } = require('../../utils/embeds');
const { isModerator, isGuildManager } = require('../../utils/permissions');
const { ACTION_LABELS } = require('../../utils/caseLabels');
const approvalService = require('../../services/approvalService');

const STATUS_EMOJI = { Pending: '🕓', Approved: '✅', Rejected: '❌', Expired: '⏰', Cancelled: '🚫' };

module.exports = {
  data: new SlashCommandBuilder()
    .setName('approvals')
    .setDescription('Manage approval-gated moderation requests')
    .setDescriptionLocalizations({ ar: 'إدارة طلبات الإشراف التي تتطلب موافقة', 'en-US': 'Manage approval-gated moderation requests' })
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addSubcommand((s) =>
      s
        .setName('list')
        .setDescription('List approval requests for this server')
      .setDescriptionLocalizations({ ar: 'عرض طلبات الموافقة لهذا السيرفر', 'en-US': 'List approval requests for this server' })
        .addStringOption((o) =>
          o
            .setName('status')
            .setDescription('Filter by status (default: Pending)').setDescriptionLocalizations({ ar: 'التصفية حسب الحالة (افتراضياً: معلّق)', 'en-US': 'Filter by status (default: Pending)' })
            .addChoices(
              { name: 'Pending', value: 'Pending' },
              { name: 'Approved', value: 'Approved' },
              { name: 'Rejected', value: 'Rejected' },
              { name: 'Expired', value: 'Expired' },
              { name: 'Cancelled', value: 'Cancelled' },
              { name: 'All', value: 'All' }
            )
        )
        .addIntegerOption((o) => o.setName('page').setDescription('Page number').setDescriptionLocalizations({ ar: 'رقم الصفحة', 'en-US': 'Page number' }).setMinValue(1))
    )
    .addSubcommand((s) => s.setName('status').setDescription('Show full detail for one approval request')
      .setDescriptionLocalizations({ ar: 'عرض التفاصيل الكاملة لطلب موافقة واحد', 'en-US': 'Show full detail for one approval request' }).addStringOption((o) => o.setName('id').setDescription('Request ID from /approvals list').setDescriptionLocalizations({ ar: 'معرّف الطلب من /approvals list', 'en-US': 'Request ID from /approvals list' }).setRequired(true)))
    .addSubcommand((s) => s.setName('cancel').setDescription('Cancel a pending approval request')
      .setDescriptionLocalizations({ ar: 'إلغاء طلب موافقة معلّق', 'en-US': 'Cancel a pending approval request' }).addStringOption((o) => o.setName('id').setDescription('Request ID from /approvals list').setDescriptionLocalizations({ ar: 'معرّف الطلب من /approvals list', 'en-US': 'Request ID from /approvals list' }).setRequired(true)))
    .addSubcommand((s) =>
      s
        .setName('setup')
        .setDescription('Configure the approval-gated moderation system')
      .setDescriptionLocalizations({ ar: 'إعداد نظام الإشراف الذي يتطلب موافقة', 'en-US': 'Configure the approval-gated moderation system' })
        .addBooleanOption((o) => o.setName('enabled').setDescription('Turn the approval system on or off').setDescriptionLocalizations({ ar: 'تفعيل أو تعطيل نظام الموافقات', 'en-US': 'Turn the approval system on or off' }))
        .addChannelOption((o) => o.setName('review_channel').setDescription('Channel where requests are posted for review').setDescriptionLocalizations({ ar: 'القناة التي تُنشر فيها الطلبات للمراجعة', 'en-US': 'Channel where requests are posted for review' }).addChannelTypes(ChannelType.GuildText))
        .addStringOption((o) => o.setName('actions').setDescription('Comma-separated list of gated actions, e.g. ban,kick,softban,timeout').setDescriptionLocalizations({ ar: 'قائمة الإجراءات المقيّدة مفصولة بفواصل، مثل ban,kick,softban,timeout', 'en-US': 'Comma-separated list of gated actions, e.g. ban,kick,softban,timeout' }))
        .addIntegerOption((o) => o.setName('expires_after_minutes').setDescription('Minutes before an undecided request auto-expires').setDescriptionLocalizations({ ar: 'الدقائق قبل انتهاء صلاحية الطلب غير المحسوم تلقائياً', 'en-US': 'Minutes before an undecided request auto-expires' }).setMinValue(1))
        .addRoleOption((o) => o.setName('approver_role').setDescription('Add a role allowed to approve/reject (omit to leave any moderator able to)').setDescriptionLocalizations({ ar: 'إضافة رتبة مسموح لها بالموافقة/الرفض (اتركه فارغاً للسماح لأي مشرف)', 'en-US': 'Add a role allowed to approve/reject (omit to leave any moderator able to)' }))
    ),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isModerator(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'ليس لديك صلاحية استخدام هذا الأمر.')], ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();

    if (sub === 'list') {
      const status = interaction.options.getString('status') || 'Pending';
      const page = interaction.options.getInteger('page') || 1;
      const { requests, total, totalPages } = await approvalService.listRequests(interaction.guildId, { status, page });

      if (!requests.length) {
        return interaction.reply({ embeds: [errorEmbed(settings, `لا توجد طلبات موافقة بحالة ${status}.`)], ephemeral: true });
      }

      const embed = baseEmbed(settings)
        .setTitle(`طلبات الموافقة - ${status} (${total})`)
        .setDescription(
          requests
            .map((r) => {
              const label = ACTION_LABELS[r.action] || r.action;
              const caseRef = typeof r.caseId === 'number' ? ` (Case #${r.caseId})` : '';
              return `${STATUS_EMOJI[r.status] || ''} **${label}** على <@${r.targetId}>${caseRef}\nمعرّف: \`${r._id}\` - بواسطة <@${r.moderatorId}>`;
            })
            .join('\n\n')
        )
        .setFooter({ text: `الصفحة ${page} من ${totalPages}` });

      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    if (sub === 'status') {
      const id = interaction.options.getString('id');
      const request = await approvalService.getRequestById(interaction.guildId, id);
      if (!request) {
        return interaction.reply({ embeds: [errorEmbed(settings, 'لم يتم العثور على طلب بهذا المعرّف.')], ephemeral: true });
      }
      return interaction.reply({ embeds: [approvalService.buildRequestEmbed(settings, request)], ephemeral: true });
    }

    if (sub === 'cancel') {
      const id = interaction.options.getString('id');
      return approvalService.cancelRequest(interaction, id);
    }

    if (sub === 'setup') {
      if (!isGuildManager(interaction.member, guildConfig)) {
        return interaction.reply({ embeds: [errorEmbed(settings, 'تحتاج صلاحية Manage Server لتعديل هذا الإعداد.')], ephemeral: true });
      }

      const enabled = interaction.options.getBoolean('enabled');
      const reviewChannel = interaction.options.getChannel('review_channel');
      const actionsRaw = interaction.options.getString('actions');
      const expiresAfterMinutes = interaction.options.getInteger('expires_after_minutes');
      const approverRole = interaction.options.getRole('approver_role');

      if (typeof enabled === 'boolean') guildConfig.approvals.enabled = enabled;
      if (reviewChannel) guildConfig.approvals.reviewChannelId = reviewChannel.id;
      if (typeof expiresAfterMinutes === 'number') guildConfig.approvals.expiresAfterMinutes = expiresAfterMinutes;
      if (actionsRaw) {
        guildConfig.approvals.requiredActions = actionsRaw
          .split(',')
          .map((a) => a.trim().toLowerCase())
          .filter(Boolean);
      }
      if (approverRole && !guildConfig.approvals.approverRoleIds.includes(approverRole.id)) {
        guildConfig.approvals.approverRoleIds.push(approverRole.id);
      }

      await guildConfig.save();
      invalidateGuildConfig(interaction.guildId);

      const summary = [
        `مفعّل: ${guildConfig.approvals.enabled ? '✅' : '❌'}`,
        `روم المراجعة: ${guildConfig.approvals.reviewChannelId ? `<#${guildConfig.approvals.reviewChannelId}>` : 'غير محدد'}`,
        `الأوامر المشمولة: ${guildConfig.approvals.requiredActions.join(', ') || 'لا شيء'}`,
        `مهلة الانتهاء: ${guildConfig.approvals.expiresAfterMinutes} دقيقة`,
        `الأدوار المخوّلة بالبت: ${guildConfig.approvals.approverRoleIds.length ? guildConfig.approvals.approverRoleIds.map((id) => `<@&${id}>`).join(', ') : 'أي مشرف'}`,
      ].join('\n');

      return interaction.reply({ embeds: [successEmbed(settings, `تم تحديث إعدادات نظام الموافقات:\n${summary}`)], ephemeral: true });
    }
  },
};
