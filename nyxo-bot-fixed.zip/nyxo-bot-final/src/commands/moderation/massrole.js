const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');
const { sendModLog } = require('../../utils/modLog');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('massrole')
    .setDescription('Add or remove a role from many members at once')
    .setDescriptionLocalizations({ ar: 'إضافة أو إزالة رتبة من عدة أعضاء دفعة واحدة', 'en-US': 'Add or remove a role from many members at once' })
    .addSubcommand((sc) =>
      sc
        .setName('add')
        .setDescription('Add a role to everyone, or everyone with a given role')
      .setDescriptionLocalizations({ ar: 'إضافة رتبة للجميع، أو لكل من يملك رتبة معينة', 'en-US': 'Add a role to everyone, or everyone with a given role' })
        .addRoleOption((o) => o.setName('role').setDescription('Role to add').setDescriptionLocalizations({ ar: 'الرتبة المراد إضافتها', 'en-US': 'Role to add' }).setRequired(true))
        .addRoleOption((o) => o.setName('has_role').setDescription('Only affect members who already have this role').setDescriptionLocalizations({ ar: 'التأثير فقط على الأعضاء الذين يملكون هذه الرتبة بالفعل', 'en-US': 'Only affect members who already have this role' }))
    )
    .addSubcommand((sc) =>
      sc
        .setName('remove')
        .setDescription('Remove a role from everyone, or everyone with a given role')
      .setDescriptionLocalizations({ ar: 'إزالة رتبة من الجميع، أو من كل من يملك رتبة معينة', 'en-US': 'Remove a role from everyone, or everyone with a given role' })
        .addRoleOption((o) => o.setName('role').setDescription('Role to remove').setDescriptionLocalizations({ ar: 'الرتبة المراد إزالتها', 'en-US': 'Role to remove' }).setRequired(true))
        .addRoleOption((o) => o.setName('has_role').setDescription('Only affect members who already have this role').setDescriptionLocalizations({ ar: 'التأثير فقط على الأعضاء الذين يملكون هذه الرتبة بالفعل', 'en-US': 'Only affect members who already have this role' }))
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You need to be a guild manager to run mass role changes.')], ephemeral: true });
    }

    const role = interaction.options.getRole('role');
    const filterRole = interaction.options.getRole('has_role');
    const isAdd = interaction.options.getSubcommand() === 'add';

    if (!role.editable) {
      return interaction.reply({ embeds: [errorEmbed(settings, `I cannot manage **${role.name}** - it may be above my highest role.`)], ephemeral: true });
    }

    await interaction.deferReply();

    const members = await interaction.guild.members.fetch();
    const targets = members.filter((m) => !m.user.bot && (isAdd ? !m.roles.cache.has(role.id) : m.roles.cache.has(role.id)) && (!filterRole || m.roles.cache.has(filterRole.id)));

    let success = 0;
    let failed = 0;
    for (const member of targets.values()) {
      try {
        if (isAdd) await member.roles.add(role);
        else await member.roles.remove(role);
        success += 1;
      } catch {
        failed += 1;
      }
    }

    await interaction.editReply({
      embeds: [successEmbed(settings, `${isAdd ? 'Added' : 'Removed'} **${role.name}** ${isAdd ? 'to' : 'from'} **${success}** member(s)${failed ? ` (${failed} failed)` : ''}.`)],
    });

    await sendModLog(interaction.guild, guildConfig, settings, {
      title: `Mass Role ${isAdd ? 'Add' : 'Remove'}`,
      fields: [
        { name: 'Role', value: `${role}`, inline: true },
        { name: 'Affected', value: `${success}`, inline: true },
        { name: 'Moderator', value: `${interaction.user}`, inline: true },
      ],
    });
  },
};
