const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { isModerator } = require('../../utils/permissions');
const { isServerOwner, outranksExecutor } = require('../../utils/moderationGuards');
const { sendModerationLog } = require('../../utils/moderationLogService');
const { UNLIMITED, getMemberWeeklySoftbanLimit, countSoftbansThisWeek, recordSoftban } = require('../../utils/softbanLimitService');
const { createCase } = require('../../services/caseService');
const approvalService = require('../../services/approvalService');

const { safeAutocomplete, reasonChoices } = require('../../utils/autocomplete');
module.exports = {
  data: new SlashCommandBuilder()
    .setName('softban')
    .setDescription('Ban then immediately unban a member, to purge their recent messages without a permanent ban')
    .setDescriptionLocalizations({ ar: 'حظر ثم رفع الحظر فوراً عن عضو لحذف رسائله الأخيرة دون حظر دائم', 'en-US': 'Ban then immediately unban a member, to purge their recent messages without a permanent ban' })
    .addUserOption((o) => o.setName('user').setDescription('The user to softban').setDescriptionLocalizations({ ar: 'المستخدم المراد حظره مؤقتاً', 'en-US': 'The user to softban' }).setRequired(true))
    .addStringOption((o) => o.setName('reason').setDescription('Reason for the softban').setDescriptionLocalizations({ ar: 'سبب الحظر المؤقت', 'en-US': 'Reason for the softban' }).setAutocomplete(true))
    .addIntegerOption((o) =>
      o.setName('delete_days').setDescription('Days of message history to delete (0-7, default 1)').setDescriptionLocalizations({ ar: 'عدد أيام سجل الرسائل المراد حذفها (0-7، الافتراضي 1)', 'en-US': 'Days of message history to delete (0-7, default 1)' }).setMinValue(0).setMaxValue(7)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

  autocomplete: safeAutocomplete(async (interaction) => {
    return reasonChoices(interaction.options.getFocused());
  }),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isModerator(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'ليس لديك صلاحية استخدام هذا الأمر.')], ephemeral: true });
    }

    const target = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || 'No reason provided';
    const deleteDays = interaction.options.getInteger('delete_days') ?? 1;

    // 1) Server owner can never be softbanned, by anyone.
    if (isServerOwner(interaction.guild, target.id)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'لا يمكن تنفيذ Softban على صاحب السيرفر.')], ephemeral: true });
    }

    const member = await interaction.guild.members.fetch(target.id).catch(() => null);

    // 2) Executor can't softban someone whose highest role is above or
    //    equal to their own - unless the executor is the server owner.
    if (outranksExecutor(interaction, member)) {
      return interaction.reply({
        embeds: [errorEmbed(settings, 'لا يمكنك تنفيذ Softban على عضو رتبته أعلى من رتبتك أو مساوية لها.')],
        ephemeral: true,
      });
    }

    // 3) Bot needs to be able to ban this member (softban is a ban+unban
    //    under the hood, so the ban-hierarchy check applies the same way).
    if (member && !member.bannable) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'لا يستطيع البوت تنفيذ Softban على هذا العضو (رتبته أعلى من رتبة البوت أو صلاحيات ناقصة).')], ephemeral: true });
    }

    // 4) Weekly per-role softban quota.
    const limit = getMemberWeeklySoftbanLimit(interaction.member, guildConfig);
    let usedThisWeek = 0;
    if (limit !== UNLIMITED) {
      usedThisWeek = await countSoftbansThisWeek(interaction.guildId, interaction.user.id);
      if (usedThisWeek >= limit) {
        return interaction.reply({
          embeds: [errorEmbed(settings, 'لقد وصلت إلى الحد الأسبوعي المسموح لعمليات الـ Softban.')],
          ephemeral: true,
        });
      }
    }

    // 5) If softbans require approval in this guild, submit a request
    //    instead of running it now.
    if (approvalService.requiresApproval(guildConfig, 'softban')) {
      return approvalService.createApprovalRequest(interaction, guildConfig, settings, {
        action: 'softban',
        target,
        reason,
        deleteDays,
      });
    }

    // Ban (which purges `deleteDays` worth of messages via Discord's API),
    // then unban right away - the member is never actually kept banned.
    await interaction.guild.members.ban(target.id, { deleteMessageSeconds: deleteDays * 86400, reason });
    await interaction.guild.members.unban(target.id, 'Softban - automatic unban').catch(() => null);
    await recordSoftban(interaction.guildId, interaction.user.id, target.id, reason);

    const caseDoc = await createCase({
      guildId: interaction.guildId,
      action: 'softban',
      moderatorId: interaction.user.id,
      targetId: target.id,
      reason,
    });

    let description = `تم تنفيذ Softban على **${target.tag}** (تم حذف رسائل ${deleteDays} يوم/أيام). السبب: ${reason}\nرقم القضية: #${caseDoc.caseId}`;
    if (limit !== UNLIMITED) {
      const remaining = Math.max(limit - (usedThisWeek + 1), 0);
      description += `\nالمتبقي لك هذا الأسبوع: ${remaining} من أصل ${limit}.`;
    }

    await interaction.reply({ embeds: [successEmbed(settings, description)] });

    await sendModerationLog(interaction.guild, guildConfig, settings, {
      action: 'softban',
      moderator: interaction.user,
      target,
      reason,
      caseId: caseDoc.caseId,
      weeklyQuota: limit !== UNLIMITED ? { used: usedThisWeek + 1, limit } : null,
    });
  },
};
