const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved, invalidateGuildConfig } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed, infoEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');
const { safeAutocomplete, commandNameChoices } = require('../../utils/autocomplete');
const { PROTECTED_COMMANDS, getOrCreateEntry, addUnique, removeIfPresent } = require('../../utils/commandPermissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('permissions')
    .setDescription('Configure per-command role/user/channel permission overrides')
    .setDescriptionLocalizations({ ar: 'إعداد صلاحيات مخصصة لكل أمر (أدوار/أعضاء/قنوات)', 'en-US': 'Configure per-command role/user/channel permission overrides' })
    .addSubcommandGroup((g) =>
      g
        .setName('allow')
        .setDescription('Restrict a command to specific roles/users (only they may use it)')
        .setDescriptionLocalizations({ ar: 'قصر أمر على أدوار/أعضاء محددين (هم فقط من يستطيع استخدامه)', 'en-US': 'Restrict a command to specific roles/users (only they may use it)' })
        .addSubcommand((s) =>
          s
            .setName('role')
            .setDescription('Allow a role to use this command')
            .setDescriptionLocalizations({ ar: 'السماح لدور باستخدام هذا الأمر', 'en-US': 'Allow a role to use this command' })
            .addStringOption((o) => o.setName('command').setDescription('Command name, e.g. ban').setDescriptionLocalizations({ ar: 'اسم الأمر، مثل ban', 'en-US': 'Command name, e.g. ban' }).setRequired(true).setAutocomplete(true))
            .addRoleOption((o) => o.setName('role').setDescription('Role to allow').setDescriptionLocalizations({ ar: 'الدور المراد السماح له', 'en-US': 'Role to allow' }).setRequired(true))
        )
        .addSubcommand((s) =>
          s
            .setName('user')
            .setDescription('Allow a specific user to use this command')
            .setDescriptionLocalizations({ ar: 'السماح لعضو معين باستخدام هذا الأمر', 'en-US': 'Allow a specific user to use this command' })
            .addStringOption((o) => o.setName('command').setDescription('Command name, e.g. ban').setDescriptionLocalizations({ ar: 'اسم الأمر، مثل ban', 'en-US': 'Command name, e.g. ban' }).setRequired(true).setAutocomplete(true))
            .addUserOption((o) => o.setName('user').setDescription('User to allow').setDescriptionLocalizations({ ar: 'العضو المراد السماح له', 'en-US': 'User to allow' }).setRequired(true))
        )
        .addSubcommand((s) =>
          s
            .setName('channel')
            .setDescription('Restrict this command to only be usable in a specific channel')
            .setDescriptionLocalizations({ ar: 'قصر استخدام هذا الأمر على قناة محددة', 'en-US': 'Restrict this command to only be usable in a specific channel' })
            .addStringOption((o) => o.setName('command').setDescription('Command name, e.g. ban').setDescriptionLocalizations({ ar: 'اسم الأمر، مثل ban', 'en-US': 'Command name, e.g. ban' }).setRequired(true).setAutocomplete(true))
            .addChannelOption((o) => o.setName('channel').setDescription('Channel to allow').setDescriptionLocalizations({ ar: 'القناة المراد السماح فيها', 'en-US': 'Channel to allow' }).setRequired(true))
        )
    )
    .addSubcommandGroup((g) =>
      g
        .setName('deny')
        .setDescription('Block specific roles/users from a command, even if they would otherwise be able to use it')
        .setDescriptionLocalizations({ ar: 'منع أدوار/أعضاء محددين من أمر، حتى لو كانوا قادرين على استخدامه أصلاً', 'en-US': 'Block specific roles/users from a command, even if they would otherwise be able to use it' })
        .addSubcommand((s) =>
          s
            .setName('role')
            .setDescription('Deny a role from using this command')
            .setDescriptionLocalizations({ ar: 'منع دور من استخدام هذا الأمر', 'en-US': 'Deny a role from using this command' })
            .addStringOption((o) => o.setName('command').setDescription('Command name, e.g. ban').setDescriptionLocalizations({ ar: 'اسم الأمر، مثل ban', 'en-US': 'Command name, e.g. ban' }).setRequired(true).setAutocomplete(true))
            .addRoleOption((o) => o.setName('role').setDescription('Role to deny').setDescriptionLocalizations({ ar: 'الدور المراد منعه', 'en-US': 'Role to deny' }).setRequired(true))
        )
        .addSubcommand((s) =>
          s
            .setName('user')
            .setDescription('Deny a specific user from using this command')
            .setDescriptionLocalizations({ ar: 'منع عضو معين من استخدام هذا الأمر', 'en-US': 'Deny a specific user from using this command' })
            .addStringOption((o) => o.setName('command').setDescription('Command name, e.g. ban').setDescriptionLocalizations({ ar: 'اسم الأمر، مثل ban', 'en-US': 'Command name, e.g. ban' }).setRequired(true).setAutocomplete(true))
            .addUserOption((o) => o.setName('user').setDescription('User to deny').setDescriptionLocalizations({ ar: 'العضو المراد منعه', 'en-US': 'User to deny' }).setRequired(true))
        )
        .addSubcommand((s) =>
          s
            .setName('channel')
            .setDescription('Block this command from being used in a specific channel')
            .setDescriptionLocalizations({ ar: 'منع استخدام هذا الأمر في قناة محددة', 'en-US': 'Block this command from being used in a specific channel' })
            .addStringOption((o) => o.setName('command').setDescription('Command name, e.g. ban').setDescriptionLocalizations({ ar: 'اسم الأمر، مثل ban', 'en-US': 'Command name, e.g. ban' }).setRequired(true).setAutocomplete(true))
            .addChannelOption((o) => o.setName('channel').setDescription('Channel to deny').setDescriptionLocalizations({ ar: 'القناة المراد منعها', 'en-US': 'Channel to deny' }).setRequired(true))
        )
    )
    .addSubcommandGroup((g) =>
      g
        .setName('remove')
        .setDescription('Remove a role/user override (allow or deny) from a command')
        .setDescriptionLocalizations({ ar: 'إزالة استثناء (سماح أو منع) عن أمر', 'en-US': 'Remove a role/user override (allow or deny) from a command' })
        .addSubcommand((s) =>
          s
            .setName('role')
            .setDescription('Remove a role override from this command')
            .setDescriptionLocalizations({ ar: 'إزالة استثناء دور عن هذا الأمر', 'en-US': 'Remove a role override from this command' })
            .addStringOption((o) => o.setName('command').setDescription('Command name, e.g. ban').setDescriptionLocalizations({ ar: 'اسم الأمر، مثل ban', 'en-US': 'Command name, e.g. ban' }).setRequired(true).setAutocomplete(true))
            .addRoleOption((o) => o.setName('role').setDescription('Role to remove').setDescriptionLocalizations({ ar: 'الدور المراد إزالته', 'en-US': 'Role to remove' }).setRequired(true))
        )
        .addSubcommand((s) =>
          s
            .setName('user')
            .setDescription('Remove a user override from this command')
            .setDescriptionLocalizations({ ar: 'إزالة استثناء عضو عن هذا الأمر', 'en-US': 'Remove a user override from this command' })
            .addStringOption((o) => o.setName('command').setDescription('Command name, e.g. ban').setDescriptionLocalizations({ ar: 'اسم الأمر، مثل ban', 'en-US': 'Command name, e.g. ban' }).setRequired(true).setAutocomplete(true))
            .addUserOption((o) => o.setName('user').setDescription('User to remove').setDescriptionLocalizations({ ar: 'العضو المراد إزالته', 'en-US': 'User to remove' }).setRequired(true))
        )
        .addSubcommand((s) =>
          s
            .setName('channel')
            .setDescription('Remove a channel override (allow or deny) from this command')
            .setDescriptionLocalizations({ ar: 'إزالة استثناء قناة (سماح أو منع) عن هذا الأمر', 'en-US': 'Remove a channel override (allow or deny) from this command' })
            .addStringOption((o) => o.setName('command').setDescription('Command name, e.g. ban').setDescriptionLocalizations({ ar: 'اسم الأمر، مثل ban', 'en-US': 'Command name, e.g. ban' }).setRequired(true).setAutocomplete(true))
            .addChannelOption((o) => o.setName('channel').setDescription('Channel to remove').setDescriptionLocalizations({ ar: 'القناة المراد إزالتها', 'en-US': 'Channel to remove' }).setRequired(true))
        )
    )
    .addSubcommand((s) =>
      s
        .setName('list')
        .setDescription("Show a command's current permission overrides")
        .setDescriptionLocalizations({ ar: 'عرض استثناءات الصلاحيات الحالية لأمر', 'en-US': "Show a command's current permission overrides" })
        .addStringOption((o) => o.setName('command').setDescription('Command name, e.g. ban').setDescriptionLocalizations({ ar: 'اسم الأمر، مثل ban', 'en-US': 'Command name, e.g. ban' }).setRequired(true).setAutocomplete(true))
    )
    .addSubcommand((s) =>
      s
        .setName('reset')
        .setDescription('Clear every permission override for a command')
        .setDescriptionLocalizations({ ar: 'مسح جميع استثناءات الصلاحيات لأمر', 'en-US': 'Clear every permission override for a command' })
        .addStringOption((o) => o.setName('command').setDescription('Command name, e.g. ban').setDescriptionLocalizations({ ar: 'اسم الأمر، مثل ban', 'en-US': 'Command name, e.g. ban' }).setRequired(true).setAutocomplete(true))
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  autocomplete: safeAutocomplete(async (interaction) => {
    return commandNameChoices(interaction, interaction.options.getFocused());
  }),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You need to be a guild manager to use this command.')], ephemeral: true });
    }

    const group = interaction.options.getSubcommandGroup(false);
    const sub = interaction.options.getSubcommand();
    const name = interaction.options.getString('command').toLowerCase();

    if (!interaction.client.commands.has(name)) {
      return interaction.reply({ embeds: [errorEmbed(settings, `No command named \`${name}\` exists.`)], ephemeral: true });
    }
    if (PROTECTED_COMMANDS.has(name)) {
      return interaction.reply({
        embeds: [errorEmbed(settings, `\`/${name}\` always stays usable for guild managers and cannot be restricted, so it can never be locked out by mistake.`)],
        ephemeral: true,
      });
    }

    if (sub === 'list') {
      const entry = guildConfig.commandPermissions.find((e) => e.commandName === name);
      return interaction.reply({
        embeds: [
          infoEmbed(settings, `Permission overrides for \`/${name}\``).addFields(
            { name: 'Allowed roles', value: entry?.allowedRoleIds.map((id) => `<@&${id}>`).join(', ') || 'None', inline: true },
            { name: 'Allowed users', value: entry?.allowedUserIds.map((id) => `<@${id}>`).join(', ') || 'None', inline: true },
            { name: 'Allowed channels', value: entry?.allowedChannelIds.map((id) => `<#${id}>`).join(', ') || 'None', inline: true },
            { name: 'Denied roles', value: entry?.deniedRoleIds.map((id) => `<@&${id}>`).join(', ') || 'None', inline: true },
            { name: 'Denied users', value: entry?.deniedUserIds.map((id) => `<@${id}>`).join(', ') || 'None', inline: true },
            { name: 'Denied channels', value: entry?.deniedChannelIds.map((id) => `<#${id}>`).join(', ') || 'None', inline: true }
          ),
        ],
        ephemeral: true,
      });
    }

    if (sub === 'reset') {
      const idx = guildConfig.commandPermissions.findIndex((e) => e.commandName === name);
      if (idx === -1) {
        return interaction.reply({ embeds: [errorEmbed(settings, `\`/${name}\` has no permission overrides to clear.`)], ephemeral: true });
      }
      guildConfig.commandPermissions.splice(idx, 1);
      await guildConfig.save();
      invalidateGuildConfig(interaction.guildId);
      return interaction.reply({ embeds: [successEmbed(settings, `Cleared every permission override for \`/${name}\`.`)] });
    }

    // Everything below is one of allow/deny/remove x role/user/channel,
    // which all share the same shape: mutate one list on the command's
    // entry, save, invalidate the cache, and confirm.
    const target = sub === 'role' ? interaction.options.getRole('role') : sub === 'channel' ? interaction.options.getChannel('channel') : interaction.options.getUser('user');
    const targetMention = sub === 'channel' ? `<#${target.id}>` : `${target}`;

    const entry = getOrCreateEntry(guildConfig, name);
    let changed = false;
    let message = '';

    // Picks the allow/deny list pair for whichever of role/user/channel
    // this subcommand targets, so the allow/deny/remove branches below
    // don't need to know which one they're dealing with.
    const listsFor = { role: [entry.allowedRoleIds, entry.deniedRoleIds], user: [entry.allowedUserIds, entry.deniedUserIds], channel: [entry.allowedChannelIds, entry.deniedChannelIds] };
    const [allowList, denyList] = listsFor[sub];
    const targetLabel = sub === 'channel' ? 'This channel' : targetMention;

    if (group === 'allow') {
      removeIfPresent(denyList, target.id); // allow always wins over a prior deny for the same target
      changed = addUnique(allowList, target.id);
      message = changed
        ? `${targetLabel} can now be used with \`/${name}\` (allow-list mode is now active for this command - see \`/permissions list\`).`
        : `${targetLabel} was already allowed to use \`/${name}\`.`;
    } else if (group === 'deny') {
      removeIfPresent(allowList, target.id); // deny always wins over a prior allow for the same target
      changed = addUnique(denyList, target.id);
      message = changed ? `${targetLabel} is now blocked from using \`/${name}\`.` : `${targetLabel} was already blocked from using \`/${name}\`.`;
    } else if (group === 'remove') {
      const removedFromAllow = removeIfPresent(allowList, target.id);
      const removedFromDeny = removeIfPresent(denyList, target.id);
      changed = removedFromAllow || removedFromDeny;
      message = changed ? `Removed ${targetLabel}'s override for \`/${name}\`.` : `${targetLabel} had no override set for \`/${name}\`.`;
    }

    if (changed) {
      await guildConfig.save();
      invalidateGuildConfig(interaction.guildId);
    }

    await interaction.reply({ embeds: [successEmbed(settings, message)] });
  },
};
