const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { isModerator } = require('../../utils/permissions');
const { applyWarnThresholds } = require('../../utils/warnThresholds');
const { sendModerationLog } = require('../../utils/moderationLogService');
const { createCase } = require('../../services/caseService');
const Warn = require('../../database/models/Warn');

const { safeAutocomplete, reasonChoices } = require('../../utils/autocomplete');
module.exports = {
  data: new SlashCommandBuilder()
    .setName('warn')
    .setDescription('Issue a warning to a member')
    .setDescriptionLocalizations({ ar: 'توجيه تحذير لعضو', 'en-US': 'Issue a warning to a member' })
    .addUserOption((o) => o.setName('user').setDescription('The user to warn').setDescriptionLocalizations({ ar: 'المستخدم المراد تحذيره', 'en-US': 'The user to warn' }).setRequired(true))
    .addStringOption((o) => o.setName('reason').setDescription('Reason for the warning').setDescriptionLocalizations({ ar: 'سبب التحذير', 'en-US': 'Reason for the warning' }).setRequired(true).setAutocomplete(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  autocomplete: safeAutocomplete(async (interaction) => {
    return reasonChoices(interaction.options.getFocused());
  }),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isModerator(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You do not have permission to use this command.')], ephemeral: true });
    }

    const target = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason');

    await Warn.create({ guildId: interaction.guildId, userId: target.id, moderatorId: interaction.user.id, reason });
    const count = await Warn.countDocuments({ guildId: interaction.guildId, userId: target.id });

    const caseDoc = await createCase({
      guildId: interaction.guildId,
      action: 'warn',
      moderatorId: interaction.user.id,
      targetId: target.id,
      reason,
    });

    await interaction.reply({
      embeds: [successEmbed(settings, `**${target.tag}** has been warned (total: ${count}). Reason: ${reason}\nرقم القضية: #${caseDoc.caseId}`)],
    });
    await target.send({ embeds: [errorEmbed(settings, `You were warned in **${interaction.guild.name}**: ${reason}`)] }).catch(() => null);

    await applyWarnThresholds(interaction.guild, guildConfig, settings, target.id, count);

    await sendModerationLog(interaction.guild, guildConfig, settings, {
      action: 'warn',
      moderator: interaction.user,
      target,
      reason,
      caseId: caseDoc.caseId,
    });
  },
};
