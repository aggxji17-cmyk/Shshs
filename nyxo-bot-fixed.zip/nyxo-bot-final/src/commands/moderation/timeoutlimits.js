const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved, invalidateGuildConfig } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed, baseEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('timeoutlimits')
    .setDescription('Configure the weekly per-role timeout quota')
    .setDescriptionLocalizations({ ar: 'إعداد الحد الأسبوعي للتقييد حسب الرتبة', 'en-US': 'Configure the weekly per-role timeout quota' })
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand((sc) =>
      sc
        .setName('set')
        .setDescription('Set (or update) the weekly timeout limit for a role')
      .setDescriptionLocalizations({ ar: 'تعيين (أو تحديث) الحد الأسبوعي للتقييد لرتبة معينة', 'en-US': 'Set (or update) the weekly timeout limit for a role' })
        .addRoleOption((o) => o.setName('role').setDescription('The role this limit applies to').setDescriptionLocalizations({ ar: 'الرتبة التي يُطبّق عليها هذا الحد', 'en-US': 'The role this limit applies to' }).setRequired(true))
        .addIntegerOption((o) =>
          o.setName('limit').setDescription('Timeouts allowed per week for this role (-1 = unlimited)').setDescriptionLocalizations({ ar: 'عدد التقييد المسموح أسبوعياً لهذه الرتبة (-1 = غير محدود)', 'en-US': 'Timeouts allowed per week for this role (-1 = unlimited)' }).setRequired(true).setMinValue(-1)
        )
    )
    .addSubcommand((sc) =>
      sc
        .setName('remove')
        .setDescription('Remove the weekly timeout limit for a role')
      .setDescriptionLocalizations({ ar: 'إزالة الحد الأسبوعي للتقييد لرتبة معينة', 'en-US': 'Remove the weekly timeout limit for a role' })
        .addRoleOption((o) => o.setName('role').setDescription('The role to remove').setDescriptionLocalizations({ ar: 'الرتبة المراد إزالتها', 'en-US': 'The role to remove' }).setRequired(true))
    )
    .addSubcommand((sc) => sc.setName('list').setDescription('List all configured weekly timeout limits')
      .setDescriptionLocalizations({ ar: 'عرض جميع حدود التقييد الأسبوعية المُعدّة', 'en-US': 'List all configured weekly timeout limits' }))
    .addSubcommand((sc) =>
      sc
        .setName('toggle')
        .setDescription('Enable or disable the weekly timeout limit system')
      .setDescriptionLocalizations({ ar: 'تفعيل أو تعطيل نظام الحد الأسبوعي للتقييد', 'en-US': 'Enable or disable the weekly timeout limit system' })
        .addBooleanOption((o) => o.setName('enabled').setDescription('Whether limits should be enforced').setDescriptionLocalizations({ ar: 'هل يجب فرض الحدود', 'en-US': 'Whether limits should be enforced' }).setRequired(true))
    ),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'ليس لديك صلاحية استخدام هذا الأمر.')], ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();
    guildConfig.moderation = guildConfig.moderation || {};
    guildConfig.moderation.timeoutLimits = guildConfig.moderation.timeoutLimits || { enabled: false, perRole: [] };

    if (sub === 'toggle') {
      const enabled = interaction.options.getBoolean('enabled');
      guildConfig.moderation.timeoutLimits.enabled = enabled;
      guildConfig.markModified('moderation.timeoutLimits');
      await guildConfig.save();
      invalidateGuildConfig(interaction.guildId);
      return interaction.reply({
        embeds: [successEmbed(settings, enabled ? 'تم تفعيل نظام حد الـ Timeout الأسبوعي.' : 'تم تعطيل نظام حد الـ Timeout الأسبوعي.')],
        ephemeral: true,
      });
    }

    if (sub === 'set') {
      const role = interaction.options.getRole('role');
      const limit = interaction.options.getInteger('limit');
      const perRole = guildConfig.moderation.timeoutLimits.perRole;
      const existing = perRole.find((entry) => entry.roleId === role.id);
      if (existing) existing.weeklyLimit = limit;
      else perRole.push({ roleId: role.id, weeklyLimit: limit });

      guildConfig.markModified('moderation.timeoutLimits');
      await guildConfig.save();
      invalidateGuildConfig(interaction.guildId);

      const limitText = limit < 0 ? 'بدون حد (غير محدود)' : `${limit} عملية Timeout أسبوعيًا`;
      return interaction.reply({ embeds: [successEmbed(settings, `تم ضبط حد رتبة **${role.name}**: ${limitText}.`)], ephemeral: true });
    }

    if (sub === 'remove') {
      const role = interaction.options.getRole('role');
      const perRole = guildConfig.moderation.timeoutLimits.perRole;
      const before = perRole.length;
      guildConfig.moderation.timeoutLimits.perRole = perRole.filter((entry) => entry.roleId !== role.id);

      if (guildConfig.moderation.timeoutLimits.perRole.length === before) {
        return interaction.reply({ embeds: [errorEmbed(settings, `لا يوجد حد مضبوط لرتبة **${role.name}**.`)], ephemeral: true });
      }

      guildConfig.markModified('moderation.timeoutLimits');
      await guildConfig.save();
      invalidateGuildConfig(interaction.guildId);
      return interaction.reply({ embeds: [successEmbed(settings, `تم إزالة حد رتبة **${role.name}**.`)], ephemeral: true });
    }

    // sub === 'list'
    const { enabled, perRole } = guildConfig.moderation.timeoutLimits;
    const embed = baseEmbed(settings).setTitle('حدود الـ Timeout الأسبوعية');

    if (!perRole.length) {
      embed.setDescription(`الحالة: ${enabled ? 'مفعّل ✅' : 'معطّل ❌'}\nلا توجد رتب مضبوطة حاليًا - جميع الرتب غير محدودة.`);
    } else {
      const lines = perRole.map((entry) => {
        const limitText = entry.weeklyLimit < 0 ? 'بدون حد' : `${entry.weeklyLimit} / أسبوعيًا`;
        return `<@&${entry.roleId}> — ${limitText}`;
      });
      embed.setDescription(`الحالة: ${enabled ? 'مفعّل ✅' : 'معطّل ❌'}\n\n${lines.join('\n')}`);
    }

    await interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
