const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { getGuildConfig, resolved, invalidateGuildConfig } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed, baseEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('modlogs')
    .setDescription('Configure the unified moderation log (ban/kick/timeout/warn/unban)')
    .setDescriptionLocalizations({ ar: 'إعداد سجل الإشراف الموحد (حظر/طرد/تقييد/تحذير/رفع حظر)', 'en-US': 'Configure the unified moderation log (ban/kick/timeout/warn/unban)' })
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand((sc) =>
      sc
        .setName('set')
        .setDescription('Set the channel moderation actions are logged to')
      .setDescriptionLocalizations({ ar: 'تعيين قناة تسجيل إجراءات الإشراف', 'en-US': 'Set the channel moderation actions are logged to' })
        .addChannelOption((o) =>
          o.setName('channel').setDescription('The text channel to post logs in').setDescriptionLocalizations({ ar: 'القناة النصية التي تُنشر فيها السجلات', 'en-US': 'The text channel to post logs in' }).addChannelTypes(ChannelType.GuildText).setRequired(true)
        )
    )
    .addSubcommand((sc) => sc.setName('remove').setDescription('Stop logging moderation actions')
      .setDescriptionLocalizations({ ar: 'إيقاف تسجيل إجراءات الإشراف', 'en-US': 'Stop logging moderation actions' }))
    .addSubcommand((sc) => sc.setName('status').setDescription('Show the current moderation log configuration')
      .setDescriptionLocalizations({ ar: 'عرض إعدادات سجل الإشراف الحالية', 'en-US': 'Show the current moderation log configuration' })),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'ليس لديك صلاحية استخدام هذا الأمر.')], ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();

    if (sub === 'set') {
      const channel = interaction.options.getChannel('channel');
      guildConfig.moderationLogChannelId = channel.id;
      await guildConfig.save();
      invalidateGuildConfig(interaction.guildId);
      return interaction.reply({ embeds: [successEmbed(settings, `سيتم الآن إرسال سجلات الإشراف إلى ${channel}.`)], ephemeral: true });
    }

    if (sub === 'remove') {
      if (!guildConfig.moderationLogChannelId) {
        return interaction.reply({ embeds: [errorEmbed(settings, 'لا يوجد روم لوقات مضبوط أصلًا.')], ephemeral: true });
      }
      guildConfig.moderationLogChannelId = null;
      await guildConfig.save();
      invalidateGuildConfig(interaction.guildId);
      return interaction.reply({ embeds: [successEmbed(settings, 'تم إلغاء روم سجلات الإشراف. لن تُرسل أي لوقات إشراف بعد الآن.')], ephemeral: true });
    }

    // sub === 'status'
    const embed = baseEmbed(settings).setTitle('حالة نظام سجلات الإشراف');
    if (guildConfig.moderationLogChannelId) {
      embed.setDescription(`الحالة: مفعّل ✅\nالروم: <#${guildConfig.moderationLogChannelId}>`);
    } else {
      embed.setDescription('الحالة: معطّل ❌\nلم يتم تحديد روم بعد - استخدم `/modlogs set`.');
    }
    embed.addFields({ name: 'الأوامر المدعومة', value: 'Ban, Kick, Timeout, Warn, Unban' });

    await interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
