const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed, baseEmbed } = require('../../utils/embeds');
const { isModerator } = require('../../utils/permissions');
const StaffNote = require('../../database/models/StaffNote');

/**
 * Internal, staff-only notes about a user - never DMed to the target and
 * never counted toward warn thresholds or /modhistory. Meant for context
 * moderators want to leave each other ("possible alt of <user>", "keeps
 * being polite in DMs, be patient") that doesn't rise to a formal warning.
 */
module.exports = {
  data: new SlashCommandBuilder()
    .setName('note')
    .setDescription('Manage internal staff notes about a user (never shown to the user)')
    .setDescriptionLocalizations({ ar: 'إدارة ملاحظات إشرافية داخلية عن مستخدم (لا تُعرض له أبداً)', 'en-US': 'Manage internal staff notes about a user (never shown to the user)' })
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addSubcommand((s) =>
      s
        .setName('add')
        .setDescription('Add a staff note to a user')
        .setDescriptionLocalizations({ ar: 'إضافة ملاحظة إشرافية لمستخدم', 'en-US': 'Add a staff note to a user' })
        .addUserOption((o) => o.setName('user').setDescription('The user to note').setDescriptionLocalizations({ ar: 'المستخدم المراد إضافة ملاحظة له', 'en-US': 'The user to note' }).setRequired(true))
        .addStringOption((o) => o.setName('content').setDescription('The note content').setDescriptionLocalizations({ ar: 'محتوى الملاحظة', 'en-US': 'The note content' }).setRequired(true).setMaxLength(1000))
    )
    .addSubcommand((s) =>
      s
        .setName('list')
        .setDescription('List staff notes for a user')
        .setDescriptionLocalizations({ ar: 'عرض الملاحظات الإشرافية لمستخدم', 'en-US': 'List staff notes for a user' })
        .addUserOption((o) => o.setName('user').setDescription('The user to check').setDescriptionLocalizations({ ar: 'المستخدم المراد التحقق منه', 'en-US': 'The user to check' }).setRequired(true))
    )
    .addSubcommand((s) =>
      s
        .setName('remove')
        .setDescription('Remove one staff note by its ID')
        .setDescriptionLocalizations({ ar: 'حذف ملاحظة إشرافية واحدة عن طريق معرّفها', 'en-US': 'Remove one staff note by its ID' })
        .addStringOption((o) => o.setName('id').setDescription('Note ID from /note list').setDescriptionLocalizations({ ar: 'معرّف الملاحظة من /note list', 'en-US': 'Note ID from /note list' }).setRequired(true))
    )
    .addSubcommand((s) =>
      s
        .setName('clear')
        .setDescription('Remove all staff notes for a user')
        .setDescriptionLocalizations({ ar: 'حذف جميع الملاحظات الإشرافية لمستخدم', 'en-US': 'Remove all staff notes for a user' })
        .addUserOption((o) => o.setName('user').setDescription('The user to clear notes for').setDescriptionLocalizations({ ar: 'المستخدم المراد حذف ملاحظاته', 'en-US': 'The user to clear notes for' }).setRequired(true))
    ),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isModerator(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You do not have permission to use this command.')], ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();

    if (sub === 'add') {
      const target = interaction.options.getUser('user');
      const content = interaction.options.getString('content');

      const note = await StaffNote.create({
        guildId: interaction.guildId,
        userId: target.id,
        authorId: interaction.user.id,
        content,
      });

      return interaction.reply({
        embeds: [successEmbed(settings, `Note added for **${target.tag}**.\nNote ID: \`${note._id}\``)],
        ephemeral: true,
      });
    }

    if (sub === 'list') {
      const target = interaction.options.getUser('user');
      const notes = await StaffNote.find({ guildId: interaction.guildId, userId: target.id }).sort({ createdAt: -1 }).limit(25);

      if (!notes.length) {
        return interaction.reply({ embeds: [errorEmbed(settings, `No staff notes found for **${target.tag}**.`)], ephemeral: true });
      }

      const embed = baseEmbed(settings)
        .setTitle(`Staff notes - ${target.tag}`)
        .setDescription(
          notes
            .map((n) => `**\`${n._id}\`** — <@${n.authorId}> — <t:${Math.floor(n.createdAt.getTime() / 1000)}:R>\n${n.content}`)
            .join('\n\n')
        );

      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    if (sub === 'remove') {
      const id = interaction.options.getString('id');
      let deleted = null;
      try {
        deleted = await StaffNote.findOneAndDelete({ _id: id, guildId: interaction.guildId });
      } catch {
        // Malformed ObjectId string - falls through to the "not found" reply below.
        deleted = null;
      }

      if (!deleted) {
        return interaction.reply({ embeds: [errorEmbed(settings, 'No note found with that ID in this server.')], ephemeral: true });
      }
      return interaction.reply({ embeds: [successEmbed(settings, 'Note removed.')], ephemeral: true });
    }

    if (sub === 'clear') {
      const target = interaction.options.getUser('user');
      const { deletedCount } = await StaffNote.deleteMany({ guildId: interaction.guildId, userId: target.id });
      return interaction.reply({
        embeds: [successEmbed(settings, `Removed ${deletedCount} note(s) for **${target.tag}**.`)],
        ephemeral: true,
      });
    }
  },
};
