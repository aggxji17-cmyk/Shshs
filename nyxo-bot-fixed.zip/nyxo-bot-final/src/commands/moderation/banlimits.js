const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved, invalidateGuildConfig } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed, baseEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('banlimits')
    .setDescription('Configure the weekly per-role ban quota')
    .setDescriptionLocalizations({ ar: 'إعداد الحد الأسبوعي لعمليات الحظر حسب الرتبة', 'en-US': 'Configure the weekly per-role ban quota' })
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand((sc) =>
      sc
        .setName('set')
        .setDescription('Set (or update) the weekly ban limit for a role')
      .setDescriptionLocalizations({ ar: 'تعيين (أو تحديث) الحد الأسبوعي للحظر لرتبة معينة', 'en-US': 'Set (or update) the weekly ban limit for a role' })
        .addRoleOption((o) => o.setName('role').setDescription('The role this limit applies to').setDescriptionLocalizations({ ar: 'الرتبة التي يُطبّق عليها هذا الحد', 'en-US': 'The role this limit applies to' }).setRequired(true))
        .addIntegerOption((o) =>
          o.setName('limit').setDescription('Bans allowed per week for this role (-1 = unlimited)').setDescriptionLocalizations({ ar: 'عدد الحظر المسموح أسبوعياً لهذه الرتبة (-1 = غير محدود)', 'en-US': 'Bans allowed per week for this role (-1 = unlimited)' }).setRequired(true).setMinValue(-1)
        )
    )
    .addSubcommand((sc) =>
      sc
        .setName('remove')
        .setDescription('Remove the weekly ban limit for a role')
      .setDescriptionLocalizations({ ar: 'إزالة الحد الأسبوعي للحظر لرتبة معينة', 'en-US': 'Remove the weekly ban limit for a role' })
        .addRoleOption((o) => o.setName('role').setDescription('The role to remove').setDescriptionLocalizations({ ar: 'الرتبة المراد إزالتها', 'en-US': 'The role to remove' }).setRequired(true))
    )
    .addSubcommand((sc) => sc.setName('list').setDescription('List all configured weekly ban limits')
      .setDescriptionLocalizations({ ar: 'عرض جميع حدود الحظر الأسبوعية المُعدّة', 'en-US': 'List all configured weekly ban limits' }))
    .addSubcommand((sc) =>
      sc
        .setName('toggle')
        .setDescription('Enable or disable the weekly ban limit system')
      .setDescriptionLocalizations({ ar: 'تفعيل أو تعطيل نظام الحد الأسبوعي للحظر', 'en-US': 'Enable or disable the weekly ban limit system' })
        .addBooleanOption((o) => o.setName('enabled').setDescription('Whether limits should be enforced').setDescriptionLocalizations({ ar: 'هل يجب فرض الحدود', 'en-US': 'Whether limits should be enforced' }).setRequired(true))
    ),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'ليس لديك صلاحية استخدام هذا الأمر.')], ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();
    guildConfig.moderation = guildConfig.moderation || {};
    guildConfig.moderation.banLimits = guildConfig.moderation.banLimits || { enabled: false, perRole: [] };

    if (sub === 'toggle') {
      const enabled = interaction.options.getBoolean('enabled');
      guildConfig.moderation.banLimits.enabled = enabled;
      guildConfig.markModified('moderation.banLimits');
      await guildConfig.save();
      invalidateGuildConfig(interaction.guildId);
      return interaction.reply({
        embeds: [successEmbed(settings, enabled ? 'تم تفعيل نظام حد الحظر الأسبوعي.' : 'تم تعطيل نظام حد الحظر الأسبوعي.')],
        ephemeral: true,
      });
    }

    if (sub === 'set') {
      const role = interaction.options.getRole('role');
      const limit = interaction.options.getInteger('limit');
      const perRole = guildConfig.moderation.banLimits.perRole;
      const existing = perRole.find((entry) => entry.roleId === role.id);
      if (existing) existing.weeklyLimit = limit;
      else perRole.push({ roleId: role.id, weeklyLimit: limit });

      guildConfig.markModified('moderation.banLimits');
      await guildConfig.save();
      invalidateGuildConfig(interaction.guildId);

      const limitText = limit < 0 ? 'بدون حد (غير محدود)' : `${limit} عملية حظر أسبوعيًا`;
      return interaction.reply({ embeds: [successEmbed(settings, `تم ضبط حد رتبة **${role.name}**: ${limitText}.`)], ephemeral: true });
    }

    if (sub === 'remove') {
      const role = interaction.options.getRole('role');
      const perRole = guildConfig.moderation.banLimits.perRole;
      const before = perRole.length;
      guildConfig.moderation.banLimits.perRole = perRole.filter((entry) => entry.roleId !== role.id);

      if (guildConfig.moderation.banLimits.perRole.length === before) {
        return interaction.reply({ embeds: [errorEmbed(settings, `لا يوجد حد مضبوط لرتبة **${role.name}**.`)], ephemeral: true });
      }

      guildConfig.markModified('moderation.banLimits');
      await guildConfig.save();
      invalidateGuildConfig(interaction.guildId);
      return interaction.reply({ embeds: [successEmbed(settings, `تم إزالة حد رتبة **${role.name}**.`)], ephemeral: true });
    }

    // sub === 'list'
    const { enabled, perRole } = guildConfig.moderation.banLimits;
    const embed = baseEmbed(settings).setTitle('حدود الحظر الأسبوعية');

    if (!perRole.length) {
      embed.setDescription(`الحالة: ${enabled ? 'مفعّل ✅' : 'معطّل ❌'}\nلا توجد رتب مضبوطة حاليًا - جميع الرتب غير محدودة.`);
    } else {
      const lines = perRole.map((entry) => {
        const limitText = entry.weeklyLimit < 0 ? 'بدون حد' : `${entry.weeklyLimit} / أسبوعيًا`;
        return `<@&${entry.roleId}> — ${limitText}`;
      });
      embed.setDescription(`الحالة: ${enabled ? 'مفعّل ✅' : 'معطّل ❌'}\n\n${lines.join('\n')}`);
    }

    await interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
