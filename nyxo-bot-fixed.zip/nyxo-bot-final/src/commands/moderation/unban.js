const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { isModerator } = require('../../utils/permissions');
const { sendModerationLog } = require('../../utils/moderationLogService');
const { createCase, findActiveBanCase, revertCase } = require('../../services/caseService');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unban')
    .setDescription('Unban a user by ID')
    .setDescriptionLocalizations({ ar: 'رفع الحظر عن مستخدم عبر المعرف', 'en-US': 'Unban a user by ID' })
    .addStringOption((o) => o.setName('user_id').setDescription('The user ID to unban').setDescriptionLocalizations({ ar: 'معرّف المستخدم المراد رفع الحظر عنه', 'en-US': 'The user ID to unban' }).setRequired(true))
    .addStringOption((o) => o.setName('reason').setDescription('Reason for the unban').setDescriptionLocalizations({ ar: 'سبب رفع الحظر', 'en-US': 'Reason for the unban' }))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isModerator(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'ليس لديك صلاحية استخدام هذا الأمر.')], ephemeral: true });
    }

    const userId = interaction.options.getString('user_id');
    const reason = interaction.options.getString('reason') || 'No reason provided';

    const banEntry = await interaction.guild.bans.fetch(userId).catch(() => null);
    if (!banEntry) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'هذا المستخدم غير محظور في هذا السيرفر.')], ephemeral: true });
    }

    await interaction.guild.members.unban(userId, reason);

    // If this user still has an Active ban Case, close that Case out
    // (status -> Reverted) instead of creating a brand-new, disconnected
    // unban Case for the same punishment. Only falls back to creating a
    // fresh 'unban' Case when there's nothing to link it to (e.g. the ban
    // predates the Case system, or its Case was already resolved).
    const activeBanCase = await findActiveBanCase(interaction.guildId, userId);
    const caseDoc = activeBanCase
      ? await revertCase(interaction.guildId, activeBanCase.caseId, {
          revertedBy: interaction.user.id,
          revertReason: reason,
        })
      : await createCase({
          guildId: interaction.guildId,
          action: 'unban',
          moderatorId: interaction.user.id,
          targetId: userId,
          reason,
        });

    await interaction.reply({
      embeds: [successEmbed(settings, `تم فك الحظر عن **${banEntry.user.tag}**. السبب: ${reason}\nرقم القضية: #${caseDoc.caseId}`)],
    });

    await sendModerationLog(interaction.guild, guildConfig, settings, {
      action: 'unban',
      moderator: interaction.user,
      target: banEntry.user,
      reason,
      caseId: caseDoc.caseId,
    });
  },
};
