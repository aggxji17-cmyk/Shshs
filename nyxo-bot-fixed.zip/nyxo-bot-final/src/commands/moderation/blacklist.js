const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved, invalidateGuildConfig } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed, infoEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');
const { safeAutocomplete, commandNameChoices } = require('../../utils/autocomplete');
const { PROTECTED_COMMANDS } = require('../../utils/commandPermissions');
const { toggleCommandInChannel } = require('../../utils/channelCommandBlacklist');
const { toggleCommandForRole } = require('../../utils/roleCommandBlacklist');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('blacklist')
    .setDescription('Manage user and command blacklists')
    .setDescriptionLocalizations({ ar: 'منع أعضاء من استخدام أوامر البوت أو تعطيل أوامر معينة في السيرفر أو في قناة محددة أو لرتبة محددة', 'en-US': 'Block users from using bot commands, or disable specific commands server-wide, per channel, or per role' })
    .addSubcommand((sc) => sc.setName('user').setDescription('Toggle a user\'s ability to use bot commands')
      .setDescriptionLocalizations({ ar: 'تبديل قدرة مستخدم على استخدام أوامر البوت', 'en-US': 'Toggle a user\'s ability to use bot commands' }).addUserOption((o) => o.setName('user').setDescription('User to toggle').setDescriptionLocalizations({ ar: 'المستخدم المراد تبديل حالته', 'en-US': 'User to toggle' }).setRequired(true)))
    .addSubcommand((sc) => sc.setName('command').setDescription('Toggle whether a command is disabled in this server')
      .setDescriptionLocalizations({ ar: 'تبديل حالة تعطيل أمر في هذا السيرفر', 'en-US': 'Toggle whether a command is disabled in this server' }).addStringOption((o) => o.setName('name').setDescription('Command name, e.g. ban').setDescriptionLocalizations({ ar: 'اسم الأمر، مثل ban', 'en-US': 'Command name, e.g. ban' }).setRequired(true).setAutocomplete(true)))
    .addSubcommand((sc) => sc.setName('channel').setDescription('Toggle whether a command is disabled in a specific channel')
      .setDescriptionLocalizations({ ar: 'تبديل حالة تعطيل أمر في قناة محددة', 'en-US': 'Toggle whether a command is disabled in a specific channel' })
      .addStringOption((o) => o.setName('name').setDescription('Command name, e.g. ban').setDescriptionLocalizations({ ar: 'اسم الأمر، مثل ban', 'en-US': 'Command name, e.g. ban' }).setRequired(true).setAutocomplete(true))
      .addChannelOption((o) => o.setName('channel').setDescription('Channel to toggle (defaults to this channel)').setDescriptionLocalizations({ ar: 'القناة المراد التبديل فيها (الافتراضي: هذه القناة)', 'en-US': 'Channel to toggle (defaults to this channel)' })))
    .addSubcommand((sc) => sc.setName('role').setDescription('Toggle whether a command is disabled for everyone holding a specific role')
      .setDescriptionLocalizations({ ar: 'تبديل حالة تعطيل أمر لكل من يحمل رتبة محددة', 'en-US': 'Toggle whether a command is disabled for everyone holding a specific role' })
      .addStringOption((o) => o.setName('name').setDescription('Command name, e.g. ban').setDescriptionLocalizations({ ar: 'اسم الأمر، مثل ban', 'en-US': 'Command name, e.g. ban' }).setRequired(true).setAutocomplete(true))
      .addRoleOption((o) => o.setName('role').setDescription('Role to toggle').setDescriptionLocalizations({ ar: 'الرتبة المراد التبديل لها', 'en-US': 'Role to toggle' }).setRequired(true)))
    .addSubcommand((sc) => sc.setName('list').setDescription('Show the current blacklist')
      .setDescriptionLocalizations({ ar: 'عرض القائمة السوداء الحالية', 'en-US': 'Show the current blacklist' }))
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  autocomplete: safeAutocomplete(async (interaction) => {
    return commandNameChoices(interaction, interaction.options.getFocused());
  }),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You need to be a guild manager to use this command.')], ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();

    if (sub === 'list') {
      return interaction.reply({
        embeds: [
          infoEmbed(settings, 'Current command blacklist').addFields(
            { name: 'Blocked users', value: guildConfig.commandBlacklist.userIds.map((id) => `<@${id}>`).join(', ') || 'None' },
            { name: 'Disabled commands', value: guildConfig.commandBlacklist.commandNames.map((c) => `\`${c}\``).join(', ') || 'None' },
            {
              name: 'Disabled per-channel',
              value:
                guildConfig.channelCommandBlacklist
                  .map((e) => `<#${e.channelId}>: ${e.commandNames.map((c) => `\`${c}\``).join(', ')}`)
                  .join('\n') || 'None',
            },
            {
              name: 'Disabled per-role',
              value:
                guildConfig.roleCommandBlacklist
                  .map((e) => `<@&${e.roleId}>: ${e.commandNames.map((c) => `\`${c}\``).join(', ')}`)
                  .join('\n') || 'None',
            }
          ),
        ],
        ephemeral: true,
      });
    }

    if (sub === 'user') {
      const target = interaction.options.getUser('user');
      const list = guildConfig.commandBlacklist.userIds;
      const idx = list.indexOf(target.id);
      if (idx === -1) list.push(target.id);
      else list.splice(idx, 1);
      await guildConfig.save();
      invalidateGuildConfig(interaction.guildId);
      return interaction.reply({ embeds: [successEmbed(settings, `${target} is ${idx === -1 ? 'now blocked from' : 'no longer blocked from'} using bot commands.`)] });
    }

    if (sub === 'command') {
      const name = interaction.options.getString('name').toLowerCase();
      if (!interaction.client.commands.has(name)) {
        return interaction.reply({ embeds: [errorEmbed(settings, `No command named \`${name}\` exists.`)], ephemeral: true });
      }
      const list = guildConfig.commandBlacklist.commandNames;
      const idx = list.indexOf(name);
      if (idx === -1) list.push(name);
      else list.splice(idx, 1);
      await guildConfig.save();
      invalidateGuildConfig(interaction.guildId);
      return interaction.reply({ embeds: [successEmbed(settings, `\`/${name}\` is ${idx === -1 ? 'now disabled' : 'now re-enabled'} in this server.`)] });
    }

    if (sub === 'channel') {
      const name = interaction.options.getString('name').toLowerCase();
      if (!interaction.client.commands.has(name)) {
        return interaction.reply({ embeds: [errorEmbed(settings, `No command named \`${name}\` exists.`)], ephemeral: true });
      }
      if (PROTECTED_COMMANDS.has(name)) {
        return interaction.reply({
          embeds: [errorEmbed(settings, `\`/${name}\` always stays usable in every channel and cannot be disabled, so it can never be locked out by mistake.`)],
          ephemeral: true,
        });
      }
      const channel = interaction.options.getChannel('channel') || interaction.channel;
      const nowDisabled = toggleCommandInChannel(guildConfig, name, channel.id);
      await guildConfig.save();
      invalidateGuildConfig(interaction.guildId);
      return interaction.reply({ embeds: [successEmbed(settings, `\`/${name}\` is ${nowDisabled ? 'now disabled' : 'now re-enabled'} in <#${channel.id}>.`)] });
    }

    if (sub === 'role') {
      const name = interaction.options.getString('name').toLowerCase();
      if (!interaction.client.commands.has(name)) {
        return interaction.reply({ embeds: [errorEmbed(settings, `No command named \`${name}\` exists.`)], ephemeral: true });
      }
      if (PROTECTED_COMMANDS.has(name)) {
        return interaction.reply({
          embeds: [errorEmbed(settings, `\`/${name}\` always stays usable for every role and cannot be disabled, so it can never be locked out by mistake.`)],
          ephemeral: true,
        });
      }
      const role = interaction.options.getRole('role');
      const nowDisabled = toggleCommandForRole(guildConfig, name, role.id);
      await guildConfig.save();
      invalidateGuildConfig(interaction.guildId);
      return interaction.reply({ embeds: [successEmbed(settings, `\`/${name}\` is ${nowDisabled ? 'now disabled' : 'now re-enabled'} for ${role}.`)] });
    }
  },
};
