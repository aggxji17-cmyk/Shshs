const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { errorEmbed } = require('../../utils/embeds');
const { isModerator } = require('../../utils/permissions');
const { buildCasesPage } = require('../../utils/caseEmbed');

module.exports = {
  data: new SlashCommandBuilder().setName('cases').setDescription('View all moderation cases for a specific member')
    .setDescriptionLocalizations({ ar: 'عرض جميع قضايا الإشراف الخاصة بعضو معين', 'en-US': 'View all moderation cases for a specific member' })
    .addUserOption((o) => o.setName('user').setDescription('The member').setDescriptionLocalizations({ ar: 'العضو', 'en-US': 'The member' }).setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isModerator(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'ليس لديك صلاحية استخدام هذا الأمر.')], ephemeral: true });
    }

    const target = interaction.options.getUser('user');
    const { embed, components } = await buildCasesPage(settings, interaction.guildId, target, 1);

    await interaction.reply({ embeds: [embed], components });
  },
};
