const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { errorEmbed } = require('../../utils/embeds');
const { isModerator } = require('../../utils/permissions');
const { getCaseById, getRecentCases, editCase } = require('../../services/caseService');
const { buildCaseEmbed } = require('../../utils/caseEmbed');
const { safeAutocomplete, fuzzyFilter, reasonChoices } = require('../../utils/autocomplete');

module.exports = {
  data: new SlashCommandBuilder().setName('editcase').setDescription('Edit a case\'s reason or add notes without changing its core data')
    .setDescriptionLocalizations({ ar: 'تعديل سبب أو إضافة ملاحظات لقضية دون تغيير بياناتها الأساسية', 'en-US': 'Edit a case\'s reason or add notes without changing its core data' })
    .addIntegerOption((o) => o.setName('case_id').setDescription('The case number').setDescriptionLocalizations({ ar: 'رقم القضية', 'en-US': 'The case number' }).setRequired(true).setMinValue(1).setAutocomplete(true))
    .addStringOption((o) => o.setName('reason').setDescription('The new reason').setDescriptionLocalizations({ ar: 'السبب الجديد', 'en-US': 'The new reason' }).setAutocomplete(true))
    .addStringOption((o) => o.setName('notes').setDescription('Additional note').setDescriptionLocalizations({ ar: 'ملاحظة إضافية', 'en-US': 'Additional note' }))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  autocomplete: safeAutocomplete(async (interaction) => {
    const focusedOption = interaction.options.getFocused(true);

    if (focusedOption.name === 'case_id') {
      if (!interaction.guildId) return [];
      const recent = await getRecentCases(interaction.guildId, 25);
      const matched = fuzzyFilter(recent, focusedOption.value, { key: (c) => String(c.caseId) });
      return matched.map((c) => ({
        name: `#${c.caseId} • ${c.action} • ${c.reason || 'No reason provided'}`,
        value: c.caseId,
      }));
    }

    if (focusedOption.name === 'reason') {
      return reasonChoices(focusedOption.value);
    }

    return [];
  }),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isModerator(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'ليس لديك صلاحية استخدام هذا الأمر.')], ephemeral: true });
    }

    const caseId = interaction.options.getInteger('case_id');
    const reason = interaction.options.getString('reason');
    const notes = interaction.options.getString('notes');

    if (reason === null && notes === null) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'يجب تحديد سبب جديد أو ملاحظة على الأقل.')], ephemeral: true });
    }

    const existing = await getCaseById(interaction.guildId, caseId);
    if (!existing) {
      return interaction.reply({ embeds: [errorEmbed(settings, `لا توجد قضية بالرقم #${caseId}.`)], ephemeral: true });
    }

    const updated = await editCase(interaction.guildId, caseId, { reason, notes });

    await interaction.reply({
      content: `✅ تم تحديث القضية #${caseId}.`,
      embeds: [buildCaseEmbed(settings, updated)],
    });
  },
};
