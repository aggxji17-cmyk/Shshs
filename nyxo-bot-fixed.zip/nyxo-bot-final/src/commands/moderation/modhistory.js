const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { errorEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');
const { RANGE_CHOICES, SORT_CHOICES } = require('../../utils/auditLabels');
const { buildModHistoryPage } = require('../../utils/auditEmbed');

module.exports = {
  data: new SlashCommandBuilder().setName('modhistory').setDescription('View a moderator\'s action history and statistics')
    .setDescriptionLocalizations({ ar: 'عرض سجل وإحصائيات عمليات الإشراف الخاصة بمشرف معين', 'en-US': 'View a moderator\'s action history and statistics' })
    .addUserOption((o) => o.setName('moderator').setDescription('The moderator').setDescriptionLocalizations({ ar: 'المشرف', 'en-US': 'The moderator' }).setRequired(true))
    .addStringOption((o) => o.setName('range').setDescription('Time period').setDescriptionLocalizations({ ar: 'الفترة الزمنية', 'en-US': 'Time period' }).addChoices(...RANGE_CHOICES))
    .addStringOption((o) => o.setName('sort').setDescription('Order').setDescriptionLocalizations({ ar: 'الترتيب', 'en-US': 'Order' }).addChoices(...SORT_CHOICES))
    // Auditing staff activity is treated as an admin-tier action, not a
    // regular moderator one - a junior mod shouldn't be able to pull up a
    // senior mod's full action history.
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'ليس لديك صلاحية استخدام هذا الأمر.')], ephemeral: true });
    }

    const moderator = interaction.options.getUser('moderator');
    const range = interaction.options.getString('range') || 'all';
    const sort = interaction.options.getString('sort') || 'newest';

    const { embed, components } = await buildModHistoryPage(settings, interaction.guildId, moderator, { range, sort, page: 1 });

    await interaction.reply({ embeds: [embed], components });
  },
};
