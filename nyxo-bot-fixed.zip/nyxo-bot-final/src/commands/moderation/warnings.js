const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { baseEmbed, errorEmbed } = require('../../utils/embeds');
const { isModerator } = require('../../utils/permissions');
const Warn = require('../../database/models/Warn');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warnings')
    .setDescription("View a member's warning history")
    .setDescriptionLocalizations({ ar: 'عرض سجل تحذيرات عضو', 'en-US': 'View a member\'s warning history' })
    .addUserOption((o) => o.setName('user').setDescription('The user to check').setDescriptionLocalizations({ ar: 'المستخدم المراد التحقق منه', 'en-US': 'The user to check' }).setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isModerator(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You do not have permission to use this command.')], ephemeral: true });
    }

    const target = interaction.options.getUser('user');
    const warns = await Warn.find({ guildId: interaction.guildId, userId: target.id }).sort({ createdAt: -1 }).limit(10);

    const embed = baseEmbed(settings).setTitle(`Warnings for ${target.tag}`);
    if (!warns.length) {
      embed.setDescription('This user has no warnings.');
    } else {
      embed.setDescription(
        warns.map((w, i) => `**${i + 1}.** ${w.reason} - <@${w.moderatorId}> (<t:${Math.floor(w.createdAt.getTime() / 1000)}:R>)`).join('\n')
      );
    }

    await interaction.reply({ embeds: [embed] });
  },
};
