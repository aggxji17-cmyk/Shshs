const {
  SlashCommandBuilder,
  PermissionsBitField,
  EmbedBuilder,
  CommandInteraction,
  ActionRowBuilder,
  ButtonBuilder,
  MessageFlags,
  ButtonStyle,
  PermissionFlagsBits,
  TextInputBuilder,
  TextInputStyle,
  ModalBuilder,
} = require("discord.js");
const { COLORS } = require("../../utils/designSystem");
const sourcebin = require("sourcebin_js");
const logger = require("../../utils/logger");
const { isOwner } = require("../../utils/permissions");

module.exports = {
  data: new SlashCommandBuilder()
    .setName(`owner`)
    .setDescription(`Commands that are for managing bot and can be used by owner only!`)
    .addSubcommandGroup((group) =>
      group
        .setName("blacklist")
        .setDescription("Manage blacklists")
        .addSubcommand((command) =>
          command
            .setName("user")
            .setDescription("Manage user blacklist")
            .addStringOption((option) =>
              option
                .setName("action")
                .setDescription("Add or remove from blacklist")
                .setRequired(true)
                .addChoices(
                  { name: "Add", value: "add" },
                  { name: "Remove", value: "remove" }
                )
            )
            .addStringOption((option) =>
              option
                .setName("userid")
                .setDescription("The user ID to blacklist/unblacklist")
                .setRequired(true)
            )
            .addStringOption((option) =>
              option
                .setName("reason")
                .setDescription("The reason for the blacklist")
                .setRequired(false)
            )
        )
        .addSubcommand((command) =>
          command
            .setName("guild")
            .setDescription("Manage guild blacklist")
            .addStringOption((option) =>
              option
                .setName("action")
                .setDescription("Add or remove from blacklist")
                .setRequired(true)
                .addChoices(
                  { name: "Add", value: "add" },
                  { name: "Remove", value: "remove" }
                )
            )
            .addStringOption((option) =>
              option
                .setName("guildid")
                .setDescription("The guild ID to blacklist/unblacklist")
                .setRequired(true)
            )
            .addStringOption((option) =>
              option
                .setName("reason")
                .setDescription("The reason for the blacklist")
                .setRequired(false)
            )
        )
    )
    .addSubcommand((command) =>
      command
        .setName(`send-changelogs`)
        .setDescription(`Send a new bot changelogs`)
    )
    .addSubcommand((command) =>
      command
        .setName(`restart`)
        .setDescription(`Shuts down and restarts bots (developer only)`)
    )
    .addSubcommand((command) =>
      command.setName("servers").setDescription("servers")
    ),
  developer: true,
  async execute(interaction, client) {
    if (!isOwner(interaction.user.id)) {
      return interaction.reply({
        content: `Only **the owner** of ${client.user} can use this command.`,
        flags: MessageFlags.Ephemeral,
      });
    }

    const subcommandGroup = interaction.options.getSubcommandGroup();
    const sub = interaction.options.getSubcommand();

    const blacklistDB = require("../../database/models/blacklistSchema");
    const guildBlacklistDB = require("../../database/models/guildBlacklistSchema");
    let embed = new EmbedBuilder();

    if (subcommandGroup === "blacklist") {
      if (sub === "user") {
        const action = interaction.options.getString("action");
        const userId = interaction.options.getString("userid");
        const reason = interaction.options.getString("reason") || "No reason provided";

        if (action === "add") {
          const blacklist = await blacklistDB.findOne({ userId });

          if (blacklist) {
            return interaction.reply({
              embeds: [
                new EmbedBuilder()
                  .setDescription(`${client.emoji.error} That user is already blacklisted`)
                  .setColor(client.config.embedColor)
              ],
              flags: MessageFlags.Ephemeral,
            });
          }

          await blacklistDB.create({ userId, reason });

          const removeButton = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
              .setLabel("🗑️ Remove")
              .setStyle(ButtonStyle.Danger)
              .setCustomId("remove")
          );

          embed
            .setTitle("User Blacklist")
            .setColor(client.config.embedColor)
            .setDescription(
              `Successfully added user \`${userId}\` to blacklist.\n**Reason:** ${reason}`
            );

          await interaction.reply({
            embeds: [embed],
            components: [removeButton],
          });

          const collector = interaction.channel.createMessageComponentCollector({
            time: 60000,
          });

          collector.on("collect", async (i) => {
            if (i.customId === "remove" && i.user.id === interaction.user.id) {
              await blacklistDB.deleteOne({ userId });
              await i.update({
                embeds: [
                  new EmbedBuilder()
                    .setTitle("User Blacklist")
                    .setDescription("Successfully removed user from blacklist")
                    .setColor(client.config.embedColor)
                ],
                components: [],
              });
            }
          });
        } else if (action === "remove") {
          const blacklist = await blacklistDB.findOne({ userId });

          if (!blacklist) {
            return interaction.reply({
              embeds: [
                new EmbedBuilder()
                  .setDescription(`${client.emoji.error} That user is not blacklisted`)
                  .setColor(client.config.embedColor)
              ],
              flags: MessageFlags.Ephemeral,
            });
          }

          await blacklistDB.deleteOne({ userId });

          embed
            .setTitle("User Blacklist")
            .setColor(client.config.embedColor)
            .setDescription(`Successfully removed user \`${userId}\` from the blacklist`);

          await interaction.reply({ embeds: [embed] });
        }
      } else if (sub === "guild") {
        const action = interaction.options.getString("action");
        const guildId = interaction.options.getString("guildid");
        const reason = interaction.options.getString("reason") || "No reason provided";

        if (action === "add") {
          const blacklist = await guildBlacklistDB.findOne({ guildId });

          if (blacklist) {
            return interaction.reply({
              embeds: [
                new EmbedBuilder()
                  .setDescription(`${client.emoji.error} That guild is already blacklisted`)
                  .setColor(client.config.embedColor)
              ],
              flags: MessageFlags.Ephemeral,
            });
          }

          await guildBlacklistDB.create({ guildId, reason });

          const guild = client.guilds.cache.get(guildId);

          if (guild) {
            try {
              const owner = await guild.fetchOwner();

              const dmEmbed = new EmbedBuilder()
                .setTitle("🚫 Server Blacklisted")
                .setDescription(
                  `Your server **${guild.name}** has been blacklisted from using ${client.user.username}.`
                )
                .addFields({ name: "Reason", value: reason })
                .setColor(COLORS.error)
                .setTimestamp();

              await owner.send({ embeds: [dmEmbed] }).catch(() => {
                logger.warn(`Could not DM owner of ${guild.name} about the blacklist.`);
              });

              await guild.leave();
            } catch (error) {
              console.error(`Error leaving guild ${guildId}:`, error);
            }
          }

          embed
            .setTitle("Guild Blacklist")
            .setColor(client.config.embedColor)
            .setDescription(
              `Successfully added guild \`${guildId}\` to blacklist.\n**Reason:** ${reason}\n${guild ? "✅ Bot has left the server" : "⚠️ Bot is not in that server"}`
            );

          await interaction.reply({ embeds: [embed] });
        } else if (action === "remove") {
          const blacklist = await guildBlacklistDB.findOne({ guildId });

          if (!blacklist) {
            return interaction.reply({
              embeds: [
                new EmbedBuilder()
                  .setDescription(`${client.emoji.error} That guild is not blacklisted`)
                  .setColor(client.config.embedColor)
              ],
              flags: MessageFlags.Ephemeral,
            });
          }

          await guildBlacklistDB.deleteOne({ guildId });

          embed
            .setTitle("Guild Blacklist")
            .setColor(client.config.embedColor)
            .setDescription(`Successfully removed guild \`${guildId}\` from the blacklist`);

          await interaction.reply({ embeds: [embed] });
        }
      }
    } else {
      // Handle other subcommands (restart, servers, send-changelogs)
      switch (sub) {
        case "restart":
          if (isOwner(interaction.user.id)) {
            await interaction.reply({
              content: `**Shutting down..**`,
              flags: MessageFlags.Ephemeral,
            });
            await client.user.setStatus("invisible");
            // Raw process.exit() used to skip index.js's shutdown() entirely -
            // no dashboard server close, no client.destroy(), no MongoDB
            // connection close, just an abrupt kill. Sending ourselves the
            // same SIGTERM the process already listens for (process managers
            // like PM2/Docker/Pterodactyl send this to restart) reuses that
            // existing graceful-shutdown path instead of adding a new one.
            process.kill(process.pid, "SIGTERM");
          } else {
            return interaction.reply({
              content: `Only **the owner** of ${client.user} can use this command.`,
              flags: MessageFlags.Ephemeral,
            });
          }
          break;

        case "servers":
          let list = "";
          client.guilds.cache.forEach((guild) => {
            list += `${guild.name} (${guild.id}) | ${guild.memberCount} Members | Owner: ${guild.ownerId}\n`;
          });

          sourcebin
            .create([
              {
                name: `Server list of ${client.user.tag}`,
                content: list,
                languageId: "js",
              },
            ])
            .then((src) => {
              interaction.reply({
                content: `My Server List - ${src.url}`,
                flags: MessageFlags.Ephemeral,
              });
            });
          break;

        case "send-changelogs":
          const modal = new ModalBuilder()
            .setCustomId("changelogs")
            .setTitle("Send changelogs");

          const title = new TextInputBuilder()
            .setCustomId("changelogs-title")
            .setLabel("Changelogs title")
            .setStyle(TextInputStyle.Short)
            .setRequired(false)
            .setMaxLength(30)
            .setPlaceholder("April changelogs");

          const description = new TextInputBuilder()
            .setCustomId("changelogs-description")
            .setLabel("Changelogs description")
            .setStyle(TextInputStyle.Paragraph)
            .setRequired(true)
            .setMaxLength(500)
            .setPlaceholder("Fixed bugs related to the help command");

          const footer = new TextInputBuilder()
            .setCustomId("changelogs-footer")
            .setLabel("Embed footer")
            .setStyle(TextInputStyle.Short)
            .setRequired(false)
            .setMaxLength(20)
            .setPlaceholder("monthly update");

          const color = new TextInputBuilder()
            .setCustomId("changelogs-color")
            .setLabel("Embed color")
            .setStyle(TextInputStyle.Short)
            .setRequired(false)
            .setMaxLength(7)
            .setMinLength(7)
            .setPlaceholder("#ffffff || #000000");

          const type = new TextInputBuilder()
            .setCustomId("changelogs-type")
            .setLabel("Changelogs type")
            .setStyle(TextInputStyle.Short)
            .setRequired(false)
            .setMaxLength(20)
            .setPlaceholder(
              "new commands implemented | bugs fixed | optimization"
            );

          const titleActionRow = new ActionRowBuilder().addComponents(title);
          const descriptionActionRow = new ActionRowBuilder().addComponents(
            description
          );
          const footerActionRow = new ActionRowBuilder().addComponents(footer);
          const colorActionRow = new ActionRowBuilder().addComponents(color);
          const typeActionRow = new ActionRowBuilder().addComponents(type);

          modal.addComponents(
            titleActionRow,
            descriptionActionRow,
            footerActionRow,
            colorActionRow,
            typeActionRow
          );

          await interaction.showModal(modal);
          break;
      }
    }
  },
};

/**
 * Credits: Arpan | @arpandevv
 * Buy: https://nyxo.buzz/buy
 */