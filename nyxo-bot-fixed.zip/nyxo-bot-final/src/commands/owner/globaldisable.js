const { SlashCommandBuilder } = require('discord.js');
const { isOwner } = require('../../utils/permissions');
const { successEmbed, errorEmbed, infoEmbed } = require('../../utils/embeds');
const { safeAutocomplete, commandNameChoices } = require('../../utils/autocomplete');
const { PROTECTED_COMMANDS } = require('../../utils/commandPermissions');
const { getBotConfig, invalidateBotConfig, toggleGlobalCommand } = require('../../utils/globalCommandBlacklist');
const { config } = require('../../config/config');

// This command isn't guild-scoped (it affects every server at once), so
// its embeds use the bot's own .env defaults rather than any one guild's
// resolved settings.
const settings = { embedColor: config.embedColor, footer: config.embedFooter };

/**
 * Bot-owner-only kill switch: disables a command across every server the
 * bot is in at once, bypassing every guild's own settings entirely. This
 * has no setDefaultMemberPermissions gate (there's no Discord permission
 * that means "bot owner") - access is controlled purely by the isOwner()
 * check in execute(), same as config.ownerIds is used everywhere else in
 * this codebase.
 */
module.exports = {
  data: new SlashCommandBuilder()
    .setName('globaldisable')
    .setDescription('[Owner only] Toggle whether a command is disabled across every server the bot is in')
    .setDescriptionLocalizations({
      ar: '[للمالك فقط] تبديل حالة تعطيل أمر في جميع السيرفرات التي يتواجد بها البوت',
      'en-US': '[Owner only] Toggle whether a command is disabled across every server the bot is in',
    })
    .addSubcommand((s) =>
      s
        .setName('toggle')
        .setDescription('Toggle a command globally')
        .setDescriptionLocalizations({ ar: 'تبديل حالة أمر بشكل شامل', 'en-US': 'Toggle a command globally' })
        .addStringOption((o) =>
          o
            .setName('name')
            .setDescription('Command name, e.g. ban')
            .setDescriptionLocalizations({ ar: 'اسم الأمر، مثل ban', 'en-US': 'Command name, e.g. ban' })
            .setRequired(true)
            .setAutocomplete(true)
        )
    )
    .addSubcommand((s) =>
      s
        .setName('list')
        .setDescription('Show every command currently disabled globally')
        .setDescriptionLocalizations({ ar: 'عرض جميع الأوامر المعطلة حالياً بشكل شامل', 'en-US': 'Show every command currently disabled globally' })
    ),

  autocomplete: safeAutocomplete(async (interaction) => {
    return commandNameChoices(interaction, interaction.options.getFocused());
  }),

  async execute(interaction) {
    if (!isOwner(interaction.user.id)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'Only the bot owner can use this command.')], ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();
    const botConfig = await getBotConfig();

    if (sub === 'list') {
      return interaction.reply({
        embeds: [
          infoEmbed(settings, 'Globally disabled commands').addFields({
            name: 'Disabled everywhere',
            value: botConfig.globalCommandBlacklist.map((c) => `\`${c}\``).join(', ') || 'None',
          }),
        ],
        ephemeral: true,
      });
    }

    const name = interaction.options.getString('name').toLowerCase();
    if (!interaction.client.commands.has(name)) {
      return interaction.reply({ embeds: [errorEmbed(settings, `No command named \`${name}\` exists.`)], ephemeral: true });
    }
    if (PROTECTED_COMMANDS.has(name)) {
      return interaction.reply({
        embeds: [errorEmbed(settings, `\`/${name}\` always stays usable everywhere and cannot be disabled, so the bot can never be locked out of its own management commands.`)],
        ephemeral: true,
      });
    }

    const nowDisabled = toggleGlobalCommand(botConfig, name);
    await botConfig.save();
    invalidateBotConfig();

    return interaction.reply({
      embeds: [successEmbed(settings, `\`/${name}\` is ${nowDisabled ? 'now disabled' : 'now re-enabled'} across every server the bot is in.`)],
      ephemeral: true,
    });
  },
};
