const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');
const moment = require('moment');
const voucher_codes = require('voucher-code-generator');
const Redeem = require("../../database/models/redeemSchema");
const Premium = require("../../database/models/premiumUserSchema");
const PremiumGuild = require('../../database/models/premiumGuildSchema.js');
const { isOwner } = require('../../utils/permissions');

module.exports = {
    data: new SlashCommandBuilder()
        .setName("premium")
        .setDescription("Manage premium codes and users.")
        .addSubcommand(subcommand =>
            subcommand
                .setName("gencode")
                .setDescription("🪙 | Create premium code for 1 user/guild")
                .addStringOption(option =>
                    option.setName("type")
                        .setDescription("User or Guild Code?")
                        .setRequired(true)
                        .addChoices({ name: "User", value: "User" }, { name: "Guild", value: "Guild" }))
                .addStringOption(option =>
                    option.setName("plan")
                        .setDescription("Select a premium plan")
                        .setAutocomplete(true)
                        .setRequired(true))
                .addStringOption(option =>
                    option.setName("amount")
                        .setDescription("How much codes do you want to make?")
                        .setRequired(false)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('premiumlist')
                .setDescription('List all premium users/guilds.'))
        .addSubcommand(subcommand =>
            subcommand
                .setName("removeguildpremium")
                .setDescription("Remove premium from a guild.")
                .addStringOption(option =>
                    option.setName("guild")
                        .setDescription("The guild to remove premium from. (Use its id.)")
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName("removepremium")
                .setDescription("Remove premium from a user.")
                .addUserOption(option =>
                    option.setName("user")
                        .setDescription("The user to remove premium from. (use their id)")
                        .setRequired(true))),
    developer: true,

    async autocomplete(interaction, client) {
        const focusedValue = interaction.options.getFocused();
        const PremiumPlan = require("../../database/models/premiumPlanSchema");
        const plans = await PremiumPlan.find({});
        
        let choices = plans.map(p => ({
            name: `${p.planName} (${p.planId}) - ${p.durationDays} Days`,
            value: p.planId
        }));

        const filtered = choices.filter(choice => 
            choice.name.toLowerCase().includes(focusedValue.toLowerCase()) || 
            choice.value.toLowerCase().includes(focusedValue.toLowerCase())
        );

        await interaction.respond(
            filtered.slice(0, 25)
        );
    },

    async execute(interaction, client) {
        // This command lives in src/commands/owner/ and can mint or
        // revoke premium access - it had no access check at all (not an
        // isOwner() call, not even a Discord-side default member
        // permission), unlike every other command in this folder. Gated
        // the same way as owner.js and globaldisable.js for consistency.
        if (!isOwner(interaction.user.id)) {
            return interaction.reply({
                content: 'Only **the bot owner** can use this command.',
                flags: MessageFlags.Ephemeral,
            });
        }

        const subcommand = interaction.options.getSubcommand();

        if (subcommand === "gencode") {
            try {
                await interaction.deferReply();
                const { options } = interaction;
                const codeType = options.getString("type");
                const planId = options.getString("plan").toLowerCase();
                const camount = options.getString("amount");

                const PremiumPlan = require("../../database/models/premiumPlanSchema");
                const dynamicPlan = await PremiumPlan.findOne({ planId: planId });

                if (!dynamicPlan) {
                    return interaction.editReply({ content: `**Invalid Plan!** You can only generate codes for plans created in the dashboard.` });
                }

                let amount = parseInt(camount) || 1;

                let codesArray = [];
                let descriptionLines = []; // Bypassing embed field limits

                for (let i = 0; i < amount; i++) {
                    const codePremium = voucher_codes.generate({
                        prefix: "PREM",
                        postfix: "RZ",
                        pattern: '-####-####-####-'
                    });
                    const code = codePremium.toString().toUpperCase();
                    // Code itself won't expire for 5 years
                    const codeExpiry = new Date(Date.now() + 5 * 365 * 24 * 60 * 60 * 1000);
                    codesArray.push({ code: code, plan: planId, codeType: codeType, expiresAt: codeExpiry });
                    descriptionLines.push(`\`${code}\` - ${codeType} - ${planId}`);
                }

                // Insert efficiently via transaction
                await Redeem.insertMany(codesArray);

                const embed = new EmbedBuilder()
                    .setColor(0xd4af37)
                    .setTitle(`Generated ${amount} Codes`)
                    .setDescription(descriptionLines.join('\\n'))
                    .setAuthor({ name: interaction.user.username, iconURL: interaction.user.displayAvatarURL() })
                    .setTimestamp();

                await interaction.editReply({ embeds: [embed] });
            } catch (error) {
                console.error(error);
                await interaction.editReply({ content: 'An error occurred while executing this command.', flags: MessageFlags.Ephemeral });
            }
        } else if (subcommand === 'premiumlist') {
            try {
                const premiums = await Premium.find({ isPremium: true });
                const premiumguilds = await PremiumGuild.find({ isPremiumGuild: true });
                const embed = new EmbedBuilder()
                    .setColor('#f7d864')
                    .setTitle('List of Premium Users/Guilds')
                    .setDescription(`There are currently **${premiums.length}** premium users and **${premiumguilds.length}** premium guilds.`)
                    .setTimestamp();

                await interaction.reply({ embeds: [embed] });
            } catch (error) {
                console.error(error);
                await interaction.reply({ content: "An error occurred while fetching the premium list.", flags: MessageFlags.Ephemeral });
            }
        } else if (subcommand === "removeguildpremium") {
            const guild = interaction.options.getString("guild");
            try {
                const premiumGuild = await PremiumGuild.findOne({ id: guild, isPremiumGuild: true });
                if (!premiumGuild) {
                    return interaction.reply({ content: "This guild does not have premium.", flags: MessageFlags.Ephemeral });
                }

                premiumGuild.isPremiumGuild = false;
                await premiumGuild.save();
                return interaction.reply({ content: "Premium has been removed from this guild.", flags: MessageFlags.Ephemeral });
            } catch (error) {
                console.error(error);
                return interaction.reply({ content: "An error occurred while removing premium from this guild.", flags: MessageFlags.Ephemeral });
            }
        } else if (subcommand === "removepremium") {
            const user = interaction.options.getUser('user');
            try {
                const premium = await Premium.findOne({ id: user.id, isPremium: true });
                if (!premium) {
                    return interaction.reply({ content: "This user does not have premium.", flags: MessageFlags.Ephemeral });
                }

                premium.isPremium = false;
                await premium.save();
                return interaction.reply({ content: "Premium has been removed from this user.", flags: MessageFlags.Ephemeral });
            } catch (error) {
                console.error(error);
                return interaction.reply({ content: "An error occurred while removing premium from this user.", flags: MessageFlags.Ephemeral });
            }
        }
    }
};