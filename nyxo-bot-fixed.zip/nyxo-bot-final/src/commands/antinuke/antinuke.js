const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved, invalidateGuildConfig } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed, baseEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('antinuke')
    .setDescription('Configure the anti-nuke protection system')
    .setDescriptionLocalizations({ ar: 'إعداد نظام الحماية من تخريب السيرفر (Anti-Nuke)', 'en-US': 'Configure the anti-nuke protection system' })
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand((s) => s.setName('status').setDescription('View the current Anti-Nuke configuration')
      .setDescriptionLocalizations({ ar: 'عرض إعدادات Anti-Nuke الحالية', 'en-US': 'View the current Anti-Nuke configuration' }))
    .addSubcommand((s) => s.setName('toggle').setDescription('Enable or disable Anti-Nuke protection')
      .setDescriptionLocalizations({ ar: 'تفعيل أو تعطيل حماية Anti-Nuke', 'en-US': 'Enable or disable Anti-Nuke protection' }))
    .addSubcommand((s) =>
      s
        .setName('punishment')
        .setDescription('Set what happens to a detected attacker')
      .setDescriptionLocalizations({ ar: 'تحديد ما يحدث للمهاجم عند اكتشافه', 'en-US': 'Set what happens to a detected attacker' })
        .addStringOption((o) =>
          o
            .setName('type')
            .setDescription('Punishment type').setDescriptionLocalizations({ ar: 'نوع العقوبة', 'en-US': 'Punishment type' })
            .setRequired(true)
            .addChoices(
              { name: 'Strip Roles', value: 'stripRoles' },
              { name: 'Kick', value: 'kick' },
              { name: 'Ban', value: 'ban' }
            )
        )
    )
    .addSubcommand((s) =>
      s
        .setName('whitelist')
        .setDescription('Add or remove a trusted user from Anti-Nuke checks')
      .setDescriptionLocalizations({ ar: 'إضافة أو إزالة مستخدم موثوق من فحوصات Anti-Nuke', 'en-US': 'Add or remove a trusted user from Anti-Nuke checks' })
        .addUserOption((o) => o.setName('user').setDescription('User to whitelist/unwhitelist').setDescriptionLocalizations({ ar: 'المستخدم المراد إضافته/إزالته من القائمة الموثوقة', 'en-US': 'User to whitelist/unwhitelist' }).setRequired(true))
    ),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You need Administrator permission to use this command.')], ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();

    if (sub === 'status') {
      const n = guildConfig.antinuke;
      const embed = baseEmbed(settings)
        .setTitle('Anti-Nuke Configuration')
        .addFields(
          { name: 'Enabled', value: n.enabled ? '✅' : '❌', inline: true },
          { name: 'Punishment', value: n.punishment, inline: true },
          { name: 'Whitelisted Users', value: n.whitelistedUserIds.length ? n.whitelistedUserIds.map((id) => `<@${id}>`).join(', ') : 'None' }
        );
      return interaction.reply({ embeds: [embed] });
    }

    if (sub === 'toggle') {
      guildConfig.antinuke.enabled = !guildConfig.antinuke.enabled;
      await guildConfig.save();
      invalidateGuildConfig(interaction.guildId);
      return interaction.reply({
        embeds: [successEmbed(settings, `Anti-Nuke protection is now **${guildConfig.antinuke.enabled ? 'enabled' : 'disabled'}**.`)],
      });
    }

    if (sub === 'punishment') {
      guildConfig.antinuke.punishment = interaction.options.getString('type');
      await guildConfig.save();
      invalidateGuildConfig(interaction.guildId);
      return interaction.reply({ embeds: [successEmbed(settings, `Punishment set to **${guildConfig.antinuke.punishment}**.`)] });
    }

    if (sub === 'whitelist') {
      const user = interaction.options.getUser('user');
      const list = guildConfig.antinuke.whitelistedUserIds;
      const idx = list.indexOf(user.id);

      if (idx === -1) list.push(user.id);
      else list.splice(idx, 1);

      await guildConfig.save();
      invalidateGuildConfig(interaction.guildId);
      return interaction.reply({
        embeds: [successEmbed(settings, `**${user.tag}** is ${idx === -1 ? 'now whitelisted' : 'no longer whitelisted'}.`)],
      });
    }
  },
};
