const { SlashCommandBuilder } = require("@discordjs/builders");
const { CommandInteraction, EmbedBuilder } = require("discord.js");
const { COLORS } = require("../../utils/designSystem");
const moment = require("moment");
const PremiumUser = require('../../database/models/premiumUserSchema');
const PremiumGuild = require('../../database/models/premiumGuildSchema');
const PremiumPlan = require('../../database/models/premiumPlanSchema');
const Redeem = require("../../database/models/redeemSchema");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("redeem")
        .setDescription("Redeem a premium code for yourself or your server!")
        .addStringOption((option) =>
            option.setName("code")
                .setDescription("The code you want to redeem")
                .setRequired(true)
        ),

    async execute(interaction = new CommandInteraction()) {
        await interaction.deferReply();
        const codeString = interaction.options.getString("code").toUpperCase();

        const redeem = await Redeem.findOne({ code: codeString });
        if (!redeem) {
            const embed = new EmbedBuilder()
                .setColor(COLORS.error)
                .setDescription("Invalid code! Please check that you entered the code correctly and it has not been used before.");
            return interaction.editReply({ embeds: [embed] });
        }

        // Check if plan exists (Legacy string plan vs dynamic DB plan)
        let durationObj = null;
        let pPlanName = redeem.plan;

        const dbPlan = await PremiumPlan.findOne({ planId: redeem.plan });
        if (dbPlan) {
            durationObj = moment().add(dbPlan.durationDays, 'days');
            pPlanName = dbPlan.planName;
        } else {
            // Fallback for codes generated using the old strings
            if (redeem.plan === 'daily') durationObj = moment().add(1, 'days');
            else if (redeem.plan === 'weekly') durationObj = moment().add(7, 'days');
            else if (redeem.plan === 'monthly') durationObj = moment().add(1, 'months');
            else if (redeem.plan === 'yearly') durationObj = moment().add(1, 'years');
            else if (redeem.plan === 'lifetime') durationObj = moment().add(100, 'years');
            else durationObj = moment().add(30, 'days'); // fallback
        }

        const isGuildCode = (redeem.codeType === 'Guild');

        if (isGuildCode) {
            // Guild Redeem Logic
            let guildDoc = await PremiumGuild.findOne({ id: interaction.guild.id });

            if (guildDoc && guildDoc.isPremiumGuild) {
                // Stack Time
                const newExpiry = moment(guildDoc.premium.expiresAt).add(durationObj.diff(moment(), 'days'), 'days');
                guildDoc.premium.expiresAt = newExpiry.toDate();
                guildDoc.premium.plan = pPlanName;
                guildDoc.premium.redeemedBy.push(interaction.user.id);
                guildDoc.premium.redeemedAt = Date.now();
                await guildDoc.save();

                await redeem.deleteOne();
                const embed = new EmbedBuilder().setColor(COLORS.success).setTitle("Premium Extended!").setDescription(`🎉 **Added Plan:** \`${pPlanName}\`\n📆 **New Expiry:** \`${newExpiry.format("Do MMMM YYYY")}\``);
                return interaction.editReply({ embeds: [embed] });
            } else {
                if (guildDoc) {
                    guildDoc.isPremiumGuild = true;
                    guildDoc.premium.expiresAt = durationObj.toDate();
                    guildDoc.premium.plan = pPlanName;
                    guildDoc.premium.redeemedBy = [interaction.user.id];
                    guildDoc.premium.redeemedAt = Date.now();
                    await guildDoc.save();
                } else {
                    await PremiumGuild.create({
                        id: interaction.guild.id,
                        isPremiumGuild: true,
                        premium: { expiresAt: durationObj.toDate(), plan: pPlanName, redeemedBy: [interaction.user.id], redeemedAt: Date.now() },
                    });
                }
            }
        } else {
            // User Redeem Logic
            let userDoc = await PremiumUser.findOne({ id: interaction.user.id });

            if (userDoc && userDoc.isPremium) {
                // Stack Time
                const newExpiry = moment(userDoc.premium.expiresAt).add(durationObj.diff(moment(), 'days'), 'days');
                userDoc.premium.expiresAt = newExpiry.toDate();
                userDoc.premium.plan = pPlanName;
                userDoc.premium.redeemedBy.push(interaction.user.id);
                userDoc.premium.redeemedAt = Date.now();
                await userDoc.save();

                await redeem.deleteOne();
                const embed = new EmbedBuilder().setColor(COLORS.success).setTitle("Premium Extended!").setDescription(`🎉 **Added Plan:** \`${pPlanName}\`\n📆 **New Expiry:** \`${newExpiry.format("Do MMMM YYYY")}\``);
                return interaction.editReply({ embeds: [embed] });
            } else {
                if (userDoc) {
                    userDoc.isPremium = true;
                    userDoc.premium.expiresAt = durationObj.toDate();
                    userDoc.premium.plan = pPlanName;
                    userDoc.premium.redeemedBy = [interaction.user.id];
                    userDoc.premium.redeemedAt = Date.now();
                    await userDoc.save();
                } else {
                    await PremiumUser.create({
                        id: interaction.user.id,
                        isPremium: true,
                        premium: { expiresAt: durationObj.toDate(), plan: pPlanName, redeemedBy: [interaction.user.id], redeemedAt: Date.now() },
                    });
                }
            }
        }

        await redeem.deleteOne();

        const embed = new EmbedBuilder()
            .setColor(COLORS.success)
            .setTitle(isGuildCode ? "Guild Premium activated!" : "Premium activated!")
            .setDescription(`🎉 **Subscribed:** \`${pPlanName}\`\n📆 **Expires:** \`${durationObj.format("Do MMMM YYYY")}\``);

        return interaction.editReply({ embeds: [embed] });
    },
};
