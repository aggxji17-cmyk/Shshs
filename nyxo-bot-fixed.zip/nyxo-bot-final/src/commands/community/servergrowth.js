const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');
const { getGrowthHistory } = require('../../services/memberGrowthService');
const { config } = require('../../config/config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('servergrowth')
    .setDescription('View this server\'s member count trend over the last two weeks.')
    .setDescriptionLocalizations({ ar: 'اعرض اتجاه عدد أعضاء السيرفر خلال آخر أسبوعين.' }),

  async execute(interaction) {
    const history = await getGrowthHistory(interaction.guild.id, 14);

    if (history.length < 2) {
      return interaction.reply({
        content: 'Not enough data yet - check back in a day or two. / لا توجد بيانات كافية بعد، تحقق مرة أخرى خلال يوم أو يومين.',
        flags: MessageFlags.Ephemeral,
      });
    }

    const first = history[0];
    const last = history[history.length - 1];
    const diff = last.count - first.count;
    const diffLabel = diff > 0 ? `+${diff}` : `${diff}`;

    const lines = history
      .map((point) => `\`${point.date.toISOString().slice(0, 10)}\` — **${point.count}** members`)
      .join('\n');

    const embed = new EmbedBuilder()
      .setColor(config.embedColor)
      .setTitle('📈 Member Growth')
      .setDescription(lines)
      .addFields({ name: 'Net change', value: `${diffLabel} members since ${first.date.toISOString().slice(0, 10)}` })
      .setFooter({ text: config.embedFooter })
      .setTimestamp();

    return interaction.reply({ embeds: [embed] });
  },
};
