const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('about')
    .setDescription('معلومات عن البوت'),

  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setColor(0x2f3136)
      .setTitle('🤖 About the Bot')
      .setDescription(
        '**RespectMC System**\n\n' +
        '👤 Developer: **AGHILAS**\n' +
        '📅 Year: **2026**\n' +
        '© All rights reserved'
      )
      .setFooter({ text: 'RespectMC © 2026' });

    await interaction.reply({ embeds: [embed] });
  },
};