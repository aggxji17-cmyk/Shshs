const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved, invalidateGuildConfig } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('autorole')
    .setDescription('Set the role automatically given to new members')
    .setDescriptionLocalizations({ ar: 'تعيين الرتبة التي تُمنح تلقائياً للأعضاء الجدد', 'en-US': 'Set the role automatically given to new members' })
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addRoleOption((o) => o.setName('role').setDescription('Role to auto-assign (omit to disable)').setDescriptionLocalizations({ ar: 'الرتبة التي تُمنح تلقائياً (اتركه فارغاً للتعطيل)', 'en-US': 'Role to auto-assign (omit to disable)' })),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You need Manage Server permission to use this command.')], ephemeral: true });
    }

    const role = interaction.options.getRole('role');

    if (role && !role.editable) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'I cannot assign that role (it may be above my highest role).')], ephemeral: true });
    }

    guildConfig.autoRoleId = role?.id || null;
    await guildConfig.save();
    invalidateGuildConfig(interaction.guildId);

    await interaction.reply({
      embeds: [successEmbed(settings, role ? `New members will automatically receive **${role.name}**.` : 'Autorole disabled.')],
    });
  },
};
