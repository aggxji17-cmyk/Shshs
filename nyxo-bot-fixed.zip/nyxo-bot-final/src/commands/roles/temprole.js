const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed, baseEmbed } = require('../../utils/embeds');
const { isModerator } = require('../../utils/permissions');
const { outranksExecutor } = require('../../utils/moderationGuards');
const { parseDuration } = require('../../utils/duration');
const scheduleService = require('../../services/scheduleService');
const tempRoleService = require('../../services/tempRoleService');

const MIN_DELAY_MS = 60_000; // 1 minute
const MAX_DELAY_MS = 365 * 86_400_000; // 1 year
const ACTION = 'temprole_remove';

/** Parses+validates the shared `time` option. Returns a ms duration, or null (with the error already sent) if invalid. */
async function resolveDurationMs(interaction, settings) {
  const durationMs = parseDuration(interaction.options.getString('time'));
  if (!durationMs || durationMs < MIN_DELAY_MS || durationMs > MAX_DELAY_MS) {
    await interaction.reply({
      embeds: [errorEmbed(settings, 'Give a valid duration between 1 minute and 1 year, e.g. `10m`, `2h30m`, `7d`.')],
      ephemeral: true,
    });
    return null;
  }
  return durationMs;
}

/** Looks up the Pending temprole task for user+role, or replies with a not-found error and returns null. */
async function findTaskOrReply(interaction, settings, guildId, userId, roleId) {
  const task = await scheduleService.findPendingTask(guildId, ACTION, userId, roleId);
  if (!task) {
    await interaction.reply({ embeds: [errorEmbed(settings, 'No active temp-role task found for that member and role.')], ephemeral: true });
    return null;
  }
  return task;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('temprole')
    .setDescription('Give and manage temporary roles')
    .setDescriptionLocalizations({ ar: 'منح الرتب المؤقتة وإدارتها', 'en-US': 'Give and manage temporary roles' })
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
    .addSubcommand((s) =>
      s
        .setName('add')
        .setDescription('Give a member a role that is automatically removed later')
      .setDescriptionLocalizations({ ar: 'منح عضو رتبة تُزال تلقائياً لاحقاً', 'en-US': 'Give a member a role that is automatically removed later' })
        .addUserOption((o) => o.setName('user').setDescription('Member to give the role to').setDescriptionLocalizations({ ar: 'العضو الذي ستُمنح له الرتبة', 'en-US': 'Member to give the role to' }).setRequired(true))
        .addRoleOption((o) => o.setName('role').setDescription('Role to grant').setDescriptionLocalizations({ ar: 'الرتبة المراد منحها', 'en-US': 'Role to grant' }).setRequired(true))
        .addStringOption((o) => o.setName('time').setDescription('How long they keep it, e.g. 10m, 2h30m, 7d').setDescriptionLocalizations({ ar: 'المدة التي سيحتفظ بها بها، مثل 10m أو 2h30m أو 7d', 'en-US': 'How long they keep it, e.g. 10m, 2h30m, 7d' }).setRequired(true))
        .addStringOption((o) => o.setName('reason').setDescription('Reason for granting the role').setDescriptionLocalizations({ ar: 'سبب منح الرتبة', 'en-US': 'Reason for granting the role' }))
    )
    .addSubcommand((s) =>
      s
        .setName('remove')
        .setDescription('Remove a temp role before its time is up')
      .setDescriptionLocalizations({ ar: 'إزالة رتبة مؤقتة قبل انتهاء مدتها', 'en-US': 'Remove a temp role before its time is up' })
        .addUserOption((o) => o.setName('user').setDescription('Member to update').setDescriptionLocalizations({ ar: 'العضو المراد تحديثه', 'en-US': 'Member to update' }).setRequired(true))
        .addRoleOption((o) => o.setName('role').setDescription('Role to remove').setDescriptionLocalizations({ ar: 'الرتبة المراد إزالتها', 'en-US': 'Role to remove' }).setRequired(true))
    )
    .addSubcommand((s) => s.setName('list').setDescription('List every active temp role in this server')
      .setDescriptionLocalizations({ ar: 'عرض جميع الرتب المؤقتة النشطة في هذا السيرفر', 'en-US': 'List every active temp role in this server' }))
    .addSubcommand((s) =>
      s
        .setName('extend')
        .setDescription('Extend how long a member keeps a temp role')
      .setDescriptionLocalizations({ ar: 'تمديد مدة احتفاظ عضو برتبة مؤقتة', 'en-US': 'Extend how long a member keeps a temp role' })
        .addUserOption((o) => o.setName('user').setDescription('Member to update').setDescriptionLocalizations({ ar: 'العضو المراد تحديثه', 'en-US': 'Member to update' }).setRequired(true))
        .addRoleOption((o) => o.setName('role').setDescription('Role to extend').setDescriptionLocalizations({ ar: 'الرتبة المراد تمديدها', 'en-US': 'Role to extend' }).setRequired(true))
        .addStringOption((o) => o.setName('time').setDescription('How much longer, e.g. 10m, 2h30m, 7d').setDescriptionLocalizations({ ar: 'المدة الإضافية، مثل 10m أو 2h30m أو 7d', 'en-US': 'How much longer, e.g. 10m, 2h30m, 7d' }).setRequired(true))
    )
    .addSubcommand((s) =>
      s
        .setName('cancel')
        .setDescription('Cancel the expiry and keep the role permanently')
      .setDescriptionLocalizations({ ar: 'إلغاء انتهاء الصلاحية والاحتفاظ بالرتبة بشكل دائم', 'en-US': 'Cancel the expiry and keep the role permanently' })
        .addUserOption((o) => o.setName('user').setDescription('Member to update').setDescriptionLocalizations({ ar: 'العضو المراد تحديثه', 'en-US': 'Member to update' }).setRequired(true))
        .addRoleOption((o) => o.setName('role').setDescription('Role to make permanent').setDescriptionLocalizations({ ar: 'الرتبة المراد جعلها دائمة', 'en-US': 'Role to make permanent' }).setRequired(true))
    ),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isModerator(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'ليس لديك صلاحية استخدام هذا الأمر.')], ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();

    if (sub === 'add') {
      const user = interaction.options.getUser('user');
      const role = interaction.options.getRole('role');
      const reason = interaction.options.getString('reason') || 'No reason provided';

      const member = await interaction.guild.members.fetch(user.id).catch(() => null);
      if (!member) return interaction.reply({ embeds: [errorEmbed(settings, 'That user is not in this server.')], ephemeral: true });

      if (!role.editable) {
        return interaction.reply({ embeds: [errorEmbed(settings, 'I cannot manage that role (it may be above my highest role).')], ephemeral: true });
      }
      if (outranksExecutor(interaction, member)) {
        return interaction.reply({ embeds: [errorEmbed(settings, 'لا يمكنك إعطاء رتبة لعضو رتبته أعلى من رتبتك أو مساوية لها.')], ephemeral: true });
      }
      if (member.roles.cache.has(role.id)) {
        return interaction.reply({ embeds: [errorEmbed(settings, `**${user.tag}** already has **${role.name}**.`)], ephemeral: true });
      }

      const durationMs = await resolveDurationMs(interaction, settings);
      if (!durationMs) return;
      const executeAt = new Date(Date.now() + durationMs);

      let task;
      try {
        task = await tempRoleService.addTempRole(interaction.client, {
          guild: interaction.guild,
          member,
          role,
          moderatorId: interaction.user.id,
          reason,
          executeAt,
        });
      } catch (err) {
        return interaction.reply({ embeds: [errorEmbed(settings, err.message)], ephemeral: true });
      }

      return interaction.reply({
        embeds: [
          successEmbed(
            settings,
            `Gave **${role.name}** to **${user.tag}** until <t:${Math.floor(executeAt.getTime() / 1000)}:F> (<t:${Math.floor(executeAt.getTime() / 1000)}:R>).\nTask ID: \`${task._id}\``
          ),
        ],
      });
    }

    if (sub === 'remove') {
      const user = interaction.options.getUser('user');
      const role = interaction.options.getRole('role');

      const task = await findTaskOrReply(interaction, settings, interaction.guildId, user.id, role.id);
      if (!task) return;

      if (!role.editable) {
        return interaction.reply({ embeds: [errorEmbed(settings, 'I cannot manage that role (it may be above my highest role).')], ephemeral: true });
      }

      await tempRoleService.removeTempRoleEarly(interaction.client, interaction.guild, task, interaction.user.id);

      return interaction.reply({ embeds: [successEmbed(settings, `Removed **${role.name}** from **${user.tag}** early.`)] });
    }

    if (sub === 'list') {
      const tasks = await scheduleService.listScheduledTasks(interaction.guildId, { status: 'Pending', action: ACTION, limit: 25 });

      if (!tasks.length) {
        return interaction.reply({ embeds: [errorEmbed(settings, 'No active temp roles in this server.')], ephemeral: true });
      }

      const embed = baseEmbed(settings)
        .setTitle('Active Temp Roles')
        .setDescription(
          tasks
            .map((t) => {
              const when = `<t:${Math.floor(t.executeAt.getTime() / 1000)}:R>`;
              return `<@&${t.roleId}> on <@${t.targetId}> - expires ${when}\nID: \`${t._id}\` - given by <@${t.moderatorId}>`;
            })
            .join('\n\n')
        );

      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    if (sub === 'extend') {
      const user = interaction.options.getUser('user');
      const role = interaction.options.getRole('role');

      const task = await findTaskOrReply(interaction, settings, interaction.guildId, user.id, role.id);
      if (!task) return;

      const durationMs = await resolveDurationMs(interaction, settings);
      if (!durationMs) return;

      const extended = await scheduleService.extendScheduledTask(interaction.guildId, task._id, durationMs);
      if (!extended || extended.status !== 'Pending') {
        return interaction.reply({ embeds: [errorEmbed(settings, 'That task is no longer active and cannot be extended.')], ephemeral: true });
      }

      return interaction.reply({
        embeds: [successEmbed(settings, `**${role.name}** on **${user.tag}** now expires <t:${Math.floor(extended.executeAt.getTime() / 1000)}:R>.`)],
      });
    }

    if (sub === 'cancel') {
      const user = interaction.options.getUser('user');
      const role = interaction.options.getRole('role');

      const task = await findTaskOrReply(interaction, settings, interaction.guildId, user.id, role.id);
      if (!task) return;

      const cancelled = await scheduleService.cancelScheduledTask(interaction.guildId, task._id, interaction.user.id);
      if (!cancelled || cancelled.status !== 'Cancelled') {
        return interaction.reply({ embeds: [errorEmbed(settings, 'That task is no longer active and cannot be cancelled.')], ephemeral: true });
      }

      return interaction.reply({ embeds: [successEmbed(settings, `**${role.name}** on **${user.tag}** will no longer expire - it is now permanent.`)] });
    }
  },
};
