const { SlashCommandBuilder, PermissionFlagsBits, StringSelectMenuBuilder, ActionRowBuilder } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed, baseEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('rolemenu')
    .setDescription('Post a self-assignable role selection menu')
    .setDescriptionLocalizations({ ar: 'نشر قائمة رتب يمكن للأعضاء اختيارها بأنفسهم', 'en-US': 'Post a self-assignable role selection menu' })
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
    .addStringOption((o) => o.setName('title').setDescription('Title for the role menu').setDescriptionLocalizations({ ar: 'عنوان قائمة الرتب', 'en-US': 'Title for the role menu' }).setRequired(true))
    .addRoleOption((o) => o.setName('role1').setDescription('Role option 1').setDescriptionLocalizations({ ar: 'الرتبة 1', 'en-US': 'Role option 1' }).setRequired(true))
    .addRoleOption((o) => o.setName('role2').setDescription('Role option 2').setDescriptionLocalizations({ ar: 'الرتبة 2', 'en-US': 'Role option 2' }))
    .addRoleOption((o) => o.setName('role3').setDescription('Role option 3').setDescriptionLocalizations({ ar: 'الرتبة 3', 'en-US': 'Role option 3' }))
    .addRoleOption((o) => o.setName('role4').setDescription('Role option 4').setDescriptionLocalizations({ ar: 'الرتبة 4', 'en-US': 'Role option 4' }))
    .addRoleOption((o) => o.setName('role5').setDescription('Role option 5').setDescriptionLocalizations({ ar: 'الرتبة 5', 'en-US': 'Role option 5' })),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You need Manage Roles permission to use this command.')], ephemeral: true });
    }

    const title = interaction.options.getString('title');
    const roles = [1, 2, 3, 4, 5]
      .map((i) => interaction.options.getRole(`role${i}`))
      .filter(Boolean);

    const unassignable = roles.find((r) => !r.editable);
    if (unassignable) {
      return interaction.reply({
        embeds: [errorEmbed(settings, `I cannot assign **${unassignable.name}** (it may be above my highest role).`)],
        ephemeral: true,
      });
    }

    const menu = new StringSelectMenuBuilder()
      .setCustomId('rolemenu_select')
      .setPlaceholder('Select your roles...')
      .setMinValues(0)
      .setMaxValues(roles.length)
      .addOptions(roles.map((r) => ({ label: r.name, value: r.id })));

    await interaction.reply({
      embeds: [baseEmbed(settings).setTitle(title).setDescription('Select any roles below to add them, deselect to remove.')],
      components: [new ActionRowBuilder().addComponents(menu)],
    });
  },
};
