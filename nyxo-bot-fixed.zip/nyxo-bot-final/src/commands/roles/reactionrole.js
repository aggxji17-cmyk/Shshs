const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');
const { emojiKey } = require('../../services/reactionRoleService');
const ReactionRole = require('../../database/models/ReactionRole');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('reactionrole')
    .setDescription('Grant a role when members react to a message with an emoji')
    .setDescriptionLocalizations({ ar: 'منح رتبة عند تفاعل الأعضاء برمز على رسالة', 'en-US': 'Grant a role when members react to a message with an emoji' })
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
    .addSubcommand((s) =>
      s
        .setName('add')
        .setDescription('Add a reaction-role mapping to a message')
      .setDescriptionLocalizations({ ar: 'إضافة ربط بين تفاعل ورتبة على رسالة', 'en-US': 'Add a reaction-role mapping to a message' })
        .addStringOption((o) => o.setName('message_id').setDescription('ID of the message to react to').setDescriptionLocalizations({ ar: 'معرّف الرسالة المراد التفاعل معها', 'en-US': 'ID of the message to react to' }).setRequired(true))
        .addStringOption((o) => o.setName('emoji').setDescription('Emoji members will react with').setDescriptionLocalizations({ ar: 'الإيموجي الذي سيتفاعل به الأعضاء', 'en-US': 'Emoji members will react with' }).setRequired(true))
        .addRoleOption((o) => o.setName('role').setDescription('Role to grant').setDescriptionLocalizations({ ar: 'الرتبة المراد منحها', 'en-US': 'Role to grant' }).setRequired(true))
    )
    .addSubcommand((s) =>
      s
        .setName('remove')
        .setDescription('Remove a reaction-role mapping')
      .setDescriptionLocalizations({ ar: 'إزالة ربط بين تفاعل ورتبة', 'en-US': 'Remove a reaction-role mapping' })
        .addStringOption((o) => o.setName('message_id').setDescription('ID of the message').setDescriptionLocalizations({ ar: 'معرّف الرسالة', 'en-US': 'ID of the message' }).setRequired(true))
        .addStringOption((o) => o.setName('emoji').setDescription('Emoji to remove').setDescriptionLocalizations({ ar: 'الإيموجي المراد إزالته', 'en-US': 'Emoji to remove' }).setRequired(true))
    ),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You need Manage Roles permission to use this command.')], ephemeral: true });
    }

    const messageId = interaction.options.getString('message_id');
    const emojiInput = interaction.options.getString('emoji');
    const message = await interaction.channel.messages.fetch(messageId).catch(() => null);

    if (!message) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'Could not find that message in this channel.')], ephemeral: true });
    }

    if (interaction.options.getSubcommand() === 'remove') {
      const config = await ReactionRole.findOne({ messageId });
      if (!config) return interaction.reply({ embeds: [errorEmbed(settings, 'No reaction-role mappings exist on that message.')], ephemeral: true });

      config.mappings = config.mappings.filter((m) => m.emoji !== emojiInput);
      await config.save();
      return interaction.reply({ embeds: [successEmbed(settings, 'Mapping removed.')], ephemeral: true });
    }

    const role = interaction.options.getRole('role');
    if (!role.editable) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'I cannot assign that role (it may be above my highest role).')], ephemeral: true });
    }

    await message.react(emojiInput).catch(() => null);
    const emoji = message.reactions.cache.find((r) => r.emoji.toString() === emojiInput || r.emoji.name === emojiInput)?.emoji;
    const storedEmoji = emoji ? emojiKey(emoji) : emojiInput;

    await ReactionRole.findOneAndUpdate(
      { messageId },
      {
        $setOnInsert: { guildId: interaction.guildId, channelId: interaction.channelId },
        $pull: { mappings: { emoji: storedEmoji } },
      },
      { upsert: true }
    );
    await ReactionRole.updateOne({ messageId }, { $push: { mappings: { emoji: storedEmoji, roleId: role.id } } });

    return interaction.reply({ embeds: [successEmbed(settings, `Reacting with ${emojiInput} on that message now grants **${role.name}**.`)], ephemeral: true });
  },
};
