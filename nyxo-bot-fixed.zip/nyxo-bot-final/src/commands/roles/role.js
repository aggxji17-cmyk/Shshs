const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { isModerator } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('role')
    .setDescription('Add or remove a role from a member')
    .setDescriptionLocalizations({ ar: 'إضافة أو إزالة رتبة من عضو', 'en-US': 'Add or remove a role from a member' })
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
    .addSubcommand((s) =>
      s
        .setName('add')
        .setDescription('Add a role to a member')
      .setDescriptionLocalizations({ ar: 'إضافة رتبة لعضو', 'en-US': 'Add a role to a member' })
        .addUserOption((o) => o.setName('user').setDescription('Member to update').setDescriptionLocalizations({ ar: 'العضو المراد تحديثه', 'en-US': 'Member to update' }).setRequired(true))
        .addRoleOption((o) => o.setName('role').setDescription('Role to add').setDescriptionLocalizations({ ar: 'الرتبة المراد إضافتها', 'en-US': 'Role to add' }).setRequired(true))
    )
    .addSubcommand((s) =>
      s
        .setName('remove')
        .setDescription('Remove a role from a member')
      .setDescriptionLocalizations({ ar: 'إزالة رتبة من عضو', 'en-US': 'Remove a role from a member' })
        .addUserOption((o) => o.setName('user').setDescription('Member to update').setDescriptionLocalizations({ ar: 'العضو المراد تحديثه', 'en-US': 'Member to update' }).setRequired(true))
        .addRoleOption((o) => o.setName('role').setDescription('Role to remove').setDescriptionLocalizations({ ar: 'الرتبة المراد إزالتها', 'en-US': 'Role to remove' }).setRequired(true))
    ),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isModerator(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You do not have permission to use this command.')], ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();
    const user = interaction.options.getUser('user');
    const role = interaction.options.getRole('role');

    const member = await interaction.guild.members.fetch(user.id).catch(() => null);
    if (!member) return interaction.reply({ embeds: [errorEmbed(settings, 'That user is not in this server.')], ephemeral: true });

    if (!role.editable) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'I cannot manage that role (it may be above my highest role).')], ephemeral: true });
    }

    if (sub === 'add') {
      await member.roles.add(role);
      await interaction.reply({ embeds: [successEmbed(settings, `Added **${role.name}** to **${user.tag}**.`)] });
    } else {
      await member.roles.remove(role);
      await interaction.reply({ embeds: [successEmbed(settings, `Removed **${role.name}** from **${user.tag}**.`)] });
    }
  },
};
