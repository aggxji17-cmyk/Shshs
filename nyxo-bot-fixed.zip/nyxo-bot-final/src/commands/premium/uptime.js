const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require('discord.js');
const { COLORS } = require('../../utils/designSystem');
const uptimeSchema = require('../../database/models/uptimeSchema');
const { URL } = require('url');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('uptime')
    .setDescription('Advanced uptime monitor')
    .addSubcommand(s => s.setName('add').setDescription('Add a URL to monitor')
      .addStringOption(o => o.setName('url').setDescription('URL to monitor').setRequired(true))
      .addIntegerOption(o => o.setName('interval').setDescription('Interval in minutes (1-60)'))
      .addStringOption(o => o.setName('name').setDescription('Friendly name')))
    .addSubcommand(s => s.setName('delete').setDescription('Remove a monitored URL')
      .addStringOption(o => o.setName('url').setDescription('URL to remove').setRequired(true)))
    .addSubcommand(s => s.setName('list').setDescription('List monitored URLs'))
    .addSubcommand(s => s.setName('info').setDescription('Get detailed info for a URL')
      .addStringOption(o => o.setName('url').setDescription('URL to inspect').setRequired(true)))
    .addSubcommand(s => s.setName('resetstats').setDescription('Reset stats for a URL')
      .addStringOption(o => o.setName('url').setDescription('URL to reset').setRequired(true)))
    .addSubcommand(s => s.setName('setalert').setDescription('Toggle DM alerts for a URL')
      .addStringOption(o => o.setName('url').setDescription('URL to toggle alerts').setRequired(true)))
  ,
  premium: true,
  requiredPlan: 'advanced',
  async execute(interaction, client) {
    const sub = interaction.options.getSubcommand();
    const guildId = interaction.guild.id;
    const userId = interaction.user.id;

    // Helper: Validate URL
    const validateUrl = (u) => {
      try {
        const parsed = new URL(u);
        return parsed.protocol === 'http:' || parsed.protocol === 'https:';
      } catch {
        return false;
      }
    };

    // Helper: Create Visual Status Bar
    const getStatusBar = (pings) => {
      if (!pings || pings.length === 0) return 'No data yet';
      // Take last 10 pings for the visual bar
      const recent = pings.slice(-10);
      return recent.map(r => r.status === 'online' ? '🟩' : '🟥').join('');
    };

    if (sub === 'add') {
      const url = interaction.options.getString('url').trim();
      const interval = interaction.options.getInteger('interval') || 5;
      const name = interaction.options.getString('name') || '';

      if (!validateUrl(url)) return interaction.reply({ content: 'Provide a valid URL starting with http:// or https://', flags: MessageFlags.Ephemeral });
      if (interval < 1 || interval > 60) return interaction.reply({ content: 'Interval must be between 1 and 60 minutes.', flags: MessageFlags.Ephemeral });

      const exists = await uptimeSchema.findOne({ Guild: guildId, URL: url });
      if (exists) return interaction.reply({ content: 'This URL is already being monitored in this guild.', flags: MessageFlags.Ephemeral });

      await uptimeSchema.create({
        Guild: guildId,
        User: userId,
        URL: url,
        Name: name,
        Interval: interval,
        AlertDM: true
      });

      return interaction.reply({ embeds: [new EmbedBuilder().setColor(client.config.embedColor || '#00ff99').setTitle('✅ Monitor Added').setDescription(`${name ? `**${name}** — ` : ''}[${url}](${url})\n**Interval:** ${interval}m\n**Alerts:** Enabled`)], flags: MessageFlags.Ephemeral });
    }

    if (sub === 'delete') {
      const url = interaction.options.getString('url').trim();
      const data = await uptimeSchema.findOneAndDelete({ Guild: guildId, URL: url });
      if (!data) return interaction.reply({ content: 'No such monitored URL found.', flags: MessageFlags.Ephemeral });
      return interaction.reply({ embeds: [new EmbedBuilder().setColor(COLORS.success).setTitle('🗑️ Monitor Removed').setDescription(`[${url}](${url}) has been removed from monitoring.`)], flags: MessageFlags.Ephemeral });
    }

    if (sub === 'list') {
      const list = await uptimeSchema.find({ Guild: guildId });
      if (!list.length) return interaction.reply({ content: 'No monitored links in this guild.', flags: MessageFlags.Ephemeral });

      const embed = new EmbedBuilder()
        .setColor(client.config.embedColor || '#00aaff')
        .setTitle('🌐 Uptime Dashboard')
        .setDescription(`Monitoring **${list.length}** services.`);

      const fields = [];
      for (const doc of list.slice(0, 25)) {
        const name = doc.Name || new URL(doc.URL).hostname;
        const status = doc.LastStatus === 'online' ? '🟢 Online' : '🔴 Offline';
        const avg = doc.RecentPings.length ? Math.round(doc.RecentPings.reduce((a, b) => a + b.response, 0) / doc.RecentPings.length) + 'ms' : '—';
        const uptime = doc.TotalPings ? `${Math.round(doc.UptimePercent)}%` : '—';
        const bar = getStatusBar(doc.RecentPings);

        fields.push({
          name: `${name}`,
          value: `**Status:** ${status}\n**Avg Latency:** ${avg} • **Uptime:** ${uptime}\n${bar}\n[Link](${doc.URL})`,
          inline: true
        });
      }

      // Add fields in chunks to respect Discord limits if needed, here we just add all
      embed.addFields(fields);
      embed.setFooter({ text: `Next refresh in ~5 minutes` });

      return interaction.reply({ embeds: [embed], ephemeral: false });
    }

    if (sub === 'info') {
      const url = interaction.options.getString('url').trim();
      const doc = await uptimeSchema.findOne({ Guild: guildId, URL: url });
      if (!doc) return interaction.reply({ content: 'URL not found.', flags: MessageFlags.Ephemeral });

      // Calculations
      const pings = doc.RecentPings || [];
      const responses = pings.map(p => p.response);

      const minPing = responses.length ? Math.min(...responses) : 0;
      const maxPing = responses.length ? Math.max(...responses) : 0;
      const avgPing = responses.length ? Math.round(responses.reduce((a, b) => a + b, 0) / responses.length) : 0;

      // Calculate Jitter (Standard Deviation)
      let jitter = 0;
      if (responses.length > 1) {
        const variance = responses.reduce((t, n) => t + Math.pow(n - avgPing, 2), 0) / (responses.length - 1);
        jitter = Math.round(Math.sqrt(variance));
      }

      // Estimated Downtime
      const totalMinutesMonitored = doc.TotalPings * doc.Interval;
      const downMinutes = doc.FailedPings * doc.Interval;

      // Recent History Formatting
      const history = pings.slice(-8).reverse().map(r => {
        const indicator = r.status === 'online' ? '🟢' : '🔴';
        const time = `<t:${Math.floor(new Date(r.time).getTime() / 1000)}:R>`;
        return `${indicator} **${r.response}ms** — ${time}`;
      }).join('\n') || 'No data yet';

      const embed = new EmbedBuilder()
        .setColor(doc.LastStatus === 'online' ? '#00ff99' : '#ff5555')
        .setTitle(`📊 Advanced Statistics`)
        .setDescription(`**Target:** [${doc.Name || new URL(doc.URL).hostname}](${doc.URL})\n**Status:** ${doc.LastStatus === 'online' ? '🟢 Online' : '🔴 Offline'}`)
        .addFields(
          { name: '📈 Performance', value: `\`\`\`yml\nAvg Ping: ${avgPing}ms\nMin Ping: ${minPing}ms\nMax Ping: ${maxPing}ms\nJitter:   ${jitter}ms\`\`\``, inline: false },
          { name: '⏱️ Availability', value: `\`\`\`yml\nUptime:    ${Math.round(doc.UptimePercent)}%\nDowntime:  ~${downMinutes} min\nInterval:  ${doc.Interval} min\`\`\``, inline: false },
          { name: '📜 Recent Checks', value: history, inline: false }
        )
        .setFooter({ text: `Monitored since` })
        .setTimestamp(doc._id.getTimestamp()); // MongoDB ObjectIds have a timestamp

      return interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
    }

    if (sub === 'resetstats') {
      const url = interaction.options.getString('url').trim();
      const doc = await uptimeSchema.findOne({ Guild: guildId, URL: url });
      if (!doc) return interaction.reply({ content: 'URL not found.', flags: MessageFlags.Ephemeral });

      doc.TotalPings = 0;
      doc.FailedPings = 0;
      doc.UptimePercent = 100;
      doc.RecentPings = [];
      await doc.save();

      return interaction.reply({ content: 'Stats have been fully reset.', flags: MessageFlags.Ephemeral });
    }

    if (sub === 'setalert') {
      const url = interaction.options.getString('url').trim();
      const doc = await uptimeSchema.findOne({ Guild: guildId, URL: url });
      if (!doc) return interaction.reply({ content: 'URL not found.', flags: MessageFlags.Ephemeral });

      doc.AlertDM = !doc.AlertDM;
      await doc.save();

      return interaction.reply({ content: `DM alerts are now **${doc.AlertDM ? 'ENABLED' : 'DISABLED'}** for this URL.`, flags: MessageFlags.Ephemeral });
    }
  }
};
