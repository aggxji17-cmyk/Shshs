const { SlashCommandBuilder, PermissionFlagsBits, MessageFlags, EmbedBuilder } = require('discord.js');
const { COLORS } = require('../../utils/designSystem');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('botprofile')
    .setDescription("Customize the bot's profile for this server (Premium only).")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addStringOption((option) =>
      option
        .setName('nickname')
        .setDescription('The nickname for the bot in this server. (Leave empty to keep current)')
        .setMaxLength(32)
        .setRequired(false)
    )
    .addStringOption((option) =>
      option
        .setName('bio')
        .setDescription('The bio/about me for the bot in this server.')
        .setRequired(false)
    )
    .addAttachmentOption((option) =>
      option
        .setName('avatar')
        .setDescription('The server avatar for the bot. (Image)')
        .setRequired(false)
    )
    .addAttachmentOption((option) =>
      option
        .setName('banner')
        .setDescription('The server banner for the bot. (Image)')
        .setRequired(false)
    ),
  premium: true,
  requiredPlan: 'advanced',
  async execute(interaction, client) {
    // Restrict this entirely to the guild owner
    if (interaction.user.id !== interaction.guild.ownerId) {
      return interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setDescription(`${client.emoji?.error || '❌'} Only the **Guild Owner** can use this command.`)
            .setColor(client.config?.embedColor || COLORS.error),
        ],
        flags: MessageFlags.Ephemeral,
      });
    }

    const nickname = interaction.options.getString('nickname');
    const bio = interaction.options.getString('bio');
    const avatarAttachment = interaction.options.getAttachment('avatar');
    const bannerAttachment = interaction.options.getAttachment('banner');

    if (!nickname && !bio && !avatarAttachment && !bannerAttachment) {
      return interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setDescription(`${client.emoji?.error || '❌'} You must provide at least one option to change (nickname, bio, avatar, or banner).`)
            .setColor(client.config?.embedColor || COLORS.error),
        ],
        flags: MessageFlags.Ephemeral,
      });
    }

    await interaction.deferReply({ flags: MessageFlags.Ephemeral });

    try {
      const getBase64 = async (url) => {
        const response = await fetch(url);
        if (!response.ok) throw new Error('Failed to fetch image');
        const buffer = await response.arrayBuffer();
        const type = response.headers.get('content-type') || 'image/png';
        return `data:${type};base64,${Buffer.from(buffer).toString('base64')}`;
      };

      const body = {};

      if (nickname) body.nick = nickname === 'reset' ? null : nickname;
      if (avatarAttachment) body.avatar = await getBase64(avatarAttachment.url);
      if (bannerAttachment) body.banner = await getBase64(bannerAttachment.url);
      if (bio) body.about_me = bio === 'reset' ? null : bio; // Discord uses about_me for bio/description

      // Send a PATCH request to Discord API to modify the bot's own member in the guild
      await client.rest.patch(`/guilds/${interaction.guild.id}/members/@me`, {
        body,
      });

      return interaction.editReply({
        embeds: [
          new EmbedBuilder()
            .setTitle(`Server Profile Updated`)
            .setDescription(`Successfully updated my profile for **${interaction.guild.name}**!`)
            .setColor(client.config?.embedColor || COLORS.success),
        ],
      });
    } catch (error) {
      console.error('Error updating bot server profile:', error);
      return interaction.editReply({
        embeds: [
          new EmbedBuilder()
            .setTitle(`Update Failed`)
            .setDescription(
              `${client.emoji?.error || '❌'} An error occurred while updating the profile. Make sure the bot has sufficient permissions and Discord supports updating these fields for this bot.`
            )
            .setColor(client.config?.embedColor || COLORS.error),
        ],
      });
    }
  },
};
