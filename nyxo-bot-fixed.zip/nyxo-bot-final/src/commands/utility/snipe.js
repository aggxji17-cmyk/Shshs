const { SlashCommandBuilder } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { baseEmbed, errorEmbed } = require('../../utils/embeds');
const { getLastDeleted } = require('../../services/snipeService');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('snipe')
    .setDescription('Show the most recently deleted message in this channel')
    .setDescriptionLocalizations({ ar: 'عرض آخر رسالة تم حذفها في هذه القناة', 'en-US': 'Show the most recently deleted message in this channel' })
    .addIntegerOption((o) => o.setName('index').setDescription('1 = most recent (up to 5)').setDescriptionLocalizations({ ar: '1 = الأحدث (حتى 5)', 'en-US': '1 = most recent (up to 5)' }).setMinValue(1).setMaxValue(5)),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    const index = (interaction.options.getInteger('index') || 1) - 1;

    const entry = getLastDeleted(interaction.channelId, index);
    if (!entry) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'Nothing to snipe in this channel.')], ephemeral: true });
    }

    const embed = baseEmbed(settings)
      .setAuthor({ name: entry.authorTag, iconURL: entry.authorAvatar })
      .setDescription(entry.content || '*(no text content)*')
      .setFooter({ text: `Deleted • ${settings.footer}` });

    if (entry.attachmentUrls[0]) embed.setImage(entry.attachmentUrls[0]);

    await interaction.reply({ embeds: [embed] });
  },
};
