const { SlashCommandBuilder } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { baseEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder().setName('serverinfo').setDescription('View information about this server')
    .setDescriptionLocalizations({ ar: 'عرض معلومات عن هذا السيرفر', 'en-US': 'View information about this server' }),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    const guild = interaction.guild;

    const embed = baseEmbed(settings)
      .setTitle(guild.name)
      .setThumbnail(guild.iconURL())
      .addFields(
        { name: 'Owner', value: `<@${guild.ownerId}>`, inline: true },
        { name: 'Members', value: `${guild.memberCount}`, inline: true },
        { name: 'Channels', value: `${guild.channels.cache.size}`, inline: true },
        { name: 'Roles', value: `${guild.roles.cache.size}`, inline: true },
        { name: 'Created', value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:D>`, inline: true },
        { name: 'Boost Level', value: `${guild.premiumTier}`, inline: true }
      );

    await interaction.reply({ embeds: [embed] });
  },
};
