const { SlashCommandBuilder } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed, baseEmbed } = require('../../utils/embeds');
const { isModerator } = require('../../utils/permissions');
const { safeAutocomplete, fuzzyFilter } = require('../../utils/autocomplete');
const Tag = require('../../database/models/Tag');

const MAX_TAGS_PER_GUILD = 200;

module.exports = {
  data: new SlashCommandBuilder()
    .setName('tag')
    .setDescription('Save and reuse canned-response snippets (rules, FAQs, apply instructions, ...)')
    .setDescriptionLocalizations({ ar: 'حفظ واستخدام مقاطع نصية جاهزة (قوانين، أسئلة شائعة، تعليمات التقديم...)', 'en-US': 'Save and reuse canned-response snippets (rules, FAQs, apply instructions, ...)' })
    .addSubcommand((s) =>
      s
        .setName('show')
        .setDescription('Post a saved tag')
        .setDescriptionLocalizations({ ar: 'نشر مقطع محفوظ', 'en-US': 'Post a saved tag' })
        .addStringOption((o) => o.setName('name').setDescription('Tag name').setDescriptionLocalizations({ ar: 'اسم المقطع', 'en-US': 'Tag name' }).setRequired(true).setAutocomplete(true))
    )
    .addSubcommand((s) =>
      s
        .setName('create')
        .setDescription('Create a new tag (staff only)')
        .setDescriptionLocalizations({ ar: 'إنشاء مقطع جديد (للإشراف فقط)', 'en-US': 'Create a new tag (staff only)' })
        .addStringOption((o) => o.setName('name').setDescription('Tag name (unique per server)').setDescriptionLocalizations({ ar: 'اسم المقطع (فريد لكل سيرفر)', 'en-US': 'Tag name (unique per server)' }).setRequired(true).setMaxLength(50))
        .addStringOption((o) => o.setName('content').setDescription('Tag content').setDescriptionLocalizations({ ar: 'محتوى المقطع', 'en-US': 'Tag content' }).setRequired(true).setMaxLength(2000))
    )
    .addSubcommand((s) =>
      s
        .setName('edit')
        .setDescription('Edit an existing tag (staff only)')
        .setDescriptionLocalizations({ ar: 'تعديل مقطع موجود (للإشراف فقط)', 'en-US': 'Edit an existing tag (staff only)' })
        .addStringOption((o) => o.setName('name').setDescription('Tag name').setDescriptionLocalizations({ ar: 'اسم المقطع', 'en-US': 'Tag name' }).setRequired(true).setAutocomplete(true))
        .addStringOption((o) => o.setName('content').setDescription('New content').setDescriptionLocalizations({ ar: 'المحتوى الجديد', 'en-US': 'New content' }).setRequired(true).setMaxLength(2000))
    )
    .addSubcommand((s) =>
      s
        .setName('delete')
        .setDescription('Delete a tag (staff only)')
        .setDescriptionLocalizations({ ar: 'حذف مقطع (للإشراف فقط)', 'en-US': 'Delete a tag (staff only)' })
        .addStringOption((o) => o.setName('name').setDescription('Tag name').setDescriptionLocalizations({ ar: 'اسم المقطع', 'en-US': 'Tag name' }).setRequired(true).setAutocomplete(true))
    )
    .addSubcommand((s) =>
      s
        .setName('list')
        .setDescription('List every tag in this server')
        .setDescriptionLocalizations({ ar: 'عرض جميع المقاطع في هذا السيرفر', 'en-US': 'List every tag in this server' })
    )
    .addSubcommand((s) =>
      s
        .setName('raw')
        .setDescription('Show a tag\'s raw, unformatted content (useful before editing it)')
        .setDescriptionLocalizations({ ar: 'عرض محتوى المقطع بدون تنسيق (مفيد قبل تعديله)', 'en-US': "Show a tag's raw, unformatted content (useful before editing it)" })
        .addStringOption((o) => o.setName('name').setDescription('Tag name').setDescriptionLocalizations({ ar: 'اسم المقطع', 'en-US': 'Tag name' }).setRequired(true).setAutocomplete(true))
    ),

  autocomplete: safeAutocomplete(async (interaction) => {
    if (!interaction.guildId) return [];
    const focused = String(interaction.options.getFocused());
    const tags = await Tag.find({ guildId: interaction.guildId }).select('name').limit(200).lean();
    const matched = fuzzyFilter(tags, focused, { key: (t) => t.name });
    return matched.map((t) => ({ name: t.name, value: t.name }));
  }),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    const sub = interaction.options.getSubcommand();

    if (sub === 'show') {
      const name = interaction.options.getString('name').trim().toLowerCase();
      const tag = await Tag.findOneAndUpdate({ guildId: interaction.guildId, name }, { $inc: { uses: 1 } });
      if (!tag) {
        return interaction.reply({ embeds: [errorEmbed(settings, `No tag named \`${name}\` exists. Use \`/tag list\` to see them all.`)], ephemeral: true });
      }
      return interaction.reply({ content: tag.content });
    }

    if (sub === 'raw') {
      const name = interaction.options.getString('name').trim().toLowerCase();
      const tag = await Tag.findOne({ guildId: interaction.guildId, name });
      if (!tag) {
        return interaction.reply({ embeds: [errorEmbed(settings, `No tag named \`${name}\` exists.`)], ephemeral: true });
      }
      return interaction.reply({ content: `\`\`\`\n${tag.content.replace(/```/g, '\u200b`\u200b`\u200b`')}\n\`\`\``, ephemeral: true });
    }

    if (sub === 'list') {
      const tags = await Tag.find({ guildId: interaction.guildId }).sort({ name: 1 }).limit(200).lean();
      if (!tags.length) {
        return interaction.reply({ embeds: [errorEmbed(settings, 'No tags have been created in this server yet.')], ephemeral: true });
      }
      const embed = baseEmbed(settings)
        .setTitle(`Tags (${tags.length})`)
        .setDescription(tags.map((t) => `\`${t.name}\` (${t.uses} use${t.uses === 1 ? '' : 's'})`).join(', '));
      return interaction.reply({ embeds: [embed] });
    }

    // create / edit / delete are staff-only.
    if (!isModerator(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You do not have permission to manage tags in this server.')], ephemeral: true });
    }

    if (sub === 'create') {
      const name = interaction.options.getString('name').trim().toLowerCase();
      const content = interaction.options.getString('content');

      const existing = await Tag.findOne({ guildId: interaction.guildId, name });
      if (existing) {
        return interaction.reply({ embeds: [errorEmbed(settings, `A tag named \`${name}\` already exists. Use \`/tag edit\` to change it.`)], ephemeral: true });
      }

      const count = await Tag.countDocuments({ guildId: interaction.guildId });
      if (count >= MAX_TAGS_PER_GUILD) {
        return interaction.reply({ embeds: [errorEmbed(settings, `This server has reached the ${MAX_TAGS_PER_GUILD}-tag limit. Delete one before creating another.`)], ephemeral: true });
      }

      await Tag.create({ guildId: interaction.guildId, name, content, createdBy: interaction.user.id });
      return interaction.reply({ embeds: [successEmbed(settings, `Tag \`${name}\` created. Use it with \`/tag show name:${name}\`.`)], ephemeral: true });
    }

    if (sub === 'edit') {
      const name = interaction.options.getString('name').trim().toLowerCase();
      const content = interaction.options.getString('content');

      const tag = await Tag.findOneAndUpdate({ guildId: interaction.guildId, name }, { content });
      if (!tag) {
        return interaction.reply({ embeds: [errorEmbed(settings, `No tag named \`${name}\` exists.`)], ephemeral: true });
      }
      return interaction.reply({ embeds: [successEmbed(settings, `Tag \`${name}\` updated.`)], ephemeral: true });
    }

    if (sub === 'delete') {
      const name = interaction.options.getString('name').trim().toLowerCase();
      const tag = await Tag.findOneAndDelete({ guildId: interaction.guildId, name });
      if (!tag) {
        return interaction.reply({ embeds: [errorEmbed(settings, `No tag named \`${name}\` exists.`)], ephemeral: true });
      }
      return interaction.reply({ embeds: [successEmbed(settings, `Tag \`${name}\` deleted.`)], ephemeral: true });
    }
  },
};
