const { SlashCommandBuilder } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { baseEmbed } = require('../../utils/embeds');

function formatUptime(ms) {
  const seconds = Math.floor(ms / 1000) % 60;
  const minutes = Math.floor(ms / 60000) % 60;
  const hours = Math.floor(ms / 3600000) % 24;
  const days = Math.floor(ms / 86400000);
  return `${days}d ${hours}h ${minutes}m ${seconds}s`;
}

module.exports = {
  data: new SlashCommandBuilder().setName('stats').setDescription('View bot statistics')
    .setDescriptionLocalizations({ ar: 'عرض إحصائيات البوت', 'en-US': 'View bot statistics' }),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    const client = interaction.client;

    const memoryMb = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(1);
    const totalMembers = client.guilds.cache.reduce((acc, g) => acc + g.memberCount, 0);

    const embed = baseEmbed(settings)
      .setTitle('📊 Bot Statistics')
      .addFields(
        { name: 'Servers', value: `${client.guilds.cache.size}`, inline: true },
        { name: 'Users', value: `${totalMembers}`, inline: true },
        { name: 'Uptime', value: formatUptime(client.uptime), inline: true },
        { name: 'Memory Usage', value: `${memoryMb} MB`, inline: true },
        { name: 'WebSocket Ping', value: `${client.ws.ping}ms`, inline: true },
        { name: 'Node.js', value: process.version, inline: true }
      );

    await interaction.reply({ embeds: [embed] });
  },
};
