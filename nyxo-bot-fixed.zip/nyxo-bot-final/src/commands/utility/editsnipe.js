const { SlashCommandBuilder } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { baseEmbed, errorEmbed } = require('../../utils/embeds');
const { getLastEdited } = require('../../services/snipeService');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('editsnipe')
    .setDescription('Show the most recently edited message in this channel')
    .setDescriptionLocalizations({ ar: 'عرض آخر رسالة تم تعديلها في هذه القناة', 'en-US': 'Show the most recently edited message in this channel' })
    .addIntegerOption((o) => o.setName('index').setDescription('1 = most recent (up to 5)').setDescriptionLocalizations({ ar: '1 = الأحدث (حتى 5)', 'en-US': '1 = most recent (up to 5)' }).setMinValue(1).setMaxValue(5)),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    const index = (interaction.options.getInteger('index') || 1) - 1;

    const entry = getLastEdited(interaction.channelId, index);
    if (!entry) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'Nothing to editsnipe in this channel.')], ephemeral: true });
    }

    const embed = baseEmbed(settings)
      .setAuthor({ name: entry.authorTag, iconURL: entry.authorAvatar })
      .addFields(
        { name: 'Before', value: entry.before?.slice(0, 1000) || '*(empty)*' },
        { name: 'After', value: entry.after?.slice(0, 1000) || '*(empty)*' }
      );

    await interaction.reply({ embeds: [embed] });
  },
};
