const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { baseEmbed, errorEmbed } = require('../../utils/embeds');
const Poll = require('../../database/models/Poll');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('poll')
    .setDescription('Create a poll with up to 5 options')
    .setDescriptionLocalizations({ ar: 'إنشاء استطلاع رأي بحتى 5 خيارات', 'en-US': 'Create a poll with up to 5 options' })
    .addStringOption((o) => o.setName('question').setDescription('The poll question').setDescriptionLocalizations({ ar: 'سؤال الاستطلاع', 'en-US': 'The poll question' }).setRequired(true))
    .addStringOption((o) => o.setName('option1').setDescription('Option 1').setDescriptionLocalizations({ ar: 'الخيار 1', 'en-US': 'Option 1' }).setRequired(true))
    .addStringOption((o) => o.setName('option2').setDescription('Option 2').setDescriptionLocalizations({ ar: 'الخيار 2', 'en-US': 'Option 2' }).setRequired(true))
    .addStringOption((o) => o.setName('option3').setDescription('Option 3').setDescriptionLocalizations({ ar: 'الخيار 3', 'en-US': 'Option 3' }))
    .addStringOption((o) => o.setName('option4').setDescription('Option 4').setDescriptionLocalizations({ ar: 'الخيار 4', 'en-US': 'Option 4' }))
    .addStringOption((o) => o.setName('option5').setDescription('Option 5').setDescriptionLocalizations({ ar: 'الخيار 5', 'en-US': 'Option 5' }))
    .addIntegerOption((o) => o.setName('duration_minutes').setDescription('Auto-close after this many minutes').setDescriptionLocalizations({ ar: 'الإغلاق التلقائي بعد هذا العدد من الدقائق', 'en-US': 'Auto-close after this many minutes' }))
    .addBooleanOption((o) => o.setName('allow_multiple').setDescription('Allow voting for more than one option').setDescriptionLocalizations({ ar: 'السماح بالتصويت لأكثر من خيار', 'en-US': 'Allow voting for more than one option' })),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    const question = interaction.options.getString('question');
    const optionTexts = [1, 2, 3, 4, 5]
      .map((i) => interaction.options.getString(`option${i}`))
      .filter(Boolean);
    const durationMinutes = interaction.options.getInteger('duration_minutes');
    const allowMultiple = interaction.options.getBoolean('allow_multiple') || false;

    if (durationMinutes && (durationMinutes < 1 || durationMinutes > 43200)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'Duration must be between 1 minute and 30 days.')], ephemeral: true });
    }

    const options = optionTexts.map((text) => ({ text, voterIds: [] }));
    const embed = baseEmbed(settings)
      .setTitle(`📊 ${question}`)
      .setDescription(options.map((o, i) => `**${i + 1}.** ${o.text}`).join('\n'))
      .setFooter({ text: durationMinutes ? `Poll closes in ${durationMinutes} minute(s)` : 'Poll open until manually closed' });

    const reply = await interaction.reply({ embeds: [embed], components: [], fetchReply: true });

    const poll = await Poll.create({
      guildId: interaction.guildId,
      channelId: interaction.channelId,
      messageId: reply.id,
      question,
      options,
      allowMultiple,
      createdBy: interaction.user.id,
      endsAt: durationMinutes ? new Date(Date.now() + durationMinutes * 60_000) : null,
    });

    const row = new ActionRowBuilder().addComponents(
      options.map((o, i) => new ButtonBuilder().setCustomId(`poll_vote:${poll._id}:${i}`).setLabel(o.text.slice(0, 80)).setStyle(ButtonStyle.Primary))
    );

    await interaction.editReply({ components: [row] });
  },
};
