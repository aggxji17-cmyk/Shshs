const { SlashCommandBuilder } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed } = require('../../utils/embeds');
const AfkStatus = require('../../database/models/AfkStatus');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('afk')
    .setDescription('Mark yourself as AFK - the bot will notify anyone who mentions you')
    .setDescriptionLocalizations({ ar: 'وضع علامة أنك بعيد (AFK) - سيخبر البوت من يذكرك', 'en-US': 'Mark yourself as AFK - the bot will notify anyone who mentions you' })
    .addStringOption((o) => o.setName('reason').setDescription('Reason for being AFK').setDescriptionLocalizations({ ar: 'سبب الغياب (AFK)', 'en-US': 'Reason for being AFK' }).setMaxLength(200)),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    const reason = interaction.options.getString('reason') || 'AFK';

    await AfkStatus.findOneAndUpdate(
      { guildId: interaction.guildId, userId: interaction.user.id },
      { reason, since: new Date(), mentionCount: 0 },
      { upsert: true }
    );

    await interaction.reply({ embeds: [successEmbed(settings, `You are now AFK: **${reason}**`)] });
  },
};
