const { SlashCommandBuilder } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { baseEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder().setName('ping').setDescription("Check the bot's latency")
    .setDescriptionLocalizations({ ar: 'فحص زمن استجابة البوت', 'en-US': 'Check the bot\'s latency' }),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    const sent = await interaction.reply({ embeds: [baseEmbed(settings).setDescription('🏓 Pinging...')], fetchReply: true });
    const roundTrip = sent.createdTimestamp - interaction.createdTimestamp;

    await interaction.editReply({
      embeds: [
        baseEmbed(settings)
          .setTitle('🏓 Pong!')
          .addFields(
            { name: 'Roundtrip Latency', value: `${roundTrip}ms`, inline: true },
            { name: 'WebSocket Latency', value: `${interaction.client.ws.ping}ms`, inline: true }
          ),
      ],
    });
  },
};
