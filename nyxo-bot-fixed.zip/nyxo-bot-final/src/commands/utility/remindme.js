const { SlashCommandBuilder } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const Reminder = require('../../database/models/Reminder');

const UNIT_MS = { s: 1000, m: 60_000, h: 3_600_000, d: 86_400_000, w: 604_800_000 };

/** Parses strings like "10m", "2h30m", "1d" into milliseconds. Returns null if invalid. */
function parseDuration(input) {
  const matches = [...input.toLowerCase().matchAll(/(\d+)\s*(s|m|h|d|w)/g)];
  if (!matches.length) return null;
  return matches.reduce((total, [, amount, unit]) => total + Number(amount) * UNIT_MS[unit], 0);
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('remindme')
    .setDescription('Set a reminder')
    .setDescriptionLocalizations({ ar: 'تعيين تذكير', 'en-US': 'Set a reminder' })
    .addStringOption((o) => o.setName('time').setDescription('e.g. 10m, 2h30m, 1d').setDescriptionLocalizations({ ar: 'مثل 10m أو 2h30m أو 1d', 'en-US': 'e.g. 10m, 2h30m, 1d' }).setRequired(true))
    .addStringOption((o) => o.setName('message').setDescription('What should I remind you about?').setDescriptionLocalizations({ ar: 'بماذا تريدني أن أذكّرك؟', 'en-US': 'What should I remind you about?' }).setRequired(true)),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    const durationMs = parseDuration(interaction.options.getString('time'));
    if (!durationMs || durationMs < 10_000 || durationMs > 1000 * 60 * 60 * 24 * 365) {
      return interaction.reply({
        embeds: [errorEmbed(settings, 'Give a valid duration between 10 seconds and 1 year, e.g. `10m`, `2h30m`, `1d`.')],
        ephemeral: true,
      });
    }

    const message = interaction.options.getString('message');
    const remindAt = new Date(Date.now() + durationMs);

    await Reminder.create({
      userId: interaction.user.id,
      guildId: interaction.guildId,
      channelId: interaction.channelId,
      message,
      remindAt,
    });

    await interaction.reply({
      embeds: [successEmbed(settings, `I'll remind you <t:${Math.floor(remindAt.getTime() / 1000)}:R>: **${message}**`)],
      ephemeral: true,
    });
  },
};
