const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../../utils/embeds');

const CUSTOM_EMOJI_RE = /<(a?):(\w+):(\d+)>/;

module.exports = {
  data: new SlashCommandBuilder()
    .setName('emojisteal')
    .setDescription('Add a custom emoji (or image URL) to this server')
    .setDescriptionLocalizations({ ar: 'إضافة إيموجي مخصص (أو رابط صورة) إلى هذا السيرفر', 'en-US': 'Add a custom emoji (or image URL) to this server' })
    .addStringOption((o) => o.setName('emoji_or_url').setDescription('A custom emoji, e.g. :pog: from another server, or a direct image URL').setDescriptionLocalizations({ ar: 'إيموجي مخصص، مثل :pog: من سيرفر آخر، أو رابط صورة مباشر', 'en-US': 'A custom emoji, e.g. :pog: from another server, or a direct image URL' }).setRequired(true))
    .addStringOption((o) => o.setName('name').setDescription('Name for the new emoji (letters, numbers, underscores)').setDescriptionLocalizations({ ar: 'اسم الإيموجي الجديد (أحرف، أرقام، شرطات سفلية)', 'en-US': 'Name for the new emoji (letters, numbers, underscores)' }))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuildExpressions),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    const input = interaction.options.getString('emoji_or_url').trim();
    const match = input.match(CUSTOM_EMOJI_RE);

    let url;
    let name = interaction.options.getString('name');

    if (match) {
      const [, animated, emojiName, emojiId] = match;
      url = `https://cdn.discordapp.com/emojis/${emojiId}.${animated ? 'gif' : 'png'}`;
      name = name || emojiName;
    } else if (/^https?:\/\/.+\.(png|jpe?g|gif|webp)$/i.test(input)) {
      url = input;
      name = name || 'emoji';
    } else {
      return interaction.reply({
        embeds: [errorEmbed(settings, 'Provide a custom emoji (like `:pog:` pasted from another server) or a direct image URL ending in .png/.jpg/.gif/.webp.')],
        ephemeral: true,
      });
    }

    name = name.replace(/[^a-zA-Z0-9_]/g, '').slice(0, 32) || 'emoji';

    await interaction.deferReply();

    try {
      const emoji = await interaction.guild.emojis.create({ attachment: url, name });
      await interaction.editReply({ embeds: [successEmbed(settings, `Added ${emoji} as \`:${emoji.name}:\``)] });
    } catch (err) {
      await interaction.editReply({
        embeds: [errorEmbed(settings, `Could not add that emoji (${err.message}). Check the server has free emoji slots and I have Manage Emojis permission.`)],
      });
    }
  },
};
