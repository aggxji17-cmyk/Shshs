const { SlashCommandBuilder } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { baseEmbed, errorEmbed } = require('../../utils/embeds');
const { safeAutocomplete, commandNameChoices } = require('../../utils/autocomplete');

const CATEGORIES = {
  Moderation: ['ban', 'kick', 'timeout', 'warn', 'warnings', 'clearwarnings', 'purge'],
  'Anti-Nuke & AutoMod': ['antinuke', 'automod', 'mentionprotect'],
  'Welcome & Roles': ['autorole', 'role', 'rolemenu'],
  Leveling: ['rank', 'leaderboard'],
  Giveaways: ['gstart', 'gend', 'greroll', 'glist'],
  'Tickets & Suggestions': ['ticketsetup', 'ticketnotify', 'suggest', 'suggestionsetup'],
  Minecraft: ['ip', 'minecraft', 'mcconfig', 'link', 'mclink', 'mcprofile', 'mcunlink', 'setupstatus'],
  Utility: ['ping', 'help', 'stats', 'serverinfo', 'userinfo'],
  Settings: ['settings', 'setlogs', 'setwelcome', 'setgoodbye', 'backup'],
};

module.exports = {
  data: new SlashCommandBuilder().setName('help').setDescription('View all available commands')
    .setDescriptionLocalizations({ ar: 'عرض جميع الأوامر المتاحة', 'en-US': 'View all available commands' })
    .addStringOption((o) =>
      o.setName('command')
        .setDescription('Get details about one specific command')
        .setDescriptionLocalizations({ ar: 'عرض تفاصيل أمر معيّن', 'en-US': 'Get details about one specific command' })
        .setAutocomplete(true)
    ),

  autocomplete: safeAutocomplete(async (interaction) => {
    return commandNameChoices(interaction, interaction.options.getFocused());
  }),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    const requested = interaction.options.getString('command');

    if (requested) {
      const name = requested.replace(/^\//, '').toLowerCase();
      const command = interaction.client.commands.get(name);

      if (!command) {
        return interaction.reply({ embeds: [errorEmbed(settings, `لا يوجد أمر باسم \`${requested}\`.`)], ephemeral: true });
      }

      const json = command.data.toJSON();
      const embed = baseEmbed(settings)
        .setTitle(`📖 /${json.name}`)
        .setDescription(json.description || '—');

      if (json.options?.length) {
        embed.addFields({
          name: 'Options',
          value: json.options
            .map((opt) => `\`${opt.name}\`${opt.required ? ' *(required)*' : ''} — ${opt.description}`)
            .join('\n')
            .slice(0, 1024),
        });
      }

      return interaction.reply({ embeds: [embed] });
    }

    const embed = baseEmbed(settings).setTitle('📖 Command List');
    for (const [category, commands] of Object.entries(CATEGORIES)) {
      embed.addFields({ name: category, value: commands.map((c) => `\`/${c}\``).join(', ') });
    }

    await interaction.reply({ embeds: [embed] });
  },
};
