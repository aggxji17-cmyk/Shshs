const { SlashCommandBuilder, PermissionFlagsBits, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('embedbuilder')
    .setDescription('Open a form to build and send a custom embed')
    .setDescriptionLocalizations({ ar: 'فتح نموذج لإنشاء وإرسال embed مخصص', 'en-US': 'Open a form to build and send a custom embed' })
    .addChannelOption((o) => o.setName('channel').setDescription('Channel to send the embed to (defaults to here)').setDescriptionLocalizations({ ar: 'القناة التي يُرسل إليها الـ embed (افتراضياً هذه القناة)', 'en-US': 'Channel to send the embed to (defaults to here)' }))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

  async execute(interaction) {
    const targetChannelId = interaction.options.getChannel('channel')?.id || interaction.channelId;

    const modal = new ModalBuilder().setCustomId(`embedbuilder_modal:${targetChannelId}`).setTitle('Embed Builder');

    const title = new TextInputBuilder().setCustomId('title').setLabel('Title').setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(256);
    const description = new TextInputBuilder()
      .setCustomId('description')
      .setLabel('Description')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(true)
      .setMaxLength(4000);
    const color = new TextInputBuilder().setCustomId('color').setLabel('Hex color (e.g. #5865F2)').setStyle(TextInputStyle.Short).setRequired(false);
    const imageUrl = new TextInputBuilder().setCustomId('imageUrl').setLabel('Image URL').setStyle(TextInputStyle.Short).setRequired(false);
    const footer = new TextInputBuilder().setCustomId('footer').setLabel('Footer text').setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(200);

    modal.addComponents(
      new ActionRowBuilder().addComponents(title),
      new ActionRowBuilder().addComponents(description),
      new ActionRowBuilder().addComponents(color),
      new ActionRowBuilder().addComponents(imageUrl),
      new ActionRowBuilder().addComponents(footer)
    );

    await interaction.showModal(modal);
  },
};
