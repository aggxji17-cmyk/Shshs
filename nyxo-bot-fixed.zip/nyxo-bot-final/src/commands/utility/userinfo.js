const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { baseEmbed } = require('../../utils/embeds');
const { isModerator } = require('../../utils/permissions');
const { RANGE_CHOICES, SORT_CHOICES } = require('../../utils/auditLabels');
const { getUserStats } = require('../../services/auditService');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('userinfo')
    .setDescription('View information about a member')
    .setDescriptionLocalizations({ ar: 'عرض معلومات عن عضو', 'en-US': 'View information about a member' })
    .addUserOption((o) => o.setName('user').setDescription('The member to look up').setDescriptionLocalizations({ ar: 'العضو المراد البحث عنه', 'en-US': 'The member to look up' }))
    .addStringOption((o) => o.setName('range').setDescription('Case log period (visible to moderators only)').setDescriptionLocalizations({ ar: 'فترة سجل العقوبات (تظهر للمشرفين فقط)', 'en-US': 'Case log period (visible to moderators only)' }).addChoices(...RANGE_CHOICES))
    .addStringOption((o) => o.setName('sort').setDescription('Case log order (visible to moderators only)').setDescriptionLocalizations({ ar: 'ترتيب سجل العقوبات (يظهر للمشرفين فقط)', 'en-US': 'Case log order (visible to moderators only)' }).addChoices(...SORT_CHOICES)),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    const user = interaction.options.getUser('user') || interaction.user;
    const member = await interaction.guild.members.fetch(user.id).catch(() => null);

    const embed = baseEmbed(settings)
      .setTitle(user.tag)
      .setThumbnail(user.displayAvatarURL())
      .addFields(
        { name: 'ID', value: user.id, inline: true },
        { name: 'Account Created', value: `<t:${Math.floor(user.createdTimestamp / 1000)}:D>`, inline: true }
      );

    if (member) {
      embed.addFields(
        { name: 'Joined Server', value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:D>`, inline: true },
        {
          name: 'Roles',
          value: member.roles.cache.filter((r) => r.id !== interaction.guild.id).map((r) => r.toString()).join(', ') || 'None',
        }
      );
    }

    let components = [];

    // Punishment record - moderator-only, powered entirely by the Case
    // audit system (services/auditService.js). Regular members viewing
    // their own or someone else's /userinfo never see this section.
    if (isModerator(interaction.member, guildConfig)) {
      const range = interaction.options.getString('range') || 'all';
      const sort = interaction.options.getString('sort') || 'newest';
      const { stats, total } = await getUserStats(interaction.guildId, user.id, range);

      embed.addFields({
        name: 'سجل العقوبات',
        value: `🔨 ${stats.ban} • 👢 ${stats.kick} • ⏱️ ${stats.timeout} • ⚠️ ${stats.warn} • 🧹 ${stats.softban} • ♻️ ${stats.unban} — الإجمالي: ${total}`,
      });

      if (total > 0) {
        components = [
          new ActionRowBuilder().addComponents(
            new ButtonBuilder()
              .setCustomId(`userinfo_audit_page:${user.id}:${range}:${sort}:1`)
              .setLabel('📋 عرض السجل الكامل')
              .setStyle(ButtonStyle.Secondary)
          ),
        ];
      }
    }

    await interaction.reply({ embeds: [embed], components });
  },
};
