const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { getGuildConfig, resolved, invalidateGuildConfig } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('jointocreate')
    .setDescription('Configure join-to-create temporary voice channels')
    .setDescriptionLocalizations({ ar: 'إعداد القنوات الصوتية المؤقتة (الانضمام للإنشاء)', 'en-US': 'Configure join-to-create temporary voice channels' })
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
    .addSubcommand((s) =>
      s
        .setName('config')
        .setDescription('Set the trigger channel and category for temp channels')
      .setDescriptionLocalizations({ ar: 'تعيين قناة التفعيل وفئة القنوات المؤقتة', 'en-US': 'Set the trigger channel and category for temp channels' })
        .addChannelOption((o) => o.setName('trigger_channel').setDescription('Voice channel that spawns a new channel when joined').setDescriptionLocalizations({ ar: 'القناة الصوتية التي تُنشئ قناة جديدة عند الانضمام إليها', 'en-US': 'Voice channel that spawns a new channel when joined' }).addChannelTypes(ChannelType.GuildVoice).setRequired(true))
        .addChannelOption((o) => o.setName('category').setDescription('Category new channels are created under').setDescriptionLocalizations({ ar: 'الفئة التي تُنشأ تحتها القنوات الجديدة', 'en-US': 'Category new channels are created under' }).addChannelTypes(ChannelType.GuildCategory))
        .addIntegerOption((o) => o.setName('user_limit').setDescription('Default user limit for created channels (0 = unlimited)').setDescriptionLocalizations({ ar: 'الحد الافتراضي للأعضاء في القنوات المُنشأة (0 = غير محدود)', 'en-US': 'Default user limit for created channels (0 = unlimited)' }).setMinValue(0).setMaxValue(99)
        )
    )
    .addSubcommand((s) => s.setName('toggle').setDescription('Enable or disable join-to-create')
      .setDescriptionLocalizations({ ar: 'تفعيل أو تعطيل الانضمام للإنشاء', 'en-US': 'Enable or disable join-to-create' })),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You need Manage Channels permission to use this command.')], ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();

    if (sub === 'toggle') {
      guildConfig.joinToCreate.enabled = !guildConfig.joinToCreate.enabled;
      await guildConfig.save();
      invalidateGuildConfig(interaction.guildId);
      return interaction.reply({ embeds: [successEmbed(settings, `Join-to-create is now **${guildConfig.joinToCreate.enabled ? 'enabled' : 'disabled'}**.`)] });
    }

    const triggerChannel = interaction.options.getChannel('trigger_channel');
    const category = interaction.options.getChannel('category');
    const userLimit = interaction.options.getInteger('user_limit');

    guildConfig.joinToCreate.triggerChannelId = triggerChannel.id;
    if (category) guildConfig.joinToCreate.categoryId = category.id;
    if (userLimit !== null) guildConfig.joinToCreate.userLimit = userLimit;

    await guildConfig.save();
    invalidateGuildConfig(interaction.guildId);
    return interaction.reply({ embeds: [successEmbed(settings, `Members who join ${triggerChannel} will now get their own temporary channel.`)] });
  },
};
