const { SlashCommandBuilder } = require('discord.js');
const axios = require('axios');
const { useQueue } = require('discord-player');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { baseEmbed, errorEmbed } = require('../../utils/embeds');
const { getKazagumo } = require('../../services/lavalinkManager');

const DESCRIPTION_LIMIT = 4096;
const FIELD_LIMIT = 1024;
const MAX_FIELDS = 4; // keeps the embed well under Discord's 6000 char total cap

// Strips the noisy bits YouTube/SoundCloud titles tend to carry
// ("(Official Video)", "[Lyrics]", "ft. X", etc.) so the search query
// sent to the lyrics provider is closer to a clean "artist - title".
function cleanTitle(title) {
  return title
    .replace(/\[[^\]]*\]/g, '')
    .replace(/\([^)]*\)/g, '')
    .replace(/ft\.?.*$/i, '')
    .replace(/feat\.?.*$/i, '')
    .replace(/official\s*(video|audio|music video|lyric video)?/gi, '')
    .replace(/\s{2,}/g, ' ')
    .trim();
}

function chunkLyrics(lyrics) {
  const clean = lyrics.replace(/\r/g, '').trim();
  if (clean.length <= DESCRIPTION_LIMIT) return { description: clean, fields: [] };

  const description = clean.slice(0, DESCRIPTION_LIMIT);
  const rest = clean.slice(DESCRIPTION_LIMIT);
  const fields = [];
  for (let i = 0; i < rest.length && fields.length < MAX_FIELDS; i += FIELD_LIMIT) {
    fields.push({ name: '\u200b', value: rest.slice(i, i + FIELD_LIMIT) });
  }
  return { description, fields, truncated: rest.length > MAX_FIELDS * FIELD_LIMIT };
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('lyrics')
    .setDescription('Look up the lyrics for a song')
    .setDescriptionLocalizations({ ar: 'البحث عن كلمات أغنية', 'en-US': 'Look up the lyrics for a song' })
    .addStringOption((o) =>
      o
        .setName('song')
        .setDescription('Song title (and artist). Leave blank to use the track playing now')
        .setDescriptionLocalizations({ ar: 'اسم الأغنية (والفنان). اتركه فارغاً لاستخدام المقطع الذي يعمل حالياً', 'en-US': 'Song title (and artist). Leave blank to use the track playing now' })
    ),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    let query = interaction.options.getString('song');

    if (!query) {
      // Check the Kazagumo/Lavalink player first (migrated guilds), then
      // fall back to discord-player's queue - same guilds this bot has
      // always used, unchanged behavior when Lavalink isn't configured.
      const kazagumo = getKazagumo();
      const kazagumoPlayer = kazagumo?.players.get(interaction.guildId);
      const kazagumoTrack = kazagumoPlayer?.queue.current;

      const queue = useQueue(interaction.guildId);
      const track = kazagumoTrack || queue?.currentTrack;

      if (!track) {
        return interaction.reply({
          embeds: [errorEmbed(settings, 'Nothing is playing right now. Give me a song name with `/lyrics song:`.')],
          ephemeral: true,
        });
      }
      query = `${track.author ? `${track.author} ` : ''}${cleanTitle(track.title)}`.trim();
    }

    await interaction.deferReply();

    try {
      // 1. Resolve a clean "artist / title" pair via the free lookup endpoint,
      //    since users (and track titles) rarely provide them separately.
      const suggestRes = await axios.get(`https://api.lyrics.ovh/suggest/${encodeURIComponent(query)}`);
      const match = suggestRes.data?.data?.[0];

      if (!match) {
        return interaction.editReply({ embeds: [errorEmbed(settings, `No lyrics found for **${query}**.`)] });
      }

      const artist = match.artist?.name || 'Unknown Artist';
      const title = match.title || query;

      // 2. Fetch the actual lyrics for that artist/title pair.
      const lyricsRes = await axios.get(`https://api.lyrics.ovh/v1/${encodeURIComponent(artist)}/${encodeURIComponent(title)}`);
      const lyrics = lyricsRes.data?.lyrics;

      if (!lyrics || !lyrics.trim()) {
        return interaction.editReply({ embeds: [errorEmbed(settings, `No lyrics found for **${title}** by **${artist}**.`)] });
      }

      const { description, fields, truncated } = chunkLyrics(lyrics);

      const embed = baseEmbed(settings)
        .setTitle(`🎤 ${title}`)
        .setAuthor({ name: artist })
        .setDescription(description)
        .setThumbnail(match.album?.cover_medium || null);

      if (fields.length) embed.addFields(fields);
      if (truncated) embed.addFields({ name: '\u200b', value: '*Lyrics truncated - too long to display in full.*' });

      return interaction.editReply({ embeds: [embed] });
    } catch (err) {
      if (err.response?.status === 404) {
        return interaction.editReply({ embeds: [errorEmbed(settings, `No lyrics found for **${query}**.`)] });
      }
      return interaction.editReply({ embeds: [errorEmbed(settings, "Couldn't fetch lyrics right now, please try again later.")] });
    }
  },
};
