const { SlashCommandBuilder } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { requireActiveQueue } = require('../../utils/musicChecks');
const { getKazagumo } = require('../../services/lavalinkManager');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('remove')
    .setDescription('Remove a track from the queue')
    .setDescriptionLocalizations({ ar: 'إزالة مقطع من قائمة الانتظار', 'en-US': 'Remove a track from the queue' })
    .addIntegerOption((o) => o.setName('position').setDescription('Position in the queue (see /queue)').setDescriptionLocalizations({ ar: 'الموضع في قائمة الانتظار (راجع /queue)', 'en-US': 'Position in the queue (see /queue)' }).setRequired(true).setMinValue(1)),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    // Migrated path: if this guild's queue is being run through
    // Kazagumo/Lavalink, remove from it that way. KazagumoQueue extends
    // Array and only holds the *upcoming* tracks (the current track
    // lives separately on .queue.current), matching what
    // queue.tracks.toArray() means on the discord-player side below -
    // so the same 1-based `position` the user gives maps the same way.
    const kazagumo = getKazagumo();
    const kazagumoPlayer = kazagumo?.players.get(interaction.guildId);

    if (kazagumoPlayer && kazagumoPlayer.queue.current) {
      const memberChannel = interaction.member?.voice?.channel;
      if (!memberChannel || memberChannel.id !== kazagumoPlayer.voiceId) {
        return interaction.reply({
          embeds: [errorEmbed(settings, `Join <#${kazagumoPlayer.voiceId}> to control the music.`)],
          ephemeral: true,
        });
      }

      const positionKazagumo = interaction.options.getInteger('position', true);
      const trackKazagumo = kazagumoPlayer.queue[positionKazagumo - 1];

      if (!trackKazagumo) {
        return interaction.reply({
          embeds: [errorEmbed(settings, `There's no track at position **${positionKazagumo}**. Use \`/queue\` to see valid positions.`)],
          ephemeral: true,
        });
      }

      kazagumoPlayer.queue.remove(positionKazagumo - 1);
      return interaction.reply({ embeds: [successEmbed(settings, `🗑️ Removed **${trackKazagumo.title}** from the queue.`)] });
    }

    // Not migrated for this guild yet (no Kazagumo player, e.g. Lavalink
    // isn't configured, or this guild's queue predates it) - fall back to
    // the original discord-player path so behavior is unchanged from
    // before this task.
    const queue = await requireActiveQueue(interaction, settings);
    if (!queue) return;

    const position = interaction.options.getInteger('position', true);
    const tracks = queue.tracks.toArray();
    const track = tracks[position - 1];

    if (!track) {
      return interaction.reply({ embeds: [errorEmbed(settings, `There's no track at position **${position}**. Use \`/queue\` to see valid positions.`)], ephemeral: true });
    }

    queue.removeTrack(track);
    return interaction.reply({ embeds: [successEmbed(settings, `🗑️ Removed **${track.title}** from the queue.`)] });
  },
};
