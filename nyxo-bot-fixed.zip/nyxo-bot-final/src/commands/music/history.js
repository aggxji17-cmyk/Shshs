const { SlashCommandBuilder } = require('discord.js');
const { useMainPlayer } = require('discord-player');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { baseEmbed, successEmbed, errorEmbed } = require('../../utils/embeds');
const { requireVoiceChannel } = require('../../utils/musicChecks');
const { isModerator } = require('../../utils/permissions');
const { safeAutocomplete, fuzzyFilter } = require('../../utils/autocomplete');
const musicHistoryService = require('../../services/musicHistoryService');
const MusicHistory = require('../../database/models/MusicHistory');
const { guildIsOnKazagumo } = require('../../services/lavalinkManager');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('history')
    .setDescription('View or replay this server\u2019s recently played music')
    .setDescriptionLocalizations({ ar: 'عرض أو إعادة تشغيل الأغاني التي عُزفت مؤخراً في هذا السيرفر', 'en-US': 'View or replay this server\u2019s recently played music' })
    .addSubcommand((sc) =>
      sc
        .setName('recent')
        .setDescription(`Show the last played tracks (up to ${musicHistoryService.MAX_LIMIT})`)
        .setDescriptionLocalizations({ ar: `عرض آخر المقاطع التي عُزفت (حتى ${musicHistoryService.MAX_LIMIT})`, 'en-US': `Show the last played tracks (up to ${musicHistoryService.MAX_LIMIT})` })
        .addUserOption((o) =>
          o.setName('user').setDescription('Only show tracks requested by this user').setDescriptionLocalizations({ ar: 'عرض المقاطع التي طلبها هذا العضو فقط', 'en-US': 'Only show tracks requested by this user' })
        )
        .addIntegerOption((o) =>
          o
            .setName('limit')
            .setDescription(`How many tracks to show (default ${musicHistoryService.DEFAULT_LIMIT})`)
            .setDescriptionLocalizations({ ar: `عدد المقاطع المطلوب عرضها (افتراضياً ${musicHistoryService.DEFAULT_LIMIT})`, 'en-US': `How many tracks to show (default ${musicHistoryService.DEFAULT_LIMIT})` })
            .setMinValue(1)
            .setMaxValue(musicHistoryService.MAX_LIMIT)
        )
    )
    .addSubcommand((sc) =>
      sc
        .setName('replay')
        .setDescription('Queue a track from recent history again')
        .setDescriptionLocalizations({ ar: 'إعادة إضافة مقطع من السجل إلى قائمة التشغيل', 'en-US': 'Queue a track from recent history again' })
        .addStringOption((o) =>
          o.setName('track').setDescription('Track to replay').setDescriptionLocalizations({ ar: 'المقطع المراد إعادة تشغيله', 'en-US': 'Track to replay' }).setRequired(true).setAutocomplete(true)
        )
    )
    .addSubcommand((sc) =>
      sc
        .setName('clear')
        .setDescription('Clear this server\u2019s recorded music history')
        .setDescriptionLocalizations({ ar: 'حذف سجل الموسيقى المسجل لهذا السيرفر', 'en-US': 'Clear this server\u2019s recorded music history' })
    ),

  autocomplete: safeAutocomplete(async (interaction) => {
    const focused = interaction.options.getFocused(true);
    if (focused.name !== 'track' || !interaction.guildId) return [];

    const entries = await musicHistoryService.getRecentHistory(interaction.guildId, { limit: musicHistoryService.MAX_LIMIT });
    const matched = fuzzyFilter(entries, String(focused.value), { key: (e) => e.title });
    return matched.map((e) => ({ name: `${e.title}${e.author ? ` — ${e.author}` : ''}`.slice(0, 100), value: String(e._id) }));
  }),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    const sub = interaction.options.getSubcommand();

    if (sub === 'recent') return handleRecent(interaction, settings);
    if (sub === 'replay') return handleReplay(interaction, settings, guildConfig);
    if (sub === 'clear') return handleClear(interaction, settings, guildConfig);
  },
};

async function handleRecent(interaction, settings) {
  const user = interaction.options.getUser('user');
  const limit = interaction.options.getInteger('limit') || musicHistoryService.DEFAULT_LIMIT;

  const entries = await musicHistoryService.getRecentHistory(interaction.guildId, { userId: user?.id, limit });
  if (!entries.length) {
    return interaction.reply({
      embeds: [errorEmbed(settings, user ? `No history recorded for ${user} in this server yet.` : 'No music history recorded in this server yet.')],
      ephemeral: true,
    });
  }

  const lines = entries.map(
    (e) => `<t:${Math.floor(e.playedAt.getTime() / 1000)}:R> - [${e.title}](${e.url}) - <@${e.userId}>`
  );

  const embed = baseEmbed(settings)
    .setTitle(`🕒 Recently Played${user ? ` — ${user.username}` : ''}`)
    .setDescription(lines.join('\n'))
    .setThumbnail(entries[0].thumbnail || null);

  return interaction.reply({ embeds: [embed] });
}

async function handleReplay(interaction, settings, guildConfig) {
  const historyId = interaction.options.getString('track', true);
  const entry = await MusicHistory.findOne({ _id: historyId, guildId: interaction.guildId }).catch(() => null);
  if (!entry) {
    return interaction.reply({ embeds: [errorEmbed(settings, "That track isn't in this server's recent history anymore.")], ephemeral: true });
  }

  if (guildIsOnKazagumo(interaction.guildId)) {
    return interaction.reply({
      embeds: [errorEmbed(settings, "This server's current music session is running on the Lavalink engine, which `/history play` doesn't support yet. Use `/play` with the track link instead.")],
      ephemeral: true,
    });
  }

  const voiceChannel = await requireVoiceChannel(interaction, settings);
  if (!voiceChannel) return;

  const permissions = voiceChannel.permissionsFor(interaction.guild.members.me);
  if (!permissions?.has(['Connect', 'Speak'])) {
    return interaction.reply({ embeds: [errorEmbed(settings, 'I need **Connect** and **Speak** permissions in that voice channel.')], ephemeral: true });
  }

  await interaction.deferReply();
  const player = useMainPlayer();
  const is247 = guildConfig.music?.twentyFourSeven?.enabled;

  try {
    const { track } = await player.play(voiceChannel, entry.url, {
      nodeOptions: {
        metadata: { channel: interaction.channel, requestedBy: interaction.user },
        volume: 70,
        leaveOnEmpty: !is247,
        leaveOnEmptyCooldown: 60_000,
        leaveOnEnd: !is247,
        leaveOnEndCooldown: 300_000,
        leaveOnStop: !is247,
        selfDeaf: true,
      },
      requestedBy: interaction.user,
    });

    return interaction.editReply({ embeds: [baseEmbed(settings).setDescription(`🕒 Queued **[${track.title}](${track.url})** again from history.`)] });
  } catch (err) {
    return interaction.editReply({ embeds: [errorEmbed(settings, `Couldn't replay that track: ${err?.message || err}`)] });
  }
}

async function handleClear(interaction, settings, guildConfig) {
  if (!isModerator(interaction.member, guildConfig)) {
    return interaction.reply({ embeds: [errorEmbed(settings, 'You do not have permission to use this command.')], ephemeral: true });
  }

  const deletedCount = await musicHistoryService.clearHistory(interaction.guildId);
  if (!deletedCount) {
    return interaction.reply({ embeds: [errorEmbed(settings, 'There is no music history to clear in this server.')], ephemeral: true });
  }

  return interaction.reply({ embeds: [successEmbed(settings, `Cleared **${deletedCount}** history entr${deletedCount === 1 ? 'y' : 'ies'} for this server.`)] });
}
