const { SlashCommandBuilder } = require('discord.js');
const { useQueue } = require('discord-player');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { baseEmbed, errorEmbed } = require('../../utils/embeds');
const { buildMusicControlsRow } = require('../../utils/musicControls');
const { getKazagumo } = require('../../services/lavalinkManager');

const REPEAT_MODE_LABELS = { 0: 'Off', 1: 'Track', 2: 'Queue', 3: 'Autoplay' };
// Mirrors queue.js's LOOP_TO_REPEAT_MODE so a Kazagumo player's loop
// string reads through the same REPEAT_MODE_LABELS table as discord-player.
const KAZAGUMO_LOOP_TO_REPEAT_MODE = { none: 0, track: 1, queue: 2 };

/** Simple text progress bar built from a Kazagumo player's live position - discord-player's queue.node.createProgressBar() has no Kazagumo equivalent. */
function buildKazagumoProgressBar(positionMs, durationMs, size = 15) {
  if (!durationMs || durationMs <= 0) return '';
  const ratio = Math.min(Math.max(positionMs / durationMs, 0), 1);
  const filled = Math.round(ratio * size);
  const bar = '▬'.repeat(filled) + '🔘' + '▬'.repeat(Math.max(size - filled, 0));
  const fmt = (ms) => {
    const totalSeconds = Math.floor(ms / 1000);
    const m = Math.floor(totalSeconds / 60);
    const s = totalSeconds % 60;
    return `${m}:${String(s).padStart(2, '0')}`;
  };
  return `${fmt(positionMs)} ${bar} ${fmt(durationMs)}`;
}

module.exports = {
  data: new SlashCommandBuilder().setName('nowplaying').setDescription('Show details about the currently playing track')
    .setDescriptionLocalizations({ ar: 'عرض تفاصيل المقطع الذي يعمل حالياً', 'en-US': 'Show details about the currently playing track' }),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    // Migrated path: if this guild's queue is being run through
    // Kazagumo/Lavalink, render it from Kazagumo's player/queue data.
    const kazagumo = getKazagumo();
    const kazagumoPlayer = kazagumo?.players.get(interaction.guildId);

    if (kazagumoPlayer && kazagumoPlayer.queue.current) {
      const kTrack = kazagumoPlayer.queue.current;
      const activeFilters = kazagumoPlayer.novaActiveFilters ? [...kazagumoPlayer.novaActiveFilters] : [];
      const progressBar = kTrack.isStream ? '' : buildKazagumoProgressBar(kazagumoPlayer.position, kTrack.length);

      const embed = baseEmbed(settings)
        .setTitle('🎶 Now Playing')
        .setDescription(`[${kTrack.title}](${kTrack.uri})`)
        .setThumbnail(kTrack.thumbnail || null)
        .addFields(
          { name: 'Requested by', value: `${kTrack.requester ?? 'Unknown'}`, inline: true },
          { name: 'Volume', value: `${kazagumoPlayer.volume ?? 100}%`, inline: true },
          { name: 'Loop Mode', value: REPEAT_MODE_LABELS[KAZAGUMO_LOOP_TO_REPEAT_MODE[kazagumoPlayer.loop] ?? 0] ?? 'Off', inline: true }
        );

      if (activeFilters.length) {
        embed.addFields({ name: 'Filters', value: activeFilters.map((f) => `\`${f}\``).join(', '), inline: true });
      }
      if (progressBar) embed.addFields({ name: '\u200b', value: progressBar });

      const controlsQueueShim = {
        repeatMode: KAZAGUMO_LOOP_TO_REPEAT_MODE[kazagumoPlayer.loop] ?? 0,
        node: { isPaused: () => kazagumoPlayer.paused },
      };

      return interaction.reply({ embeds: [embed], components: buildMusicControlsRow(controlsQueueShim) });
    }

    // Not migrated for this guild yet (no Kazagumo player, e.g. Lavalink
    // isn't configured, or this guild's queue predates it) - fall back to
    // the original discord-player path so behavior is unchanged from
    // before this task.
    const queue = useQueue(interaction.guildId);
    if (!queue || !queue.currentTrack) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'Nothing is playing right now.')], ephemeral: true });
    }

    const track = queue.currentTrack;
    let progressBar = '';
    try {
      progressBar = queue.node.createProgressBar();
    } catch {
      progressBar = '';
    }

    const embed = baseEmbed(settings)
      .setTitle('🎶 Now Playing')
      .setDescription(`[${track.title}](${track.url})`)
      .setThumbnail(track.thumbnail || null)
      .addFields(
        { name: 'Requested by', value: `${track.requestedBy ?? 'Unknown'}`, inline: true },
        { name: 'Volume', value: `${queue.node.volume}%`, inline: true },
        { name: 'Loop Mode', value: REPEAT_MODE_LABELS[queue.repeatMode] ?? 'Off', inline: true }
      );

    let activeFilters = [];
    try {
      activeFilters = queue.filters.ffmpeg.getFiltersEnabled();
    } catch {
      activeFilters = [];
    }
    if (activeFilters.length) {
      embed.addFields({ name: 'Filters', value: activeFilters.map((f) => `\`${f}\``).join(', '), inline: true });
    }

    if (progressBar) embed.addFields({ name: '\u200b', value: progressBar });

    return interaction.reply({ embeds: [embed], components: buildMusicControlsRow(queue) });
  },
};
