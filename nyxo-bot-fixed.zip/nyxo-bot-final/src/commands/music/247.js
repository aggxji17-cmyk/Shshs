const { SlashCommandBuilder, ChannelType } = require('discord.js');
const { useMainPlayer, useQueue } = require('discord-player');
const { getGuildConfig, resolved, invalidateGuildConfig } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');
const { guildIsOnKazagumo } = require('../../services/lavalinkManager');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('247')
    .setDescription('Toggle 24/7 mode - the bot stays connected to a voice channel and never auto-leaves')
    .setDescriptionLocalizations({
      ar: 'تبديل وضع 24/7 - يبقى البوت متصلاً بالقناة الصوتية ولا يغادر تلقائياً',
      'en-US': 'Toggle 24/7 mode - the bot stays connected to a voice channel and never auto-leaves',
    })
    .addChannelOption((o) =>
      o
        .setName('channel')
        .setDescription('Voice channel to stay connected to (defaults to your current one)')
        .setDescriptionLocalizations({ ar: 'القناة الصوتية للبقاء متصلاً بها (افتراضياً قناتك الحالية)', 'en-US': 'Voice channel to stay connected to (defaults to your current one)' })
        .addChannelTypes(ChannelType.GuildVoice, ChannelType.GuildStageVoice)
    ),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You need Manage Server permission to use this command.')], ephemeral: true });
    }

    const alreadyOn = guildConfig.music.twentyFourSeven.enabled;

    // Turning it off: just flip the flag and let the queue's normal
    // leaveOnEmpty/leaveOnEnd behavior (restored on its *next* creation -
    // see /commands/music/play.js) take back over. We don't force-
    // disconnect an active session; if people are still listening it
    // should keep playing until they finish or stop it themselves.
    if (alreadyOn) {
      guildConfig.music.twentyFourSeven.enabled = false;
      guildConfig.music.twentyFourSeven.voiceChannelId = null;
      guildConfig.music.twentyFourSeven.textChannelId = null;
      await guildConfig.save();
      invalidateGuildConfig(interaction.guildId);

      const queue = useQueue(interaction.guildId);
      if (queue && queue.options) {
        queue.options.leaveOnEmpty = true;
        queue.options.leaveOnEnd = true;
        queue.options.leaveOnStop = true;
      }

      return interaction.reply({ embeds: [successEmbed(settings, '🌙 24/7 mode is now **disabled**.')] });
    }

    const channel = interaction.options.getChannel('channel') || interaction.member?.voice?.channel;
    if (!channel) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'Join a voice channel first, or specify one with the `channel` option.')], ephemeral: true });
    }

    const permissions = channel.permissionsFor(interaction.guild.members.me);
    if (!permissions?.has(['Connect', 'Speak'])) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'I need **Connect** and **Speak** permissions in that voice channel.')], ephemeral: true });
    }

    if (guildIsOnKazagumo(interaction.guildId)) {
      return interaction.reply({
        embeds: [errorEmbed(settings, "This server's current music session is running on the Lavalink engine, which doesn't support 24/7 mode yet. Stop the current session first if you want to switch.")],
        ephemeral: true,
      });
    }

    await interaction.deferReply();

    const player = useMainPlayer();
    let queue = useQueue(interaction.guildId);

    try {
      if (!queue) {
        queue = player.nodes.create(interaction.guild, {
          metadata: { channel: interaction.channel },
          selfDeaf: true,
          volume: 70,
          leaveOnEmpty: false,
          leaveOnEmptyCooldown: 60_000,
          leaveOnEnd: false,
          leaveOnEndCooldown: 300_000,
          leaveOnStop: false,
        });
      } else if (queue.options) {
        // Queue already exists (music is playing) - flip its live leave
        // behavior instead of recreating it, so playback isn't interrupted.
        queue.options.leaveOnEmpty = false;
        queue.options.leaveOnEnd = false;
        queue.options.leaveOnStop = false;
      }

      if (!queue.connection) {
        await queue.connect(channel);
      }
    } catch (err) {
      return interaction.editReply({ embeds: [errorEmbed(settings, `Couldn't connect to that voice channel: ${err?.message || err}`)] });
    }

    guildConfig.music.twentyFourSeven.enabled = true;
    guildConfig.music.twentyFourSeven.voiceChannelId = channel.id;
    guildConfig.music.twentyFourSeven.textChannelId = interaction.channel.id;
    await guildConfig.save();
    invalidateGuildConfig(interaction.guildId);

    return interaction.editReply({ embeds: [successEmbed(settings, `🌙 24/7 mode is now **enabled** in ${channel}. I won't leave when the channel is empty or the queue ends.`)] });
  },
};
