const { SlashCommandBuilder } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { requireActiveQueue } = require('../../utils/musicChecks');
const { getKazagumo } = require('../../services/lavalinkManager');

/** Parses "mm:ss" or "hh:mm:ss" into milliseconds. Returns null if invalid. */
function parseTimestamp(input) {
  const parts = input.split(':').map((p) => Number(p));
  if (parts.some((p) => Number.isNaN(p) || p < 0)) return null;

  let seconds = 0;
  if (parts.length === 3) seconds = parts[0] * 3600 + parts[1] * 60 + parts[2];
  else if (parts.length === 2) seconds = parts[0] * 60 + parts[1];
  else if (parts.length === 1) seconds = parts[0];
  else return null;

  return seconds * 1000;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('seek')
    .setDescription('Seek to a specific point in the current track')
    .setDescriptionLocalizations({ ar: 'الانتقال إلى نقطة محددة في المقطع الحالي', 'en-US': 'Seek to a specific point in the current track' })
    .addStringOption((o) => o.setName('timestamp').setDescription('Timestamp to seek to, e.g. 1:30 or 0:45').setDescriptionLocalizations({ ar: 'الوقت المراد الانتقال إليه، مثل 1:30 أو 0:45', 'en-US': 'Timestamp to seek to, e.g. 1:30 or 0:45' }).setRequired(true)),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    // Migrated path: if this guild's queue is being run through
    // Kazagumo/Lavalink, seek it that way. KazagumoPlayer.seek() takes
    // its position in the same unit (ms) as KazagumoTrack.length, which
    // parseTimestamp() below already produces.
    const kazagumo = getKazagumo();
    const kazagumoPlayer = kazagumo?.players.get(interaction.guildId);

    if (kazagumoPlayer && kazagumoPlayer.queue.current) {
      const memberChannel = interaction.member?.voice?.channel;
      if (!memberChannel || memberChannel.id !== kazagumoPlayer.voiceId) {
        return interaction.reply({
          embeds: [errorEmbed(settings, `Join <#${kazagumoPlayer.voiceId}> to control the music.`)],
          ephemeral: true,
        });
      }

      const rawKazagumo = interaction.options.getString('timestamp', true);
      const msKazagumo = parseTimestamp(rawKazagumo);

      if (msKazagumo === null) {
        return interaction.reply({ embeds: [errorEmbed(settings, 'Invalid timestamp. Use a format like `1:30` or `0:45`.')], ephemeral: true });
      }

      try {
        await kazagumoPlayer.seek(msKazagumo);
      } catch (err) {
        return interaction.reply({ embeds: [errorEmbed(settings, `Couldn't seek: ${err?.message || err}`)], ephemeral: true });
      }

      return interaction.reply({ embeds: [successEmbed(settings, `⏩ Seeked to **${rawKazagumo}**.`)] });
    }

    // Not migrated for this guild yet (no Kazagumo player, e.g. Lavalink
    // isn't configured, or this guild's queue predates it) - fall back to
    // the original discord-player path so behavior is unchanged from
    // before this task.
    const queue = await requireActiveQueue(interaction, settings);
    if (!queue) return;

    const raw = interaction.options.getString('timestamp', true);
    const ms = parseTimestamp(raw);

    if (ms === null) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'Invalid timestamp. Use a format like `1:30` or `0:45`.')], ephemeral: true });
    }

    await queue.node.seek(ms);
    return interaction.reply({ embeds: [successEmbed(settings, `⏩ Seeked to **${raw}**.`)] });
  },
};
