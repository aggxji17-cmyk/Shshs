const { SlashCommandBuilder } = require('discord.js');
const { QueueRepeatMode } = require('discord-player');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { requireActiveQueue } = require('../../utils/musicChecks');
const { getKazagumo } = require('../../services/lavalinkManager');

const MODES = {
  off: { value: QueueRepeatMode.OFF, label: 'disabled' },
  track: { value: QueueRepeatMode.TRACK, label: 'looping the current track' },
  queue: { value: QueueRepeatMode.QUEUE, label: 'looping the whole queue' },
  autoplay: { value: QueueRepeatMode.AUTOPLAY, label: 'autoplaying similar tracks when the queue ends' },
};

// Maps this command's mode names to KazagumoPlayer.setLoop()'s own mode
// names ('none' instead of 'off' - everything else matches). 'autoplay'
// has no entry: Lavalink/Kazagumo has no built-in "play similar tracks
// when the queue ends" feature (that's a discord-player extractor
// feature), so it's handled as an explicit unsupported case below instead
// of silently mapping to something else - same approach filters.js uses
// for FFmpeg-only presets with no Lavalink equivalent.
const KAZAGUMO_LOOP_MODES = { off: 'none', track: 'track', queue: 'queue' };

module.exports = {
  data: new SlashCommandBuilder()
    .setName('loop')
    .setDescription('Set the loop mode')
    .setDescriptionLocalizations({ ar: 'تعيين وضع التكرار', 'en-US': 'Set the loop mode' })
    .addStringOption((o) =>
      o
        .setName('mode')
        .setDescription('Loop mode').setDescriptionLocalizations({ ar: 'وضع التكرار', 'en-US': 'Loop mode' })
        .setRequired(true)
        .addChoices(
          { name: 'Off', value: 'off' },
          { name: 'Track', value: 'track' },
          { name: 'Queue', value: 'queue' },
          { name: 'Autoplay', value: 'autoplay' }
        )
    ),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    const mode = interaction.options.getString('mode', true);

    // Migrated path: if this guild's queue is being run through
    // Kazagumo/Lavalink, set its loop mode that way.
    const kazagumo = getKazagumo();
    const kazagumoPlayer = kazagumo?.players.get(interaction.guildId);

    if (kazagumoPlayer && kazagumoPlayer.queue.current) {
      const memberChannel = interaction.member?.voice?.channel;
      if (!memberChannel || memberChannel.id !== kazagumoPlayer.voiceId) {
        return interaction.reply({
          embeds: [errorEmbed(settings, `Join <#${kazagumoPlayer.voiceId}> to control the music.`)],
          ephemeral: true,
        });
      }

      if (mode === 'autoplay') {
        return interaction.reply({
          embeds: [errorEmbed(settings, "**Autoplay** isn't available over Lavalink yet - try `/loop mode:off|track|queue`.")],
          ephemeral: true,
        });
      }

      kazagumoPlayer.setLoop(KAZAGUMO_LOOP_MODES[mode]);
      return interaction.reply({ embeds: [successEmbed(settings, `🔁 Loop mode is now **${MODES[mode].label}**.`)] });
    }

    // Not migrated for this guild yet (no Kazagumo player, e.g. Lavalink
    // isn't configured, or this guild's queue predates it) - fall back to
    // the original discord-player path so behavior is unchanged from
    // before this task.
    const queue = await requireActiveQueue(interaction, settings);
    if (!queue) return;

    const { value, label } = MODES[mode];

    queue.setRepeatMode(value);
    return interaction.reply({ embeds: [successEmbed(settings, `🔁 Loop mode is now **${label}**.`)] });
  },
};
