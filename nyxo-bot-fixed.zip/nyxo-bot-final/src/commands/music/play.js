const { SlashCommandBuilder } = require('discord.js');
const { useMainPlayer } = require('discord-player');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { errorEmbed, baseEmbed } = require('../../utils/embeds');
const { requireVoiceChannel } = require('../../utils/musicChecks');
const { getKazagumo } = require('../../services/lavalinkManager');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('play')
    .setDescription('Play a song or playlist in your voice channel')
    .setDescriptionLocalizations({ ar: 'تشغيل أغنية أو قائمة تشغيل في القناة الصوتية', 'en-US': 'Play a song or playlist in your voice channel' })
    .addStringOption((o) =>
      o.setName('query').setDescription('Song name, artist, or a YouTube/Spotify/SoundCloud link').setDescriptionLocalizations({ ar: 'اسم الأغنية أو الفنان أو رابط من يوتيوب/سبوتيفاي/ساوندكلاود', 'en-US': 'Song name, artist, or a YouTube/Spotify/SoundCloud link' }).setRequired(true)
    ),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    const voiceChannel = await requireVoiceChannel(interaction, settings);
    if (!voiceChannel) return;

    const permissions = voiceChannel.permissionsFor(interaction.guild.members.me);
    if (!permissions?.has(['Connect', 'Speak'])) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'I need **Connect** and **Speak** permissions in that voice channel.')], ephemeral: true });
    }

    const query = interaction.options.getString('query', true);
    const is247 = guildConfig.music?.twentyFourSeven?.enabled;

    // Engine choice (Task 6): discord-player is the primary engine.
    // Kazagumo/Lavalink is only ever used to *continue* a session that
    // already exists there (e.g. one started before this fix, or created
    // some other way) - it is never chosen for a brand-new session, even
    // when LAVALINK_* is configured. This keeps a running queue from
    // being split across two engines mid-session without making
    // Kazagumo compete with discord-player for new /play requests.
    const kazagumo = getKazagumo();
    const existingKazagumoPlayer = kazagumo?.players.get(interaction.guildId);
    const useKazagumoEngine = Boolean(existingKazagumoPlayer);

    // requireVoiceChannel() above only knows about discord-player's queue
    // channel (see utils/musicChecks.js), so a guild already connected via
    // Kazagumo needs the same "don't let a member in a different channel
    // hijack the session" guard applied here explicitly.
    if (existingKazagumoPlayer && existingKazagumoPlayer.voiceId !== voiceChannel.id) {
      return interaction.reply({
        embeds: [errorEmbed(settings, `I'm already playing music in <#${existingKazagumoPlayer.voiceId}>.`)],
        ephemeral: true,
      });
    }

    await interaction.deferReply();

    if (useKazagumoEngine) {
      return playViaKazagumo(interaction, settings, kazagumo, voiceChannel, query);
    }

    return playViaDiscordPlayer(interaction, settings, voiceChannel, query, is247);
  },
};

async function playViaKazagumo(interaction, settings, kazagumo, voiceChannel, query) {
  try {
    const result = await kazagumo.search(query, { requester: interaction.user });

    if (!result || !result.tracks.length) {
      return interaction.editReply({ embeds: [errorEmbed(settings, "Couldn't find or play that: no results found.")] });
    }

    let player = kazagumo.players.get(interaction.guildId);
    if (!player) {
      player = await kazagumo.createPlayer({
        guildId: interaction.guildId,
        textId: interaction.channel.id,
        voiceId: voiceChannel.id,
        shardId: interaction.guild.shardId ?? 0,
        deaf: true,
        volume: 70,
      });
    }

    // Snapshot "was something already queued" BEFORE adding this
    // request's track(s), same distinction the discord-player path makes
    // between "Starting" (nothing was playing) and "Queued" (something
    // already was).
    const alreadyPlaying = Boolean(player.queue.current) || player.queue.length > 0;

    let description;
    if (result.type === 'PLAYLIST') {
      for (const t of result.tracks) player.queue.add(t);
      const name = result.playlistName || 'Unknown playlist';
      description = alreadyPlaying
        ? `Queued playlist **${name}** (${result.tracks.length} tracks)`
        : `Starting playlist **${name}** (${result.tracks.length} tracks)`;
    } else {
      const track = result.tracks[0];
      player.queue.add(track);
      description = alreadyPlaying
        ? `Queued **[${track.title}](${track.uri})**`
        : `Starting **[${track.title}](${track.uri})**`;
    }

    if (!player.playing && !player.paused) player.play();

    return interaction.editReply({ embeds: [baseEmbed(settings).setDescription(`🎵 ${description}`)] });
  } catch (err) {
    const raw = err?.message || String(err);
    const isYoutubeAuthError = /sign in|not a bot|login required|age.?restrict/i.test(raw);
    const message = isYoutubeAuthError
      ? "YouTube blocked this request (it wants a signed-in session). Ask the bot owner to set `YOUTUBE_COOKIE` in the bot's `.env` - see `.env.example` for how to get one."
      : `Couldn't find or play that: ${raw}`;

    return interaction.editReply({ embeds: [errorEmbed(settings, message)] });
  }
}

async function playViaDiscordPlayer(interaction, settings, voiceChannel, query, is247) {
  const player = useMainPlayer();

  // If 24/7 mode is on for this guild, a fresh queue should never
  // auto-leave either - matches what /247 sets on a queue it creates
  // directly, so behavior is identical whether 24/7 was turned on
  // before or after the first /play.
  try {
    const { track, queue } = await player.play(voiceChannel, query, {
      nodeOptions: {
        metadata: { channel: interaction.channel, requestedBy: interaction.user },
        volume: 70,
        leaveOnEmpty: !is247,
        leaveOnEmptyCooldown: 60_000,
        leaveOnEnd: !is247,
        leaveOnEndCooldown: 300_000,
        leaveOnStop: !is247,
        selfDeaf: true,
      },
      requestedBy: interaction.user,
    });

    const alreadyPlaying = queue.currentTrack && queue.currentTrack.id === track.id && queue.tracks.toArray().length === 0;
    const description = alreadyPlaying
      ? `Starting **[${track.title}](${track.url})**`
      : `Queued **[${track.title}](${track.url})**`;

    return interaction.editReply({ embeds: [baseEmbed(settings).setDescription(`🎵 ${description}`)] });
  } catch (err) {
    const raw = err?.message || String(err);
    const isYoutubeAuthError = /sign in|not a bot|login required|age.?restrict/i.test(raw);
    const message = isYoutubeAuthError
      ? "YouTube blocked this request (it wants a signed-in session). Ask the bot owner to set `YOUTUBE_COOKIE` in the bot's `.env` - see `.env.example` for how to get one."
      : `Couldn't find or play that: ${raw}`;

    return interaction.editReply({ embeds: [errorEmbed(settings, message)] });
  }
}
