const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { getGuildConfig, resolved, invalidateGuildConfig } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed, infoEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');
const { getInviteCount } = require('../../services/inviteService');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('invites')
    .setDescription('View invite stats or configure invite tracking')
    .setDescriptionLocalizations({ ar: 'عرض إحصائيات الدعوات أو إعداد تتبعها', 'en-US': 'View invite stats or configure invite tracking' })
    .addSubcommand((s) => s.setName('view').setDescription('View how many members someone has invited')
      .setDescriptionLocalizations({ ar: 'عرض عدد الأعضاء الذين دعاهم شخص ما', 'en-US': 'View how many members someone has invited' }).addUserOption((o) => o.setName('user').setDescription('User to check (defaults to you)').setDescriptionLocalizations({ ar: 'المستخدم المراد التحقق منه (افتراضياً أنت)', 'en-US': 'User to check (defaults to you)' })))
    .addSubcommand((s) =>
      s
        .setName('config')
        .setDescription('Configure invite tracking')
      .setDescriptionLocalizations({ ar: 'إعداد تتبع الدعوات', 'en-US': 'Configure invite tracking' })
        .addChannelOption((o) => o.setName('log_channel').setDescription('Channel to announce who invited each new member').setDescriptionLocalizations({ ar: 'القناة التي يُعلن فيها عمّن دعا كل عضو جديد', 'en-US': 'Channel to announce who invited each new member' }).addChannelTypes(ChannelType.GuildText))
    )
    .addSubcommand((s) => s.setName('toggle').setDescription('Enable or disable invite tracking')
      .setDescriptionLocalizations({ ar: 'تفعيل أو تعطيل تتبع الدعوات', 'en-US': 'Enable or disable invite tracking' })),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    const sub = interaction.options.getSubcommand();

    if (sub === 'view') {
      const user = interaction.options.getUser('user') || interaction.user;
      const count = await getInviteCount(interaction.guildId, user.id);
      return interaction.reply({ embeds: [infoEmbed(settings, `**${user.tag}** has invited **${count}** member(s).`)] });
    }

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You need Manage Server permission to use this command.')], ephemeral: true });
    }

    if (sub === 'toggle') {
      guildConfig.invites.enabled = !guildConfig.invites.enabled;
      await guildConfig.save();
      invalidateGuildConfig(interaction.guildId);
      return interaction.reply({ embeds: [successEmbed(settings, `Invite tracking is now **${guildConfig.invites.enabled ? 'enabled' : 'disabled'}**.`)] });
    }

    const logChannel = interaction.options.getChannel('log_channel');
    if (logChannel) guildConfig.invites.logChannelId = logChannel.id;
    await guildConfig.save();
    invalidateGuildConfig(interaction.guildId);
    return interaction.reply({ embeds: [successEmbed(settings, 'Invite tracking configuration updated.')] });
  },
};
