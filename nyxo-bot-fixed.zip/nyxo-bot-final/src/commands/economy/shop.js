const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed, infoEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');
const { purchaseItem } = require('../../services/economyService');
const { deliverPurchase } = require('../../services/minecraftDeliveryService');
const { listServers } = require('../../services/minecraftPlayerService');
const { safeAutocomplete, fuzzyFilter } = require('../../utils/autocomplete');
const { t, resolveLanguage } = require('../../utils/i18n');
const ShopItem = require('../../database/models/ShopItem');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('shop')
    .setDescription('Browse and buy from the server shop')
    .setDescriptionLocalizations({ ar: 'تصفح والشراء من متجر السيرفر', 'en-US': 'Browse and buy from the server shop' })
    .addSubcommand((s) => s.setName('list').setDescription('List everything available in the shop')
      .setDescriptionLocalizations({ ar: 'عرض كل ما هو متوفر في المتجر', 'en-US': 'List everything available in the shop' }))
    .addSubcommand((s) => s.setName('buy').setDescription('Buy an item')
      .setDescriptionLocalizations({ ar: 'شراء عنصر', 'en-US': 'Buy an item' }).addStringOption((o) => o.setName('name').setDescription('Item name').setDescriptionLocalizations({ ar: 'اسم العنصر', 'en-US': 'Item name' }).setRequired(true)))
    .addSubcommand((s) =>
      s
        .setName('additem')
        .setDescription('Add an item to the shop (managers only)')
      .setDescriptionLocalizations({ ar: 'إضافة عنصر إلى المتجر (للمدراء فقط)', 'en-US': 'Add an item to the shop (managers only)' })
        .addStringOption((o) => o.setName('name').setDescription('Item name').setDescriptionLocalizations({ ar: 'اسم العنصر', 'en-US': 'Item name' }).setRequired(true))
        .addIntegerOption((o) => o.setName('price').setDescription('Price').setDescriptionLocalizations({ ar: 'السعر', 'en-US': 'Price' }).setRequired(true).setMinValue(1))
        .addStringOption((o) => o.setName('description').setDescription('Description').setDescriptionLocalizations({ ar: 'الوصف', 'en-US': 'Description' }))
        .addRoleOption((o) => o.setName('role').setDescription('Role to grant on purchase').setDescriptionLocalizations({ ar: 'الرتبة الممنوحة عند الشراء', 'en-US': 'Role to grant on purchase' }))
        .addStringOption((o) =>
          o
            .setName('server')
            .setDescription('Minecraft server to deliver this item on (pairs with "command")')
            .setDescriptionLocalizations({
              ar: 'سيرفر Minecraft الذي يُسلَّم عليه هذا العنصر (يُستخدم مع "command")',
              'en-US': 'Minecraft server to deliver this item on (pairs with "command")',
            })
            .setAutocomplete(true)
        )
        .addStringOption((o) =>
          o
            .setName('command')
            .setDescription('Console command to run on purchase - use {player} and {uuid} as placeholders')
            .setDescriptionLocalizations({
              ar: 'أمر الكونسول الذي يُنفَّذ عند الشراء - استخدم {player} و{uuid} كمتغيرات',
              'en-US': 'Console command to run on purchase - use {player} and {uuid} as placeholders',
            })
        )
        .addStringOption((o) =>
          o
            .setName('type')
            .setDescription('Delivery type: rank or item/spawner')
            .setDescriptionLocalizations({
              ar: 'رتبة (تُسلَّم فوراً سواء كان اللاعب متصلاً أم لا) أو آيتم/سباونر (يحتاج اللاعب متصلاً، وإلا يُحفظ ويُسلَّم عند دخوله)',
              'en-US': 'Rank (delivered immediately, online or not) or item/spawner (needs the player online, otherwise queued until they join)',
            })
            .addChoices(
              { name: 'Rank / رتبة', value: 'rank' },
              { name: 'Item / آيتم-سباونر', value: 'item' }
            )
        )
    )
    .addSubcommand((s) => s.setName('removeitem').setDescription('Remove an item from the shop (managers only)')
      .setDescriptionLocalizations({ ar: 'إزالة عنصر من المتجر (للمدراء فقط)', 'en-US': 'Remove an item from the shop (managers only)' }).addStringOption((o) => o.setName('name').setDescription('Item name').setDescriptionLocalizations({ ar: 'اسم العنصر', 'en-US': 'Item name' }).setRequired(true))),

  autocomplete: safeAutocomplete(async (interaction) => {
    const focused = String(interaction.options.getFocused());
    const servers = await listServers();
    const matched = fuzzyFilter(servers, focused, { key: (s) => s.name || s._id });

    return matched.map((s) => ({
      name: `${s.name || s._id}${s.status === 'online' ? ' 🟢' : ' 🔴'}`,
      value: s._id,
    }));
  }),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    const lang = resolveLanguage({ guildConfigDoc: guildConfig, interaction });
    const sub = interaction.options.getSubcommand();

    if (!guildConfig.economy?.enabled) {
      return interaction.reply({ embeds: [errorEmbed(settings, t(lang, 'shop.disabled'))], ephemeral: true });
    }

    if (sub === 'list') {
      const items = await ShopItem.find({ guildId: interaction.guildId });
      if (!items.length) return interaction.reply({ embeds: [infoEmbed(settings, t(lang, 'shop.empty'))] });
      const lines = items.map((i) => `**${i.name}** - ${i.price} ${guildConfig.economy.currencySymbol}${i.description ? ` - ${i.description}` : ''}`);
      return interaction.reply({ embeds: [infoEmbed(settings, lines.join('\n'))] });
    }

    if (sub === 'buy') {
      const name = interaction.options.getString('name');
      const item = await ShopItem.findOne({ guildId: interaction.guildId, name });
      if (!item) return interaction.reply({ embeds: [errorEmbed(settings, t(lang, 'shop.item_not_found'))], ephemeral: true });

      const result = await purchaseItem(interaction.guildId, interaction.user.id, item);
      if (!result.success) return interaction.reply({ embeds: [errorEmbed(settings, result.reason)], ephemeral: true });

      if (item.roleId) await interaction.member.roles.add(item.roleId).catch(() => null);

      // In-game delivery (Task 4/5). The purchase itself already succeeded
      // (balance deducted, role granted) - a delivery failure here is
      // reported alongside the success message rather than undone, same
      // as any real-world "payment went through, delivery pending"
      // pattern. The attempt (success, queued, or failure) is always
      // logged by deliverPurchase regardless of how this reply reads.
      const delivery = await deliverPurchase({
        guild: interaction.guild,
        guildConfig,
        discordUserId: interaction.user.id,
        item,
        requestedBy: `discord:${interaction.user.id}`,
        lang,
      });

      const purchasedEmbed = successEmbed(settings, t(lang, 'shop.purchased', { item: item.name }));

      if (delivery.success === false) {
        return interaction.reply({ embeds: [purchasedEmbed.addFields({ name: t(lang, 'minecraft_delivery.delivery_failed_title'), value: delivery.reason })] });
      }

      if (delivery.queued) {
        return interaction.reply({
          embeds: [purchasedEmbed.addFields({ name: t(lang, 'minecraft_delivery.queued_title'), value: t(lang, 'minecraft_delivery.queued_body') })],
        });
      }

      return interaction.reply({ embeds: [purchasedEmbed] });
    }

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, t(lang, 'common.manager_required'))], ephemeral: true });
    }

    if (sub === 'additem') {
      const name = interaction.options.getString('name');
      const price = interaction.options.getInteger('price');
      const description = interaction.options.getString('description') || '';
      const role = interaction.options.getRole('role');
      const serverId = interaction.options.getString('server');
      const command = interaction.options.getString('command');
      const kind = interaction.options.getString('type') || 'item';

      if ((serverId && !command) || (!serverId && command)) {
        return interaction.reply({ embeds: [errorEmbed(settings, t(lang, 'common.server_command_pair_required'))], ephemeral: true });
      }

      await ShopItem.findOneAndUpdate(
        { guildId: interaction.guildId, name },
        {
          price,
          description,
          roleId: role?.id || null,
          minecraft:
            serverId && command
              ? { enabled: true, kind, targetServerId: serverId, commandTemplate: command }
              : { enabled: false, kind: 'item', targetServerId: null, commandTemplate: null },
        },
        { upsert: true }
      );
      return interaction.reply({
        embeds: [successEmbed(settings, t(lang, 'shop.item_upserted', { item: name, price, currency: guildConfig.economy.currencySymbol }))],
      });
    }

    const name = interaction.options.getString('name');
    const removed = await ShopItem.findOneAndDelete({ guildId: interaction.guildId, name });
    return interaction.reply({
      embeds: [removed ? successEmbed(settings, t(lang, 'shop.item_removed', { item: name })) : errorEmbed(settings, t(lang, 'shop.item_not_found'))],
    });
  },
};
