const { SlashCommandBuilder } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { infoEmbed, errorEmbed } = require('../../utils/embeds');
const { getBalance } = require('../../services/economyService');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('balance')
    .setDescription('Check your (or someone else\'s) balance')
    .setDescriptionLocalizations({ ar: 'عرض رصيدك أو رصيد عضو آخر', 'en-US': 'Check your (or someone else\'s) balance' })
    .addUserOption((o) => o.setName('user').setDescription('User to check (defaults to you)').setDescriptionLocalizations({ ar: 'المستخدم المراد التحقق منه (افتراضياً أنت)', 'en-US': 'User to check (defaults to you)' })),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!guildConfig.economy?.enabled) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'The economy system is not enabled on this server.')], ephemeral: true });
    }

    const user = interaction.options.getUser('user') || interaction.user;
    const balance = await getBalance(interaction.guildId, user.id);

    return interaction.reply({
      embeds: [infoEmbed(settings, `**${user.tag}** has **${balance}** ${guildConfig.economy.currencySymbol} ${guildConfig.economy.currencyName}.`)],
    });
  },
};
