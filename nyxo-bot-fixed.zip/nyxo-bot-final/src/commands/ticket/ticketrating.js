const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { getGuildConfig, resolved, invalidateGuildConfig } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed, baseEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');
const { DEFAULT_PROMPT_MESSAGE, DEFAULT_THANK_YOU_MESSAGE } = require('../../services/ratingService');
const Rating = require('../../database/models/Rating');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ticketrating')
    .setDescription('Configure the post-ticket support rating system')
    .setDescriptionLocalizations({ ar: 'إعداد نظام تقييم الدعم الفني بعد إغلاق التذاكر', 'en-US': 'Configure the post-ticket support rating system' })
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((s) =>
      s
        .setName('toggle')
        .setDescription('Enable or disable the rating system')
        .setDescriptionLocalizations({ ar: 'تفعيل أو تعطيل نظام التقييم', 'en-US': 'Enable or disable the rating system' })
    )
    .addSubcommand((s) =>
      s
        .setName('setchannel')
        .setDescription('Set the channel rating results are posted to')
        .setDescriptionLocalizations({ ar: 'تحديد الروم الذي تُرسل إليه نتائج التقييمات', 'en-US': 'Set the channel rating results are posted to' })
        .addChannelOption((o) =>
          o
            .setName('channel')
            .setDescription('Channel for rating results')
            .setDescriptionLocalizations({ ar: 'روم نتائج التقييمات', 'en-US': 'Channel for rating results' })
            .addChannelTypes(ChannelType.GuildText)
            .setRequired(true)
        )
    )
    .addSubcommand((s) =>
      s
        .setName('setmessage')
        .setDescription('Customize the rating-prompt DM or the thank-you message')
        .setDescriptionLocalizations({ ar: 'تعديل رسالة طلب التقييم أو رسالة الشكر', 'en-US': 'Customize the rating-prompt DM or the thank-you message' })
        .addStringOption((o) =>
          o
            .setName('type')
            .setDescription('Which message to edit')
            .setDescriptionLocalizations({ ar: 'الرسالة المراد تعديلها', 'en-US': 'Which message to edit' })
            .setRequired(true)
            .addChoices(
              { name: 'رسالة طلب التقييم (Prompt)', value: 'prompt' },
              { name: 'رسالة الشكر (Thank you)', value: 'thanks' }
            )
        )
        .addStringOption((o) =>
          o
            .setName('message')
            .setDescription('New message text. Prompt supports {number} {type} {server} - use \\n for new lines')
            .setDescriptionLocalizations({ ar: 'النص الجديد. رسالة الطلب تدعم {number} {type} {server} - استخدم \\n لسطر جديد', 'en-US': 'New message text. Prompt supports {number} {type} {server} - use \\n for new lines' })
            .setRequired(true)
            .setMaxLength(1000)
        )
    )
    .addSubcommand((s) =>
      s
        .setName('reset')
        .setDescription('Reset the prompt/thank-you messages back to the defaults')
        .setDescriptionLocalizations({ ar: 'إعادة رسالة الطلب/الشكر إلى الإعدادات الافتراضية', 'en-US': 'Reset the prompt/thank-you messages back to the defaults' })
    )
    .addSubcommand((s) =>
      s
        .setName('stats')
        .setDescription('Show average rating - overall, or for a specific staff member')
        .setDescriptionLocalizations({ ar: 'عرض متوسط التقييمات - عام أو لإداري محدد', 'en-US': 'Show average rating - overall, or for a specific staff member' })
        .addUserOption((o) =>
          o
            .setName('staff')
            .setDescription('Show this staff member\'s average only')
            .setDescriptionLocalizations({ ar: 'عرض متوسط هذا الإداري فقط', 'en-US': "Show this staff member's average only" })
        )
    ),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'ليس لديك صلاحية استخدام هذا الأمر (تحتاج صلاحية إدارة السيرفر).')], ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();
    if (!guildConfig.tickets.ratings) guildConfig.tickets.ratings = {};

    if (sub === 'toggle') return handleToggle(interaction, guildConfig, settings);
    if (sub === 'setchannel') return handleSetChannel(interaction, guildConfig, settings);
    if (sub === 'setmessage') return handleSetMessage(interaction, guildConfig, settings);
    if (sub === 'reset') return handleReset(interaction, guildConfig, settings);
    if (sub === 'stats') return handleStats(interaction, guildConfig, settings);
  },
};

async function handleToggle(interaction, guildConfig, settings) {
  guildConfig.tickets.ratings.enabled = !guildConfig.tickets.ratings.enabled;
  await guildConfig.save();
  invalidateGuildConfig(interaction.guildId);

  const state = guildConfig.tickets.ratings.enabled;
  const note = state && !guildConfig.tickets.ratings.channelId ? '\n⚠️ لم يتم تحديد روم للتقييمات بعد - استخدم `/ticketrating setchannel`.' : '';

  return interaction.reply({
    embeds: [successEmbed(settings, `نظام تقييم الدعم الفني الآن **${state ? 'مفعّل ✅' : 'معطّل ❌'}**.${note}`)],
  });
}

async function handleSetChannel(interaction, guildConfig, settings) {
  const channel = interaction.options.getChannel('channel');
  guildConfig.tickets.ratings.channelId = channel.id;
  await guildConfig.save();
  invalidateGuildConfig(interaction.guildId);

  return interaction.reply({
    embeds: [successEmbed(settings, `سيتم إرسال نتائج التقييمات إلى ${channel}.`)],
    ephemeral: true,
  });
}

async function handleSetMessage(interaction, guildConfig, settings) {
  const type = interaction.options.getString('type');
  const message = interaction.options.getString('message').replace(/\\n/g, '\n');

  if (type === 'prompt') {
    guildConfig.tickets.ratings.promptMessage = message;
  } else {
    guildConfig.tickets.ratings.thankYouMessage = message;
  }

  await guildConfig.save();
  invalidateGuildConfig(interaction.guildId);

  return interaction.reply({
    embeds: [successEmbed(settings, `تم تحديث ${type === 'prompt' ? 'رسالة طلب التقييم' : 'رسالة الشكر'}.`)],
    ephemeral: true,
  });
}

async function handleReset(interaction, guildConfig, settings) {
  guildConfig.tickets.ratings.promptMessage = null;
  guildConfig.tickets.ratings.thankYouMessage = null;
  await guildConfig.save();
  invalidateGuildConfig(interaction.guildId);

  return interaction.reply({
    embeds: [successEmbed(settings, 'تمت إعادة رسالتي الطلب والشكر إلى الإعدادات الافتراضية.')],
    ephemeral: true,
  });
}

async function handleStats(interaction, guildConfig, settings) {
  const staff = interaction.options.getUser('staff');

  if (staff) {
    const agg = await Rating.aggregate([
      { $match: { guildId: interaction.guildId, staffId: staff.id } },
      { $group: { _id: '$staffId', avg: { $avg: '$stars' }, count: { $sum: 1 } } },
    ]);

    if (!agg.length) {
      return interaction.reply({ embeds: [errorEmbed(settings, `لا توجد تقييمات مسجّلة لـ **${staff.tag}** بعد.`)], ephemeral: true });
    }

    const { avg, count } = agg[0];
    return interaction.reply({
      embeds: [
        baseEmbed(settings)
          .setTitle(`📊・إحصائيات تقييم ${staff.tag}`)
          .addFields(
            { name: 'متوسط التقييم', value: `⭐ ${avg.toFixed(2)} / 5`, inline: true },
            { name: 'عدد التقييمات', value: `${count}`, inline: true }
          ),
      ],
    });
  }

  const agg = await Rating.aggregate([
    { $match: { guildId: interaction.guildId, staffId: { $ne: null } } },
    { $group: { _id: '$staffId', avg: { $avg: '$stars' }, count: { $sum: 1 } } },
    { $sort: { avg: -1 } },
    { $limit: 15 },
  ]);

  if (!agg.length) {
    return interaction.reply({ embeds: [errorEmbed(settings, 'لا توجد أي تقييمات مسجّلة في هذا السيرفر بعد.')], ephemeral: true });
  }

  const lines = agg.map((row, i) => `**${i + 1}.** <@${row._id}> — ⭐ ${row.avg.toFixed(2)}/5 (${row.count} تقييم)`);

  return interaction.reply({
    embeds: [baseEmbed(settings).setTitle('📊・متوسط تقييمات فريق الدعم').setDescription(lines.join('\n'))],
  });
}
