const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { getGuildConfig, resolved, invalidateGuildConfig } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed, baseEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');
const { safeAutocomplete, fuzzyFilter } = require('../../utils/autocomplete');
const { buildPanelEmbed, buildPanelComponents, MAX_TOTAL_TYPES } = require('../../utils/ticketPanel');
const { DEFAULT_CLOSE_MESSAGE, DEFAULT_DELETE_LABEL, DEFAULT_REOPEN_LABEL } = require('../../services/ticketCloseService');

const TYPE_ID_RE = /^[a-z0-9_-]{1,20}$/;
const TYPES_PER_LIST_EMBED = 8; // keeps each embed well under Discord's field/description limits

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ticketsetup')
    .setDescription('Configure and deploy the support ticket system')
    .setDescriptionLocalizations({ ar: 'إعداد ونشر نظام تذاكر الدعم', 'en-US': 'Configure and deploy the support ticket system' })
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((s) =>
      s
        .setName('config')
        .setDescription('Configure ticket categories/roles and the panel text')
        .setDescriptionLocalizations({ ar: 'إعداد فئات التذاكر والرتب ونصوص لوحة التذاكر', 'en-US': 'Configure ticket categories/roles and the panel text' })
        .addChannelOption((o) => o.setName('category').setDescription('Default category new ticket channels are created under').setDescriptionLocalizations({ ar: 'الفئة الافتراضية التي تُنشأ تحتها قنوات التذاكر الجديدة', 'en-US': 'Default category new ticket channels are created under' }).addChannelTypes(ChannelType.GuildCategory))
        .addRoleOption((o) => o.setName('support_role').setDescription('Default role mentioned + given view access when a type has no override').setDescriptionLocalizations({ ar: 'الرتبة الافتراضية التي تُمنشن ويُمنح لها صلاحية الرؤية عند عدم وجود إعداد مخصص للنوع', 'en-US': 'Default role mentioned + given view access when a type has no override' }))
        .addChannelOption((o) => o.setName('log_channel').setDescription('Channel where closed-ticket logs are sent').setDescriptionLocalizations({ ar: 'القناة التي تُرسل إليها سجلات التذاكر المغلقة', 'en-US': 'Channel where closed-ticket logs are sent' }).addChannelTypes(ChannelType.GuildText))
        .addStringOption((o) => o.setName('panel_title').setDescription('Title shown at the top of the ticket panel embed').setDescriptionLocalizations({ ar: 'العنوان الظاهر أعلى رسالة لوحة التذاكر', 'en-US': 'Title shown at the top of the ticket panel embed' }).setMaxLength(256))
        .addStringOption((o) => o.setName('panel_description').setDescription('Intro text explaining the ticket system').setDescriptionLocalizations({ ar: 'نص تعريفي يشرح نظام التذاكر', 'en-US': 'Intro text explaining the ticket system' }).setMaxLength(2000))
        .addStringOption((o) => o.setName('panel_rules').setDescription('Rules/instructions text shown in the panel (use \\n for new lines)').setDescriptionLocalizations({ ar: 'نص القوانين/التعليمات الظاهر في اللوحة (استخدم \\n لسطر جديد)', 'en-US': 'Rules/instructions text shown in the panel (use \\n for new lines)' }).setMaxLength(1024))
    )
    .addSubcommand((s) => s.setName('panel').setDescription('Post (or refresh) the ticket panel in this channel')
      .setDescriptionLocalizations({ ar: 'نشر (أو تحديث) لوحة التذاكر في هذه القناة', 'en-US': 'Post (or refresh) the ticket panel in this channel' }))
    .addSubcommand((s) => s.setName('toggle').setDescription('Enable or disable the ticket system')
      .setDescriptionLocalizations({ ar: 'تفعيل أو تعطيل نظام التذاكر', 'en-US': 'Enable or disable the ticket system' }))
    .addSubcommandGroup((g) =>
      g
        .setName('type')
        .setDescription('Manage per-type ticket settings (name, category, role, welcome message, channel name...)')
        .setDescriptionLocalizations({ ar: 'إدارة إعدادات كل نوع تذكرة (الاسم، الكاتقوري، الرتبة، رسالة الترحيب، اسم الروم...)', 'en-US': 'Manage per-type ticket settings (name, category, role, welcome message, channel name...)' })
        .addSubcommand((s) =>
          s
            .setName('add')
            .setDescription('Add a ticket type, or update it if the id already exists')
            .setDescriptionLocalizations({ ar: 'إضافة نوع تذكرة، أو تحديثه إذا كان المعرّف موجوداً مسبقاً', 'en-US': 'Add a ticket type, or update it if the id already exists' })
            .addStringOption((o) => o.setName('id').setDescription('Short unique id, e.g. "general" (lowercase letters/numbers/-/_ only)').setDescriptionLocalizations({ ar: 'معرّف قصير وفريد، مثل "general" (حروف إنجليزية صغيرة/أرقام/- /_ فقط)', 'en-US': 'Short unique id, e.g. "general" (lowercase letters/numbers/-/_ only)' }).setRequired(true).setMaxLength(20))
            .addStringOption((o) => o.setName('label').setDescription('Ticket type name, shown on the button/menu option').setDescriptionLocalizations({ ar: 'اسم نوع التذكرة، يظهر على الزر أو خيار القائمة', 'en-US': 'Ticket type name, shown on the button/menu option' }).setRequired(true).setMaxLength(80))
            .addStringOption((o) =>
              o
                .setName('style')
                .setDescription('Button color (ignored once the panel switches to a dropdown - see /ticketsetup type list)')
                .setDescriptionLocalizations({ ar: 'لون الزر (يُتجاهل إذا تحوّلت اللوحة لقائمة منسدلة - راجع /ticketsetup type list)', 'en-US': 'Button color (ignored once the panel switches to a dropdown - see /ticketsetup type list)' })
                .setRequired(true)
                .addChoices(
                  { name: 'Blurple (Primary)', value: 'Primary' },
                  { name: 'Grey (Secondary)', value: 'Secondary' },
                  { name: 'Green (Success)', value: 'Success' },
                  { name: 'Red (Danger)', value: 'Danger' }
                )
            )
            .addStringOption((o) => o.setName('emoji').setDescription('Emoji shown on the button/menu option, e.g. 🎫 or a custom emoji').setDescriptionLocalizations({ ar: 'الإيموجي الظاهر على الزر/خيار القائمة، مثل 🎫 أو إيموجي مخصص', 'en-US': 'Emoji shown on the button/menu option, e.g. 🎫 or a custom emoji' }))
            .addStringOption((o) => o.setName('description').setDescription('Short description shown next to this type in the panel').setDescriptionLocalizations({ ar: 'وصف قصير يظهر بجانب هذا النوع في اللوحة', 'en-US': 'Short description shown next to this type in the panel' }).setMaxLength(150))
            .addChannelOption((o) => o.setName('category').setDescription('الكاتقوري: category override for this type only (omit to use the default)').setDescriptionLocalizations({ ar: 'الكاتقوري المخصص لهذا النوع فقط (اتركه فارغاً لاستخدام الفئة الافتراضية)', 'en-US': 'Category override for this type only (omit to use the default)' }).addChannelTypes(ChannelType.GuildCategory))
            .addRoleOption((o) => o.setName('mention_role').setDescription('Role mentioned when a ticket of this type opens (omit to use the default)').setDescriptionLocalizations({ ar: 'الرتبة التي يتم منشنها عند فتح تذكرة من هذا النوع (اتركه فارغاً لاستخدام الرتبة الافتراضية)', 'en-US': 'Role mentioned when a ticket of this type opens (omit to use the default)' }))
            .addStringOption((o) => o.setName('welcome_message').setDescription('Welcome message shown in the ticket. Placeholders: {user} {type} {number}').setDescriptionLocalizations({ ar: 'رسالة الترحيب الظاهرة داخل التذكرة. المتغيرات المتاحة: {user} {type} {number}', 'en-US': 'Welcome message shown in the ticket. Placeholders: {user} {type} {number}' }).setMaxLength(1500))
            .addStringOption((o) => o.setName('channel_name').setDescription('Ticket channel name template. Placeholders: {user} {number}, e.g. "support-{number}"').setDescriptionLocalizations({ ar: 'اسم الروم (قالب اسم قناة التذكرة). المتغيرات المتاحة: {user} {number}، مثل "support-{number}"', 'en-US': 'Ticket channel name template. Placeholders: {user} {number}, e.g. "support-{number}"' }).setMaxLength(90))
        )
        .addSubcommand((s) =>
          s
            .setName('remove')
            .setDescription('Remove a ticket type')
            .setDescriptionLocalizations({ ar: 'حذف نوع تذكرة', 'en-US': 'Remove a ticket type' })
            .addStringOption((o) => o.setName('id').setDescription('The type id to remove').setDescriptionLocalizations({ ar: 'معرّف النوع المراد حذفه', 'en-US': 'The type id to remove' }).setRequired(true).setAutocomplete(true))
        )
        .addSubcommand((s) => s.setName('list').setDescription('List all configured ticket types and their settings')
          .setDescriptionLocalizations({ ar: 'عرض جميع أنواع التذاكر المُعدّة وإعداداتها', 'en-US': 'List all configured ticket types and their settings' }))
        .addSubcommand((s) =>
          s
            .setName('addview')
            .setDescription('Grant a role view access to tickets of this type (صلاحيات الرؤية) - can add several')
            .setDescriptionLocalizations({ ar: 'منح رتبة صلاحية رؤية التذاكر من هذا النوع - يمكن إضافة أكثر من رتبة', 'en-US': 'Grant a role view access to tickets of this type (صلاحيات الرؤية) - can add several' })
            .addStringOption((o) => o.setName('id').setDescription('The ticket type id').setDescriptionLocalizations({ ar: 'معرّف نوع التذكرة', 'en-US': 'The ticket type id' }).setRequired(true).setAutocomplete(true))
            .addRoleOption((o) => o.setName('role').setDescription('Role to grant view access to').setDescriptionLocalizations({ ar: 'الرتبة المراد منحها صلاحية الرؤية', 'en-US': 'Role to grant view access to' }).setRequired(true))
        )
        .addSubcommand((s) =>
          s
            .setName('removeview')
            .setDescription('Revoke a role\'s view access to tickets of this type')
            .setDescriptionLocalizations({ ar: 'إزالة صلاحية الرؤية عن رتبة لتذاكر هذا النوع', 'en-US': "Revoke a role's view access to tickets of this type" })
            .addStringOption((o) => o.setName('id').setDescription('The ticket type id').setDescriptionLocalizations({ ar: 'معرّف نوع التذكرة', 'en-US': 'The ticket type id' }).setRequired(true).setAutocomplete(true))
            .addRoleOption((o) => o.setName('role').setDescription('Role to revoke view access from').setDescriptionLocalizations({ ar: 'الرتبة المراد إزالة صلاحية الرؤية عنها', 'en-US': 'Role to revoke view access from' }).setRequired(true))
        )
    )
    .addSubcommandGroup((g) =>
      g
        .setName('closeprompt')
        .setDescription('Customize the smart-close 🗑️/🔓 confirmation message, button labels, and auto-delete timer')
        .setDescriptionLocalizations({ ar: 'تخصيص رسالة تأكيد الإغلاق الذكي 🗑️/🔓 ونصوص الأزرار ومؤقت الحذف التلقائي', 'en-US': 'Customize the smart-close 🗑️/🔓 confirmation message, button labels, and auto-delete timer' })
        .addSubcommand((s) =>
          s
            .setName('setmessage')
            .setDescription('Set the confirmation message or a button label')
            .setDescriptionLocalizations({ ar: 'تعديل رسالة التأكيد أو نص أحد الزرين', 'en-US': 'Set the confirmation message or a button label' })
            .addStringOption((o) =>
              o
                .setName('type')
                .setDescription('Which text to edit')
                .setDescriptionLocalizations({ ar: 'النص المراد تعديله', 'en-US': 'Which text to edit' })
                .setRequired(true)
                .addChoices(
                  { name: 'رسالة التأكيد (Confirmation message)', value: 'message' },
                  { name: 'نص زر الحذف نهائياً (Delete button)', value: 'delete_button' },
                  { name: 'نص زر إعادة الفتح (Reopen button)', value: 'reopen_button' }
                )
            )
            .addStringOption((o) =>
              o
                .setName('text')
                .setDescription('New text. The confirmation message supports {number} {type} {minutes} - use \\n for new lines')
                .setDescriptionLocalizations({ ar: 'النص الجديد. رسالة التأكيد تدعم {number} {type} {minutes} - استخدم \\n لسطر جديد', 'en-US': 'New text. The confirmation message supports {number} {type} {minutes} - use \\n for new lines' })
                .setRequired(true)
                .setMaxLength(1000)
            )
        )
        .addSubcommand((s) =>
          s
            .setName('settimer')
            .setDescription('Set how many minutes an unattended closed ticket waits before being auto-deleted (0 = disable)')
            .setDescriptionLocalizations({ ar: 'تحديد عدد الدقائق التي تنتظرها التذكرة المغلقة قبل حذفها تلقائياً (0 = تعطيل)', 'en-US': 'Set how many minutes an unattended closed ticket waits before being auto-deleted (0 = disable)' })
            .addIntegerOption((o) =>
              o
                .setName('minutes')
                .setDescription('Minutes before auto-delete, 0 to disable')
                .setDescriptionLocalizations({ ar: 'عدد الدقائق قبل الحذف التلقائي، 0 للتعطيل', 'en-US': 'Minutes before auto-delete, 0 to disable' })
                .setRequired(true)
                .setMinValue(0)
                .setMaxValue(43200)
            )
        )
        .addSubcommand((s) =>
          s
            .setName('setwarning')
            .setDescription('Set when the channel changes from 🔵 to 🔴 before deletion')
            .setDescriptionLocalizations({
              ar: 'تحديد عدد الدقائق قبل الحذف التلقائي التي يتحول عندها اسم الروم من 🔵 إلى 🔴 (0 = تعطيل مرحلة 🔴)',
              'en-US': 'Set how many minutes before auto-delete the channel switches from 🔵 to 🔴 (0 = disable the 🔴 stage)',
            })
            .addIntegerOption((o) =>
              o
                .setName('minutes')
                .setDescription('Minutes remaining when the 🔴 warning kicks in, 0 to disable')
                .setDescriptionLocalizations({ ar: 'عدد الدقائق المتبقية عند تفعيل تحذير 🔴، 0 للتعطيل', 'en-US': 'Minutes remaining when the 🔴 warning kicks in, 0 to disable' })
                .setRequired(true)
                .setMinValue(0)
                .setMaxValue(43200)
            )
        )
        .addSubcommand((s) => s.setName('reset').setDescription('Reset the confirmation message, button labels, and timers back to defaults')
          .setDescriptionLocalizations({ ar: 'إعادة رسالة التأكيد ونصوص الأزرار والمؤقتات إلى الإعدادات الافتراضية', 'en-US': 'Reset the confirmation message, button labels, and timers back to defaults' }))
    ),

  autocomplete: safeAutocomplete(async (interaction) => {
    const focused = interaction.options.getFocused(true);
    if (focused.name !== 'id') return [];

    const guildConfig = await getGuildConfig(interaction.guildId);
    const types = guildConfig.tickets.types || [];
    const matched = fuzzyFilter(types, String(focused.value), { key: (t) => `${t.typeId} ${t.label}` });
    return matched.map((t) => ({ name: `${t.label} (${t.typeId})`, value: t.typeId }));
  }),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'ليس لديك صلاحية استخدام هذا الأمر (تحتاج صلاحية إدارة السيرفر).')], ephemeral: true });
    }

    const group = interaction.options.getSubcommandGroup(false);
    const sub = interaction.options.getSubcommand();

    if (group === 'type') {
      if (sub === 'add') return handleTypeAdd(interaction, guildConfig, settings);
      if (sub === 'remove') return handleTypeRemove(interaction, guildConfig, settings);
      if (sub === 'list') return handleTypeList(interaction, guildConfig, settings);
      if (sub === 'addview') return handleTypeView(interaction, guildConfig, settings, 'add');
      if (sub === 'removeview') return handleTypeView(interaction, guildConfig, settings, 'remove');
    }

    if (group === 'closeprompt') {
      if (sub === 'setmessage') return handleClosePromptSetMessage(interaction, guildConfig, settings);
      if (sub === 'settimer') return handleClosePromptSetTimer(interaction, guildConfig, settings);
      if (sub === 'setwarning') return handleClosePromptSetWarning(interaction, guildConfig, settings);
      if (sub === 'reset') return handleClosePromptReset(interaction, guildConfig, settings);
    }

    if (sub === 'config') return handleConfig(interaction, guildConfig, settings);
    if (sub === 'toggle') return handleToggle(interaction, guildConfig, settings);
    if (sub === 'panel') return handlePanel(interaction, guildConfig, settings);
  },
};

async function handleConfig(interaction, guildConfig, settings) {
  const category = interaction.options.getChannel('category');
  const supportRole = interaction.options.getRole('support_role');
  const logChannel = interaction.options.getChannel('log_channel');
  const panelTitle = interaction.options.getString('panel_title');
  const panelDescription = interaction.options.getString('panel_description');
  const panelRules = interaction.options.getString('panel_rules');

  if (category) guildConfig.tickets.categoryId = category.id;
  if (supportRole) guildConfig.tickets.supportRoleId = supportRole.id;
  if (logChannel) guildConfig.tickets.logChannelId = logChannel.id;
  if (panelTitle) guildConfig.tickets.panelTitle = panelTitle.replace(/\\n/g, '\n');
  if (panelDescription) guildConfig.tickets.panelDescription = panelDescription.replace(/\\n/g, '\n');
  if (panelRules) guildConfig.tickets.panelRules = panelRules.replace(/\\n/g, '\n');

  await guildConfig.save();
  invalidateGuildConfig(interaction.guildId);
  return interaction.reply({ embeds: [successEmbed(settings, 'تم تحديث إعدادات نظام التذاكر. استخدم `/ticketsetup panel` لتحديث اللوحة المنشورة إن وُجدت.')], ephemeral: true });
}

async function handleToggle(interaction, guildConfig, settings) {
  guildConfig.tickets.enabled = !guildConfig.tickets.enabled;
  await guildConfig.save();
  invalidateGuildConfig(interaction.guildId);
  return interaction.reply({
    embeds: [successEmbed(settings, `نظام التذاكر الآن **${guildConfig.tickets.enabled ? 'مفعّل ✅' : 'معطّل ❌'}**.`)],
  });
}

async function handlePanel(interaction, guildConfig, settings) {
  if (!guildConfig.tickets.enabled) {
    return interaction.reply({ embeds: [errorEmbed(settings, 'يجب تفعيل نظام التذاكر أولاً باستخدام `/ticketsetup toggle`.')], ephemeral: true });
  }

  const message = await interaction.channel.send({
    embeds: [buildPanelEmbed(settings, guildConfig)],
    components: buildPanelComponents(guildConfig),
  });

  guildConfig.tickets.panelChannelId = interaction.channelId;
  guildConfig.tickets.panelMessageId = message.id;
  await guildConfig.save();
  invalidateGuildConfig(interaction.guildId);

  return interaction.reply({ embeds: [successEmbed(settings, 'تم نشر لوحة التذاكر.')], ephemeral: true });
}

async function handleTypeAdd(interaction, guildConfig, settings) {
  const typeId = interaction.options.getString('id').toLowerCase();
  if (!TYPE_ID_RE.test(typeId)) {
    return interaction.reply({
      embeds: [errorEmbed(settings, 'المعرّف غير صالح - استخدم حروفاً إنجليزية صغيرة وأرقام و- و_ فقط (بحد أقصى 20 رمزاً).')],
      ephemeral: true,
    });
  }

  const types = guildConfig.tickets.types;
  const existing = types.find((t) => t.typeId === typeId);

  if (!existing && types.length >= MAX_TOTAL_TYPES) {
    return interaction.reply({ embeds: [errorEmbed(settings, `الحد الأقصى ${MAX_TOTAL_TYPES} نوع تذكرة (حدود مكونات ديسكورد).`)], ephemeral: true });
  }

  const label = interaction.options.getString('label');
  const style = interaction.options.getString('style');
  const emoji = interaction.options.getString('emoji');
  const description = interaction.options.getString('description');
  const category = interaction.options.getChannel('category');
  const mentionRole = interaction.options.getRole('mention_role');
  const welcomeMessage = interaction.options.getString('welcome_message');
  const channelName = interaction.options.getString('channel_name');

  const entry = existing || { typeId, viewRoleIds: [] };
  entry.label = label;
  entry.style = style;
  if (emoji !== null) entry.emoji = emoji || null;
  if (description !== null) entry.description = description || null;
  if (category) entry.categoryId = category.id;
  if (mentionRole) entry.mentionRoleId = mentionRole.id;
  if (welcomeMessage !== null) entry.welcomeMessage = welcomeMessage ? welcomeMessage.replace(/\\n/g, '\n') : null;
  if (channelName !== null) entry.channelName = channelName || null;

  if (!existing) types.push(entry);

  guildConfig.markModified('tickets.types');
  await guildConfig.save();
  invalidateGuildConfig(interaction.guildId);

  return interaction.reply({
    embeds: [successEmbed(settings, `تم ${existing ? 'تحديث' : 'إضافة'} نوع التذكرة **${label}** (\`${typeId}\`). استخدم \`/ticketsetup panel\` لتحديث اللوحة المنشورة.`)],
    ephemeral: true,
  });
}

async function handleTypeRemove(interaction, guildConfig, settings) {
  const typeId = interaction.options.getString('id').toLowerCase();
  const types = guildConfig.tickets.types;
  const before = types.length;
  guildConfig.tickets.types = types.filter((t) => t.typeId !== typeId);

  if (guildConfig.tickets.types.length === before) {
    return interaction.reply({ embeds: [errorEmbed(settings, `لا يوجد نوع تذكرة بالمعرّف \`${typeId}\`.`)], ephemeral: true });
  }

  guildConfig.markModified('tickets.types');
  await guildConfig.save();
  invalidateGuildConfig(interaction.guildId);

  return interaction.reply({
    embeds: [successEmbed(settings, `تم حذف نوع التذكرة \`${typeId}\`. استخدم \`/ticketsetup panel\` لتحديث اللوحة المنشورة.`)],
    ephemeral: true,
  });
}

async function handleTypeView(interaction, guildConfig, settings, action) {
  const typeId = interaction.options.getString('id').toLowerCase();
  const role = interaction.options.getRole('role');
  const type = guildConfig.tickets.types.find((t) => t.typeId === typeId);

  if (!type) {
    return interaction.reply({ embeds: [errorEmbed(settings, `لا يوجد نوع تذكرة بالمعرّف \`${typeId}\`.`)], ephemeral: true });
  }

  type.viewRoleIds = type.viewRoleIds || [];

  if (action === 'add') {
    if (type.viewRoleIds.includes(role.id)) {
      return interaction.reply({ embeds: [errorEmbed(settings, `رتبة **${role.name}** لديها صلاحية الرؤية بالفعل لنوع \`${typeId}\`.`)], ephemeral: true });
    }
    type.viewRoleIds.push(role.id);
  } else {
    if (!type.viewRoleIds.includes(role.id)) {
      return interaction.reply({ embeds: [errorEmbed(settings, `رتبة **${role.name}** لا تملك صلاحية رؤية مخصصة لنوع \`${typeId}\`.`)], ephemeral: true });
    }
    type.viewRoleIds = type.viewRoleIds.filter((id) => id !== role.id);
  }

  guildConfig.markModified('tickets.types');
  await guildConfig.save();
  invalidateGuildConfig(interaction.guildId);

  const verb = action === 'add' ? 'منح' : 'إزالة';
  return interaction.reply({
    embeds: [successEmbed(settings, `تم ${verb} صلاحية الرؤية لرتبة **${role.name}** على نوع \`${typeId}\`.`)],
    ephemeral: true,
  });
}

async function handleTypeList(interaction, guildConfig, settings) {
  const types = guildConfig.tickets.types;

  if (!types.length) {
    return interaction.reply({
      embeds: [baseEmbed(settings).setTitle('📂・أنواع التذاكر المُعدّة').setDescription('لا توجد أنواع مخصصة حالياً - سيظهر زر افتراضي واحد ("فتح تذكرة") في اللوحة.')],
      ephemeral: true,
    });
  }

  const blocks = types.map((t) => {
    const parts = [`${t.emoji || '•'} **${t.label}** — \`${t.typeId}\` — ${t.style}`];
    if (t.description) parts.push(`  ↳ الوصف: ${t.description}`);
    if (t.categoryId) parts.push(`  ↳ الكاتقوري: <#${t.categoryId}>`);
    if (t.mentionRoleId) parts.push(`  ↳ رتبة المنشن: <@&${t.mentionRoleId}>`);
    if (t.viewRoleIds?.length) parts.push(`  ↳ صلاحية الرؤية: ${t.viewRoleIds.map((id) => `<@&${id}>`).join(', ')}`);
    if (t.channelName) parts.push(`  ↳ اسم الروم: \`${t.channelName}\``);
    if (t.welcomeMessage) parts.push(`  ↳ رسالة ترحيب مخصصة ✅`);
    return parts.join('\n');
  });

  const pages = [];
  for (let i = 0; i < blocks.length; i += TYPES_PER_LIST_EMBED) pages.push(blocks.slice(i, i + TYPES_PER_LIST_EMBED));

  const embeds = pages.slice(0, 10).map((page, i) =>
    baseEmbed(settings)
      .setTitle(pages.length > 1 ? `📂・أنواع التذاكر المُعدّة (${i + 1}/${pages.length})` : '📂・أنواع التذاكر المُعدّة')
      .setDescription(page.join('\n\n'))
  );

  return interaction.reply({ embeds, ephemeral: true });
}

async function handleClosePromptSetMessage(interaction, guildConfig, settings) {
  const type = interaction.options.getString('type');
  const text = interaction.options.getString('text');

  guildConfig.tickets.closePrompt = guildConfig.tickets.closePrompt || {};

  if (type === 'message') {
    guildConfig.tickets.closePrompt.message = text.replace(/\\n/g, '\n');
  } else if (type === 'delete_button') {
    if (text.length > 80) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'نص الزر يجب ألا يتجاوز 80 حرفاً (حد ديسكورد لنصوص الأزرار).')], ephemeral: true });
    }
    guildConfig.tickets.closePrompt.deleteButtonLabel = text;
  } else if (type === 'reopen_button') {
    if (text.length > 80) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'نص الزر يجب ألا يتجاوز 80 حرفاً (حد ديسكورد لنصوص الأزرار).')], ephemeral: true });
    }
    guildConfig.tickets.closePrompt.reopenButtonLabel = text;
  }

  guildConfig.markModified('tickets.closePrompt');
  await guildConfig.save();
  invalidateGuildConfig(interaction.guildId);

  const labels = { message: 'رسالة التأكيد', delete_button: 'نص زر الحذف نهائياً', reopen_button: 'نص زر إعادة الفتح' };
  return interaction.reply({
    embeds: [successEmbed(settings, `تم تحديث ${labels[type]}. سيظهر التحديث في أول تذكرة تُغلق بعد الآن.`)],
    ephemeral: true,
  });
}

async function handleClosePromptSetTimer(interaction, guildConfig, settings) {
  const minutes = interaction.options.getInteger('minutes');

  guildConfig.tickets.closePrompt = guildConfig.tickets.closePrompt || {};
  guildConfig.tickets.closePrompt.autoDeleteMinutes = minutes;

  guildConfig.markModified('tickets.closePrompt');
  await guildConfig.save();
  invalidateGuildConfig(interaction.guildId);

  return interaction.reply({
    embeds: [
      successEmbed(
        settings,
        minutes > 0
          ? `سيتم حذف التذاكر المغلقة تلقائياً بعد **${minutes}** دقيقة ما لم يتم التدخل.`
          : 'تم تعطيل الحذف التلقائي - ستبقى التذاكر المغلقة بانتظار حذف يدوي إلى أن يضغط أحد الموظفين 🗑️.'
      ),
    ],
    ephemeral: true,
  });
}

/** /ticketsetup closeprompt setwarning - task 9: how many minutes before auto-delete the channel switches 🔵 → 🔴. */
async function handleClosePromptSetWarning(interaction, guildConfig, settings) {
  const minutes = interaction.options.getInteger('minutes');

  guildConfig.tickets.closePrompt = guildConfig.tickets.closePrompt || {};
  guildConfig.tickets.closePrompt.warningMinutes = minutes;

  guildConfig.markModified('tickets.closePrompt');
  await guildConfig.save();
  invalidateGuildConfig(interaction.guildId);

  return interaction.reply({
    embeds: [
      successEmbed(
        settings,
        minutes > 0
          ? `سيتحول اسم روم التذكرة المغلقة إلى 🔴 عندما يتبقى **${minutes}** دقيقة على حذفها تلقائياً.`
          : 'تم تعطيل مرحلة 🔴 - ستبقى التذاكر المغلقة بالحالة 🔵 حتى موعد حذفها.'
      ),
    ],
    ephemeral: true,
  });
}

async function handleClosePromptReset(interaction, guildConfig, settings) {
  guildConfig.tickets.closePrompt = { message: null, deleteButtonLabel: null, reopenButtonLabel: null, autoDeleteMinutes: 240, warningMinutes: 30 };
  guildConfig.markModified('tickets.closePrompt');
  await guildConfig.save();
  invalidateGuildConfig(interaction.guildId);

  return interaction.reply({
    embeds: [
      successEmbed(settings, 'تمت إعادة رسالة التأكيد ونصوص الأزرار والمؤقتات إلى الإعدادات الافتراضية (حذف تلقائي خلال 4 ساعات، وتحذير 🔴 قبل 30 دقيقة).').addFields(
        { name: 'الرسالة الافتراضية', value: DEFAULT_CLOSE_MESSAGE },
        { name: 'زر الحذف', value: DEFAULT_DELETE_LABEL, inline: true },
        { name: 'زر إعادة الفتح', value: DEFAULT_REOPEN_LABEL, inline: true }
      ),
    ],
    ephemeral: true,
  });
}
