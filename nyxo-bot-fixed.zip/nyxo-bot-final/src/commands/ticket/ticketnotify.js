const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { isModerator } = require('../../utils/permissions');
const { notifyMember } = require('../../services/ticketNotifyService');
const Ticket = require('../../database/models/Ticket');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ticketnotify')
    .setDescription('Summon a member into this ticket - grants access and pings them if needed')
    .setDescriptionLocalizations({
      ar: 'استدعاء عضو إلى هذه التذكرة - يمنحه صلاحية الوصول ويقوم بمنشنه عند الحاجة',
      'en-US': 'Summon a member into this ticket - grants access and pings them if needed',
    })
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addUserOption((o) =>
      o
        .setName('member')
        .setDescription('The member to summon into this ticket')
        .setDescriptionLocalizations({ ar: 'العضو المراد استدعاؤه إلى هذه التذكرة', 'en-US': 'The member to summon into this ticket' })
        .setRequired(true)
    )
    .addStringOption((o) =>
      o
        .setName('reason')
        .setDescription('Why they are being called in (optional)')
        .setDescriptionLocalizations({ ar: 'سبب الاستدعاء (اختياري)', 'en-US': 'Why they are being called in (optional)' })
        .setMaxLength(300)
    ),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isModerator(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'الموظفون فقط يمكنهم استخدام هذا الأمر.')], ephemeral: true });
    }

    const ticket = await Ticket.findOne({ channelId: interaction.channelId, status: { $ne: 'closed' } });
    if (!ticket) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'هذا الأمر يعمل فقط داخل روم تذكرة مفتوحة.')], ephemeral: true });
    }

    const member = interaction.options.getUser('member');
    if (member.bot) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'لا يمكن استدعاء بوت.')], ephemeral: true });
    }
    if (member.id === ticket.userId) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'هذا العضو هو صاحب التذكرة بالفعل.')], ephemeral: true });
    }

    const reason = interaction.options.getString('reason');

    await interaction.deferReply({ ephemeral: true });

    await notifyMember({
      channel: interaction.channel,
      guildConfig,
      settings,
      ticket,
      requestedBy: interaction.user,
      target: member,
      reason,
    });

    await interaction.editReply({ embeds: [successEmbed(settings, `تم استدعاء ${member} إلى التذكرة.`)] });
  },
};
