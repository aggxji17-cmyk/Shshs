const { SlashCommandBuilder, PermissionsBitField, MessageFlags, EmbedBuilder, Colors } = require("discord.js");
const voiceLevelSchema = require("../../database/models/voiceLevelSchema");
const voiceBlacklistSchema = require("../../database/models/voiceBlacklistSchema");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("voiceleveling")
        .setDMPermission(false)
        .setDescription("Configure the voice leveling system.")
        .addSubcommand((command) =>
            command
                .setName("enable")
                .setDescription("Enables the voice leveling system.")
                .addChannelOption((option) =>
                    option
                        .setName("channel")
                        .setDescription("The channel to send level-up messages.")
                        .setRequired(true)
                )
        )
        .addSubcommand((command) =>
            command
                .setName("disable")
                .setDescription("Disables the voice leveling system.")
        )
        .addSubcommand((command) =>
            command
                .setName("add-blacklist")
                .setDescription("Add a voice channel to the blacklist.")
                .addChannelOption((option) =>
                    option
                        .setName("channel")
                        .setDescription("The voice channel to blacklist.")
                        .setRequired(true)
                )
        )
        .addSubcommand((command) =>
            command
                .setName("remove-blacklist")
                .setDescription("Remove a voice channel from the blacklist.")
                .addChannelOption((option) =>
                    option
                        .setName("channel")
                        .setDescription("The voice channel to remove from blacklist.")
                        .setRequired(true)
                )
        ),
    async execute(interaction, client) {
        // --- HELPER: ERROR EMBED ---
        const sendError = async (message) => {
            const errorEmbed = new EmbedBuilder()
                .setColor(Colors.Red)
                .setDescription(`❌ **Error**\n> ${message}`);
            
            return await interaction.reply({ embeds: [errorEmbed], flags: MessageFlags.Ephemeral });
        };

        // Permission Check
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return sendError("You need **Administrator** privileges to configure this.");
        }

        const sub = interaction.options.getSubcommand();
        const { guild } = interaction;

        switch (sub) {
            case "enable":
                const notificationChannel = interaction.options.getChannel("channel");
                
                const existingData = await voiceLevelSchema.findOne({ Guild: guild.id });
                if (existingData && existingData.IsEnabled) {
                    return sendError(`System is already active in ${notificationChannel}.`);
                }
                
                await voiceLevelSchema.updateOne(
                    { Guild: guild.id },
                    { $set: { IsEnabled: true, NotificationChannel: notificationChannel.id } },
                    { upsert: true }
                );

                const enableEmbed = new EmbedBuilder()
                    .setColor(Colors.Green) // Clean Green
                    .setDescription(
                        `## 🟢 System Enabled\n` +
                        `The voice leveling module is now **active**.\n\n` +
                        `> 📢 **Output:** ${notificationChannel}\n` +
                        `> 👤 **Admin:** ${interaction.user}`
                    )
                    .setFooter({ text: `NYXO BOT • Updated` })
                    .setTimestamp();

                await interaction.reply({ embeds: [enableEmbed] });
                break;

            case "disable":
                await voiceLevelSchema.updateOne(
                    { Guild: guild.id },
                    { $set: { IsEnabled: false } },
                    { upsert: true }
                );

                const disableEmbed = new EmbedBuilder()
                    .setColor(Colors.Red) // Clean Red
                    .setDescription(
                        `## 🔴 System Disabled\n` +
                        `Voice XP tracking has been paused for the server.\n\n` +
                        `> 👤 **Admin:** ${interaction.user}`
                    )
                    .setFooter({ text: `NYXO BOT • Updated` })
                    .setTimestamp();

                await interaction.reply({ embeds: [disableEmbed] });
                break;

            case "add-blacklist":
                const addChannel = interaction.options.getChannel("channel");
                const existingBlacklist = await voiceBlacklistSchema.findOne({
                    Guild: guild.id,
                    ChannelID: addChannel.id,
                });

                if (existingBlacklist) {
                    return sendError(`${addChannel} is already on the blacklist.`);
                }

                await voiceBlacklistSchema.create({
                    Guild: guild.id,
                    ChannelID: addChannel.id,
                });

                const blacklistAddEmbed = new EmbedBuilder()
                    .setColor(Colors.Grey) // Neutral/Dark for restrictions
                    .setDescription(
                        `## 🔒 Channel Restricted\n` +
                        `Users will no longer gain XP in this channel.\n\n` +
                        `> 🔇 **Channel:** ${addChannel}`
                    )
                    .setTimestamp();

                await interaction.reply({ embeds: [blacklistAddEmbed], flags: MessageFlags.Ephemeral });
                break;

            case "remove-blacklist":
                const removeChannel = interaction.options.getChannel("channel");
                const blacklistEntry = await voiceBlacklistSchema.findOneAndDelete({
                    Guild: guild.id,
                    ChannelID: removeChannel.id,
                });

                if (!blacklistEntry) {
                    return sendError(`${removeChannel} is not blacklisted.`);
                }

                const blacklistRemoveEmbed = new EmbedBuilder()
                    .setColor(Colors.Green)
                    .setDescription(
                        `## 🔓 Channel Unlocked\n` +
                        `XP gain has been restored for this channel.\n\n` +
                        `> 🔊 **Channel:** ${removeChannel}`
                    )
                    .setTimestamp();

                await interaction.reply({ embeds: [blacklistRemoveEmbed], flags: MessageFlags.Ephemeral });
                break;
        }
    },
};