const {
  SlashCommandBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  PermissionsBitField,
  MessageFlags,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  ContainerBuilder,
  SectionBuilder,
  TextDisplayBuilder,
  ThumbnailBuilder,
  SeparatorBuilder
} = require("discord.js");

const aiConfig = require("../../database/models/aiSchema");
const { config } = require('../../config/config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName("ai-config")
    .setDescription("Configure Artificial Intelligence in your server!"),

  execute: async function (interaction, client) {
    if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
      return await interaction.reply({
        content: `${client.emoji.error} | You don't have perms to manage the AI configuration system.`,
        flags: MessageFlags.Ephemeral,
      });
    }

    const data = await aiConfig.findOne({ guildId: interaction.guild.id });
    const botAvatar = interaction.client.user.displayAvatarURL({ extension: 'png', size: 512 });
    const accentColor = parseInt(config.embedColor.replace('#', ''), 16);

    const mainButtons = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId("channel_setup")
        .setLabel("Channel")
        .setStyle(ButtonStyle.Primary)
        .setDisabled(!!data),
      new ButtonBuilder()
        .setCustomId("ai_provider_setup")
        .setLabel("AI Provider")
        .setStyle(ButtonStyle.Success)
        .setDisabled(!data),
      new ButtonBuilder()
        .setCustomId("personality_setup")
        .setLabel("Personality")
        .setEmoji("🎭")
        .setStyle(ButtonStyle.Success)
        .setDisabled(!data),
      new ButtonBuilder()
        .setCustomId("blacklist_setup")
        .setLabel("Blacklist")
        .setStyle(ButtonStyle.Danger)
        .setDisabled(!data),
      new ButtonBuilder()
        .setCustomId("disable_ai")
        .setLabel("Disable AI")
        .setStyle(ButtonStyle.Secondary)
        .setDisabled(!data)
    );

    const blacklistButtons = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId("blacklist_add")
        .setLabel("Add")
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId("blacklist_remove")
        .setLabel("Remove")
        .setStyle(ButtonStyle.Danger),
      new ButtonBuilder()
        .setCustomId("back_to_main")
        .setLabel("Back")
        .setStyle(ButtonStyle.Secondary)
    );

    const buildContainer = (configData, rows = []) => {
      let blacklistedCount = configData && configData.blacklists ? configData.blacklists.length : 0;
      let aiProvider = configData?.aiProvider || 'default';
      let modelName = configData?.modelName || 'Not Set';
      let personality = configData?.personality || 'default';

      const container = new ContainerBuilder()
        .setAccentColor(accentColor)
        .addSectionComponents(

          new SectionBuilder()
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent('### AI Configuration Panel'),
              new TextDisplayBuilder().setContent('> Configure your server\'s AI behavior and providers.')
            )
            .setThumbnailAccessory(new ThumbnailBuilder({ media: { url: botAvatar } }))
        )
        .addSeparatorComponents(new SeparatorBuilder().setDivider(true))
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('**Welcome to the ChatBot System**'),
          new TextDisplayBuilder().setContent('```md\n# Multi-Provider AI Support\nConfigure Gemini, OpenAI, or Claude for your server.```')
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('**System Status**'),
          new TextDisplayBuilder().setContent(configData
            ? '```ansi\n\u001b[32m□ 🟢 SYSTEM ONLINE\n\u001b[32m├───> All Systems Operational\n\u001b[32m├───> Features: Fully Available\n\u001b[32m└───> Updates: Real-time Enabled```'
            : '```ansi\n\u001b[31m□ 🔴 SYSTEM OFFLINE\n\u001b[31m├───> Features: NOT CONFIGURED\n\u001b[31m└───> Updates: Disabled```')
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('**Active Configuration**'),
          new TextDisplayBuilder().setContent(configData
            ? `\`\`\`yml\n"channel": "${configData.channelId}"\n"blacklisted-users": "${blacklistedCount}"\n"ai-provider": "${aiProvider}"\n"model": "${modelName}"\n"personality": "${personality}"\`\`\``
            : `\`\`\`yml\n"channel": "Not Configured"\n"blacklisted-users": "0"\n"ai-provider": "default"\n"model": "Not Set"\n"personality": "default"\`\`\``)
        );

      rows.forEach(row => container.addActionRowComponents(row));
      
      return container;
    };

    const response = await interaction.reply({
      components: [buildContainer(data, [mainButtons])],
      flags: MessageFlags.IsComponentsV2,
      withResponse: true
    });

    const message = response.resource.message;

    const collector = message.createMessageComponentCollector({
      filter: (i) => i.user.id === interaction.user.id,
      time: 120000,
    });

    collector.on("collect", async (i) => {

      const currentData = await aiConfig.findOne({ guildId: interaction.guild.id });

      switch (i.customId) {
        case "channel_setup":
          await i.reply({
            content: "Please mention the channel where you want to bind the AI.",
            flags: MessageFlags.Ephemeral,
          });

          const channelFilter = (m) => m.author.id === i.user.id;
          const channelCollector = interaction.channel.createMessageCollector({
            filter: channelFilter,
            time: 30000,
            max: 1,
          });

          channelCollector.on("collect", async (m) => {
            const channel = m.mentions.channels.first();
            if (!channel) {
              await m.reply({
                content: "Invalid channel mentioned. Please try again.",
                flags: MessageFlags.Ephemeral,
              });
              return;
            }

            const newData = await aiConfig.create({
              guildId: interaction.guild.id,
              channelId: channel.id,
              blacklists: [],
              aiProvider: 'default',
              apiKey: null,
              modelName: 'gemini-2.5-flash'
            });

            mainButtons.components[0].setDisabled(true);
            mainButtons.components[1].setDisabled(false);
            mainButtons.components[2].setDisabled(false);
            mainButtons.components[3].setDisabled(false);
            mainButtons.components[4].setDisabled(false);

            await message.edit({
              components: [buildContainer(newData, [mainButtons])],
            });

            await m.reply({
              content: `AI has been bound to ${channel}. Now configure your AI provider using the "AI Provider" button.`,
              flags: MessageFlags.Ephemeral,
            });
          });
          break;

        case "ai_provider_setup":
          const selectMenu = new StringSelectMenuBuilder()
            .setCustomId('select_ai_provider')
            .setPlaceholder('Choose an AI Provider')
            .addOptions(
              new StringSelectMenuOptionBuilder()
                .setLabel('Default (Bot Owner\'s API)')
                .setDescription('Use the bot\'s configured Gemini API')
                .setValue('default')
                .setEmoji('🔷'),
              new StringSelectMenuOptionBuilder()
                .setLabel('Google Gemini')
                .setDescription('Use your own Google Gemini API key')
                .setValue('gemini')
                .setEmoji('✨'),
              new StringSelectMenuOptionBuilder()
                .setLabel('OpenAI (GPT)')
                .setDescription('Use your own OpenAI API key')
                .setValue('openai')
                .setEmoji('🤖'),
              new StringSelectMenuOptionBuilder()
                .setLabel('Anthropic Claude')
                .setDescription('Use your own Claude API key')
                .setValue('claude')
                .setEmoji('🧠')
            );

          const selectRow = new ActionRowBuilder().addComponents(selectMenu);
          const backButtonRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
              .setCustomId("back_to_main")
              .setLabel("Back")
              .setStyle(ButtonStyle.Secondary)
          );

          await i.update({
            components: [buildContainer(currentData, [selectRow, backButtonRow])],
          });
          break;

        case "blacklist_setup":
          await i.update({
            components: [buildContainer(currentData, [blacklistButtons])],
          });
          break;

        case "blacklist_add":
          await i.reply({
            content: "Please mention the user you want to blacklist.",
            flags: MessageFlags.Ephemeral,
          });

          const addFilter = (m) => m.author.id === i.user.id;
          const addCollector = interaction.channel.createMessageCollector({
            filter: addFilter,
            time: 30000,
            max: 1,
          });

          addCollector.on("collect", async (m) => {
            const user = m.mentions.users.first();
            if (!user) {
              return m.reply({
                content: "Invalid user mentioned. Please try again.",
                flags: MessageFlags.Ephemeral,
              });
            }

            const activeData = await aiConfig.findOne({ guildId: i.guild.id });
            if (!activeData) {
              return m.reply({
                content: "You need to configure AI before managing the blacklist.",
                flags: MessageFlags.Ephemeral,
              });
            }

            if (activeData.blacklists.includes(user.id)) {
              return m.reply({
                content: "This user is already blacklisted.",
                flags: MessageFlags.Ephemeral,
              });
            }

            activeData.blacklists.push(user.id);
            await activeData.save();

            await message.edit({
              components: [buildContainer(activeData, [blacklistButtons])],
            });

            await m.reply({
              content: `${user} has been blacklisted from using AI.`,
              flags: MessageFlags.Ephemeral,
            });
          });
          break;

        case "blacklist_remove":
          await i.reply({
            content: "Please mention the user you want to remove from the blacklist.",
            flags: MessageFlags.Ephemeral,
          });

          const removeFilter = (m) => m.author.id === i.user.id;
          const removeCollector = interaction.channel.createMessageCollector({
            filter: removeFilter,
            time: 30000,
            max: 1,
          });

          removeCollector.on("collect", async (m) => {
            const user = m.mentions.users.first();
            if (!user) {
              return m.reply({
                content: "Invalid user mentioned. Please try again.",
                flags: MessageFlags.Ephemeral,
              });
            }

            const activeData = await aiConfig.findOne({ guildId: i.guild.id });
            if (!activeData) {
              return m.reply({
                content: "You need to configure AI before managing the blacklist.",
                flags: MessageFlags.Ephemeral,
              });
            }

            if (!activeData.blacklists.includes(user.id)) {
              return m.reply({
                content: "This user is not blacklisted.",
                flags: MessageFlags.Ephemeral,
              });
            }

            activeData.blacklists = activeData.blacklists.filter((id) => id !== user.id);
            await activeData.save();

            await message.edit({
              components: [buildContainer(activeData, [blacklistButtons])],
            });

            await m.reply({
              content: `${user} has been removed from the blacklist.`,
              flags: MessageFlags.Ephemeral,
            });
          });
          break;

        case "back_to_main":
          await i.update({
            components: [buildContainer(currentData, [mainButtons])],
          });
          break;

        case "personality_setup": {
          const personalityMenu = new StringSelectMenuBuilder()
            .setCustomId('select_personality')
            .setPlaceholder('Choose a Personality')
            .addOptions(
              new StringSelectMenuOptionBuilder()
                .setLabel('Default')
                .setDescription('Helpful and neutral assistant')
                .setValue('default')
                .setEmoji('🤖'),
              new StringSelectMenuOptionBuilder()
                .setLabel('Friendly')
                .setDescription('Warm, enthusiastic, and supportive')
                .setValue('friendly')
                .setEmoji('😊'),
              new StringSelectMenuOptionBuilder()
                .setLabel('Sarcastic')
                .setDescription('Witty, dry humor with helpful answers')
                .setValue('sarcastic')
                .setEmoji('😏'),
              new StringSelectMenuOptionBuilder()
                .setLabel('Formal')
                .setDescription('Professional and dignified responses')
                .setValue('formal')
                .setEmoji('🎩'),
              new StringSelectMenuOptionBuilder()
                .setLabel('Pirate')
                .setDescription('Arrr! Swashbuckling pirate talk!')
                .setValue('pirate')
                .setEmoji('🏴‍☠️'),
              new StringSelectMenuOptionBuilder()
                .setLabel('Custom')
                .setDescription('Write your own system prompt')
                .setValue('custom')
                .setEmoji('✏️')
            );

          const personalityRow = new ActionRowBuilder().addComponents(personalityMenu);
          const personalityBackBtn = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
              .setCustomId("back_to_main")
              .setLabel("Back")
              .setStyle(ButtonStyle.Secondary)
          );

          await i.update({
            components: [buildContainer(currentData, [personalityRow, personalityBackBtn])],
          });
          break;
        }

        case "select_personality": {
          const selectedPersonality = i.values[0];

          if (selectedPersonality === 'custom') {
            const customModal = new ModalBuilder()
              .setCustomId('custom_personality_modal')
              .setTitle('Custom AI Personality');

            const promptInput = new TextInputBuilder()
              .setCustomId('custom_prompt')
              .setLabel('System Prompt')
              .setStyle(TextInputStyle.Paragraph)
              .setPlaceholder('Example: You are a wise wizard who speaks in riddles and gives cryptic advice...')
              .setRequired(true)
              .setMaxLength(500);

            const modalRow = new ActionRowBuilder().addComponents(promptInput);
            customModal.addComponents(modalRow);

            await i.showModal(customModal);
          } else {
            currentData.personality = selectedPersonality;
            currentData.customSystemPrompt = null;
            await currentData.save();

            const personalityNames = {
              'default': '🤖 Default',
              'friendly': '😊 Friendly',
              'sarcastic': '😏 Sarcastic',
              'formal': '🎩 Formal',
              'pirate': '🏴‍☠️ Pirate',
            };

            await i.update({
              components: [buildContainer(currentData, [mainButtons])],
            });

            await i.followUp({
              content: `✅ AI Personality set to **${personalityNames[selectedPersonality]}**`,
              flags: MessageFlags.Ephemeral,
            });
          }
          break;
        }

        case "disable_ai":
          if (!currentData) {
            return i.reply({
              content: "AI is not configured in this server.",
              flags: MessageFlags.Ephemeral,
            });
          }

          await aiConfig.deleteOne({ guildId: i.guild.id });

          mainButtons.components[0].setDisabled(false);
          mainButtons.components[1].setDisabled(true);
          mainButtons.components[2].setDisabled(true);
          mainButtons.components[3].setDisabled(true);
          mainButtons.components[4].setDisabled(true);

          await i.update({
            components: [buildContainer(null, [mainButtons])],
          });

          await i.followUp({
            content: "AI has been disabled in this server.",
            flags: MessageFlags.Ephemeral,
          });
          break;

        case "select_ai_provider":
          const selectedProvider = i.values[0];

          if (selectedProvider === 'default') {
            currentData.aiProvider = 'default';
            currentData.apiKey = null;
            currentData.modelName = 'gemini-2.5-flash';
            await currentData.save();

            await i.update({
              components: [buildContainer(currentData, [mainButtons])],
            });

            await i.followUp({
              content: "✅ AI Provider set to Default (Bot Owner's Gemini API)",
              flags: MessageFlags.Ephemeral,
            });
          } else {
            const modal = new ModalBuilder()
              .setCustomId(`api_key_modal_${selectedProvider}`)
              .setTitle(`Configure ${selectedProvider.toUpperCase()} API`);

            const apiKeyInput = new TextInputBuilder()
              .setCustomId('api_key')
              .setLabel('API Key')
              .setStyle(TextInputStyle.Short)
              .setPlaceholder('Enter your API key here')
              .setRequired(true);

            const modelInput = new TextInputBuilder()
              .setCustomId('model_name')
              .setLabel('Model Name')
              .setStyle(TextInputStyle.Short)
              .setRequired(true);

            if (selectedProvider === 'gemini') {
              modelInput.setPlaceholder('e.g., gemini-2.5-flash')
                .setValue('gemini-2.5-flash');
            } else if (selectedProvider === 'openai') {
              modelInput.setPlaceholder('e.g., gpt-4o, gpt-4o-mini')
                .setValue('gpt-4o-mini');
            } else if (selectedProvider === 'claude') {
              modelInput.setPlaceholder('e.g., claude-sonnet-4-20250514')
                .setValue('claude-sonnet-4-20250514');
            }

            const firstActionRow = new ActionRowBuilder().addComponents(apiKeyInput);
            const secondActionRow = new ActionRowBuilder().addComponents(modelInput);

            modal.addComponents(firstActionRow, secondActionRow);

            await i.showModal(modal);
          }
          break;
      }
    });

    collector.on("end", async () => {
      mainButtons.components.forEach((component) => component.setDisabled(true));
      try {
        const finalData = await aiConfig.findOne({ guildId: interaction.guild.id });
        await message.edit({
          components: [buildContainer(finalData, [mainButtons])],
        });
      } catch (err) {
        console.error('Failed to edit message on collector end:', err);
      }
    });
  },
};

// Modal submission handler (remains the same as it doesn't edit the original panel directly via this command)
module.exports.handleModalSubmit = async (interaction, client) => {
  if (!interaction.isModalSubmit()) return;

  // Handle API key modal
  if (interaction.customId.startsWith('api_key_modal_')) {
    const provider = interaction.customId.replace('api_key_modal_', '');
    const apiKey = interaction.fields.getTextInputValue('api_key');
    const modelName = interaction.fields.getTextInputValue('model_name');

    const currentData = await aiConfig.findOne({ guildId: interaction.guild.id });
    if (!currentData) {
      return interaction.reply({
        content: "AI configuration not found. Please set up the channel first.",
        flags: MessageFlags.Ephemeral,
      });
    }

    currentData.aiProvider = provider;
    currentData.apiKey = apiKey;
    currentData.modelName = modelName;
    await currentData.save();

    await interaction.reply({
      content: `✅ AI Provider configured successfully!\n**Provider:** ${provider}\n**Model:** ${modelName}`,
      flags: MessageFlags.Ephemeral,
    });
  }

  // Handle custom personality modal
  else if (interaction.customId === 'custom_personality_modal') {
    const customPrompt = interaction.fields.getTextInputValue('custom_prompt');

    const currentData = await aiConfig.findOne({ guildId: interaction.guild.id });
    if (!currentData) {
      return interaction.reply({
        content: "AI configuration not found. Please set up the channel first.",
        flags: MessageFlags.Ephemeral,
      });
    }

    currentData.personality = 'custom';
    currentData.customSystemPrompt = customPrompt;
    await currentData.save();

    await interaction.reply({
      content: `✅ Custom AI Personality set!\n**System Prompt:** ${customPrompt.length > 100 ? customPrompt.slice(0, 100) + '...' : customPrompt}`,
      flags: MessageFlags.Ephemeral,
    });
  }
};

/**
 * Credits: Arpan | @arpandevv
 * Buy: https://nyxo.buzz/buy
 */
