const { SlashCommandBuilder, PermissionsBitField, MessageFlags, EmbedBuilder, ChannelType } = require('discord.js');
const SmartAlertConfig = require('../../database/models/smartAlertConfigSchema');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('setup-smart-alerts')
        .setDescription('Configure AI-powered server health monitoring.')
        .addSubcommand(sub =>
            sub
                .setName('set')
                .setDescription('Set the alerts channel.')
                .addChannelOption(opt =>
                    opt
                        .setName('channel')
                        .setDescription('Channel where AI health reports will be sent.')
                        .addChannelTypes(ChannelType.GuildText)
                        .setRequired(true)
                )
        )
        .addSubcommand(sub =>
            sub.setName('disable').setDescription('Disable Smart Alerts.')
        )
        .addSubcommand(sub =>
            sub.setName('status').setDescription('View current status of Smart Alerts.')
        ),

    async execute(interaction, client) {
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) {
            return interaction.reply({
                content: `${client.emoji.error} | You need **Manage Server** permission to use this command.`,
                flags: MessageFlags.Ephemeral,
            });
        }

        const sub = interaction.options.getSubcommand();
        const guildId = interaction.guild.id;

        if (sub === 'set') {
            const channel = interaction.options.getChannel('channel');

            await SmartAlertConfig.findOneAndUpdate(
                { guildId },
                { channelId: channel.id, enabled: true },
                { upsert: true }
            );

            return interaction.reply({
                content: `${client.emoji.tick} | Smart Alerts have been enabled. Reports will be sent to ${channel} every Sunday.`,
                flags: MessageFlags.Ephemeral
            });
        }

        if (sub === 'disable') {
            await SmartAlertConfig.findOneAndUpdate(
                { guildId },
                { enabled: false }
            );

            return interaction.reply({
                content: `${client.emoji.tick} | Smart Alerts have been disabled.`,
                flags: MessageFlags.Ephemeral
            });
        }

        if (sub === 'status') {
            const data = await SmartAlertConfig.findOne({ guildId });
            
            const embed = new EmbedBuilder()
                .setTitle('🩺 Smart Alerts Status')
                .setColor(client.config.embedColor)
                .addFields(
                    { name: 'Status', value: data?.enabled ? 'Enabled ✅' : 'Disabled ❌', inline: true },
                    { name: 'Channel', value: data?.channelId ? `<#${data.channelId}>` : 'Not set', inline: true }
                )
                .setFooter({ text: 'AI Health Monitoring' });

            return interaction.reply({ embeds: [embed] });
        }
    }
};
