const {
    SlashCommandBuilder,
    PermissionsBitField,
    EmbedBuilder,
    MessageFlags,
} = require("discord.js");
const warnConfigSchema = require("../../database/models/warnConfigSchema");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("warnconfig")
        .setDescription("Configure automatic warn punishments and decay.")
        .setDMPermission(false)
        .setDefaultMemberPermissions(PermissionsBitField.Flags.Administrator)
        .addSubcommand((sub) =>
            sub
                .setName("add")
                .setDescription("Add an auto-punishment threshold.")
                .addIntegerOption((opt) =>
                    opt
                        .setName("count")
                        .setDescription("Number of warnings to trigger the action (e.g. 3)")
                        .setRequired(true)
                        .setMinValue(1)
                        .setMaxValue(50)
                )
                .addStringOption((opt) =>
                    opt
                        .setName("action")
                        .setDescription("The punishment to apply")
                        .setRequired(true)
                        .addChoices(
                            { name: "Timeout", value: "timeout" },
                            { name: "Kick", value: "kick" },
                            { name: "Ban", value: "ban" }
                        )
                )
                .addStringOption((opt) =>
                    opt
                        .setName("duration")
                        .setDescription("Timeout duration (only for timeout action)")
                        .setRequired(false)
                        .addChoices(
                            { name: "5 Minutes", value: "300" },
                            { name: "10 Minutes", value: "600" },
                            { name: "30 Minutes", value: "1800" },
                            { name: "1 Hour", value: "3600" },
                            { name: "6 Hours", value: "21600" },
                            { name: "12 Hours", value: "43200" },
                            { name: "1 Day", value: "86400" },
                            { name: "3 Days", value: "259200" },
                            { name: "1 Week", value: "604800" }
                        )
                )
        )
        .addSubcommand((sub) =>
            sub
                .setName("remove")
                .setDescription("Remove an auto-punishment threshold.")
                .addIntegerOption((opt) =>
                    opt
                        .setName("count")
                        .setDescription("The warn count threshold to remove")
                        .setRequired(true)
                        .setMinValue(1)
                )
        )
        .addSubcommand((sub) =>
            sub
                .setName("decay")
                .setDescription("Configure automatic warn decay.")
                .addBooleanOption((opt) =>
                    opt
                        .setName("enabled")
                        .setDescription("Enable or disable warn decay")
                        .setRequired(true)
                )
                .addIntegerOption((opt) =>
                    opt
                        .setName("days")
                        .setDescription("Warnings older than this many days will be removed (default: 30)")
                        .setRequired(false)
                        .setMinValue(1)
                        .setMaxValue(365)
                )
        )
        .addSubcommand((sub) =>
            sub
                .setName("view")
                .setDescription("View current warn configuration.")
        ),

    async execute(interaction, client) {
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
            return await interaction.reply({
                content: "You **do not** have the permission to do that!",
                flags: MessageFlags.Ephemeral,
            });
        }

        const sub = interaction.options.getSubcommand();
        const guildId = interaction.guild.id;

        if (sub === "add") {
            return await handleAdd(interaction, client, guildId);
        } else if (sub === "remove") {
            return await handleRemove(interaction, client, guildId);
        } else if (sub === "decay") {
            return await handleDecay(interaction, client, guildId);
        } else if (sub === "view") {
            return await handleView(interaction, client, guildId);
        }
    },
};

// ========================================
// /warnconfig add
// ========================================
async function handleAdd(interaction, client, guildId) {
    const count = interaction.options.getInteger("count");
    const action = interaction.options.getString("action");
    const durationStr = interaction.options.getString("duration");
    const duration = durationStr ? parseInt(durationStr) : null;

    if (action === "timeout" && !duration) {
        return await interaction.reply({
            content: "⚠️ You must specify a **duration** when using the timeout action.",
            flags: MessageFlags.Ephemeral,
        });
    }

    let config = await warnConfigSchema.findOne({ GuildID: guildId });

    if (!config) {
        config = await warnConfigSchema.create({
            GuildID: guildId,
            Thresholds: [],
        });
    }

    // Check if threshold already exists for this count
    const existing = config.Thresholds.find((t) => t.Count === count);
    if (existing) {
        existing.Action = action;
        existing.Duration = duration;
    } else {
        config.Thresholds.push({ Count: count, Action: action, Duration: duration });
    }

    // Sort thresholds by count
    config.Thresholds.sort((a, b) => a.Count - b.Count);
    await config.save();

    const durationLabel = duration ? formatDuration(duration) : "N/A";
    const embed = new EmbedBuilder()
        .setColor(client.config.embedColor)
        .setAuthor({ name: "⚠️ Warn Config", iconURL: client.user.displayAvatarURL() })
        .setTitle("> Threshold Added!")
        .addFields(
            { name: "• Warn Count", value: `> ${count}`, inline: true },
            { name: "• Action", value: `> ${capitalize(action)}`, inline: true },
            { name: "• Duration", value: `> ${durationLabel}`, inline: true }
        )
        .setFooter({ text: `Configured by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
        .setTimestamp();

    await interaction.reply({ embeds: [embed] });
}

// ========================================
// /warnconfig remove
// ========================================
async function handleRemove(interaction, client, guildId) {
    const count = interaction.options.getInteger("count");

    const config = await warnConfigSchema.findOne({ GuildID: guildId });
    if (!config) {
        return await interaction.reply({
            content: "⚠️ No warn configuration found for this server. Use `/warnconfig add` first.",
            flags: MessageFlags.Ephemeral,
        });
    }

    const index = config.Thresholds.findIndex((t) => t.Count === count);
    if (index === -1) {
        return await interaction.reply({
            content: `⚠️ No threshold found for **${count} warnings**.`,
            flags: MessageFlags.Ephemeral,
        });
    }

    const removed = config.Thresholds.splice(index, 1)[0];
    await config.save();

    const embed = new EmbedBuilder()
        .setColor(client.config.embedColor)
        .setAuthor({ name: "⚠️ Warn Config", iconURL: client.user.displayAvatarURL() })
        .setTitle("> Threshold Removed!")
        .addFields(
            { name: "• Warn Count", value: `> ${removed.Count}`, inline: true },
            { name: "• Action", value: `> ${capitalize(removed.Action)}`, inline: true }
        )
        .setFooter({ text: `Configured by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
        .setTimestamp();

    await interaction.reply({ embeds: [embed] });
}

// ========================================
// /warnconfig decay
// ========================================
async function handleDecay(interaction, client, guildId) {
    const enabled = interaction.options.getBoolean("enabled");
    const days = interaction.options.getInteger("days");

    let config = await warnConfigSchema.findOne({ GuildID: guildId });
    if (!config) {
        config = await warnConfigSchema.create({
            GuildID: guildId,
            Thresholds: [],
        });
    }

    config.DecayEnabled = enabled;
    if (days) config.DecayDays = days;
    await config.save();

    const embed = new EmbedBuilder()
        .setColor(client.config.embedColor)
        .setAuthor({ name: "⚠️ Warn Config", iconURL: client.user.displayAvatarURL() })
        .setTitle("> Warn Decay Updated!")
        .addFields(
            { name: "• Status", value: `> ${enabled ? "✅ Enabled" : "❌ Disabled"}`, inline: true },
            { name: "• Decay Period", value: `> ${config.DecayDays} days`, inline: true }
        )
        .setDescription(enabled
            ? `Warnings older than **${config.DecayDays} days** will be automatically removed daily.`
            : "Warn decay is now disabled. Warnings will remain indefinitely."
        )
        .setFooter({ text: `Configured by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
        .setTimestamp();

    await interaction.reply({ embeds: [embed] });
}

// ========================================
// /warnconfig view
// ========================================
async function handleView(interaction, client, guildId) {
    const config = await warnConfigSchema.findOne({ GuildID: guildId });

    if (!config || config.Thresholds.length === 0) {
        const emptyEmbed = new EmbedBuilder()
            .setColor(client.config.embedColor)
            .setAuthor({ name: "⚠️ Warn Config", iconURL: client.user.displayAvatarURL() })
            .setTitle("> Warn Configuration")
            .setDescription("```\nNo thresholds configured.\nUse /warnconfig add to set up auto-punishments.\n```")
            .addFields({
                name: "• Warn Decay",
                value: config
                    ? `> Status: ${config.DecayEnabled ? "✅ Enabled" : "❌ Disabled"}\n> Period: ${config.DecayDays} days`
                    : "> Status: ❌ Disabled\n> Period: 30 days (default)",
            })
            .setFooter({ text: `Requested by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
            .setTimestamp();

        return await interaction.reply({ embeds: [emptyEmbed] });
    }

    const thresholdList = config.Thresholds
        .sort((a, b) => a.Count - b.Count)
        .map((t) => {
            const dur = t.Action === "timeout" && t.Duration ? ` (${formatDuration(t.Duration)})` : "";
            return `> \`${t.Count}\` warns → **${capitalize(t.Action)}**${dur}`;
        })
        .join("\n");

    const embed = new EmbedBuilder()
        .setColor(client.config.embedColor)
        .setAuthor({ name: "⚠️ Warn Config", iconURL: client.user.displayAvatarURL() })
        .setTitle("> Warn Configuration")
        .addFields(
            {
                name: "• Auto-Punishment Thresholds",
                value: thresholdList,
            },
            {
                name: "• Warn Decay",
                value: `> Status: ${config.DecayEnabled ? "✅ Enabled" : "❌ Disabled"}\n> Period: ${config.DecayDays} days`,
            }
        )
        .setFooter({ text: `Requested by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
        .setTimestamp();

    await interaction.reply({ embeds: [embed] });
}

// ========================================
// Helpers
// ========================================
function capitalize(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
}

function formatDuration(seconds) {
    if (seconds < 60) return `${seconds}s`;
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h`;
    return `${Math.floor(seconds / 86400)}d`;
}

/**
 * Credits: Arpan | @arpandevv
 * Buy: https://nyxo.buzz/buy
 */
