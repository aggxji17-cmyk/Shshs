const {
  SlashCommandBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  PermissionsBitField,
  MessageFlags,
  ContainerBuilder,
  SectionBuilder,
  TextDisplayBuilder,
  ThumbnailBuilder,
  SeparatorBuilder
} = require("discord.js");
const ghostSchema = require("../../database/models/ghostpingSchema");
const numSchema = require("../../database/models/ghostNumSchema");
const { config } = require('../../config/config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName("anti-ghostping")
    .setDescription("Setup the anti ghost ping system")
    .addSubcommand((command) =>
      command
        .setName("setup")
        .setDescription("Setup the anti ghost ping system")
        .addChannelOption((option) =>
          option
            .setName("log-channel")
            .setDescription("The channel where ghost pings will be logged")
            .setRequired(false)
        )
    )
    .addSubcommand((command) =>
      command
        .setName("disable")
        .setDescription("Disable the anti ghost ping system")
    )
    .addSubcommand((command) =>
      command
        .setName("number-reset")
        .setDescription("Reset a user's ghost ping count")
        .addUserOption((option) =>
          option
            .setName("user")
            .setDescription(
              "The user you want to reset the number of ghost pings of"
            )
            .setRequired(true)
        )
    ),
  async execute(interaction, client) {
    if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
      return await interaction.reply({
        content: `${client.emoji.error} | You don't have perms to manage the anti ghost ping system`,
        flags: MessageFlags.Ephemeral,
      });
    }

    const { options } = interaction;
    const sub = options.getSubcommand();
    const botAvatar = interaction.client.user.displayAvatarURL({ extension: 'png', size: 512 });
    const accentColor = parseInt(config.embedColor.replace('#', ''), 16);

    const Data = await ghostSchema.findOne({ Guild: interaction.guild.id });

    switch (sub) {
      case "setup": {
        if (Data) {
          return await interaction.reply({
            content: `${client.emoji.warn} You already have the anti-ghost ping system setup.`,
            flags: MessageFlags.Ephemeral,
          });
        }

        const logChannel = options.getChannel("log-channel");
        
        await ghostSchema.create({
          Guild: interaction.guild.id,
          LogChannel: logChannel ? logChannel.id : null,
        });

        const container = new ContainerBuilder()
          .setAccentColor(accentColor)
          .addSectionComponents(
            new SectionBuilder()
              .addTextDisplayComponents(
                new TextDisplayBuilder().setContent('### 🛡️ Anti-Ghost Ping Enabled'),
                new TextDisplayBuilder().setContent(`Success! I've activated the ghost ping protection for **${interaction.guild.name}**.`)
              )
              .setThumbnailAccessory(new ThumbnailBuilder({ media: { url: botAvatar } }))
          )
          .addSeparatorComponents(new SeparatorBuilder().setDivider(true))
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`✨ **Status:** Active\n📝 **Logging:** ${logChannel ? logChannel.toString() : 'Disabled'}\n⚠️ **Policy:** Automatic timeout for offenders.`)
          );

        await interaction.reply({
          components: [container],
          flags: MessageFlags.IsComponentsV2
        });
        break;
      }

      case "disable": {
        if (!Data) {
          return await interaction.reply({
            content: `${client.emoji.error} | There is no anti-ghost ping system in place here.`,
            flags: MessageFlags.Ephemeral,
          });
        }

        await ghostSchema.deleteMany({ Guild: interaction.guild.id });

        const container = new ContainerBuilder()
          .setAccentColor(accentColor)
          .addSectionComponents(
            new SectionBuilder()
              .addTextDisplayComponents(
                new TextDisplayBuilder().setContent('### 🛡️ Anti-Ghost Ping Disabled'),
                new TextDisplayBuilder().setContent(`The ghost ping protection has been deactivated for **${interaction.guild.name}**.`)
              )
              .setThumbnailAccessory(new ThumbnailBuilder({ media: { url: botAvatar } }))
          )
          .addSeparatorComponents(new SeparatorBuilder().setDivider(true))
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`🗑️ **Action:** System Deactivated\n⚠️ **Warning:** Members can now ghost ping without penalties.`)
          );

        await interaction.reply({
          components: [container],
          flags: MessageFlags.IsComponentsV2
        });
        break;
      }

      case "number-reset": {
        const member = options.getUser("user");
        const data = await numSchema.findOne({
          Guild: interaction.guild.id,
          User: member.id,
        });

        if (!data) {
          return await interaction.reply({
            content: `This member doesn't have any ghost pings yet.`,
            flags: MessageFlags.Ephemeral,
          });
        }

        await data.deleteOne();

        const container = new ContainerBuilder()
          .setAccentColor(accentColor)
          .addSectionComponents(
            new SectionBuilder()
              .addTextDisplayComponents(
                new TextDisplayBuilder().setContent('### 🔄 Ghost Ping Reset'),
                new TextDisplayBuilder().setContent(`The ghost ping count for **${member.username}** has been cleared.`)
              )
              .setThumbnailAccessory(new ThumbnailBuilder({ media: { url: member.displayAvatarURL() } }))
          )
          .addSeparatorComponents(new SeparatorBuilder().setDivider(true))
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`👤 **User:** ${member}\n📊 **New Count:** 0\n✅ **Status:** User given a fresh start.`)
          );

        await interaction.reply({
          components: [container],
          flags: MessageFlags.IsComponentsV2
        });
        break;
      }
    }
  },
};



/**
 * Credits: Arpan | @arpandevv
 * Buy: https://nyxo.buzz/buy
 */