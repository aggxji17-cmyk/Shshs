const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ChannelSelectMenuBuilder,
  ChannelType,
} = require("discord.js");

const AutoDelete = require("../../database/models/autoDeleteSchema");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("setup-autodelete")
    .setDescription("Configure automatic message deletion per channel")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    let data = await AutoDelete.findOne({ guildId: interaction.guild.id });
    if (!data) {
      data = await AutoDelete.create({
        guildId: interaction.guild.id,
        channels: [],
      });
    }

    const mainEmbed = new EmbedBuilder()
      .setColor("#ED4245")
      .setAuthor({
        name: "Auto Delete System",
        iconURL: interaction.client.user.displayAvatarURL(),
      })
      .setDescription(
        "**Automatically delete messages after a set time in selected channels.**\n\n" +
        "• Keep chat clean\n" +
        "• Reduce spam\n" +
        "• Ideal for help / bot channels"
      )
      .setFooter({ text: "NYXO BOT • Channel Management" });

    const mainMenu = new StringSelectMenuBuilder()
      .setCustomId("autodelete-main")
      .setPlaceholder("Choose an action")
      .addOptions([
        { label: "Add Auto Delete Channel", value: "add", emoji: "➕" },
        { label: "Remove Auto Delete Channel", value: "remove", emoji: "➖" },
        { label: "Show Configured Channels", value: "show", emoji: "📑" },
      ]);

    const response = await interaction.reply({
      embeds: [mainEmbed],
      components: [new ActionRowBuilder().addComponents(mainMenu)],
      withResponse: true,
    });

    const msg = response.resource.message;

    const collector = msg.createMessageComponentCollector({
      time: 120_000,
    });

    let selectedChannelId = null;

    collector.on("collect", async i => {
      if (i.user.id !== interaction.user.id)
        return i.reply({ content: "❌ This setup isn’t for you.", ephemeral: true });

      /* SHOW */
      if (i.customId === "autodelete-main" && i.values[0] === "show") {
        const list =
          data.channels.length === 0
            ? "No channels configured yet."
            : data.channels
                .map(c => `• <#${c.channelId}> → **${c.delay / 1000}s**`)
                .join("\n");

        return i.update({
          embeds: [
            new EmbedBuilder()
              .setColor("Green")
              .setTitle("📑 Auto Delete Channels")
              .setDescription(list),
          ],
          components: [],
        });
      }

      /* ADD STEP 1 — PICK CHANNEL */
      if (i.customId === "autodelete-main" && i.values[0] === "add") {
        const channelMenu = new ChannelSelectMenuBuilder()
          .setCustomId("autodelete-pick-channel")
          .setPlaceholder("Select a channel")
          .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement)
          .setMaxValues(1);

        return i.update({
          embeds: [
            new EmbedBuilder()
              .setColor("#FEE75C")
              .setTitle("➕ Add Auto Delete Channel")
              .setDescription("Select the channel where messages should auto-delete."),
          ],
          components: [new ActionRowBuilder().addComponents(channelMenu)],
        });
      }

      /* ADD STEP 2 — PICK TIME */
      if (i.customId === "autodelete-pick-channel") {
        selectedChannelId = i.values[0];

        const timeMenu = new StringSelectMenuBuilder()
          .setCustomId("autodelete-pick-time")
          .setPlaceholder("Select delete delay")
          .addOptions([
            { label: "5 Seconds", value: "5000" },
            { label: "10 Seconds", value: "10000" },
            { label: "30 Seconds", value: "30000" },
            { label: "1 Minute", value: "60000" },
            { label: "5 Minutes", value: "300000" },
          ]);

        return i.update({
          embeds: [
            new EmbedBuilder()
              .setColor("#FEE75C")
              .setTitle("⏱️ Select Delete Delay")
              .setDescription(`Channel selected: <#${selectedChannelId}>`),
          ],
          components: [new ActionRowBuilder().addComponents(timeMenu)],
        });
      }

      /* ADD FINAL — SAVE */
      if (i.customId === "autodelete-pick-time") {
        const delay = Number(i.values[0]);

        if (data.channels.some(c => c.channelId === selectedChannelId)) {
          return i.update({
            content: "⚠️ This channel is already configured.",
            embeds: [],
            components: [],
          });
        }

        data.channels.push({
          channelId: selectedChannelId,
          delay,
        });

        await data.save();

        return i.update({
          embeds: [
            new EmbedBuilder()
              .setColor("Green")
              .setTitle("✅ Auto Delete Enabled")
              .setDescription(
                `Messages in <#${selectedChannelId}> will be deleted after **${delay / 1000} seconds**.`
              ),
          ],
          components: [],
        });
      }

      /* REMOVE */
      if (i.customId === "autodelete-main" && i.values[0] === "remove") {
        if (!data.channels.length)
          return i.reply({ content: "⚠️ No channels to remove.", ephemeral: true });

        const removeMenu = new ChannelSelectMenuBuilder()
          .setCustomId("autodelete-remove")
          .setPlaceholder("Select channel to remove")
          .setMaxValues(1);

        return i.update({
          embeds: [
            new EmbedBuilder()
              .setColor("Red")
              .setTitle("➖ Remove Auto Delete Channel"),
          ],
          components: [new ActionRowBuilder().addComponents(removeMenu)],
        });
      }

      if (i.customId === "autodelete-remove") {
        data.channels = data.channels.filter(c => c.channelId !== i.values[0]);
        await data.save();

        return i.update({
          embeds: [
            new EmbedBuilder()
              .setColor("Green")
              .setTitle("✅ Channel Removed")
              .setDescription(`<#${i.values[0]}> is no longer auto-deleted.`),
          ],
          components: [],
        });
      }
    });

    collector.on("end", () => {
      msg.edit({ components: [] }).catch(() => {});
    });
  },
};
