const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits } = require('discord.js');
const MenuApply = require('../../database/models/menuApplySchema');
const Apply = require('../../database/models/applySchema');
const { getNumberEmojis } = require('../../../Utilities/emojiUtils');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('setup-menuapply')
        .setDescription('Create a selection menu for multiple application types')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    async execute(interaction) {
        const { guild, user } = interaction;
        const NumberEmojis = getNumberEmojis();

        await interaction.deferReply({ flags: 64 });

        async function firstLayer() {
            const menuOptions = [];

            for (let i = 1; i <= 10; i++) {
                const option = {
                    label: `Menu System #${i}`,
                    value: `${i}. Menu Apply`,
                    description: `Configure the multi-application menu for slot ${i}`
                };

                if (NumberEmojis[i]) {
                    option.emoji = NumberEmojis[i];
                }

                menuOptions.push(option);
            }

            const selectMenu = new ActionRowBuilder().addComponents(
                new StringSelectMenuBuilder()
                    .setCustomId('menuapply_select_main')
                    .setPlaceholder('Select a menu system to configure...')
                    .setMinValues(1)
                    .setMaxValues(1)
                    .addOptions(menuOptions)
            );

            const embed = new EmbedBuilder()
                .setColor('#5865F2')
                .setTitle('📂 Multi-Application Setup')
                .setDescription('This tool allows you to create a single message with a dropdown menu, letting users choose from various application types. Select one of the **10 available slots** to begin.')
                .addFields({ name: '💡 Tip', value: 'You can link existing application systems (from `/setup-apply`) to this menu.' })
                .setFooter({ text: 'Menu System • Management Portal', iconURL: guild.iconURL() });

            const msg = await interaction.editReply({
                embeds: [embed],
                components: [selectMenu]
            });

            const collector = msg.createMessageComponentCollector({
                filter: i => i.user.id === user.id && i.isStringSelectMenu(),
                time: 90000
            });

            collector.on('collect', async i => {
                await i.deferUpdate();
                const setupNumber = parseInt(i.values[0].split('.')[0]);
                collector.stop();
                await secondLayer(setupNumber);
            });

            collector.on('end', async (collected) => {
                if (collected.size === 0) {
                    const timeoutEmbed = EmbedBuilder.from(embed)
                        .setColor('#ED4245')
                        .setDescription('❌ **Setup session timed out.** Please run the command again.');

                    await interaction.editReply({
                        embeds: [timeoutEmbed],
                        components: []
                    }).catch(() => { });
                }
            });
        }

        async function secondLayer(setupNumber) {
            const menuOptions = [
                {
                    label: 'Deploy Menu',
                    value: 'send_config',
                    description: 'Send or update the application menu message',
                    emoji: '🚀'
                },
                {
                    label: 'Add Application Type',
                    value: 'add_option',
                    description: 'Add a new application option to this menu',
                    emoji: '➕'
                },
                {
                    label: 'Remove Application Type',
                    value: 'remove_option',
                    description: 'Delete an existing option from this menu',
                    emoji: '➖'
                },
                {
                    label: 'Exit',
                    value: 'cancel',
                    description: 'Close the configuration menu',
                    emoji: '🚪'
                }
            ];

            const selectMenu = new ActionRowBuilder().addComponents(
                new StringSelectMenuBuilder()
                    .setCustomId('menuapply_config')
                    .setPlaceholder(`Configuring Menu #${setupNumber}`)
                    .setMinValues(1)
                    .setMaxValues(1)
                    .addOptions(menuOptions)
            );

            const embed = new EmbedBuilder()
                .setColor('#5865F2')
                .setTitle(`⚙️ Menu Configuration: #${setupNumber}`)
                .setDescription('Manage the options available in this multi-application menu. You must add at least one option before deploying.')
                .setFooter({ text: 'Select an action from the dropdown' });

            const msg = await interaction.editReply({
                embeds: [embed],
                components: [selectMenu]
            });

            const collector = msg.createMessageComponentCollector({
                filter: i => i.user.id === user.id && i.isStringSelectMenu(),
                time: 90000
            });

            collector.on('collect', async i => {
                await i.deferUpdate();
                collector.stop();

                if (i.values[0] === 'cancel') {
                    return interaction.followUp({ content: '👋 **Configuration session closed.**', ephemeral: true });
                }

                await handlePicks(i.values[0], setupNumber);
            });
        }

        async function handlePicks(option, setupNumber) {
            switch (option) {
                case 'send_config':
                    await sendConfigMessage(setupNumber);
                    break;
                case 'add_option':
                    await addApplyOption(setupNumber);
                    break;
                case 'remove_option':
                    await removeApplyOption(setupNumber);
                    break;
            }
        }

        async function sendConfigMessage(setupNumber) {
            let menuApply = await MenuApply.findOne({ guildId: guild.id, systemNumber: setupNumber });

            if (!menuApply || menuApply.options.length < 1) {
                return interaction.followUp({
                    content: '❌ **You must add at least one application option before deploying the menu.**',
                    ephemeral: true
                });
            }

            const textEmbed = new EmbedBuilder()
                .setColor('#5865F2')
                .setTitle('📝 Embed Content')
                .setDescription('Enter the text you want to display in the application menu embed.\n\n*Example: "Please select the department you wish to apply for from the menu below."*');

            await interaction.followUp({ embeds: [textEmbed], ephemeral: true });

            const textFilter = m => m.author.id === user.id;
            const textCollected = await interaction.channel.awaitMessages({ filter: textFilter, max: 1, time: 90000 }).catch(() => null);

            if (!textCollected || !textCollected.first()) {
                return interaction.followUp({ content: '❌ **No input received. Operation cancelled.**', ephemeral: true });
            }

            const embedText = textCollected.first().content;
            await textCollected.first().delete().catch(() => { });

            const channelEmbed = new EmbedBuilder()
                .setColor('#5865F2')
                .setTitle('📍 Target Channel')
                .setDescription('Mention the channel where the application menu should be sent.')
                .setFooter({ text: menuApply.channelId ? `Current: #${guild.channels.cache.get(menuApply.channelId)?.name || 'Unknown'}` : 'No channel set yet' });

            await interaction.followUp({ embeds: [channelEmbed], ephemeral: true });

            const channelCollected = await interaction.channel.awaitMessages({ filter: textFilter, max: 1, time: 90000 }).catch(() => null);

            if (!channelCollected || !channelCollected.first() || !channelCollected.first().mentions.channels.size) {
                return interaction.followUp({ content: '❌ **Invalid channel. Operation cancelled.**', ephemeral: true });
            }

            const targetChannel = channelCollected.first().mentions.channels.first();
            await channelCollected.first().delete().catch(() => { });

            const finalEmbed = new EmbedBuilder()
                .setColor('#5865F2')
                .setTitle('📋 Application Portal')
                .setDescription(embedText)
                .setFooter({ text: guild.name, iconURL: guild.iconURL() });

            const finalMenu = new ActionRowBuilder().addComponents(
                new StringSelectMenuBuilder()
                    .setCustomId(`menuapply_user_select_${setupNumber}`)
                    .setPlaceholder('Choose an application type...')
                    .addOptions(menuApply.options.map((opt, idx) => ({
                        label: opt.value,
                        description: opt.description,
                        value: opt.applySystemNumber.toString(),
                        emoji: opt.emoji || NumberEmojis[idx + 1] || '📝'
                    })))
            );

            await targetChannel.send({
                embeds: [finalEmbed],
                components: [finalMenu]
            });

            menuApply.channelId = targetChannel.id;
            await menuApply.save();

            await interaction.followUp({ content: `✅ **Application menu successfully deployed to ${targetChannel}!**`, ephemeral: true });
        }

        async function addApplyOption(setupNumber) {
            let menuApply = await MenuApply.findOne({ guildId: guild.id, systemNumber: setupNumber });
            if (!menuApply) {
                menuApply = new MenuApply({ guildId: guild.id, systemNumber: setupNumber, options: [] });
            }

            if (menuApply.options.length >= 25) {
                return interaction.followUp({ content: '❌ **Maximum limit of 25 options reached for this menu.**', ephemeral: true });
            }

            const systems = await Apply.find({ guildId: guild.id });
            if (systems.length === 0) {
                return interaction.followUp({ content: '❌ **No application systems found. Create one first using `/setup-apply`.**', ephemeral: true });
            }

            const systemSelect = new ActionRowBuilder().addComponents(
                new StringSelectMenuBuilder()
                    .setCustomId('select_apply_system')
                    .setPlaceholder('Link an application system...')
                    .addOptions(systems.map(s => ({
                        label: `System #${s.systemNumber}`,
                        value: s.systemNumber.toString(),
                        description: `Questions: ${s.questions.length}`
                    })))
            );

            const embed = new EmbedBuilder()
                .setColor('#5865F2')
                .setTitle('🔗 Link Application System')
                .setDescription('Select which application system should be triggered when this option is chosen.');

            const msg = await interaction.followUp({ embeds: [embed], components: [systemSelect], ephemeral: true });

            const collector = msg.createMessageComponentCollector({
                filter: i => i.user.id === user.id && i.isStringSelectMenu(),
                time: 60000
            });

            collector.on('collect', async i => {
                await i.deferUpdate();
                const linkedSystem = parseInt(i.values[0]);
                collector.stop();

                await interaction.followUp({ content: '📝 **Enter the label for this option (e.g., "Staff Application"):**', ephemeral: true });
                const filter = m => m.author.id === user.id;
                const labelMsg = await interaction.channel.awaitMessages({ filter, max: 1, time: 60000 }).catch(() => null);
                if (!labelMsg || !labelMsg.first()) return;
                const label = labelMsg.first().content;
                await labelMsg.first().delete().catch(() => { });

                await interaction.followUp({ content: '📝 **Enter a short description for this option:**', ephemeral: true });
                const descMsg = await interaction.channel.awaitMessages({ filter, max: 1, time: 60000 }).catch(() => null);
                if (!descMsg || !descMsg.first()) return;
                const description = descMsg.first().content;
                await descMsg.first().delete().catch(() => { });

                menuApply.options.push({
                    value: label,
                    description: description,
                    applySystemNumber: linkedSystem
                });

                await menuApply.save();
                await interaction.followUp({ content: `✅ **Option "${label}" added to Menu #${setupNumber}.**`, ephemeral: true });
                await secondLayer(setupNumber);
            });
        }

        async function removeApplyOption(setupNumber) {
            const menuApply = await MenuApply.findOne({ guildId: guild.id, systemNumber: setupNumber });

            if (!menuApply || menuApply.options.length === 0) {
                return interaction.followUp({ content: '❌ **There are no options to remove.**', ephemeral: true });
            }

            const selectMenu = new ActionRowBuilder().addComponents(
                new StringSelectMenuBuilder()
                    .setCustomId('remove_options')
                    .setPlaceholder('Select options to remove...')
                    .setMinValues(1)
                    .setMaxValues(menuApply.options.length)
                    .addOptions(menuApply.options.map((opt, idx) => ({
                        label: opt.value.substring(0, 100),
                        value: opt.value,
                        description: opt.description.substring(0, 100),
                        emoji: opt.emoji || NumberEmojis[idx + 1] || '📝'
                    })))
            );

            const embed = new EmbedBuilder()
                .setColor('#ED4245')
                .setTitle('🗑️ Remove Options')
                .setDescription('Select the options you wish to remove from this menu.');

            const msg = await interaction.followUp({
                embeds: [embed],
                components: [selectMenu],
                ephemeral: true
            });

            const collector = msg.createMessageComponentCollector({
                filter: i => i.user.id === user.id && i.isStringSelectMenu(),
                time: 90000
            });

            collector.on('collect', async i => {
                await i.deferUpdate();
                collector.stop();

                const valuesToRemove = i.values;
                menuApply.options = menuApply.options.filter(opt => !valuesToRemove.includes(opt.value));
                await menuApply.save();

                await interaction.followUp({
                    content: `✅ **Removed ${valuesToRemove.length} option(s).** Remember to redeploy the menu message!`,
                    ephemeral: true
                });
                await secondLayer(setupNumber);
            });
        }

        await firstLayer();
    }
};
