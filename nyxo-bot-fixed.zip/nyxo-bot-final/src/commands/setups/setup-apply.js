const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits, ChannelType } = require('discord.js');
const Apply = require('../../database/models/applySchema');
const { getNumberEmojis } = require('../../../Utilities/emojiUtils');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('setup-apply')
        .setDescription('Configure and manage your server application systems')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    async execute(interaction) {
        const { guild, user } = interaction;
        const NumberEmojis = getNumberEmojis();

        await interaction.deferReply({ flags: 64 });

        async function firstLayer() {
            const menuOptions = [];

            for (let i = 1; i <= 10; i++) {
                const option = {
                    label: `Application System #${i}`,
                    value: `${i} Apply System`,
                    description: `Configure settings for application slot ${i}`
                };

                if (NumberEmojis[i]) {
                    option.emoji = NumberEmojis[i];
                }

                menuOptions.push(option);
            }

            const selectMenu = new ActionRowBuilder().addComponents(
                new StringSelectMenuBuilder()
                    .setCustomId('apply_select_main')
                    .setPlaceholder('Select an application system to manage...')
                    .setMinValues(1)
                    .setMaxValues(1)
                    .addOptions(menuOptions)
            );

            const embed = new EmbedBuilder()
                .setColor('#5865F2')
                .setTitle('🛠️ Application Management')
                .setDescription('Welcome to the application setup wizard. Please select one of the **10 available slots** below to begin configuring your custom application system.')
                .addFields({ name: '📌 Note', value: 'Each system can be independently configured with its own questions, roles, and logging channels.' })
                .setFooter({ text: 'Application System • Management Portal', iconURL: guild.iconURL() });

            const msg = await interaction.editReply({
                embeds: [embed],
                components: [selectMenu]
            });

            const collector = msg.createMessageComponentCollector({
                filter: i => i.user.id === user.id && i.isStringSelectMenu(),
                time: 90000
            });

            collector.on('collect', async i => {
                await i.deferUpdate();
                const setupNumber = parseInt(i.values[0].split(' ')[0]);
                collector.stop();
                await secondLayer(setupNumber);
            });

            collector.on('end', async (collected) => {
                if (collected.size === 0) {
                    const timeoutEmbed = EmbedBuilder.from(embed)
                        .setColor('#ED4245')
                        .setDescription('❌ **Setup session timed out.** Please run the command again if you wish to continue.');

                    await interaction.editReply({
                        embeds: [timeoutEmbed],
                        components: []
                    }).catch(() => { });
                }
            });
        }

        async function secondLayer(setupNumber) {
            let applySystem = await Apply.findOne({ guildId: guild.id, systemNumber: setupNumber });
            if (!applySystem) {
                applySystem = new Apply({
                    guildId: guild.id,
                    systemNumber: setupNumber,
                    questions: [{ number: 1, question: 'DEFAULT' }]
                });
                await applySystem.save();
            }

            const menuOptions = [
                {
                    label: 'Initialize System',
                    value: 'create',
                    description: 'Set up channels and initial questions',
                    emoji: '🚀'
                },
                {
                    label: 'Acceptance Message',
                    value: 'acceptmsg',
                    description: 'Customize the message sent upon approval',
                    emoji: '✅'
                },
                {
                    label: 'Rejection Message',
                    value: 'denymsg',
                    description: 'Customize the message sent upon denial',
                    emoji: '❌'
                },
                {
                    label: 'Ticket Message',
                    value: 'ticketmsg',
                    description: 'Message for redirected applications',
                    emoji: '🎫'
                },
                {
                    label: 'Success Role',
                    value: 'acceptrole',
                    description: 'Role granted after application approval',
                    emoji: '🏆'
                },
                {
                    label: 'Pending Role',
                    value: 'temprole',
                    description: 'Role granted while application is active',
                    emoji: '⏳'
                },
                {
                    label: 'Question Management',
                    value: 'editquestion',
                    description: 'Modify existing application questions',
                    emoji: '📝'
                },
                {
                    label: 'Add Question',
                    value: 'addquestion',
                    description: 'Insert a new question into the system',
                    emoji: '➕'
                },
                {
                    label: 'Remove Question',
                    value: 'removequestion',
                    description: 'Delete a question from the system',
                    emoji: '➖'
                },
                {
                    label: 'Submission Channel',
                    value: 'applychannel',
                    description: 'Where users start their application',
                    emoji: '📥'
                },
                {
                    label: 'Logging Channel',
                    value: 'finishedapplychannel',
                    description: 'Where staff reviews submissions',
                    emoji: '📑'
                },
                {
                    label: applySystem.lastVerify ? 'Disable Verification' : 'Enable Verification',
                    value: 'lastverify',
                    description: 'Toggle final confirmation step',
                    emoji: '🛡️'
                },
                {
                    label: 'Exit Setup',
                    value: 'cancel',
                    description: 'Close the configuration menu',
                    emoji: '🚪'
                }
            ];

            const selectMenu = new ActionRowBuilder().addComponents(
                new StringSelectMenuBuilder()
                    .setCustomId('apply_config')
                    .setPlaceholder(`Configuring System #${setupNumber}`)
                    .setMinValues(1)
                    .setMaxValues(1)
                    .addOptions(menuOptions)
            );

            const embed = new EmbedBuilder()
                .setColor('#5865F2')
                .setTitle(`⚙️ Configuration: System #${setupNumber}`)
                .setDescription('Select an option from the menu below to customize this application system. Changes are saved automatically.')
                .addFields(
                    { name: '📊 Current Status', value: `Questions: \`${applySystem.questions.length}\`\nVerification: \`${applySystem.lastVerify ? 'Enabled' : 'Disabled'}\``, inline: true },
                    { name: '📍 Active Channels', value: `Apply: ${applySystem.applyChannelId ? `<#${applySystem.applyChannelId}>` : '`Not Set`'}\nLogs: ${applySystem.finishedChannelId ? `<#${applySystem.finishedChannelId}>` : '`Not Set`'}`, inline: true }
                )
                .setFooter({ text: 'Use the dropdown to navigate settings' });

            const msg = await interaction.editReply({
                embeds: [embed],
                components: [selectMenu]
            });

            const collector = msg.createMessageComponentCollector({
                filter: i => i.user.id === user.id && i.isStringSelectMenu(),
                time: 90000
            });

            collector.on('collect', async i => {
                await i.deferUpdate();
                collector.stop();

                if (i.values[0] === 'cancel') {
                    return interaction.followUp({ content: '👋 **Configuration session closed.**', ephemeral: true });
                }

                switch (i.values[0]) {
                    case 'create':
                        await setupWithChannelCreation(setupNumber);
                        break;
                    case 'acceptmsg':
                        await editMessage(setupNumber, 'accept', 'Acceptance Message');
                        break;
                    case 'denymsg':
                        await editMessage(setupNumber, 'deny', 'Rejection Message');
                        break;
                    case 'ticketmsg':
                        await editMessage(setupNumber, 'ticket', 'Ticket Message');
                        break;
                    case 'acceptrole':
                        await editRole(setupNumber, 'acceptRole', 'Success Role');
                        break;
                    case 'temprole':
                        await editRole(setupNumber, 'tempRole', 'Pending Role');
                        break;
                    case 'editquestion':
                        await editQuestion(setupNumber);
                        break;
                    case 'addquestion':
                        await addQuestion(setupNumber);
                        break;
                    case 'removequestion':
                        await removeQuestion(setupNumber);
                        break;
                    case 'applychannel':
                        await setApplyChannel(setupNumber);
                        break;
                    case 'finishedapplychannel':
                        await setFinishedChannel(setupNumber);
                        break;
                    case 'lastverify':
                        applySystem.lastVerify = !applySystem.lastVerify;
                        await applySystem.save();
                        await interaction.followUp({ content: `✅ **Verification is now ${applySystem.lastVerify ? 'enabled' : 'disabled'}.**`, ephemeral: true });
                        await secondLayer(setupNumber);
                        break;
                }
            });
        }

        async function setupWithChannelCreation(setupNumber) {
            await interaction.followUp({
                content: '🛠️ **Initializing system...** Please follow the prompts in the next messages.',
                ephemeral: true
            });

            const applyChannel = await guild.channels.create({
                name: `apply-system-${setupNumber}`,
                type: ChannelType.GuildText,
                permissionOverwrites: [
                    {
                        id: guild.id,
                        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages],
                    }
                ]
            });

            const finishedChannel = await guild.channels.create({
                name: `logs-system-${setupNumber}`,
                type: ChannelType.GuildText,
                permissionOverwrites: [
                    {
                        id: guild.id,
                        deny: [PermissionFlagsBits.ViewChannel],
                    }
                ]
            });

            await askQuestionsSimple(setupNumber, applyChannel, finishedChannel);
        }

        async function askQuestionsSimple(setupNumber, applyChannel, finishedChannel) {
            const questions = [];

            await interaction.followUp({
                content: '📝 **Please enter your questions one by one. Type `finish` when you are done.**',
                ephemeral: true
            });

            const filter = m => m.author.id === user.id;

            for (let i = 1; i <= 25; i++) {
                const prompt = await interaction.channel.send(`**Question #${i}:** (Type \`finish\` to complete)`);

                const collected = await interaction.channel.awaitMessages({
                    filter,
                    max: 1,
                    time: 180000
                }).catch(() => null);

                if (!collected || !collected.first()) break;

                const content = collected.first().content;
                await collected.first().delete().catch(() => { });
                await prompt.delete().catch(() => { });

                if (content.toLowerCase() === 'finish') break;

                questions.push({ number: i, question: content });
            }

            const applyEmbed = new EmbedBuilder()
                .setColor('#5865F2')
                .setTitle('📋 Application Form')
                .setDescription('Ready to join our team? Click the button below to start your application process. Make sure to answer all questions honestly!')
                .setFooter({ text: 'Powered by Application System' });

            const applyButton = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId(`User_Apply_${setupNumber}`)
                    .setLabel('Start Application')
                    .setStyle(ButtonStyle.Primary)
                    .setEmoji('📝')
            );

            await applyChannel.send({
                embeds: [applyEmbed],
                components: [applyButton]
            });

            const applySystem = await Apply.findOne({ guildId: guild.id, systemNumber: setupNumber });
            applySystem.questions = questions;
            applySystem.applyChannelId = applyChannel.id;
            applySystem.finishedChannelId = finishedChannel.id;
            await applySystem.save();

            await interaction.followUp({
                content: `✅ **System #${setupNumber} is now live!**\n\n📍 **Apply here:** ${applyChannel}\n📑 **Review here:** ${finishedChannel}`,
                ephemeral: true
            });
        }

        async function editMessage(setupNumber, field, fieldName) {
            await interaction.followUp({
                content: `📝 **Please enter the new ${fieldName}:**`,
                ephemeral: true
            });

            const filter = m => m.author.id === user.id;
            const collected = await interaction.channel.awaitMessages({
                filter,
                max: 1,
                time: 180000
            }).catch(() => null);

            if (!collected || !collected.first()) {
                return interaction.followUp({ content: '❌ **Timed out.**', ephemeral: true });
            }

            const content = collected.first().content;
            await collected.first().delete().catch(() => { });

            const applySystem = await Apply.findOne({ guildId: guild.id, systemNumber: setupNumber });

            if (field === 'accept') applySystem.acceptMessage = content;
            else if (field === 'deny') applySystem.denyMessage = content;
            else if (field === 'ticket') applySystem.ticketMessage = content;

            await applySystem.save();

            await interaction.followUp({ content: `✅ **${fieldName} has been updated.**`, ephemeral: true });
            await secondLayer(setupNumber);
        }

        async function editRole(setupNumber, field, fieldName) {
            await interaction.followUp({
                content: `🎭 **Please mention the role for ${fieldName}:**`,
                ephemeral: true
            });

            const filter = m => m.author.id === user.id;
            const collected = await interaction.channel.awaitMessages({
                filter,
                max: 1,
                time: 180000
            }).catch(() => null);

            if (!collected || !collected.first()) {
                return interaction.followUp({ content: '❌ **Timed out.**', ephemeral: true });
            }

            const role = collected.first().mentions.roles.first();
            await collected.first().delete().catch(() => { });

            if (!role) {
                return interaction.followUp({ content: '❌ **Invalid role mentioned.**', ephemeral: true });
            }

            const applySystem = await Apply.findOne({ guildId: guild.id, systemNumber: setupNumber });

            if (field === 'acceptRole') applySystem.acceptRole = role.id;
            else if (field === 'tempRole') applySystem.tempRole = role.id;

            await applySystem.save();

            await interaction.followUp({ content: `✅ **${fieldName} set to ${role}.**`, ephemeral: true });
            await secondLayer(setupNumber);
        }

        async function editQuestion(setupNumber) {
            await interaction.followUp({ content: '🚧 **This feature is currently under maintenance.**', ephemeral: true });
            await secondLayer(setupNumber);
        }

        async function addQuestion(setupNumber) {
            const applySystem = await Apply.findOne({ guildId: guild.id, systemNumber: setupNumber });

            if (applySystem.questions.length >= 25) {
                return interaction.followUp({ content: '❌ **Maximum limit of 25 questions reached.**', ephemeral: true });
            }

            await interaction.followUp({ content: '📝 **Enter the new question text:**', ephemeral: true });

            const filter = m => m.author.id === user.id;
            const collected = await interaction.channel.awaitMessages({
                filter,
                max: 1,
                time: 180000
            }).catch(() => null);

            if (!collected || !collected.first()) {
                return interaction.followUp({ content: '❌ **Timed out.**', ephemeral: true });
            }

            const question = collected.first().content;
            await collected.first().delete().catch(() => { });

            applySystem.questions.push({
                number: applySystem.questions.length + 1,
                question
            });

            await applySystem.save();

            await interaction.followUp({ content: `✅ **Question added. Total: ${applySystem.questions.length}**`, ephemeral: true });
            await secondLayer(setupNumber);
        }

        async function removeQuestion(setupNumber) {
            const applySystem = await Apply.findOne({ guildId: guild.id, systemNumber: setupNumber });
            if (applySystem.questions.length <= 1) {
                return interaction.followUp({ content: '❌ **You must have at least one question.**', ephemeral: true });
            }

            applySystem.questions.pop();
            await applySystem.save();

            await interaction.followUp({ content: '✅ **Last question removed.**', ephemeral: true });
            await secondLayer(setupNumber);
        }

        async function setApplyChannel(setupNumber) {
            await interaction.followUp({ content: '📍 **Mention the channel where users will start applications:**', ephemeral: true });

            const filter = m => m.author.id === user.id;
            const collected = await interaction.channel.awaitMessages({
                filter,
                max: 1,
                time: 180000
            }).catch(() => null);

            if (!collected || !collected.first() || !collected.first().mentions.channels.size) {
                return interaction.followUp({ content: '❌ **Invalid channel.**', ephemeral: true });
            }

            const channel = collected.first().mentions.channels.first();
            await collected.first().delete().catch(() => { });

            const applySystem = await Apply.findOne({ guildId: guild.id, systemNumber: setupNumber });
            applySystem.applyChannelId = channel.id;
            await applySystem.save();

            await interaction.followUp({ content: `✅ **Apply channel set to ${channel}.**`, ephemeral: true });
            await secondLayer(setupNumber);
        }

        async function setFinishedChannel(setupNumber) {
            await interaction.followUp({ content: '📍 **Mention the channel for application logs:**', ephemeral: true });

            const filter = m => m.author.id === user.id;
            const collected = await interaction.channel.awaitMessages({
                filter,
                max: 1,
                time: 180000
            }).catch(() => null);

            if (!collected || !collected.first() || !collected.first().mentions.channels.size) {
                return interaction.followUp({ content: '❌ **Invalid channel.**', ephemeral: true });
            }

            const channel = collected.first().mentions.channels.first();
            await collected.first().delete().catch(() => { });

            const applySystem = await Apply.findOne({ guildId: guild.id, systemNumber: setupNumber });
            applySystem.finishedChannelId = channel.id;
            await applySystem.save();

            await interaction.followUp({ content: `✅ **Log channel set to ${channel}.**`, ephemeral: true });
            await secondLayer(setupNumber);
        }

        await firstLayer();
    }
};
