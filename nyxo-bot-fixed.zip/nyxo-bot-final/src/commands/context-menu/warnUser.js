const { ContextMenuCommandBuilder, ApplicationCommandType, PermissionFlagsBits, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { errorEmbed } = require('../../utils/embeds');
const { isModerator } = require('../../utils/permissions');

/**
 * User context-menu command ("Apps" menu on right-click / long-press a
 * member) offering a one-click shortcut to /warn. Since context menu
 * commands can't take extra options, the reason is collected via the
 * same modal pattern used elsewhere (see components/modals.js's
 * `ctxwarn_modal` handler, which does the actual Warn/Case creation).
 */
module.exports = {
  data: new ContextMenuCommandBuilder()
    .setName('تحذير سريع')
    .setNameLocalizations({ ar: 'تحذير سريع', 'en-US': 'Quick Warn' })
    .setType(ApplicationCommandType.User)
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isModerator(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You do not have permission to use this command.')], ephemeral: true });
    }

    const target = interaction.targetUser;
    if (target.bot) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You cannot warn a bot.')], ephemeral: true });
    }

    const modal = new ModalBuilder().setCustomId(`ctxwarn_modal:${target.id}`).setTitle(`Warn ${target.tag}`.slice(0, 45));

    const reason = new TextInputBuilder()
      .setCustomId('reason')
      .setLabel('Reason / السبب')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(true)
      .setMaxLength(500);

    modal.addComponents(new ActionRowBuilder().addComponents(reason));

    await interaction.showModal(modal);
  },
};
