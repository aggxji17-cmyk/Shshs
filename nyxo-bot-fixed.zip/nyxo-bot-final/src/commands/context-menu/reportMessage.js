const { ContextMenuCommandBuilder, ApplicationCommandType } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { baseEmbed, successEmbed, errorEmbed } = require('../../utils/embeds');

/**
 * Message context-menu command ("Apps" menu on right-click / long-press a
 * message) letting any member flag a message to staff. Open to everyone
 * (no setDefaultMemberPermissions) - unlike the moderation commands,
 * reporting is meant to be usable by regular members, not just staff.
 */
module.exports = {
  data: new ContextMenuCommandBuilder()
    .setName('الإبلاغ عن الرسالة')
    .setNameLocalizations({ ar: 'الإبلاغ عن الرسالة', 'en-US': 'Report Message' })
    .setType(ApplicationCommandType.Message),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    const channelId = guildConfig.moderationLogChannelId;
    const logChannel = channelId ? interaction.guild.channels.cache.get(channelId) : null;

    if (!logChannel) {
      return interaction.reply({
        embeds: [errorEmbed(settings, 'This server has not configured a moderation log channel, so reports cannot be delivered.')],
        ephemeral: true,
      });
    }

    const message = interaction.targetMessage;

    if (message.author.id === interaction.user.id) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You cannot report your own message.')], ephemeral: true });
    }

    const embed = baseEmbed(settings)
      .setTitle('🚩 Message Reported / تم الإبلاغ عن رسالة')
      .addFields(
        { name: 'Author', value: `${message.author} (${message.author.id})`, inline: true },
        { name: 'Reported by', value: `${interaction.user} (${interaction.user.id})`, inline: true },
        { name: 'Channel', value: `${message.channel}`, inline: true },
        { name: 'Content', value: message.content ? message.content.slice(0, 1000) : '*No text content*' },
        { name: 'Jump', value: message.url }
      );

    if (message.attachments.size > 0) {
      embed.setImage(message.attachments.first().url);
    }

    await logChannel.send({ embeds: [embed] }).catch(() => null);

    await interaction.reply({ embeds: [successEmbed(settings, 'This message has been reported to the moderation team.')], ephemeral: true });
  },
};
