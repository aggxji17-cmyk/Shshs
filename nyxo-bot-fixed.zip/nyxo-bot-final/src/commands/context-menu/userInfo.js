const { ContextMenuCommandBuilder, ApplicationCommandType } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { baseEmbed } = require('../../utils/embeds');
const { isModerator } = require('../../utils/permissions');
const { getUserStats } = require('../../services/auditService');

/**
 * User context-menu command ("Apps" menu on right-click / long-press a
 * member). Mirrors /userinfo's card but with no options - context menu
 * commands can't take arguments - so moderators always see the
 * all-time punishment record here instead of a chosen range/sort.
 */
module.exports = {
  data: new ContextMenuCommandBuilder()
    .setName('معلومات المستخدم')
    .setNameLocalizations({ ar: 'معلومات المستخدم', 'en-US': 'User Info' })
    .setType(ApplicationCommandType.User),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    const user = interaction.targetUser;
    const member = interaction.targetMember || (await interaction.guild.members.fetch(user.id).catch(() => null));

    const embed = baseEmbed(settings)
      .setTitle(user.tag)
      .setThumbnail(user.displayAvatarURL())
      .addFields(
        { name: 'ID', value: user.id, inline: true },
        { name: 'Account Created', value: `<t:${Math.floor(user.createdTimestamp / 1000)}:D>`, inline: true }
      );

    if (member) {
      embed.addFields(
        { name: 'Joined Server', value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:D>`, inline: true },
        {
          name: 'Roles',
          value: member.roles.cache.filter((r) => r.id !== interaction.guild.id).map((r) => r.toString()).join(', ') || 'None',
        }
      );
    }

    if (isModerator(interaction.member, guildConfig)) {
      const { stats, total } = await getUserStats(interaction.guildId, user.id, 'all');
      embed.addFields({
        name: 'سجل العقوبات',
        value: `🔨 ${stats.ban} • 👢 ${stats.kick} • ⏱️ ${stats.timeout} • ⚠️ ${stats.warn} • 🧹 ${stats.softban} • ♻️ ${stats.unban} — الإجمالي: ${total}`,
      });
    }

    await interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
