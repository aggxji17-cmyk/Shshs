const { ContextMenuCommandBuilder, ApplicationCommandType, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { isModerator } = require('../../utils/permissions');

/**
 * Message context-menu command ("Apps" menu on right-click / long-press a
 * message) that deletes a single message in one step, without needing
 * /purge's amount option. Staff-only, same gate as /purge.
 */
module.exports = {
  data: new ContextMenuCommandBuilder()
    .setName('حذف الرسالة')
    .setNameLocalizations({ ar: 'حذف الرسالة', 'en-US': 'Delete Message' })
    .setType(ApplicationCommandType.Message)
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isModerator(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You do not have permission to use this command.')], ephemeral: true });
    }

    const message = interaction.targetMessage;

    if (!message.deletable) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'This message can no longer be deleted (too old or already removed).')], ephemeral: true });
    }

    await message.delete().catch(() => null);

    await interaction.reply({ embeds: [successEmbed(settings, `Message from **${message.author.tag}** has been deleted.`)], ephemeral: true });
  },
};
