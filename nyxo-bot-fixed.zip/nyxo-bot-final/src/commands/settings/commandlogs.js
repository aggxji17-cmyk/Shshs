const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { getGuildConfig, resolved, invalidateGuildConfig } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed, infoEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');
const CommandLog = require('../../database/models/CommandLog');

const RECENT_LIMIT = 15;

module.exports = {
  data: new SlashCommandBuilder()
    .setName('commandlogs')
    .setDescription('Configure the command-usage log channel, or view recent command usage')
    .setDescriptionLocalizations({ ar: 'إعداد قناة سجل استخدام الأوامر أو عرض آخر الاستخدامات', 'en-US': 'Configure the command-usage log channel, or view recent command usage' })
    .addSubcommand((s) =>
      s
        .setName('channel')
        .setDescription('Send a live log of every command used to a channel')
        .setDescriptionLocalizations({ ar: 'إرسال سجل مباشر لكل أمر يُستخدم إلى قناة', 'en-US': 'Send a live log of every command used to a channel' })
        .addChannelOption((o) =>
          o
            .setName('channel')
            .setDescription('Channel to send usage logs to')
            .setDescriptionLocalizations({ ar: 'القناة التي تُرسل إليها سجلات الاستخدام', 'en-US': 'Channel to send usage logs to' })
            .addChannelTypes(ChannelType.GuildText)
            .setRequired(true)
        )
    )
    .addSubcommand((s) =>
      s
        .setName('disable')
        .setDescription('Stop sending the live command-usage log to a channel')
        .setDescriptionLocalizations({ ar: 'إيقاف إرسال سجل استخدام الأوامر المباشر إلى القناة', 'en-US': 'Stop sending the live command-usage log to a channel' })
    )
    .addSubcommand((s) =>
      s
        .setName('recent')
        .setDescription(`Show the last ${RECENT_LIMIT} commands used in this server`)
        .setDescriptionLocalizations({ ar: `عرض آخر ${RECENT_LIMIT} أمر تم استخدامه في هذا السيرفر`, 'en-US': `Show the last ${RECENT_LIMIT} commands used in this server` })
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You need to be a guild manager to use this command.')], ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();

    if (sub === 'channel') {
      const channel = interaction.options.getChannel('channel');
      guildConfig.commandLogging.channelId = channel.id;
      guildConfig.commandLogging.enabled = true;
      await guildConfig.save();
      invalidateGuildConfig(interaction.guildId);
      return interaction.reply({ embeds: [successEmbed(settings, `Every command used in this server will now also be logged live to ${channel}.`)] });
    }

    if (sub === 'disable') {
      if (!guildConfig.commandLogging.enabled) {
        return interaction.reply({ embeds: [errorEmbed(settings, 'The command-usage log channel is not currently enabled.')], ephemeral: true });
      }
      guildConfig.commandLogging.enabled = false;
      await guildConfig.save();
      invalidateGuildConfig(interaction.guildId);
      return interaction.reply({ embeds: [successEmbed(settings, 'The live command-usage log channel has been disabled (usage is still recorded for `/commandlogs recent`).')] });
    }

    // sub === 'recent': every command usage is always recorded regardless
    // of the live channel above, so this works even when that's off.
    const entries = await CommandLog.find({ guildId: interaction.guildId }).sort({ createdAt: -1 }).limit(RECENT_LIMIT);

    if (!entries.length) {
      return interaction.reply({ embeds: [infoEmbed(settings, 'No command usage has been recorded in this server yet.')], ephemeral: true });
    }

    const lines = entries.map((e) => `<t:${Math.floor(e.createdAt.getTime() / 1000)}:R> - <@${e.userId}> used \`/${e.commandName}\`${e.channelId ? ` in <#${e.channelId}>` : ''}`);

    return interaction.reply({
      embeds: [infoEmbed(settings, `Last ${entries.length} command${entries.length === 1 ? '' : 's'} used in this server`).addFields({ name: '\u200b', value: lines.join('\n') })],
      ephemeral: true,
    });
  },
};
