const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed, baseEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');
const announcementService = require('../../services/announcementService');

const DAY_NAMES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const TIME_REGEX = /^([01]\d|2[0-3]):([0-5]\d)$/;

module.exports = {
  data: new SlashCommandBuilder()
    .setName('announcement')
    .setDescription('Schedule a recurring or one-off announcement in a channel')
    .setDescriptionLocalizations({ ar: 'جدولة إعلان متكرر أو لمرة واحدة في قناة', 'en-US': 'Schedule a recurring or one-off announcement in a channel' })
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((s) =>
      s
        .setName('create')
        .setDescription('Create a new scheduled announcement')
        .setDescriptionLocalizations({ ar: 'إنشاء إعلان مجدول جديد', 'en-US': 'Create a new scheduled announcement' })
        .addChannelOption((o) => o.setName('channel').setDescription('Channel to post in').setDescriptionLocalizations({ ar: 'القناة التي سيُنشر فيها', 'en-US': 'Channel to post in' }).setRequired(true).addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement))
        .addStringOption((o) => o.setName('content').setDescription('The announcement text').setDescriptionLocalizations({ ar: 'نص الإعلان', 'en-US': 'The announcement text' }).setRequired(true).setMaxLength(2000))
        .addStringOption((o) =>
          o
            .setName('recurrence')
            .setDescription('How often to repeat')
            .setDescriptionLocalizations({ ar: 'مدى التكرار', 'en-US': 'How often to repeat' })
            .setRequired(true)
            .addChoices(
              { name: 'Once (in a set number of minutes)', value: 'once' },
              { name: 'Every day at a set time (UTC)', value: 'daily' },
              { name: 'Every week on a set day/time (UTC)', value: 'weekly' },
              { name: 'Every N minutes', value: 'interval' }
            )
        )
        .addIntegerOption((o) => o.setName('minutes').setDescription('For "once": minutes from now. For "interval": minutes between runs.').setDescriptionLocalizations({ ar: 'لخيار "لمرة واحدة": الدقائق من الآن. لخيار "بفاصل زمني": الدقائق بين كل تكرار.', 'en-US': 'For "once": minutes from now. For "interval": minutes between runs.' }).setMinValue(1).setMaxValue(527_040))
        .addStringOption((o) => o.setName('time').setDescription('For "daily"/"weekly": time of day in 24h UTC, e.g. 14:30').setDescriptionLocalizations({ ar: 'لخيار "يومي"/"أسبوعي": وقت اليوم بتنسيق 24 ساعة UTC، مثل 14:30', 'en-US': 'For "daily"/"weekly": time of day in 24h UTC, e.g. 14:30' }))
        .addIntegerOption((o) =>
          o
            .setName('day')
            .setDescription('For "weekly": day of the week (UTC)')
            .setDescriptionLocalizations({ ar: 'لخيار "أسبوعي": يوم الأسبوع (UTC)', 'en-US': 'For "weekly": day of the week (UTC)' })
            .addChoices(...DAY_NAMES.map((name, value) => ({ name, value })))
        )
    )
    .addSubcommand((s) =>
      s
        .setName('list')
        .setDescription('List this server\'s scheduled announcements')
        .setDescriptionLocalizations({ ar: 'عرض الإعلانات المجدولة لهذا السيرفر', 'en-US': "List this server's scheduled announcements" })
    )
    .addSubcommand((s) =>
      s
        .setName('cancel')
        .setDescription('Cancel a scheduled announcement')
        .setDescriptionLocalizations({ ar: 'إلغاء إعلان مجدول', 'en-US': 'Cancel a scheduled announcement' })
        .addStringOption((o) => o.setName('id').setDescription('Announcement ID from /announcement list').setDescriptionLocalizations({ ar: 'معرّف الإعلان من /announcement list', 'en-US': 'Announcement ID from /announcement list' }).setRequired(true))
    ),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You do not have permission to use this command.')], ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();

    if (sub === 'create') {
      const channel = interaction.options.getChannel('channel');
      const content = interaction.options.getString('content');
      const recurrence = interaction.options.getString('recurrence');
      const minutes = interaction.options.getInteger('minutes');
      const time = interaction.options.getString('time');
      const day = interaction.options.getInteger('day');

      if ((recurrence === 'once' || recurrence === 'interval') && !minutes) {
        return interaction.reply({ embeds: [errorEmbed(settings, 'Provide `minutes` for the "once"/"interval" recurrence types.')], ephemeral: true });
      }
      if ((recurrence === 'daily' || recurrence === 'weekly') && (!time || !TIME_REGEX.test(time))) {
        return interaction.reply({ embeds: [errorEmbed(settings, 'Provide a valid `time` in 24h UTC format (HH:MM), e.g. `14:30`.')], ephemeral: true });
      }
      if (recurrence === 'weekly' && day === null) {
        return interaction.reply({ embeds: [errorEmbed(settings, 'Provide a `day` of the week for the "weekly" recurrence.')], ephemeral: true });
      }

      const doc = await announcementService.createAnnouncement({
        guildId: interaction.guildId,
        channelId: channel.id,
        createdBy: interaction.user.id,
        content,
        recurrence,
        intervalMinutes: recurrence === 'interval' ? minutes : null,
        dayOfWeek: recurrence === 'weekly' ? day : null,
        timeOfDay: recurrence === 'daily' || recurrence === 'weekly' ? time : null,
        startAt: recurrence === 'once' ? new Date(Date.now() + minutes * 60_000) : null,
      });

      return interaction.reply({
        embeds: [
          successEmbed(
            settings,
            `Announcement scheduled in ${channel} (**${recurrence}**). First run: <t:${Math.floor(doc.nextRun.getTime() / 1000)}:F>.\nAnnouncement ID: \`${doc._id}\``
          ),
        ],
        ephemeral: true,
      });
    }

    if (sub === 'list') {
      const items = await announcementService.listAnnouncements(interaction.guildId);
      if (!items.length) {
        return interaction.reply({ embeds: [errorEmbed(settings, 'No scheduled announcements in this server.')], ephemeral: true });
      }

      const embed = baseEmbed(settings)
        .setTitle('Scheduled Announcements')
        .setDescription(
          items
            .map((a) => {
              const status = a.active ? '🟢' : '🔴';
              const next = a.active ? `Next: <t:${Math.floor(a.nextRun.getTime() / 1000)}:R>` : 'Inactive';
              return `${status} **\`${a._id}\`** — <#${a.channelId}> — ${a.recurrence} — ${next}`;
            })
            .join('\n')
        );

      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    if (sub === 'cancel') {
      const id = interaction.options.getString('id');
      const doc = await announcementService.cancelAnnouncement(interaction.guildId, id);
      if (!doc) {
        return interaction.reply({ embeds: [errorEmbed(settings, 'No announcement found with that ID in this server.')], ephemeral: true });
      }
      return interaction.reply({ embeds: [successEmbed(settings, 'Announcement cancelled.')], ephemeral: true });
    }
  },
};
