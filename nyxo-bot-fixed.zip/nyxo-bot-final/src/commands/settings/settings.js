const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { baseEmbed, errorEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('settings')
    .setDescription("View this server's current bot configuration")
    .setDescriptionLocalizations({ ar: 'عرض الإعدادات الحالية للبوت في هذا السيرفر', 'en-US': 'View this server\'s current bot configuration' })
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You need Manage Server permission to use this command.')], ephemeral: true });
    }

    const embed = baseEmbed(settings)
      .setTitle(`Settings for ${interaction.guild.name}`)
      .addFields(
        { name: 'Prefix', value: settings.prefix, inline: true },
        { name: 'Embed Color', value: settings.embedColor, inline: true },
        { name: 'Mod Role', value: guildConfig.modRoleId ? `<@&${guildConfig.modRoleId}>` : 'Not set', inline: true },
        { name: 'Admin Role', value: guildConfig.adminRoleId ? `<@&${guildConfig.adminRoleId}>` : 'Not set', inline: true },
        { name: 'Auto Role', value: guildConfig.autoRoleId ? `<@&${guildConfig.autoRoleId}>` : 'Not set', inline: true },
        { name: 'Welcome', value: guildConfig.welcome.enabled ? `✅ <#${guildConfig.welcome.channelId}>` : '❌', inline: true },
        { name: 'Goodbye', value: guildConfig.goodbye.enabled ? `✅ <#${guildConfig.goodbye.channelId}>` : '❌', inline: true },
        { name: 'Logging', value: guildConfig.logging.enabled ? `✅ <#${guildConfig.logging.channelId}>` : '❌', inline: true },
        { name: 'AutoMod', value: guildConfig.automod.enabled ? '✅' : '❌', inline: true },
        { name: 'Anti-Nuke', value: guildConfig.antinuke.enabled ? '✅' : '❌', inline: true },
        { name: 'Mention Protection', value: guildConfig.mentionProtection.enabled ? '✅' : '❌', inline: true },
        { name: 'Leveling', value: guildConfig.leveling.enabled ? '✅' : '❌', inline: true },
        { name: 'Tickets', value: guildConfig.tickets.enabled ? '✅' : '❌', inline: true },
        { name: 'Suggestions', value: guildConfig.suggestions.enabled ? '✅' : '❌', inline: true },
        { name: 'Minecraft Server', value: `${settings.minecraft.name} (\`${settings.minecraft.ip}:${settings.minecraft.port}\`)` }
      )
      .setFooter({ text: 'Use the /automod, /antinuke, /mentionprotect, /ticketsetup, /suggestionsetup, /mcconfig, /setlogs, /setwelcome, /setgoodbye commands (or the web dashboard) to change these.' });

    await interaction.reply({ embeds: [embed], ephemeral: true });
  },
};
