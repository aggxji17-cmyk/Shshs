const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { getGuildConfig, resolved, invalidateGuildConfig } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setgoodbye')
    .setDescription('Configure the goodbye message for departing members')
    .setDescriptionLocalizations({ ar: 'إعداد رسالة الوداع للأعضاء المغادرين', 'en-US': 'Configure the goodbye message for departing members' })
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addChannelOption((o) => o.setName('channel').setDescription('Channel to post goodbye messages in').setDescriptionLocalizations({ ar: 'القناة التي تُنشر فيها رسائل الوداع', 'en-US': 'Channel to post goodbye messages in' }).addChannelTypes(ChannelType.GuildText).setRequired(true))
    .addStringOption((o) =>
      o
        .setName('message')
        .setDescription('Use {user}, {username}, {server}, {memberCount} as placeholders').setDescriptionLocalizations({ ar: 'استخدم {user} و {username} و {server} و {memberCount} كمتغيرات', 'en-US': 'Use {user}, {username}, {server}, {memberCount} as placeholders' })
    ),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You need Manage Server permission to use this command.')], ephemeral: true });
    }

    const channel = interaction.options.getChannel('channel');
    const message = interaction.options.getString('message');

    guildConfig.goodbye.channelId = channel.id;
    guildConfig.goodbye.enabled = true;
    if (message) guildConfig.goodbye.message = message;

    await guildConfig.save();
    invalidateGuildConfig(interaction.guildId);

    await interaction.reply({ embeds: [successEmbed(settings, `Goodbye messages will now be posted in ${channel}.`)] });
  },
};
