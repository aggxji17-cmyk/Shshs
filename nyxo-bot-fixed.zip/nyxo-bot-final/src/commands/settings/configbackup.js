const { SlashCommandBuilder, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed, infoEmbed, baseEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');
const backupService = require('../../services/backupService');

/**
 * Backs up and restores the bot's *settings* for this server (moderation,
 * AutoMod, logs, cases, tickets, leveling, economy, music, and every
 * other GuildConfig block) - not Discord channels/roles, which the
 * existing `/backup` command (commands/settings/backup.js) already
 * handles. Named `/configbackup` rather than reusing `/backup` to avoid
 * colliding with that unrelated command.
 */
module.exports = {
  data: new SlashCommandBuilder()
    .setName('configbackup')
    .setDescription("Backup and restore this server's bot settings")
    .setDescriptionLocalizations({ ar: 'نسخ واستعادة إعدادات البوت لهذا السيرفر', 'en-US': 'Backup and restore this server\'s bot settings' })
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand((s) =>
      s
        .setName('create')
        .setDescription('Save a snapshot of the current bot settings for this server')
      .setDescriptionLocalizations({ ar: 'حفظ نسخة من إعدادات البوت الحالية لهذا السيرفر', 'en-US': 'Save a snapshot of the current bot settings for this server' })
        .addStringOption((o) => o.setName('label').setDescription('Optional label for this backup').setDescriptionLocalizations({ ar: 'تسمية اختيارية لهذه النسخة الاحتياطية', 'en-US': 'Optional label for this backup' }).setMaxLength(50))
    )
    .addSubcommand((s) => s.setName('list').setDescription('List saved settings backups for this server')
      .setDescriptionLocalizations({ ar: 'عرض نسخ الإعدادات الاحتياطية المحفوظة لهذا السيرفر', 'en-US': 'List saved settings backups for this server' }))
    .addSubcommand((s) =>
      s
        .setName('delete')
        .setDescription('Delete a settings backup')
      .setDescriptionLocalizations({ ar: 'حذف نسخة احتياطية من الإعدادات', 'en-US': 'Delete a settings backup' })
        .addStringOption((o) => o.setName('id').setDescription('Backup ID from /configbackup list').setDescriptionLocalizations({ ar: 'معرّف النسخة الاحتياطية من /configbackup list', 'en-US': 'Backup ID from /configbackup list' }).setRequired(true))
    )
    .addSubcommand((s) =>
      s
        .setName('restore')
        .setDescription('Restore bot settings from a backup')
      .setDescriptionLocalizations({ ar: 'استعادة إعدادات البوت من نسخة احتياطية', 'en-US': 'Restore bot settings from a backup' })
        .addStringOption((o) => o.setName('id').setDescription('Backup ID from /configbackup list').setDescriptionLocalizations({ ar: 'معرّف النسخة الاحتياطية من /configbackup list', 'en-US': 'Backup ID from /configbackup list' }).setRequired(true))
        .addBooleanOption((o) =>
          o.setName('reset_user_data').setDescription('Also permanently wipe economy balances and XP/levels for this server (default: no)').setDescriptionLocalizations({ ar: 'أيضاً مسح أرصدة الاقتصاد ونقاط الخبرة/المستويات نهائياً لهذا السيرفر (افتراضياً: لا)', 'en-US': 'Also permanently wipe economy balances and XP/levels for this server (default: no)' })
        )
    ),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You need Administrator permission to use this command.')], ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();

    if (sub === 'create') {
      await interaction.deferReply({ ephemeral: true });
      const label = interaction.options.getString('label');

      const backup = await backupService.createBackup({
        guildId: interaction.guildId,
        guildName: interaction.guild.name,
        userId: interaction.user.id,
        label,
      });

      return interaction.editReply({
        embeds: [successEmbed(settings, `Settings backup created${label ? ` (**${label}**)` : ''}.\nID: \`${backup._id}\``)],
      });
    }

    if (sub === 'list') {
      const backups = await backupService.listBackups(interaction.guildId);
      if (!backups.length) {
        return interaction.reply({ embeds: [errorEmbed(settings, 'No settings backups saved for this server yet.')], ephemeral: true });
      }

      const embed = baseEmbed(settings)
        .setTitle('Saved Settings Backups')
        .setDescription(
          backups
            .map(
              (b) =>
                `**${b.label || 'Unnamed backup'}** - \`${b._id}\`\nCreated by <@${b.createdBy}> - <t:${Math.floor(b.createdAt.getTime() / 1000)}:R>`
            )
            .join('\n\n')
        );

      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    if (sub === 'delete') {
      const id = interaction.options.getString('id');
      const deleted = await backupService.deleteBackup(interaction.guildId, id);

      if (!deleted) {
        return interaction.reply({ embeds: [errorEmbed(settings, 'Backup not found. Check the ID with `/configbackup list`.')], ephemeral: true });
      }
      return interaction.reply({ embeds: [successEmbed(settings, 'Backup deleted.')], ephemeral: true });
    }

    if (sub === 'restore') {
      const id = interaction.options.getString('id');
      const resetUserData = interaction.options.getBoolean('reset_user_data') || false;

      const backup = await backupService.getBackup(interaction.guildId, id);
      if (!backup) {
        return interaction.reply({ embeds: [errorEmbed(settings, 'Backup not found. Check the ID with `/configbackup list`.')], ephemeral: true });
      }

      const warningLines = [
        `Server name at backup time: **${backup.guildName}**`,
        `Created: <t:${Math.floor(backup.createdAt.getTime() / 1000)}:F>`,
        'This will overwrite the current bot settings for this server with this backup.',
        resetUserData
          ? '⚠️ **reset_user_data is ON** - this will also permanently delete all economy balances and XP/levels for this server.'
          : 'Economy balances and XP/levels will **not** be touched.',
      ];

      const confirmRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('configbackup_confirm').setLabel('🔴 Restore').setStyle(ButtonStyle.Danger),
        new ButtonBuilder().setCustomId('configbackup_cancel').setLabel('⚪ Cancel').setStyle(ButtonStyle.Secondary)
      );

      const confirmMessage = await interaction.reply({
        embeds: [infoEmbed(settings, warningLines.join('\n'))],
        components: [confirmRow],
        ephemeral: true,
        fetchReply: true,
      });

      let confirmation;
      try {
        confirmation = await confirmMessage.awaitMessageComponent({
          componentType: ComponentType.Button,
          filter: (i) => i.user.id === interaction.user.id,
          time: 30_000,
        });
      } catch {
        return interaction.editReply({ embeds: [errorEmbed(settings, 'Restore confirmation timed out. No changes were made.')], components: [] });
      }

      if (confirmation.customId === 'configbackup_cancel') {
        return confirmation.update({ embeds: [errorEmbed(settings, 'Restore cancelled. No changes were made.')], components: [] });
      }

      await confirmation.deferUpdate();

      try {
        const { usersReset } = await backupService.restoreBackup({ guildId: interaction.guildId, backupId: id, resetUserData });

        const resultLines = [`Settings restored from backup \`${id}\`.`];
        if (resetUserData) resultLines.push(`Also wiped ${usersReset} user data record(s) (economy + leveling).`);

        return interaction.editReply({ embeds: [successEmbed(settings, resultLines.join('\n'))], components: [] });
      } catch (err) {
        return interaction.editReply({ embeds: [errorEmbed(settings, `Restore failed: ${err.message}`)], components: [] });
      }
    }
  },
};
