const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved, invalidateGuildConfig } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('antiraid')
    .setDescription('Configure anti-raid protection')
    .setDescriptionLocalizations({ ar: 'إعداد الحماية من الغارات (Anti-Raid)', 'en-US': 'Configure anti-raid protection' })
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand((s) =>
      s
        .setName('config')
        .setDescription('Configure join burst detection')
      .setDescriptionLocalizations({ ar: 'إعداد كشف الانضمام الجماعي المفاجئ', 'en-US': 'Configure join burst detection' })
        .addIntegerOption((o) => o.setName('join_threshold').setDescription('Joins within the window that trigger a response').setDescriptionLocalizations({ ar: 'عدد الانضمامات خلال المدة التي تُفعّل الاستجابة', 'en-US': 'Joins within the window that trigger a response' }).setMinValue(2))
        .addIntegerOption((o) => o.setName('window_seconds').setDescription('Time window in seconds').setDescriptionLocalizations({ ar: 'المدة الزمنية بالثواني', 'en-US': 'Time window in seconds' }).setMinValue(1))
        .addStringOption((o) => o.setName('action').setDescription('Response when a raid is detected').setDescriptionLocalizations({ ar: 'الاستجابة عند اكتشاف غارة', 'en-US': 'Response when a raid is detected' }).addChoices({ name: 'Lockdown all channels', value: 'lockdown' }, { name: 'Kick new joiners', value: 'kick' }, { name: 'Ban new joiners', value: 'ban' }))
    )
    .addSubcommand((s) =>
      s
        .setName('newaccounts')
        .setDescription('Configure handling of very new accounts')
      .setDescriptionLocalizations({ ar: 'إعداد التعامل مع الحسابات الجديدة جداً', 'en-US': 'Configure handling of very new accounts' })
        .addIntegerOption((o) => o.setName('min_age_days').setDescription('Minimum account age in days').setDescriptionLocalizations({ ar: 'الحد الأدنى لعمر الحساب بالأيام', 'en-US': 'Minimum account age in days' }).setMinValue(0))
        .addStringOption((o) => o.setName('action').setDescription('Action for accounts younger than the minimum').setDescriptionLocalizations({ ar: 'الإجراء للحسابات الأصغر من الحد الأدنى', 'en-US': 'Action for accounts younger than the minimum' }).addChoices({ name: 'Do nothing', value: 'none' }, { name: 'Flag in mod log', value: 'flag' }, { name: 'Kick automatically', value: 'kick' }))
    )
    .addSubcommand((s) => s.setName('toggle').setDescription('Enable or disable anti-raid protection')
      .setDescriptionLocalizations({ ar: 'تفعيل أو تعطيل الحماية من الغارات', 'en-US': 'Enable or disable anti-raid protection' })),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You need Administrator permission to use this command.')], ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();

    if (sub === 'toggle') {
      guildConfig.antiRaid.enabled = !guildConfig.antiRaid.enabled;
      await guildConfig.save();
      invalidateGuildConfig(interaction.guildId);
      return interaction.reply({ embeds: [successEmbed(settings, `Anti-raid protection is now **${guildConfig.antiRaid.enabled ? 'enabled' : 'disabled'}**.`)] });
    }

    if (sub === 'newaccounts') {
      const minAge = interaction.options.getInteger('min_age_days');
      const action = interaction.options.getString('action');
      if (minAge !== null) guildConfig.antiRaid.newAccountAgeDays = minAge;
      if (action) guildConfig.antiRaid.newAccountAction = action;
      await guildConfig.save();
      invalidateGuildConfig(interaction.guildId);
      return interaction.reply({ embeds: [successEmbed(settings, 'New-account handling updated.')] });
    }

    const joinThreshold = interaction.options.getInteger('join_threshold');
    const windowSeconds = interaction.options.getInteger('window_seconds');
    const action = interaction.options.getString('action');

    if (joinThreshold) guildConfig.antiRaid.joinThreshold = joinThreshold;
    if (windowSeconds) guildConfig.antiRaid.windowMs = windowSeconds * 1000;
    if (action) guildConfig.antiRaid.action = action;

    await guildConfig.save();
    invalidateGuildConfig(interaction.guildId);
    return interaction.reply({ embeds: [successEmbed(settings, 'Anti-raid configuration updated.')] });
  },
};
