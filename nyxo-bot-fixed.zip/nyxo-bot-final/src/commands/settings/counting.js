const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved, invalidateGuildConfig } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('counting')
    .setDescription('Configure the counting game')
    .setDescriptionLocalizations({ ar: 'إعداد لعبة العد', 'en-US': 'Configure the counting game' })
    .addSubcommand((sc) => sc.setName('enable').setDescription('Enable counting in a channel')
      .setDescriptionLocalizations({ ar: 'تفعيل لعبة العد في قناة', 'en-US': 'Enable counting in a channel' }).addChannelOption((o) => o.setName('channel').setDescription('Counting channel').setDescriptionLocalizations({ ar: 'قناة لعبة العد', 'en-US': 'Counting channel' }).setRequired(true)))
    .addSubcommand((sc) => sc.setName('disable').setDescription('Disable the counting game')
      .setDescriptionLocalizations({ ar: 'تعطيل لعبة العد', 'en-US': 'Disable the counting game' }))
    .addSubcommand((sc) => sc.setName('reset').setDescription('Reset the count back to 0')
      .setDescriptionLocalizations({ ar: 'إعادة تعيين العدّاد إلى 0', 'en-US': 'Reset the count back to 0' }))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You need to be a guild manager to configure counting.')], ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();

    if (sub === 'enable') {
      const channel = interaction.options.getChannel('channel');
      guildConfig.counting.enabled = true;
      guildConfig.counting.channelId = channel.id;
      guildConfig.counting.currentCount = 0;
      guildConfig.counting.lastUserId = null;
      await guildConfig.save();
      invalidateGuildConfig(interaction.guildId);
      return interaction.reply({ embeds: [successEmbed(settings, `Counting game enabled in ${channel}. The next number is **1**.`)] });
    }

    if (sub === 'disable') {
      guildConfig.counting.enabled = false;
      await guildConfig.save();
      invalidateGuildConfig(interaction.guildId);
      return interaction.reply({ embeds: [successEmbed(settings, 'Counting game disabled.')] });
    }

    guildConfig.counting.currentCount = 0;
    guildConfig.counting.lastUserId = null;
    await guildConfig.save();
    invalidateGuildConfig(interaction.guildId);
    return interaction.reply({ embeds: [successEmbed(settings, 'Count reset to 0. The next number is **1**.')] });
  },
};
