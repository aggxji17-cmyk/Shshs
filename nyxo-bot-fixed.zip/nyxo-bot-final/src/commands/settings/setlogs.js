const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { getGuildConfig, resolved, invalidateGuildConfig } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setlogs')
    .setDescription('Configure the moderation/audit logging channel')
    .setDescriptionLocalizations({ ar: 'إعداد قناة سجلات الإشراف والتدقيق', 'en-US': 'Configure the moderation/audit logging channel' })
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addChannelOption((o) => o.setName('channel').setDescription('Channel to send logs to').setDescriptionLocalizations({ ar: 'القناة التي تُرسل إليها السجلات', 'en-US': 'Channel to send logs to' }).addChannelTypes(ChannelType.GuildText).setRequired(true)),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You need Manage Server permission to use this command.')], ephemeral: true });
    }

    const channel = interaction.options.getChannel('channel');
    guildConfig.logging.channelId = channel.id;
    guildConfig.logging.enabled = true;
    await guildConfig.save();
    invalidateGuildConfig(interaction.guildId);

    await interaction.reply({ embeds: [successEmbed(settings, `Logs will now be sent to ${channel}.`)] });
  },
};
