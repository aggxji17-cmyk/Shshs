const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved, invalidateGuildConfig } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');

const HEX_REGEX = /^#([0-9A-F]{6})$/i;

module.exports = {
  data: new SlashCommandBuilder()
    .setName('branding')
    .setDescription("Customize the bot's embed color, footer, prefix, and staff roles for this server")
    .setDescriptionLocalizations({ ar: 'تخصيص لون البوت والتذييل والبادئة ورتب الإدارة لهذا السيرفر', 'en-US': 'Customize the bot\'s embed color, footer, prefix, and staff roles for this server' })
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addStringOption((o) => o.setName('color').setDescription('Hex color, e.g. #5865F2').setDescriptionLocalizations({ ar: 'لون Hex، مثل #5865F2', 'en-US': 'Hex color, e.g. #5865F2' }))
    .addStringOption((o) => o.setName('footer').setDescription('Embed footer text').setDescriptionLocalizations({ ar: 'نص تذييل الـ embed', 'en-US': 'Embed footer text' }))
    .addStringOption((o) => o.setName('prefix').setDescription('Legacy text command prefix').setDescriptionLocalizations({ ar: 'بادئة الأوامر النصية القديمة', 'en-US': 'Legacy text command prefix' }))
    .addRoleOption((o) => o.setName('mod_role').setDescription('Role treated as moderator staff').setDescriptionLocalizations({ ar: 'الرتبة المعتبرة طاقم إشراف', 'en-US': 'Role treated as moderator staff' }))
    .addRoleOption((o) => o.setName('admin_role').setDescription('Role treated as server admin').setDescriptionLocalizations({ ar: 'الرتبة المعتبرة إدارة السيرفر', 'en-US': 'Role treated as server admin' })),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You need Manage Server permission to use this command.')], ephemeral: true });
    }

    const color = interaction.options.getString('color');
    const footer = interaction.options.getString('footer');
    const prefix = interaction.options.getString('prefix');
    const modRole = interaction.options.getRole('mod_role');
    const adminRole = interaction.options.getRole('admin_role');

    if (color && !HEX_REGEX.test(color)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'Color must be a valid hex code, e.g. `#5865F2`.')], ephemeral: true });
    }

    if (color) guildConfig.embedColor = color;
    if (footer) guildConfig.footer = footer;
    if (prefix) guildConfig.prefix = prefix;
    if (modRole) guildConfig.modRoleId = modRole.id;
    if (adminRole) guildConfig.adminRoleId = adminRole.id;

    await guildConfig.save();
    invalidateGuildConfig(interaction.guildId);

    await interaction.reply({ embeds: [successEmbed(settings, 'Branding & staff role settings updated.')], ephemeral: true });
  },
};
