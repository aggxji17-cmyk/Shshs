const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved, invalidateGuildConfig } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed, infoEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');
const { t, resolveLanguage, SUPPORTED_LANGUAGES } = require('../../utils/i18n');

const LANGUAGE_NAMES = { ar: 'العربية (Arabic)', en: 'English' };

module.exports = {
  data: new SlashCommandBuilder()
    .setName('language')
    .setDescription('View or set the language the bot replies in for this server')
    .setDescriptionLocalizations({
      ar: 'عرض أو تغيير اللغة التي يرد بها البوت في هذا السيرفر',
      'en-US': 'View or set the language the bot replies in for this server',
    })
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((s) =>
      s
        .setName('set')
        .setDescription('Set the reply language for this server')
        .setDescriptionLocalizations({ ar: 'ضبط لغة ردود البوت في هذا السيرفر', 'en-US': 'Set the reply language for this server' })
        .addStringOption((o) =>
          o
            .setName('language')
            .setDescription('ar, en, or auto (follow each member\'s Discord client language)')
            .setDescriptionLocalizations({
              ar: 'ar أو en أو auto (اتباع لغة تطبيق ديسكورد لكل عضو)',
              'en-US': "ar, en, or auto (follow each member's Discord client language)",
            })
            .setRequired(true)
            .addChoices({ name: 'العربية (Arabic)', value: 'ar' }, { name: 'English', value: 'en' }, { name: 'Auto', value: 'auto' })
        )
    )
    .addSubcommand((s) =>
      s.setName('view').setDescription('Show the current reply language').setDescriptionLocalizations({ ar: 'عرض لغة الردود الحالية', 'en-US': 'Show the current reply language' })
    ),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    const lang = resolveLanguage({ guildConfigDoc: guildConfig, interaction });
    const sub = interaction.options.getSubcommand();

    if (sub === 'view') {
      const label = settings.language ? LANGUAGE_NAMES[settings.language] : t(lang, 'language.auto');
      return interaction.reply({ embeds: [infoEmbed(settings, t(lang, 'language.current', { language: label }))] });
    }

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, t(lang, 'common.manager_required'))], ephemeral: true });
    }

    const choice = interaction.options.getString('language', true);
    const value = choice === 'auto' ? null : choice;

    if (value !== null && !SUPPORTED_LANGUAGES.includes(value)) {
      return interaction.reply({ embeds: [errorEmbed(settings, t(lang, 'language.invalid'))], ephemeral: true });
    }

    guildConfig.language = value;
    await guildConfig.save();
    invalidateGuildConfig(interaction.guildId);

    const newLang = resolveLanguage({ guildConfigDoc: guildConfig, interaction });
    const label = value ? LANGUAGE_NAMES[value] : t(newLang, 'language.auto');
    return interaction.reply({ embeds: [successEmbed({ ...settings, language: value }, t(newLang, 'language.set', { language: label }))] });
  },
};
