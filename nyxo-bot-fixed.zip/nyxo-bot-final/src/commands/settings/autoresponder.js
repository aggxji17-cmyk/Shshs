const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed, infoEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');
const AutoResponder = require('../../database/models/AutoResponder');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('autoresponder')
    .setDescription('Manage automatic text responses')
    .setDescriptionLocalizations({ ar: 'إدارة الردود النصية التلقائية', 'en-US': 'Manage automatic text responses' })
    .addSubcommand((sc) =>
      sc
        .setName('add')
        .setDescription('Add an auto-response')
      .setDescriptionLocalizations({ ar: 'إضافة رد تلقائي', 'en-US': 'Add an auto-response' })
        .addStringOption((o) => o.setName('trigger').setDescription('Text that triggers the response').setDescriptionLocalizations({ ar: 'النص الذي يُفعّل الرد', 'en-US': 'Text that triggers the response' }).setRequired(true).setMaxLength(100))
        .addStringOption((o) => o.setName('response').setDescription('The bot\'s response').setDescriptionLocalizations({ ar: 'رد البوت', 'en-US': 'The bot\'s response' }).setRequired(true).setMaxLength(1500))
        .addStringOption((o) => o.setName('match_type').setDescription('How the trigger should match').setDescriptionLocalizations({ ar: 'طريقة مطابقة الكلمة المحفّزة', 'en-US': 'How the trigger should match' }).addChoices({ name: 'Contains', value: 'contains' }, { name: 'Exact message', value: 'exact' }))
    )
    .addSubcommand((sc) => sc.setName('remove').setDescription('Remove an auto-response')
      .setDescriptionLocalizations({ ar: 'إزالة رد تلقائي', 'en-US': 'Remove an auto-response' }).addStringOption((o) => o.setName('trigger').setDescription('Trigger to remove').setDescriptionLocalizations({ ar: 'الكلمة المحفّزة المراد إزالتها', 'en-US': 'Trigger to remove' }).setRequired(true)))
    .addSubcommand((sc) => sc.setName('list').setDescription('List all auto-responses')
      .setDescriptionLocalizations({ ar: 'عرض جميع الردود التلقائية', 'en-US': 'List all auto-responses' }))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You need to be a guild manager to manage auto-responses.')], ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();

    if (sub === 'list') {
      const all = await AutoResponder.find({ guildId: interaction.guildId });
      return interaction.reply({
        embeds: [infoEmbed(settings, all.length ? all.map((a) => `**${a.trigger}** (${a.matchType}) → ${a.response.slice(0, 80)}`).join('\n') : 'No auto-responses configured.')],
        ephemeral: true,
      });
    }

    if (sub === 'remove') {
      const trigger = interaction.options.getString('trigger').toLowerCase();
      const removed = await AutoResponder.findOneAndDelete({ guildId: interaction.guildId, trigger });
      return interaction.reply({ embeds: [removed ? successEmbed(settings, `Removed auto-response for **${trigger}**.`) : errorEmbed(settings, 'No auto-response found with that trigger.')], ephemeral: true });
    }

    const trigger = interaction.options.getString('trigger').toLowerCase();
    const response = interaction.options.getString('response');
    const matchType = interaction.options.getString('match_type') || 'contains';

    await AutoResponder.findOneAndUpdate(
      { guildId: interaction.guildId, trigger },
      { response, matchType, createdBy: interaction.user.id },
      { upsert: true }
    );

    await interaction.reply({ embeds: [successEmbed(settings, `Auto-response set: **${trigger}** → "${response.slice(0, 80)}"`)], ephemeral: true });
  },
};
