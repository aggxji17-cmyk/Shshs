const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed, baseEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');
const Backup = require('../../database/models/Backup');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('backup')
    .setDescription('Create or restore a snapshot of channels and roles')
    .setDescriptionLocalizations({ ar: 'إنشاء أو استعادة نسخة احتياطية من القنوات والرتب', 'en-US': 'Create or restore a snapshot of channels and roles' })
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand((s) =>
      s
        .setName('create')
        .setDescription('Save a snapshot of the current channels and roles')
      .setDescriptionLocalizations({ ar: 'حفظ نسخة من القنوات والرتب الحالية', 'en-US': 'Save a snapshot of the current channels and roles' })
        .addStringOption((o) => o.setName('name').setDescription('Label for this backup').setDescriptionLocalizations({ ar: 'تسمية هذه النسخة الاحتياطية', 'en-US': 'Label for this backup' }))
    )
    .addSubcommand((s) => s.setName('list').setDescription('List saved backups for this server')
      .setDescriptionLocalizations({ ar: 'عرض النسخ الاحتياطية المحفوظة لهذا السيرفر', 'en-US': 'List saved backups for this server' }))
    .addSubcommand((s) =>
      s
        .setName('restore')
        .setDescription('Restore roles and channels from a backup (recreates missing ones)')
      .setDescriptionLocalizations({ ar: 'استعادة الرتب والقنوات من نسخة احتياطية (يعيد إنشاء المفقود منها)', 'en-US': 'Restore roles and channels from a backup (recreates missing ones)' })
        .addStringOption((o) => o.setName('id').setDescription('Backup ID from /backup list').setDescriptionLocalizations({ ar: 'معرّف النسخة الاحتياطية من /backup list', 'en-US': 'Backup ID from /backup list' }).setRequired(true))
    ),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You need Administrator permission to use this command.')], ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();

    if (sub === 'create') {
      await interaction.deferReply({ ephemeral: true });
      const guild = interaction.guild;

      const roles = guild.roles.cache
        .filter((r) => r.id !== guild.id && !r.managed)
        .map((r) => ({
          name: r.name,
          color: r.color,
          hoist: r.hoist,
          mentionable: r.mentionable,
          permissions: r.permissions.bitfield.toString(),
          position: r.position,
        }));

      const channels = guild.channels.cache
        .filter((c) => c.type === ChannelType.GuildText || c.type === ChannelType.GuildCategory || c.type === ChannelType.GuildVoice)
        .map((c) => ({
          name: c.name,
          type: c.type,
          topic: c.topic || '',
          parentName: c.parent?.name || null,
          position: c.position,
        }));

      const backup = await Backup.create({
        guildId: interaction.guildId,
        createdBy: interaction.user.id,
        name: interaction.options.getString('name') || `backup-${Date.now()}`,
        data: { name: guild.name, roles, channels },
      });

      return interaction.editReply({
        embeds: [successEmbed(settings, `Backup **${backup.name}** created with ${roles.length} roles and ${channels.length} channels.\nID: \`${backup._id}\``)],
      });
    }

    if (sub === 'list') {
      const backups = await Backup.find({ guildId: interaction.guildId }).sort({ createdAt: -1 }).limit(10);
      if (!backups.length) {
        return interaction.reply({ embeds: [errorEmbed(settings, 'No backups saved for this server yet.')], ephemeral: true });
      }
      const embed = baseEmbed(settings)
        .setTitle('Saved Backups')
        .setDescription(
          backups
            .map((b) => `**${b.name}** - \`${b._id}\` - <t:${Math.floor(b.createdAt.getTime() / 1000)}:R>`)
            .join('\n')
        );
      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    if (sub === 'restore') {
      await interaction.deferReply({ ephemeral: true });
      const backup = await Backup.findOne({ _id: interaction.options.getString('id'), guildId: interaction.guildId }).catch(() => null);

      if (!backup) {
        return interaction.editReply({ embeds: [errorEmbed(settings, 'Backup not found. Check the ID with `/backup list`.')] });
      }

      const guild = interaction.guild;
      const existingRoleNames = new Set(guild.roles.cache.map((r) => r.name));
      const existingChannelNames = new Set(guild.channels.cache.map((c) => c.name));

      let rolesCreated = 0;
      for (const roleData of backup.data.roles) {
        if (existingRoleNames.has(roleData.name)) continue;
        await guild.roles
          .create({
            name: roleData.name,
            color: roleData.color,
            hoist: roleData.hoist,
            mentionable: roleData.mentionable,
            permissions: BigInt(roleData.permissions),
            reason: `Restored from backup ${backup.name}`,
          })
          .catch(() => null);
        rolesCreated += 1;
      }

      let channelsCreated = 0;
      for (const channelData of backup.data.channels) {
        if (existingChannelNames.has(channelData.name)) continue;
        const parent = channelData.parentName
          ? guild.channels.cache.find((c) => c.name === channelData.parentName && c.type === ChannelType.GuildCategory)
          : null;
        await guild.channels
          .create({
            name: channelData.name,
            type: channelData.type,
            topic: channelData.topic || undefined,
            parent: parent?.id,
            reason: `Restored from backup ${backup.name}`,
          })
          .catch(() => null);
        channelsCreated += 1;
      }

      await interaction.editReply({
        embeds: [successEmbed(settings, `Restore complete: created ${rolesCreated} missing role(s) and ${channelsCreated} missing channel(s).`)],
      });
    }
  },
};
