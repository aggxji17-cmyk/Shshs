const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');
const StickyMessage = require('../../database/models/StickyMessage');
const { repostSticky } = require('../../services/stickyService');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('sticky')
    .setDescription('Keep a message pinned to the bottom of a channel')
    .setDescriptionLocalizations({ ar: 'إبقاء رسالة ثابتة في أسفل القناة', 'en-US': 'Keep a message pinned to the bottom of a channel' })
    .addSubcommand((sc) =>
      sc
        .setName('set')
        .setDescription('Set (or replace) the sticky message for this channel')
      .setDescriptionLocalizations({ ar: 'تعيين (أو استبدال) الرسالة الثابتة لهذه القناة', 'en-US': 'Set (or replace) the sticky message for this channel' })
        .addStringOption((o) => o.setName('content').setDescription('Sticky message content').setDescriptionLocalizations({ ar: 'محتوى الرسالة الثابتة', 'en-US': 'Sticky message content' }).setRequired(true).setMaxLength(2000))
    )
    .addSubcommand((sc) => sc.setName('remove').setDescription('Remove the sticky message from this channel')
      .setDescriptionLocalizations({ ar: 'إزالة الرسالة الثابتة من هذه القناة', 'en-US': 'Remove the sticky message from this channel' }))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You need to be a guild manager to manage sticky messages.')], ephemeral: true });
    }

    if (interaction.options.getSubcommand() === 'remove') {
      const removed = await StickyMessage.findOneAndDelete({ channelId: interaction.channelId });
      if (removed?.lastMessageId) {
        const old = await interaction.channel.messages.fetch(removed.lastMessageId).catch(() => null);
        if (old) await old.delete().catch(() => null);
      }
      return interaction.reply({ embeds: [successEmbed(settings, removed ? 'Sticky message removed.' : 'This channel has no sticky message.')] });
    }

    const content = interaction.options.getString('content');
    const doc = await StickyMessage.findOneAndUpdate(
      { channelId: interaction.channelId },
      { guildId: interaction.guildId, content, createdBy: interaction.user.id },
      { upsert: true, new: true }
    );

    await interaction.reply({ embeds: [successEmbed(settings, 'Sticky message set for this channel.')] });
    await repostSticky(interaction.channel, doc, settings);
  },
};
