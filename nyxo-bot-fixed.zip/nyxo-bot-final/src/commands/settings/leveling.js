const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { getGuildConfig, resolved, invalidateGuildConfig } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('levelingconfig')
    .setDescription('Configure the XP/leveling system')
    .setDescriptionLocalizations({ ar: 'إعداد نظام نقاط الخبرة والمستويات', 'en-US': 'Configure the XP/leveling system' })
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((s) => s.setName('toggle').setDescription('Enable or disable leveling')
      .setDescriptionLocalizations({ ar: 'تفعيل أو تعطيل نظام المستويات', 'en-US': 'Enable or disable leveling' }))
    .addSubcommand((s) =>
      s
        .setName('announce')
        .setDescription('Set the channel where level-up messages are announced')
      .setDescriptionLocalizations({ ar: 'تعيين قناة إعلان ترقية المستوى', 'en-US': 'Set the channel where level-up messages are announced' })
        .addChannelOption((o) => o.setName('channel').setDescription('Announcement channel').setDescriptionLocalizations({ ar: 'قناة الإعلان', 'en-US': 'Announcement channel' }).addChannelTypes(ChannelType.GuildText).setRequired(true))
    )
    .addSubcommand((s) =>
      s
        .setName('xp')
        .setDescription('Set XP gained per message and cooldown')
      .setDescriptionLocalizations({ ar: 'تعيين نقاط الخبرة لكل رسالة ومدة التبريد', 'en-US': 'Set XP gained per message and cooldown' })
        .addIntegerOption((o) => o.setName('amount').setDescription('XP per message').setDescriptionLocalizations({ ar: 'نقاط الخبرة لكل رسالة', 'en-US': 'XP per message' }).setMinValue(1).setMaxValue(1000).setRequired(true))
        .addIntegerOption((o) => o.setName('cooldown').setDescription('Cooldown in seconds').setDescriptionLocalizations({ ar: 'مدة التبريد بالثواني', 'en-US': 'Cooldown in seconds' }).setMinValue(0).setMaxValue(3600).setRequired(true))
    ),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You need Manage Server permission to use this command.')], ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();

    if (sub === 'toggle') {
      guildConfig.leveling.enabled = !guildConfig.leveling.enabled;
      await guildConfig.save();
      invalidateGuildConfig(interaction.guildId);
      return interaction.reply({
        embeds: [successEmbed(settings, `Leveling is now **${guildConfig.leveling.enabled ? 'enabled' : 'disabled'}**.`)],
      });
    }

    if (sub === 'announce') {
      guildConfig.leveling.announceChannelId = interaction.options.getChannel('channel').id;
      await guildConfig.save();
      invalidateGuildConfig(interaction.guildId);
      return interaction.reply({ embeds: [successEmbed(settings, 'Level-up announcement channel updated.')] });
    }

    if (sub === 'xp') {
      guildConfig.leveling.xpPerMessage = interaction.options.getInteger('amount');
      guildConfig.leveling.cooldownSeconds = interaction.options.getInteger('cooldown');
      await guildConfig.save();
      invalidateGuildConfig(interaction.guildId);
      return interaction.reply({ embeds: [successEmbed(settings, 'XP settings updated.')] });
    }
  },
};
