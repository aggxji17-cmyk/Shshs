const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { getGuildConfig, resolved, invalidateGuildConfig } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('boosterannounce')
    .setDescription('Configure server boost announcements')
    .setDescriptionLocalizations({ ar: 'إعداد إعلانات تعزيز السيرفر (Boost)', 'en-US': 'Configure server boost announcements' })
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((s) =>
      s
        .setName('config')
        .setDescription('Set the announcement channel/message')
      .setDescriptionLocalizations({ ar: 'تعيين قناة ورسالة الإعلان', 'en-US': 'Set the announcement channel/message' })
        .addChannelOption((o) => o.setName('channel').setDescription('Channel to post boost announcements in').setDescriptionLocalizations({ ar: 'القناة التي تُنشر فيها إعلانات التعزيز', 'en-US': 'Channel to post boost announcements in' }).addChannelTypes(ChannelType.GuildText))
        .addStringOption((o) => o.setName('message').setDescription('Message template - {user} and {server} supported').setDescriptionLocalizations({ ar: 'قالب الرسالة - يدعم {user} و {server}', 'en-US': 'Message template - {user} and {server} supported' }).setMaxLength(500))
    )
    .addSubcommand((s) => s.setName('toggle').setDescription('Enable or disable boost announcements')
      .setDescriptionLocalizations({ ar: 'تفعيل أو تعطيل إعلانات التعزيز', 'en-US': 'Enable or disable boost announcements' })),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You need Manage Server permission to use this command.')], ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();

    if (sub === 'toggle') {
      guildConfig.boosterAnnounce.enabled = !guildConfig.boosterAnnounce.enabled;
      await guildConfig.save();
      invalidateGuildConfig(interaction.guildId);
      return interaction.reply({ embeds: [successEmbed(settings, `Boost announcements are now **${guildConfig.boosterAnnounce.enabled ? 'enabled' : 'disabled'}**.`)] });
    }

    const channel = interaction.options.getChannel('channel');
    const message = interaction.options.getString('message');

    if (channel) guildConfig.boosterAnnounce.channelId = channel.id;
    if (message) guildConfig.boosterAnnounce.message = message;

    await guildConfig.save();
    invalidateGuildConfig(interaction.guildId);
    return interaction.reply({ embeds: [successEmbed(settings, 'Boost announcement configuration updated.')] });
  },
};
