const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { isModerator } = require('../../utils/permissions');
const Giveaway = require('../../database/models/Giveaway');
const { rerollGiveaway } = require('../../services/giveawayService');
const { safeAutocomplete, fuzzyFilter } = require('../../utils/autocomplete');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('greroll')
    .setDescription('Pick new winner(s) for an ended giveaway')
    .setDescriptionLocalizations({ ar: 'اختيار فائز أو فائزين جدد لسحب منتهٍ', 'en-US': 'Pick new winner(s) for an ended giveaway' })
    .addStringOption((o) => o.setName('message_id').setDescription('The giveaway message ID').setDescriptionLocalizations({ ar: 'معرّف رسالة سحب الهدايا', 'en-US': 'The giveaway message ID' }).setRequired(true).setAutocomplete(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  // Only already-ended giveaways can be rerolled, so this only ever
  // suggests { guildId, ended: true }, most recently ended first.
  autocomplete: safeAutocomplete(async (interaction) => {
    if (!interaction.guildId) return [];
    const focused = String(interaction.options.getFocused());

    const ended = await Giveaway.find({ guildId: interaction.guildId, ended: true })
      .sort({ endsAt: -1 })
      .limit(25)
      .select('messageId prize endsAt');

    const matched = fuzzyFilter(ended, focused, { key: (g) => g.messageId });
    return matched.map((g) => ({
      name: `${g.prize} • ended ${g.endsAt.toISOString().slice(0, 16).replace('T', ' ')} • ${g.messageId}`,
      value: g.messageId,
    }));
  }),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isModerator(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You do not have permission to use this command.')], ephemeral: true });
    }

    const messageId = interaction.options.getString('message_id');
    const giveaway = await Giveaway.findOne({ guildId: interaction.guildId, messageId });

    if (!giveaway) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'No giveaway found with that message ID in this server.')], ephemeral: true });
    }
    if (!giveaway.ended) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'That giveaway has not ended yet.')], ephemeral: true });
    }

    await interaction.deferReply({ ephemeral: true });
    const winners = await rerollGiveaway(interaction.client, messageId);

    if (!winners?.length) {
      return interaction.editReply({ embeds: [errorEmbed(settings, 'There were no valid entries to reroll.')] });
    }
    await interaction.editReply({ embeds: [successEmbed(settings, `New winner(s): ${winners.map((id) => `<@${id}>`).join(', ')}`)] });
  },
};
