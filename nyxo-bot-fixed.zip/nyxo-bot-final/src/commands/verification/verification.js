const { SlashCommandBuilder, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { getGuildConfig, resolved, invalidateGuildConfig } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed, baseEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('verification')
    .setDescription('Configure member verification')
    .setDescriptionLocalizations({ ar: 'إعداد نظام التحقق من الأعضاء', 'en-US': 'Configure member verification' })
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((s) =>
      s
        .setName('config')
        .setDescription('Set the role granted on verification')
      .setDescriptionLocalizations({ ar: 'تعيين الرتبة الممنوحة عند التحقق', 'en-US': 'Set the role granted on verification' })
        .addRoleOption((o) => o.setName('role').setDescription('Role to grant once verified').setDescriptionLocalizations({ ar: 'الرتبة الممنوحة عند التحقق', 'en-US': 'Role to grant once verified' }).setRequired(true))
    )
    .addSubcommand((s) => s.setName('toggle').setDescription('Enable or disable verification')
      .setDescriptionLocalizations({ ar: 'تفعيل أو تعطيل نظام التحقق', 'en-US': 'Enable or disable verification' }))
    .addSubcommand((s) => s.setName('panel').setDescription('Post the verification panel in this channel')
      .setDescriptionLocalizations({ ar: 'نشر لوحة التحقق في هذه القناة', 'en-US': 'Post the verification panel in this channel' })),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You need Manage Server permission to use this command.')], ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();

    if (sub === 'config') {
      const role = interaction.options.getRole('role');
      if (!role.editable) {
        return interaction.reply({ embeds: [errorEmbed(settings, 'I cannot assign that role (it may be above my highest role).')], ephemeral: true });
      }
      guildConfig.verification.roleId = role.id;
      await guildConfig.save();
      invalidateGuildConfig(interaction.guildId);
      return interaction.reply({ embeds: [successEmbed(settings, `Verified members will now receive **${role.name}**.`)] });
    }

    if (sub === 'toggle') {
      guildConfig.verification.enabled = !guildConfig.verification.enabled;
      await guildConfig.save();
      invalidateGuildConfig(interaction.guildId);
      return interaction.reply({ embeds: [successEmbed(settings, `Verification is now **${guildConfig.verification.enabled ? 'enabled' : 'disabled'}**.`)] });
    }

    if (!guildConfig.verification.enabled || !guildConfig.verification.roleId) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'Configure and enable verification first (`/verification config`, `/verification toggle`).')], ephemeral: true });
    }

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('verification_verify').setLabel('Verify').setEmoji('✅').setStyle(ButtonStyle.Success)
    );

    const message = await interaction.channel.send({
      embeds: [baseEmbed(settings).setTitle('Server Verification').setDescription('Click the button below to verify yourself and gain access to the server.')],
      components: [row],
    });

    guildConfig.verification.channelId = interaction.channelId;
    guildConfig.verification.panelMessageId = message.id;
    await guildConfig.save();
    invalidateGuildConfig(interaction.guildId);

    return interaction.reply({ embeds: [successEmbed(settings, 'Verification panel posted.')], ephemeral: true });
  },
};
