const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved, invalidateGuildConfig } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed, baseEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');
const { CHECKS } = require('../../services/automodChecks');
const { AUTOMOD_PUNISHMENT_LABELS } = require('../../utils/automodConstants');

const CHECK_CHOICES = CHECKS.map((c) => ({ name: c.label, value: c.key }));
const THRESHOLD_CHECK_CHOICES = CHECKS.filter((c) => c.hasThreshold).map((c) => ({ name: c.label, value: c.key }));
const PUNISHMENT_CHOICES = Object.entries(AUTOMOD_PUNISHMENT_LABELS).map(([value, name]) => ({ name, value }));

module.exports = {
  data: new SlashCommandBuilder()
    .setName('automod')
    .setDescription('Configure the AutoMod system')
    .setDescriptionLocalizations({ ar: 'إعداد نظام الإشراف التلقائي (AutoMod)', 'en-US': 'Configure the AutoMod system' })
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((s) => s.setName('status').setDescription('View the current AutoMod status')
      .setDescriptionLocalizations({ ar: 'عرض حالة نظام AutoMod الحالية', 'en-US': 'View the current AutoMod status' }))
    .addSubcommand((s) => s.setName('toggle').setDescription('Enable or disable AutoMod or one of its protection systems')
      .setDescriptionLocalizations({ ar: 'تفعيل أو تعطيل نظام AutoMod أو أحد أنظمة الحماية', 'en-US': 'Enable or disable AutoMod or one of its protection systems' })
        .addStringOption((o) =>
          o
            .setName('check').setDescription('The system to enable/disable').setDescriptionLocalizations({ ar: 'النظام المراد تفعيله/تعطيله', 'en-US': 'The system to enable/disable' })
            .setRequired(true)
            .addChoices({ name: 'الكل (المفتاح الرئيسي)', value: 'all' }, ...CHECK_CHOICES)
        )
        .addBooleanOption((o) =>
          o.setName('state').setDescription('true to enable, false to disable - leave empty to toggle the current state').setDescriptionLocalizations({ ar: 'true لتفعيل، false لتعطيل - اتركه فارغًا لعكس الحالة الحالية', 'en-US': 'true to enable, false to disable - leave empty to toggle the current state' })
        )
    )
    .addSubcommand((s) => s.setName('punishment').setDescription('Set the punishment type for a specific protection system')
      .setDescriptionLocalizations({ ar: 'تحديد نوع العقوبة لنظام حماية معين', 'en-US': 'Set the punishment type for a specific protection system' })
        .addStringOption((o) => o.setName('check').setDescription('The system').setDescriptionLocalizations({ ar: 'النظام', 'en-US': 'The system' }).setRequired(true).addChoices(...CHECK_CHOICES))
        .addStringOption((o) =>
          o.setName('type').setDescription('Punishment type').setDescriptionLocalizations({ ar: 'نوع العقوبة', 'en-US': 'Punishment type' }).setRequired(true).addChoices(...PUNISHMENT_CHOICES)
        )
        .addIntegerOption((o) =>
          o
            .setName('timeout_minutes').setDescription('Timeout duration in minutes (only when Timeout punishment is chosen)').setDescriptionLocalizations({ ar: 'مدة الـ Timeout بالدقائق (فقط عند اختيار عقوبة Timeout)', 'en-US': 'Timeout duration in minutes (only when Timeout punishment is chosen)' })
            .setMinValue(1)
            .setMaxValue(40320)
        )
    )
    .addSubcommand((s) => s.setName('threshold').setDescription('Set the numeric threshold for a specific protection system')
      .setDescriptionLocalizations({ ar: 'تحديد القيمة الرقمية (threshold) لنظام حماية معين', 'en-US': 'Set the numeric threshold for a specific protection system' })
        .addStringOption((o) =>
          o.setName('check').setDescription('The system').setDescriptionLocalizations({ ar: 'النظام', 'en-US': 'The system' }).setRequired(true).addChoices(...THRESHOLD_CHECK_CHOICES)
        )
        .addIntegerOption((o) => o.setName('value').setDescription('The value').setDescriptionLocalizations({ ar: 'القيمة', 'en-US': 'The value' }).setRequired(true).setMinValue(1).setMaxValue(100))
    )
    .addSubcommand((s) => s.setName('whitelistrole').setDescription('Manage roles exempt from all AutoMod systems')
      .setDescriptionLocalizations({ ar: 'إدارة الرتب المستثناة من جميع أنظمة AutoMod', 'en-US': 'Manage roles exempt from all AutoMod systems' })
        .addStringOption((o) =>
          o
            .setName('action').setDescription('The action').setDescriptionLocalizations({ ar: 'الإجراء', 'en-US': 'The action' })
            .setRequired(true)
            .addChoices({ name: 'إضافة', value: 'add' }, { name: 'إزالة', value: 'remove' })
        )
        .addRoleOption((o) => o.setName('role').setDescription('The role').setDescriptionLocalizations({ ar: 'الرتبة', 'en-US': 'The role' }).setRequired(true))
    )
    .addSubcommand((s) => s.setName('whitelistchannel').setDescription('Manage channels exempt from all AutoMod systems')
      .setDescriptionLocalizations({ ar: 'إدارة القنوات المستثناة من جميع أنظمة AutoMod', 'en-US': 'Manage channels exempt from all AutoMod systems' })
        .addStringOption((o) =>
          o
            .setName('action').setDescription('The action').setDescriptionLocalizations({ ar: 'الإجراء', 'en-US': 'The action' })
            .setRequired(true)
            .addChoices({ name: 'إضافة', value: 'add' }, { name: 'إزالة', value: 'remove' })
        )
        .addChannelOption((o) => o.setName('channel').setDescription('The channel').setDescriptionLocalizations({ ar: 'القناة', 'en-US': 'The channel' }).setRequired(true))
    ),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({
        embeds: [errorEmbed(settings, 'تحتاج صلاحية Manage Server لاستخدام هذا الأمر.')],
        ephemeral: true,
      });
    }

    const sub = interaction.options.getSubcommand();
    const automod = guildConfig.automod;

    if (sub === 'status') return handleStatus(interaction, settings, automod);
    if (sub === 'toggle') return handleToggle(interaction, guildConfig, settings, automod);
    if (sub === 'punishment') return handlePunishment(interaction, guildConfig, settings, automod);
    if (sub === 'threshold') return handleThreshold(interaction, guildConfig, settings, automod);
    if (sub === 'whitelistrole') return handleWhitelistRole(interaction, guildConfig, settings, automod);
    if (sub === 'whitelistchannel') return handleWhitelistChannel(interaction, guildConfig, settings, automod);
  },
};

async function handleStatus(interaction, settings, automod) {
  const embed = baseEmbed(settings)
    .setTitle('حالة نظام AutoMod')
    .setDescription(`المفتاح الرئيسي: ${automod.enabled ? '✅ مفعل' : '❌ معطل'}`);

  for (const check of CHECKS) {
    const cfg = automod.checks[check.key];
    const lines = [
      `الحالة: ${cfg.enabled ? '✅' : '❌'}`,
      `العقوبة: ${AUTOMOD_PUNISHMENT_LABELS[cfg.punishment]}${cfg.punishment === 'timeout' ? ` (${cfg.timeoutMinutes} د)` : ''}`,
    ];
    if (check.hasThreshold) lines.push(`${check.thresholdLabel}: ${cfg.threshold}`);
    embed.addFields({ name: check.label, value: lines.join('\n'), inline: true });
  }

  embed.addFields(
    {
      name: 'الرتب المستثناة',
      value: automod.ignoredRoleIds?.length ? automod.ignoredRoleIds.map((id) => `<@&${id}>`).join(', ') : 'لا يوجد',
    },
    {
      name: 'القنوات المستثناة',
      value: automod.ignoredChannelIds?.length ? automod.ignoredChannelIds.map((id) => `<#${id}>`).join(', ') : 'لا يوجد',
    }
  );

  return interaction.reply({ embeds: [embed] });
}

async function handleToggle(interaction, guildConfig, settings, automod) {
  const check = interaction.options.getString('check');
  const state = interaction.options.getBoolean('state');

  let label;
  let nowEnabled;

  if (check === 'all') {
    automod.enabled = state === null ? !automod.enabled : state;
    label = 'AutoMod';
    nowEnabled = automod.enabled;
  } else {
    const cfg = automod.checks[check];
    cfg.enabled = state === null ? !cfg.enabled : state;
    label = CHECKS.find((c) => c.key === check).label;
    nowEnabled = cfg.enabled;
  }

  await guildConfig.save();
  invalidateGuildConfig(interaction.guildId);

  return interaction.reply({
    embeds: [successEmbed(settings, `تم ${nowEnabled ? 'تفعيل' : 'تعطيل'} **${label}**.`)],
  });
}

async function handlePunishment(interaction, guildConfig, settings, automod) {
  const check = interaction.options.getString('check');
  const type = interaction.options.getString('type');
  const timeoutMinutes = interaction.options.getInteger('timeout_minutes');

  const cfg = automod.checks[check];
  cfg.punishment = type;
  if (type === 'timeout' && timeoutMinutes) cfg.timeoutMinutes = timeoutMinutes;

  await guildConfig.save();
  invalidateGuildConfig(interaction.guildId);

  const checkLabel = CHECKS.find((c) => c.key === check).label;
  const durationNote = type === 'timeout' ? ` لمدة ${cfg.timeoutMinutes} دقيقة` : '';

  return interaction.reply({
    embeds: [successEmbed(settings, `تم تعيين عقوبة **${checkLabel}** إلى **${AUTOMOD_PUNISHMENT_LABELS[type]}**${durationNote}.`)],
  });
}

async function handleThreshold(interaction, guildConfig, settings, automod) {
  const check = interaction.options.getString('check');
  const value = interaction.options.getInteger('value');

  const definition = CHECKS.find((c) => c.key === check);
  if (!definition?.hasThreshold) {
    return interaction.reply({ embeds: [errorEmbed(settings, 'هذا النظام لا يدعم قيمة threshold.')], ephemeral: true });
  }

  automod.checks[check].threshold = value;
  await guildConfig.save();
  invalidateGuildConfig(interaction.guildId);

  return interaction.reply({
    embeds: [successEmbed(settings, `تم تعيين **${definition.thresholdLabel}** لنظام **${definition.label}** إلى **${value}**.`)],
  });
}

async function handleWhitelistRole(interaction, guildConfig, settings, automod) {
  const action = interaction.options.getString('action');
  const role = interaction.options.getRole('role');

  if (action === 'add') {
    if (!automod.ignoredRoleIds.includes(role.id)) automod.ignoredRoleIds.push(role.id);
  } else {
    automod.ignoredRoleIds = automod.ignoredRoleIds.filter((id) => id !== role.id);
  }

  await guildConfig.save();
  invalidateGuildConfig(interaction.guildId);

  const message = action === 'add' ? `تم إضافة ${role} إلى قائمة الاستثناء.` : `تم إزالة ${role} من قائمة الاستثناء.`;
  return interaction.reply({ embeds: [successEmbed(settings, message)], ephemeral: true });
}

async function handleWhitelistChannel(interaction, guildConfig, settings, automod) {
  const action = interaction.options.getString('action');
  const channel = interaction.options.getChannel('channel');

  if (action === 'add') {
    if (!automod.ignoredChannelIds.includes(channel.id)) automod.ignoredChannelIds.push(channel.id);
  } else {
    automod.ignoredChannelIds = automod.ignoredChannelIds.filter((id) => id !== channel.id);
  }

  await guildConfig.save();
  invalidateGuildConfig(interaction.guildId);

  const message = action === 'add' ? `تم إضافة ${channel} إلى قائمة الاستثناء.` : `تم إزالة ${channel} من قائمة الاستثناء.`;
  return interaction.reply({ embeds: [successEmbed(settings, message)], ephemeral: true });
}
