const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved, invalidateGuildConfig } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed, baseEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('mentionprotect')
    .setDescription('Protect specific members from being @mentioned by anyone without a bypass role')
    .setDescriptionLocalizations({
      ar: 'حماية أعضاء محددين من المنشن من قبل أي شخص لا يملك رتبة مستثناة',
      'en-US': 'Protect specific members from being @mentioned by anyone without a bypass role',
    })
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((s) =>
      s.setName('toggle').setDescription('Enable or disable mention protection')
        .setDescriptionLocalizations({ ar: 'تفعيل أو تعطيل نظام حماية المنشنات', 'en-US': 'Enable or disable mention protection' })
    )
    .addSubcommand((s) =>
      s
        .setName('protect')
        .setDescription('Add or remove a member from the protected list')
        .setDescriptionLocalizations({ ar: 'إضافة أو إزالة عضو من قائمة الحماية', 'en-US': 'Add or remove a member from the protected list' })
        .addStringOption((o) =>
          o
            .setName('action')
            .setDescription('The action')
            .setDescriptionLocalizations({ ar: 'الإجراء', 'en-US': 'The action' })
            .setRequired(true)
            .addChoices({ name: 'إضافة', value: 'add' }, { name: 'إزالة', value: 'remove' })
        )
        .addUserOption((o) => o.setName('member').setDescription('The member to protect/unprotect').setDescriptionLocalizations({ ar: 'العضو المراد حمايته/إزالة حمايته', 'en-US': 'The member to protect/unprotect' }).setRequired(true))
    )
    .addSubcommand((s) =>
      s
        .setName('bypassrole')
        .setDescription('Add or remove a role exempt from mention protection')
        .setDescriptionLocalizations({ ar: 'إضافة أو إزالة رتبة مستثناة من نظام الحماية', 'en-US': 'Add or remove a role exempt from mention protection' })
        .addStringOption((o) =>
          o
            .setName('action')
            .setDescription('The action')
            .setDescriptionLocalizations({ ar: 'الإجراء', 'en-US': 'The action' })
            .setRequired(true)
            .addChoices({ name: 'إضافة', value: 'add' }, { name: 'إزالة', value: 'remove' })
        )
        .addRoleOption((o) => o.setName('role').setDescription('The role').setDescriptionLocalizations({ ar: 'الرتبة', 'en-US': 'The role' }).setRequired(true))
    )
    .addSubcommand((s) =>
      s.setName('list').setDescription('List protected members and bypass roles')
        .setDescriptionLocalizations({ ar: 'عرض الأعضاء المحميين والرتب المستثناة', 'en-US': 'List protected members and bypass roles' })
    ),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'ليس لديك صلاحية استخدام هذا الأمر (تحتاج صلاحية إدارة السيرفر).')], ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();
    if (sub === 'toggle') return handleToggle(interaction, guildConfig, settings);
    if (sub === 'protect') return handleProtect(interaction, guildConfig, settings);
    if (sub === 'bypassrole') return handleBypassRole(interaction, guildConfig, settings);
    if (sub === 'list') return handleList(interaction, guildConfig, settings);
  },
};

async function handleToggle(interaction, guildConfig, settings) {
  guildConfig.mentionProtection.enabled = !guildConfig.mentionProtection.enabled;
  await guildConfig.save();
  invalidateGuildConfig(interaction.guildId);

  return interaction.reply({
    embeds: [successEmbed(settings, `نظام حماية المنشنات الآن **${guildConfig.mentionProtection.enabled ? 'مفعّل ✅' : 'معطّل ❌'}**.`)],
    ephemeral: true,
  });
}

async function handleProtect(interaction, guildConfig, settings) {
  const action = interaction.options.getString('action');
  const member = interaction.options.getUser('member');

  if (member.bot) {
    return interaction.reply({ embeds: [errorEmbed(settings, 'لا يمكن حماية بوت من المنشن.')], ephemeral: true });
  }

  const protectedIds = guildConfig.mentionProtection.protectedUserIds;

  if (action === 'add') {
    if (protectedIds.includes(member.id)) {
      return interaction.reply({ embeds: [errorEmbed(settings, `${member} محمي بالفعل من المنشن.`)], ephemeral: true });
    }
    protectedIds.push(member.id);
  } else {
    if (!protectedIds.includes(member.id)) {
      return interaction.reply({ embeds: [errorEmbed(settings, `${member} غير موجود في قائمة الحماية.`)], ephemeral: true });
    }
    guildConfig.mentionProtection.protectedUserIds = protectedIds.filter((id) => id !== member.id);
  }

  guildConfig.markModified('mentionProtection.protectedUserIds');
  await guildConfig.save();
  invalidateGuildConfig(interaction.guildId);

  const verb = action === 'add' ? 'تمت إضافة' : 'تمت إزالة';
  const suffix = action === 'add' ? 'إلى قائمة الحماية' : 'من قائمة الحماية';
  return interaction.reply({ embeds: [successEmbed(settings, `${verb} ${member} ${suffix}.`)], ephemeral: true });
}

async function handleBypassRole(interaction, guildConfig, settings) {
  const action = interaction.options.getString('action');
  const role = interaction.options.getRole('role');

  const bypassRoleIds = guildConfig.mentionProtection.bypassRoleIds;

  if (action === 'add') {
    if (bypassRoleIds.includes(role.id)) {
      return interaction.reply({ embeds: [errorEmbed(settings, `رتبة **${role.name}** مستثناة بالفعل.`)], ephemeral: true });
    }
    bypassRoleIds.push(role.id);
  } else {
    if (!bypassRoleIds.includes(role.id)) {
      return interaction.reply({ embeds: [errorEmbed(settings, `رتبة **${role.name}** غير موجودة في قائمة الاستثناءات.`)], ephemeral: true });
    }
    guildConfig.mentionProtection.bypassRoleIds = bypassRoleIds.filter((id) => id !== role.id);
  }

  guildConfig.markModified('mentionProtection.bypassRoleIds');
  await guildConfig.save();
  invalidateGuildConfig(interaction.guildId);

  const verb = action === 'add' ? 'تمت إضافة' : 'تمت إزالة';
  const suffix = action === 'add' ? 'إلى قائمة الاستثناءات' : 'من قائمة الاستثناءات';
  return interaction.reply({ embeds: [successEmbed(settings, `${verb} رتبة **${role.name}** ${suffix}.`)], ephemeral: true });
}

async function handleList(interaction, guildConfig, settings) {
  const { enabled, protectedUserIds, bypassRoleIds } = guildConfig.mentionProtection;

  const embed = baseEmbed(settings)
    .setTitle('🛡️ نظام حماية المنشنات')
    .addFields(
      { name: 'الحالة', value: enabled ? 'مفعّل ✅' : 'معطّل ❌', inline: false },
      {
        name: `👤 الأعضاء المحميون (${protectedUserIds.length})`,
        value: protectedUserIds.length ? protectedUserIds.map((id) => `<@${id}>`).join('\n') : 'لا يوجد',
      },
      {
        name: `🔓 الرتب المستثناة (${bypassRoleIds.length})`,
        value: bypassRoleIds.length ? bypassRoleIds.map((id) => `<@&${id}>`).join('\n') : 'لا يوجد',
      }
    );

  return interaction.reply({ embeds: [embed], ephemeral: true });
}
