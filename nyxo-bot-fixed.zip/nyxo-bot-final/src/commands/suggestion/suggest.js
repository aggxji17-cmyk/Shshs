const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed, baseEmbed } = require('../../utils/embeds');
const Suggestion = require('../../database/models/Suggestion');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('suggest')
    .setDescription('Submit a suggestion for the server')
    .setDescriptionLocalizations({ ar: 'إرسال اقتراح للسيرفر', 'en-US': 'Submit a suggestion for the server' })
    .addStringOption((o) => o.setName('idea').setDescription('Your suggestion').setDescriptionLocalizations({ ar: 'اقتراحك', 'en-US': 'Your suggestion' }).setRequired(true).setMaxLength(1000)),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!guildConfig.suggestions.enabled || !guildConfig.suggestions.channelId) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'The suggestion system is not set up in this server.')], ephemeral: true });
    }

    const channel = interaction.guild.channels.cache.get(guildConfig.suggestions.channelId);
    if (!channel) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'The configured suggestions channel no longer exists.')], ephemeral: true });
    }

    const idea = interaction.options.getString('idea');

    const embed = baseEmbed(settings)
      .setAuthor({ name: `Suggestion by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() })
      .setDescription(idea)
      .addFields({ name: '👍 Upvotes', value: '0', inline: true }, { name: '👎 Downvotes', value: '0', inline: true });

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('suggestion_upvote').setEmoji('👍').setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId('suggestion_downvote').setEmoji('👎').setStyle(ButtonStyle.Danger)
    );

    const message = await channel.send({ embeds: [embed], components: [row] });

    await Suggestion.create({
      guildId: interaction.guildId,
      messageId: message.id,
      userId: interaction.user.id,
      content: idea,
    });

    await interaction.reply({ embeds: [successEmbed(settings, `Your suggestion has been posted in ${channel}!`)], ephemeral: true });
  },
};
