const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { getGuildConfig, resolved, invalidateGuildConfig } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('suggestionsetup')
    .setDescription('Configure the suggestion system')
    .setDescriptionLocalizations({ ar: 'إعداد نظام الاقتراحات', 'en-US': 'Configure the suggestion system' })
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addChannelOption((o) => o.setName('channel').setDescription('Channel where suggestions are posted').setDescriptionLocalizations({ ar: 'القناة التي تُنشر فيها الاقتراحات', 'en-US': 'Channel where suggestions are posted' }).addChannelTypes(ChannelType.GuildText).setRequired(true)),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You need Manage Server permission to use this command.')], ephemeral: true });
    }

    const channel = interaction.options.getChannel('channel');
    guildConfig.suggestions.channelId = channel.id;
    guildConfig.suggestions.enabled = true;
    await guildConfig.save();
    invalidateGuildConfig(interaction.guildId);

    await interaction.reply({ embeds: [successEmbed(settings, `Suggestions will now be posted in ${channel}.`)] });
  },
};
