const { SlashCommandBuilder, ChannelType, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');
const { setupStatusPanel } = require('../../services/minecraftStatusPanelService');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setupstatus')
    .setDescription('Create (or recreate) the live Minecraft server status panel')
    .setDescriptionLocalizations({ ar: 'إنشاء (أو إعادة إنشاء) لوحة حالة سيرفر ماينكرافت المباشرة', 'en-US': 'Create (or recreate) the live Minecraft server status panel' })
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addChannelOption((o) =>
      o
        .setName('channel')
        .setDescription('Channel to post the status panel in (defaults to this channel)').setDescriptionLocalizations({ ar: 'القناة التي تُنشر فيها لوحة الحالة (افتراضياً هذه القناة)', 'en-US': 'Channel to post the status panel in (defaults to this channel)' })
        .addChannelTypes(ChannelType.GuildText)
    ),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({
        embeds: [errorEmbed(settings, 'You need Manage Server permission to use this command.')],
        ephemeral: true,
      });
    }

    const channel = interaction.options.getChannel('channel') || interaction.channel;

    await interaction.deferReply({ ephemeral: true });

    try {
      const message = await setupStatusPanel(channel, settings, interaction.guildId);
      await interaction.editReply({
        embeds: [
          successEmbed(
            settings,
            `Status panel created in <#${channel.id}>. It refreshes automatically every 60 seconds.\n${message.url}`
          ),
        ],
      });
    } catch (err) {
      await interaction.editReply({
        embeds: [errorEmbed(settings, `Failed to set up the status panel: ${err.message}`)],
      });
    }
  },
};
