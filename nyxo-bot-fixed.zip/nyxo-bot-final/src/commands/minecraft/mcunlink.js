const { SlashCommandBuilder } = require('discord.js');
const MinecraftLink = require('../../database/models/MinecraftLink');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('mcunlink')
    .setDescription('Unlink a Minecraft account from Discord')
    .setDescriptionLocalizations({ ar: 'فك ربط حساب ماينكرافت عن ديسكورد', 'en-US': 'Unlink a Minecraft account from Discord' })
    .addUserOption((o) =>
      o.setName('user').setDescription("Unlink another member's account instead (requires Manage Server)").setDescriptionLocalizations({ ar: 'فك ربط حساب عضو آخر بدلاً من ذلك (يتطلب صلاحية إدارة السيرفر)', 'en-US': 'Unlink another member\'s account instead (requires Manage Server)' })
    ),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    const targetUser = interaction.options.getUser('user');

    if (targetUser && targetUser.id !== interaction.user.id && !isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({
        embeds: [errorEmbed(settings, 'تحتاج صلاحية Manage Server لفك ربط حساب عضو آخر.')],
        ephemeral: true,
      });
    }

    const discordId = (targetUser || interaction.user).id;
    const link = await MinecraftLink.findOneAndDelete({ guildId: interaction.guildId, discordId });

    if (!link) {
      return interaction.reply({
        embeds: [
          errorEmbed(
            settings,
            targetUser ? 'هذا العضو لا يملك حساب Minecraft مربوط.' : 'ليس لديك حساب Minecraft مربوط حالياً.'
          ),
        ],
        ephemeral: true,
      });
    }

    return interaction.reply({
      embeds: [successEmbed(settings, `تم فك ربط الحساب **${link.minecraftUsername}** بنجاح.`)],
    });
  },
};
