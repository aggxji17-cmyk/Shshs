const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig, resolved, invalidateGuildConfig } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('mcconfig')
    .setDescription('Configure the Minecraft server shown by /ip and the "ip" auto-responder')
    .setDescriptionLocalizations({ ar: 'إعداد سيرفر ماينكرافت الذي يعرضه أمر /ip والرد التلقائي على كلمة ip', 'en-US': 'Configure the Minecraft server shown by /ip and the "ip" auto-responder' })
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addStringOption((o) => o.setName('name').setDescription('Display name for the server').setDescriptionLocalizations({ ar: 'الاسم المعروض للسيرفر', 'en-US': 'Display name for the server' }))
    .addStringOption((o) => o.setName('ip').setDescription('Server IP or hostname (used for both Java and Bedrock)').setDescriptionLocalizations({ ar: 'آيبي أو اسم مضيف السيرفر (يُستخدم لكل من Java و Bedrock)', 'en-US': 'Server IP or hostname (used for both Java and Bedrock)' }))
    .addIntegerOption((o) => o.setName('port').setDescription('Java Edition server port').setDescriptionLocalizations({ ar: 'منفذ سيرفر إصدار Java', 'en-US': 'Java Edition server port' }).setMinValue(1).setMaxValue(65535))
    .addIntegerOption((o) =>
      o.setName('bedrockport').setDescription('Bedrock Edition port (same server/IP as Java, just a different port)').setDescriptionLocalizations({ ar: 'منفذ إصدار Bedrock (نفس سيرفر/آيبي Java، فقط منفذ مختلف)', 'en-US': 'Bedrock Edition port (same server/IP as Java, just a different port)' }).setMinValue(1).setMaxValue(65535)
    )
    .addStringOption((o) =>
      o
        .setName('statsapiurl')
        .setDescription('Optional stats API base URL used by /mcprofile (rank/playtime/kills/deaths)').setDescriptionLocalizations({ ar: 'رابط API إحصائيات اختياري يستخدمه /mcprofile (الرتبة/وقت اللعب/القتلات/الوفيات)', 'en-US': 'Optional stats API base URL used by /mcprofile (rank/playtime/kills/deaths)' })
    ),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You need Manage Server permission to use this command.')], ephemeral: true });
    }

    const name = interaction.options.getString('name');
    const ip = interaction.options.getString('ip');
    const port = interaction.options.getInteger('port');
    const bedrockPort = interaction.options.getInteger('bedrockport');
    const statsApiUrl = interaction.options.getString('statsapiurl');

    if (!name && !ip && !port && !bedrockPort && !statsApiUrl) {
      return interaction.reply({
        embeds: [
          successEmbed(
            settings,
            `Current Minecraft config:\n**Name:** ${settings.minecraft.name}\n**IP:** ${settings.minecraft.ip}\n**Java Port:** ${settings.minecraft.port}\n**Bedrock Port:** ${settings.minecraft.bedrockPort}\n**Stats API URL:** ${settings.minecraft.statsApiUrl || 'not set'}`
          ),
        ],
        ephemeral: true,
      });
    }

    if (name) guildConfig.minecraft.name = name;
    if (ip) guildConfig.minecraft.ip = ip;
    if (port) guildConfig.minecraft.port = port;
    if (bedrockPort) guildConfig.minecraft.bedrockPort = bedrockPort;
    if (statsApiUrl) guildConfig.minecraft.statsApiUrl = statsApiUrl;

    await guildConfig.save();
    invalidateGuildConfig(interaction.guildId);

    await interaction.reply({ embeds: [successEmbed(settings, 'Minecraft server configuration updated.')] });
  },
};
