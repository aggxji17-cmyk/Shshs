const { SlashCommandBuilder } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { buildMinecraftStatusResponse } = require('../../services/minecraftEmbedBuilder');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ip')
    .setDescription("Show this server's Minecraft server status")
    .setDescriptionLocalizations({ ar: 'عرض حالة سيرفر ماينكرافت الخاص بهذا السيرفر', 'en-US': 'Show this server\'s Minecraft server status' }),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    await interaction.deferReply();

    const response = await buildMinecraftStatusResponse(settings);
    await interaction.editReply(response);
  },
};
