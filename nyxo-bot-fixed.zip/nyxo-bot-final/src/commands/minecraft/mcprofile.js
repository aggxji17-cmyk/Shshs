const { SlashCommandBuilder } = require('discord.js');
const MinecraftLink = require('../../database/models/MinecraftLink');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { baseEmbed, errorEmbed } = require('../../utils/embeds');
const { fetchPlayerStats } = require('../../services/minecraftStatsService');
const { listServers, getServerById, getPlayerCache, buildPresenceInfo } = require('../../services/minecraftPlayerService');
const { resolveHeadRenderUrl } = require('../../services/skinService');
const { safeAutocomplete, fuzzyFilter } = require('../../utils/autocomplete');

const NOT_AVAILABLE = 'غير متوفر';

/** Discord's own markup renders this as a live, auto-updating relative time ("منذ 3 ساعات") - no manual formatting/timezone math needed. */
function relativeTimestamp(date) {
  if (!date) return NOT_AVAILABLE;
  return `<t:${Math.floor(new Date(date).getTime() / 1000)}:R>`;
}

function formatPlaytime(cache, statsPlaytimeHours) {
  if (typeof cache?.playtimeMinutes === 'number') {
    const hours = Math.floor(cache.playtimeMinutes / 60);
    const minutes = cache.playtimeMinutes % 60;
    return `${hours}س ${minutes}د`;
  }
  if (statsPlaytimeHours != null) return `${statsPlaytimeHours} ساعة`;
  return NOT_AVAILABLE;
}

function formatRanks(cache, statsRank) {
  if (Array.isArray(cache?.ranks) && cache.ranks.length) return cache.ranks.join('، ');
  if (cache?.rank) return cache.rank;
  if (statsRank) return statsRank;
  return NOT_AVAILABLE;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('mcprofile')
    .setDescription("Show a member's linked Minecraft profile")
    .setDescriptionLocalizations({ ar: 'عرض الملف الشخصي المرتبط بحساب ماينكرافت لعضو', 'en-US': 'Show a member\'s linked Minecraft profile' })
    .addUserOption((o) => o.setName('user').setDescription("Show another member's profile instead").setDescriptionLocalizations({ ar: 'عرض ملف عضو آخر بدلاً من ذلك', 'en-US': 'Show another member\'s profile instead' }))
    .addStringOption((o) =>
      o
        .setName('server')
        .setDescription('Check this player on a specific registered server (e.g. Survival, SMP)')
        .setDescriptionLocalizations({
          ar: 'اعرض معلومات اللاعب على سيرفر معيّن (مثل Survival أو SMP)',
          'en-US': 'Check this player on a specific registered server (e.g. Survival, SMP)',
        })
        .setAutocomplete(true)
    ),

  autocomplete: safeAutocomplete(async (interaction) => {
    const focused = String(interaction.options.getFocused());
    const servers = await listServers();
    const matched = fuzzyFilter(servers, focused, { key: (s) => s.name || s._id });

    return matched.map((s) => ({
      name: `${s.name || s._id}${s.status === 'online' ? ' 🟢' : ' 🔴'}`,
      value: s._id,
    }));
  }),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    const targetUser = interaction.options.getUser('user') || interaction.user;
    const serverId = interaction.options.getString('server');

    await interaction.deferReply();

    const link = await MinecraftLink.findOne({ guildId: interaction.guildId, discordId: targetUser.id });
    if (!link) {
      return interaction.editReply({
        embeds: [
          errorEmbed(
            settings,
            targetUser.id === interaction.user.id
              ? 'ليس لديك حساب Minecraft مربوط. استخدم `/mclink` لربط حسابك أولاً.'
              : 'هذا العضو لا يملك حساب Minecraft مربوط.'
          ),
        ],
      });
    }

    let chosenServer = null;
    if (serverId) {
      chosenServer = await getServerById(serverId);
      if (!chosenServer) {
        return interaction.editReply({
          embeds: [errorEmbed(settings, 'لم يتم العثور على سيرفر بهذا الاسم. استخدم الاقتراحات الظاهرة أثناء الكتابة.')],
        });
      }
    }

    const [stats, cache] = await Promise.all([
      fetchPlayerStats(settings.minecraft.statsApiUrl, link.minecraftUuid, link.minecraftUsername).catch(
        () => ({ rank: null, playtimeHours: null, kills: null, deaths: null })
      ),
      getPlayerCache(link.minecraftUuid).catch(() => null),
    ]);

    const presence = buildPresenceInfo(cache, chosenServer?._id ?? null);

    // Status line: three distinct cases so the wording never implies more
    // than we actually know - "online here", "online elsewhere", "offline".
    let statusText;
    if (chosenServer) {
      if (presence.onlineHere) {
        statusText = `🟢 متصل الآن على **${chosenServer.name || chosenServer._id}**`;
      } else if (presence.online) {
        const elsewhere = presence.currentServerId ? ` (متصل حالياً على سيرفر آخر)` : '';
        statusText = `🔴 غير متصل على **${chosenServer.name || chosenServer._id}**${elsewhere}`;
      } else {
        statusText = '🔴 غير متصل';
      }
    } else {
      statusText = presence.online ? '🟢 متصل' : cache ? '🔴 غير متصل' : NOT_AVAILABLE;
    }

    const lastLoginText = presence.lastLogin ? relativeTimestamp(presence.lastLogin) : NOT_AVAILABLE;
    const lastLogoutText = presence.online ? '— (متصل حالياً)' : presence.lastLogout ? relativeTimestamp(presence.lastLogout) : NOT_AVAILABLE;

    const headUrl = resolveHeadRenderUrl({
      minecraftUuid: link.minecraftUuid,
      minecraftUsername: link.minecraftUsername,
      skinUrl: cache?.skinUrl ?? null,
    });

    const embed = baseEmbed(settings)
      .setTitle(`👤 ${link.minecraftUsername}`)
      .setColor(presence.online ? '#57F287' : settings.embedColor)
      .addFields(
        { name: 'اسم اللاعب', value: link.minecraftUsername, inline: true },
        { name: 'الرتب', value: formatRanks(cache, stats.rank), inline: true },
        { name: 'الحالة', value: statusText, inline: true },
        { name: 'وقت اللعب', value: formatPlaytime(cache, stats.playtimeHours), inline: true },
        { name: 'آخر دخول', value: lastLoginText, inline: true },
        { name: 'آخر خروج', value: lastLogoutText, inline: true }
      );

    if (headUrl) embed.setThumbnail(headUrl);
    if (stats.kills != null || stats.deaths != null) {
      embed.addFields(
        { name: 'عدد القتلات', value: stats.kills != null ? `${stats.kills}` : NOT_AVAILABLE, inline: true },
        { name: 'عدد الوفيات', value: stats.deaths != null ? `${stats.deaths}` : NOT_AVAILABLE, inline: true }
      );
    }

    return interaction.editReply({ embeds: [embed] });
  },
};
