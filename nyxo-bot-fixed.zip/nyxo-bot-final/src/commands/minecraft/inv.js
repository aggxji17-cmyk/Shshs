const { SlashCommandBuilder, AttachmentBuilder } = require('discord.js');
const MinecraftLink = require('../../database/models/MinecraftLink');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { baseEmbed, errorEmbed } = require('../../utils/embeds');
const { listServers, getServerById } = require('../../services/minecraftPlayerService');
const { requestInventorySnapshot, InventoryUnavailableError } = require('../../services/inventoryService');
const { renderInventoryImage, assetsReady } = require('../../services/inventoryRenderService');
const { safeAutocomplete, fuzzyFilter } = require('../../utils/autocomplete');

/**
 * /inv - shows a linked member's live Minecraft inventory (main, hotbar,
 * armor, offhand) as a pixel-accurate image, rendered from a snapshot the
 * target server reports over NovaBridge's command queue.
 *
 * ARCHITECTURE ONLY for now, per this task's scope: everything below is
 * fully wired end-to-end, but two pieces it depends on are intentionally
 * not implemented yet (see the READMEs in services/inventoryService.js
 * and services/inventoryRenderService.js):
 *   - the plugin doesn't have a "get_inventory" handler registered, so a
 *     real request will sit "pending" until it times out
 *   - the texture assets renderInventoryImage needs aren't bundled
 * Both failure paths are handled gracefully below (clear Arabic error
 * messages instead of a crash/hang), so this command is safe to deploy
 * now and will simply start working once those two pieces land.
 */
module.exports = {
  data: new SlashCommandBuilder()
    .setName('inv')
    .setDescription("Show a member's live Minecraft inventory")
    .setDescriptionLocalizations({
      ar: 'عرض إنفنتوري عضو مرتبط بحساب ماينكرافت',
      'en-US': "Show a member's live Minecraft inventory",
    })
    .addUserOption((o) =>
      o
        .setName('user')
        .setDescription("Show another member's inventory instead")
        .setDescriptionLocalizations({ ar: 'عرض إنفنتوري عضو آخر بدلاً من ذلك', 'en-US': "Show another member's inventory instead" })
    )
    .addStringOption((o) =>
      o
        .setName('server')
        .setDescription('Which registered server to check the player on')
        .setDescriptionLocalizations({
          ar: 'اختر السيرفر الذي تريد التحقق من اللاعب عليه',
          'en-US': 'Which registered server to check the player on',
        })
        .setAutocomplete(true)
        .setRequired(true)
    ),

  // Same live-registry autocomplete pattern as /mcprofile - see
  // services/minecraftPlayerService.js#listServers.
  autocomplete: safeAutocomplete(async (interaction) => {
    const focused = String(interaction.options.getFocused());
    const servers = await listServers();
    const matched = fuzzyFilter(servers, focused, { key: (s) => s.name || s._id });

    return matched.map((s) => ({
      name: `${s.name || s._id}${s.status === 'online' ? ' 🟢' : ' 🔴'}`,
      value: s._id,
    }));
  }),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    const targetUser = interaction.options.getUser('user') || interaction.user;
    const serverId = interaction.options.getString('server', true);

    await interaction.deferReply();

    const server = await getServerById(serverId);
    if (!server) {
      return interaction.editReply({
        embeds: [errorEmbed(settings, 'لم يتم العثور على سيرفر بهذا الاسم. استخدم الاقتراحات الظاهرة أثناء الكتابة.')],
      });
    }

    const link = await MinecraftLink.findOne({ guildId: interaction.guildId, discordId: targetUser.id });
    if (!link) {
      return interaction.editReply({
        embeds: [
          errorEmbed(
            settings,
            targetUser.id === interaction.user.id
              ? 'ليس لديك حساب Minecraft مربوط. استخدم `/mclink` لربط حسابك أولاً.'
              : 'هذا العضو لا يملك حساب Minecraft مربوط.'
          ),
        ],
      });
    }

    if (!assetsReady()) {
      return interaction.editReply({
        embeds: [
          errorEmbed(
            settings,
            'ميزة عرض الإنفنتوري لم يتم تفعيلها بالكامل بعد على هذا البوت (البنية جاهزة، بانتظار إكمال الإعداد). حاول لاحقاً.'
          ),
        ],
      });
    }

    let snapshot;
    try {
      snapshot = await requestInventorySnapshot(server._id, link.minecraftUuid, `discord:${interaction.user.id}`);
    } catch (err) {
      if (err instanceof InventoryUnavailableError) {
        return interaction.editReply({ embeds: [errorEmbed(settings, err.message)] });
      }
      throw err;
    }

    if (!snapshot.online) {
      return interaction.editReply({
        embeds: [errorEmbed(settings, `**${link.minecraftUsername}** غير متصل حالياً على **${server.name || server._id}**.`)],
      });
    }

    const imageBuffer = await renderInventoryImage(snapshot);
    const attachment = new AttachmentBuilder(imageBuffer, { name: 'inventory.png' });

    const embed = baseEmbed(settings)
      .setTitle(`🎒 إنفنتوري ${link.minecraftUsername}`)
      .setDescription(`السيرفر: **${server.name || server._id}**`)
      .setImage('attachment://inventory.png');

    return interaction.editReply({ embeds: [embed], files: [attachment] });
  },
};
