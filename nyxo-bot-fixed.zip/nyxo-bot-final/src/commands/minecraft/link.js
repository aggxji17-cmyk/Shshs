const { SlashCommandBuilder } = require('discord.js');
const MinecraftLink = require('../../database/models/MinecraftLink');
const { createLinkCode } = require('../../services/linkCodeService');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed, infoEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('link')
    .setDescription('Get a private code to securely link your Minecraft account')
    .setDescriptionLocalizations({
      ar: 'احصل على كود خاص لربط حسابك في ماينكرافت بأمان',
      'en-US': 'Get a private code to securely link your Minecraft account',
    }),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    const existing = await MinecraftLink.findOne({
      guildId: interaction.guildId,
      discordId: interaction.user.id,
    });
    if (existing) {
      return interaction.reply({
        embeds: [
          errorEmbed(
            settings,
            `حسابك مربوط بالفعل مع **${existing.minecraftUsername}**. استخدم \`/mcunlink\` أولاً إذا أردت ربط حساب آخر.`
          ),
        ],
        ephemeral: true,
      });
    }

    await interaction.deferReply({ ephemeral: true });

    const { code, expiresAt } = await createLinkCode(interaction.guildId, interaction.user.id);
    const minutesLeft = Math.round((expiresAt.getTime() - Date.now()) / 60000);

    try {
      await interaction.user.send({
        embeds: [
          infoEmbed(
            settings,
            [
              `كود ربط حسابك هو: **${code}**`,
              '',
              `هذا الكود صالح لمدة **${minutesLeft} دقائق** فقط، ويصبح غير صالح بعد استخدامه مرة واحدة.`,
              '',
              'ادخل إلى السيرفر واستخدم الأمر الخاص بتأكيد الربط داخل ماينكرافت مع هذا الكود لإتمام العملية.',
            ].join('\n')
          ),
        ],
      });
    } catch (err) {
      return interaction.editReply({
        embeds: [
          errorEmbed(
            settings,
            'تعذر إرسال رسالة خاصة لك. فعّل استقبال الرسائل الخاصة من أعضاء هذا السيرفر ثم أعد المحاولة.'
          ),
        ],
      });
    }

    return interaction.editReply({
      embeds: [successEmbed(settings, `تم إرسال كود الربط إلى رسائلك الخاصة ✅ (صالح لمدة ${minutesLeft} دقائق)`)],
    });
  },
};
