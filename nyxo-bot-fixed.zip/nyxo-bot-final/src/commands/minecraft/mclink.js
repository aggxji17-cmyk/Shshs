const { SlashCommandBuilder } = require('discord.js');
const MinecraftLink = require('../../database/models/MinecraftLink');
const { resolveUsername } = require('../../services/mojangService');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('mclink')
    .setDescription('Link your Minecraft Java Edition account to your Discord account')
    .setDescriptionLocalizations({ ar: 'ربط حساب ماينكرافت (جافا) بحسابك في ديسكورد', 'en-US': 'Link your Minecraft Java Edition account to your Discord account' })
    .addStringOption((o) =>
      o.setName('username').setDescription('Your Minecraft Java Edition username').setDescriptionLocalizations({ ar: 'اسم مستخدمك في ماينكرافت (إصدار Java)', 'en-US': 'Your Minecraft Java Edition username' }).setRequired(true)
    ),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);
    const username = interaction.options.getString('username', true);

    await interaction.deferReply({ ephemeral: true });

    // One Discord account can only hold one link at a time.
    const existing = await MinecraftLink.findOne({ guildId: interaction.guildId, discordId: interaction.user.id });
    if (existing) {
      return interaction.editReply({
        embeds: [
          errorEmbed(
            settings,
            `حسابك مربوط بالفعل مع **${existing.minecraftUsername}**. استخدم \`/mcunlink\` أولاً إذا أردت ربط حساب آخر.`
          ),
        ],
      });
    }

    let profile;
    try {
      profile = await resolveUsername(username);
    } catch (err) {
      return interaction.editReply({
        embeds: [errorEmbed(settings, 'تعذر الاتصال بخوادم Mojang للتحقق من اسم اللاعب. حاول مرة أخرى لاحقاً.')],
      });
    }

    if (!profile) {
      return interaction.editReply({
        embeds: [errorEmbed(settings, `لا يوجد حساب Minecraft (Java Edition) بالاسم **${username}**.`)],
      });
    }

    // One Minecraft account (by UUID, not username) can only be claimed by
    // one Discord member per guild.
    const takenBy = await MinecraftLink.findOne({ guildId: interaction.guildId, minecraftUuid: profile.uuid });
    if (takenBy) {
      return interaction.editReply({
        embeds: [errorEmbed(settings, `حساب **${profile.name}** مربوط بالفعل مع عضو آخر في هذا السيرفر.`)],
      });
    }

    try {
      await MinecraftLink.create({
        guildId: interaction.guildId,
        discordId: interaction.user.id,
        minecraftUuid: profile.uuid,
        minecraftUsername: profile.name,
        linkedBy: interaction.user.id,
      });
    } catch (err) {
      // Safety net for the rare race where two /mclink calls for the same
      // account or user slip past the checks above at nearly the same
      // time - the unique indexes on MinecraftLink reject the duplicate.
      return interaction.editReply({
        embeds: [
          errorEmbed(settings, 'حدث تعارض أثناء الربط، من المحتمل أن الحساب رُبط للتو من جهة أخرى. حاول مرة أخرى.'),
        ],
      });
    }

    return interaction.editReply({
      embeds: [successEmbed(settings, `تم ربط حسابك بنجاح مع **${profile.name}** ✅`)],
    });
  },
};
