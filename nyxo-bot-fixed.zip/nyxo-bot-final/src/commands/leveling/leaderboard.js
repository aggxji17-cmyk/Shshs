const { SlashCommandBuilder } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { baseEmbed, errorEmbed } = require('../../utils/embeds');
const { getLeaderboard } = require('../../services/levelingService');

module.exports = {
  data: new SlashCommandBuilder().setName('leaderboard').setDescription('View the server XP leaderboard')
    .setDescriptionLocalizations({ ar: 'عرض قائمة متصدري نقاط الخبرة في السيرفر', 'en-US': 'View the server XP leaderboard' }),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!guildConfig.leveling.enabled) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'The leveling system is disabled in this server.')], ephemeral: true });
    }

    const top = await getLeaderboard(interaction.guildId, 10);
    if (!top.length) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'No one has earned XP yet.')] });
    }

    const medals = ['🥇', '🥈', '🥉'];
    const description = top
      .map((doc, i) => `${medals[i] || `**${i + 1}.**`} <@${doc.userId}> - Level ${doc.level} (${doc.xp} XP)`)
      .join('\n');

    await interaction.reply({ embeds: [baseEmbed(settings).setTitle('🏆 XP Leaderboard').setDescription(description)] });
  },
};
