const { SlashCommandBuilder } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { baseEmbed, errorEmbed } = require('../../utils/embeds');
const { getRank, xpForLevel } = require('../../services/levelingService');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('rank')
    .setDescription('View your (or another member\'s) level and XP')
    .setDescriptionLocalizations({ ar: 'عرض مستواك أو مستوى عضو آخر ونقاط خبرته', 'en-US': 'View your (or another member\'s) level and XP' })
    .addUserOption((o) => o.setName('user').setDescription('The member to check').setDescriptionLocalizations({ ar: 'العضو المراد التحقق منه', 'en-US': 'The member to check' })),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!guildConfig.leveling.enabled) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'The leveling system is disabled in this server.')], ephemeral: true });
    }

    const target = interaction.options.getUser('user') || interaction.user;
    const result = await getRank(interaction.guildId, target.id);

    if (!result) {
      return interaction.reply({ embeds: [errorEmbed(settings, `${target.tag} has not earned any XP yet.`)], ephemeral: true });
    }

    const embed = baseEmbed(settings)
      .setTitle(`${target.username}'s Rank`)
      .setThumbnail(target.displayAvatarURL())
      .addFields(
        { name: 'Rank', value: `#${result.rank}`, inline: true },
        { name: 'Level', value: `${result.doc.level}`, inline: true },
        { name: 'XP', value: `${result.doc.xp} / ${result.doc.xp + xpForLevel(result.doc.level)}`, inline: true },
        { name: 'Messages Sent', value: `${result.doc.messages}`, inline: true }
      );

    await interaction.reply({ embeds: [embed] });
  },
};
