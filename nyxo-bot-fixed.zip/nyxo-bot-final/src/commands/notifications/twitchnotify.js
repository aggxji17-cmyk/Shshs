const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed, infoEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');
const { config } = require('../../config/config');
const StreamSubscription = require('../../database/models/StreamSubscription');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('twitchnotify')
    .setDescription('Announce when a Twitch channel goes live')
    .setDescriptionLocalizations({ ar: 'الإعلان عند بدء بث قناة تويتش', 'en-US': 'Announce when a Twitch channel goes live' })
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((s) =>
      s
        .setName('add')
        .setDescription('Subscribe to a Twitch channel')
      .setDescriptionLocalizations({ ar: 'الاشتراك في قناة تويتش', 'en-US': 'Subscribe to a Twitch channel' })
        .addStringOption((o) => o.setName('twitch_channel').setDescription('Twitch login name (from the channel URL)').setDescriptionLocalizations({ ar: 'اسم الدخول في تويتش (من رابط القناة)', 'en-US': 'Twitch login name (from the channel URL)' }).setRequired(true))
        .addChannelOption((o) => o.setName('channel').setDescription('Discord channel to post announcements in').setDescriptionLocalizations({ ar: 'قناة الديسكورد التي تُنشر فيها الإعلانات', 'en-US': 'Discord channel to post announcements in' }).addChannelTypes(ChannelType.GuildText).setRequired(true))
        .addStringOption((o) => o.setName('message').setDescription('Message template - {channel} and {title} supported').setDescriptionLocalizations({ ar: 'قالب الرسالة - يدعم {channel} و {title}', 'en-US': 'Message template - {channel} and {title} supported' }))
    )
    .addSubcommand((s) => s.setName('remove').setDescription('Unsubscribe from a Twitch channel')
      .setDescriptionLocalizations({ ar: 'إلغاء الاشتراك من قناة تويتش', 'en-US': 'Unsubscribe from a Twitch channel' }).addStringOption((o) => o.setName('twitch_channel').setDescription('Twitch login name').setDescriptionLocalizations({ ar: 'اسم الدخول في تويتش', 'en-US': 'Twitch login name' }).setRequired(true)))
    .addSubcommand((s) => s.setName('list').setDescription('List all Twitch subscriptions')
      .setDescriptionLocalizations({ ar: 'عرض جميع اشتراكات تويتش', 'en-US': 'List all Twitch subscriptions' })),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You need Manage Server permission to use this command.')], ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();

    if (sub === 'list') {
      const subs = await StreamSubscription.find({ guildId: interaction.guildId, platform: 'twitch' });
      if (!subs.length) return interaction.reply({ embeds: [infoEmbed(settings, 'No Twitch subscriptions configured.')] });
      return interaction.reply({ embeds: [infoEmbed(settings, subs.map((s) => `**${s.channelIdentifier}** → <#${s.discordChannelId}>`).join('\n'))] });
    }

    if (sub === 'remove') {
      const twitchChannel = interaction.options.getString('twitch_channel').toLowerCase();
      const removed = await StreamSubscription.findOneAndDelete({ guildId: interaction.guildId, platform: 'twitch', channelIdentifier: twitchChannel });
      return interaction.reply({ embeds: [removed ? successEmbed(settings, `Unsubscribed from **${twitchChannel}**.`) : errorEmbed(settings, 'No subscription found for that channel.')] });
    }

    if (!config.twitch.clientId || !config.twitch.clientSecret) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'Twitch integration is not configured on this bot (missing API credentials).')], ephemeral: true });
    }

    const twitchChannel = interaction.options.getString('twitch_channel').toLowerCase();
    const discordChannel = interaction.options.getChannel('channel');
    const message = interaction.options.getString('message') || '{channel} is now live: {title}';

    await StreamSubscription.findOneAndUpdate(
      { guildId: interaction.guildId, platform: 'twitch', channelIdentifier: twitchChannel },
      { discordChannelId: discordChannel.id, message },
      { upsert: true }
    );

    return interaction.reply({ embeds: [successEmbed(settings, `Now watching **${twitchChannel}** - announcements will post in ${discordChannel}.`)] });
  },
};
