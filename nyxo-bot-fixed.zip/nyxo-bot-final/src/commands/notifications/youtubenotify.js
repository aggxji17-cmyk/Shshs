const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed, infoEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');
const { config } = require('../../config/config');
const StreamSubscription = require('../../database/models/StreamSubscription');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('youtubenotify')
    .setDescription('Announce when a YouTube channel uploads a new video')
    .setDescriptionLocalizations({ ar: 'الإعلان عند نشر فيديو جديد على قناة يوتيوب', 'en-US': 'Announce when a YouTube channel uploads a new video' })
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((s) =>
      s
        .setName('add')
        .setDescription('Subscribe to a YouTube channel')
      .setDescriptionLocalizations({ ar: 'الاشتراك في قناة يوتيوب', 'en-US': 'Subscribe to a YouTube channel' })
        .addStringOption((o) => o.setName('channel_id').setDescription('YouTube channel ID (starts with UC...)').setDescriptionLocalizations({ ar: 'معرّف قناة يوتيوب (يبدأ بـ UC...)', 'en-US': 'YouTube channel ID (starts with UC...)' }).setRequired(true))
        .addChannelOption((o) => o.setName('channel').setDescription('Discord channel to post announcements in').setDescriptionLocalizations({ ar: 'قناة الديسكورد التي تُنشر فيها الإعلانات', 'en-US': 'Discord channel to post announcements in' }).addChannelTypes(ChannelType.GuildText).setRequired(true))
        .addStringOption((o) => o.setName('message').setDescription('Message template - {channel} and {title} supported').setDescriptionLocalizations({ ar: 'قالب الرسالة - يدعم {channel} و {title}', 'en-US': 'Message template - {channel} and {title} supported' }))
    )
    .addSubcommand((s) => s.setName('remove').setDescription('Unsubscribe from a YouTube channel')
      .setDescriptionLocalizations({ ar: 'إلغاء الاشتراك من قناة يوتيوب', 'en-US': 'Unsubscribe from a YouTube channel' }).addStringOption((o) => o.setName('channel_id').setDescription('YouTube channel ID').setDescriptionLocalizations({ ar: 'معرّف قناة يوتيوب', 'en-US': 'YouTube channel ID' }).setRequired(true)))
    .addSubcommand((s) => s.setName('list').setDescription('List all YouTube subscriptions')
      .setDescriptionLocalizations({ ar: 'عرض جميع اشتراكات يوتيوب', 'en-US': 'List all YouTube subscriptions' })),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You need Manage Server permission to use this command.')], ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();

    if (sub === 'list') {
      const subs = await StreamSubscription.find({ guildId: interaction.guildId, platform: 'youtube' });
      if (!subs.length) return interaction.reply({ embeds: [infoEmbed(settings, 'No YouTube subscriptions configured.')] });
      return interaction.reply({ embeds: [infoEmbed(settings, subs.map((s) => `**${s.channelIdentifier}** → <#${s.discordChannelId}>`).join('\n'))] });
    }

    if (sub === 'remove') {
      const channelId = interaction.options.getString('channel_id');
      const removed = await StreamSubscription.findOneAndDelete({ guildId: interaction.guildId, platform: 'youtube', channelIdentifier: channelId });
      return interaction.reply({ embeds: [removed ? successEmbed(settings, 'Unsubscribed from that channel.') : errorEmbed(settings, 'No subscription found for that channel ID.')] });
    }

    if (!config.youtube.apiKey) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'YouTube integration is not configured on this bot (missing API key).')], ephemeral: true });
    }

    const channelId = interaction.options.getString('channel_id');
    const discordChannel = interaction.options.getChannel('channel');
    const message = interaction.options.getString('message') || '{channel} uploaded: {title}';

    await StreamSubscription.findOneAndUpdate(
      { guildId: interaction.guildId, platform: 'youtube', channelIdentifier: channelId },
      { discordChannelId: discordChannel.id, message },
      { upsert: true }
    );

    return interaction.reply({ embeds: [successEmbed(settings, `Now watching that channel - new uploads will post in ${discordChannel}.`)] });
  },
};
