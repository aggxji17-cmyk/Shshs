const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { getGuildConfig, resolved, invalidateGuildConfig } = require('../../utils/resolveGuildSettings');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { isGuildManager } = require('../../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('starboard')
    .setDescription('Configure the starboard')
    .setDescriptionLocalizations({ ar: 'إعداد لوحة النجوم (Starboard)', 'en-US': 'Configure the starboard' })
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((s) =>
      s
        .setName('config')
        .setDescription('Configure the starboard channel/threshold')
      .setDescriptionLocalizations({ ar: 'إعداد قناة وعتبة لوحة النجوم', 'en-US': 'Configure the starboard channel/threshold' })
        .addChannelOption((o) => o.setName('channel').setDescription('Channel starred messages get posted to').setDescriptionLocalizations({ ar: 'القناة التي تُنشر بها الرسائل المميّزة بنجمة', 'en-US': 'Channel starred messages get posted to' }).addChannelTypes(ChannelType.GuildText))
        .addIntegerOption((o) => o.setName('threshold').setDescription('Stars needed to post').setDescriptionLocalizations({ ar: 'عدد النجوم المطلوب للنشر', 'en-US': 'Stars needed to post' }).setMinValue(1))
        .addStringOption((o) => o.setName('emoji').setDescription('Emoji to track (default ⭐)').setDescriptionLocalizations({ ar: 'الإيموجي المراد تتبعه (افتراضياً ⭐)', 'en-US': 'Emoji to track (default ⭐)' }))
    )
    .addSubcommand((s) => s.setName('toggle').setDescription('Enable or disable the starboard')
      .setDescriptionLocalizations({ ar: 'تفعيل أو تعطيل لوحة النجوم', 'en-US': 'Enable or disable the starboard' })),

  async execute(interaction) {
    const guildConfig = await getGuildConfig(interaction.guildId);
    const settings = resolved(guildConfig);

    if (!isGuildManager(interaction.member, guildConfig)) {
      return interaction.reply({ embeds: [errorEmbed(settings, 'You need Manage Server permission to use this command.')], ephemeral: true });
    }

    const sub = interaction.options.getSubcommand();

    if (sub === 'toggle') {
      guildConfig.starboard.enabled = !guildConfig.starboard.enabled;
      await guildConfig.save();
      invalidateGuildConfig(interaction.guildId);
      return interaction.reply({ embeds: [successEmbed(settings, `Starboard is now **${guildConfig.starboard.enabled ? 'enabled' : 'disabled'}**.`)] });
    }

    const channel = interaction.options.getChannel('channel');
    const threshold = interaction.options.getInteger('threshold');
    const emoji = interaction.options.getString('emoji');

    if (channel) guildConfig.starboard.channelId = channel.id;
    if (threshold) guildConfig.starboard.threshold = threshold;
    if (emoji) guildConfig.starboard.emoji = emoji;

    await guildConfig.save();
    invalidateGuildConfig(interaction.guildId);
    return interaction.reply({ embeds: [successEmbed(settings, 'Starboard configuration updated.')] });
  },
};
