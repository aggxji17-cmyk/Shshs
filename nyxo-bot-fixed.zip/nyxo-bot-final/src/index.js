require('./legacy/compat');

const mongoose = require('mongoose');
const { Client, GatewayIntentBits, Partials } = require('discord.js');
const { config, validateConfig } = require('./config/config');
const connectDatabase = require('./database/connect');
const loadCommands = require('./handlers/commandHandler');
const loadEvents = require('./handlers/eventHandler');
const loadLegacyHandlers = require('./legacy/loadLegacyHandlers');
const { initMusicPlayer } = require('./services/musicService');
const { stopScheduler } = require('./services/scheduleService');
const { stopAnnouncementScheduler } = require('./services/announcementService');
const { stopAllAfkSessions } = require('./services/afkRewardsService');
const logger = require('./utils/logger');

let dashboardServer = null;
let shuttingDown = false;

validateConfig();

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.GuildModeration,
    GatewayIntentBits.GuildWebhooks,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildVoiceStates,
  ],
  partials: [Partials.Message, Partials.Channel, Partials.Reaction, Partials.GuildMember],
});

// Fix for MaxListenersExceededWarning - increase to 20 listeners
client.setMaxListeners(20);

// discord.js's Client is a plain Node EventEmitter under the hood, and an
// EventEmitter throws synchronously the moment an 'error' event is emitted
// with zero listeners attached - so without this, any WebSocket-layer
// error (the case discord.js's own docs call out this listener for) would
// crash out of internal library code instead of being logged like every
// other failure in this file. Reconnection itself is already automatic
// (handled internally by discord.js/ws) - these are purely visibility so a
// disconnect/resume shows up in the logs instead of going unnoticed.
client.on('error', (err) => logger.error(`Discord client error: ${err?.stack || err}`));
client.on('shardError', (err, shardId) => logger.error(`Discord shard ${shardId} error: ${err?.stack || err}`));
client.on('shardDisconnect', (event, shardId) => logger.warn(`Discord shard ${shardId} disconnected (code ${event?.code}). Reconnecting automatically...`));
client.on('shardReconnecting', (shardId) => logger.warn(`Discord shard ${shardId} reconnecting...`));
client.on('shardResume', (shardId, replayedEvents) => logger.success(`Discord shard ${shardId} resumed (${replayedEvents} events replayed).`));

async function main() {
  await connectDatabase();
  loadCommands(client);
  loadEvents(client);
  loadLegacyHandlers(client);
  initMusicPlayer(client);
client.on('shardReconnecting', (shardId) => logger.warn(`Discord shard ${shardId} reconnecting...`));
client.on('shardResume', (shardId, replayedEvents) => logger.success(`Discord shard ${shardId} resumed (${replayedEvents} events replayed).`));

async function main() {
  await connectDatabase();
  loadCommands(client);
  loadEvents(client);
  loadLegacyHandlers(client);
  initMusicPlayer(client);

  await client.login(config.token);

  const startDashboard = require('../dashboard/server');
  dashboardServer = startDashboard(client);
}

// Closes the dashboard HTTP server, the Discord connection and the MongoDB
// connection in turn (in that order, since it's harmless for the DB to stay
// up slightly longer, but we don't want the dashboard or the bot appearing
// "up" once a shutdown has started). Wired to SIGINT/SIGTERM below so
// process managers (Pterodactyl, pm2, Docker, Ctrl+C) can stop the bot
// without it looking like a crash in the logs, and so in-flight DB writes
// aren't cut off mid-operation.
async function shutdown(signal) {
  if (shuttingDown) return;
  shuttingDown = true;
  logger.warn(`Received ${signal}, shutting down gracefully...`);

  const timeout = setTimeout(() => {
    logger.error('Graceful shutdown timed out after 10s, forcing exit.');
    process.exit(1);
  }, 10_000);
  timeout.unref();

  // Stop the self-rescheduling poll loops first (scheduleService.js /
  // announcementService.js - see events/client/ready.js where they're
  // started) so a pending timer doesn't fire mid-shutdown and try to use
  // the Discord client or MongoDB connection right as they're closing.
  try {
    stopScheduler();
    stopAnnouncementScheduler();
    stopAllAfkSessions();
  } catch (err) {
    logger.error(`Error stopping schedulers: ${err?.stack || err}`);
  }

  try {
    if (dashboardServer) {
      await new Promise((resolve) => dashboardServer.close(resolve));
    }
  } catch (err) {
    logger.error(`Error closing dashboard server: ${err?.stack || err}`);
  }

  try {
    client.destroy();
  } catch (err) {
    logger.error(`Error destroying Discord client: ${err?.stack || err}`);
  }

  try {
    if (mongoose.connection.readyState !== 0) {
      await mongoose.connection.close();
    }
  } catch (err) {
    logger.error(`Error closing MongoDB connection: ${err?.stack || err}`);
  }

  logger.success('Shutdown complete.');
  clearTimeout(timeout);
  process.exit(0);
}

process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));

process.on('unhandledRejection', (err) => {
  logger.error(`Unhandled promise rejection: ${err?.stack || err}`);
});

process.on('uncaughtException', (err) => {
  logger.error(`Uncaught exception: ${err?.stack || err}`);
});

main().catch((err) => {
  logger.error(`Fatal startup error: ${err?.stack || err}`);
  process.exit(1);
});

module.exports = client;
