const Module = require('node:module');
const { Database } = require('./legacyDatabase');
const { Locale } = require('discord.js');

function installDiscordLocaleCompatibility() {
  if (Module.__nyxoDiscordLocaleCompatInstalled) return;

  const supportedLocales = new Set(Object.values(Locale));
  const discordBuilders = require('@discordjs/builders');
  const builderNames = [
    'SlashCommandBuilder',
    'SlashCommandSubcommandBuilder',
    'SlashCommandSubcommandGroupBuilder',
    'SlashCommandStringOption',
    'SlashCommandIntegerOption',
    'SlashCommandNumberOption',
    'SlashCommandBooleanOption',
    'SlashCommandUserOption',
    'SlashCommandChannelOption',
    'SlashCommandRoleOption',
    'SlashCommandMentionableOption',
    'SlashCommandAttachmentOption',
    'ContextMenuCommandBuilder',
  ];

  for (const builderName of builderNames) {
    const Builder = discordBuilders[builderName];
    if (!Builder?.prototype) continue;

    for (const methodName of ['setNameLocalizations', 'setDescriptionLocalizations']) {
      const original = Builder.prototype[methodName];
      if (typeof original !== 'function' || original.__nyxoWrapped) continue;

      const wrapped = function setSupportedLocalizations(localizations) {
        if (!localizations || typeof localizations !== 'object') {
          return original.call(this, localizations);
        }

        const maxLength = methodName === 'setNameLocalizations' ? 32 : 100;
        const supported = Object.fromEntries(
          Object.entries(localizations)
            .filter(([locale]) => supportedLocales.has(locale))
            .map(([locale, value]) => [locale, typeof value === 'string' ? value.slice(0, maxLength) : value]),
        );
        return original.call(this, supported);
      };
      wrapped.__nyxoWrapped = true;
      Builder.prototype[methodName] = wrapped;
    }

    const originalDescription = Builder.prototype.setDescription;
    if (typeof originalDescription === 'function' && !originalDescription.__nyxoWrapped) {
      const wrappedDescription = function setDiscordDescription(description) {
        return originalDescription.call(
          this,
          typeof description === 'string' ? description.slice(0, 100) : description,
        );
      };
      wrappedDescription.__nyxoWrapped = true;
      Builder.prototype.setDescription = wrappedDescription;
    }
  }

  Module.__nyxoDiscordLocaleCompatInstalled = true;
}

installDiscordLocaleCompatibility();

// The legacy project used st.db with absolute "/Json-db/..." paths. Keep its
// public API available while routing all reads and writes into NYXO BOT's
// project-local data/legacy directory.
if (!Module.__nyxoLegacyCompatInstalled) {
  const originalLoad = Module._load;
  Module._load = function loadWithNyxoCompatibility(request, parent, isMain) {
    if (request === 'st.db') return { Database };
    return originalLoad.call(this, request, parent, isMain);
  };
  Module.__nyxoLegacyCompatInstalled = true;
}
