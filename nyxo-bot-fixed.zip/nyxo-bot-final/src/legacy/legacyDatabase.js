const fs = require('node:fs');
const path = require('node:path');

const DATA_ROOT = path.resolve(__dirname, '../../data/legacy');

function normalizeFile(fileName) {
  const value = String(fileName || 'database.json')
    .replace(/^[/\\]+/, '')
    .replace(/^Json-db[/\\]+/i, '');
  const safeParts = value
    .split(/[/\\]+/)
    .filter((part) => part && part !== '.' && part !== '..')
    .map((part) => part.replace(/[^a-zA-Z0-9._-]/g, '_'));
  const relative = safeParts.length ? safeParts : ['Bots', 'database.json'];
  const filePath = path.join(DATA_ROOT, ...relative);
  if (!path.extname(filePath)) return `${filePath}.json`;
  return filePath;
}

function clone(value) {
  if (value === undefined) return undefined;
  return JSON.parse(JSON.stringify(value));
}

class Database {
  constructor(fileName) {
    this.filePath = normalizeFile(fileName);
    this.ensureFile();
  }

  ensureFile() {
    fs.mkdirSync(path.dirname(this.filePath), { recursive: true });
    if (!fs.existsSync(this.filePath)) {
      fs.writeFileSync(this.filePath, '{}\n', 'utf8');
    }
  }

  read() {
    this.ensureFile();
    try {
      const raw = fs.readFileSync(this.filePath, 'utf8').trim();
      return raw ? JSON.parse(raw) : {};
    } catch {
      return {};
    }
  }

  write(data) {
    this.ensureFile();
    const temporary = `${this.filePath}.${process.pid}.tmp`;
    fs.writeFileSync(temporary, `${JSON.stringify(data, null, 2)}\n`, 'utf8');
    fs.renameSync(temporary, this.filePath);
    return data;
  }

  get(key) {
    return clone(this.read()[key]);
  }

  set(key, value) {
    const data = this.read();
    data[key] = clone(value);
    this.write(data);
    return value;
  }

  push(key, value) {
    const data = this.read();
    const list = Array.isArray(data[key]) ? data[key] : [];
    list.push(clone(value));
    data[key] = list;
    this.write(data);
    return list;
  }

  delete(key) {
    const data = this.read();
    const existed = Object.prototype.hasOwnProperty.call(data, key);
    delete data[key];
    this.write(data);
    return existed;
  }

  has(key) {
    return Object.prototype.hasOwnProperty.call(this.read(), key);
  }

  all() {
    return clone(this.read());
  }
}

module.exports = { Database };