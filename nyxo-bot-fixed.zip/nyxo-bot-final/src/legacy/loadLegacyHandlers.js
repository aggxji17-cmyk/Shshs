const fs = require('node:fs');
const path = require('node:path');
const logger = require('../utils/logger');

function loadLegacyHandlers(client) {
  const handlersPath = path.join(__dirname, '..', 'legacy-handlers');
  const files = fs.readdirSync(handlersPath)
    .filter((file) => file.endsWith('.js') && file !== 'events.js')
    .sort();

  let loaded = 0;
  let skipped = 0;
  for (const file of files) {
    const fullPath = path.join(handlersPath, file);
    try {
      delete require.cache[require.resolve(fullPath)];
      const register = require(fullPath);
      if (typeof register !== 'function') {
        skipped += 1;
        logger.warn(`Skipping legacy handler without a registrar: ${file}`);
        continue;
      }
      register(client);
      loaded += 1;
    } catch (error) {
      skipped += 1;
      logger.warn(`Skipping legacy handler ${file}: ${error.message}`);
    }
  }

  logger.success(`Loaded ${loaded} legacy compatibility handlers${skipped ? ` (${skipped} skipped safely)` : ''}`);
}

module.exports = loadLegacyHandlers;
