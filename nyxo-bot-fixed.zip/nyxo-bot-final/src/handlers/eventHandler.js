const path = require('node:path');
const logger = require('../utils/logger');
const { walk } = require('../utils/fileWalker');

function loadEvents(client) {
  const eventsPath = path.join(__dirname, '..', 'events');
  const files = walk(eventsPath);

  let loaded = 0;
  for (const file of files) {
    delete require.cache[require.resolve(file)];
    const event = require(file);

    if (!event?.name || !event?.execute) {
      logger.warn(`Skipping invalid event file: ${file}`);
      continue;
    }

    if (event.once) {
      client.once(event.name, (...args) => runEvent(event, args, client));
    } else {
      client.on(event.name, (...args) => runEvent(event, args, client));
    }
    loaded += 1;
  }

  logger.success(`Loaded ${loaded} events`);
}

/**
 * Reliability net around every event listener: most event files (see
 * src/events/**) are async and have no top-level try/catch of their own,
 * so a rejection anywhere inside one (a DB hiccup, a missing cache entry,
 * etc.) used to surface only as a generic, context-free line from index.js's
 * global unhandledRejection handler - with no indication of which event
 * fired it. This catches it right at the source, logs the event name so
 * it's actually actionable, and - since discord.js keeps dispatching future
 * emissions of the same event regardless - preserves the exact behavior
 * that already existed: one bad emission is logged and dropped, the bot
 * keeps running.
 */
async function runEvent(event, args, client) {
  try {
    await event.execute(...args, client);
  } catch (err) {
    logger.error(`Event "${event.name}" handler crashed: ${err?.stack || err}`);
  }
}

module.exports = loadEvents;
