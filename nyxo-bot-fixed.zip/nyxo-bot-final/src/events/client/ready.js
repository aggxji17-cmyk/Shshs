const { config } = require('../../config/config');
const logger = require('../../utils/logger');
const { startGiveawayScheduler } = require('../../services/giveawayService');
const { startReminderScheduler } = require('../../services/reminderService');
const { startPollScheduler } = require('../../services/pollService');
const { startStreamNotificationPoller } = require('../../services/streamNotificationService');
const { startMemberCountUpdater } = require('../../services/memberCountService');
const { startMinecraftStatusPanelUpdater } = require('../../services/minecraftStatusPanelService');
const { startPendingDeliveryScheduler } = require('../../services/minecraftPendingDeliveryService');
const { cacheGuildInvites } = require('../../services/inviteService');
const { startCaseExpiryScheduler } = require('../../services/caseService');
const { startTicketAutoDeleteScheduler } = require('../../services/ticketCloseService');
const { startScheduler: startModerationScheduler } = require('../../services/scheduleService');
const { restoreTwentyFourSevenSessions } = require('../../services/musicService');
const { initKazagumo } = require('../../services/lavalinkManager');
const { startLinkCodeWatcher } = require('../../services/linkCodeService');
const { startAnnouncementScheduler } = require('../../services/announcementService');
const { startMemberGrowthScheduler } = require('../../services/memberGrowthService');
const { startSmartAlertsScheduler } = require('../../services/smartAlertsService');

module.exports = {
  name: 'clientReady',
  once: true,
  async execute(client) {
    logger.success(`Logged in as ${client.user.tag} (${client.guilds.cache.size} guilds)`);

    // Sets up the Kazagumo/Lavalink player used as the active engine for
    // most music commands (play/skip/pause/resume/stop/volume/seek/
    // filters/loop/shuffle/remove/autoplay/queue/nowplaying/lyrics - see
    // services/lavalinkManager.js). Safe no-op if LAVALINK_HOST/
    // LAVALINK_PASSWORD aren't set in .env yet.
    initKazagumo(client);

    client.user.setPresence({
      status: config.botStatus,
      activities: [{ name: config.activityText, type: activityTypeToEnum(config.activityType) }],
    });

    startGiveawayScheduler(client);
    startReminderScheduler(client);
    startPollScheduler(client);
    startStreamNotificationPoller(client);
    startMemberCountUpdater(client);
    startMinecraftStatusPanelUpdater(client);
    // Delivers shop item/spawner purchases that were queued because the
    // buyer was offline at purchase time, the moment they're seen online
    // on the item's target server - see services/minecraftPendingDeliveryService.js.
    startPendingDeliveryScheduler(client);
    startCaseExpiryScheduler();
    // Sweeps closed tickets whose 🗑️/🔓 window has expired and permanently
    // deletes them (archive + logs first) - see services/ticketCloseService.js.
    startTicketAutoDeleteScheduler(client);
    // Loads and resumes every still-Pending scheduled moderation task from
    // the database (including any that came due while the bot was
    // offline) - see services/scheduleService.js.
    startModerationScheduler(client);
    // Finalizes /link codes once a future in-game command marks them
    // "completed" - see services/linkCodeService.js.
    startLinkCodeWatcher(client);
    // Sends/reschedules recurring or one-off channel announcements set up
    // via /announcement - see services/announcementService.js.
    startAnnouncementScheduler(client);
    // Records a daily member-count point per guild and answers /servergrowth -
    // see services/memberGrowthService.js.
    startMemberGrowthScheduler(client);
    // Daily activity snapshots + a weekly Sunday health report for guilds
    // that enabled it via /setup-smart-alerts - see services/smartAlertsService.js.
    startSmartAlertsScheduler(client);
    // Rejoins every voice channel that had /247 enabled before the bot
    // last went offline - see services/musicService.js.
    restoreTwentyFourSevenSessions(client).catch((err) => logger.error(`24/7 restore failed: ${err.stack || err}`));

    for (const guild of client.guilds.cache.values()) {
      await cacheGuildInvites(guild).catch((err) => logger.warn(`Initial invite cache failed for ${guild.id}: ${err.message}`));
    }
  },
};

function activityTypeToEnum(type) {
  const map = { Playing: 0, Streaming: 1, Listening: 2, Watching: 3, Competing: 5 };
  return map[type] ?? 3;
}
