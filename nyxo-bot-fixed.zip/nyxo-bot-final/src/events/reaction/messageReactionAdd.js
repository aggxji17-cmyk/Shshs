const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { syncStarboardPost } = require('../../services/starboardService');
const { handleReactionAdd } = require('../../services/reactionRoleService');

module.exports = {
  name: 'messageReactionAdd',
  async execute(reaction, user) {
    if (user.bot || !reaction.message.guild) return;

    // Reactions on uncached (partial) messages need a fetch before their
    // content/author/etc. are usable.
    if (reaction.partial) {
      reaction = await reaction.fetch().catch(() => null);
      if (!reaction) return;
    }
    if (reaction.message.partial) {
      await reaction.message.fetch().catch(() => null);
    }

    const guildConfig = await getGuildConfig(reaction.message.guild.id);
    const settings = resolved(guildConfig);

    await syncStarboardPost(reaction, guildConfig, settings).catch(() => null);
    await handleReactionAdd(reaction, user).catch(() => null);
  },
};
