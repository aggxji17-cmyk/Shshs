const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { syncStarboardPost } = require('../../services/starboardService');
const { handleReactionRemove } = require('../../services/reactionRoleService');

module.exports = {
  name: 'messageReactionRemove',
  async execute(reaction, user) {
    if (user.bot || !reaction.message.guild) return;

    if (reaction.partial) {
      reaction = await reaction.fetch().catch(() => null);
      if (!reaction) return;
    }
    if (reaction.message.partial) {
      await reaction.message.fetch().catch(() => null);
    }

    const guildConfig = await getGuildConfig(reaction.message.guild.id);
    const settings = resolved(guildConfig);

    await syncStarboardPost(reaction, guildConfig, settings).catch(() => null);
    await handleReactionRemove(reaction, user).catch(() => null);
  },
};
