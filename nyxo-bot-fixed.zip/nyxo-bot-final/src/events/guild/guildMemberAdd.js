const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { applyPlaceholders } = require('../../utils/placeholders');
const { baseEmbed, errorEmbed } = require('../../utils/embeds');
const { resolveJoinInvite } = require('../../services/inviteService');
const { recordJoinAndCheckRaid, isNewAccount } = require('../../services/antiRaidService');
const { sendModLog } = require('../../utils/modLog');
const logger = require('../../utils/logger');

module.exports = {
  name: 'guildMemberAdd',
  async execute(member) {
    const guildConfig = await getGuildConfig(member.guild.id);
    const settings = resolved(guildConfig);

    const wasRaidJustHandled = await recordJoinAndCheckRaid(member, guildConfig, settings).catch(() => false);
    await handleNewAccountFlag(member, guildConfig, settings);

    if (guildConfig.autoRoleId) {
      const role = member.guild.roles.cache.get(guildConfig.autoRoleId);
      if (role) await member.roles.add(role).catch((err) => logger.warn(`Autorole failed: ${err.message}`));
    }

    if (guildConfig.welcome?.enabled && guildConfig.welcome.channelId) {
      const channel = member.guild.channels.cache.get(guildConfig.welcome.channelId);
      if (channel) {
        const embed = baseEmbed(settings)
          .setTitle('👋 Welcome!')
          .setDescription(applyPlaceholders(guildConfig.welcome.message, member))
          .setThumbnail(member.user.displayAvatarURL());
        if (guildConfig.welcome.color) embed.setColor(guildConfig.welcome.color);
        if (guildConfig.welcome.imageUrl) embed.setImage(guildConfig.welcome.imageUrl);
        channel.send({ embeds: [embed] }).catch(() => null);
      }
    }

    if (guildConfig.welcome?.dm?.enabled) {
      const dmTemplate = guildConfig.welcome.dm.message || guildConfig.welcome.message;
      const dmEmbed = baseEmbed(settings)
        .setTitle(`👋 Welcome to ${member.guild.name}!`)
        .setDescription(applyPlaceholders(dmTemplate, member))
        .setThumbnail(member.guild.iconURL() || null);
      if (guildConfig.welcome.color) dmEmbed.setColor(guildConfig.welcome.color);
      // Best-effort only - DMs are frequently closed to non-friends/non-
      // shared-server senders, and that failure should never be treated
      // as noteworthy (no log, no fallback message to the guild).
      member.send({ embeds: [dmEmbed] }).catch(() => null);
    }

    if (guildConfig.logging?.enabled && guildConfig.logging.events.memberJoin) {
      const logChannel = member.guild.channels.cache.get(guildConfig.logging.channelId);
      if (logChannel) {
        logChannel
          .send({
            embeds: [
              baseEmbed(settings)
                .setTitle('Member Joined')
                .setDescription(`${member} (${member.user.tag})`)
                .setThumbnail(member.user.displayAvatarURL()),
            ],
          })
          .catch(() => null);
      }
    }

    if (!wasRaidJustHandled) {
      await handleInviteTracking(member, guildConfig, settings);
    }
  },
};

async function handleInviteTracking(member, guildConfig, settings) {
  if (!guildConfig.invites?.enabled) return;

  const inviterId = await resolveJoinInvite(member.guild).catch(() => null);
  if (!guildConfig.invites.logChannelId) return;

  const logChannel = member.guild.channels.cache.get(guildConfig.invites.logChannelId);
  if (!logChannel) return;

  const description = inviterId
    ? `${member} joined, invited by <@${inviterId}>.`
    : `${member} joined (invite could not be determined - vanity URL or expired invite).`;

  logChannel.send({ embeds: [baseEmbed(settings).setDescription(description)] }).catch(() => null);
}

async function handleNewAccountFlag(member, guildConfig, settings) {
  if (!guildConfig.antiRaid?.enabled) return;
  if (!isNewAccount(member.user, guildConfig)) return;

  if (guildConfig.antiRaid.newAccountAction === 'kick') {
    await member.kick('Account younger than the configured minimum age').catch(() => null);
    await sendModLog(member.guild, guildConfig, settings, {
      title: 'New Account Kicked',
      description: `${member.user.tag} was kicked automatically for having an account younger than ${guildConfig.antiRaid.newAccountAgeDays} day(s).`,
      color: '#ED4245',
    });
  } else if (guildConfig.antiRaid.newAccountAction === 'flag') {
    await sendModLog(member.guild, guildConfig, settings, {
      title: 'New Account Joined',
      description: `${member} has an account younger than ${guildConfig.antiRaid.newAccountAgeDays} day(s). Flagged for review.`,
      color: '#FEE75C',
    });
  }
}
