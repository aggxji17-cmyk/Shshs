// Feeds the Smart Alerts weekly health report (src/services/smartAlertsService.js).
// Kept as its own listener file (rather than editing guildBanAdd.js) since the
// event handler loads every file under src/events and multiple files may
// share the same event name.
const { trackBan } = require('../../services/smartAlertsService');

module.exports = {
  name: 'guildBanAdd',
  async execute(ban) {
    await trackBan(ban.guild);
  },
};
