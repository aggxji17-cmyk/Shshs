const { AuditLogEvent } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { applyPlaceholders } = require('../../utils/placeholders');
const { baseEmbed } = require('../../utils/embeds');
const { fetchExecutorId } = require('../../utils/auditLog');
const { handleManualRoleRemoval } = require('../../services/tempRoleService');

async function handleBoosterAnnouncement(oldMember, newMember) {
  // premiumSince goes from null to a Date the moment a member starts boosting.
  const justBoosted = !oldMember.premiumSince && newMember.premiumSince;
  if (!justBoosted) return;

  const guildConfig = await getGuildConfig(newMember.guild.id);
  if (!guildConfig.boosterAnnounce?.enabled || !guildConfig.boosterAnnounce.channelId) return;

  const channel = newMember.guild.channels.cache.get(guildConfig.boosterAnnounce.channelId);
  if (!channel) return;

  const settings = resolved(guildConfig);
  const description = applyPlaceholders(guildConfig.boosterAnnounce.message, newMember);
  channel
    .send({ embeds: [baseEmbed(settings).setDescription(description).setThumbnail(newMember.user.displayAvatarURL())] })
    .catch(() => null);
}

/**
 * If a role that services/tempRoleService.js is tracking (a Pending
 * temprole_remove task) just disappeared from this member - however that
 * happened, whether through /role remove, the Discord UI, or another bot -
 * resolve that task now instead of leaving it to fire later against a role
 * the member no longer has. This is what satisfies "a role removed
 * manually before its time is up must not be removed again".
 *
 * Skipped when the bot itself was the executor: that means either
 * tempRoleService's own scheduled expiry or its own /temprole remove just
 * ran, and both already update the task's status themselves. Without this
 * check, this handler could race that in-flight update and flip a task
 * that is about to be marked Completed back to Cancelled.
 */
async function handleTempRoleRemovals(oldMember, newMember) {
  const removedRoleIds = oldMember.roles.cache.filter((r) => !newMember.roles.cache.has(r.id)).map((r) => r.id);
  if (!removedRoleIds.length) return;

  const executorId = await fetchExecutorId(newMember.guild, AuditLogEvent.MemberRoleUpdate, newMember.id);
  if (executorId === newMember.client.user.id) return;

  for (const roleId of removedRoleIds) {
    await handleManualRoleRemoval(newMember.client, newMember.guild, newMember.id, roleId, executorId).catch(() => null);
  }
}

module.exports = {
  name: 'guildMemberUpdate',
  async execute(oldMember, newMember) {
    await handleBoosterAnnouncement(oldMember, newMember);
    await handleTempRoleRemovals(oldMember, newMember);
  },
};
