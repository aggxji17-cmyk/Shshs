const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { applyPlaceholders } = require('../../utils/placeholders');
const { baseEmbed } = require('../../utils/embeds');

module.exports = {
  name: 'guildMemberRemove',
  async execute(member) {
    const guildConfig = await getGuildConfig(member.guild.id);
    const settings = resolved(guildConfig);

    if (guildConfig.goodbye?.enabled && guildConfig.goodbye.channelId) {
      const channel = member.guild.channels.cache.get(guildConfig.goodbye.channelId);
      if (channel) {
        const embed = baseEmbed(settings)
          .setTitle('👋 Goodbye')
          .setDescription(applyPlaceholders(guildConfig.goodbye.message, member))
          .setThumbnail(member.user.displayAvatarURL());
        channel.send({ embeds: [embed] }).catch(() => null);
      }
    }

    if (guildConfig.logging?.enabled && guildConfig.logging.events.memberLeave) {
      const logChannel = member.guild.channels.cache.get(guildConfig.logging.channelId);
      if (logChannel) {
        logChannel
          .send({
            embeds: [baseEmbed(settings).setTitle('Member Left').setDescription(`${member.user.tag} (${member.id})`)],
          })
          .catch(() => null);
      }
    }
  },
};
