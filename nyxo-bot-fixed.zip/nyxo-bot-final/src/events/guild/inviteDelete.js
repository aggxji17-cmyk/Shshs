const InviteCache = require('../../database/models/InviteCache');

module.exports = {
  name: 'inviteDelete',
  async execute(invite) {
    if (!invite.guild) return;
    await InviteCache.deleteOne({ guildId: invite.guild.id, code: invite.code }).catch(() => null);
  },
};
