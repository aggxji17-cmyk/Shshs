const { AuditLogEvent } = require('discord.js');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { trackAndEnforce } = require('../../services/antiNukeService');
const { fetchExecutorId } = require('../../utils/auditLog');
const { baseEmbed } = require('../../utils/embeds');

module.exports = {
  name: 'roleDelete',
  async execute(role) {
    const guildConfig = await getGuildConfig(role.guild.id);
    const settings = resolved(guildConfig);

    const executorId = await fetchExecutorId(role.guild, AuditLogEvent.RoleDelete, role.id);
    if (!executorId) return;

    await trackAndEnforce(role.guild, executorId, 'roleDelete', guildConfig);

    if (guildConfig.logging?.enabled && guildConfig.logging.events.roleUpdates) {
      const logChannel = role.guild.channels.cache.get(guildConfig.logging.channelId);
      if (logChannel) {
        logChannel
          .send({
            embeds: [
              baseEmbed(settings)
                .setTitle('Role Deleted')
                .addFields(
                  { name: 'Role', value: role.name, inline: true },
                  { name: 'By', value: `<@${executorId}>`, inline: true }
                ),
            ],
          })
          .catch(() => null);
      }
    }
  },
};
