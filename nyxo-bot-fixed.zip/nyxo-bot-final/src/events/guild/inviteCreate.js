const { cacheGuildInvites } = require('../../services/inviteService');

module.exports = {
  name: 'inviteCreate',
  async execute(invite) {
    if (!invite.guild) return;
    await cacheGuildInvites(invite.guild).catch(() => null);
  },
};
