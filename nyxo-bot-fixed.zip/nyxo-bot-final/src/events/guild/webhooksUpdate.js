const { AuditLogEvent } = require('discord.js');
const { getGuildConfig } = require('../../utils/resolveGuildSettings');
const { trackAndEnforce } = require('../../services/antiNukeService');
const { fetchExecutorId } = require('../../utils/auditLog');

module.exports = {
  name: 'webhooksUpdate',
  async execute(channel) {
    const guildConfig = await getGuildConfig(channel.guild.id);
    if (!guildConfig.antinuke?.enabled) return;

    const executorId = await fetchExecutorId(channel.guild, AuditLogEvent.WebhookCreate, null);
    if (!executorId) return;

    await trackAndEnforce(channel.guild, executorId, 'webhookCreate', guildConfig);
  },
};
