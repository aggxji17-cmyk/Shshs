// Feeds the Smart Alerts weekly health report (src/services/smartAlertsService.js)
// with per-staff message activity. Kept as its own listener file (rather than
// editing messageCreate.js) since the event handler loads every file under
// src/events and multiple files may share the same event name.
const { trackStaffActivity } = require('../../services/smartAlertsService');

module.exports = {
  name: 'messageCreate',
  async execute(message) {
    await trackStaffActivity(message);
  },
};
