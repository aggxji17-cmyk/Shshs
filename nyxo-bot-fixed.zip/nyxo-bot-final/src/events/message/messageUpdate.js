const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { baseEmbed } = require('../../utils/embeds');
const { sendModLog } = require('../../utils/modLog');
const { recordEditedMessage } = require('../../services/snipeService');

// An edit that strips a mention within this many milliseconds of the
// original send is treated as a possible "edit ghost ping".
const GHOST_PING_EDIT_WINDOW_MS = 15000;

module.exports = {
  name: 'messageUpdate',
  async execute(oldMessage, newMessage) {
    if (!newMessage.guild || newMessage.author?.bot) return;
    if (oldMessage.content === newMessage.content) return;

    recordEditedMessage(oldMessage, newMessage);

    const guildConfig = await getGuildConfig(newMessage.guild.id);
    const settings = resolved(guildConfig);

    await handleEditGhostPing(oldMessage, newMessage, guildConfig, settings);

    if (!guildConfig.logging?.enabled || !guildConfig.logging.events.messageEdit) return;

    const logChannel = newMessage.guild.channels.cache.get(guildConfig.logging.channelId);
    if (!logChannel) return;

    logChannel
      .send({
        embeds: [
          baseEmbed(settings)
            .setTitle('Message Edited')
            .addFields(
              { name: 'Author', value: `${newMessage.author.tag}`, inline: true },
              { name: 'Channel', value: `${newMessage.channel}`, inline: true },
              { name: 'Before', value: oldMessage.content?.slice(0, 500) || '*(unknown)*' },
              { name: 'After', value: newMessage.content?.slice(0, 500) || '*(unknown)*' }
            ),
        ],
      })
      .catch(() => null);
  },
};

/**
 * Flags a message that had a mention edited out shortly after being sent -
 * the same "ghost ping" intent as a delete, just achieved via edit instead.
 */
async function handleEditGhostPing(oldMessage, newMessage, guildConfig, settings) {
  if (!guildConfig.moderation?.antiGhostPing) return;
  if (!newMessage.createdTimestamp) return;

  const age = Date.now() - newMessage.createdTimestamp;
  if (age > GHOST_PING_EDIT_WINDOW_MS) return;

  const oldMentions = oldMessage.mentions?.users ?? new Map();
  const newMentionIds = new Set(newMessage.mentions?.users?.keys() ?? []);
  const removed = [...oldMentions.values()].filter((u) => !newMentionIds.has(u.id));
  if (!removed.length) return;

  await sendModLog(newMessage.guild, guildConfig, settings, {
    title: 'Ghost Ping Detected (Edit)',
    description: `${newMessage.author} edited out a mention of ${removed.map((u) => `${u}`).join(', ')} in ${newMessage.channel} shortly after sending.`,
    color: '#ED4245',
  });
}
