const { PermissionFlagsBits } = require('discord.js');
const logger = require('../../utils/logger');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { processMessage: runAutoModeration } = require('../../services/autoModerationService');
const { grantMessageXp } = require('../../services/levelingService');
const { baseEmbed, successEmbed, errorEmbed } = require('../../utils/embeds');
const { markAutoDeleted } = require('../../utils/autoDeleteTracker');
const { buildMinecraftStatusResponse } = require('../../services/minecraftEmbedBuilder');
const { isModerator } = require('../../utils/permissions');
const { notifyMember } = require('../../services/ticketNotifyService');
const { hasBypass, mentionsProtectedUser } = require('../../services/mentionProtectionService');

const AfkStatus = require('../../database/models/AfkStatus');
const StickyMessage = require('../../database/models/StickyMessage');
const AutoResponder = require('../../database/models/AutoResponder');
const Ticket = require('../../database/models/Ticket');
const { repostSticky } = require('../../services/stickyService');
const { buildStatusChannelName, deriveBaseChannelName } = require('../../utils/ticketPanel');

/**
 * Reliability isolation: this pipeline is a chain of otherwise-independent
 * features (AFK, sticky, autoresponder, leveling, ticket status, ...).
 * Before this wrapper, an unexpected rejection in any one step (e.g. a
 * transient Mongo error inside handleAfkClear) propagated straight out of
 * execute() and silently skipped every step after it - automod, leveling
 * XP, sticky reposts, etc. - for that message, with the only trace being a
 * generic, context-free line from index.js's global unhandledRejection
 * handler. Wrapping each step keeps a single flaky feature from taking the
 * rest of the pipeline down with it, and logs which step failed for which
 * message/guild.
 */
async function safeStep(name, message, fn) {
  try {
    return await fn();
  } catch (err) {
    logger.error(`messageCreate.${name} failed (message ${message.id}, guild ${message.guild?.id}): ${err?.stack || err}`);
    return undefined;
  }
}

module.exports = {
  name: 'messageCreate',
  async execute(message) {
    if (message.author.bot || !message.guild) return;

    const guildConfig = await getGuildConfig(message.guild.id).catch((err) => {
      logger.error(`messageCreate: failed to load guild config for guild ${message.guild.id}: ${err?.stack || err}`);
      return null;
    });
    if (!guildConfig) return;
    const settings = resolved(guildConfig);

    if (await safeStep('handleIpTrigger', message, () => handleIpTrigger(message, settings))) return;
    if (await safeStep('handleMentionProtection', message, () => handleMentionProtection(message, guildConfig))) return;

    // Both steps below need the same "open ticket for this channel" lookup
    // (Ticket.findOne({channelId, status: {$ne: 'closed'}})) - fetch it once
    // here and share it instead of each running an identical query on every
    // single message sent anywhere in the server.
    const openTicket = await safeStep('handleTicketLookup', message, () =>
      Ticket.findOne({ channelId: message.channel.id, status: { $ne: 'closed' } })
    );
    await safeStep('handleTicketStatusUpdate', message, () => handleTicketStatusUpdate(message, openTicket));
    await safeStep('handleTicketSmartMention', message, () => handleTicketSmartMention(message, guildConfig, settings, openTicket));

    await safeStep('handleAfkClear', message, () => handleAfkClear(message, settings));
    await safeStep('handleAfkMentions', message, () => handleAfkMentions(message, guildConfig, settings));

    if (await safeStep('handleCounting', message, () => handleCounting(message, guildConfig, settings))) return;
    if (await safeStep('handleAutomod', message, () => handleAutomod(message, guildConfig, settings))) return;

    await safeStep('handleAutoDeleteSchedule', message, () => handleAutoDeleteSchedule(message, guildConfig));
    await safeStep('handleStickyRepost', message, () => handleStickyRepost(message, settings));
    await safeStep('handleAutoResponder', message, () => handleAutoResponder(message, guildConfig));
    await safeStep('handleLeveling', message, () => handleLeveling(message, guildConfig, settings));
    await safeStep('handleLegacyPrefixCommands', message, () => handleLegacyPrefixCommands(message, settings));
  },
};

/**
 * Whenever someone sends a message that is just the word "ip" (any casing,
 * whitespace trimmed) in any channel, replies with a live-updated embed of
 * the configured Minecraft server(s) - Java + Bedrock status, player count,
 * a fill progress bar, MOTD and server icon. If the bot has Manage Messages
 * in that channel, the triggering "ip" message is deleted afterward.
 * Returns true if this message was handled as an ip trigger (so the caller
 * can skip the rest of the message pipeline for it).
 */
async function handleIpTrigger(message, settings) {
  if (message.content.trim().toLowerCase() !== 'ip') return false;

  const response = await buildMinecraftStatusResponse(settings);
  await message.channel.send(response).catch(() => null);

  const canManageMessages = message.channel
    .permissionsFor(message.guild.members.me)
    ?.has(PermissionFlagsBits.ManageMessages);

  if (canManageMessages) {
    await message.delete().catch(() => null);
  }

  return true;
}

/**
 * Deletes any message that @mentions a protected user, unless its author
 * is exempt (guild manager or a configured bypass role). Runs before
 * everything else in the pipeline - there's no reason to process a
 * message further once it's been removed for this. Discord has already
 * fired the mention notification by the time the bot can react to it, so
 * this can't guarantee the ping was never seen - only that the message
 * itself is gone as fast as possible (see the schema comment in
 * GuildConfig.js).
 */
async function handleMentionProtection(message, guildConfig) {
  if (!guildConfig.mentionProtection?.enabled) return false;
  if (!mentionsProtectedUser(message, guildConfig)) return false;
  if (hasBypass(message.member, guildConfig)) return false;

  await message.delete().catch(() => null);
  return true;
}

/**
 * "Smart notification": when a staff member @mentions, inside a ticket
 * channel, someone who doesn't yet have access to that channel (i.e.
 * "شخص خارج التكت"), the bot takes over instead of leaving a raw ping
 * sitting there:
 *   1. grants that member access to the ticket (see ticketNotifyService),
 *   2. sends its own clean notification message with the actual ping,
 *   3. deletes the staff member's original message.
 * Mentioning someone who already has access (another staff member, the
 * ticket opener, etc.) is left alone - that's just a normal message.
 */
async function handleTicketSmartMention(message, guildConfig, settings, ticket) {
  if (!message.mentions.users.size) return;
  if (!ticket) return;
  if (!isModerator(message.member, guildConfig)) return;

  const outsiders = [];
  for (const user of message.mentions.users.values()) {
    if (user.bot || user.id === message.author.id) continue;
    const member = await message.guild.members.fetch(user.id).catch(() => null);
    if (!member) continue;
    const perms = message.channel.permissionsFor(member);
    if (!perms?.has(PermissionFlagsBits.ViewChannel)) outsiders.push(user);
  }

  if (!outsiders.length) return;

  const reason = message.content.replace(/<@!?\d+>/g, '').trim() || null;

  await message.delete().catch(() => null);

  for (const target of outsiders) {
    await notifyMember({
      channel: message.channel,
      guildConfig,
      settings,
      ticket,
      requestedBy: message.author,
      target,
      reason,
    }).catch(() => null);
  }
}

/**
 * Keeps a ticket channel's 🟡/🟢 status in sync with who last spoke in it:
 * the ticket opener speaking means staff still owes a reply (🟡 needs_reply),
 * anyone else speaking (staff) means the ball is no longer in the opener's
 * court (🟢 no_action). Only touches open/claimed tickets, and only renames
 * the channel when the status actually flips, to stay well under Discord's
 * 2-renames-per-10-minutes-per-channel limit during an active conversation.
 */
async function handleTicketStatusUpdate(message, ticket) {
  if (!ticket) return;

  const nextStatus = message.author.id === ticket.userId ? 'needs_reply' : 'no_action';
  if (ticket.replyStatus === nextStatus) return;

  const baseName = ticket.baseChannelName || deriveBaseChannelName(message.channel.name);

  ticket.replyStatus = nextStatus;
  ticket.baseChannelName = baseName;
  await ticket.save();

  await message.channel.setName(buildStatusChannelName(baseName, nextStatus)).catch(() => null);
}

/**
 * Clears the sender's own AFK status the moment they speak again, and lets
 * them know how many times they were mentioned while away.
 */
async function handleAfkClear(message, settings) {
  const afk = await AfkStatus.findOneAndDelete({ guildId: message.guild.id, userId: message.author.id });
  if (!afk) return;

  const mentionNote = afk.mentionCount > 0 ? ` You were mentioned **${afk.mentionCount}** time(s) while away.` : '';
  message
    .reply({ embeds: [successEmbed(settings, `Welcome back, ${message.author}! I removed your AFK status.${mentionNote}`)] })
    .then((m) => setTimeout(() => m.delete().catch(() => null), 8000))
    .catch(() => null);
}

/**
 * Notifies the author when they mention someone who is currently AFK, and
 * bumps that AFK user's mention counter for when they return.
 */
async function handleAfkMentions(message, guildConfig, settings) {
  if (!message.mentions.users.size) return;

  const mentionedIds = [...message.mentions.users.keys()].filter((id) => id !== message.author.id);
  if (!mentionedIds.length) return;

  const afkUsers = await AfkStatus.find({ guildId: message.guild.id, userId: { $in: mentionedIds } });
  if (!afkUsers.length) return;

  await AfkStatus.updateMany(
    { guildId: message.guild.id, userId: { $in: afkUsers.map((a) => a.userId) } },
    { $inc: { mentionCount: 1 } }
  );

  const lines = afkUsers.map((a) => `<@${a.userId}> is AFK: ${a.reason}`);
  message.reply({ embeds: [baseEmbed(settings).setDescription(lines.join('\n'))] }).catch(() => null);
}

/**
 * Reposts the channel's sticky message (if one is configured) to the bottom
 * of the channel so it stays visible under new activity.
 */
async function handleStickyRepost(message, settings) {
  const sticky = await StickyMessage.findOne({ channelId: message.channelId });
  if (!sticky) return;
  // Don't immediately re-repost in response to the bot's own sticky message.
  if (message.id === sticky.lastMessageId) return;

  await repostSticky(message.channel, sticky, settings);
}

/**
 * Matches the message content against configured auto-responder triggers
 * and sends the first matching response.
 */
async function handleAutoResponder(message, guildConfig) {
  const content = message.content.toLowerCase().trim();
  if (!content) return;

  const responders = await AutoResponder.find({ guildId: message.guild.id });
  if (!responders.length) return;

  const match = responders.find((r) => {
    const trigger = r.trigger.toLowerCase();
    return r.matchType === 'exact' ? content === trigger : content.includes(trigger);
  });
  if (!match) return;

  // The response text is staff-configured (via /autoresponder, gated on
  // ManageGuild) but that permission is not the same as Discord's own
  // "Mention Everyone" permission - without this, a guild manager who
  // lacks MentionEveryone could still get an actual @everyone/@here/role
  // ping out of the bot (which normally does have that permission) just
  // by putting it in a trigger response. Mirrors the same fix already
  // applied to dashboard/routes/sticky.js's raw content send.
  message.channel.send({ content: match.response, allowedMentions: { parse: [] } }).catch(() => null);
}

/**
 * Drives the counting game: validates the next number, updates the running
 * count, and resets on a broken sequence or a repeat-user violation.
 * Returns true if the message belonged to the counting channel (so the
 * caller can skip other handlers like automod/autoresponder for it).
 */
async function handleCounting(message, guildConfig, settings) {
  if (!guildConfig.counting?.enabled || message.channelId !== guildConfig.counting.channelId) return false;

  const submitted = Number(message.content.trim());
  const expected = guildConfig.counting.currentCount + 1;
  const isValidNumber = Number.isInteger(submitted) && String(submitted) === message.content.trim();
  const isSameUserTwice = guildConfig.counting.lastUserId === message.author.id;

  if (!isValidNumber || submitted !== expected || isSameUserTwice) {
    await message.react('❌').catch(() => null);

    const reason = isSameUserTwice
      ? 'you cannot count twice in a row'
      : !isValidNumber
        ? 'that is not a valid whole number'
        : `the next number should have been **${expected}**`;

    message.channel
      .send({ embeds: [errorEmbed(settings, `${message.author} broke the count at **${guildConfig.counting.currentCount}** - ${reason}.`)] })
      .catch(() => null);

    if (guildConfig.counting.resetOnError) {
      guildConfig.counting.currentCount = 0;
      guildConfig.counting.lastUserId = null;
    }
    await guildConfig.save();
    return true;
  }

  guildConfig.counting.currentCount = submitted;
  guildConfig.counting.lastUserId = message.author.id;
  if (submitted > guildConfig.counting.highestCount) guildConfig.counting.highestCount = submitted;
  await guildConfig.save();

  await message.react('✅').catch(() => null);
  return true;
}

/**
 * If this channel is configured for auto-delete, schedules the message for
 * removal after the configured delay and flags it so messageDelete knows
 * this was an expected cleanup rather than a real deletion.
 */
async function handleAutoDeleteSchedule(message, guildConfig) {
  const config = (guildConfig.moderation?.autoDeleteChannels || []).find((c) => c.channelId === message.channelId);
  if (!config) return;

  setTimeout(() => {
    markAutoDeleted(message.id);
    message.delete().catch(() => null);
  }, config.delaySeconds * 1000).unref?.();
}

async function handleAutomod(message, guildConfig, settings) {
  return runAutoModeration(message, guildConfig, settings);
}

async function handleLeveling(message, guildConfig, settings) {
  if (!guildConfig.leveling?.enabled) return;

  const { leveledUp, newLevel } = await grantMessageXp(
    message.guild.id,
    message.author.id,
    guildConfig.leveling.xpPerMessage,
    guildConfig.leveling.cooldownSeconds
  );

  if (leveledUp) {
    const channelId = guildConfig.leveling.announceChannelId || message.channelId;
    const channel = message.guild.channels.cache.get(channelId) || message.channel;
    channel
      .send({
        embeds: [baseEmbed(settings).setDescription(`🎉 ${message.author} leveled up to **level ${newLevel}**!`)],
      })
      .catch(() => null);
  }
}

async function handleLegacyPrefixCommands(message, settings) {
  if (!message.content.startsWith(settings.prefix)) return;

  const args = message.content.slice(settings.prefix.length).trim().split(/\s+/);
  const commandName = args.shift()?.toLowerCase();

  if (commandName === 'ping') {
    await message.reply({
      embeds: [baseEmbed(settings).setDescription(`🏓 Pong! Latency: **${message.client.ws.ping}ms**`)],
    });
  } else if (commandName === 'help') {
    await message.reply({
      embeds: [
        baseEmbed(settings)
          .setTitle('Need help?')
          .setDescription('This bot primarily uses **slash commands** - type `/` to see the full list.'),
      ],
    });
  }
}
