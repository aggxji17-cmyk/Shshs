const { ChannelType, PermissionFlagsBits } = require('discord.js');
const { getGuildConfig } = require('../../utils/resolveGuildSettings');

// channelId (of a created temp channel) -> true, so we know which voice
// channels are ours to auto-delete once they empty out.
const managedChannels = new Set();

module.exports = {
  name: 'voiceStateUpdate',
  async execute(oldState, newState) {
    const guild = newState.guild || oldState.guild;
    const guildConfig = await getGuildConfig(guild.id);
    if (!guildConfig.joinToCreate?.enabled) return;

    if (newState.channelId && newState.channelId === guildConfig.joinToCreate.triggerChannelId) {
      await createTempChannel(newState, guildConfig);
    }

    if (oldState.channel && managedChannels.has(oldState.channelId) && oldState.channel.members.size === 0) {
      await oldState.channel.delete().catch(() => null);
      managedChannels.delete(oldState.channelId);
    }
  },
};

async function createTempChannel(state, guildConfig) {
  const name = guildConfig.joinToCreate.nameTemplate.replace('{username}', state.member.user.username);

  const channel = await state.guild.channels
    .create({
      name,
      type: ChannelType.GuildVoice,
      parent: guildConfig.joinToCreate.categoryId || state.channel.parentId || undefined,
      userLimit: guildConfig.joinToCreate.userLimit || undefined,
      permissionOverwrites: [
        {
          id: state.member.id,
          allow: [PermissionFlagsBits.ManageChannels, PermissionFlagsBits.MoveMembers],
        },
      ],
    })
    .catch(() => null);
  if (!channel) return;

  managedChannels.add(channel.id);
  await state.member.voice.setChannel(channel).catch(() => null);
}
