const { handleVoiceStateChange } = require('../../services/afkRewardsService');

/**
 * Minecraft AFK Voice Rewards. Registered alongside the existing
 * `voiceStateUpdate` listener (src/events/voice/voiceStateUpdate.js) -
 * discord.js/Node's EventEmitter supports multiple listeners per event,
 * and the event loader (src/handlers/eventHandler.js) already loads
 * every file under src/events/**, so this doesn't touch (or risk
 * breaking) the join-to-create logic in that file.
 *
 * All the actual logic - timer bookkeeping, the AFK-channel check, and
 * granting the reward through the existing Minecraft link/command-queue
 * integration - lives in services/afkRewardsService.js, which no-ops
 * safely if the feature is disabled or unconfigured.
 */
module.exports = {
  name: 'voiceStateUpdate',
  async execute(oldState, newState) {
    handleVoiceStateChange(oldState, newState);
  },
};
