const { useQueue } = require('discord-player');
const { getGuildConfig, resolved } = require('../../utils/resolveGuildSettings');
const { baseEmbed } = require('../../utils/embeds');
const logger = require('../../utils/logger');

/**
 * Companion to the auto-pause in services/musicService.js's EmptyChannel
 * handler: once everyone leaves the bot's voice channel, playback is
 * paused (not just left waiting to disconnect) and the queue is tagged
 * `metadata.autoPausedForEmpty`. This listener watches for a member
 * (re)joining that same channel and, if the tag is set, unpauses right
 * where the track left off and clears the tag.
 *
 * Deliberately ignores plain manual pauses (/pause, the ⏸️ button) -
 * those never set the tag, so this never overrides a pause someone
 * chose on purpose.
 */
module.exports = {
  name: 'voiceStateUpdate',
  async execute(oldState, newState) {
    // Only care about someone *entering* a channel - covers a fresh
    // join and switching channels. A pure leave has newState.channelId
    // === null (or unchanged if this update isn't about channel at all).
    if (newState.channelId === oldState.channelId || !newState.channelId) return;
    if (newState.member?.user?.bot) return;

    const guild = newState.guild;
    const queue = useQueue(guild.id);
    if (!queue || !queue.channel || queue.channel.id !== newState.channelId) return;
    if (!queue.metadata?.autoPausedForEmpty) return;

    queue.node.setPaused(false);
    queue.metadata.autoPausedForEmpty = false;

    const channel = queue.metadata?.channel;
    if (!channel) return;
    try {
      const guildConfig = await getGuildConfig(guild.id);
      const settings = resolved(guildConfig);
      await channel.send({
        embeds: [baseEmbed(settings).setDescription(`▶️ Welcome back — resumed **${queue.currentTrack?.title ?? 'playback'}**.`)],
      });
    } catch (err) {
      logger.error(`Failed to send auto-resume message: ${err.stack || err}`);
    }
  },
};
