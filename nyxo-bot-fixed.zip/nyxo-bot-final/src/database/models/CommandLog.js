const { Schema, model } = require('mongoose');

/**
 * One document per command invocation, written by
 * utils/commandLogService.js right before a command actually executes
 * (so blocked/blacklisted/on-cooldown attempts are not recorded - only
 * genuine usage is). Powers /commandlogs recent and the optional live
 * usage channel (GuildConfig.commandLogging).
 *
 * guildId is nullable to also support commands used in DMs.
 * Auto-expires after 30 days so this collection doesn't grow forever -
 * plenty for reviewing recent usage without needing indefinite storage.
 */
const commandLogSchema = new Schema(
  {
    guildId: { type: String, default: null, index: true },
    commandName: { type: String, required: true },
    userId: { type: String, required: true },
    channelId: { type: String, default: null },
    createdAt: { type: Date, default: Date.now, expires: 60 * 60 * 24 * 30 },
  },
  { timestamps: false }
);

module.exports = model('CommandLog', commandLogSchema);
