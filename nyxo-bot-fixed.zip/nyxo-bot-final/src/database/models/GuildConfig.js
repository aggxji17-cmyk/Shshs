const { Schema, model } = require('mongoose');
const { AUTOMOD_PUNISHMENTS } = require('../../utils/automodConstants');

/**
 * One shared field shape for every AutoMod check (antiSpam, antiInvite,
 * antiLink, antiMentionSpam, antiMassEmoji, antiCaps, antiZalgo...). Adding
 * a brand new protection type later is just one more `<key>:
 * automodCheckSchema(defaultThreshold)` line here plus one entry in the
 * CHECKS registry (services/automodChecks.js) - nothing else about how a
 * check is stored needs to be redesigned.
 *
 * `threshold`'s meaning is defined per-check by services/automodChecks.js
 * (message count, mention count, emoji count, a percentage, ...); checks
 * that don't use it (antiInvite/antiLink) simply ignore the field.
 */
function automodCheckSchema(defaultThreshold = 0) {
  return {
    enabled: { type: Boolean, default: false },
    punishment: { type: String, enum: AUTOMOD_PUNISHMENTS, default: 'delete' },
    // Only meaningful when punishment === 'timeout'.
    timeoutMinutes: { type: Number, default: 10 },
    threshold: { type: Number, default: defaultThreshold },
  };
}

/**
 * One document per guild. This is the single source of truth for every
 * per-server setting exposed by both slash commands and the dashboard.
 * Anything not set here falls back to the defaults in src/config/config.js.
 */
const guildConfigSchema = new Schema(
  {
    guildId: { type: String, required: true, unique: true, index: true },

    // Task 6: explicit per-guild language override for every bilingual
    // bot reply (see utils/i18n.js#resolveLanguage). null = auto (each
    // member's own Discord client language, English if unsupported) -
    // set via `/language set`.
    language: { type: String, enum: ['ar', 'en', null], default: null },

    prefix: { type: String, default: null },
    embedColor: { type: String, default: null },
    footer: { type: String, default: null },

    modRoleId: { type: String, default: null },
    adminRoleId: { type: String, default: null },
    autoRoleId: { type: String, default: null },
    // Dedicated channel for the unified moderation log (ban/kick/timeout/
    // warn/unban embeds via utils/moderationLogService.js). Separate from
    // the general `logging` channel above, which covers message/member
    // events instead.
    moderationLogChannelId: { type: String, default: null },
    // Per-guild sequential counter backing the moderation Case system
    // (services/caseService.js). Incremented atomically ($inc) every time
    // a new Case is created, so Case IDs are simple, gapless-per-guild
    // integers like #1, #2, #3... instead of Mongo ObjectIds.
    caseCounter: { type: Number, default: 0 },

    welcome: {
      enabled: { type: Boolean, default: false },
      channelId: { type: String, default: null },
      message: {
        type: String,
        default: 'Welcome {user} to **{server}**! You are member #{memberCount}.',
      },
      // Optional banner image shown at the bottom of the welcome embed
      // (e.g. a server-branded graphic). Null = no image.
      imageUrl: { type: String, default: null },
      // Optional embed color override just for welcome messages. Falls
      // back to the guild's normal embedColor (see resolveGuildSettings)
      // when unset.
      color: { type: String, default: null },
      // Separate, optional welcome DM sent directly to the new member
      // in addition to (or instead of) the channel message. Best-effort
      // only - many users have DMs closed to non-friends, and that's
      // silently ignored rather than treated as an error.
      dm: {
        enabled: { type: Boolean, default: false },
        // Falls back to the channel `message` template above when unset,
        // so turning DMs on doesn't require writing a second message.
        message: { type: String, default: null },
      },
    },
    goodbye: {
      enabled: { type: Boolean, default: false },
      channelId: { type: String, default: null },
      message: { type: String, default: '{user} has left **{server}**. Goodbye!' },
    },

    logging: {
      enabled: { type: Boolean, default: false },
      channelId: { type: String, default: null },
      events: {
        messageDelete: { type: Boolean, default: true },
        messageEdit: { type: Boolean, default: true },
        memberJoin: { type: Boolean, default: true },
        memberLeave: { type: Boolean, default: true },
        memberBan: { type: Boolean, default: true },
        memberUnban: { type: Boolean, default: true },
        channelUpdates: { type: Boolean, default: true },
        roleUpdates: { type: Boolean, default: true },
      },
    },

    // Command usage logging (models/CommandLog.js, utils/commandLogService.js,
    // commands/settings/commandlogs.js). Every command invocation that
    // reaches execution is always recorded to the CommandLog collection
    // for /commandlogs recent, regardless of this setting; `enabled` +
    // `channelId` here additionally mirror each usage live to a channel,
    // same shape as the general `logging` block above.
    commandLogging: {
      enabled: { type: Boolean, default: false },
      channelId: { type: String, default: null },
    },

    // Full AutoMod system (services/autoModerationService.js +
    // services/automodChecks.js + commands/automod/automod.js). `enabled`
    // is the master switch - each individual check below has its own
    // enabled flag too, so a check only ever runs when both are on.
    // ignoredRoleIds/ignoredChannelIds are global: a member with one of
    // these roles, or a message in one of these channels, bypasses every
    // check, not just one.
    automod: {
      enabled: { type: Boolean, default: false },
      ignoredRoleIds: { type: [String], default: [] },
      ignoredChannelIds: { type: [String], default: [] },
      checks: {
        antiSpam: automodCheckSchema(5),
        antiInvite: automodCheckSchema(0),
        antiLink: automodCheckSchema(0),
        antiMentionSpam: automodCheckSchema(5),
        antiMassEmoji: automodCheckSchema(7),
        antiCaps: automodCheckSchema(70),
        antiZalgo: automodCheckSchema(30),
      },
    },

    antinuke: {
      enabled: { type: Boolean, default: false },
      whitelistedUserIds: { type: [String], default: [] },
      punishment: { type: String, enum: ['ban', 'kick', 'stripRoles'], default: 'stripRoles' },
      thresholds: {
        channelDelete: { type: Number, default: 3 },
        roleDelete: { type: Number, default: 3 },
        memberBan: { type: Number, default: 3 },
        webhookCreate: { type: Number, default: 3 },
      },
      windowMs: { type: Number, default: 10000 },
    },

    // Mention Protection (services/mentionProtectionService.js): deletes
    // any message that @mentions one of protectedUserIds, unless the
    // author is a guild manager or holds one of bypassRoleIds. Discord
    // gives no way to fully suppress the mention notification itself -
    // by the time the bot sees the message the ping has already fired -
    // so this only guarantees the message is deleted as fast as possible
    // after the fact, not that the notification never arrived.
    mentionProtection: {
      enabled: { type: Boolean, default: false },
      protectedUserIds: { type: [String], default: [] },
      bypassRoleIds: { type: [String], default: [] },
    },

    leveling: {
      enabled: { type: Boolean, default: false },
      announceChannelId: { type: String, default: null },
      xpPerMessage: { type: Number, default: 15 },
      cooldownSeconds: { type: Number, default: 60 },
    },

    tickets: {
      enabled: { type: Boolean, default: false },
      categoryId: { type: String, default: null },
      supportRoleId: { type: String, default: null },
      logChannelId: { type: String, default: null },
      panelChannelId: { type: String, default: null },
      panelMessageId: { type: String, default: null },
      counter: { type: Number, default: 0 },
      // Optional overrides for the panel embed's copy. Left null, the
      // panel falls back to sensible defaults (see ticketsetup.js).
      panelTitle: { type: String, default: null },
      panelDescription: { type: String, default: null },
      panelRules: { type: String, default: null },
      // Fully admin-managed via /ticketsetup type add|remove|list - no code
      // change needed to add, restyle, or remove a ticket button. Each entry
      // becomes one button on the panel (chunked 5-per-row, 25 max, Discord's
      // own component limits). categoryId/supportRoleId here override the
      // guild-wide tickets.categoryId/supportRoleId above for that type only.
      types: {
        type: [
          {
            typeId: { type: String, required: true },
            label: { type: String, required: true },
            emoji: { type: String, default: null },
            style: { type: String, enum: ['Primary', 'Secondary', 'Success', 'Danger'], default: 'Primary' },
            description: { type: String, default: null },
            categoryId: { type: String, default: null },
            // Role pinged in the opening message for this type. Falls back
            // to tickets.supportRoleId (guild default) when unset.
            mentionRoleId: { type: String, default: null },
            // Roles granted ViewChannel/SendMessages on tickets of this
            // type. Falls back to [tickets.supportRoleId] when empty -
            // managed via /ticketsetup type addview|removeview.
            viewRoleIds: { type: [String], default: [] },
            // Shown as the embed description when a ticket of this type
            // opens (supports {user}/{type}/{number} placeholders). Falls
            // back to a generic line when unset.
            welcomeMessage: { type: String, default: null },
            // Channel-name template for this type (supports {user}/{number}
            // placeholders). Falls back to `ticket-<type>-<number>` when unset.
            channelName: { type: String, default: null },
          },
        ],
        default: [],
      },
      // Post-close support rating system (see /ticketrating and
      // components/buttons.js ticket_rate*). Independent on/off switch
      // from tickets.enabled above, so ratings can be toggled without
      // touching the ticket system itself.
      ratings: {
        enabled: { type: Boolean, default: false },
        // Channel staff-facing rating summaries are posted to.
        channelId: { type: String, default: null },
        // DM sent to the ticket opener right after close, before they
        // pick a star rating. Supports {number}/{type} placeholders.
        // Falls back to a sensible default when unset (see buttons.js).
        promptMessage: { type: String, default: null },
        thankYouMessage: { type: String, default: null },
      },
      // "الإغلاق الذكي" - smart close: closing a ticket no longer deletes
      // it right away. Instead the channel is locked and a confirmation
      // message (see services/ticketCloseService.js) with a 🗑️ delete /
      // 🔓 reopen button pair is posted, giving the opener a window to
      // change their mind before the channel is permanently deleted -
      // either by staff clicking delete, or automatically once
      // autoDeleteMinutes elapses (see Ticket.autoDeleteAt).
      closePrompt: {
        // Supports {number}/{type}/{minutes} placeholders. Falls back to
        // a sensible default when unset (see ticketCloseService.js).
        message: { type: String, default: null },
        deleteButtonLabel: { type: String, default: null },
        reopenButtonLabel: { type: String, default: null },
        // Minutes an unattended closed ticket stays before being
        // permanently auto-deleted. 0 disables the auto-delete timer
        // entirely (the ticket then waits for a manual click forever).
        // Default is 4 hours (task 9).
        autoDeleteMinutes: { type: Number, default: 240 },
        // Minutes before auto-delete at which the channel switches from
        // 🔵 (pending deletion) to 🔴 (about to be deleted) so staff can
        // tell from the channel list alone that time is almost up. 0
        // disables the 🔴 warning stage - the channel just stays 🔵 until
        // it's deleted. Default is 30 minutes (task 9).
        warningMinutes: { type: Number, default: 30 },
      },
    },

    suggestions: {
      enabled: { type: Boolean, default: false },
      channelId: { type: String, default: null },
    },

    minecraft: {
      name: { type: String, default: null },
      ip: { type: String, default: null },
      port: { type: Number, default: null },
      // Bedrock (Geyser) shares the same IP as Java - only the port is separate.
      bedrockPort: { type: Number, default: null },
      // Optional URL of a third-party stats endpoint (e.g. a server-side
      // plugin exposing player stats over HTTP) used by /mcprofile to show
      // rank/playtime/kills/deaths. Left null, those fields simply render
      // as "not available" instead of erroring.
      statsApiUrl: { type: String, default: null },
      // Where services/minecraftDeliveryService.js posts a log embed for
      // every shop-purchase delivery attempt (success or failure) - see
      // Task 4. Left null, delivery still happens and is still recorded
      // in the MinecraftDelivery collection; it just isn't mirrored to a
      // channel. Independent of the general `logging` block above.
      deliveryLogChannelId: { type: String, default: null },
    },

    music: {
      twentyFourSeven: {
        enabled: { type: Boolean, default: false },
        // Voice channel the bot stays connected to. Set by /247 enable,
        // and re-used on bot startup (index.js) to reconnect automatically
        // after a restart.
        voiceChannelId: { type: String, default: null },
        // Text channel Now Playing / queue-finished messages get sent to
        // while parked in 24/7 mode with nothing queued.
        textChannelId: { type: String, default: null },
      },
    },

    starboard: {
      enabled: { type: Boolean, default: false },
      channelId: { type: String, default: null },
      threshold: { type: Number, default: 3 },
      emoji: { type: String, default: '⭐' },
      ignoredChannelIds: { type: [String], default: [] },
    },

    verification: {
      enabled: { type: Boolean, default: false },
      channelId: { type: String, default: null },
      roleId: { type: String, default: null },
      panelMessageId: { type: String, default: null },
    },

    invites: {
      enabled: { type: Boolean, default: false },
      logChannelId: { type: String, default: null },
    },

    economy: {
      enabled: { type: Boolean, default: false },
      currencyName: { type: String, default: 'coins' },
      currencySymbol: { type: String, default: '🪙' },
      dailyAmount: { type: Number, default: 100 },
      workMin: { type: Number, default: 20 },
      workMax: { type: Number, default: 150 },
      workCooldownMinutes: { type: Number, default: 60 },
    },

    joinToCreate: {
      enabled: { type: Boolean, default: false },
      triggerChannelId: { type: String, default: null },
      categoryId: { type: String, default: null },
      nameTemplate: { type: String, default: "{username}'s Channel" },
      userLimit: { type: Number, default: 0 },
    },

    boosterAnnounce: {
      enabled: { type: Boolean, default: false },
      channelId: { type: String, default: null },
      message: { type: String, default: '🎉 {user} just boosted **{server}**! Thank you!' },
    },

    memberCountChannel: {
      enabled: { type: Boolean, default: false },
      channelId: { type: String, default: null },
      format: { type: String, default: 'Members: {count}' },
    },

    antiRaid: {
      enabled: { type: Boolean, default: false },
      joinThreshold: { type: Number, default: 8 },
      windowMs: { type: Number, default: 10000 },
      action: { type: String, enum: ['kick', 'ban', 'lockdown'], default: 'lockdown' },
      newAccountAgeDays: { type: Number, default: 7 },
      newAccountAction: { type: String, enum: ['none', 'kick', 'flag'], default: 'flag' },
    },

    moderation: {
      antiGhostPing: { type: Boolean, default: false },
      warnThresholds: {
        type: [
          {
            count: { type: Number, required: true },
            action: { type: String, enum: ['timeout', 'kick', 'ban'], required: true },
            durationMinutes: { type: Number, default: 60 },
          },
        ],
        default: [],
      },
      autoDeleteChannels: {
        type: [{ channelId: { type: String, required: true }, delaySeconds: { type: Number, required: true } }],
        default: [],
      },
      // Weekly /ban quota per role. `weeklyLimit: -1` means unlimited for
      // that role. If a member holds several configured roles, the highest
      // resulting limit applies (unlimited beats any number). Members who
      // hold none of the listed roles are unlimited - only ranks an admin
      // explicitly adds here get capped. See utils/banLimitService.js.
      banLimits: {
        enabled: { type: Boolean, default: false },
        perRole: {
          type: [
            {
              roleId: { type: String, required: true },
              weeklyLimit: { type: Number, required: true },
            },
          ],
          default: [],
        },
      },
      // Same idea as banLimits, but for /kick. Kept as a separate object
      // (rather than reusing banLimits) so ban and kick quotas can be
      // configured independently per role.
      kickLimits: {
        enabled: { type: Boolean, default: false },
        perRole: {
          type: [
            {
              roleId: { type: String, required: true },
              weeklyLimit: { type: Number, required: true },
            },
          ],
          default: [],
        },
      },
      // Same idea again, for /timeout. Each moderation action keeps its own
      // independent quota object so servers can tune ban/kick/timeout
      // limits separately per role.
      timeoutLimits: {
        enabled: { type: Boolean, default: false },
        perRole: {
          type: [
            {
              roleId: { type: String, required: true },
              weeklyLimit: { type: Number, required: true },
            },
          ],
          default: [],
        },
      },
      // Same idea again, for /softban.
      softbanLimits: {
        enabled: { type: Boolean, default: false },
        perRole: {
          type: [
            {
              roleId: { type: String, required: true },
              weeklyLimit: { type: Number, required: true },
            },
          ],
          default: [],
        },
      },
    },

    // Approval-gated moderation actions (services/approvalService.js). When
    // enabled, any action whose name is listed in `requiredActions` no
    // longer executes immediately - instead an ApprovalRequest is created
    // and posted to `reviewChannelId` with Approve/Reject buttons. Adding a
    // brand new gate-able action later needs no schema change here: just
    // add its name to `requiredActions` and make sure
    // scheduleService.getActionExecutor(action) can resolve a handler for
    // it (services/scheduleService.js's registerHandler).
    approvals: {
      enabled: { type: Boolean, default: false },
      reviewChannelId: { type: String, default: null },
      // Empty array means "any moderator" (utils/permissions.js isModerator)
      // may approve/reject. When non-empty, only members holding one of
      // these roles (or a guild manager) can decide a request.
      approverRoleIds: { type: [String], default: [] },
      // How long a Pending request stays open before services/
      // scheduleService.js automatically marks it Expired.
      expiresAfterMinutes: { type: Number, default: 60 },
      // Which moderation actions require approval before running. Anything
      // not listed here still executes immediately, unchanged.
      requiredActions: { type: [String], default: ['ban', 'kick', 'softban', 'timeout'] },
      // Whether the original requester gets DMed when their request is
      // approved/rejected/expired.
      notifyRequester: { type: Boolean, default: true },
    },

    commandBlacklist: {
      userIds: { type: [String], default: [] },
      commandNames: { type: [String], default: [] },
    },

    // Per-channel command disable list (utils/channelCommandBlacklist.js,
    // commands/moderation/blacklist.js "channel" subcommand). A blunt,
    // blocks-everyone switch just like commandBlacklist.commandNames
    // above, just scoped to one channel instead of the whole guild. One
    // array entry per channel that has ANY command disabled in it -
    // channels with no entry here are completely unaffected.
    channelCommandBlacklist: {
      type: [
        {
          channelId: { type: String, required: true },
          commandNames: { type: [String], default: [] },
        },
      ],
      default: [],
    },

    // Per-role command disable list (utils/roleCommandBlacklist.js,
    // commands/moderation/blacklist.js "role" subcommand). Same blunt,
    // blocks-everyone-holding-the-role switch as channelCommandBlacklist
    // above, just scoped to a role instead of a channel. One array entry
    // per role that has ANY command disabled for it - roles with no
    // entry here are completely unaffected.
    roleCommandBlacklist: {
      type: [
        {
          roleId: { type: String, required: true },
          commandNames: { type: [String], default: [] },
        },
      ],
      default: [],
    },

    // Per-command custom permission overrides (utils/commandPermissions.js,
    // commands/moderation/permissions.js), on top of commandBlacklist above.
    // commandBlacklist is a blunt, guild-wide on/off switch; this is
    // finer-grained: role/user-specific allow and deny rules per command
    // name. One array entry per command that has ANY rule configured -
    // commands with no entry here are completely unaffected and fall back
    // to their own setDefaultMemberPermissions + in-code checks (isModerator
    // etc.) exactly as before.
    //
    // Resolution order (see utils/commandPermissions.js):
    //   1. deniedUserIds / deniedRoleIds always win - blocks even a
    //      Discord-permission-holding member from this one command.
    //   2. If allowedUserIds/allowedRoleIds is non-empty, the command
    //      becomes allow-list-only for members who aren't guild managers:
    //      only members on one of those lists (or a guild manager) may use
    //      it, regardless of their Discord permissions.
    //   3. Otherwise (only deny rules, or no rules) the command falls
    //      through to its normal Discord permission bit + in-code checks.
    commandPermissions: {
      type: [
        {
          commandName: { type: String, required: true },
          allowedRoleIds: { type: [String], default: [] },
          allowedUserIds: { type: [String], default: [] },
          deniedRoleIds: { type: [String], default: [] },
          deniedUserIds: { type: [String], default: [] },
          // Channel-scoped rules, same resolution role as the role/user
          // lists above: deniedChannelIds always blocks use of the
          // command in that channel; a non-empty allowedChannelIds
          // restricts the command to only those channels (for
          // non-guild-managers), same as an allow-list of roles/users.
          allowedChannelIds: { type: [String], default: [] },
          deniedChannelIds: { type: [String], default: [] },
        },
      ],
      default: [],
    },

    counting: {
      enabled: { type: Boolean, default: false },
      channelId: { type: String, default: null },
      currentCount: { type: Number, default: 0 },
      lastUserId: { type: String, default: null },
      highestCount: { type: Number, default: 0 },
      resetOnError: { type: Boolean, default: true },
    },

    botStatus: { type: String, default: null },
    activityType: { type: String, default: null },
    activityText: { type: String, default: null },
  },
  { timestamps: true }
);

module.exports = model('GuildConfig', guildConfigSchema);
