// Per-guild configuration for the Smart Alerts weekly AI-ish health report
// (src/services/smartAlertsService.js), configured via /setup-smart-alerts.
const mongoose = require('mongoose');

const schema = new mongoose.Schema(
  {
    guildId: { type: String, required: true, unique: true, index: true },
    channelId: { type: String, required: true },
    enabled: { type: Boolean, default: true },
  },
  { strict: false, timestamps: true }
);

module.exports = mongoose.models.SmartAlertConfig || mongoose.model('SmartAlertConfig', schema);
