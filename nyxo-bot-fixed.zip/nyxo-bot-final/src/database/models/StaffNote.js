const { Schema, model } = require('mongoose');

/**
 * Internal staff-only remarks about a user, separate from Warn/Case.
 * A Warn/Case is a formal punishment record shown to the target and
 * counted toward thresholds; a StaffNote is purely informational context
 * for moderators ("keep an eye on this one", "resolved a support ticket
 * calmly", "alt of <user>, confirmed by IP match") that should never be
 * DMed to the user or counted as a punishment. Kept as its own model
 * instead of piggybacking on Warn so /modhistory, warn thresholds, and
 * the warn-count shown in /userinfo never pick these up by accident.
 */
const staffNoteSchema = new Schema(
  {
    guildId: { type: String, required: true, index: true },
    userId: { type: String, required: true, index: true },
    authorId: { type: String, required: true },
    content: { type: String, required: true, maxlength: 1000 },
  },
  { timestamps: true }
);

// /note list <user>: every note for one member in a guild, newest first.
staffNoteSchema.index({ guildId: 1, userId: 1, createdAt: -1 });

module.exports = model('StaffNote', staffNoteSchema);
