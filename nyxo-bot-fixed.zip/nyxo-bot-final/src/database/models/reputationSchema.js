// Auto-generated legacy-compatibility schema for ported v2.0.8 features.
// Loose/strict:false so any field the legacy code reads or writes works
// without needing every historical field enumerated here.
const mongoose = require('mongoose');

const schema = new mongoose.Schema(
  {
  userId: { type: String, index: true },
  points: { type: Number, default: 0 },
  },
  { strict: false, timestamps: true }
);

module.exports = mongoose.models.Reputation || mongoose.model('Reputation', schema);
