const { Schema, model } = require('mongoose');

/**
 * A recurring or one-off message the bot posts to a channel on its own,
 * without a moderator re-running a command every time. Deliberately its
 * own model rather than reusing ScheduledTask's 'message' action:
 * ScheduledTask is a single-fire, delete-after-run system built around
 * moderation actions, while this is meant to survive its own execution
 * and re-schedule itself (daily/weekly/interval), which doesn't fit that
 * model's Completed/Cancelled/Failed lifecycle without complicating it
 * for every other action type.
 */
const RECURRENCE_TYPES = ['once', 'daily', 'weekly', 'interval'];

const announcementSchema = new Schema(
  {
    guildId: { type: String, required: true, index: true },
    channelId: { type: String, required: true },
    createdBy: { type: String, required: true },
    content: { type: String, required: true, maxlength: 2000 },

    recurrence: { type: String, enum: RECURRENCE_TYPES, required: true },
    // Only used by 'interval': how many minutes between runs.
    intervalMinutes: { type: Number, default: null },
    // Only used by 'weekly': 0 (Sunday) - 6 (Saturday), UTC.
    dayOfWeek: { type: Number, default: null },
    // Only used by 'daily'/'weekly': "HH:MM" 24h, UTC.
    timeOfDay: { type: String, default: null },

    nextRun: { type: Date, required: true, index: true },
    lastRun: { type: Date, default: null },
    active: { type: Boolean, default: true },
  },
  { timestamps: true }
);

// The poller: everything due, across every guild, in one query.
announcementSchema.index({ active: 1, nextRun: 1 });
// /announcement list: one guild's announcements.
announcementSchema.index({ guildId: 1, active: 1 });

const AnnouncementModel = model('Announcement', announcementSchema);
AnnouncementModel.RECURRENCE_TYPES = RECURRENCE_TYPES;

module.exports = AnnouncementModel;
