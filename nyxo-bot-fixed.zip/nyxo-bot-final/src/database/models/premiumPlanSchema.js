// Auto-generated legacy-compatibility schema for ported v2.0.8 features.
// Loose/strict:false so any field the legacy code reads or writes works
// without needing every historical field enumerated here.
const mongoose = require('mongoose');

const schema = new mongoose.Schema(
  {
  name: String,
  price: Number,
  },
  { strict: false, timestamps: true }
);

module.exports = mongoose.models.PremiumPlan || mongoose.model('PremiumPlan', schema);
