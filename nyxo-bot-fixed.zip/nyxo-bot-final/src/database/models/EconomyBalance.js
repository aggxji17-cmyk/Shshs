const { Schema, model } = require('mongoose');

const economyBalanceSchema = new Schema({
  guildId: { type: String, required: true, index: true },
  userId: { type: String, required: true },
  balance: { type: Number, default: 0 },
  lastDaily: { type: Date, default: null },
  lastWork: { type: Date, default: null },
  inventory: { type: [String], default: [] }, // shop item names owned
});

economyBalanceSchema.index({ guildId: 1, userId: 1 }, { unique: true });

module.exports = model('EconomyBalance', economyBalanceSchema);
