const { Schema, model } = require('mongoose');

const suggestionSchema = new Schema(
  {
    guildId: { type: String, required: true, index: true },
    messageId: { type: String, required: true, unique: true },
    userId: { type: String, required: true },
    content: { type: String, required: true },
    status: { type: String, enum: ['pending', 'approved', 'denied'], default: 'pending' },
    upvotes: { type: [String], default: [] },
    downvotes: { type: [String], default: [] },
  },
  { timestamps: true }
);

module.exports = model('Suggestion', suggestionSchema);
