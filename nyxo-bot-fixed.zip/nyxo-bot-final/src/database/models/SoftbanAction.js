const { Schema, model } = require('mongoose');

/**
 * One document per successful softban (ban + immediate unban, used to purge
 * a member's recent messages without permanently banning them). Used to
 * enforce the per-role weekly softban limit and as an audit trail.
 */
const softbanActionSchema = new Schema(
  {
    guildId: { type: String, required: true, index: true },
    moderatorId: { type: String, required: true, index: true },
    targetId: { type: String, required: true },
    reason: { type: String, default: 'No reason provided' },
  },
  { timestamps: true }
);

// Most lookups are "softbans by this moderator, in this guild, since date X".
softbanActionSchema.index({ guildId: 1, moderatorId: 1, createdAt: 1 });

module.exports = model('SoftbanAction', softbanActionSchema);
