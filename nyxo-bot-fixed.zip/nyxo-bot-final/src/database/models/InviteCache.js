const { Schema, model } = require('mongoose');

/**
 * Persists last-known invite use counts so uses can be diffed on
 * guildMemberAdd even across bot restarts (the in-memory client cache
 * resets on restart, but this doesn't).
 */
const inviteCacheSchema = new Schema({
  guildId: { type: String, required: true, index: true },
  code: { type: String, required: true },
  inviterId: { type: String, default: null },
  uses: { type: Number, default: 0 },
});

inviteCacheSchema.index({ guildId: 1, code: 1 }, { unique: true });

module.exports = model('InviteCache', inviteCacheSchema);
