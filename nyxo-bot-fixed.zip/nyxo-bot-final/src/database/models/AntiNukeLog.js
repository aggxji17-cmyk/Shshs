const { Schema, model } = require('mongoose');

/**
 * Rolling log of suspicious actions used purely in-memory-adjacent bookkeeping
 * (kept in Mongo so counts survive a bot restart within the detection window).
 */
const antiNukeLogSchema = new Schema(
  {
    guildId: { type: String, required: true, index: true },
    userId: { type: String, required: true, index: true },
    actionType: { type: String, required: true },
    createdAt: { type: Date, default: Date.now, expires: 3600 },
  },
  { timestamps: false }
);

module.exports = model('AntiNukeLog', antiNukeLogSchema);
