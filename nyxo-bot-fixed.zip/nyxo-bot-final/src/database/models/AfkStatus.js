const { Schema, model } = require('mongoose');

/**
 * Tracks a member's AFK state per guild. Cleared automatically the next
 * time they send a message (see events/message/messageCreate.js).
 */
const afkStatusSchema = new Schema({
  guildId: { type: String, required: true, index: true },
  userId: { type: String, required: true },
  reason: { type: String, default: 'AFK' },
  mentionCount: { type: Number, default: 0 },
  since: { type: Date, default: Date.now },
});

afkStatusSchema.index({ guildId: 1, userId: 1 }, { unique: true });

module.exports = model('AfkStatus', afkStatusSchema);
