const { Schema, model } = require('mongoose');

/**
 * One document per track that actually started playing (written from
 * the Player's PlayerStart event in services/musicService.js - same
 * "one row per event" shape as CommandLog, and for the same reason:
 * a simple find().sort().limit() query is all /history recent needs,
 * with no per-guild document to load and mutate first.
 *
 * Auto-expires after 30 days, matching CommandLog's retention window,
 * so this collection doesn't grow forever.
 */
const musicHistorySchema = new Schema(
  {
    guildId: { type: String, required: true, index: true },
    userId: { type: String, required: true },
    title: { type: String, required: true },
    url: { type: String, required: true },
    duration: { type: String, default: null },
    thumbnail: { type: String, default: null },
    author: { type: String, default: null },
    playedAt: { type: Date, default: Date.now, expires: 60 * 60 * 24 * 30 },
  },
  { timestamps: false }
);

module.exports = model('MusicHistory', musicHistorySchema);
