const { Schema, model } = require('mongoose');

const shopItemSchema = new Schema(
  {
    guildId: { type: String, required: true, index: true },
    name: { type: String, required: true },
    price: { type: Number, required: true },
    description: { type: String, default: '' },
    roleId: { type: String, default: null }, // if set, purchasing grants this role

    // Optional in-game delivery (Task 4: shop <-> Minecraft bridge).
    // Independent of roleId - an item can grant a Discord role, run an
    // in-game command, both, or neither. Delivery runs through
    // services/minecraftDeliveryService.js, which sends `commandTemplate`
    // (after placeholder substitution) to `targetServerId` over
    // NovaBridge's command queue (see services/commandQueueService.js),
    // reusing the plugin's existing "console_command" handler - already
    // shipped and working today, no plugin changes needed.
    //
    // `commandTemplate` supports `{player}` (the buyer's linked Minecraft
    // username) and `{uuid}` (their Minecraft UUID), e.g.:
    //   "lp user {player} parent add vip"          (rank purchase)
    //   "give {player} minecraft:spawner 1"         (item/spawner purchase)
    //
    // Task 5: `kind` decides HOW delivery is timed.
    //   - "rank": the command doesn't need the player to be online (a
    //     permissions plugin like LuckPerms applies it by name/uuid
    //     regardless), so it always runs immediately on `targetServerId`.
    //   - "item": the command (e.g. `give`) only works while the player is
    //     actually online on `targetServerId`, so delivery checks presence
    //     first - online now -> deliver immediately, offline -> saved as a
    //     MinecraftPendingDelivery and delivered automatically the moment
    //     they join that server (see services/minecraftDeliveryService.js
    //     and services/minecraftPendingDeliveryService.js).
    minecraft: {
      enabled: { type: Boolean, default: false },
      kind: { type: String, enum: ['rank', 'item'], default: 'item' },
      targetServerId: { type: String, default: null }, // a MinecraftServer._id, e.g. "survival-01" - which server this item's command runs on
      commandTemplate: { type: String, default: null },
    },
  },
  { timestamps: true }
);

shopItemSchema.index({ guildId: 1, name: 1 }, { unique: true });

module.exports = model('ShopItem', shopItemSchema);
