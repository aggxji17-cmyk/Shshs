const { Schema, model } = require('mongoose');

/** Running per-inviter invite count for a guild, shown by the /invites command. */
const inviteStatSchema = new Schema({
  guildId: { type: String, required: true, index: true },
  userId: { type: String, required: true },
  count: { type: Number, default: 0 },
});

inviteStatSchema.index({ guildId: 1, userId: 1 }, { unique: true });

module.exports = model('InviteStat', inviteStatSchema);
