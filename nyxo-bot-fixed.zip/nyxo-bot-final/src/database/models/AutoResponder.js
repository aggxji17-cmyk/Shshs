const { Schema, model } = require('mongoose');

const autoResponderSchema = new Schema(
  {
    guildId: { type: String, required: true, index: true },
    trigger: { type: String, required: true },
    response: { type: String, required: true },
    matchType: { type: String, enum: ['exact', 'contains'], default: 'contains' },
    createdBy: { type: String, required: true },
  },
  { timestamps: true }
);

autoResponderSchema.index({ guildId: 1, trigger: 1 }, { unique: true });

module.exports = model('AutoResponder', autoResponderSchema);
