// Daily per-guild activity snapshot used by the Smart Alerts weekly health
// check (src/services/smartAlertsService.js). Tracks member count, ban
// volume, and per-staff-member message activity so trends/anomalies can be
// detected over a rolling window.
const mongoose = require('mongoose');

const schema = new mongoose.Schema(
  {
    guildId: { type: String, required: true, index: true },
    date: { type: Date, required: true }, // normalized to 00:00 UTC
    memberCount: { type: Number },
    banCount: { type: Number, default: 0 },
    modActivity: [
      {
        userId: String,
        messageCount: { type: Number, default: 0 },
      },
    ],
    alertSent: { type: Boolean, default: false },
  },
  { strict: false, timestamps: true }
);

schema.index({ guildId: 1, date: 1 }, { unique: true });

module.exports = mongoose.models.ServerSnapshot || mongoose.model('ServerSnapshot', schema);
