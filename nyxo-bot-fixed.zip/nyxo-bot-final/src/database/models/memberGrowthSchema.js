// Daily member-count snapshot per guild. One document per guild per day.
// Backs the member growth tracker (src/services/memberGrowthService.js)
// and the /servergrowth command.
const mongoose = require('mongoose');

const schema = new mongoose.Schema(
  {
    guildId: { type: String, required: true, index: true },
    date: { type: Date, required: true }, // normalized to 00:00 UTC
    count: { type: Number, required: true },
  },
  { strict: false, timestamps: true }
);

schema.index({ guildId: 1, date: 1 }, { unique: true });

module.exports = mongoose.models.MemberGrowth || mongoose.model('MemberGrowth', schema);
