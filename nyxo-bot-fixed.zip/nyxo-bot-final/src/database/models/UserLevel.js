const { Schema, model } = require('mongoose');

const userLevelSchema = new Schema(
  {
    guildId: { type: String, required: true },
    userId: { type: String, required: true, index: true },
    xp: { type: Number, default: 0 },
    level: { type: Number, default: 0 },
    messages: { type: Number, default: 0 },
    lastMessageAt: { type: Date, default: null },
  },
  { timestamps: true }
);

// Serves the guildId+userId upsert/lookup in grantMessageXp()/getRank().
// A separate single-field guildId index was removed - this compound index
// already serves any guildId-only query too (Mongo can use a compound
// index's leftmost prefix), so the old one was pure extra write overhead
// on this collection, which gets an update on nearly every message sent.
userLevelSchema.index({ guildId: 1, userId: 1 }, { unique: true });
// Serves getLeaderboard() (sort by xp within a guild) and getRank()'s
// countDocuments({guildId, xp: {$gt}}) - without this both had to filter
// by guildId then sort/scan in memory.
userLevelSchema.index({ guildId: 1, xp: -1 });

module.exports = model('UserLevel', userLevelSchema);
