const { Schema, model } = require('mongoose');

/**
 * A short-lived, single-use verification code created by /link and, once
 * the plugin side is built (see the "collections.link-codes" comment in
 * NovaBridge's config.yml - to be added in that phase), consumed by an
 * in-game command such as `/discordlink <code>`.
 *
 * Lifecycle:
 *   1. /link inserts a "pending" document (10-minute expiresAt, unique code).
 *   2. The player runs the in-game confirmation command. That future plugin
 *      feature finds the doc by `code`, checks it is still "pending" and not
 *      expired, then sets minecraftUuid/minecraftUsername/completedServerId
 *      and flips status to "completed" - it does NOT create the final
 *      MinecraftLink itself (this plugin only ever reads that collection).
 *   3. NYXO BOT's linkCodeService watcher (see services/linkCodeService.js)
 *      polls for "completed" documents, creates the real MinecraftLink
 *      record, DMs the user the result, and marks the code "finalized" so
 *      it's only ever acted on once.
 *
 * This collection is intentionally separate from MinecraftLink: it only
 * ever holds in-flight verification attempts, never the permanent link.
 */
const linkCodeSchema = new Schema(
  {
    guildId: { type: String, required: true },
    discordId: { type: String, required: true, index: true },

    // Uppercase, ambiguous-character-free (no 0/O/1/I/L) so it's easy to
    // read off a Discord DM and type correctly into Minecraft chat.
    code: { type: String, required: true, unique: true },

    status: {
      type: String,
      enum: ['pending', 'completed', 'finalized', 'failed'],
      default: 'pending',
    },

    // Filled in later, by the in-game confirmation command (Phase 2).
    minecraftUuid: { type: String, default: null },
    minecraftUsername: { type: String, default: null },
    completedServerId: { type: String, default: null },
    completedAt: { type: Date, default: null },

    // Set once NYXO BOT has turned a "completed" code into a real
    // MinecraftLink (or determined it can't be, e.g. already claimed) so
    // the watcher never double-processes the same code.
    finalizedAt: { type: Date, default: null },
    failureReason: { type: String, default: null },

    // 10 minutes from creation. A TTL index purges the document once this
    // passes, on top of the explicit expiry check every lookup already
    // does - see linkCodeService.findActiveCode.
    expiresAt: { type: Date, required: true },
  },
  { timestamps: true, collection: 'link_codes' }
);

linkCodeSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 });
linkCodeSchema.index({ guildId: 1, discordId: 1 });

module.exports = model('LinkCode', linkCodeSchema);
