// Legacy-compatibility schema for ported v2.0.8 premium-guild features.
//
// Canonical shape, matching every reader/writer in the codebase
// (src/commands/community/redeem.js, src/commands/community/guildRedeem.js,
// src/commands/owner/premium.js, dashboard/adminRoutes.js,
// dashboard/routes/guild.js, dashboard/routes/premium.js's Stripe webhook,
// and dashboard/middleware/index.js's checkPremium):
//   { id: <guildId>, isPremiumGuild: <bool>, premium: { expiresAt, plan, redeemedBy, redeemedAt } }
//
// `id` (not `guildId`) is the guild's Discord snowflake and the only field
// ever queried on - it has the real index. strict:false is kept as a safety
// net for any older/extra fields, but every field the app actually reads or
// writes is declared below so Mongoose casts and documents it properly.
const mongoose = require('mongoose');

const premiumDetailsSchema = new mongoose.Schema(
  {
    expiresAt: Date,
    plan: String,
    redeemedBy: { type: [String], default: [] },
    redeemedAt: Date,
  },
  { _id: false }
);

const schema = new mongoose.Schema(
  {
    id: { type: String, index: true, unique: true },
    isPremiumGuild: { type: Boolean, default: false },
    premium: { type: premiumDetailsSchema, default: () => ({}) },
  },
  { strict: false, timestamps: true }
);

module.exports = mongoose.models.PremiumGuild || mongoose.model('PremiumGuild', schema);
