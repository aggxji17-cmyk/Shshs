const { Schema, model } = require('mongoose');

/**
 * Every action `/schedule` currently knows how to run. To add a new
 * schedulable action later: add its name here, then register a handler
 * for it via `scheduleService.registerHandler('yourAction', fn)` - the
 * poller and every other piece of this system are already generic over
 * `action` and need no changes.
 */
// 'approval_expire' backs services/approvalService.js: when an
// ApprovalRequest is created, one of these is scheduled alongside it so a
// request nobody decides on in time flips to Expired automatically
// instead of sitting Pending forever.
const SCHEDULABLE_ACTIONS = ['ban', 'kick', 'timeout', 'unban', 'message', 'temprole_remove', 'approval_expire'];
const SCHEDULE_STATUSES = ['Pending', 'Completed', 'Cancelled', 'Failed'];

/**
 * One document per scheduled moderation task. Separate from `Case`
 * (database/models/Case.js) on purpose: a Case is a record of something
 * that *already happened*; a ScheduledTask is a request for something to
 * happen later. When a task executes successfully, services/
 * scheduleService.js creates a real Case for it via services/
 * caseService.js (the exact same function every manual moderation
 * command uses) - so once it runs, it is indistinguishable from a manual
 * action in /modhistory, /userinfo, etc. Nothing about the Case system
 * needed to change for that to work.
 */
const scheduledTaskSchema = new Schema(
  {
    guildId: { type: String, required: true, index: true },
    action: { type: String, enum: SCHEDULABLE_ACTIONS, required: true },
    moderatorId: { type: String, required: true },
    // For 'unban' this is a raw user ID (the target may not be a member
    // of the guild). For every other action it's a guild member's ID.
    targetId: { type: String, required: true },
    // For action: 'message', this field holds the message content itself
    // rather than a punishment reason - kept as one field instead of two
    // so every action type shares the same document shape.
    reason: { type: String, default: 'No reason provided' },
    // Only used by 'timeout'.
    durationMinutes: { type: Number, default: null },
    // Only used by 'ban' (mirrors /ban's delete_days option).
    deleteDays: { type: Number, default: 0 },
    // Only used by 'message': where to send it. null means DM the target.
    channelId: { type: String, default: null },
    // Only used by 'temprole_remove'. The role to strip from targetId when
    // this task runs (services/tempRoleService.js).
    roleId: { type: String, default: null },

    // The next time this task should be attempted. Set to the requested
    // time on creation; pushed forward on a failed attempt so retries are
    // spaced out instead of hammering the same failure every poll cycle.
    executeAt: { type: Date, required: true, index: true },
    status: { type: String, enum: SCHEDULE_STATUSES, default: 'Pending' },
    attempts: { type: Number, default: 0 },
    lastError: { type: String, default: null },
    executedAt: { type: Date, default: null },
    // The Case number (Case.caseId, not Case._id) created once this task
    // executes successfully - null for the 'message' action, which isn't
    // a punishment and doesn't create a Case. Lets /schedule list link
    // straight to `/case <id>` for completed tasks.
    caseId: { type: Number, default: null },
    cancelledBy: { type: String, default: null },
  },
  { timestamps: true }
);

// The scheduler poll: find everything due, across every guild, in one query.
scheduledTaskSchema.index({ status: 1, executeAt: 1 });
// /schedule list: one guild's tasks, soonest first.
scheduledTaskSchema.index({ guildId: 1, status: 1, executeAt: 1 });
// tempRoleService: find the active temprole_remove task for one member+role
// (duplicate-add checks, manual-removal detection, /temprole remove|extend|cancel).
scheduledTaskSchema.index({ guildId: 1, targetId: 1, roleId: 1, status: 1 });

const ScheduledTaskModel = model('ScheduledTask', scheduledTaskSchema);
ScheduledTaskModel.SCHEDULABLE_ACTIONS = SCHEDULABLE_ACTIONS;
ScheduledTaskModel.SCHEDULE_STATUSES = SCHEDULE_STATUSES;

module.exports = ScheduledTaskModel;
