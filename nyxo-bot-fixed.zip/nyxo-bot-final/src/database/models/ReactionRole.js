const { Schema, model } = require('mongoose');

/**
 * A single message that grants roles when reacted to. `mappings` pairs each
 * emoji (unicode or custom `<:name:id>` key) with the role it grants.
 */
const reactionRoleSchema = new Schema({
  guildId: { type: String, required: true, index: true },
  channelId: { type: String, required: true },
  messageId: { type: String, required: true, unique: true },
  mappings: {
    type: [{ emoji: { type: String, required: true }, roleId: { type: String, required: true } }],
    default: [],
  },
});

module.exports = model('ReactionRole', reactionRoleSchema);
