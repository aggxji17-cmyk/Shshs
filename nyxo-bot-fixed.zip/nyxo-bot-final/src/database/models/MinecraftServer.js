const { Schema, model } = require('mongoose');

/**
 * Read-only mirror of NovaBridge's server registry collection
 * (`registration.collection` in the plugin's config.yml, default
 * "minecraft_servers" - see ServerRegistryService.java). Every Minecraft
 * server running the plugin upserts exactly one document here, keyed by
 * its own unique `server.id`, and refreshes it on a heartbeat.
 *
 * NYXO BOT never writes to this collection - it already exists and is
 * already populated by the plugin as shipped, so this model is usable
 * immediately (no plugin changes needed) to power a "choose a server"
 * picker such as /mcprofile's `server` option.
 *
 * `strict: false` so any field the plugin adds later (before this model
 * is updated to know about it) still comes through instead of being
 * silently stripped.
 */
const minecraftServerSchema = new Schema(
  {
    _id: { type: String }, // the plugin's server.id, e.g. "survival-01", "smp-eu"
    name: { type: String, default: null }, // friendly display name, e.g. "Survival"
    status: { type: String, default: 'offline' }, // "online" | "offline"
    lastHeartbeat: { type: Date, default: null },
    pluginVersion: { type: String, default: null },
    paperVersion: { type: String, default: null },
    minecraftVersion: { type: String, default: null },
    firstSeenAt: { type: Date, default: null },
    updatedAt: { type: Date, default: null },
  },
  { collection: 'minecraft_servers', strict: false, versionKey: false }
);

module.exports = model('MinecraftServer', minecraftServerSchema);
