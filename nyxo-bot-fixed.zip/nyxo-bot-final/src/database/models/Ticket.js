const { Schema, model } = require('mongoose');

const ticketSchema = new Schema(
  {
    guildId: { type: String, required: true, index: true },
    channelId: { type: String, required: true, unique: true },
    userId: { type: String, required: true },
    ticketNumber: { type: Number, required: true },
    // Which configured panel button/type opened this ticket (see
    // GuildConfig.tickets.types). Both null on servers still using the
    // single-button legacy panel, or if the type was deleted afterwards.
    typeId: { type: String, default: null },
    typeLabel: { type: String, default: null },
    status: { type: String, enum: ['open', 'claimed', 'closed'], default: 'open' },
    claimedBy: { type: String, default: null },
    closedBy: { type: String, default: null },
    closedAt: { type: Date, default: null },
    // Smart close (task 8): while status is 'closed' the channel still
    // exists, locked, with a delete/reopen prompt posted in it. This is
    // when that prompt's permanent deletion is scheduled for - null means
    // no auto-delete timer is running (either it was disabled via
    // tickets.closePrompt.autoDeleteMinutes = 0, or the ticket isn't in
    // the pending-deletion window). Cleared whenever the ticket reopens.
    autoDeleteAt: { type: Date, default: null, index: true },
    // Mirrors which close-state emoji (see ticketPanel.js CLOSE_STATUS_EMOJI)
    // is currently applied to the channel name while status is 'closed':
    // 'pending_delete' (🔵) right after closing, then 'near_delete' (🔴)
    // once tickets.closePrompt.warningMinutes remain before auto-delete.
    // null once the ticket isn't in the pending-deletion window (open,
    // reopened, or already permanently deleted). Checked by the scheduler
    // in ticketCloseService.js so it only renames the channel once per
    // transition instead of every time it polls.
    closeStatus: { type: String, enum: ['pending_delete', 'near_delete', null], default: null },
    reopenedBy: { type: String, default: null },
    reopenedAt: { type: Date, default: null },
    // Set once finalizeTicketDeletion actually deletes the channel
    // (manually via 🗑️ or automatically once autoDeleteAt elapses).
    // The Ticket document itself is kept for ratings/history - only the
    // Discord channel is gone.
    permanentlyDeletedAt: { type: Date, default: null },
    // Reply-needed indicator, independent of open/claimed/closed above.
    // 'needs_reply' (🟡) - the ticket opener sent the last message and is
    // waiting on staff. 'no_action' (🟢) - staff (or nobody) has the ball.
    // Flips automatically on every message per whoever sent it (see
    // messageCreate.js), and can be flipped manually by staff via the
    // status button. Mirrored into the channel name so staff can read it
    // straight from the channel list - see ticketPanel.js's STATUS_EMOJI.
    replyStatus: { type: String, enum: ['needs_reply', 'no_action'], default: 'needs_reply' },
    // The channel name without its status-emoji prefix, so renames can
    // reapply the right emoji without accumulating/mismatching prefixes.
    baseChannelName: { type: String, default: null },

    // Task 5 (Race Condition fix): mirrors "status !== 'closed'" as a
    // plain boolean so it can back a partial unique index below. Set to
    // true on creation and on reopen (ticketCloseService.js#reopenTicket),
    // false on close (buttons.js#ticket_close). Kept in sync everywhere
    // `status` transitions to/from 'closed' - it is never read on its own
    // as a source of truth for ticket state, `status` still is.
    isOpen: { type: Boolean, default: true },
  },
  { timestamps: true }
);

// حد أقصى تذكرة نشطة واحدة لكل عضو في كل سيرفر - يفرضه MongoDB نفسه
// وليس كود التطبيق، فلا يمكن لأي تزامن (ضغط مزدوج، أو نداءان متزامنان)
// أن يُنشئ تذكرتين نشطتين لنفس العضو مهما كان التوقيت. partialFilterExpression
// يقصر الفهرس على الوثائق التي isOpen:true فقط، فلا يمنع تراكم عدد
// غير محدود من التذاكر المغلقة لنفس العضو - فقط يمنع تذكرتين نشطتين
// في آنٍ واحد. تُستخدم هنا مساواة بسيطة (isOpen: true) بدل $in/$ne
// لأن partialFilterExpression لا يدعم $ne إطلاقاً، ودعم $in مرتبط
// بإصدار MongoDB (5.0+) وغير مضمون على كل البيئات (مثل بعض توافقات
// DocumentDB) - المساواة البسيطة مدعومة في كل الإصدارات والبيئات.
ticketSchema.index(
  { guildId: 1, userId: 1 },
  { unique: true, partialFilterExpression: { isOpen: true }, name: 'uniq_active_ticket_per_member' }
);

module.exports = model('Ticket', ticketSchema);
