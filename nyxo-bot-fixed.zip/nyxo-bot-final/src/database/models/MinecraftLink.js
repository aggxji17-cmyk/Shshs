const { Schema, model } = require('mongoose');

/**
 * Links a Discord member to a Minecraft Java Edition account within a
 * guild. A given Discord user may hold at most one link per guild, and a
 * given Minecraft account (identified by UUID, not username, since names
 * can change) may likewise be claimed by at most one Discord user per
 * guild - both are enforced by the compound unique indexes below, in
 * addition to the application-level checks in /mclink.
 */
const minecraftLinkSchema = new Schema(
  {
    guildId: { type: String, required: true, index: true },
    discordId: { type: String, required: true },
    minecraftUuid: { type: String, required: true },
    minecraftUsername: { type: String, required: true },
    linkedBy: { type: String, required: true },
  },
  // Explicit collection name so this matches NovaBridge's `collections.discord-links`
  // (config.yml, default "discord_links" - see PlayerRepository.findDiscordLink on the
  // plugin side). Without this, Mongoose would default to "minecraftlinks", which the
  // plugin would never find anything in.
  { timestamps: true, collection: 'discord_links' }
);

// One Minecraft link per Discord member, per guild.
minecraftLinkSchema.index({ guildId: 1, discordId: 1 }, { unique: true });
// One owner per Minecraft account, per guild.
minecraftLinkSchema.index({ guildId: 1, minecraftUuid: 1 }, { unique: true });

module.exports = model('MinecraftLink', minecraftLinkSchema);
