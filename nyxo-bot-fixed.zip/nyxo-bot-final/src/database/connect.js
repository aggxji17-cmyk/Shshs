const mongoose = require('mongoose');
const { config } = require('../config/config');
const logger = require('../utils/logger');

mongoose.set('strictQuery', true);

async function connectDatabase() {
  try {
    await mongoose.connect(config.mongoUri);
    logger.success('Connected to MongoDB');
  } catch (err) {
    logger.error(`Failed to connect to MongoDB: ${err.message}`);
    process.exit(1);
  }

  mongoose.connection.on('disconnected', () => {
    logger.warn('MongoDB connection lost. Mongoose will attempt to reconnect automatically.');
  });

  mongoose.connection.on('error', (err) => {
    logger.error(`MongoDB connection error: ${err.message}`);
  });
}

module.exports = connectDatabase;
