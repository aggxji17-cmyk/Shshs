/**
 * discord-player-youtubei optionally uses `youtube-dl-exec` as a rare
 * fallback. That package needs Python installed on the server to download
 * the yt-dlp binary during its own install step; when Python isn't
 * available (common on Pterodactyl Node.js containers), its install
 * script throws and npm/yarn removes the package entirely, which then
 * crashes the bot with MODULE_NOT_FOUND the moment discord-player-youtubei
 * tries to require() it - even though normal YouTube playback never
 * actually needs it (that goes through youtubei.js).
 *
 * This script runs automatically after every `npm install` / `yarn
 * install` (see the "postinstall" script in package.json) and makes sure
 * *something* importable exists at node_modules/youtube-dl-exec, so the
 * require() in discord-player-youtubei always succeeds. If the real
 * package installed successfully (Python was available), this script
 * leaves it completely untouched. It only steps in when the real package
 * is missing or broken.
 */
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';

const require = createRequire(import.meta.url);
const __dirname = path.dirname(fileURLToPath(import.meta.url));

const target = path.join(__dirname, '..', 'node_modules', 'youtube-dl-exec');

function isUsable() {
  try {
    require(target);
    return true;
  } catch {
    return false;
  }
}

if (isUsable()) {
  console.log('[ensure-youtube-dl-stub] Real youtube-dl-exec is present and working - leaving it as is.');
  process.exit(0);
}

fs.rmSync(target, { recursive: true, force: true });
fs.mkdirSync(target, { recursive: true });

fs.writeFileSync(
  path.join(target, 'package.json'),
  JSON.stringify(
    {
      name: 'youtube-dl-exec',
      version: '0.0.0-stub',
      main: 'index.js',
      description: 'Safety stub installed automatically because the real package could not install (missing Python). See scripts/ensure-youtube-dl-stub.js.',
    },
    null,
    2
  )
);

fs.writeFileSync(
  path.join(target, 'index.js'),
  `// Auto-generated safety stub - see scripts/ensure-youtube-dl-stub.js
//
// IMPORTANT: this must be a *plain, concrete* object/function - not a
// Proxy. discord-player-youtubei accesses this module in a couple of
// different shapes depending on how its bundler (esbuild) wired up the
// CJS/ESM interop for this dependency, e.g. both:
//   require('youtube-dl-exec').constants
//   require('youtube-dl-exec').default.constants
// A Proxy's "get" trap only intercepts ONE level of property access: the
// previous version of this stub used
//   new Proxy(notAvailable, { get: () => notAvailable })
// which meant mod.default returned the *plain* notAvailable function
// (not another proxy), so the next property access - .default.constants -
// hit a real function with no "constants" property and evaluated to
// undefined, crashing the whole process at require() time with
// "Cannot read properties of undefined (reading 'constants')" before any
// try/catch in our own code could ever run.
//
// The fix: give every level of access (bare, .default, .default.default,
// ...) a real, identical object so no matter which shape the caller
// reads, it finds the same populated stub - never undefined.

const constants = {
  YOUTUBE_DL_HOST: 'https://github.com/yt-dlp/yt-dlp/releases/',
  YOUTUBE_DL_DIR: 'bin',
  YOUTUBE_DL_FILE: process.platform === 'win32' ? 'yt-dlp.exe' : 'yt-dlp',
  YOUTUBE_DL_PATH: require('path').join(
    __dirname,
    'bin',
    process.platform === 'win32' ? 'yt-dlp.exe' : 'yt-dlp'
  ),
};

function notAvailable() {
  throw new Error(
    'youtube-dl-exec is not available on this server (Python is missing), ' +
      'so this rarely-used fallback path cannot run. Normal YouTube playback ' +
      'via youtubei.js is unaffected.'
  );
}

notAvailable.exec = notAvailable;
notAvailable.raw = notAvailable;
notAvailable.create = () => notAvailable;
notAvailable.constants = constants;
// Self-reference so .default, .default.default, etc. all resolve to this
// same fully-populated stub instead of a bare function with nothing on it.
notAvailable.default = notAvailable;
notAvailable.__esModule = false;

module.exports = notAvailable;
`
);

console.log('[ensure-youtube-dl-stub] Real youtube-dl-exec was missing/broken - installed a safe stub instead.');
