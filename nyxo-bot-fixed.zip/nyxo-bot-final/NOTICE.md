# Notice

NYXO (the bot, its commands, services, database schemas, and the
accompanying web dashboard) is copyright (c) 2026 NYXO BOT. All rights
reserved. See [LICENSE](./LICENSE) for full terms.

## Third-party components

This project is built with the following open-source packages, each of
which remains under its own license (see each package's own repository
for full license text):

- discord.js — Apache-2.0
- mongoose — MIT
- express / express-session — MIT
- connect-mongo — MIT
- dotenv — BSD-2-Clause
- axios — MIT
- archiver — MIT
- minecraft-server-util — MIT
- discord-player, @discord-player/extractor, discord-player-youtubei — MIT
- @napi-rs/canvas — MIT

Use of these packages does not transfer any rights to NYXO BOT's own
source code, branding, or assets, which remain proprietary as described
in LICENSE.

## Third-party assets

Minecraft-related assets referenced under `assets/minecraft/` (item and
GUI textures, fonts) are the property of Mojang/Microsoft and are not
included or redistributed in this repository — see
`assets/minecraft/README.md` for how to source them yourself.
