// Root entry point.
// Pterodactyl's startup command is fixed to "node index.js", but the actual
// bot code lives in src/index.js. This file simply forwards execution there
// so the startup command works without needing to be changed.
require('./src/index.js');
