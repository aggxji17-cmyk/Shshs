// Lightweight in-memory cooldown gate used by the ported legacy commands
// (e.g. the /imagine AI image command). Mirrors src/utils/cooldown.js's
// style but exposes the gate(key, windowMs) API the legacy code expects:
// returns null when the action may proceed (and starts the window), or
// the number of seconds remaining if the caller is still on cooldown.
const buckets = new Map();

function gate(key, windowMs) {
  if (!windowMs || windowMs <= 0) return null;

  const now = Date.now();
  const expiresAt = buckets.get(key);

  if (expiresAt && expiresAt > now) {
    return Math.ceil((expiresAt - now) / 1000);
  }

  buckets.set(key, now + windowMs);
  return null;
}

const sweepTimer = setInterval(() => {
  const now = Date.now();
  for (const [key, expiresAt] of buckets) {
    if (expiresAt <= now) buckets.delete(key);
  }
}, 5 * 60_000);
sweepTimer.unref();

module.exports = { gate };
