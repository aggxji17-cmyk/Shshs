// Small helper shared by the ported legacy setup commands (setup-apply,
// setup-menuapply) for numbering select-menu options 1-10.
function getNumberEmojis() {
  return ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟'];
}

module.exports = { getNumberEmojis };
