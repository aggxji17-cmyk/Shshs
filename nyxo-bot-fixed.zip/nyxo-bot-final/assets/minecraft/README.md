# Minecraft texture assets (not included)

This folder holds the Mojang texture assets `services/inventoryRenderService.js`
needs to render `/inv`'s inventory image. They are **not bundled** with
this repository (Mojang's assets are copyrighted) - populate them
yourself from a legitimately owned copy of the game or your server's
resource pack before enabling the feature.

```
assets/minecraft/
├── gui/
│   └── inventory.png        176x166px - textures/gui/container/inventory.png
├── items/
│   └── <item_id>.png        16x16px each - textures/item/*.png + textures/block/*.png
│                             named after the Material key, e.g. diamond_sword.png
└── font/
    └── minecraft.ttf        optional - used for stack-count numbers
```

Until `gui/inventory.png` exists, `/inv` replies with a clear
"not set up yet" message instead of attempting to render (see
`assetsReady()` in `services/inventoryRenderService.js`).
